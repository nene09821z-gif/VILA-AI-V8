# VILA AI Studio 68.1.0 — Cohesive UI, AI Workspace + Chat Archive

Ứng dụng Android (WebView) kết nối nhiều nhà cung cấp AI, kèm AI Gateway (Node.js) tuỳ chọn. Gói này là mã nguồn, không phải APK/AAB dựng sẵn. Không đóng gói keystore ký; CI tạo debug key tạm hoặc nhận `ANDROID_DEBUG_KEYSTORE_BASE64` qua GitHub Secrets.

## V68.1.0 — Reliability and Play release lane
- Real conversation archive with switching, rename/delete, JSON text-only backup import/export, and bounded local persistence.
- GitHub Actions builds a debug APK for device testing and builds a signed release AAB only when all private signing secrets are configured. Missing signing keys are reported explicitly; no unsigned release bundle is presented as Play-ready.
- `npm run play:preflight` reports release readiness blockers; `npm run play:preflight:strict` exits nonzero while mandatory owner-provided Play data is missing.
- Version metadata: app/Gateway `68.1.0`, Android `versionCode 81`, `targetSdk 36`.
- **Not Play-approved yet:** owner contact details and real public HTTPS privacy/account-deletion URLs are intentionally not fabricated. See `docs/PLAY_STORE_READINESS.md` and `docs/BUILD_GUIDE_V68.md`.

## V68.1.0 Cohesive UI — hotfix mới nhất
- Đưa toàn bộ lớp CSS ứng dụng (kể cả final palette) về `<head>` theo đúng thứ tự cascade và chuyển `vila-simple.css` về head; tránh stylesheet cũ được chèn sau khi nội dung đã hiện khiến giao diện lóe màu cũ.
- Bỏ hẳn particle canvas/neon loop thay vì chỉ ẩn nó; nhãn trạng thái nhà cung cấp dùng cùng một bảng màu trung tính. Chỉ tắt hiệu ứng pulse/neon cũ, giữ chuyển trạng thái và độ nổi nhẹ ở thành phần cần thiết.
- Theme bootstrap chạy trước CSS/JS từ CDN, cố định màu của khung chat/header/model selector ngay từ first paint.
- Bỏ splash neon chạy liên tục, keyframes cũ và CSS Model Hub cũ chứa bảng màu cyan/tím; gom UI Model Hub vào một stylesheet, có hàng lọc tự xuống dòng và vùng danh sách cuộn.
- Sửa lỗi selector ẩn phần cha `ds-model-copy`, giúp nút chọn model cùng tên model hiện ra; dùng một nút Gửi/Dừng thay vì thêm nút Dừng nổi trùng lặp. Sửa thêm bốn shortcut Khám phá AI từng trỏ tới ID nút đã bị xóa.
- Xóa rail lịch sử nổi và kho chat-tab cũ; chỉ còn một hệ thống lịch sử có lưu trữ và mục mở trong menu chính.
- Bảng màu trung tính cho các màn cài đặt, Model Hub, Gateway, preview và đăng nhập; chế độ sáng/tối dùng chung token màu. Bổ sung selector ưu tiên cao để chặn gradient cũ trên chip model, thanh nhập, Khám phá và khung ảnh.
- `npm test`: 33/33 nhóm kiểm tra tự động đạt; 5 XML và 3 JSON hợp lệ, không trùng ID tĩnh, mọi tham chiếu `getElementById` dạng literal đều có đích. Visual rendering trên thiết bị thật chưa được kiểm chứng trong workspace này.
- Bản ZIP là mã nguồn, không phải APK/AAB đã build. Xem `VILA_V68_TEST_REPORT.md` để biết giới hạn hiện tại.

## V66 Clean UI
- Compact mobile-first chat layout with only Light/Dark theme modes.
- Model Hub filters wrap cleanly instead of overlapping the sorting selector.
- Google sign-in buttons explicitly say “Đăng nhập bằng Google”.
- Removed the duplicate floating navigation control; moved Voice Studio into the main menu so it no longer covers the composer. Max Mode is placed in the chat status row.
- Source ZIP only. Android build/sign-in and provider calls still need verification in the actual configured environment.

## Puter AI Hub
Puter.js được tích hợp như một provider độc lập. VILA tự đồng bộ danh mục model chat do Puter công bố qua `puter.ai.listModels()` và cho phép tìm theo model/provider. Danh mục thay đổi theo dịch vụ; chỉ các model thực tế từ catalog được đưa vào danh sách động. Puter có thể yêu cầu đăng nhập, giới hạn/quota và chi phí (nếu có) phụ thuộc tài khoản/chính sách dịch vụ. Xem `docs/CLAUDE_PUTER.md`.

## Model Hub Turbo (V62)
Danh mục model có tìm kiếm không phân biệt dấu tiếng Việt, lọc theo provider/khả năng, mục yêu thích, lịch sử model gần đây và tải hiển thị theo lô 60 mục để giảm tải trên điện thoại. Khả năng ảnh/suy luận/web ưu tiên metadata do provider công bố; bộ lọc lập trình có thể dùng tên model làm gợi ý. Nhãn `FREE*` không bảo đảm model còn miễn phí, quota hoặc khả dụng tại thời điểm gửi.

## Cấu trúc
- `app/` — ứng dụng Android (Java + giao diện web trong `assets/`)
- `server/` — AI Gateway (Express, Firebase Admin, định tuyến nhiều provider, đa đội suy luận, công cụ agent)
- `scripts/` — kiểm tra hồi quy mã nguồn (không cần mạng)
- `tools/play-preflight.js` — kiểm tra các điều kiện phát hành và chặn nếu còn placeholder bắt buộc
- `docs/` — Firebase, đăng nhập Google, Gateway, Play Store, bản đồ kỹ thuật và quy tắc chủ sở hữu
- `.github/workflows/main.yml` — CI: test, build APK, kiểm tra SHA-1 Google OAuth
- `CHANGELOG.md` — lịch sử thay đổi
- `VILA_V68_TEST_REPORT.md` — kết quả kiểm thử thực tế và các giới hạn chưa xác minh

## Chạy kiểm tra
```bash
npm test                       # Gateway + kiểm tra hồi quy giao diện/mã nguồn
npm run play:preflight         # Báo cáo các điều kiện còn thiếu trước khi phát hành
npm run play:preflight:strict  # Mã thoát khác 0 nếu còn hạng mục chặn phát hành
```

## Chạy Gateway
```bash
cp server/.env.example server/.env   # điền khoá provider của bạn
cd server && npm install && npm start
```
Triển khai production: xem `docs/GATEWAY_DEPLOYMENT.md` và `compose.yaml` (chỉ bind loopback; cần reverse proxy HTTPS).

**Giới hạn lượt nội bộ:** Gateway mặc định giới hạn theo `REQUESTS_PER_MINUTE=30`. Chủ server có thể đặt `REQUESTS_PER_MINUTE=0` để tắt riêng giới hạn RPM nội bộ của VILA; giới hạn đồng thời và quota/rate limit của từng nhà cung cấp AI vẫn áp dụng. Không có cài đặt nào biến quota của Google/nhà cung cấp thành vô hạn.

## Build APK
Đẩy toàn bộ nội dung thư mục này lên GitHub, chạy workflow **VILA AI - Android Build and Verify** và tải artifact. Xem `docs/BUILD_GUIDE_V68.md` để build APK kiểm thử và tạo AAB ký phát hành bằng GitHub Actions.

## Giới hạn đã biết
- APK chỉ được coi là build thành công sau khi GitHub Actions chạy xong; đăng nhập Google cần SHA-1 khớp với Firebase.
- Danh mục Puter là dữ liệu trực tiếp của dịch vụ, không cam kết mọi model đều truy cập được hoặc miễn phí.
- `privacy-policy.html` và `account-deletion.html` là bản nháp, cần điền thông tin thật và host HTTPS trước khi lên Play Store (`docs/PLAY_STORE_READINESS.md`).
- Gradle Wrapper hiện chưa đầy đủ; CI cài Gradle 9.3.1 để build. Chưa có APK/AAB đã xác minh trong ZIP này.
- Không có cam kết uptime 24/7; xem `docs/TECHNOLOGY_MAP.md`.
