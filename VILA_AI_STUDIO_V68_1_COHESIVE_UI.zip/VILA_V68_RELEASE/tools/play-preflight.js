'use strict';
/* Production release preflight. It returns nonzero while owner-only Play requirements are unresolved. */
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const findings = [];
function read(rel) { return fs.readFileSync(path.join(root, rel), 'utf8'); }
function pass(s) { findings.push({ level: 'PASS', message: s }); }
function warn(s) { findings.push({ level: 'WARN', message: s }); }
function block(s) { findings.push({ level: 'BLOCK', message: s }); }
try {
  const pkg = JSON.parse(read('package.json'));
  const gatewayPkg = JSON.parse(read('server/package.json'));
  const gradle = read('app/build.gradle');
  const workflow = read('.github/workflows/main.yml');
  const privacy = read('privacy-policy.html');
  const deletion = read('account-deletion.html');
  const manifest = read('app/src/main/AndroidManifest.xml');
  if (!fs.existsSync(path.join(root, 'gradlew')) || !fs.existsSync(path.join(root, 'gradle/wrapper/gradle-wrapper.jar'))) {
    warn('Gradle Wrapper chưa đầy đủ (thiếu gradlew và/hoặc gradle-wrapper.jar); dùng GitHub Actions theo hướng dẫn hoặc bổ sung Wrapper chính thức trước khi build CLI cục bộ.');
  } else pass('Gradle Wrapper launcher và JAR có mặt.');
  if (pkg.version === '68.1.0' && gatewayPkg.version === pkg.version && gradle.includes(`versionName "${pkg.version}"`) && gradle.includes('versionCode 81')) pass('Phiên bản V68.1.0 đồng bộ giữa ứng dụng, Gateway và package.');
  else block('Version metadata chưa đồng bộ.');
  const sdk = Number((gradle.match(/targetSdk\s+(\d+)/) || [])[1] || 0);
  if (sdk >= 36) pass(`targetSdk ${sdk} đáp ứng ngưỡng Google Play công bố cho ứng dụng mới/cập nhật từ 31-08-2026.`);
  else block(`targetSdk ${sdk} thấp hơn API 36.`);
  if (/bundleRelease/.test(workflow) && /ANDROID_KEYSTORE_BASE64/.test(workflow)) pass('CI có đường build App Bundle và nhận release keystore qua secret.');
  else block('CI chưa có quy trình build AAB ký release từ secrets.');
  if (/BẢN MẪU CHƯA ĐỦ ĐIỀU KIỆN PHÁT HÀNH|\[CẦN ĐIỀN\]|\[TÊN CÁ NHÂN|\[EMAIL LIÊN HỆ|\[URL CHÍNH SÁCH/i.test(privacy)) block('Chính sách quyền riêng tư còn thông tin chủ sở hữu/URL phải điền thật.');
  else pass('Không phát hiện placeholder phổ biến trong trang chính sách quyền riêng tư.');
  if (/TRANG MẪU — CHƯA SẴN SÀNG|\[EMAIL_LIEN_HE\]|\[THỜI HẠN XỬ LÝ/i.test(deletion)) block('Trang yêu cầu xóa tài khoản chưa có thông tin liên hệ và thời hạn xử lý thật.');
  else pass('Không phát hiện placeholder phổ biến trong trang yêu cầu xóa tài khoản.');
  if (/usesCleartextTraffic="true"/.test(manifest)) warn('Android cho phép HTTP cleartext vì giao diện loopback/local-provider; cần đánh giá luồng mạng trước khi phát hành public.');
  if (!/ANDROID_KEYSTORE_PASSWORD\s*=\s*[^\n]{8,}/.test(read('.env.production.example'))) pass('Không thấy mật khẩu keystore dạng rõ trong ví dụ môi trường.');
  warn('Chưa thể xác minh bằng preflight: APK/AAB đã ký, Firebase/OAuth live, URL HTTPS đã host, Data safety form, thiết bị thật và Play Console review.');
} catch (error) {
  block('Không đọc đủ hồ sơ phát hành: ' + String(error && error.message || error));
}
for (const f of findings) console.log(`[${f.level}] ${f.message}`);
const blockers = findings.filter(f => f.level === 'BLOCK').length;
console.log(`\nKết quả: ${findings.filter(f => f.level === 'PASS').length} đạt · ${findings.filter(f => f.level === 'WARN').length} cảnh báo · ${blockers} chặn phát hành.`);
if (process.argv.includes('--strict') && blockers) process.exitCode = 1;
