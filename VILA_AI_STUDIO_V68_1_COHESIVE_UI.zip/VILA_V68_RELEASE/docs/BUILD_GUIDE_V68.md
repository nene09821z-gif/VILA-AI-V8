# VILA AI Studio V68.1.0 — Build, verify, and release guide

This package is source code. It does not contain a verified APK or AAB. The current workspace has no Android SDK/ADB/Gradle executable, and this ZIP has only `gradle-wrapper.properties` (not the `gradlew` launchers or `gradle-wrapper.jar`); therefore the prescribed build path is GitHub Actions, which installs Gradle 9.3.1, or a separate full Android build environment with Gradle installed.

## 1. Verify the source package locally

Requirements: Node.js 20 or newer (Node.js 22 recommended). The root source tests depend on PostCSS, declared in `package.json`; install dependencies before the first run.

```bash
npm install --no-audit --no-fund
npm test
npm run play:preflight
```

`npm test` currently reports 33/33 test groups passing. It runs Gateway unit tests plus offline source-regression checks, including V68 CSS loading order before body paint, neutral provider status, unique static IDs, no missing literal element references, theme bootstrap, and Model Hub selector checks. It does not call external AI APIs or prove that Firebase sign-in works live. `npm run play:preflight` lists release blockers. The strict version exits nonzero while owner-specific release requirements are still missing:

```bash
npm run play:preflight:strict
```

## 2. Build a test APK using GitHub Actions

1. Create a private or public GitHub repository under your control.
2. Extract this ZIP and upload the **contents** of `VILA_V68_RELEASE/` to the repository root. Do not commit a second VILA release ZIP into the root; the workflow can extract a ZIP if present, which can cause it to build the wrong version.
3. Push to `main`/`master`, or run **VILA AI - Android Build and Verify** from Actions.
4. The workflow runs Gateway/source tests, validates configured Firebase/OAuth identifiers, runs Android unit tests/lint, and always attempts to build a debug APK.
5. Download the `VILA-AI-V68-Build-Files-*` artifact. Install only the debug APK for testing. It is not the signed Play release.

## 3. Build a Google Play App Bundle (AAB)

The CI workflow intentionally builds a release AAB only when all signing secrets are supplied. This prevents an unsigned `release` output from looking like a Play-ready deliverable.

Create/use a private upload keystore in a trusted environment. Never commit it, paste its password into source, or use the debug keystore as your Play upload key. Export the keystore file as Base64 locally and configure these GitHub Actions secrets:

- `ANDROID_KEYSTORE_BASE64` — Base64 of the binary `.jks`/`.keystore` file.
- `ANDROID_KEYSTORE_PASSWORD` — keystore password.
- `ANDROID_KEY_ALIAS` — alias inside the keystore.
- `ANDROID_KEY_PASSWORD` — key password.

The workflow decodes the file into the temporary runner directory, checks the alias/password, passes the path to Gradle, builds `bundleRelease`, runs `lintRelease`, verifies that the `.aab` exists and performs a JAR-signature verification before including `VILA-AI-68.1.0-release.aab` in the artifact. A bundle can still fail Play Console validation or review; signature verification is only one gate.

Keep the upload-key backup offline and private. If the app is enrolled in Play App Signing, the upload key is not the same as the Play app-signing key managed by Google.

## 4. Firebase and Google sign-in

The source package deliberately does **not** include a debug keystore. CI creates a throwaway debug key for routine builds. Google sign-in may not work on that debug APK until its SHA-1 is registered in Firebase. To reproduce a stable debug fingerprint privately, configure the `ANDROID_DEBUG_KEYSTORE_BASE64` GitHub secret with a debug keystore whose store password is `android` and alias is `androiddebugkey`; never commit that file. The CI step fails if a supplied stable key fingerprint is not registered. This key is separate from all Play upload/release signing keys.


Configure the correct Firebase Android application for package `com.vila.ai`, enable the required sign-in providers, and confirm the Web OAuth client ID is correct. Add the SHA-1/SHA-256 fingerprints for the actual signing certificate(s) in Firebase Console. A debug keystore fingerprint is not the same as a release upload-key fingerprint. The CI workflow validates the Web OAuth client and verifies the debug SHA-1 if a private stable key is configured; with an ephemeral key it warns when the fingerprint is not registered. It does not prove live Google sign-in on a handset.

Use the real project-owned `app/google-services.json` and `app/src/main/assets/firebase-config.js`. Do not expose a service-account JSON, provider secret, or real `.env` file in this ZIP. Firebase client configuration values are client-side identifiers, not a substitute for backend authorization rules.

## 5. Gateway setup

```bash
cp server/.env.example server/.env
cd server
npm install --no-audit --no-fund
npm test
npm start
```

Set production `AUTH_MODE=firebase`, a valid Firebase project/service credential, provider keys in a server-side secret store, and explicit trusted `CORS_ORIGINS`. Deploy behind an HTTPS reverse proxy. Do not expose the raw Gateway port to the public Internet. Configure upstream spending/rate limits independently: fallback does not make third-party quota unlimited.

## 6. Google Play release checklist

Before submission, the owner must:

- Replace all owner/contact/URL/deletion-time placeholders in `privacy-policy.html` and `account-deletion.html` with true details and host both pages publicly over HTTPS.
- Test in-app account deletion and the external deletion request path; decide what happens to data held by VILA and by third-party AI providers.
- Complete the Play Console Data safety form, app access instructions, content rating, target audience, ads declaration, developer contact information, and store listing truthfully.
- Test a signed AAB through Play internal testing on at least one low-end and one current Android device. Verify Google sign-in, email auth/reset, API errors/fallback, attachments, Voice Studio, theme, history restore and data deletion.
- Confirm the final app's permissions, network traffic, dependencies/licenses, privacy policy, account deletion and logging match the actual release binary.
- Keep the final `npm test`, CI build logs, signing verification, device-test checklist and preflight report as release evidence.

As of the official Google Play target-API page currently published, new apps and updates must target Android 16 / API 36 or higher from 31 August 2026. This project sets `targetSdk 36`; confirm the requirement again in Play Console before submission: https://support.google.com/googleplay/android-developer/answer/11926878?hl=en.

Account-creation apps also need an in-app way to request account deletion and an externally accessible request path. Official policy: https://support.google.com/googleplay/android-developer/answer/13327111?hl=en.

## Known unverified or blocked items
- The headless Chromium screenshot attempt timed out in the current workspace; no actual browser/device layout is claimed as verified. The stylesheet order was corrected to prevent late palette repaint, but visual QA must still recheck the first frame, selected model label, Model Hub wrapping and composer controls on an installed Android build.

- No APK/AAB was built in this workspace because Android SDK/Gradle are unavailable here.
- Live Firebase/Google OAuth and live AI providers were not called during the offline test run.
- The privacy and external account-deletion pages intentionally remain templates until the project owner supplies truthful contact details and hosting URLs; strict Play preflight is expected to fail until these are completed.
- `usesCleartextTraffic="true"` remains in the Android manifest to support the current loopback UI and user-configurable local/LAN AI endpoints. Review this networking model carefully before public release; do not send credentials or private prompts to an untrusted HTTP endpoint.
- Chat archive backup exports text messages only; binary attachments/images and API keys are not included.
