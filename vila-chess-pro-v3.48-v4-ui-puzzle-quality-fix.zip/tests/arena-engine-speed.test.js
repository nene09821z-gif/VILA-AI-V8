import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');

test('Arena defaults to current Stockfish plus a fast beginner-training opponent, not legacy SF10', () => {
  const main = read('src/main.js');
  assert.match(main, /arenaSelectedLeague = new Set\(\['stockfish', 'offline-rookie'\]\)/);
  assert.match(main, /const defaultBlack = players\.some\(p => p\.id === 'offline-rookie'\) \? 'offline-rookie'/);
  assert.match(main, /startArenaMatch\(\$\('#arenaWhite'\)\?\.value \|\| 'stockfish', \$\('#arenaBlack'\)\?\.value \|\| 'offline-rookie'\)/);
  assert.match(main, /id: 'stockfish-10'.*cổ điển \(0,1–0,25 giây\/nước\)/);
});

test('Arena search budgets are reduced while strongest post-game analysis settings remain separate', () => {
  const main = read('src/main.js');
  assert.match(main, /Math\.max\(90, Math\.min\(220, Math\.round\(Math\.max\(8, Number\(depth\) \|\| 18\) \* 8\)\)\)/);
  assert.match(main, /Math\.max\(700, Math\.min\(1500, Math\.round\(Math\.max\(8, Number\(depth\) \|\| 18\) \* 45\)\)\)/);
  assert.match(main, /const isLegacySf10 = engineHealthState\?\.profile === 'sf10'/);
  assert.match(main, /Math\.max\(100, Math\.min\(220, Math\.round\(configuredMoveTimeMs \* 0\.08\)\)\)/);
  assert.match(main, /resolveReviewMoveTimeMs\(settings\)/);
  assert.match(main, /value="150" selected>0,15 giây/);
  assert.match(main, /delayMs: Number\(\$\('#arenaDelay'\)\?\.value \?\? 150\)/);
});

test('Android bundled JS receives the same arena defaults and fast move budgets', () => {
  const bundle = read('app/src/main/assets/assets/index-CYdsNhSO.js');
  assert.match(bundle, /new Set\(\["stockfish","offline-rookie"\]\)/);
  assert.match(bundle, /en\.add\("stockfish"\),en\.add\("offline-rookie"\)/);
  assert.match(bundle, /Math\.max\(180,Math\.min\(600,Math\.round\(Math\.max\(8,Number\(t\)\|\|18\)\*20\)\)\)/);
  assert.match(bundle, /Math\.max\(700,Math\.min\(1500,Math\.round\(Math\.max\(8,Number\(n\)\|\|18\)\*45\)\)\)/);
  assert.match(bundle, /S\.botEngine==="sf10"\?Math\.max\(200,Math\.min\(500,Math\.round\(r\*\.2\)\)\):r/);
  assert.match(bundle, /Math\.max\(180,Math\.min\(600,Math\.round\(Math\.max\(8,Number\(t\)\|\|18\)\*20\)\)\)/);
  assert.match(bundle, /const a=S\.botEngine==="sf10"\?Math\.max\(3500,Math\.min\(7000,i\*6\)\)/);
  assert.match(bundle, /Stockfish 10 · cổ điển \(tối đa 0,5 giây\/nước\)/);
});


test('legacy engine init timeout is bounded and AI Studio Android asset is restored at build time', () => {
  const main = read('src/main.js');
  const gradle = read('app/build.gradle.kts');
  assert.match(main, /initTimeoutMs: 8_000, defaultSearchTimeoutMs: 4_500/);
  assert.match(gradle, /public\/assets\/aistudio/);
  assert.match(gradle, /src\/main\/assets/);
  assert.match(gradle, /stagePublicAssetsForAndroid/);
  assert.match(gradle, /dependsOn\(stagePublicAssetsForAndroid\)/);
  assert.match(gradle, /engine\/stockfish-10\.js/);
});
