import { readFileSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { clampTargetElo, resolveStockfishStrength } from '../src/elo-strength.js';

test('Elo target is clamped to the requested 500–3200 range', () => {
  assert.equal(clampTargetElo(0), 500);
  assert.equal(clampTargetElo(100), 500);
  assert.equal(clampTargetElo(500), 500);
  assert.equal(clampTargetElo(3200), 3200);
  assert.equal(clampTargetElo(4000), 3200);
});

test('low Elo targets use progressive native Stockfish skill levels, never random move probabilities', () => {
  const beginner = resolveStockfishStrength(500);
  const intermediate = resolveStockfishStrength(900);
  const advanced = resolveStockfishStrength(1310);
  assert.equal(beginner.limitStrength, false);
  assert.equal(beginner.uciElo, null);
  assert.equal(beginner.skillLevel, 0);
  assert.equal(beginner.mode, 'skill-level-floor');
  assert.ok(beginner.skillLevel < intermediate.skillLevel);
  assert.ok(intermediate.skillLevel < advanced.skillLevel);
  assert.equal(advanced.skillLevel, 7);
  assert.equal('heuristicMoveProbability' in beginner, false);
  assert.equal('randomLegalMoveProbability' in beginner, false);
  assert.equal(resolveStockfishStrength(1320).mode, 'uci-elo');
});

test('high Elo maps to Stockfish UCI_Elo supported range while retaining requested target', () => {
  assert.deepEqual(resolveStockfishStrength(2600), { targetElo: 2600, limitStrength: true, uciElo: 2600, skillLevel: 20, mode: 'uci-elo' });
  assert.equal(resolveStockfishStrength(3200).targetElo, 3200);
  assert.equal(resolveStockfishStrength(3200).uciElo, 3190);
});


test('Elo range and review symbols are wired into the actual UI and Stockfish call path', () => {
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  const schema = readFileSync(new URL('../src/settings-schema.js', import.meta.url), 'utf8');
  assert.match(main, /Elo 500–3200/);
  assert.match(main, /min=\"500\" max=\"3200\"/);
  assert.match(schema, /DEFAULTS\.botElo, 500, 3200/);
  assert.match(main, /resolveStockfishStrength\(settings\.botElo\)/);
  assert.doesNotMatch(main, /chooseBeginnerMoveFor|randomLegalMoveProbability|heuristicMoveProbability/);
  assert.match(main, /setoption name Skill Level value \${strength\.skillLevel}/);
  assert.match(main, /review-move-symbol symbol-\$\{esc\(tone\)\}/);
  assert.match(main, /review-symbol-legend/);
  assert.match(main, /aria-label=\"Chú giải ký hiệu đánh giá\"/);
});
