package com.vila.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    LocalProxy proxy;
    android.content.SharedPreferences prefs;
    static final int PORT = 18787;
    static final int REQ_NOTIFICATIONS = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vila", MODE_PRIVATE);
        proxy = new LocalProxy(this, PORT);
        proxy.start();
        web = new WebView(this);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setBackgroundColor(Color.rgb(3,7,18));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setOffscreenPreRaster(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try { startActivityForResult(intent, 2001); fileCallback = callback; return true; }
                catch (Exception e) { callback.onReceiveValue(null); return false; }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                req.setDescription("VILA AI đang tải file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
                dm.enqueue(req);
                Toast.makeText(this, "Đang tải file vào thư mục Downloads", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Không thể tải file", Toast.LENGTH_SHORT).show(); }
        });
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(web);
        web.loadUrl("http://127.0.0.1:" + PORT + "/");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != getPackageManager().PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFICATIONS);
        }
    }


    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2001 && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
    public class AndroidBridge {
        @android.webkit.JavascriptInterface public void setServerUrl(String url) {
            String u = url == null ? "" : url.trim();
            while (u.endsWith("/")) u = u.substring(0, u.length()-1);
            prefs.edit().putString("server_url", u).apply();
            proxy.setRemote(u);
        }
        @android.webkit.JavascriptInterface public String getServerUrl() { return proxy.remote == null ? "" : proxy.remote; }
    }

    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(proxy!=null) proxy.stopServer(); super.onDestroy(); }

    static class LocalProxy extends Thread {
        final MainActivity ctx; final int port; volatile boolean running=true; ServerSocket ss; volatile String remote;
        LocalProxy(MainActivity c,int p){ctx=c;port=p;remote=c.prefs.getString("server_url","").trim();}
        void setRemote(String u){remote=u;}
        public void run(){try{ss=new ServerSocket(); ss.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),port)); while(running){try{Socket s=ss.accept(); new Thread(()->handle(s)).start();}catch(Exception ignored){}}}catch(Exception ignored){}}
        void handle(Socket s){try{s.setSoTimeout(15000); BufferedInputStream in=new BufferedInputStream(s.getInputStream()); OutputStream out=s.getOutputStream(); String request=readLine(in); if(request==null){s.close();return;} String[] p=request.split(" "); String method=p[0], path=p[1]; Map<String,String> headers=new HashMap<>(); String line; while((line=readLine(in))!=null&&!line.isEmpty()){int i=line.indexOf(':');if(i>0)headers.put(line.substring(0,i).toLowerCase(),line.substring(i+1).trim());}
            int len=0; try{len=Integer.parseInt(headers.getOrDefault("content-length","0"));}catch(Exception ignored){} byte[] body=new byte[len]; int off=0; while(off<len){int n=in.read(body,off,len-off);if(n<0)break;off+=n;}
            if("OPTIONS".equalsIgnoreCase(method)){ write(out,204,"text/plain; charset=utf-8",new byte[0]); s.close(); return; }
            if(path.equals("/")||path.startsWith("/index.html")){byte[] html=asset("index.html"); write(out,200,"text/html; charset=utf-8",html);}
            else if(path.startsWith("/api/")){forward(out,method,path,body);}
            else {write(out,404,"text/plain; charset=utf-8","Not found".getBytes(StandardCharsets.UTF_8));}
            s.close();}catch(Exception ignored){try{s.close();}catch(Exception x){}}}
        String readLine(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();int c,prev=-1;while((c=in.read())!=-1){if(prev=='\r'&&c=='\n'){b.write('\r');break;}b.write(c);prev=c;if(b.size()>8192)break;}String x=b.toString("ISO-8859-1");return x.replace("\r","").replace("\n","");}
        byte[] asset(String n)throws IOException{InputStream i=ctx.getAssets().open(n);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}
        void forward(OutputStream out,String method,String path,byte[] body)throws Exception{
            // VILA can now talk to Gemini directly through this tiny Android-side proxy.
            // This removes the need for Termux/Node.js and avoids WebView CORS failures.
            if (path.equals("/api/health") && "GET".equalsIgnoreCase(method)) {
                write(out,200,"application/json; charset=utf-8",("{\"ok\":true,\"service\":\"VILA Android Gemini Proxy\"}").getBytes(StandardCharsets.UTF_8)); return;
            }
            if (path.equals("/api/chat/completions") && "POST".equalsIgnoreCase(method)) {
                geminiChat(out, body, null); return;
            }
            if (path.equals("/api/search") && "POST".equalsIgnoreCase(method)) {
                geminiChat(out, body, "search"); return;
            }
            if (path.equals("/api/models") && "GET".equalsIgnoreCase(method)) {
                // Models are discovered by the web layer using the same local proxy.
                String key = lastApiKey == null ? "" : lastApiKey;
                if (key.isEmpty()) { write(out,401,"application/json; charset=utf-8",("{\"message\":\"Chưa có Gemini API Key.\"}").getBytes(StandardCharsets.UTF_8)); return; }
                URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models?key="+URLEncoder.encode(key,"UTF-8")+"&pageSize=1000");
                HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(30000); c.setRequestMethod("GET");
                int code=c.getResponseCode(); byte[] data=readAll(code>=400?c.getErrorStream():c.getInputStream()); write(out,code,"application/json; charset=utf-8",data); c.disconnect(); return;
            }
            if(remote.isEmpty()){write(out,503,"application/json; charset=utf-8",("{\"message\":\"Chưa có Gemini proxy.\"}").getBytes(StandardCharsets.UTF_8));return;}
            URL u=new URL(remote+path);HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(60000);c.setRequestProperty("Content-Type","application/json");c.setDoInput(true);if("POST".equals(method)){c.setDoOutput(true);c.getOutputStream().write(body);}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();byte[] data=readAll(is);String ct=c.getHeaderField("Content-Type");write(out,code,ct==null?"application/json; charset=utf-8":ct,data);c.disconnect();
        }
        volatile String lastApiKey="";
        String headerKey(byte[] body){ return ""; }
        void geminiChat(OutputStream out, byte[] body, String mode)throws Exception{
            JSONObject req=new JSONObject(new String(body,StandardCharsets.UTF_8));
            String key=req.optString("apiKey","");
            if(key.isEmpty()) key=lastApiKey;
            if(key.isEmpty()){write(out,401,"application/json; charset=utf-8",("{\"error\":{\"message\":\"Chưa nhập Gemini API Key.\"}}").getBytes(StandardCharsets.UTF_8));return;}
            lastApiKey=key;
            String model=req.optString("model","gemini-3.8-flash");
            JSONArray msgs=req.optJSONArray("messages"); if(msgs==null) msgs=new JSONArray();
            JSONObject payload=new JSONObject(); JSONArray contents=new JSONArray();
            String system="";
            for(int i=0;i<msgs.length();i++){
                JSONObject m=msgs.optJSONObject(i); if(m==null) continue;
                String role=m.optString("role","user"); Object c=m.opt("content");
                if("system".equals(role)){ system=contentToText(c); continue; }
                JSONObject cm=new JSONObject(); cm.put("role","assistant".equals(role)?"model":"user");
                JSONArray parts=new JSONArray();
                if(c instanceof JSONArray){ JSONArray arr=(JSONArray)c; for(int j=0;j<arr.length();j++){ JSONObject part=arr.optJSONObject(j); if(part==null) continue; String type=part.optString("type",""); if("text".equals(type)) parts.put(new JSONObject().put("text",part.optString("text",""))); else if("image_url".equals(type)){ JSONObject iu=part.optJSONObject("image_url"); String u=iu==null?"":iu.optString("url",""); if(u.startsWith("data:")){ int comma=u.indexOf(','); if(comma>0){String meta=u.substring(5,comma); String b64=u.substring(comma+1); String mime=meta.split(";",2)[0]; parts.put(new JSONObject().put("inlineData",new JSONObject().put("mimeType",mime).put("data",b64))); } } } } }
                else parts.put(new JSONObject().put("text",String.valueOf(c==JSONObject.NULL?"":c)));
                cm.put("parts",parts); contents.put(cm);
            }
            payload.put("contents",contents);
            if(!system.isEmpty()) payload.put("systemInstruction",new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",system))));
            JSONObject gen=new JSONObject(); gen.put("temperature",req.optDouble("temperature",0.2)); gen.put("maxOutputTokens",Math.min(req.optInt("max_tokens",16384),65536)); payload.put("generationConfig",gen);
            if("search".equals(mode)) payload.put("tools",new JSONArray().put(new JSONObject().put("google_search",new JSONObject())));
            URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent?key="+URLEncoder.encode(key,"UTF-8"));
            HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(120000); c.setRequestProperty("Content-Type","application/json"); c.setDoOutput(true); byte[] outBody=payload.toString().getBytes(StandardCharsets.UTF_8); c.getOutputStream().write(outBody);
            int code=c.getResponseCode(); byte[] data=readAll(code>=400?c.getErrorStream():c.getInputStream());
            if(code>=200&&code<300){ JSONObject gd=new JSONObject(new String(data,StandardCharsets.UTF_8)); StringBuilder answer=new StringBuilder(); JSONArray cand=gd.optJSONArray("candidates"); if(cand!=null&&cand.length()>0){JSONObject co=cand.optJSONObject(0); JSONObject content=co==null?null:co.optJSONObject("content"); JSONArray parts=content==null?null:content.optJSONArray("parts"); if(parts!=null) for(int i=0;i<parts.length();i++) answer.append(parts.optJSONObject(i).optString("text",""));} JSONObject compat=new JSONObject(); JSONArray choices=new JSONArray(); JSONObject choice=new JSONObject(); choice.put("index",0); choice.put("message",new JSONObject().put("role","assistant").put("content",answer.toString())); choice.put("finish_reason","stop"); choices.put(choice); compat.put("choices",choices); compat.put("model",model); compat.put("ok",true); write(out,200,"application/json; charset=utf-8",compat.toString().getBytes(StandardCharsets.UTF_8)); }
            else { write(out,code,"application/json; charset=utf-8",data); }
            c.disconnect();
        }
        String contentToText(Object c){ if(c==null||c==JSONObject.NULL)return ""; if(c instanceof JSONArray){StringBuilder b=new StringBuilder();JSONArray a=(JSONArray)c;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)b.append(o.optString("text",""));}return b.toString();} return String.valueOf(c); }
        byte[] readAll(InputStream i)throws IOException{if(i==null)return new byte[0];ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}
        void write(OutputStream o,int code,String ct,byte[] data)throws IOException{String h="HTTP/1.1 "+code+" "+(code==200?"OK":code==503?"Service Unavailable":"Error")+"\r\nContent-Type: "+ct+"\r\nContent-Length: "+data.length+"\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";o.write(h.getBytes(StandardCharsets.ISO_8859_1));o.write(data);o.flush();}
        void stopServer(){running=false;try{if(ss!=null)ss.close();}catch(Exception ignored){}}
    }
}
