# VILA AI VIP V16

## GitHub Actions
1. Upload the contents of this folder to the repository root.
2. Open Actions -> VILA AI VIP - Build APK -> Run workflow.
3. Download the `VILA-AI-VIP-debug` artifact.

## Gemini
Enter your own Gemini API key in VILA Settings. The Android app uses a local loopback proxy, so the WebView does not need CORS access to the Gemini endpoint.

## Google login
`app/src/main/assets/firebase-config.js` must contain your Firebase Web App config. Enable Google provider in Firebase Authentication and add the required authorized domain(s). The Firebase config is client configuration, not a private service-account key.
