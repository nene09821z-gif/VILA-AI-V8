# VILA AI Studio V16 — Android, Gemini, no Termux

Bản nâng cấp từ V15. APK chạy giao diện WebView và có **Android-side Gemini proxy** tích hợp sẵn, vì vậy người dùng không cần chạy Termux/Node.js để chat.

## Có gì mới
- Sửa `Failed to fetch` do WebView/CORS khi gọi Gemini trực tiếp.
- VILA gọi `/api/chat/completions` nội bộ; Android proxy chuyển đổi OpenAI-compatible messages sang Gemini `generateContent`.
- Tự xử lý fallback model hợp lệ và retry giới hạn.
- File `.txt .md .json .csv .html .css .js .ts .py .java .kt .c .cpp .xml .svg .yaml .yml .log .pdf .docx`.
- Ảnh được gửi dạng multimodal inline data để Gemini phân tích.
- Google/Firebase login: popup + redirect fallback và xử lý redirect result.
- Memory IndexedDB/localStorage vẫn được giữ.

## API key
Vào Cài đặt và nhập Gemini API key của chính bạn. Key được lưu ở bộ nhớ ứng dụng và gửi tới proxy nội bộ; **không có API key cố định trong source**.

Gemini API key vẫn cần thiết. Firebase Google Login chỉ là đăng nhập tài khoản VILA, không thay thế Gemini API authorization.

## Google Login
Điền Firebase Web App config vào:
`app/src/main/assets/firebase-config.js`

Sau đó bật Google provider trong Firebase Authentication và cấu hình Authorized Domains.

## Build APK
Mở thư mục này bằng Android Studio → Sync Gradle → Build APK(s).

GitHub Actions có sẵn tại `.github/workflows/build-apk.yml`.

## Server Node cũ
Thư mục `server/` được giữ lại để tương thích với các bản triển khai cũ, nhưng **không cần dùng cho bản V16 Android**.
