# Build Cờ Vua ViLa bằng GitHub Actions

ZIP này là mã nguồn web HTML/CSS/JavaScript cùng cấu hình build Android, không phải APK. Quy trình release được thiết kế để dừng nếu test hoặc tải dữ liệu/asset bắt buộc không đạt chuẩn.

## Cách build

1. Giải nén `CO_VUA_VILA_V3_31_0.zip` và tải toàn bộ nội dung bên trong (bao gồm `.github/workflows`) lên một GitHub repository.
2. Mở tab **Actions**, chọn workflow **Cờ Vua ViLa Android build**, rồi bấm **Run workflow**.
3. Workflow sử dụng Node.js 22 và Java 21, cài dependencies, kiểm tra cú pháp, chạy `npm test`, tạo bộ khai cuộc ECO (ít nhất 3.000 biến) và tải 5 bộ quân SVG nguồn mở có giấy phép, rồi build web/Capacitor/Android.
4. Chỉ khi toàn bộ bước đều thành công, tải artifact `covua-vila-debug-apk` để lấy `app-debug.apk`. Artifact `covua-vila-android-gradle-source` là mã nguồn Gradle Android sinh ra, không thay cho ZIP HTML ban đầu.

## Nếu workflow thất bại

- Mở step lỗi đầu tiên; không tắt test để ép build ra APK.
- Lỗi bài test: tải artifact `test-report` và xem stack trace.
- Lỗi kho khai cuộc/bộ quân: kiểm tra GitHub runner truy cập được GitHub raw assets và các nguồn được ghi trong `public/piece-sets/CREDITS.md`. Workflow chủ động dừng nếu dữ liệu không hoàn chỉnh.
- Lỗi Stockfish: xác minh tệp engine trong `public/engine/` và log của `scripts/copy-engine.mjs`.

## Lệnh cục bộ

```bash
npm install
npm test
npm run build
npm run android:init
```

Build cục bộ cũng cần mạng ở bước tải kho ECO/SVG nếu dữ liệu chưa có sẵn, cùng dependencies Node/Java/Android phù hợp.

## Giới hạn xác minh

Trong môi trường tạo ZIP này, `npm` dependencies không có sẵn và truy cập tải gói từ command line bị hạn chế. Vì vậy mình chỉ có thể báo cáo các test tĩnh chạy thực tế; APK và hiệu năng trên OPPO A17k phải được xác minh riêng qua GitHub Actions và thiết bị thật.
