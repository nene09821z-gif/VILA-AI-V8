const clamp = (value, min, max) => Math.max(min, Math.min(max, Math.round(Number(value) || 0)));

/** Resolve a bounded, phone-friendly budget for VILA's in-app alpha-beta engine.
 * Stockfish is still the primary engine; this profile is used for VILA mode and rescue.
 */
export function resolveOfflineSearchBudget(profile = 'ethereal', settings = {}) {
  const rawMs = clamp(settings.botMoveTimeMs ?? 1600, 500, 5000) || 1600;
  const rawDepth = clamp(settings.botDepth ?? 22, 5, 30) || 22;
  const lightweight = profile === 'blitz' || profile === 'rookie';
  const maxTimeMs = lightweight
    ? clamp(rawMs * 0.6, 500, 1500)
    : clamp(rawMs, 900, 3200);
  const depth = lightweight
    ? clamp(Math.floor(rawDepth / 4), 3, 6)
    : clamp(Math.floor(rawDepth / 3), 4, 9);
  const maxNodes = lightweight
    ? clamp(maxTimeMs * 85, 45000, 135000)
    : clamp(maxTimeMs * 145, 100000, 350000);
  return { profile, depth, maxTimeMs, maxNodes };
}

/** Full-game review needs a little more than a quick static glance but must remain bounded. */
export function resolveReviewMoveTimeMs(settings = {}) {
  const configured = clamp(settings.analysisMoveTimeMs ?? 2600, 1000, 8000) || 2600;
  return clamp(configured * 0.35, 500, 1800);
}
