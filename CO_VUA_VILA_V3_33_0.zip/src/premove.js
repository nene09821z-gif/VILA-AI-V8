/** Chess.com-style premove helpers. All queued moves are revalidated on the real position. */
export function getPremoveLegalMoves(chess, color, ChessConstructor, square = null) {
  if (!chess || !['w', 'b'].includes(color) || typeof ChessConstructor !== 'function') return [];
  try {
    const fields = String(chess.fen()).split(' ');
    if (fields.length < 6) return [];
    // A premove is planned for the player's next turn, after the opponent replies.
    // En-passant rights belong to the current side and expire after its move.
    fields[1] = color;
    fields[3] = '-';
    const preview = new ChessConstructor(fields.join(' '));
    if (square) return preview.moves({ square, verbose: true });
    return preview.moves({ verbose: true });
  } catch {
    return [];
  }
}

/** Resolve a stored premove against the actual post-opponent position. */
export function resolveQueuedPremove(chess, intent, color) {
  if (!chess || !intent || chess.turn?.() !== color || !/^[a-h][1-8]$/.test(String(intent.from || '')) || !/^[a-h][1-8]$/.test(String(intent.to || ''))) return null;
  try {
    const candidates = chess.moves({ verbose: true }).filter(move => move.from === intent.from && move.to === intent.to);
    if (!candidates.length) return null;
    const isPromotion = candidates.some(move => Boolean(move.promotion));
    const promotion = isPromotion ? (['q', 'r', 'b', 'n'].includes(intent.promotion) ? intent.promotion : 'q') : null;
    const move = candidates.find(candidate => (candidate.promotion || null) === promotion);
    return move ? { from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) } : null;
  } catch {
    return null;
  }
}
