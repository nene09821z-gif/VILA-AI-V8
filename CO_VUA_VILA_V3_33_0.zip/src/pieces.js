// VILA "Royal" piece set — original vector artwork drawn for this project.
// Smooth Staunton-style silhouettes, soft gradient body, dark contour and a light rim.
// No third-party artwork is copied. Every board (play, bot, ranked, arena, puzzle, review,
// promotion dialog, drag ghost) renders through pieceSvgMarkup(), so a change here updates all.

const FOOT = '<path d="M11 58h42a1.5 1.5 0 0 0 1.5-1.5v-1.6A2.4 2.4 0 0 0 52 52.500H12a2.4 2.4 0 0 0-2.500 2.400v1.600A1.500 1.500 0 0 0 11 58z"/>';
const COLLAR = '<rect x="15.500" y="46" width="33" height="6.500" rx="3"/>';

export const PIECE_SHAPES = Object.freeze({
  p: {
    body: `${FOOT}${COLLAR}<path d="M25.500 28c0 8-4.500 13.500-8 18h29c-3.500-4.500-8-10-8-18z"/><rect x="21.500" y="25" width="21" height="5" rx="2.500"/><circle cx="32" cy="16.500" r="8.500"/>`,
    detail: '<path d="M27.500 12.500a6 6 0 0 1 4-2.600M26 33c-.8 4-3 8-5.500 11"/>'
  },
  r: {
    body: `${FOOT}${COLLAR}<path d="M23 27h18l2.500 19h-23z"/><rect x="18" y="21.500" width="28" height="6" rx="2"/><path d="M18.500 9.500h7v5h4v-5h5v5h4v-5h7v12h-27z"/>`,
    detail: '<path d="M22.500 31.500l-1.200 11M21.500 13v6.500M26 25h.01"/>'
  },
  b: {
    body: `${FOOT}${COLLAR}<path d="M26.500 34c0 6-4 10.500-7 12h25c-3-1.500-7-6-7-12z"/><rect x="23" y="30" width="18" height="5.500" rx="2.700"/><path d="M32 8.500c8 5.500 11.500 12 9 18.500-.8 2.100-2 3.200-3.200 3.800h-11.600c-1.200-.6-2.400-1.700-3.200-3.800-2.500-6.500 1-13 9-18.500z"/><circle cx="32" cy="6.500" r="3.200"/>`,
    detail: '<path d="M29 14.800 36.500 22.500M26 22c.5-3 2-5.500 4-7.500"/>'
  },
  n: {
    body: `${FOOT}${COLLAR}<path d="M17.500 46c-.8-8 1.500-14.500 8-20.500l-5-1.200-6 6.800c-1.200 1.400-3.700 1-4.400-.7-.7-1.700 0-3.400.8-4.800l5.200-8.500c1.700-2.800 3.500-4.700 5.800-6l-.4-5.400 5.200 3.400c2-.6 4-.5 6-.1 9.800 2.100 17.500 11 17.500 27.500l-.2 12.800z"/>`,
    detail: '<path d="M25.300 14.200l2.400 3.100M14 25.500l3.200-1.200M31 16c5.500 1.300 9.500 5 11.500 10"/><circle cx="26.500" cy="19.500" r="1.900" class="piece-eye"/><path d="M13.700 25.300c.9.700 1.900.9 3 .6" />'
  },
  q: {
    body: `${FOOT}${COLLAR}<path d="M26 40c.4 3 .2 4.500-.6 6h13.200c-.8-1.500-1-3-.6-6z"/><path d="M12.500 20.500 21 38.500h22l8.500-18-10.500 8-2.200-14.500-6.800 12.500-6.800-12.500L23 28.500z"/><rect x="19" y="37" width="26" height="5.500" rx="2.700"/><circle cx="12" cy="18.500" r="3.200"/><circle cx="22.500" cy="11.500" r="3.200"/><circle cx="32" cy="9" r="3.200"/><circle cx="41.500" cy="11.500" r="3.200"/><circle cx="52" cy="18.500" r="3.200"/>`,
    detail: '<path d="M22.500 33l-1.500-4.500M32 32.500l0-9M41.500 33l1.500-4.500M23 40h18"/>'
  },
  k: {
    body: `${FOOT}${COLLAR}<path d="M20 22.500c-3 5.500 0 10 3 14H41c3-4 6-8.500 3-14-2.200-4-6.500-5-12-5s-9.800 1-12 5z"/><rect x="19" y="36" width="26" height="6" rx="3"/><path d="M26.500 42c.4 2.500.2 3.500-.6 4h12.200c-.8-.5-1-1.500-.6-4z"/><path d="M29.500 3.500h5v5h5v5h-5v5h-5v-5h-5v-5h5z"/>`,
    detail: '<path d="M32 20.500v6.500M23.500 26c.8 3 2 5 3.500 7M23.500 40h17"/>'
  }
});

/**
 * Shared gradients. Inserted once (index.html carries the same block) so every inline piece
 * can reference url(#vp-grad-w / #vp-grad-b) without repeating <defs> in 64+ SVGs per board.
 */
export const PIECE_SPRITE = '<svg id="vilaPieceSprite" width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false"><defs>' +
  '<linearGradient id="vp-grad-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#fffef8"/><stop offset=".45" stop-color="#f3ead2"/><stop offset="1" stop-color="#cdbc93"/></linearGradient>' +
  '<linearGradient id="vp-grad-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#6a7a90"/><stop offset=".45" stop-color="#33404f"/><stop offset="1" stop-color="#151c26"/></linearGradient>' +
  '<linearGradient id="vp-grad-neon-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#f8fbff"/><stop offset=".48" stop-color="#9de8ff"/><stop offset="1" stop-color="#7776ff"/></linearGradient>' +
  '<linearGradient id="vp-grad-neon-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#c8ffff"/><stop offset=".45" stop-color="#4776ba"/><stop offset="1" stop-color="#25214f"/></linearGradient>' +
  '<linearGradient id="vp-grad-wood-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#fff0c8"/><stop offset=".48" stop-color="#d9ad6e"/><stop offset="1" stop-color="#80502e"/></linearGradient>' +
  '<linearGradient id="vp-grad-wood-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#edc49a"/><stop offset=".48" stop-color="#8a4c2c"/><stop offset="1" stop-color="#351d18"/></linearGradient>' +
  '<linearGradient id="vp-grad-pearl-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#fffefc"/><stop offset=".48" stop-color="#dce4ef"/><stop offset="1" stop-color="#8e9baa"/></linearGradient>' +
  '<linearGradient id="vp-grad-pearl-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#d0d6e1"/><stop offset=".48" stop-color="#6c7789"/><stop offset="1" stop-color="#293344"/></linearGradient>' +
  '<linearGradient id="vp-grad-jade-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#f5ffef"/><stop offset=".48" stop-color="#b4dca7"/><stop offset="1" stop-color="#55825b"/></linearGradient>' +
  '<linearGradient id="vp-grad-jade-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#bbd9b5"/><stop offset=".48" stop-color="#47734e"/><stop offset="1" stop-color="#182f26"/></linearGradient>' +
  '<linearGradient id="vp-grad-ruby-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#fff1ea"/><stop offset=".48" stop-color="#e8b8ab"/><stop offset="1" stop-color="#aa655f"/></linearGradient>' +
  '<linearGradient id="vp-grad-ruby-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#c45c71"/><stop offset=".48" stop-color="#692435"/><stop offset="1" stop-color="#1a101b"/></linearGradient>' +
  '<linearGradient id="vp-grad-graphite-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#ffffff"/><stop offset=".48" stop-color="#a4b0bd"/><stop offset="1" stop-color="#5f6b78"/></linearGradient>' +
  '<linearGradient id="vp-grad-graphite-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#818b98"/><stop offset=".48" stop-color="#3d4652"/><stop offset="1" stop-color="#151a21"/></linearGradient>' +
  '<linearGradient id="vp-grad-emerald-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#f3fff8"/><stop offset=".48" stop-color="#93d7b0"/><stop offset="1" stop-color="#2f7951"/></linearGradient>' +
  '<linearGradient id="vp-grad-emerald-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#b3edc8"/><stop offset=".48" stop-color="#23734a"/><stop offset="1" stop-color="#0b2d20"/></linearGradient>' +
  '<linearGradient id="vp-grad-gold-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#fff5cf"/><stop offset=".48" stop-color="#e6bd61"/><stop offset="1" stop-color="#956124"/></linearGradient>' +
  '<linearGradient id="vp-grad-gold-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#ffe0a0"/><stop offset=".48" stop-color="#966222"/><stop offset="1" stop-color="#422714"/></linearGradient>' +
  '<linearGradient id="vp-grad-ice-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#ffffff"/><stop offset=".48" stop-color="#b9e9f5"/><stop offset="1" stop-color="#638eac"/></linearGradient>' +
  '<linearGradient id="vp-grad-ice-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#d9f8ff"/><stop offset=".48" stop-color="#477e9e"/><stop offset="1" stop-color="#1d3348"/></linearGradient>' +
  '<linearGradient id="vp-grad-rose-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#fff0f1"/><stop offset=".48" stop-color="#edaeb8"/><stop offset="1" stop-color="#9d5366"/></linearGradient>' +
  '<linearGradient id="vp-grad-rose-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#d995a6"/><stop offset=".48" stop-color="#843347"/><stop offset="1" stop-color="#321623"/></linearGradient>' +
  '<linearGradient id="vp-grad-obsidian-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#f0f1f2"/><stop offset=".48" stop-color="#939ca6"/><stop offset="1" stop-color="#333c47"/></linearGradient>' +
  '<linearGradient id="vp-grad-obsidian-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#8996a4"/><stop offset=".48" stop-color="#414b57"/><stop offset="1" stop-color="#101820"/></linearGradient>' +
  '<linearGradient id="vp-grad-copper-w" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#ffefd8"/><stop offset=".48" stop-color="#ce8a50"/><stop offset="1" stop-color="#743f25"/></linearGradient>' +
  '<linearGradient id="vp-grad-copper-b" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#e9b58a"/><stop offset=".48" stop-color="#884c31"/><stop offset="1" stop-color="#311b17"/></linearGradient>' +
  '</defs></svg>';

const PIECE_STYLE_IDS = Object.freeze(['flat', 'royal', 'neon', 'wood', 'pearl', 'jade', 'ruby', 'graphite', 'emerald', 'gold', 'ice', 'rose', 'obsidian', 'copper', 'fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx']);
const LICENSED_REMOTE_PIECE_SETS = Object.freeze(['fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx']);
let pieceStyle = 'flat';
try { const saved = typeof localStorage !== 'undefined' ? localStorage.getItem('vila.chess.piece-style.v1') : ''; if (PIECE_STYLE_IDS.includes(saved)) pieceStyle = saved; } catch {}
export const PIECE_STYLES = Object.freeze([
  { id: 'flat', label: '2D cổ điển · gọn nhẹ' },
  { id: 'royal', label: 'Royal · ngà và xanh than' },
  { id: 'neon', label: 'Neon · xanh tím phát sáng' },
  { id: 'wood', label: 'Gỗ · nâu cổ điển' },
  { id: 'pearl', label: 'Ngọc trai · bạc xanh' },
  { id: 'jade', label: 'Ngọc lục bảo · xanh dịu' },
  { id: 'ruby', label: 'Ruby · đỏ rượu vang' },
  { id: 'graphite', label: 'Graphite · kim loại xám' },
  { id: 'emerald', label: 'Emerald · ngọc lục bảo' },
  { id: 'gold', label: 'Royal Gold · vàng hoàng gia' },
  { id: 'ice', label: 'Ice Crystal · pha lê băng' },
  { id: 'rose', label: 'Rose · hồng ngọc' },
  { id: 'obsidian', label: 'Obsidian · đá núi lửa' },
  { id: 'copper', label: 'Copper · đồng cổ' },
  { id: 'fantasy', label: 'Fantasy · Maurizio Monge · MIT' },
  { id: 'spatial', label: 'Spatial · Maurizio Monge · MIT' },
  { id: 'celtic', label: 'Celtic · Maurizio Monge · MIT' },
  { id: 'chessnut', label: 'Chessnut · Alexis Luengas · Apache 2.0' },
  { id: 'rhosgfx', label: 'RhosGFX · CC0 · tối giản' }
]);
export function getPieceStyle() { return pieceStyle; }
export function setPieceStyle(style) {
  pieceStyle = PIECE_STYLE_IDS.includes(style) ? style : 'flat';
  try { localStorage.setItem('vila.chess.piece-style.v1', pieceStyle); } catch {}
  return pieceStyle;
}

export function pieceSvgMarkup(piece, style = pieceStyle) {
  const shape = PIECE_SHAPES[piece?.type];
  const color = piece?.color;
  if (!shape || (color !== 'w' && color !== 'b')) return '';
  if (LICENSED_REMOTE_PIECE_SETS.includes(style)) {
    const side = color === 'w' ? 'w' : 'b';
    const type = piece.type.toUpperCase();
    // GitHub build fetches these permissively-licensed source SVGs and bundles them locally.
    // Missing/blocked assets fall back to the original bundled PNG artwork; they never break a move.
    return `<img class="piece-svg piece-svg-${piece.type} piece-set-${style}" src="./piece-sets/${style}/${side}${type}.svg" alt="" draggable="false" decoding="async" onerror="this.onerror=null;this.src='./pieces/${side}_${piece.type}.png';this.className='piece-svg piece-set-flat'"/>`;
  }
  if (style === 'flat') {
    // Supplied hand-rendered 2D piece artwork: transparent PNGs preserve the glossy,
    // outlined Chess.com-like silhouette at every board size without a sprite-sheet crop at runtime.
    const side = color === 'w' ? 'w' : 'b';
    const type = piece.type;
    return `<img class="piece-svg piece-svg-${type} piece-set-flat" src="./pieces/${side}_${type}.png" alt="" draggable="false" decoding="async" aria-hidden="true"/>`;
  }
  const alternateStyle = PIECE_STYLE_IDS.filter(id => id !== 'flat' && id !== 'royal').includes(style) ? style : 'royal';
  const palettes = {
    royal: ['var(--piece-outline,#1d1710)', 'var(--piece-detail,#1d1710)'],
    neon: ['#17204d', '#2b367a'], wood: ['#39231c', '#5e3522'],
    pearl: ['#435062', '#6b7787'], jade: ['#173b2c', '#355c40'],
    ruby: ['#471629', '#692435'], graphite: ['#161b21', '#3b4652'],
    emerald: ['#103c2c', '#266c4b'], gold: ['#5a3a12', '#8b6323'],
    ice: ['#28475e', '#507f99'], rose: ['#5f2638', '#8a4558'],
    obsidian: ['#222b36', '#505b69'], copper: ['#482719', '#7a4727']
  };
  const [outline, detail] = palettes[alternateStyle] || palettes.royal;
  const gradient = alternateStyle === 'royal' ? `vp-grad-${color}` : `vp-grad-${alternateStyle}-${color}`;
  return `<svg class="piece-svg piece-svg-${piece.type} piece-set-${alternateStyle}" viewBox="0 0 64 64" aria-hidden="true" focusable="false">` +
    `<g class="piece-silhouette" fill="url(#${gradient})" stroke="${outline}" stroke-width="2.400" stroke-linejoin="round" stroke-linecap="round">${shape.body}</g>` +
    `<g class="piece-detail" fill="none" stroke="${detail}" stroke-width="1.700" stroke-linejoin="round" stroke-linecap="round">${shape.detail}</g></svg>`;
}

export function ensurePieceSprite(doc = typeof document !== 'undefined' ? document : null) {
  if (!doc || doc.getElementById('vilaPieceSprite')) return false;
  const host = doc.createElement('div');
  host.innerHTML = PIECE_SPRITE;
  doc.body.prepend(host.firstElementChild);
  return true;
}
