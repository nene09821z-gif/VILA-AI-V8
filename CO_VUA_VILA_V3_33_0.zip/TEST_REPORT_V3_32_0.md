# Báo cáo kiểm thử Cờ Vua ViLa v3.32.0

## Đã chạy

- `npm run test:static`: **169/169 đạt**, 0 thất bại.
- Kiểm tra cú pháp bằng `node --check` cho tất cả tệp `*.js` và `*.mjs` trong `src/`, `server/`, `scripts/`, `tests/`: **đạt**.
- `npm test`: 175 bài được phát hiện, **171 đạt / 4 không chạy được**.

## Test tích hợp chưa chạy được

Bốn test không khởi chạy vì dependency không có trong môi trường kiểm thử:

- `tests/alternate-engine.test.js`: thiếu `chess.js`.
- `tests/chess.test.js`: thiếu `chess.js`.
- `tests/social.test.js`: thiếu `express`.
- `tests/v3-25-features.test.js`: thiếu `chess.js`.

Đã thử cài package, nhưng quá trình `npm install` không hoàn thành trong giới hạn môi trường; `npm install --offline` không thể tạo lockfile vì cache không có package metadata. Do đó không tạo `package-lock.json` giả và không tuyên bố đã chạy đủ test tích hợp.

## Chưa xác minh

- Chưa chạy `npm run build` vì không có dependency đã cài đầy đủ và chưa xác minh được bundle Stockfish từ npm.
- Chưa build APK bằng Gradle/GitHub Actions.
- Chưa chạy engine UCI trên Android thật; chưa đo Elo qua giải đấu benchmark.
- Chưa kiểm tra thao tác cảm ứng, hiệu năng, nhiệt độ và bộ nhớ trên OPPO A17k.

## Ghi chú

Bản 3.32.0 giữ nguyên các chức năng của 3.31.0. Các thay đổi của bản này tập trung vào sửa lỗi kiểm thử tĩnh, đồng bộ metadata phiên bản và cải thiện tính minh bạch của nghiệm thu. Các tính năng bot/câu đố/phân tích đã có trong nền 3.31.0; không nên coi việc có profile bot là bằng chứng chúng tương đương engine độc lập hay đã đạt Elo công bố.
