# Nhật ký thay đổi Cờ Vua ViLa

## v3.33.0 — giao diện phòng đấu và độ trễ thao tác
- Làm mới phòng đấu theo tông xanh đêm, thẻ người chơi/đồng hồ, thanh chức năng riêng và thanh thao tác năm nút trên điện thoại.
- Giảm chi phí chọn quân: chỉ cập nhật các ô cờ đổi trạng thái; chỉ tính nước hợp lệ khi cử chỉ đã thành thao tác kéo.
- Dùng hình học bàn cờ đã cache để xác định ô thả, tránh hit-test DOM qua `elementFromPoint()` trong lúc kéo.
- Giữ các view/chức năng cũ; thêm nút hủy lựa chọn nước đi.
- Pin phiên bản cụ thể cho các dependency trực tiếp; báo cáo kiểm thử và giới hạn môi trường nằm trong `TEST_REPORT_V3_33_0.md`.

## v3.32.0 — kiểm thử và độ tin cậy
- Sửa lỗi cú pháp trong `tests/visual-settings.test.js` khiến bộ kiểm thử tĩnh không thể khởi chạy đầy đủ.
- Chuẩn hóa kỳ vọng của test: `normalizeVisualSettings` chỉ giữ các tùy chọn giao diện mà module thực sự hỗ trợ; không giả định module này quản lý kiểu quân cờ.
- Đồng bộ phiên bản package, tiêu đề, API health, service-worker cache và nhận diện tác vụ tải tài nguyên sang 3.32.0.
- Thêm cổng kiểm tra cú pháp JavaScript toàn bộ `src`, `server`, `scripts`, `tests` vào quy trình nghiệm thu thủ công.
- Xác minh lại 169 test tĩnh và ghi rõ bốn test tích hợp bị chặn bởi dependency chưa cài trong môi trường.

## v3.31.0 — phòng đấu hợp nhất, thương hiệu mới và luyện tập mở rộng

- Tái thương hiệu toàn bộ giao diện web/Android thành **Cờ Vua ViLa**, icon mới và bảng màu xanh ngọc–vàng.
- Phòng đấu gom thao tác nhanh, thiết lập đối thủ, khai cuộc, danh sách nước và phân tích vào một màn hình.
- Sửa hoàn tác để khôi phục đúng clock snapshot trước nước đi; thêm Làm lại và lịch sử đồng hồ theo từng nửa nước đi.
- Có 18 profile bot offline cấu hình được chọn (bao gồm 6 profile mới: Mentor, Hunter, Sentinel, Strategist, Endgame Pro, Chaos), ngoài engine Stockfish; phân biệt rõ profile cấu hình với engine neural được train độc lập.
- Mở rộng lên 19 kiểu quân cờ: 14 kiểu nội bộ (1 PNG + 13 phối màu vector) và 5 bộ SVG nguồn mở được tải, kiểm tra giấy phép, đóng gói offline trong release GitHub.
- Thêm Luyện tự do, Đề hôm nay xác định theo ngày, Puzzle Rush 3 phút và Sinh tồn 3 mạng; chống kết quả Worker cũ ghi đè lượt hết giờ.
- Test: 166/167 bài kiểm thử tĩnh đạt; full suite 168/173 đạt (5 lỗi khởi tạo trong môi trường hiện tại).

## Lịch sử trước đó

Các thay đổi lịch sử từ các bản v3.x trước được gom vào các tệp nguồn, commit và kiểm thử hiện tại. Báo cáo audit/changelog lặp theo từng phiên bản cũ đã được loại khỏi ZIP để giảm nhiễu.
