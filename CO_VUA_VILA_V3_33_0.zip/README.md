# Cờ Vua ViLa v3.33.0 — phòng đấu cờ vua ngoại tuyến

Cờ Vua ViLa là ứng dụng cờ vua ưu tiên Android/WebView, đóng gói từ HTML/CSS/JavaScript và có thể build APK bằng GitHub Actions. ZIP này là mã nguồn, không phải APK đã biên dịch.

## Tính năng hiện có (kế thừa từ v3.31.0)

Bản v3.33.0 làm mới phòng đấu, tách điều hướng chức năng, giảm cập nhật DOM khi chọn quân và tối ưu xử lý kéo quân trên WebView Android. Các công cụ bot, câu đố, phân tích, khai cuộc và lưu lịch sử cũ tiếp tục được giữ lại.

- **Thương hiệu mới:** biểu tượng mã, tên Cờ Vua ViLa trên giao diện web và cấu hình nhãn Android; bảng màu xanh ngọc–vàng.
- **Phòng đấu gọn:** thao tác thiết lập, khai cuộc, nước đi, gợi ý, phân tích và xuất PGN có thể truy cập ngay trong màn hình trận đấu.
- **Hoàn tác/làm lại:** lưu snapshot đồng hồ trước mỗi nửa nước đi, khôi phục thời gian thay vì reset; thêm Redo và xác minh nhánh trước khi áp dụng.
- **19 phong cách quân cờ:** 2D PNG, 13 phối màu vector tự vẽ và 5 bộ SVG có giấy phép nguồn mở (Fantasy, Spatial, Celtic, Chessnut, RhosGFX), tải tại bước build và được cache để chơi offline.
- **Nhiều đối thủ offline:** Stockfish cùng 18 profile/phong cách cờ có cấu hình tìm kiếm, độ ngẫu nhiên và đánh giá vị trí khác nhau. Các profile VILA không phải 18 engine neural được huấn luyện độc lập, và chưa có Elo benchmark riêng.
- **Kho khai cuộc build gate:** workflow release yêu cầu kho ECO đầy đủ (ít nhất 3.000 biến hợp lệ), dừng phát hành nếu tải/parse không đạt chuẩn thay vì im lặng phát hành kho rỗng.
- **Kiểm thử:** có unit test cho clock snapshot/restore và các kiểm thử tĩnh cho tên thương hiệu, profile bot và phong cách quân cờ.

## Trung thực về sức mạnh và dữ liệu

- Stockfish 19 là engine chính khi tài nguyên được đóng gói và khởi tạo thành công. Sức mạnh thực tế phụ thuộc thiết bị, thời gian suy nghĩ, tài nguyên và cấu hình.
- Các profile như Mentor, Hunter, Sentinel, Strategist, Endgame Pro và Chaos là cấu hình trên kernel đánh giá cục bộ, không phải mạng neural đã train độc lập. Không công bố Elo nếu chưa benchmark đối kháng đủ ván.
- Thêm bốn chế độ luyện câu đố: Luyện tự do, đề chiếu hết trong 1 theo ngày (cùng một đề trong ngày trên các thiết bị), Puzzle Rush 3 phút và Sinh tồn 3 mạng. Bộ đếm Rush tự tạm dừng khi rời màn hoặc chuyển ứng dụng; bài hết hạn không được phép ghi đè bởi kết quả Worker cũ.
- Bộ câu đố offline được sinh tự động; nó cần tiếp tục được kiểm tra chiến thuật/đáp án thay thế và chưa được chứng nhận tương đương kho đề tuyển chọn của Chess.com.
- Các bộ quân mới là phối màu trên hình vector tự vẽ trong dự án. Một số nguồn quân cờ cộng đồng ngoài dự án có giấy phép riêng; phiên bản này không nhúng các SVG bên ngoài chưa tải/xác minh được, tránh phân phối nhầm tài nguyên không rõ điều khoản.

## Build bằng GitHub

1. Giải nén ZIP và upload nội dung vào repository GitHub, giữ `.github/workflows/build-android.yml`.
2. Dùng Node.js 22 và Java 21 như workflow.
3. Cài gói và chạy test bằng `npm install`, `npm test`; workflow yêu cầu test đạt trước khi đóng gói.
4. Build web, đồng bộ Capacitor, áp dụng icon/nhãn Android rồi đóng gói APK debug. Lấy APK ở artifact `covua-vila-debug-apk` nếu workflow chạy thành công.

## Lệnh hữu ích

- `npm run test:static` — nhóm test tĩnh/thuần, không cần tất cả runtime dependency.
- `npm test` — full test suite, yêu cầu các dependency đã cài.
- `npm run build` — build web tối ưu, yêu cầu Stockfish assets.
- `npm run android:init` — khởi tạo Android project nếu chưa có và áp dụng thương hiệu.

## Trạng thái xác minh của gói này

Trong môi trường chỉnh sửa hiện tại không có `node_modules` và không truy cập được npm/GitHub qua command line. Vì vậy không tuyên bố đã build APK hoặc chạy thử trên OPPO A17k. Báo cáo kiểm thử chỉ ghi nhận những kiểm tra thực sự thực hiện được; GitHub Actions phải là cổng nghiệm thu cuối trước khi phát hành.
