import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');
const html = read('../index.html');
const main = read('../src/main.js');
const css = read('../src/style.css');
const server = read('../server/social.js');
const pkg = JSON.parse(read('../package.json'));

test('v3.15 navigation preserves ranked time controls, clocks, and random-puzzle views', () => {
  assert.equal(pkg.version, '3.33.0');
  assert.match(html, /data-view="ranked"/);
  assert.match(html, /data-view="puzzles"/);
  assert.match(main, /currentView === 'ranked'.*renderRankedView/s);
  assert.match(main, /currentView === 'puzzles'.*renderPuzzleView/s);
  assert.match(main, /requestStockfishUci\(position\.fen/);
  assert.match(main, /id=\"rankedTimeControl\"/);
  assert.match(main, /JSON\.stringify\(\{ timeControl: selectedRankedTimeControl \}\)/);
  assert.match(main, /data-ranked-clock/);
  assert.match(main, /function updateRankedClockDisplay/);
  assert.match(server, /RANKED_CLOCK_PRESETS\.some/);
  assert.match(server, /settleRankedClock/);
});

test('ranked backend validates chess moves and stores Elo results server-side', () => {
  for (const route of ["'/ranked/queue'", "'/ranked/status'", "'/ranked/cancel-queue'", "'/ranked/matches/:matchId/move'", "'/ranked/matches/:matchId/resign'", "'/ranked/matches/:matchId/abandon'"]) {
    assert.ok(server.includes(route), `missing ranked endpoint ${route}`);
  }
  assert.match(server, /chess\.move\(\{ from, to/);
  assert.match(server, /finishRankedMatch\(match, result/);
  assert.match(server, /const kFactor = 24/);
  assert.doesNotMatch(server, /winnerBonus/);
  assert.match(server, /quitterId === white\.id \? 15 : 0/);
  assert.match(server, /disconnect_timeout/);
  assert.match(server, /recentFinished/);
});

test('ranked result reaches both players and board controls show moved-square labels', () => {
  assert.match(server, /rankedMatchPayload\(recentFinished, req\.socialUser\.id\)/);
  assert.match(main, /ranked-move-tag/);
  assert.match(main, /review-piece-annotation/);
  assert.match(main, /pagehide/);
  assert.match(main, /90 giây/);
  assert.match(main, /renderFullGameResultPanel\(\)/);
  assert.match(css, /\.ranked-move-tag/);
  assert.match(css, /\.review-piece-annotation/);
});

test('piece artwork is original SVG and puzzle engine exposes hint, answer and analysis controls', () => {
  const piecesSource = fs.readFileSync(new URL('../src/pieces.js', import.meta.url), 'utf8');
  assert.match(piecesSource, /original vector artwork drawn for this project/);
  assert.match(piecesSource, /class="piece-svg piece-svg-\$\{piece\.type\}[^"]*" viewBox="0 0 64 64"/);
  assert.match(main, /id="puzzleHint"/);
  assert.match(main, /id="puzzleShowAnswer"/);
  assert.match(main, /id="puzzleAnalyze"/);
  assert.match(main, /Apply the answer to a fresh copy/);
  assert.match(main, /const answerBoard = new Chess\(puzzleState\.rootFen\)/);
  assert.match(main, /recordDailyEvent\('solve_puzzle'\)/);
  assert.match(css, /\.piece-svg/);
});


test('board annotations are touch-driven, compact, movable, and restricted to solo play', () => {
  assert.match(main, /function canAnnotateBoard\(\)/);
  assert.match(main, /function finishAnnotationPointer\(event, board/);
  assert.match(main, /id="boardAnnotationWidget"/);
  assert.match(main, /data-annotation-tool="arrow"/);
  assert.match(main, /data-annotation-tool="circle"/);
  assert.match(main, /id="annotationWidgetGrip"/);
  assert.match(main, /id="annotationColorCycle"/);
  assert.match(main, /manualArrowHeadYellow/);
  assert.match(css, /\.manual-arrow-red/);
  assert.match(css, /\.manual-circle-yellow/);
  assert.match(main, /vila\.chess\.annotation-widget-position\.v2/);
  assert.match(css, /\.board-annotation-widget/);
  const ranked = main.slice(main.indexOf('function renderRankedView()'), main.indexOf('function rankedSyncChess('));
  assert.doesNotMatch(ranked, /id="newGame"|id="undoMove"|id="hintMove"/);
});

test('ranked ratings are separated by bullet, blitz, and rapid', () => {
  assert.match(server, /function ensureCategoryRatings/);
  assert.match(server, /ratingsByCategory/);
  assert.match(server, /match\.timeCategory/);
  assert.match(main, /rankedRatingOf\(own, category\)/);
});
