import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveOfflineSearchBudget, resolveReviewMoveTimeMs } from '../src/engine-budgets.js';

test('full offline profiles receive a bounded search budget driven by saved settings', () => {
  assert.deepEqual(resolveOfflineSearchBudget('classic', { botDepth: 22, botMoveTimeMs: 1600 }), {
    profile: 'classic', depth: 7, maxTimeMs: 1600, maxNodes: 232000
  });
  const budget = resolveOfflineSearchBudget('ethereal', { botDepth: 30, botMoveTimeMs: 5000 });
  assert.equal(budget.depth, 9);
  assert.equal(budget.maxTimeMs, 3200);
  assert.equal(budget.maxNodes, 350000);
});

test('beginner and blitz profiles remain intentionally lighter than full-strength offline profiles', () => {
  const regular = resolveOfflineSearchBudget('ethereal', { botDepth: 22, botMoveTimeMs: 1600 });
  for (const profile of ['blitz', 'rookie']) {
    const light = resolveOfflineSearchBudget(profile, { botDepth: 22, botMoveTimeMs: 1600 });
    assert.ok(light.maxTimeMs < regular.maxTimeMs);
    assert.ok(light.maxNodes < regular.maxNodes);
    assert.ok(light.depth < regular.depth);
  }
});

test('search budget clamps invalid and extreme settings to phone-friendly hard limits', () => {
  const budget = resolveOfflineSearchBudget('classic', { botDepth: 999, botMoveTimeMs: 999999 });
  assert.equal(budget.depth, 9);
  assert.equal(budget.maxTimeMs, 3200);
  assert.equal(budget.maxNodes, 350000);
  const malformed = resolveOfflineSearchBudget('classic', { botDepth: 'bad', botMoveTimeMs: 'bad' });
  assert.ok(malformed.depth >= 4 && malformed.depth <= 10);
  assert.ok(malformed.maxTimeMs >= 900 && malformed.maxTimeMs <= 3200);
});

test('full-game review time scales with the setting, with bounded minimum and maximum', () => {
  assert.equal(resolveReviewMoveTimeMs({ analysisMoveTimeMs: 2600 }), 910);
  assert.equal(resolveReviewMoveTimeMs({ analysisMoveTimeMs: 1000 }), 500);
  assert.equal(resolveReviewMoveTimeMs({ analysisMoveTimeMs: 8000 }), 1800);
  assert.ok(resolveReviewMoveTimeMs({ analysisMoveTimeMs: -200 }) >= 500);
});
