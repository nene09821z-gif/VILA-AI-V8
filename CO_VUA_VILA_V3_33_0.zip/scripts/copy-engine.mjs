import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const required = process.env.REQUIRE_STOCKFISH === '1' || process.argv.includes('--required');
// Full Stockfish is about 94 MB. Keep routine web/APK builds small and reliable;
// add the optional Full build only when explicitly requested.
const includeFull = process.env.INCLUDE_STOCKFISH_FULL === '1';
const packageRoot = path.join(root, 'node_modules', 'stockfish');
const destination = path.join(root, 'public', 'engine');
const liteFiles = ['stockfish-19-lite-single.js', 'stockfish-19-lite-single.wasm'];
// Small JavaScript-only recovery engine for Android WebViews that cannot load WASM.
const asmFiles = ['stockfish-19-asm.js'];
const fullFiles = ['stockfish-19-single.js', 'stockfish-19-single.wasm'];
// Optional Stockfish 10 (npm alias `stockfish-10` -> stockfish@10.0.2): classical-eval, pure asm.js,
// used as a light engine for offline game review / mistake finding. Missing = warning only,
// unless REQUIRE_STOCKFISH_10=1 is set.
const requireSf10 = process.env.REQUIRE_STOCKFISH_10 === '1';
const sf10Root = path.join(root, 'node_modules', 'stockfish-10');
function findFile(dir, file, depth = 0) {
  if (!fs.existsSync(dir) || depth > 6) return null;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
  for (const entry of entries) if (entry.isFile() && entry.name === file) return path.join(dir, entry.name);
  for (const entry of entries) if (entry.isDirectory() && !entry.name.startsWith('.')) {
    const found = findFile(path.join(dir, entry.name), file, depth + 1);
    if (found) return found;
  }
  return null;
}
function fail(message) {
  if (required) { console.error(message); process.exit(1); }
  console.warn(message);
}
if (!fs.existsSync(packageRoot)) {
  fail('[Cờ Vua ViLa] Stockfish package is not installed. Run npm install first.');
  process.exit(required ? 1 : 0);
}
const wanted = [...liteFiles, ...asmFiles, ...(includeFull ? fullFiles : [])];
const sources = new Map(wanted.map(file => [file, findFile(packageRoot, file)]));
const missing = wanted.filter(file => !sources.get(file));
// Validate sources BEFORE clearing public/engine, so a failed build cannot erase
// previously bundled engine files and leave an installed app in a broken state.
if (missing.length) {
  fail(`[Cờ Vua ViLa] Missing Stockfish assets: ${missing.join(', ')}.`);
  process.exit(required ? 1 : 0);
}
// Resolve the optional Stockfish 10 asm.js build before touching public/engine.
let sf10Source = null;
if (fs.existsSync(sf10Root)) {
  for (const candidate of ['stockfish.js', 'stockfish-10.js']) {
    const found = findFile(sf10Root, candidate);
    if (found && fs.statSync(found).size > 1000) { sf10Source = found; break; }
  }
}
if (!sf10Source) {
  const message = '[Cờ Vua ViLa] Stockfish 10 (optional) not found in node_modules/stockfish-10; the app will fall back to Lite/ASM-JS when it is selected.';
  if (requireSf10) { console.error(message); process.exit(1); }
  console.warn(message);
}
fs.mkdirSync(destination, { recursive: true });
for (const entry of fs.readdirSync(destination)) fs.rmSync(path.join(destination, entry), { recursive: true, force: true });
for (const file of wanted) fs.copyFileSync(sources.get(file), path.join(destination, file));
if (sf10Source) fs.copyFileSync(sf10Source, path.join(destination, 'stockfish-10.js'));
for (const licenseName of ['Copying.txt', 'COPYING.txt', 'COPYING', 'LICENSE.txt', 'LICENSE']) {
  const licensePath = findFile(packageRoot, licenseName);
  if (licensePath) { fs.copyFileSync(licensePath, path.join(destination, 'STOCKFISH-LICENSE.txt')); break; }
}
const manifest = { lite: true, asmFallback: true, full: includeFull, sf10: Boolean(sf10Source), sf10Version: sf10Source ? '10.0.2' : null, version: '19.0.1', buildNote: includeFull ? 'Full falls back to Lite, then ASM-JS; Lite falls back to ASM-JS' : 'Lite is default; if Lite WASM fails, ASM-JS is used. Full is optional and falls back to Lite then ASM-JS.' };
fs.writeFileSync(path.join(destination, 'engine-manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`[Cờ Vua ViLa] Stockfish Lite + ASM-JS recovery engine ready. ${includeFull ? 'Full engine also bundled.' : 'Skipping optional 94 MB Full engine.'} ${sf10Source ? 'Stockfish 10 bundled.' : 'Stockfish 10 not bundled.'}`);
