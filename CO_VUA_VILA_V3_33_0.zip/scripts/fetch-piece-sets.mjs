/**
 * Download only piece sets whose source repositories specify permissive licenses.
 * All resulting SVGs are bundled locally so the application can work offline.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicRoot = path.join(root, 'public');
const outputRoot = path.join(publicRoot, 'piece-sets');
const strict = process.env.REQUIRE_PIECE_SETS === '1';
const sets = [
  { id: 'fantasy', author: 'Maurizio Monge', license: 'MIT', licenseUrl: 'https://github.com/maurimo/chess-art/blob/main/LICENSE' },
  { id: 'spatial', author: 'Maurizio Monge', license: 'MIT', licenseUrl: 'https://github.com/maurimo/chess-art/blob/main/LICENSE' },
  { id: 'celtic', author: 'Maurizio Monge', license: 'MIT', licenseUrl: 'https://github.com/maurimo/chess-art/blob/main/LICENSE' },
  { id: 'chessnut', author: 'Alexis Luengas', license: 'Apache-2.0', licenseUrl: 'https://github.com/LexLuengas/chessnut-pieces/blob/master/LICENSE.txt' },
  { id: 'rhosgfx', author: 'RhosGFX', license: 'CC0-1.0', licenseUrl: 'https://creativecommons.org/publicdomain/zero/1.0/' }
];
const sides = ['w', 'b'];
const pieces = ['K', 'Q', 'R', 'B', 'N', 'P'];
const total = sets.length * sides.length * pieces.length;
const jobs = sets.flatMap(set => sides.flatMap(side => pieces.map(piece => ({ set, side, piece }))));
const downloaded = new Map();
let nextJob = 0;
const errors = [];

async function worker() {
  while (true) {
    const index = nextJob++;
    if (index >= jobs.length) return;
    const job = jobs[index];
    const url = `https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/${job.set.id}/${job.side}${job.piece}.svg`;
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(18000), headers: { 'user-agent': 'co-vua-vila-piece-bundler/3.33.0' } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const svg = await response.text();
      if (svg.length < 80 || svg.length > 250_000 || !/<svg\b/i.test(svg) || !/<path\b|<polygon\b|<g\b/i.test(svg)) throw new Error('response is not a bounded SVG piece');
      if (/<script\b|<foreignObject\b|javascript:|onload\s*=|<image\b/i.test(svg)) throw new Error('SVG includes active or embedded content');
      downloaded.set(`${job.set.id}/${job.side}${job.piece}.svg`, svg);
    } catch (error) {
      errors.push(`${job.set.id}/${job.side}${job.piece}.svg: ${error.message || error}`);
    }
  }
}

async function downloadLicense(urls, name, marker) {
  const candidates = Array.isArray(urls) ? urls : [urls];
  const failures = [];
  for (const url of candidates) {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(18000), headers: { 'user-agent': 'co-vua-vila-piece-bundler/3.33.0' } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      if (text.length < 200 || text.length > 200_000 || (marker && !text.includes(marker))) throw new Error('Unexpected license text');
      await fs.writeFile(path.join(outputRoot, name), text, 'utf8');
      return;
    } catch (error) { failures.push(`${url}: ${error.message || error}`); }
  }
  throw new Error(`${name}: ${failures.join('; ')}`);
}

const credits = `# Cờ Vua ViLa — piece-set notices\n\nThese five SVG sets are optional open artwork used under their stated licenses. They are fetched from the upstream Lichess public piece directory during a release build; the app loads the resulting copies locally and caches them for offline use. Do not remove these notices when redistributing the assets.\n\n| Set | Author | License | Source |\n|---|---|---|---|\n${sets.map(s => `| ${s.id} | ${s.author} | ${s.license} | https://github.com/lichess-org/lila/tree/master/public/piece/${s.id} |`).join('\n')}\n\nUpstream license mapping: https://github.com/lichess-org/lila/blob/master/COPYING.md. Cờ Vua ViLa is not affiliated with or endorsed by Lichess. These are piece artwork only; the project does not copy the Chess.com piece assets.\n`;

await Promise.all(Array.from({ length: 6 }, () => worker()));
if (downloaded.size !== total || errors.length) {
  const summary = `[piece-sets] Only ${downloaded.size}/${total} SVG pieces were verified. ${errors.slice(0, 8).join('; ')}`;
  console.error(summary);
  if (strict) {
    console.error('[piece-sets] REQUIRE_PIECE_SETS=1: release build halted; refusing to ship missing online piece assets.');
    process.exitCode = 1;
  } else {
    console.warn('[piece-sets] Non-release build continues; these optional sets fall back to local artwork.');
  }
} else {
  await fs.mkdir(outputRoot, { recursive: true });
  for (const set of sets) {
    const dir = path.join(outputRoot, set.id);
    const temp = `${dir}.tmp`;
    await fs.rm(temp, { recursive: true, force: true });
    await fs.mkdir(temp, { recursive: true });
    for (const piece of pieces) for (const side of sides) {
      const file = `${set.id}/${side}${piece}.svg`;
      await fs.writeFile(path.join(temp, `${side}${piece}.svg`), downloaded.get(file), 'utf8');
    }
    await fs.rm(dir, { recursive: true, force: true });
    await fs.rename(temp, dir);
  }
  // Preserve full source license texts as part of a distributed package.
  try {
    await downloadLicense('https://www.apache.org/licenses/LICENSE-2.0.txt', 'LICENSE-Apache-2.0.txt', 'Apache License');
    await downloadLicense(['https://raw.githubusercontent.com/maurimo/chess-art/master/LICENSE', 'https://raw.githubusercontent.com/maurimo/chess-art/main/LICENSE'], 'LICENSE-MIT-chess-art.txt', 'MIT License');
  } catch (error) {
    errors.push(`license text: ${error.message || error}`);
    if (strict) { console.error(`[piece-sets] ${errors.at(-1)}`); process.exitCode = 1; }
    else console.warn(`[piece-sets] License text fetch was unavailable: ${errors.at(-1)}`);
  }
  await fs.writeFile(path.join(outputRoot, 'CREDITS.md'), credits, 'utf8');
  console.log(`[piece-sets] Bundled ${downloaded.size}/${total} verified SVG pieces across ${sets.length} permissively licensed sets.`);
}
