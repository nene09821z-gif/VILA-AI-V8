# Cờ Vua ViLa — optional piece-set notices

The following sets are downloaded from the Lichess public piece repository by `scripts/fetch-piece-sets.mjs` during a release build. The resulting files are copied into this directory and served locally, allowing offline use. License text files are included by the same build script.

- **Fantasy, Spatial, Celtic** — Maurizio Monge, MIT. Source: https://github.com/maurimo/chess-art; upstream files: https://github.com/lichess-org/lila/tree/master/public/piece
- **Chessnut** — Alexis Luengas, Apache-2.0. Source: https://github.com/LexLuengas/chessnut-pieces
- **RhosGFX** — RhosGFX, CC0-1.0. Source: https://github.com/lichess-org/lila/tree/master/public/piece/rhosgfx; license: https://creativecommons.org/publicdomain/zero/1.0/

Upstream license map: https://github.com/lichess-org/lila/blob/master/COPYING.md. Cờ Vua ViLa is not affiliated with or endorsed by Lichess. Do not remove third-party artwork notices when redistributing downloaded assets.
