# VILA AI V48.0.0 — Media and downloadable artifact fixes

- Routes explicit image creation requests directly to Gemini image generation, including requests with image references.
- Image output requests inline JPEG data explicitly and reports API text/error if no image binary is returned; it no longer treats an ordinary chat response as a generated image.
- Routes natural-language video requests directly to Veo and implements the REST long-running generation, polling, and media download lifecycle.
- Uses `veo-3.1-generate-preview` with supported `predictLongRunning` workflow and optional first-frame image input.
- Exports changed text files individually with extension-correct MIME types. Full-project ZIP is only added to automatic artifacts when the user's prompt explicitly asks for a project ZIP/full project. The explicit ZIP action still exports the whole workspace.
- For explicit standalone file requests, attaches a download artifact from a fenced code block using the requested extension or language.

## Validation

The project includes syntax, regression and API-contract checks. Actual image/video generation depends on an enabled Gemini/Veo model, valid API key, region eligibility and account quota; the repository tests do not pretend to validate live provider access. Android Gradle build must be confirmed in GitHub Actions.
