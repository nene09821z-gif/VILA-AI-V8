# VILA AI Studio 47.0.0 — Powerful AI Gateway

## Added
- Provider circuit breaker: repeated transient upstream failures temporarily open the circuit; after cooldown, a single half-open probe checks recovery.
- Per-account concurrent chat request cap and maximum auto-routing attempts.
- Authenticated `GET /v1/gateway/status` endpoint to inspect provider health, circuit states, and server limits without exposing API keys.
- Server-generated `X-VILA-Request-Id` and metadata-only request logs. Prompts, Firebase tokens, and provider API keys are not logged.
- Gateway UI action to inspect reliability state.

## Fixed
- Automatic routing can continue to another configured provider after provider-specific 401/402/403 failures rather than failing the whole request immediately.
- Malformed payload errors such as 400/422 are not retried across providers.
- Transient failures update circuit-breaker state; successful chat or provider health checks reset the circuit.

## Limits
- Circuit-breaker, concurrency, rate-limit, and usage state remain process-local and reset on restart. These features are operational safeguards, not a durable billing ledger or distributed rate limiter.
- Source checks passed in this package. A real Android Gradle build and live provider requests must still be confirmed in GitHub Actions and on a deployed Gateway.
