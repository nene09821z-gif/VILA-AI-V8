const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const extras = fs.readFileSync(path.join(root, 'app/src/main/assets/vila-extras.js'), 'utf8');
const endpoints = fs.readFileSync(path.join(root, 'app/src/main/assets/endpoints.js'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');
function getFunction(name, nextMarker) {
  const start = html.indexOf(`function ${name}(`);
  const end = html.indexOf(nextMarker, start);
  assert.ok(start >= 0 && end > start, `Cannot locate ${name}`);
  return html.slice(start, end);
}
const intentSource = getFunction('isImageGenerationIntent', 'function classifyTaskForModel');
const context = {};
vm.runInNewContext(intentSource + '\nthis.imageIntent=isImageGenerationIntent;this.videoIntent=isVideoGenerationIntent;', context);
for (const text of ['Tạo cho tôi một bức ảnh con mèo', 'Vẽ một con rồng', 'Create a logo for my game'])
  assert.equal(context.imageIntent(text), true, `Should route image generation: ${text}`);
for (const text of ['Phân tích ảnh này', 'Vẽ sơ đồ kiến trúc', 'Đọc chữ trong ảnh'])
  assert.equal(context.imageIntent(text), false, `Should stay in chat/vision analysis: ${text}`);
for (const text of ['Tạo video phong cảnh núi rừng', 'Làm một clip hoạt hình ngắn', '/video A cat running in a garden'])
  assert.equal(context.videoIntent(text), true, `Should route video generation: ${text}`);
for (const text of ['Phân tích video này', 'Tóm tắt clip tôi gửi'])
  assert.equal(context.videoIntent(text), false, `Should stay in video understanding: ${text}`);
assert.ok(html.includes("delivery:'inline'"), 'Images must request inline binary data');
assert.ok(html.includes("mime_type:'image/jpeg'"), 'Image request must use supported JPEG response MIME');
assert.ok(html.includes('generateImageWithGemini(rawPrompt,imageFiles)'), 'Prompt submit must pass attached reference images');
assert.ok(html.includes('window.__vilaLastChangedProjectFiles=[]'), 'Changed-file list resets per user turn');
assert.ok(html.includes('function exportChangedProjectFiles(options={})'), 'Updated files can be downloaded individually');
assert.ok(html.includes('function maybeAttachRequestedCodeFile(promptText, replyText)'), 'Explicit file requests create attachments');
assert.ok(html.includes("const binaryOnly=new Set(['apk','aab','zip','pdf'"), 'The app must not disguise text code as a binary APK/PDF/ZIP/media file');
assert.ok(html.includes('await exportChangedProjectFiles({auto:true,includeZip:wantsZip})'), 'Full ZIP is no longer automatic for every file edit');
assert.ok(endpoints.includes("videoModel: 'veo-3.1-generate-preview'"), 'Video model uses Veo');
assert.ok(extras.includes(':predictLongRunning'), 'Video generation uses Veo asynchronous endpoint');
assert.ok(extras.includes('generateVideoResponse?.generatedSamples?.[0]?.video?.uri'), 'Video parser reads Veo result URI');
assert.ok(extras.includes('fetch(videoUri'), 'Video bytes are downloaded from the returned URI');
assert.ok(extras.includes('new Blob([blob], { type: mime })'), 'Video output is a binary Blob, not text');
assert.ok(gradle.includes('versionCode 55') && gradle.includes('versionName "48.0.0"'), 'Version metadata is synchronized');
console.log('PASS: V48 image/video direct routing, binary media payload flow, individual file attachments, opt-in ZIP export, Veo polling/download contract.');
