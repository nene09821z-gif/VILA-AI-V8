'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server/src/server.js'), 'utf8');
const engine = fs.readFileSync(path.join(root, 'server/src/engine.js'), 'utf8');
const env = fs.readFileSync(path.join(root, 'server/.env.example'), 'utf8');
const readme = fs.readFileSync(path.join(root, 'README_V42_AI_GATEWAY.md'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');

assert.ok(html.includes('id="vila-v42-gateway-engine"'), 'Gateway UI/engine script must exist');
for (const feature of [
  'Multi-API Gateway', 'Adaptive Router', 'Health Monitor', 'Model marketplace',
  'scanVilaLocalProviders(false)', 'scanVilaLocalProviders(true)', 'checkVilaGatewayServer()',
  'scanVilaGatewayServer()', "authedGatewayFetch('/v1/gateway/check'", 'loadVilaGatewayServerModels()', 'loadVilaGatewayUsage()',
  'checkVilaAppUpdate()', 'loadVilaGatewayStatus()', 'window.loadVilaGatewayStatus', 'window.requestVilaGateway', 'Authorization', 'Bearer '
]) assert.ok(html.includes(feature), `Missing Gateway feature ${feature}`);
assert.ok(html.includes("localStorage.getItem(gatewayModeKey)==='1'"), 'Gateway routing must be an explicit toggle');
assert.ok(java.includes('requestFirebaseIdToken()') && java.includes('getIdToken(false)'), 'Gateway must use a short-lived Firebase ID token from native auth');
assert.ok(server.includes("app.get('/v1/app/version'") && server.includes("app.get('/health'") && server.includes("app.post('/v1/chat/completions'"), 'Gateway health/chat/update routes must exist');
assert.ok(server.includes("NODE_ENV === 'production' && AUTH_MODE === 'off'"), 'Production must refuse unauthenticated mode');
assert.ok(server.includes('admin.auth().verifyIdToken') && server.includes('rateLimit'), 'Backend must verify Firebase tokens and limit requests');
assert.ok(server.includes('concurrencyLimit') && server.includes('MAX_CONCURRENT_REQUESTS_PER_USER'), 'Gateway must bound concurrent requests per account');
assert.ok(server.includes("app.get('/v1/gateway/status'") && server.includes('circuitBreaker.snapshot'), 'Gateway status must expose provider health and circuit-breaker state without secrets');
assert.ok(server.includes('req.vilaRequestId') && server.includes("event: 'http_request'"), 'Requests must get a correlation ID and metadata-only logs');
assert.ok(server.includes('shouldFallback(requestedProvider, upstream.status, message)'), 'Auto mode must fail over provider-specific auth/quota errors');
assert.ok(server.includes('VILA_APP_RELEASE_URL') && server.includes("url.protocol === 'https:'"), 'Update endpoint must only expose HTTPS release URLs');
assert.ok(server.includes('CUSTOM_BASE_URL') || env.includes('CUSTOM_BASE_URL='), 'Admin-configured custom provider must exist');
assert.ok(engine.includes('rankProviders') && engine.includes('isRetryableStatus'), 'Adaptive routing and bounded retry policies must exist');
assert.ok(server.includes('model: modelFor(p.id, task, process.env) || p.model'), 'Router ranking must use task-specific configured models');
assert.ok(server.includes("configured: true, state: 'ok'") && server.includes('configured: false, state:'), 'Provider diagnostics must return a configured flag for successful and absent endpoints');
assert.ok(server.includes("limit: '20mb'") && server.includes('18 * 1024 * 1024'), 'Gateway payload cap must support app image attachment budget while retaining an explicit limit');
assert.ok(env.includes('AUTH_MODE=off') && env.includes('VILA_APP_LATEST_VERSION=48.0.0'), 'Dev and version settings must be documented in env example');
assert.ok(readme.includes('Không có một “AI engine” duy nhất') && readme.includes('xác nhận của người dùng'), 'Deployment guide must state provider requirements and OS update limitation');
assert.ok(workflow.includes('node scripts/test-v42-gateway.js') && workflow.includes('node --test server/test/*.test.js'), 'CI must run V42 static and backend engine tests');
assert.ok(!/sk-[A-Za-z0-9]{20,}|AIzaSy[A-Za-z0-9_-]{30,}/.test(server + env), 'Backend source/example env must not contain real API secrets');
console.log('PASS: V42 AI Gateway UI, Firebase-token bridge, production auth guard, HTTPS update-check, adaptive router contracts and CI hooks.');
