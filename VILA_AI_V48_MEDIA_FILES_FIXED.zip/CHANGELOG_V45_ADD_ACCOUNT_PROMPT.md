# V45 — Auto-prompt "Add Google Account" when Credential Manager has none

## Fix
Previously, when Android's Credential Manager returned `NoCredentialException` (no Google
account configured at the OS level), VILA AI only showed Vietnamese error text and left the
user to find Settings → Accounts themselves.

Now, `MainActivity.java` catches that specific case in `onError()` and automatically opens the
system "Thêm tài khoản" (Add account) screen filtered to Google accounts
(`Settings.ACTION_ADD_ACCOUNT` + `EXTRA_ACCOUNT_TYPES = {"com.google"}`), with a toast telling
the user to come back and tap "Tiếp tục với Google" again afterward.

This does not change anything about the SHA-1/keystore fix from V44 — that is still required
once, in Firebase Console, before Google Sign-In can succeed at all. This only shortens the
no-account case from a text message to a one-tap fix.

## Still missing (unchanged from V44)
See CHANGELOG_V44_LOGIN_STABLE_KEYSTORE.md priority list — register the V44 SHA-1 fingerprint
in Firebase Console first; everything else there still applies.
