# V46 — Fallback to the classic Google account chooser

## Problem
The device has several Google accounts added (as the user's screenshot showed via Settings/Gmail's
account switcher), but VILA AI's "Tiếp tục với Google" button, using only the new Credential
Manager "Sign in with Google" bottom sheet, failed to surface any of them (`NoCredentialException`).
This happens on some OEM Android builds / Play services versions where Credential Manager's
Identity-Provider integration isn't wired up, even though the accounts exist on the device.

## Fix
`startVilaGoogleLogin()` still tries Credential Manager first. If that fails for *any* reason,
`onError()` now calls `launchClassicGoogleSignIn()`, which uses the older, universally-supported
`GoogleSignInClient` API (`com.google.android.gms.auth.api.signin`). This opens Android's native
"Chọn tài khoản" chooser — the exact screen in the screenshot, listing every Google account on
the device plus "Thêm tài khoản khác" — and returns a Firebase-compatible ID token once the user
picks one.

- `finishGoogleFirebaseSignIn()` factors out the shared Firebase sign-in + account-collision
  logic so both the Credential Manager path and the classic fallback path use it.
- `handleClassicGoogleSignInResult()` handles cancel (12501), developer/config error (12500),
  and "no account available" (status 4, which still offers to open Add Account) with the same
  Vietnamese messages as before.
- `app/build.gradle`: added an explicit `com.google.android.gms:play-services-auth:21.2.0`
  dependency (previously only pulled transitively) so the classic API is guaranteed present.

## Still outstanding
Same as V44/V45 — register the debug keystore's SHA-1 in Firebase Console once; see
CHANGELOG_V44_LOGIN_STABLE_KEYSTORE.md.

## Build metadata / CI regression fix
- Bumped Android version metadata to versionCode 52 / versionName 46.0.0.
- Updated legacy regression tests that were still asserting V43 metadata; they now validate the V46 release and classic Google Sign-In fallback dependency.


## V46.0.1 — OAuth configuration consistency patch

- GitHub Actions now treats the current `app/google-services.json` as authoritative for Android app ID and the OAuth Web Client ID. Old optional GitHub Secrets only fill missing values and cannot overwrite the OAuth client selected from the JSON.
- Added a pre-build validation that checks package `com.vila.ai`, the `client_type=3` Web Client ID, and the actual stable debug keystore SHA-1 against the Android OAuth entry. The workflow stops with a direct error rather than building an APK that is predictably rejected by Google.
- The generated source artifact keeps `keystore/vila-debug.keystore`, so rebuilding from that artifact preserves the test SHA-1. This committed key is only for testing; production distribution should use a private release keystore.
- Bumped Android metadata to `versionCode 53` / `versionName 46.0.1`.


## V47.0.0 — AI Gateway reliability upgrade

- Added provider circuit breaker with a single half-open recovery probe after cooldown.
- Fixed auto-routing so provider-specific 401/402/403 errors can fail over to another configured provider, while invalid request payload errors do not.
- Added per-account concurrent chat request limit and a configurable cap on auto-routing attempts.
- Added `X-VILA-Request-Id`, metadata-only request logs, and authenticated `/v1/gateway/status` diagnostics.
- Updated app version comparison and gateway metadata to 47.0.0 (Android versionCode 54).
- Added reliability unit tests for circuit-breaker transitions and fallback policy.
