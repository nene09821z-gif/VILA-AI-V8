'use strict';

/** Small process-local circuit breaker for upstream providers.
 * This deliberately is not a distributed breaker or billing ledger.
 */
class ProviderCircuitBreaker {
  constructor({ failureThreshold = 3, cooldownMs = 30000, now = () => Date.now() } = {}) {
    this.failureThreshold = Math.max(1, Math.min(20, Number(failureThreshold) || 3));
    this.cooldownMs = Math.max(1000, Math.min(600000, Number(cooldownMs) || 30000));
    this.now = now;
    this.states = new Map();
  }

  acquire(providerId, { force = false } = {}) {
    const id = String(providerId || '');
    const state = this.states.get(id);
    const now = this.now();
    if (!state) return { allowed: true, state: 'closed', probe: false };
    if (force) return { allowed: true, state: state.openUntil > now ? 'forced-open' : 'closed', probe: false };
    if (state.state === 'auth-error') return { allowed: false, state: 'auth-error', retryAfterMs: 0 };
    if (state.openUntil > now) {
      return { allowed: false, state: 'open', retryAfterMs: state.openUntil - now };
    }
    if (state.openUntil > 0) {
      if (state.probeInFlight) return { allowed: false, state: 'half-open', retryAfterMs: 1000 };
      state.probeInFlight = true;
      return { allowed: true, state: 'half-open', probe: true };
    }
    return { allowed: true, state: 'closed', probe: false };
  }

  success(providerId, details = '') {
    const id = String(providerId || '');
    const previous = this.states.get(id) || {};
    this.states.set(id, {
      failures: 0, openUntil: 0, probeInFlight: false, state: 'closed',
      lastSuccessAt: this.now(), lastFailureAt: previous.lastFailureAt || null,
      lastError: '', message: String(details || 'Request thành công').slice(0, 180)
    });
  }

  failure(providerId, { retryable = true, status = 0, message = '' } = {}) {
    const id = String(providerId || '');
    const now = this.now();
    const previous = this.states.get(id) || { failures: 0, openUntil: 0, probeInFlight: false };
    const next = { ...previous, probeInFlight: false, lastFailureAt: now, lastStatus: Number(status) || 0, lastError: String(message || '').slice(0, 180) };
    if (!retryable) {
      const authError = Number(status) === 401 || Number(status) === 403;
      next.state = authError ? 'auth-error' : (previous.openUntil > now ? 'open' : 'closed');
      if (authError || previous.openUntil <= now) {
        next.openUntil = 0;
        next.failures = 0;
      }
      this.states.set(id, next);
      return this.snapshot(id);
    }
    next.failures = (Number(previous.failures) || 0) + 1;
    if (previous.probeInFlight || next.failures >= this.failureThreshold) {
      next.openUntil = now + this.cooldownMs;
      next.state = 'open';
    } else {
      next.state = 'closed';
    }
    this.states.set(id, next);
    return this.snapshot(id);
  }

  snapshot(providerId) {
    const id = String(providerId || '');
    const state = this.states.get(id);
    if (!state) return { provider: id, state: 'closed', failures: 0, retryAfterMs: 0, lastSuccessAt: null, lastFailureAt: null, lastError: '' };
    const now = this.now();
    let label = state.state || 'closed';
    if (state.state === 'auth-error') label = 'auth-error';
    else if (state.openUntil > now) label = 'open';
    else if (state.openUntil > 0) label = state.probeInFlight ? 'half-open' : 'half-open-ready';
    else if (state.state === 'auth-error') label = 'auth-error';
    return {
      provider: id, state: label, failures: Number(state.failures) || 0,
      retryAfterMs: Math.max(0, (Number(state.openUntil) || 0) - now),
      lastSuccessAt: state.lastSuccessAt || null, lastFailureAt: state.lastFailureAt || null,
      lastError: String(state.lastError || '').slice(0, 180), lastStatus: Number(state.lastStatus) || 0
    };
  }

  all(providerIds) { return (Array.isArray(providerIds) ? providerIds : []).map(id => this.snapshot(id)); }
}

function shouldFallback(requestedProvider, status, message = '') {
  if (String(requestedProvider || 'auto').toLowerCase() !== 'auto') return false;
  const code = Number(status) || 0;
  // These errors are provider-specific and another configured provider may succeed.
  if ([401, 402, 403].includes(code)) return true;
  if ([400, 422].includes(code)) return false;
  if (code === 404 && /model|not found|unsupported/i.test(String(message))) return true;
  return [0, 408, 425, 429, 500, 502, 503, 504].includes(code);
}

module.exports = { ProviderCircuitBreaker, shouldFallback };
