'use strict';

require('dotenv').config();
const express = require('express');
const { randomUUID } = require('node:crypto');
const { ProviderCircuitBreaker, shouldFallback } = require('./reliability');
const cors = require('cors');
const helmet = require('helmet');
const admin = require('firebase-admin');
const {
  PROVIDER_ORDER, classifyTask, normalizeOpenAIBase, isRetryableStatus, modelFor, rankProviders
} = require('./engine');

const app = express();
const PORT = Number(process.env.PORT || 8787);
const NODE_ENV = String(process.env.NODE_ENV || 'development').toLowerCase();
const AUTH_MODE = String(process.env.AUTH_MODE || (NODE_ENV === 'production' ? 'firebase' : 'off')).toLowerCase();
const TIMEOUT_MS = Math.max(5000, Math.min(180000, Number(process.env.UPSTREAM_TIMEOUT_MS || 45000)));
const RPM = Math.max(1, Math.min(600, Number(process.env.REQUESTS_PER_MINUTE || 30)));
const requestWindows = new Map();
const metrics = { startedAt: Date.now(), requests: 0, success: 0, failed: 0, fallbacks: 0, totalLatencyMs: 0, byProvider: Object.create(null), byUser: Object.create(null) };
const healthCache = new Map();
const MAX_CONCURRENT_REQUESTS_PER_USER = Math.max(1, Math.min(20, Number(process.env.MAX_CONCURRENT_REQUESTS_PER_USER || 3)));
const MAX_PROVIDER_ATTEMPTS = Math.max(1, Math.min(5, Number(process.env.MAX_PROVIDER_ATTEMPTS || 5)));
const inFlightByUser = new Map();
const circuitBreaker = new ProviderCircuitBreaker({ failureThreshold: process.env.CIRCUIT_BREAKER_FAILURE_THRESHOLD || 3, cooldownMs: process.env.CIRCUIT_BREAKER_COOLDOWN_MS || 30000 });

if (NODE_ENV === 'production' && AUTH_MODE === 'off') {
  throw new Error('Security configuration refused: AUTH_MODE=off is prohibited in production.');
}

const allowedOrigins = String(process.env.CORS_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean);
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
// Correlation IDs and metadata-only logs: never log prompts, provider keys, or auth tokens.
app.use((req, res, next) => {
  req.vilaRequestId = randomUUID();
  req.vilaRequestStartedAt = Date.now();
  res.set('X-VILA-Request-Id', req.vilaRequestId);
  res.set('Access-Control-Expose-Headers', 'X-VILA-Provider, X-VILA-Model, X-VILA-Request-Id');
  res.once('finish', () => console.log(JSON.stringify({ event: 'http_request', requestId: req.vilaRequestId, method: req.method, path: req.path, status: res.statusCode, durationMs: Date.now() - req.vilaRequestStartedAt })));
  next();
});

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin không được phép truy cập VILA Gateway.'), false);
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Authorization', 'Content-Type', 'X-VILA-Task'],
  exposedHeaders: ['X-VILA-Provider', 'X-VILA-Model', 'X-VILA-Request-Id'],
  maxAge: 600
}));
app.use(express.json({ limit: '20mb', strict: true }));

let firebaseAdminReady = false;
let firebaseAdminError = '';
function initializeFirebaseAdmin() {
  if (admin.apps.length) { firebaseAdminReady = true; return true; }
  try {
    const projectId = String(process.env.FIREBASE_PROJECT_ID || '').trim();
    const raw = String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim();
    let credential;
    if (raw) {
      const parsed = JSON.parse(raw);
      credential = admin.credential.cert(parsed);
    } else {
      credential = admin.credential.applicationDefault();
    }
    admin.initializeApp({ credential, ...(projectId ? { projectId } : {}) });
    firebaseAdminReady = true;
    firebaseAdminError = '';
    return true;
  } catch (error) {
    firebaseAdminReady = false;
    firebaseAdminError = String(error?.message || error).slice(0, 220);
    return false;
  }
}
if (AUTH_MODE !== 'off') initializeFirebaseAdmin();

function sendError(res, status, code, message, extra = {}) {
  return res.status(status).json({ error: { code, message }, ...extra });
}

async function authenticate(req, res, next) {
  if (AUTH_MODE === 'off' && NODE_ENV !== 'production') {
    req.user = { uid: 'local-dev', email: 'local-dev@vila.invalid', devMode: true };
    return next();
  }
  if (!firebaseAdminReady) {
    initializeFirebaseAdmin();
    if (!firebaseAdminReady) return sendError(res, 503, 'firebase_admin_not_ready', 'Backend chưa cấu hình Firebase Admin. Hãy cung cấp Application Default Credentials hoặc FIREBASE_SERVICE_ACCOUNT_JSON ở secret manager.');
  }
  const header = String(req.headers.authorization || '');
  const match = header.match(/^Bearer\s+(.+)$/i);
  if (!match) return sendError(res, 401, 'auth_required', 'Cần Firebase ID token trong Authorization: Bearer …');
  try {
    const decoded = await admin.auth().verifyIdToken(match[1], true);
    req.user = { uid: decoded.uid, email: decoded.email || '', claims: decoded };
    return next();
  } catch (error) {
    return sendError(res, 401, 'invalid_auth_token', 'Phiên đăng nhập không hợp lệ hoặc đã hết hạn. Hãy đăng nhập lại.', { detail: NODE_ENV === 'production' ? undefined : String(error?.code || error?.message || '').slice(0, 120) });
  }
}

function rateLimit(req, res, next) {
  const uid = req.user?.uid || 'unknown';
  const now = Date.now();
  let bucket = requestWindows.get(uid);
  if (!bucket || now - bucket.start >= 60000) bucket = { start: now, count: 0 };
  bucket.count += 1;
  requestWindows.set(uid, bucket);
  if (requestWindows.size > 10000) {
    for (const [key, entry] of requestWindows) if (now - entry.start > 120000) requestWindows.delete(key);
  }
  if (bucket.count > RPM) {
    res.set('Retry-After', String(Math.max(1, Math.ceil((bucket.start + 60000 - now) / 1000))));
    return sendError(res, 429, 'rate_limit', `Đã vượt hạn mức ${RPM} yêu cầu/phút cho tài khoản này.`);
  }
  return next();
}

function concurrencyLimit(req, res, next) {
  const uid = String(req.user?.uid || 'unknown');
  const count = inFlightByUser.get(uid) || 0;
  if (count >= MAX_CONCURRENT_REQUESTS_PER_USER) {
    res.set('Retry-After', '2');
    return sendError(res, 429, 'concurrency_limit', `Tài khoản đang có ${count} yêu cầu chạy; giới hạn đồng thời là ${MAX_CONCURRENT_REQUESTS_PER_USER}. Hãy đợi một yêu cầu hoàn tất.`);
  }
  inFlightByUser.set(uid, count + 1);
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    const nextCount = Math.max(0, (inFlightByUser.get(uid) || 1) - 1);
    if (nextCount === 0) inFlightByUser.delete(uid);
    else inFlightByUser.set(uid, nextCount);
  };
  res.once('finish', release);
  res.once('close', release);
  return next();
}

function providerConfigs() {
  const env = process.env;
  const make = (id, name, type, keyName, baseName, defaultBase) => {
    const key = String(env[keyName] || '').trim();
    const rawBase = String(env[baseName] || defaultBase || '').trim();
    let base = '';
    let configError = '';
    try {
      if (rawBase) base = type === 'gemini' ? normalizeGeminiBase(rawBase) : normalizeOpenAIBase(rawBase);
    } catch (e) { configError = String(e.message || e); }
    const config = { id, name, type, key, baseUrl: base, configured: !!(key && base && !configError), configError };
    config.model = modelFor(id, 'general', env) || (id === 'gemini' ? 'gemini-2.5-flash' : '');
    return config;
  };
  return [
    make('gemini', 'Google Gemini', 'gemini', 'GEMINI_API_KEY', 'GEMINI_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta'),
    make('openrouter', 'OpenRouter', 'openai', 'OPENROUTER_API_KEY', 'OPENROUTER_BASE_URL', 'https://openrouter.ai/api/v1'),
    make('groq', 'Groq', 'openai', 'GROQ_API_KEY', 'GROQ_BASE_URL', 'https://api.groq.com/openai/v1'),
    make('cerebras', 'Cerebras', 'openai', 'CEREBRAS_API_KEY', 'CEREBRAS_BASE_URL', 'https://api.cerebras.ai/v1'),
    make('custom', 'Custom API', 'openai', 'CUSTOM_API_KEY', 'CUSTOM_BASE_URL', '')
  ];
}

function normalizeGeminiBase(value) {
  const url = new URL(String(value || ''));
  if (!['https:', 'http:'].includes(url.protocol)) throw new Error('Gemini Base URL phải là HTTP/HTTPS.');
  if (url.username || url.password) throw new Error('Không đặt API key trong URL.');
  url.pathname = url.pathname.replace(/\/+$/, '').replace(/\/models\/[^/]+:(?:generateContent|streamGenerateContent)$/i, '').replace(/\/models$/i, '');
  url.search = '';
  url.hash = '';
  return url.toString().replace(/\/$/, '');
}

async function fetchWithTimeout(url, options = {}, timeoutMs = TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error('Upstream timeout')), timeoutMs);
  if (typeof timer.unref === 'function') timer.unref();
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    response.__vilaTimeoutCleanup = () => clearTimeout(timer);
    return response;
  } catch (error) {
    clearTimeout(timer);
    throw error;
  }
}
function releaseResponse(response) {
  try { response?.__vilaTimeoutCleanup?.(); } catch (_) {}
}

function modelForRequest(provider, task, requestModel) {
  const explicit = String(requestModel || '').trim();
  return explicit && explicit.toLowerCase() !== 'auto' ? explicit : modelFor(provider.id, task) || provider.model;
}

function buildOpenAIRequest(provider, model, body, stream) {
  const messages = Array.isArray(body.messages) ? body.messages : [];
  const reqBody = {
    model,
    messages,
    stream,
    ...(Number.isFinite(Number(body.max_tokens)) ? { max_tokens: Math.max(1, Math.min(32768, Number(body.max_tokens))) } : {}),
    ...(Number.isFinite(Number(body.temperature)) ? { temperature: Math.max(0, Math.min(2, Number(body.temperature))) } : {})
  };
  if (provider.id === 'cerebras' || (provider.id === 'groq' && /gpt-oss-/i.test(model))) {
    if (reqBody.max_tokens) { reqBody.max_completion_tokens = reqBody.max_tokens; delete reqBody.max_tokens; }
  }
  if (body.webSearch === true) {
    if (provider.id === 'openrouter') {
      reqBody.tools = [{ type: 'openrouter:web_search', parameters: { engine: 'auto', max_results: 5, max_total_results: 8, search_context_size: 'medium' } }];
    } else if (provider.id === 'groq' && /gpt-oss-(20b|120b)/i.test(model)) {
      reqBody.tools = [{ type: 'browser_search' }];
      reqBody.tool_choice = 'required';
      reqBody.reasoning_effort = 'low';
    }
  }
  return reqBody;
}

function geminiMessagePayload(messages) {
  let systemText = '';
  const contents = [];
  for (const m of (Array.isArray(messages) ? messages : [])) {
    if (!m || !['system', 'user', 'assistant'].includes(m.role)) continue;
    if (m.role === 'system') {
      const text = Array.isArray(m.content) ? m.content.map(x => x?.text || '').join(' ') : String(m.content || '');
      systemText += (systemText ? '\n\n' : '') + text;
      continue;
    }
    const role = m.role === 'assistant' ? 'model' : 'user';
    const rawParts = Array.isArray(m.content) ? m.content : [{ type: 'text', text: String(m.content || '') }];
    const parts = [];
    for (const part of rawParts) {
      if (typeof part === 'string') { if (part) parts.push({ text: part }); continue; }
      if (part?.type === 'text' || typeof part?.text === 'string') { parts.push({ text: String(part.text || '') }); continue; }
      const source = part?.image_url?.url || part?.url || '';
      const match = String(source).match(/^data:(image\/[a-z0-9.+-]+);base64,([a-z0-9+/=\r\n]+)$/i);
      if (match) parts.push({ inlineData: { mimeType: match[1], data: match[2].replace(/\s/g, '') } });
    }
    if (parts.length) contents.push({ role, parts });
  }
  const payload = { contents };
  if (systemText.trim()) payload.systemInstruction = { parts: [{ text: systemText.trim() }] };
  if (Number.isFinite(Number(process.env.GEMINI_MAX_OUTPUT_TOKENS))) payload.generationConfig = { maxOutputTokens: Math.max(128, Math.min(32768, Number(process.env.GEMINI_MAX_OUTPUT_TOKENS))) };
  return payload;
}

function geminiText(data) {
  const candidates = Array.isArray(data?.candidates) ? data.candidates : [];
  return candidates.flatMap(c => Array.isArray(c?.content?.parts) ? c.content.parts : []).map(p => String(p?.text || '')).join('');
}

function toOpenAIShape(data, model) {
  return {
    id: data?.responseId || `vila-${Date.now()}`,
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model,
    choices: [{ index: 0, message: { role: 'assistant', content: geminiText(data) }, finish_reason: data?.candidates?.[0]?.finishReason || 'stop' }],
    usage: data?.usageMetadata ? { prompt_tokens: data.usageMetadata.promptTokenCount || 0, completion_tokens: data.usageMetadata.candidatesTokenCount || 0, total_tokens: data.usageMetadata.totalTokenCount || 0 } : undefined
  };
}

function sseChunk(model, text, finishReason) {
  return `data: ${JSON.stringify({ id: `vila-${Date.now()}`, object: 'chat.completion.chunk', created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: text ? { content: text } : {}, finish_reason: finishReason || null }] })}\n\n`;
}

async function upstreamFor(provider, model, body, stream) {
  if (provider.type === 'gemini') {
    if (body.webSearch === true && !Array.isArray(body.messages)) throw new Error('Yêu cầu tìm web không hợp lệ.');
    const payload = geminiMessagePayload(body.messages);
    if (Number.isFinite(Number(body.max_tokens))) payload.generationConfig = { ...(payload.generationConfig || {}), maxOutputTokens: Math.max(128, Math.min(32768, Number(body.max_tokens))) };
    if (body.webSearch === true) payload.tools = [{ google_search: {} }];
    const method = stream ? 'streamGenerateContent' : 'generateContent';
    const url = `${provider.baseUrl}/models/${encodeURIComponent(model)}:${method}?key=${encodeURIComponent(provider.key)}${stream ? '&alt=sse' : ''}`;
    return fetchWithTimeout(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  }
  const url = `${provider.baseUrl}/chat/completions`;
  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${provider.key}` };
  if (provider.id === 'openrouter') { headers['HTTP-Referer'] = process.env.OPENROUTER_REFERER || 'https://vila-ai.app'; headers['X-Title'] = 'VILA AI Gateway'; }
  return fetchWithTimeout(url, { method: 'POST', headers, body: JSON.stringify(buildOpenAIRequest(provider, model, body, stream)) });
}

async function listProviderModels(provider) {
  if (!provider.configured) return { provider: provider.id, name: provider.name, configured: false, state: provider.configError ? 'config-error' : 'not-configured', count: 0, models: [], message: provider.configError || 'API key chưa được cấu hình trên server.' };
  try {
    const url = provider.type === 'gemini' ? `${provider.baseUrl}/models?key=${encodeURIComponent(provider.key)}` : `${provider.baseUrl}/models`;
    const headers = provider.type === 'gemini' ? {} : { Authorization: `Bearer ${provider.key}` };
    const response = await fetchWithTimeout(url, { headers }, Math.min(TIMEOUT_MS, 20000));
    const raw = await response.text();
    releaseResponse(response);
    let data = {}; try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}
    if (!response.ok) {
      const message = String(data?.error?.message || data?.message || `HTTP ${response.status}`).slice(0, 200);
      const retryable = isRetryableStatus(response.status, message);
      circuitBreaker.failure(provider.id, { retryable, status: response.status, message });
      healthCache.set(provider.id, { state: response.status === 401 || response.status === 403 ? 'auth-error' : 'error', at: Date.now(), message });
      return { provider: provider.id, name: provider.name, configured: true, state: response.status === 401 || response.status === 403 ? 'auth-error' : 'error', count: 0, models: [], httpStatus: response.status, message };
    }
    const source = provider.type === 'gemini' ? (data.models || []) : (data.data || data.models || data.items || []);
    const models = source.map(m => {
      const id = String(m.id || m.name || '').replace(/^models\//, '');
      const methods = Array.isArray(m.supportedGenerationMethods) ? m.supportedGenerationMethods : [];
      const nonChat = /embedding|tts|transcri|speech|image-generation|video-generation|moderation|rerank/i.test(id);
      if (!id || nonChat || (provider.type === 'gemini' && methods.length && !methods.includes('generateContent'))) return null;
      return { id, name: String(m.displayName || m.name || m.id || id), contextLength: Number(m.context_length || m.inputTokenLimit || 0), isFree: /:free$/i.test(id) || (m.pricing && Number(m.pricing.prompt) === 0 && Number(m.pricing.completion) === 0), inputModalities: m.architecture?.input_modalities || [], outputModalities: m.architecture?.output_modalities || [] };
    }).filter(Boolean).slice(0, 800);
    circuitBreaker.success(provider.id, `Health check đọc được ${models.length} model.`);
    healthCache.set(provider.id, { state: 'ok', at: Date.now(), message: `Đã đọc ${models.length} model.` });
    return { provider: provider.id, name: provider.name, configured: true, state: 'ok', count: models.length, models, checkedAt: new Date().toISOString() };
  } catch (error) {
    const message = String(error?.name === 'AbortError' ? 'Timeout khi kiểm tra endpoint.' : error?.message || error).slice(0, 200);
    circuitBreaker.failure(provider.id, { retryable: true, status: 0, message });
    healthCache.set(provider.id, { state: 'network-error', at: Date.now(), message });
    return { provider: provider.id, name: provider.name, configured: true, state: 'network-error', count: 0, models: [], message };
  }
}

function publicProvider(provider) {
  const health = healthCache.get(provider.id) || {};
  return { id: provider.id, name: provider.name, type: provider.type, configured: provider.configured, model: provider.model, state: provider.configured ? (health.state || 'not-checked') : (provider.configError ? 'config-error' : 'not-configured'), lastCheckedAt: health.at || null, message: health.message || provider.configError || '', circuit: circuitBreaker.snapshot(provider.id) };
}

app.get('/v1/app/version', (_req, res) => {
  const version = String(process.env.VILA_APP_LATEST_VERSION || '47.0.0').trim().slice(0, 40);
  const rawReleaseUrl = String(process.env.VILA_APP_RELEASE_URL || '').trim();
  let releaseUrl = '';
  try { const url = new URL(rawReleaseUrl); if (url.protocol === 'https:' && !url.username && !url.password) releaseUrl = url.toString(); } catch (_) {}
  res.set('Cache-Control', 'public, max-age=60');
  return res.json({ app: 'VILA AI STUDIO', version, releaseUrl, updateAvailableConfigured: !!releaseUrl });
});

app.get('/health', (_req, res) => {
  const providers = providerConfigs();
  res.set('Cache-Control', 'no-store');
  res.json({ service: 'VILA AI Gateway', version: '47.0.0', status: 'ok', uptimeSeconds: Math.floor(process.uptime()), authMode: AUTH_MODE === 'off' && NODE_ENV !== 'production' ? 'development-open' : 'firebase-required', firebaseAdminReady, providersConfigured: providers.filter(p => p.configured).length, time: new Date().toISOString() });
});

app.get('/v1/gateway/providers', authenticate, (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ providers: providerConfigs().map(publicProvider), authMode: AUTH_MODE === 'off' && NODE_ENV !== 'production' ? 'development-open' : 'firebase-required' });
});

app.post('/v1/gateway/check', authenticate, rateLimit, async (req, res) => {
  const requested = String(req.body?.provider || 'all').toLowerCase();
  const providers = providerConfigs().filter(p => requested === 'all' || p.id === requested);
  if (!providers.length) return sendError(res, 400, 'unknown_provider', 'Nhà cung cấp không hợp lệ.');
  const results = await Promise.all(providers.map(listProviderModels));
  res.set('Cache-Control', 'no-store');
  res.json({ results: results.map(({ models, ...info }) => ({ ...info, models: models.slice(0, 100) })), checkedAt: new Date().toISOString() });
});

app.get('/v1/models', authenticate, async (req, res) => {
  const providers = providerConfigs();
  const only = String(req.query.provider || '').toLowerCase();
  const selected = providers.filter(p => !only || p.id === only);
  if (only && !selected.length) return sendError(res, 400, 'unknown_provider', 'Nhà cung cấp không hợp lệ.');
  const results = await Promise.all(selected.map(listProviderModels));
  const models = results.flatMap(result => result.models.map(m => ({ ...m, id: `${result.provider}:${m.id}`, provider: result.provider })));
  res.set('Cache-Control', 'no-store');
  res.json({ object: 'list', data: models, providers: results.map(({ models: _models, ...p }) => p), count: models.length });
});

app.get('/v1/gateway/status', authenticate, (req, res) => {
  const providers = providerConfigs().map(publicProvider);
  res.set('Cache-Control', 'no-store');
  return res.json({
    service: 'VILA AI Gateway', version: '47.0.0', uptimeSeconds: Math.floor(process.uptime()),
    authMode: AUTH_MODE === 'off' && NODE_ENV !== 'production' ? 'development-open' : 'firebase-required',
    providersConfigured: providers.filter(p => p.configured).length, providers,
    limits: { requestsPerMinute: RPM, maxConcurrentRequestsPerUser: MAX_CONCURRENT_REQUESTS_PER_USER, maxProviderAttempts: MAX_PROVIDER_ATTEMPTS },
    activeRequestsForAccount: inFlightByUser.get(String(req.user?.uid || '')) || 0,
    reliability: { circuitBreakerFailureThreshold: circuitBreaker.failureThreshold, circuitBreakerCooldownMs: circuitBreaker.cooldownMs },
    note: 'Trạng thái circuit breaker đang chạy trong tiến trình; cần kho chia sẻ nếu triển khai nhiều replica.'
  });
});

app.get('/v1/gateway/usage', authenticate, (req, res) => {
  const byUser = metrics.byUser[req.user.uid] || { requests: 0, success: 0, failed: 0, tokens: 0, costUsd: 0 };
  res.json({ ...byUser, uptimeSeconds: Math.floor(process.uptime()), averageLatencyMs: metrics.requests ? Math.round(metrics.totalLatencyMs / metrics.requests) : 0, fallbackCount: metrics.fallbacks, note: 'Thống kê trong bộ nhớ tiến trình; đặt kho dữ liệu bền vững trước khi dùng tính phí thật.' });
});

app.post('/v1/chat/completions', authenticate, rateLimit, concurrencyLimit, async (req, res) => {
  const started = Date.now();
  const body = req.body || {};
  if (!Array.isArray(body.messages) || body.messages.length === 0) return sendError(res, 400, 'invalid_messages', 'messages phải là mảng có ít nhất một tin nhắn.');
  if (JSON.stringify(body.messages).length > 18 * 1024 * 1024) return sendError(res, 413, 'context_too_large', 'Ngữ cảnh vượt giới hạn 18 MiB cho phép.');
  const task = classifyTask(body.messages, body.task || req.headers['x-vila-task']);
  const requestedProvider = String(body.provider || 'auto').toLowerCase();
  const requestedModel = String(body.model || 'auto').trim();
  const providerList = providerConfigs().map(p => ({ ...p, model: modelFor(p.id, task, process.env) || p.model, health: healthCache.get(p.id)?.state || '' }));
  let candidates = rankProviders(providerList, task, { provider: requestedProvider, model: requestedModel });
  // In auto mode, honor the caller's specific model only when its ID is prefixed with a known provider.
  if (requestedProvider === 'auto' && requestedModel !== 'auto') {
    const prefix = requestedModel.includes(':') ? requestedModel.slice(0, requestedModel.indexOf(':')).toLowerCase() : '';
    if (prefix && providerList.some(p => p.id === prefix)) candidates = providerList.filter(p => p.id === prefix && p.configured);
  }
  candidates = candidates.filter(p => p.configured);
  if (requestedProvider === 'auto') candidates = candidates.slice(0, MAX_PROVIDER_ATTEMPTS);
  if (!candidates.length) return sendError(res, 503, 'no_provider_configured', 'Không có cổng AI phù hợp đã cấu hình trên server. Hãy đặt API key và Base URL ở biến môi trường của backend.', { task });

  const shouldStream = body.stream === true;
  let lastFailure = null;
  for (let index = 0; index < candidates.length; index++) {
    const provider = candidates[index];
    const requestedForProvider = requestedModel.includes(':') && requestedModel.startsWith(`${provider.id}:`) ? requestedModel.slice(provider.id.length + 1) : requestedModel;
    const model = modelForRequest(provider, task, requestedForProvider);
    if (!model) { lastFailure = { status: 503, message: `${provider.name}: chưa cấu hình model cho tác vụ ${task}.` }; continue; }
    if (body.webSearch === true && provider.id === 'groq' && !/gpt-oss-(20b|120b)/i.test(model)) {
      lastFailure = { status: 400, message: 'Groq web search cần model GPT-OSS 20B/120B.' }; continue;
    }
    if (body.webSearch === true && !['gemini', 'openrouter', 'groq'].includes(provider.id)) {
      lastFailure = { status: 400, message: `${provider.name} chưa cấu hình tool tìm web tương thích.` }; continue;
    }
    const permit = circuitBreaker.acquire(provider.id, { force: requestedProvider !== 'auto' });
    if (!permit.allowed) {
      lastFailure = { status: 503, message: `${provider.name} đang tạm nghỉ sau các lỗi liên tiếp; thử lại sau ${Math.max(1, Math.ceil((permit.retryAfterMs || 1000) / 1000))} giây.`, provider: provider.id };
      if (requestedProvider === 'auto' && index < candidates.length - 1) metrics.fallbacks++;
      continue;
    }
    let upstream;
    try {
      upstream = await upstreamFor(provider, model, body, shouldStream);
    } catch (error) {
      lastFailure = { status: 0, message: String(error?.name === 'AbortError' ? 'Timeout từ nhà cung cấp.' : error?.message || error).slice(0, 240), provider: provider.id };
      circuitBreaker.failure(provider.id, { retryable: true, status: 0, message: lastFailure.message });
      healthCache.set(provider.id, { state: 'network-error', at: Date.now(), message: lastFailure.message });
      if (!shouldFallback(requestedProvider, 0, lastFailure.message)) break;
      metrics.fallbacks++;
      continue;
    }
    if (!upstream.ok) {
      const raw = await upstream.text().catch(() => '');
      releaseResponse(upstream);
      let detail = {}; try { detail = raw ? JSON.parse(raw) : {}; } catch (_) {}
      const message = String(detail?.error?.message || detail?.message || raw || `HTTP ${upstream.status}`).slice(0, 360);
      lastFailure = { status: upstream.status, message, provider: provider.id };
      const retryable = isRetryableStatus(upstream.status, message);
      circuitBreaker.failure(provider.id, { retryable, status: upstream.status, message });
      healthCache.set(provider.id, { state: upstream.status === 401 || upstream.status === 403 ? 'auth-error' : (retryable ? 'error' : 'request-error'), at: Date.now(), message });
      // Provider-specific auth/quota failures should move to a different configured provider in auto mode.
      if (!shouldFallback(requestedProvider, upstream.status, message)) break;
      if (index < candidates.length - 1) metrics.fallbacks++;
      continue;
    }

    circuitBreaker.success(provider.id, `Chat thành công với model ${model}.`);
    healthCache.set(provider.id, { state: 'ok', at: Date.now(), message: `Chat thành công với model ${model}.` });
    metrics.requests++;
    metrics.byProvider[provider.id] = (metrics.byProvider[provider.id] || 0) + 1;
    const uid = req.user.uid;
    const user = metrics.byUser[uid] || (metrics.byUser[uid] = { requests: 0, success: 0, failed: 0, tokens: 0, costUsd: 0 });
    user.requests++;
    res.set('X-VILA-Provider', provider.id);
    res.set('X-VILA-Model', model);
    res.set('X-VILA-Request-Id', req.vilaRequestId || randomUUID());
    res.set('Access-Control-Expose-Headers', 'X-VILA-Provider, X-VILA-Model, X-VILA-Request-Id');
    try {
      if (provider.type === 'gemini' && shouldStream) {
        res.status(200).set({ 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
        res.flushHeaders?.();
        const reader = upstream.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '', completed = false;
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split(/\r?\n/); buffer = lines.pop() || '';
          for (const line of lines) {
            if (!line.startsWith('data:')) continue;
            const data = line.slice(5).trim(); if (!data) continue;
            try {
              const payload = JSON.parse(data);
              const text = geminiText(payload);
              if (text) res.write(sseChunk(model, text));
              const finish = payload?.candidates?.[0]?.finishReason;
              if (finish && !completed) { res.write(sseChunk(model, '', String(finish).toLowerCase())); completed = true; }
            } catch (_) { /* Ignore malformed upstream event; continue valid stream. */ }
          }
        }
        releaseResponse(upstream);
        res.write('data: [DONE]\n\n');
        res.end();
      } else if (shouldStream) {
        res.status(200).set({ 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
        res.flushHeaders?.();
        const reader = upstream.body.getReader();
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          res.write(Buffer.from(value));
        }
        releaseResponse(upstream);
        res.end();
      } else {
        const raw = await upstream.text();
        releaseResponse(upstream);
        let data = {}; try { data = raw ? JSON.parse(raw) : {}; } catch (_) { return sendError(res, 502, 'invalid_upstream_json', 'Nhà cung cấp trả dữ liệu không phải JSON hợp lệ.'); }
        if (provider.type === 'gemini') data = toOpenAIShape(data, model);
        data.provider = provider.id;
        user.success++;
        metrics.success++;
        const usage = data.usage || {};
        user.tokens += Number(usage.total_tokens || 0);
        metrics.totalLatencyMs += Date.now() - started;
        return res.status(200).json(data);
      }
      user.success++;
      metrics.success++;
      metrics.totalLatencyMs += Date.now() - started;
      return;
    } catch (error) {
      releaseResponse(upstream);
      if (res.headersSent) {
        // Once a stream starts it cannot be safely spliced with another provider's response.
        res.end();
        user.failed++;
        metrics.failed++;
        metrics.totalLatencyMs += Date.now() - started;
        return;
      }
      lastFailure = { status: 0, message: String(error?.message || error).slice(0, 240), provider: provider.id };
      circuitBreaker.failure(provider.id, { retryable: true, status: 0, message: lastFailure.message });
      healthCache.set(provider.id, { state: 'network-error', at: Date.now(), message: lastFailure.message });
      if (!shouldFallback(requestedProvider, 0, lastFailure.message)) break;
      if (index < candidates.length - 1) metrics.fallbacks++;
    }
  }
  metrics.requests++;
  metrics.failed++;
  metrics.totalLatencyMs += Date.now() - started;
  const user = metrics.byUser[req.user.uid] || (metrics.byUser[req.user.uid] = { requests: 0, success: 0, failed: 0, tokens: 0, costUsd: 0 });
  user.requests++; user.failed++;
  const status = Number(lastFailure?.status || 502);
  return sendError(res, status === 401 || status === 403 ? status : (status >= 400 && status < 500 ? status : 502), 'upstream_failed', `Không có nhà cung cấp nào hoàn tất yêu cầu. ${lastFailure?.provider ? `[${lastFailure.provider}] ` : ''}${lastFailure?.message || 'Lỗi upstream không xác định.'}`, { task, triedProviders: candidates.map(p => p.id) });
});

app.use((error, _req, res, _next) => {
  if (res.headersSent) return res.end();
  if (error instanceof SyntaxError && 'body' in error) return sendError(res, 400, 'invalid_json', 'JSON gửi lên không hợp lệ.');
  if (String(error?.message || '').includes('Origin không được phép')) return sendError(res, 403, 'origin_not_allowed', error.message);
  return sendError(res, 500, 'internal_error', 'Lỗi backend không mong đợi.');
});

app.listen(PORT, '0.0.0.0', () => {
  const configured = providerConfigs().filter(p => p.configured).map(p => p.id);
  console.log(`[VILA Gateway v47.0.0] listening on :${PORT}; env=${NODE_ENV}; auth=${AUTH_MODE}; providers=${configured.join(',') || 'none configured'}; rpm=${RPM}; concurrency=${MAX_CONCURRENT_REQUESTS_PER_USER}; fallbackAttempts=${MAX_PROVIDER_ATTEMPTS}`);
  if (AUTH_MODE !== 'off' && !firebaseAdminReady) console.warn('[VILA Gateway] Firebase Admin not ready:', firebaseAdminError);
});
