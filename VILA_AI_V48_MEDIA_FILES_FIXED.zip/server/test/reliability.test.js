'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { ProviderCircuitBreaker, shouldFallback } = require('../src/reliability');

test('circuit breaker opens after repeated transient failures and allows one half-open probe', () => {
  let now = 1000;
  const cb = new ProviderCircuitBreaker({ failureThreshold: 2, cooldownMs: 5000, now: () => now });
  assert.equal(cb.acquire('gemini').allowed, true);
  cb.failure('gemini', { retryable: true, status: 503, message: 'upstream down' });
  assert.equal(cb.snapshot('gemini').state, 'closed');
  cb.failure('gemini', { retryable: true, status: 503, message: 'still down' });
  assert.equal(cb.snapshot('gemini').state, 'open');
  assert.equal(cb.acquire('gemini').allowed, false);
  now += 5001;
  const probe = cb.acquire('gemini');
  assert.equal(probe.allowed, true);
  assert.equal(probe.state, 'half-open');
  assert.equal(cb.acquire('gemini').allowed, false, 'only one half-open probe may run');
  cb.success('gemini', 'recovered');
  assert.equal(cb.snapshot('gemini').state, 'closed');
});

test('authentication errors do not trip the transient circuit breaker', () => {
  const cb = new ProviderCircuitBreaker({ failureThreshold: 2 });
  cb.failure('groq', { retryable: false, status: 401, message: 'bad key' });
  assert.equal(cb.acquire('groq').allowed, false, 'automatic routing should skip a provider with an auth error');
  assert.equal(cb.acquire('groq', { force: true }).allowed, true, 'explicit provider selection may still probe it');
  assert.equal(cb.snapshot('groq').state, 'auth-error');
});

test('auto routing fails over provider-specific auth, quota and availability failures but not bad payloads', () => {
  assert.equal(shouldFallback('auto', 401, 'bad key'), true);
  assert.equal(shouldFallback('auto', 402, 'billing'), true);
  assert.equal(shouldFallback('auto', 429, 'busy'), true);
  assert.equal(shouldFallback('auto', 404, 'model not found'), true);
  assert.equal(shouldFallback('auto', 400, 'invalid request'), false);
  assert.equal(shouldFallback('groq', 503, 'down'), false);
});
