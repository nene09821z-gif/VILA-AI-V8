# VILA Chess v3.29.0 — test report

## Passed in this environment
- `npm run test:static`: **160/160 tests passed** after the final code changes.
- `node --check` passed for all `.js` and `.mjs` files under `src`, `server`, `scripts`, `tests` and `public`; selected changed modules were checked again after the latest edits.
- Focused v3.29 budget, settings, puzzle interaction, UCI lifecycle, offline fallback and CI workflow tests passed.
- The two GitHub Actions workflows were updated so `npm test` is a required quality gate. A failed test now prevents APK packaging, while the run summary and test report artifact still explain the failure.

## Blocked by unavailable dependencies
- Full `npm test`: **162 passed, 4 test files failed to start** because this runtime has no `node_modules`: `chess.js` is missing for `alternate-engine.test.js`, `chess.test.js` and `v3-25-features.test.js`; `express` is missing for `social.test.js`. These are module-resolution failures, not failed chess assertions.
- `npm run build`: stopped at `scripts/prepare-openings.mjs` because `chess.js` is unavailable. The earlier dependency installation attempt exceeded the environment's command limit. No production build or APK was created.

## Limits
- The ZIP is source for GitHub Actions, not a prebuilt APK.
- No claim is made that the app has been played through in a real Android WebView or on a physical OPPO A17k. Actual touch feel, CPU temperature, engine speed and playing strength still need to be checked on the target phone. No Elo rating has been assigned without a match benchmark.
