# VILA Chess v3.29.0 — mobile interaction, review and appearance

## Changes
- Shared bounded time/depth/node budgets for in-app offline engine and rescue searches.
- Increased full-game review search budget from a fixed 220 ms to a configurable, clamped budget.
- Removed redundant `stop` before starting a new idle UCI review/request.
- Added tap + drag-and-drop puzzle board input, legal destination feedback and pointer cleanup.
- Added local persistence for the legal-move, last-move and subtle-animation preferences.
- Added appearance preview in Settings and reduced-motion/low-power CSS handling.
- Retained eight local piece styles and eight board palettes.
- Added tests for budget clamps, visual settings normalization and v3.29 regression requirements.

## Test status
- See `TEST_REPORT_V3_29_0.md` for precise checks and remaining environment limitations.
