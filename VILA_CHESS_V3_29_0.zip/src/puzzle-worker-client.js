import { createFallbackMatePuzzle, isPuzzleAnswerLegal } from './puzzle-generator.js';

let puzzleWorker = null;
let sequence = 0;
const pending = new Map();

function fastVerifiedFallback(options = {}) {
  // The fallback is intentionally small and deterministic in cost: never run a full search
  // synchronously on the UI thread just because module workers are blocked by the WebView.
  return createFallbackMatePuzzle({
    attempts: 96,
    excludeFens: Array.isArray(options.excludeFens) ? options.excludeFens : []
  });
}

function settle(id, puzzle, error = null) {
  const request = pending.get(id);
  if (!request) return;
  pending.delete(id);
  clearTimeout(request.timeout);
  if (error) request.resolve(fastVerifiedFallback(request.options));
  else request.resolve(puzzle || fastVerifiedFallback(request.options));
}

function stopWorker(error) {
  const failed = puzzleWorker;
  puzzleWorker = null;
  try { failed?.terminate(); } catch {}
  for (const [id, request] of pending) {
    pending.delete(id);
    clearTimeout(request.timeout);
    request.resolve(fastVerifiedFallback(request.options));
  }
  if (error) console.warn('[VILA Chess] Puzzle worker stopped; switched to the fast verified mate puzzle.', error?.message || error);
}

function ensureWorker() {
  if (puzzleWorker) return puzzleWorker;
  if (typeof Worker === 'undefined') return null;
  try {
    const worker = new Worker(new URL('./puzzle-worker.js', import.meta.url), { type: 'module' });
    worker.addEventListener('message', event => {
      const data = event.data || {};
      if (!Number.isInteger(data.id)) return;
      settle(data.id, data.puzzle || null, data.error ? new Error(data.error) : null);
    });
    worker.addEventListener('error', event => stopWorker(event.error || new Error(event.message || 'Puzzle worker error')));
    puzzleWorker = worker;
    return worker;
  } catch (error) {
    console.warn('[VILA Chess] Module worker unavailable for puzzle generation:', error?.message || error);
    return null;
  }
}

/** Main-thread-safe puzzle entrypoint. Expensive tactical scoring runs inside a module worker. */
export function generateOfflinePuzzleInWorker(options = {}) {
  const worker = ensureWorker();
  if (!worker) return Promise.resolve(fastVerifiedFallback(options));
  const id = ++sequence;
  return new Promise(resolve => {
    const timeout = setTimeout(() => {
      // Avoid a long-running worker continuing to consume phone CPU after the UI has recovered.
      const timedOutWorker = puzzleWorker;
      puzzleWorker = null;
      try { timedOutWorker?.terminate(); } catch {}
      for (const [pendingId, request] of pending) {
        pending.delete(pendingId);
        clearTimeout(request.timeout);
        request.resolve(fastVerifiedFallback(request.options));
      }
    }, Math.max(3500, Math.min(8500, Number(options.budgetMs || 6000) + 2000)));
    pending.set(id, { resolve, timeout, options });
    try { worker.postMessage({ id, options }); }
    catch {
      pending.delete(id);
      clearTimeout(timeout);
      resolve(fastVerifiedFallback(options));
    }
  });
}

export { isPuzzleAnswerLegal };
