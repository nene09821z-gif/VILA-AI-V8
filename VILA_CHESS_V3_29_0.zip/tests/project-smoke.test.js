import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('v3.29 package and interface identify the offline chess release', () => {
  const pkg = JSON.parse(read('package.json'));
  const html = read('index.html');
  assert.equal(pkg.version, '3.29.0');
  assert.match(html, /Offline Chess Arena v3\.29/);
  assert.match(read('server/index.js'), /version: '3\.29\.0'/);
  for (const view of ['home', 'play', 'arena', 'puzzles', 'openings', 'coach', 'settings']) assert.ok(html.includes(`data-view="${view}"`), `Missing ${view} view`);
});

test('no language-model API keys, model endpoints or chat routes remain in the app backend', () => {
  const main = read('src/main.js');
  const server = read('server/index.js');
  const pkg = JSON.parse(read('package.json'));
  assert.doesNotMatch(main, /\/api\/ai\/(?:chat|models)|settings\.(?:apiKey|model|endpoint|aiMode|aiProfiles)/);
  assert.doesNotMatch(server, /\/api\/ai\/(?:chat|models)|apiKey|provider-endpoints|ai-request|chat-response/);
  assert.doesNotMatch(pkg.scripts['test:static'], /(?:ai-request|chat-response|provider-endpoints|model-catalog|builtin-models|provider-errors|engine-hub|provider-regression)/);
  for (const deleted of ['server/ai-request.js','server/chat-response.js','server/model-catalog.js','server/provider-errors.js','server/provider-endpoints.js','server/engine-hub.js','src/builtin-models.js']) {
    assert.equal(fs.existsSync(path.join(root, deleted)), false, `${deleted} should be removed`);
  }
});

test('settings keep only chess, presentation and optional community configuration', () => {
  const schema = read('src/settings-schema.js');
  const settings = read('src/main.js').slice(read('src/main.js').indexOf('function renderSettingsView()'), read('src/main.js').indexOf('function wireCommonActions()'));
  assert.match(schema, /export function normalizeSettings/);
  assert.match(schema, /botMoveTimeMs/);
  assert.match(schema, /openingBookEnabled/);
  assert.doesNotMatch(schema, /aiProfiles:|apiKey:|endpoint:|model:|temperature:/);
  assert.match(settings, /Máy chủ cộng đồng/);
  assert.match(settings, /Không phải API key của mô hình AI/);
  assert.match(settings, /Chỉ có engine cờ và tùy chọn giao diện/);
  assert.doesNotMatch(settings, /id=\"(?:providerApiKey|providerEndpoint|providerModel|aiModel)\"/);
});

test('Stockfish MultiPV replies are collected before bot-personality selection', () => {
  const main = read('src/main.js');
  assert.match(main, /async function requestStockfishUci\([\s\S]{0,200}multiPv = 1/);
  assert.match(main, /setoption name MultiPV value \$\{requestedMultiPv\}/);
  assert.match(main, /arenaPvMatch/);
  assert.match(main, /pendingEngineRequest\.candidates\.set/);
  assert.match(main, /personaCandidateScore\(chess, item, profile, bestScore\)/);
  assert.match(main, /pickPersonaBookMove\(chess, profile, OPENINGS/);
});

test('arena clearly labels personas as profiles, not measured 2700-Elo engine binaries', () => {
  const main = read('src/main.js');
  assert.match(main, /các nhãn phong cách không phải xếp hạng Elo đã benchmark/i);
  assert.match(main, /không phải các engine thương hiệu bên ngoài/i);
  assert.match(main, /Stockfish được dùng để tìm nước khi sẵn sàng/);
  assert.match(main, /OFFLINE_ENGINE_CATALOG/);
  for (const profile of ['lc0', 'ethereal', 'berserk', 'fortress', 'endgame', 'dynamic', 'blitz', 'gambit', 'hyper', 'strangler', 'trickster', 'rookie']) {
    assert.ok(main.includes(`profile === '${profile}'`), `missing move-selection behavior for ${profile}`);
  }
});

test('offline puzzle progression has three stages and preserves answer legality checks', () => {
  const main = read('src/main.js');
  assert.match(main, /\['Dễ', 'Trung bình', 'Khó'\]/);
  assert.match(main, /Math\.min\(3, Math\.floor\(puzzleState\.solvedCount \/ 10\)\)/);
  assert.match(main, /isPuzzleAnswerLegal\(offline\)/);
  assert.match(main, /rememberPuzzle\(offline\.fen\)/);
  assert.match(main, /không phải bộ đề tuyển chọn chính thức của Chess\.com/);
});

test('game review, evaluation graph, SAN/PGN export and move annotations remain available', () => {
  const main = read('src/main.js');
  assert.match(main, /function startFullGameReview\(\)/);
  assert.match(main, /function getGameResult\(\)/);
  assert.match(main, /id="reviewGameBtn"/);
  assert.match(main, /id="evaluationMeterWhite"/);
  assert.match(main, /function downloadArenaPgn\(/);
  assert.match(main, /id="boardArrows"/);
});

test('Android board is responsive, square-based and uses pointer-aware drag handling', () => {
  const main = read('src/main.js');
  const css = read('src/style.css');
  assert.match(main, /function wireBoardPointerDrag\(board\)/);
  assert.match(main, /requestAnimationFrame/);
  assert.match(main, /document\.elementFromPoint\(event\.clientX, event\.clientY\)/);
  assert.match(css, /grid-template-rows:repeat\(8,minmax\(0,1fr\)\)/);
  assert.match(css, /env\(safe-area-inset-bottom/);
  assert.match(css, /v3\.28 — compact charcoal\/lime VILA Chess interface/);
});

test('bundled Stockfish assets are validated before build and Android workflow requires them', () => {
  const script = read('scripts/copy-engine.mjs');
  const workflow = read('.github/workflows/build-android.yml');
  assert.match(script, /Validate sources BEFORE clearing/);
  assert.match(script, /stockfish-19-lite-single\.js/);
  assert.match(script, /stockfish-19-lite-single\.wasm/);
  assert.match(script, /stockfish-19-asm\.js/);
  assert.match(workflow, /REQUIRE_STOCKFISH:\s*'1'/);
  assert.match(workflow, /npm test/);
});

test('community/Lichess routes are separate; backend no longer exposes provider model/chat proxy routes', () => {
  const server = read('server/index.js');
  assert.match(server, /app\.use\('\/api\/social'/);
  assert.match(server, /app\.post\('\/api\/lichess\/account'/);
  assert.match(server, /app\.get\('\/api\/health'/);
  assert.doesNotMatch(server, /app\.post\('\/api\/ai\//);
  assert.doesNotMatch(server, /listChessEngines|analyzeWithEngine/);
});

test('SVG piece sets and opening library modules are still wired', () => {
  const main = read('src/main.js');
  const openings = read('src/openings.js');
  const pieces = read('src/pieces.js');
  assert.match(main, /import \{ OPENINGS \} from '\.\/openings\.js'/);
  assert.match(main, /pieceSvgMarkup/);
  assert.match(openings, /export const OPENINGS/);
  assert.match(pieces, /pieceSvgMarkup|export/);
});
