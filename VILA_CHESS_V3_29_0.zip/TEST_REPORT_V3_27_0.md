# VILA Chess v3.27.0 — verification report

## Checks completed in this environment

- `node --check` on every `.js` and `.mjs` file under `src/`, `server/`, `scripts/`, and `tests/`: **passed**.
- `npm run test:static`: **145 passed, 0 failed** (final run: about 2.0 seconds).
- Static source audit: no active `/api/ai/chat` or `/api/ai/models` routes, no provider model/credential helpers, and no active imports referencing the removed provider modules.
- ZIP contents preserve the VILA Chess source, GitHub Actions workflows, local bot profiles/opening repertoires, SVG assets, puzzle/review code, and Stockfish build scripts.

## Checks not completed

- `npm run build` was attempted but stopped in the `prebuild` stage because this container has no `node_modules`; `scripts/prepare-openings.mjs` could not import the package `chess.js` (`ERR_MODULE_NOT_FOUND`). This is an environment/dependency-install blocker, not a successful build.
- The Vite bundle, Stockfish WASM load, Capacitor/Gradle APK build, live online-community routes, and physical Android/WebView drag performance were **not** verified here.
- No tournament/self-play benchmark was run. Stockfish is a real engine, but this report does not claim verified 2700 Elo for the app or its named VILA style profiles.

## Notes on engine/persona behavior

- Arena style bots collect real Stockfish UCI MultiPV first-move candidates and apply profile-specific selection biases and opening repertoires. The names LC0-style, Ethereal-style, and others describe a VILA profile; they are not the original independent branded engine binaries.
- The offline JavaScript search remains a fallback path if Stockfish cannot start. Its strength varies with CPU budget and search settings.
- The puzzle feature generates locally from legal chess positions and stages progress by completed puzzles. It is not the official Chess.com puzzle database.
