# VILA Chess v3.27.0 — Offline Arena & compact mobile UI

## Changes
- Removed the language-model provider UI, provider model preset catalogue, provider-specific backend helpers and `/api/ai/chat` + `/api/ai/models` routes.
- Migrated persisted settings through a whitelist that drops legacy provider credentials, chat models, endpoints and profiles.
- Replaced the remote-chat Coach view with local Stockfish analysis, full-game review, puzzle progression and opening-study actions.
- Added Stockfish UCI MultiPV parsing and passed candidate move/score results to the style-profile chooser in the offline arena.
- Improved Arena labels to distinguish VILA style profiles from original branded engines and from independently measured Elo ratings.
- Added a visible Easy → Medium → Hard puzzle path based on completed puzzle count.
- Refined the Android interface to charcoal/lime surfaces, compact panels, a 5-item bottom navigation with Arena in direct reach, and preserved responsive 8×8 SVG-backed boards.
- Kept a separate optional community backend section for accounts/friends/Lichess; it does not configure any chess-playing model or language model.

## Known limits
- VILA style bots are not independent original LCZero/Ethereal/Berserk binaries. The arena uses different opening repertoires and biases among Stockfish MultiPV lines; a local JavaScript engine is available as fallback.
- Elo controls are approximate, not benchmark ratings. No 2700-Elo benchmark claim is made.
- Puzzle tasks are locally generated and legal-move checked; they are not the official Chess.com puzzle collection.
- Live Lichess/community behavior, APK packaging and device-specific touch performance must be tested in a fully provisioned environment and on Android hardware.
