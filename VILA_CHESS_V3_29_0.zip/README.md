# VILA Chess v3.29.0 — offline-first chess arena

VILA Chess is a mobile-first chess app for GitHub Actions builds. It uses `chess.js` for legal moves, Stockfish 19 from the npm package for UCI search, local SVG/PNG piece sets, offline puzzle generation, and a local game-review workspace. This ZIP is source code, not a prebuilt APK.

## What changed in v3.29.0

- **Responsive board and mobile interaction:** kept delegated input and frame-coalesced drag rendering, added direct pointer drag to tactical puzzles with legal-move filtering and cleanup on pointer cancellation, and kept small-screen animation/shadow costs low.
- **Offline engine budgets:** VILA Classic and style-engine rescue now use a shared bounded search-budget resolver based on saved depth/time settings. The normal engine path remains real Stockfish; offline JavaScript search runs in a module Worker when available. If a WebView cannot create a Worker, the app intentionally limits synchronous fallback search to protect board responsiveness.
- **Review quality:** full-game review now uses a bounded per-position budget derived from the analysis-time setting rather than the previous fixed 220 ms. UCI requests no longer issue an unnecessary `stop` immediately before a fresh analysis request when the engine is already idle.
- **Board customization:** settings include a live appearance preview and persisted toggles for legal-move hints, last-move highlighting, and animation. Eight local piece styles and eight board palettes are available; the same piece renderer is shared by the board, captured-material tray and preview.
- **Training:** puzzle generator remains in a module Worker, while the puzzle board supports taps and drag-and-drop with legal target feedback. Local puzzle difficulty progression, hints, answer reveal, and engine analysis remain available.
- **Game review:** retains move-by-move judgments, evaluation graph, move list/replay, best-line engine analysis and PGN export. Judgments are engine/heuristic estimates and are not claimed to match Chess.com labels.
- **Regression coverage:** added unit tests for engine-budget clamps and visual preference normalization, plus source-level checks for review UCI flow, puzzle pointer input and the eight board/piece styles.

## Honest engine and rating notes

- Stockfish 19 is the main engine, but the strength you experience depends on which asset is packaged, device CPU, time per move, search depth and settings. This environment has not confirmed an APK build or a physical OPPO A17k run.
- VILA's names such as LC0-style, Ethereal-style or Berserk-style are locally implemented profiles over the search engine, not the original third-party engine binaries. Their individual Elo has not been tournament-benchmarked.
- The Elo control approximately limits Stockfish UCI strength; it is not a measured ranking. Game-review terms such as “mistake” and “brilliant” are heuristics from available engine scores. Offline puzzle generation is not a copy of Chess.com's curated puzzle database.
- If Stockfish fails to initialize, VILA attempts its bounded offline search, then a last-resort legal move to keep the game moving. The synchronous emergency path is intentionally shallow to avoid freezing low-end Android WebViews.

## Build from the ZIP

1. Upload/extract the ZIP into a GitHub repository and retain `.github/workflows/build-android.yml`.
2. Use Node.js 22, matching the workflow.
3. Run `npm install`; the postinstall script prepares Stockfish assets.
4. Run `npm run test:static` for dependency-light regression tests. When dependencies are installed, run `npm test` and `npm run build`.
5. To make an Android package, trigger the repository workflow **Build VILA Chess APK**. It installs dependencies, requires the full test suite to pass, builds the web app, syncs Capacitor and uploads a debug APK artifact. If a test fails, the workflow stops packaging and uploads the test report for diagnosis.

## Useful commands

- `npm run dev:web` — Vite frontend.
- `npm run dev:api` — optional community/Lichess backend.
- `npm run test:static` — focused tests that do not require all runtime dependencies.
- `npm test` — full suite (requires installed dependencies).
- `npm run build` — optimized production build (requires installed dependencies and Stockfish assets).
