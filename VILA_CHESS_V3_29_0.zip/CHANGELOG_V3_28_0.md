# VILA Chess v3.28.0 — Engine warm-up, puzzle worker and cosmetic controls

## Improvements
- Kept Stockfish 19 as the real UCI engine and improved the default search budget (depth 22 / 1600 ms per move). These are defaults, not a benchmarked Elo promise. Existing installs carrying the old implicit 18-depth / 1200 ms defaults are migrated, while changed or explicitly saved settings are preserved.
- Fixed the first-move warm-up path: a bot turn waits up to 8 seconds for an initializing Stockfish worker before choosing the weaker JavaScript fallback, and it resumes only if the game position still matches.
- Removed a redundant `stop` sent immediately before a normal Stockfish `go` request, reducing the chance of stale UCI terminal messages being confused with a new search.
- Switched the implicit JavaScript rescue profile from a positional “Leela-style” heuristic to the more tactical offline heuristic, and bounded rescue searches while keeping them in a module worker.
- Moved CPU-heavy offline puzzle generation into a module worker. If module workers are blocked or the job times out, the app returns a fast rules-verified mate-in-one puzzle rather than locking the UI for a long search.
- Added four additional original vector piece appearances: Pearl, Jade, Ruby and Graphite (eight selectable sets in total, including Flat/Royal/Neon/Wood).
- Made all eight board palettes selectable directly in Settings and applied them across play, arena, puzzles and review boards; the chosen palette persists separately from daily cosmetic progress.
- Reduced large shadows and transition cost on small screens and respected the operating system’s reduced-motion preference.

## Verification limits
- Automated source/unit tests and a production build are the local gates. An actual OPPO A17k WebView session, device temperature/performance and GitHub Actions Android APK build still require testing on the target hardware/environment.
- The VILA style profiles remain heuristic profiles, not the original LCZero/Ethereal/Berserk binaries and not independent Elo benchmarks.
