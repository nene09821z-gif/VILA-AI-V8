
        /* Providers Configuration Map */
        const PROVIDERS = {
            gemini: {
                name: 'Google Gemini (Free Tier)',
                baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
                defaultKey: '',
                models: [
                    { id: 'gemini-3.8-flash', name: '🧠 Gemini 3.8 Flash — VIP SMART' },
                    { id: 'gemini-3.7-flash', name: '💻 Gemini 3.7 Flash — CODING' },
                    { id: 'gemini-3.6-flash', name: '⚡ Gemini 3.6 Flash — BALANCED' },
                    { id: 'gemini-3.5-flash', name: '🚀 Gemini 3.5 Flash — FAST' },
                    { id: 'gemini-3.5-flash-lite', name: '💨 Gemini 3.5 Flash-Lite — LIGHT' },
                    { id: 'gemini-3.1-pro', name: '👑 Gemini 3.1 Pro — DEEP REASONING' },
                    { id: 'gemini-2.5-flash', name: '🛡️ Gemini 2.5 Flash — FALLBACK' },
                    { id: 'gemini-2.5-flash-lite', name: '🔋 Gemini 2.5 Flash-Lite — EMERGENCY' }
                ]
            }
        };

        /* Global State */
        let activeProvider = 'gemini';
        let activeApiKey = localStorage.getItem('vila_api_key') || '';
        let activeBaseUrl = PROVIDERS.gemini.baseUrl;
        let currentModel = localStorage.getItem('vila_selected_model') || 'gemini-3.8-flash';
        const MEMORY_KEY = 'vila_conversation_memory_v7';
        const CODE_MEMORY_KEY = 'vila_latest_code_v7';
        const PROJECT_MEMORY_KEY = 'vila_project_memory_v7';
        const MEMORY_LIMIT = 240;
        const REQUEST_CONTEXT_CHAR_LIMIT = 90000;
        const CODING_CONTEXT_MESSAGES = 100;
        const GENERAL_CONTEXT_MESSAGES = 60;
        const REQUEST_COOLDOWN_KEY = 'vila_model_cooldowns_v2';
        const MAX_RETRY_WAIT_MS = 12000;
        let modelCooldowns = {};
        let availableGeminiModels = [];
        try { modelCooldowns = JSON.parse(localStorage.getItem(REQUEST_COOLDOWN_KEY) || '{}') || {}; } catch (_) { modelCooldowns = {}; }
        const PROJECT_MEMORY_LIMIT = 12000;
        let conversationHistory = [];
        let projectMemory = localStorage.getItem(PROJECT_MEMORY_KEY) || "";
        let latestGeneratedCode = localStorage.getItem(CODE_MEMORY_KEY) || "";
        let isProcessing = false;
        let pendingAttachments = [];
        const MAX_FILE_CHARS = 60000;

        function renderAttachmentTray(){
            const tray=document.getElementById('attachmentTray'); if(!tray) return;
            tray.innerHTML=pendingAttachments.map((f,i)=>`<div class="v11-file-chip"><i class="fa-solid ${f.kind==='image'?'fa-image':'fa-file-lines'}"></i><span>${escapeHtml(f.name)}</span><span class="v11-read-status">${f.status==='ready'?'Đã đọc':'...'}</span><button type="button" onclick="removeAttachment(${i})" aria-label="Xóa file"><i class="fa-solid fa-xmark"></i></button></div>`).join('');
        }
        window.removeAttachment=function(i){ pendingAttachments.splice(i,1); renderAttachmentTray(); };
        function cleanFileText(text){ return String(text||'').replace(/\u0000/g,'').replace(/\r/g,'').slice(0,MAX_FILE_CHARS); }
        async function readPdfFile(file){
            const ab=await file.arrayBuffer();
            const pdfjs=window.pdfjsLib;
            if(!pdfjs) throw new Error('PDF reader chưa tải xong');
            const pdf=await pdfjs.getDocument({data:ab}).promise; let out=[];
            for(let p=1;p<=pdf.numPages;p++){ const page=await pdf.getPage(p); const tc=await page.getTextContent(); out.push(tc.items.map(x=>x.str).join(' ')); if(out.join('\n').length>=MAX_FILE_CHARS) break; }
            return cleanFileText(out.join('\n\n'));
        }
        async function readDocxFile(file){
            if(!window.mammoth) throw new Error('DOCX reader chưa tải xong');
            const ab=await file.arrayBuffer(); const r=await mammoth.extractRawText({arrayBuffer:ab}); return cleanFileText(r.value);
        }
        async function readAttachment(file){
            const lower=file.name.toLowerCase();
            if(file.type.startsWith('image/')) return {kind:'image',content:'',status:'ready'};
            if(lower.endsWith('.pdf')) return {kind:'text',content:await readPdfFile(file),status:'ready'};
            if(lower.endsWith('.docx')) return {kind:'text',content:await readDocxFile(file),status:'ready'};
            return {kind:'text',content:cleanFileText(await file.text()),status:'ready'};
        }
        async function handleFiles(files){
            for(const file of Array.from(files||[])){
                if(file.size>8*1024*1024){ showToast(`${file.name}: file quá lớn (tối đa 8MB).`,'error'); continue; }
                const item={name:file.name,size:file.size,kind:file.type.startsWith('image/')?'image':'text',content:'',status:'reading'};
                pendingAttachments.push(item); renderAttachmentTray();
                try{ const r=await readAttachment(file); Object.assign(item,r); showToast(`Đã đọc ${file.name}`,'success'); }
                catch(e){ item.status='error'; showToast(`Không đọc được ${file.name}: ${e.message||'lỗi file'}`,'error'); }
                renderAttachmentTray();
            }
        }



        /* VILA V15.1: fast controls, sessions, voice, modes */
        const VILA_SESSIONS_KEY = 'vila_chat_sessions_v1';
        let vilaMode = 'chat';
        let vilaCurrentSessionId = localStorage.getItem('vila_current_session_v1') || ('s_' + Date.now());

        function vilaSaveSession(){
            try{
                const all = JSON.parse(localStorage.getItem(VILA_SESSIONS_KEY) || '[]');
                const titleMsg = conversationHistory.find(x=>x.role==='user')?.content || 'Đoạn chat mới';
                const title = String(titleMsg).replace(/\s+/g,' ').slice(0,60);
                const clean = conversationHistory.filter(x=>x.role!=='system').slice(-MEMORY_LIMIT);
                const i = all.findIndex(x=>x.id===vilaCurrentSessionId);
                const item={id:vilaCurrentSessionId,title,messages:clean,updatedAt:Date.now()};
                if(i>=0) all[i]=item; else all.unshift(item);
                localStorage.setItem(VILA_SESSIONS_KEY,JSON.stringify(all.slice(0,30)));
                vilaRenderSessions();
            }catch(e){console.warn('session save',e);}
        }
        function vilaRenderSessions(){
            const box=document.getElementById('vilaSessionList'); if(!box)return;
            let all=[]; try{all=JSON.parse(localStorage.getItem(VILA_SESSIONS_KEY)||'[]')}catch(_){}
            box.innerHTML = all.length ? all.map(x=>`<div class="v15-session" data-session="${escapeHtml(x.id)}"><i class="fa-regular fa-message text-gray-500"></i><span class="title">${escapeHtml(x.title||'Đoạn chat')}</span><button type="button" class="v15-tool vila-delete-session" data-del="${escapeHtml(x.id)}" title="Xóa"><i class="fa-solid fa-trash"></i></button></div>`).join('') : '<div class="text-xs text-gray-500 p-2">Chưa có đoạn chat cũ</div>';
            box.querySelectorAll('[data-session]').forEach(el=>el.addEventListener('click',e=>{
                if(e.target.closest('[data-del]')) return;
                vilaOpenSession(el.dataset.session);
            }));
            box.querySelectorAll('[data-del]').forEach(b=>b.addEventListener('click',e=>{
                e.stopPropagation();
                let a=JSON.parse(localStorage.getItem(VILA_SESSIONS_KEY)||'[]').filter(x=>x.id!==b.dataset.del);
                localStorage.setItem(VILA_SESSIONS_KEY,JSON.stringify(a)); vilaRenderSessions();
            }));
        }
        function vilaNewChat(){
            vilaSaveSession();
            vilaCurrentSessionId='s_'+Date.now();
            localStorage.setItem('vila_current_session_v1',vilaCurrentSessionId);
            conversationHistory=[]; projectMemory=''; latestGeneratedCode='';
            localStorage.removeItem(MEMORY_KEY); localStorage.removeItem(PROJECT_MEMORY_KEY); localStorage.removeItem(CODE_MEMORY_KEY);
            setupSystemPrompt();
            const box=document.getElementById('chatMessages'); if(box) box.innerHTML='';
            const input=document.getElementById('userPrompt'); if(input){input.value='';input.style.height='auto';}
            document.getElementById('vilaSessionMenu')?.classList.add('hidden');
            showToast('Đã tạo đoạn chat mới','success');
        }
        function vilaOpenSession(id){
            let all=[]; try{all=JSON.parse(localStorage.getItem(VILA_SESSIONS_KEY)||'[]')}catch(_){}
            const x=all.find(v=>v.id===id); if(!x)return;
            vilaCurrentSessionId=id; localStorage.setItem('vila_current_session_v1',id);
            conversationHistory=Array.isArray(x.messages)?x.messages.slice():[];
            localStorage.setItem(MEMORY_KEY,JSON.stringify({version:15,savedAt:Date.now(),messages:conversationHistory}));
            const box=document.getElementById('chatMessages'); if(box) box.innerHTML='';
            renderConversationMessages(conversationHistory);
            document.getElementById('vilaSessionMenu')?.classList.add('hidden');
            showToast('Đã mở đoạn chat','success');
        }
        function vilaSetMode(mode){
            vilaMode=mode;
            document.querySelectorAll('[data-vila-mode]').forEach(b=>b.classList.toggle('active',b.dataset.vilaMode===mode));
            const input=document.getElementById('userPrompt');
            if(!input)return;
            input.placeholder = mode==='code' ? 'Mô tả code cần tạo, sửa hoặc kiểm tra…' : mode==='write' ? 'Viết hoặc chỉnh sửa nội dung…' : 'Hỏi VILA AI…';
            refreshSystemPrompt();
        }
        function vilaToggleVoice(){
            const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
            if(!Speech){showToast('Thiết bị/WebView chưa hỗ trợ nhập giọng nói','error');return;}
            const btn=document.getElementById('vilaVoiceBtn');
            if(window.vilaRecognition){window.vilaRecognition.stop();return;}
            const r=new Speech(); window.vilaRecognition=r;
            r.lang='vi-VN'; r.interimResults=true; r.continuous=false;
            btn?.classList.add('recording');
            r.onresult=e=>{
                let finalText='';
                for(let i=e.resultIndex;i<e.results.length;i++) finalText+=e.results[i][0].transcript;
                const input=document.getElementById('userPrompt'); if(input){input.value=finalText;autoResizeTextarea(input);}
            };
            r.onerror=e=>showToast('Không thể ghi âm: '+(e.error||'lỗi'),'error');
            r.onend=()=>{btn?.classList.remove('recording');window.vilaRecognition=null;};
            try{r.start();showToast('Đang nghe…','info')}catch(e){btn?.classList.remove('recording');window.vilaRecognition=null;}
        }

        /* Event Listeners setup on load */
        document.addEventListener('DOMContentLoaded', () => {
            const toggleLayoutBtn = document.getElementById('toggleLayoutBtn');
            if (toggleLayoutBtn) toggleLayoutBtn.addEventListener('click', () => {
                const preview = document.getElementById('previewPanel');
                showMobilePanel(preview && preview.classList.contains('mobile-visible') ? 'chat' : 'preview');
            });
            if (window.innerWidth < 768) showMobilePanel('chat');
            setupSystemPrompt();
            loadConversationMemory();
            populateModelOptions();
            updateUIState();
            vilaRenderSessions();
            document.getElementById('vilaNewChatBtn')?.addEventListener('click', vilaNewChat);
            document.getElementById('vilaCloseSessions')?.addEventListener('click',()=>document.getElementById('vilaSessionMenu')?.classList.add('hidden'));
            document.getElementById('vilaVoiceBtn')?.addEventListener('click', vilaToggleVoice);
            document.querySelectorAll('[data-vila-mode]').forEach(b=>b.addEventListener('click',()=>vilaSetMode(b.dataset.vilaMode)));
            document.getElementById('extraFilePicker')?.addEventListener('change',e=>{handleFiles(e.target.files);e.target.value='';});
            document.getElementById('attachFileBtn')?.addEventListener('click',()=>document.getElementById('filePicker')?.click());
            document.addEventListener('click',e=>{
                const wrap=document.getElementById('vilaSessionWrap');
                const menu=document.getElementById('vilaSessionMenu');
                if(menu && wrap && !wrap.contains(e.target)) menu.classList.add('hidden');
            });

            // Handle Textarea submit and resize
            const userPromptEl = document.getElementById('userPrompt');
            if(userPromptEl) {
                userPromptEl.addEventListener('keydown', handleKeyDown);
                userPromptEl.addEventListener('input', function() { autoResizeTextarea(this); });
            }

            const chatFormEl = document.getElementById('chatForm');
            if(chatFormEl) {
                chatFormEl.addEventListener('submit', handleChatSubmit);
            }
        });

        /* Canvas Interactive Particle Background Engine */
        const canvas = document.getElementById('bgCanvas');
        let ctx = null;
        if(canvas) {
            ctx = canvas.getContext('2d');
            let particles = [];

            function resizeCanvas() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }
            window.addEventListener('resize', resizeCanvas);
            resizeCanvas();

            class Particle {
                constructor() { this.reset(); }
                reset() {
                    this.x = Math.random() * canvas.width;
                    this.y = Math.random() * canvas.height;
                    this.vx = (Math.random() - 0.5) * 0.3;
                    this.vy = (Math.random() - 0.5) * 0.3;
                    this.radius = Math.random() * 1.5 + 0.5;
                    this.alpha = Math.random() * 0.4 + 0.1;
                    this.color = Math.random() > 0.5 ? '#a855f7' : '#00f2fe';
                }
                update() {
                    this.x += this.vx;
                    this.y += this.vy;
                    if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) this.reset();
                }
                draw() {
                    if(!ctx) return;
                    ctx.save();
                    ctx.globalAlpha = this.alpha;
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                    ctx.fillStyle = this.color;
                    ctx.fill();
                    ctx.restore();
                }
            }

            const particleCount = window.innerWidth < 768 ? 0 : 8;
            for (let i = 0; i < particleCount; i++) particles.push(new Particle());
            let lastFrame = 0;
            function animateParticles(now) {
                if (!ctx || particleCount === 0) return;
                if (now - lastFrame < 50) { requestAnimationFrame(animateParticles); return; }
                lastFrame = now;
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                particles.forEach(p => { p.update(); p.draw(); });
                requestAnimationFrame(animateParticles);
            }
            if (particleCount) requestAnimationFrame(animateParticles);
        }

        /* Audio Generator */
        let audioCtx = null;
        function playFuturisticSound(type) {
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (!audioCtx) audioCtx = new AudioContext();
                if (audioCtx.state === 'suspended') audioCtx.resume();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain); gain.connect(audioCtx.destination);
                const now = audioCtx.currentTime;

                if (type === 'send') {
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(440, now);
                    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
                    gain.gain.setValueAtTime(0.1, now);
                    gain.gain.linearRampToValueAtTime(0.01, now + 0.12);
                    osc.start(now); osc.stop(now + 0.12);
                } else if (type === 'complete') {
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(523.25, now);
                    osc.frequency.setValueAtTime(659.25, now + 0.08);
                    gain.gain.setValueAtTime(0.1, now);
                    gain.gain.linearRampToValueAtTime(0.01, now + 0.25);
                    osc.start(now); osc.stop(now + 0.25);
                }
            } catch (e) {
                console.log("Audio not supported or blocked");
            }
        }

        /* VILA Intelligence / Memory Core */
        function cleanDisplayText(text) {
            if (typeof text !== 'string') return '';
            // Remove invisible/control characters but preserve normal Unicode Vietnamese text.
            let s = text.normalize('NFC').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
            // Repair a few common UTF-8 mojibake sequences without touching code blocks.
            const fixes = [['â€™','’'],['â€œ','“'],['â€','”'],['â€“','–'],['â€”','—'],['â€¦','…'],['Â ',' '],['Â','']];
            const parts = s.split(/(```[\\s\\S]*?```)/g);
            for (let i = 0; i < parts.length; i += 2) {
                for (const [bad, good] of fixes) parts[i] = parts[i].split(bad).join(good);
                parts[i] = parts[i].replace(/[ \t]{3,}/g, '  ').replace(/\n{4,}/g, '\n\n\n');
            }
            return parts.join('');
        }

        function classifyTaskForModel(userText) {
            const t = String(userText || '').toLowerCase();
            if (/\b(code|lập trình|javascript|typescript|html|css|python|java|kotlin|android|apk|debug|sửa code|fix code|build|bug|error|api|database|sql|react|node|php|c\+\+|rust|go|java|xml|json)\b/.test(t)) return 'coding';
            if (/\b(phân tích|logic|toán|giải thích sâu|kiến trúc|thuật toán|suy luận|reason|reasoning|debug|so sánh|đánh giá|chứng minh)\b/.test(t)) return 'reasoning';
            if (/\b(ảnh|hình|image|vision|screenshot|photo)\b/.test(t)) return 'multimodal';
            if (/\b(viết|soạn|email|bài văn|caption|kịch bản|biên tập|rewrite|dịch)\b/.test(t)) return 'writing';
            return 'general';
        }

        function getSmartModelOrder(userText) {
            const task = classifyTaskForModel(userText);
            const primary = currentModel || 'gemini-3.8-flash';
            const orders = {
                coding: ['gemini-3.1-pro','gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-2.5-flash'],
                reasoning: ['gemini-3.1-pro','gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-2.5-flash'],
                multimodal: ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-2.5-flash'],
                writing: ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-2.5-flash'],
                general: ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-3.5-flash-lite','gemini-2.5-flash']
            };
            return [primary, ...(orders[task] || orders.general)].filter((m,i,a)=>a.indexOf(m)===i);
        }

        // Build a bounded context window. This prevents old chats from making
        // the model slower and keeps the newest coding decisions highest priority.
        function buildSmartRequestMessages(userText) {
            const task = classifyTaskForModel(userText);
            const system = conversationHistory.find(m => m.role === 'system') || {role:'system',content:getSystemPrompt()};
            const all = conversationHistory.filter(m => m.role !== 'system');
            const limit = task === 'coding' ? CODING_CONTEXT_MESSAGES : GENERAL_CONTEXT_MESSAGES;
            let selected = all.slice(-limit);
            let total = String(system.content || '').length;
            const kept = [];
            for (let i = selected.length - 1; i >= 0; i--) {
                const msg = selected[i];
                const text = String(msg.content || '');
                if (total + text.length > REQUEST_CONTEXT_CHAR_LIMIT && kept.length > 8) break;
                kept.unshift(msg);
                total += text.length;
            }
            return [system, ...kept];
        }

        async function discoverAvailableGeminiModels() {
            if (!activeApiKey) return [];
            try {
                const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(activeApiKey)}&pageSize=1000`);
                if (!r.ok) return [];
                const d = await r.json();
                return (d.models || []).filter(m => Array.isArray(m.supportedGenerationMethods) && m.supportedGenerationMethods.includes('generateContent')).map(m => String(m.baseModelId || m.name || '').replace(/^models\//,''));
            } catch (_) { return []; }
        }

        async function refreshAvailableModels() {
            if (!activeApiKey || !activeBaseUrl.includes('generativelanguage.googleapis.com')) return;
            try {
                const discovered = await discoverAvailableGeminiModels();
                if (!discovered.length) return;
                availableGeminiModels = discovered;
                const preferred = ['gemini-3.1-pro','gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-2.5-flash'];
                const currentAvailable = availableGeminiModels.includes(currentModel);
                if (!currentAvailable) {
                    const next = preferred.find(m => availableGeminiModels.includes(m));
                    if (next) {
                        currentModel = next;
                        localStorage.setItem('vila_selected_model', currentModel);
                        populateModelOptions();
                    }
                }
            } catch (_) {}
        }

        function getSystemPrompt() {
            return `Bạn là VILA AI (Visual Interactive Logic Assistant), một trợ lý AI chuyên sâu về lập trình, phân tích, sáng tạo và xử lý công việc dài. Hãy suy nghĩ có cấu trúc nội bộ trước khi trả lời, nhưng chỉ xuất phần cần thiết cho Master.
MỤC TIÊU: trả lời hữu ích, chính xác, trung thành với yêu cầu hợp lệ của Master và duy trì ngữ cảnh công việc lâu dài.
CHẾ ĐỘ LẬP TRÌNH VIÊN CHUYÊN NGHIỆP:
- Khi yêu cầu liên quan code, hãy ưu tiên tính đúng và khả năng chạy thực tế hơn lời giải thích dài dòng.
- Trước khi sửa: xác định kiến trúc, điểm vào/ra, dependency, state, API và các chức năng đang hoạt động. Không phá tính năng cũ nếu không được yêu cầu.
- Khi sửa lỗi: tìm nguyên nhân gốc trước, sau đó sửa tối thiểu nhưng triệt để; kiểm tra cả lỗi đồng bộ/bất đồng bộ, null/undefined, scope, event listener trùng, race condition, timeout, API status, encoding và dữ liệu biên.
- Khi tạo code dài: trả đủ phần cần chạy, không dùng dấu ba chấm để bỏ qua đoạn quan trọng. Nếu file lớn, chia thành các phần có thứ tự nhưng mỗi phần phải hoàn chỉnh và ghép được.
- Với JavaScript/TypeScript: kiểm tra scope, promise/async-await, DOM lifecycle, event listener, memory leak và lỗi runtime phổ biến.
- Với HTML/CSS: kiểm tra ID/class được gọi có tồn tại, responsive mobile, overflow, z-index, accessibility cơ bản và sự tương thích giữa CSS/JS.
- Với API: kiểm tra payload, endpoint, authentication, HTTP status, retry/backoff, timeout và fallback; không giả định model/API tồn tại nếu chưa xác thực được.
- Với lập trình Android/APK: phân biệt rõ mã nguồn, WebView/JS, manifest, resource và binary APK; không tuyên bố đã build/chạy thành công nếu chưa thực sự kiểm tra.
- Nếu có nhiều cách làm, chọn cách ổn định, dễ bảo trì và ít phụ thuộc nhất; chỉ dùng giải pháp phức tạp khi nó mang lại lợi ích rõ ràng.
- Nếu thông tin thiếu, nêu đúng giả định cần thiết và tiếp tục phần có thể làm được thay vì bịa.
- Không tiết lộ chuỗi suy luận nội bộ. Chỉ cung cấp kết luận, các bước kiểm tra có ích và lý do kỹ thuật ngắn gọn.

NGUYÊN TẮC TRUNG THÀNH:
1. XƯNG HÔ: xưng "VILA", gọi người dùng là "Master" khi phù hợp.
2. ƯU TIÊN YÊU CẦU: bám sát yêu cầu mới nhất của Master; giữ lại các ràng buộc, giao diện, tên biến, kiến trúc và quyết định trước đó nếu chúng vẫn còn hiệu lực. Không tự ý đổi mục tiêu.
3. KHÔNG BỊA: nếu thiếu thông tin hoặc không chắc, nói rõ phần chưa chắc thay vì bịa API, thư viện, tính năng hoặc kết quả.
4. TỰ KIỂM TRA: trước khi đưa code, kiểm tra cú pháp, biến/hàm được gọi, luồng dữ liệu, lỗi null/undefined, điểm tích hợp và tính nhất quán. Nếu có giới hạn do API/model, nói rõ. Với code quan trọng, thực hiện mental test theo các đường chạy chính, trường hợp rỗng, lỗi mạng và dữ liệu bất thường.
5. LẬP TRÌNH MẠNH: khi Master yêu cầu code, ưu tiên code hoàn chỉnh, chạy được, có cấu trúc rõ ràng, xử lý lỗi và bảo toàn phần đang hoạt động. Không tự ý rút gọn để tiết kiệm chữ.
6. CODE DÀI: nếu cần nhiều code, viết đầy đủ và ưu tiên tính chạy được. Không cắt ngắn chỉ vì câu trả lời dài. Không dùng "...", "TODO", "phần còn lại", placeholder hoặc bỏ qua đoạn quan trọng. Với website/app HTML5, nếu Master yêu cầu một file thì đặt HTML + CSS + JS trong một khối \`\`\`html...\`\`\`.
7. SỬA CODE: nếu Master đưa code hiện có, sửa trực tiếp theo mục tiêu; cố gắng giữ tính năng cũ. Khi trả bản hoàn chỉnh, đưa toàn bộ phần cần thay thế thay vì chỉ nói lý thuyết.
8. CHẠY TRỰC TIẾP: HTML/CSS/JS trong Live Preview được gọi là "chạy", "render" hoặc "hiển thị trực tiếp", không gọi là "biên dịch".
9. NGỮ CẢNH: sử dụng lịch sử hội thoại và bộ nhớ dự án được cung cấp. Không bắt Master lặp lại thông tin đã có, trừ khi thông tin thật sự không đủ.
10. GIAO TIẾP: thân thiện, thẳng vào việc, giải thích vừa đủ. Khi Master chỉ muốn kết quả, ưu tiên kết quả.
11. CHẤT LƯỢNG ĐẦU RA: dùng tiếng Việt tự nhiên, Unicode chuẩn NFC, hạn chế ký tự trang trí thừa. Không chèn ký tự rác, mojibake, emoji liên tục hoặc tiêu đề dư thừa. Code phải giữ nguyên ký tự cần thiết cho cú pháp.
12. QUY TRÌNH CODE CHẤT LƯỢNG: khi tạo hoặc sửa code, ưu tiên bản hoàn chỉnh; sau khi viết phải tự rà soát ít nhất 4 lớp: cú pháp, logic, tích hợp/API, và khả năng chạy thực tế. Nếu phát hiện lỗi trong chính bản nháp, tự sửa trước khi trả. Không được tuyên bố "chắc chắn không có lỗi" khi chưa có môi trường chạy thực tế; thay vào đó nói rõ phần đã kiểm tra và phần cần chạy thử.
13. LÀM VIỆC VỚI FILE: khi Master tải file lên, đọc đúng nội dung file được cung cấp; khi sửa code, giữ cấu trúc và tính năng không liên quan. Khi tạo code thành file, luôn đặt trong code block rõ ngôn ngữ để VILA có thể xuất file.
14. AN TOÀN VÀ GIỚI HẠN: tuân thủ các quy tắc an toàn và kỹ thuật của hệ thống; "trung thành" không có nghĩa là bỏ qua các giới hạn đó.

BỘ NHỚ DỰ ÁN:
${projectMemory || "(Chưa có bộ nhớ dự án riêng.)"}`;
        }

        function setupSystemPrompt() {
            conversationHistory = [{ role: 'system', content: getSystemPrompt() }];
        }

        function refreshSystemPrompt() {
            const idx = conversationHistory.findIndex(m => m.role === 'system');
            const prompt = getSystemPrompt();
            if (idx >= 0) conversationHistory[idx].content = prompt;
            else conversationHistory.unshift({ role: 'system', content: prompt });
        }

        function updateProjectMemoryFromTurn(userText, aiText) {
            const combined = `MASTER: ${userText}\nVILA: ${aiText}`;
            const important = combined.length > 9000 ? combined.slice(0, 9000) : combined;
            const stamp = new Date().toLocaleString('vi-VN');
            const entry = `[${stamp}]\n${important}`;
            projectMemory = `${projectMemory ? projectMemory + "\n\n" : ""}${entry}`.slice(-PROJECT_MEMORY_LIMIT);
            try { localStorage.setItem(PROJECT_MEMORY_KEY, projectMemory); } catch (e) {}
            refreshSystemPrompt();
        }

        function saveConversationMemory() {
            try {
                const messages = conversationHistory.filter(m => m.role !== 'system').slice(-MEMORY_LIMIT);
                localStorage.setItem(MEMORY_KEY, JSON.stringify({
                    version: 15,
                    savedAt: Date.now(),
                    messages
                }));
                localStorage.setItem(PROJECT_MEMORY_KEY, projectMemory);
                try { vilaSaveSession(); } catch (_) {}
            } catch (e) {
                console.warn('Không thể lưu bộ nhớ hội thoại:', e);
            }
        }

        function loadConversationMemory() {
            setupSystemPrompt();
            try {
                projectMemory = localStorage.getItem(PROJECT_MEMORY_KEY) || "";
                refreshSystemPrompt();
                const raw = localStorage.getItem(MEMORY_KEY);
                if (!raw) return renderWelcomeMessage();

                const saved = JSON.parse(raw);
                const messages = Array.isArray(saved?.messages) ? saved.messages : [];
                if (!messages.length) return renderWelcomeMessage();

                conversationHistory.push(...messages);
                renderConversationMessages(messages);
            } catch (e) {
                console.warn('Bộ nhớ hội thoại không hợp lệ, tạo phiên mới:', e);
                localStorage.removeItem(MEMORY_KEY);
            localStorage.removeItem(PROJECT_MEMORY_KEY);
                renderWelcomeMessage();
            }
        }

        function renderWelcomeMessage() {
            const chatBox = document.getElementById('chatMessages');
            if (!chatBox) return;
        }

        function renderConversationMessages(messages) {
            const chatBox = document.getElementById('chatMessages');
            if (!chatBox) return;
            chatBox.innerHTML = '';
            messages.forEach(m => {
                if (m.role === 'user') appendUserMessage(m.content, false);
                if (m.role === 'assistant') appendAiMessage(m.content, false);
            });
            scrollToBottom();
        }

        function populateModelOptions() {
            const modelSelect = document.getElementById('modelSelect');
            const mobileModelSelect = document.getElementById('mobileModelSelect');
            if(!modelSelect || !mobileModelSelect) return;
            
            modelSelect.innerHTML = '';
            mobileModelSelect.innerHTML = '';

            const provider = PROVIDERS.gemini;
            
            provider.models.forEach(m => {
                const opt1 = document.createElement('option');
                opt1.value = m.id; opt1.textContent = m.name;
                const opt2 = document.createElement('option');
                opt2.value = m.id; opt2.textContent = m.name;

                modelSelect.appendChild(opt1);
                mobileModelSelect.appendChild(opt2);
            });

            const exists = provider.models.some(m => m.id === currentModel);
            if (!exists && provider.models.length > 0) {
                currentModel = provider.models[0].id;
            }

            modelSelect.value = currentModel;
            mobileModelSelect.value = currentModel;
            
            const handleModelChange = (e) => {
                const target = e.target;
                if(target && 'value' in target) {
                    currentModel = String(target.value);
                    modelSelect.value = currentModel;
                    mobileModelSelect.value = currentModel;
                    localStorage.setItem('vila_selected_model', currentModel);
                    showToast(`Đã chọn model: ${currentModel}`, 'info');
                }
            };
            if (modelSelect._vilaModelHandler) modelSelect.removeEventListener('change', modelSelect._vilaModelHandler);
            if (mobileModelSelect._vilaModelHandler) mobileModelSelect.removeEventListener('change', mobileModelSelect._vilaModelHandler);
            modelSelect._vilaModelHandler = handleModelChange;
            mobileModelSelect._vilaModelHandler = handleModelChange;
            modelSelect.addEventListener('change', handleModelChange);
            mobileModelSelect.addEventListener('change', handleModelChange);
        }

        function applyProviderPreset(type) {
            activeProvider = type;
            const p = PROVIDERS.gemini;
            document.getElementById('apiBaseUrlInput').value = p.baseUrl;
            document.getElementById('apiKeyInput').value = p.defaultKey || (type === activeProvider ? activeApiKey : '');

            const buttons = {
                gemini: document.getElementById('presetGeminiBtn'),
                groq: document.getElementById('presetGroqBtn'),
                github: document.getElementById('presetGithubBtn')
            };
            Object.entries(buttons).forEach(([name, btn]) => {
                if (!btn) return;
                btn.className = name === type
                    ? "py-2.5 px-3 rounded-xl border text-xs font-mono flex items-center justify-center gap-2 transition-all bg-cyan-600/20 border-cyan-500 text-cyan-300"
                    : "py-2.5 px-3 rounded-xl border text-xs font-mono flex items-center justify-center gap-2 transition-all bg-white/5 border-white/10 text-gray-400 hover:text-white";
            });

            if (p.models.length && !p.models.some(m => m.id === currentModel)) {
                currentModel = p.models[0].id;
                localStorage.setItem('vila_selected_model', currentModel);
            }
            populateModelOptions();
            updateUIState();
        }

        function updateUIState() {
            document.getElementById('apiKeyInput').value = activeApiKey;
            document.getElementById('apiBaseUrlInput').value = activeBaseUrl;

            const statusText = document.getElementById('keyStatusText');
            const badge = document.getElementById('keyStatusBadge');
            if(!statusText || !badge) return;

            const icon = badge.querySelector('i');
            if (activeProvider === 'gemini' && activeApiKey) {
                statusText.innerText = "GEMINI FREE KEY ACTIVE";
                statusText.className = "hidden md:inline font-bold text-cyan-300";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-cyan-400";
            } else if (activeApiKey) {
                statusText.innerText = "API KEY ACTIVE";
                statusText.className = "hidden md:inline font-bold text-emerald-300";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-emerald-400";
            } else {
                statusText.innerText = "NO API KEY";
                statusText.className = "hidden md:inline font-bold text-gray-400";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-gray-400 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-gray-500";
            }
        }

        /* VILA V3 PRO: Fast Gemini + Auto Fallback + Optional Google Search */
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        function isRetryableGeminiStatus(status) {
            return [408, 429, 500, 502, 503, 504].includes(Number(status));
        }

        function getFallbackModels(primaryModel) {
            const preferred = [
                primaryModel,
                'gemini-3.5-flash-lite',
                'gemini-2.5-flash-lite',
                'gemini-2.5-flash',
                'gemini-3.5-flash',
                'gemini-3.6-flash',
                'gemini-3.7-flash',
                'gemini-3.8-flash'
            ];
            const validIds = new Set((PROVIDERS.gemini?.models || []).map(m => m.id));
            return [...new Set(preferred)].filter(id => validIds.has(id));
        }

        function parseRetryAfterMs(response, data) {
            const header = response?.headers?.get?.('Retry-After');
            if (header) {
                const seconds = Number(header);
                if (Number.isFinite(seconds)) return Math.min(MAX_RETRY_WAIT_MS, Math.max(500, seconds * 1000));
                const date = Date.parse(header);
                if (Number.isFinite(date)) return Math.min(MAX_RETRY_WAIT_MS, Math.max(500, date - Date.now()));
            }
            const msg = String(data?.error?.message || data?.message || '');
            const match = msg.match(/retry(?:Delay| after)?[\\s:=]+([0-9]+(?:\\.[0-9]+)?)s/i);
            if (match) return Math.min(MAX_RETRY_WAIT_MS, Math.max(500, Number(match[1]) * 1000));
            return 1800;
        }

        function markModelCooldown(model, ms) {
            modelCooldowns[model] = Date.now() + Math.min(ms, 60000);
            try { localStorage.setItem(REQUEST_COOLDOWN_KEY, JSON.stringify(modelCooldowns)); } catch (_) {}
        }

        function getModelCooldown(model) {
            const until = Number(modelCooldowns[model] || 0);
            if (until <= Date.now()) {
                delete modelCooldowns[model];
                return 0;
            }
            return until - Date.now();
        }

        function classifyGeminiError(status, data) {
            const msg = String(data?.error?.message || data?.message || '').toLowerCase();
            const reason = String(data?.error?.status || '').toLowerCase();
            return {
                quota: status === 429 && (reason.includes('resource_exhausted') || msg.includes('quota') || msg.includes('rate limit') || msg.includes('exceeded')),
                retryable: isRetryableGeminiStatus(status)
            };
        }

        async function requestGeminiFast(model, messages, maxRetries = 1) {
            const fetchUrl = `${activeBaseUrl}/chat/completions`;
            let lastError = null;

            const cooldown = getModelCooldown(model);
            if (cooldown > 0) {
                const err = new Error(`Model ${model} đang tạm nghỉ ${Math.ceil(cooldown / 1000)} giây do giới hạn tốc độ.`);
                err.status = 429;
                err.cooldown = true;
                throw err;
            }

            for (let attempt = 0; attempt <= maxRetries; attempt++) {
                let timeoutId = null;
                try {
                    const task = classifyTaskForModel(messages.filter(m => m.role === 'user').slice(-1)[0]?.content || '');
                    const controller = new AbortController();
                    const timeoutMs = task === 'coding' || task === 'reasoning' ? 45000 : 30000;
                    timeoutId = setTimeout(() => controller.abort(), timeoutMs);
                    const generation = task === 'coding'
                        ? { temperature: 0.12, max_tokens: 8192, top_p: 0.92 }
                        : task === 'reasoning'
                            ? { temperature: 0.16, max_tokens: 6144, top_p: 0.92 }
                            : task === 'writing'
                                ? { temperature: 0.35, max_tokens: 6144, top_p: 0.94 }
                                : { temperature: 0.22, max_tokens: 4096, top_p: 0.94 };
                    const responseBody = { model, messages, ...generation };
                    const response = await fetch(fetchUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${activeApiKey}`
                        },
                        body: JSON.stringify(responseBody),
                        signal: controller.signal
                    });
                    clearTimeout(timeoutId);

                    const raw = await response.text();
                    let data = {};
                    try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}

                    if (response.ok) {
                        const aiReply = data?.choices?.[0]?.message?.content || '';
                        if (!aiReply) throw new Error('Gemini không trả về nội dung.');
                        return { aiReply, model };
                    }

                    const error = new Error(data?.error?.message || data?.message || `Gemini API lỗi HTTP ${response.status}`);
                    error.status = response.status;
                    error.retryAfterMs = parseRetryAfterMs(response, data);
                    error.quota = classifyGeminiError(response.status, data).quota;
                    lastError = error;

                    if (response.status === 429) {
                        markModelCooldown(model, error.retryAfterMs);
                        // Do not hammer a rate-limited/quota-limited endpoint.
                        // Fallback is handled by requestGeminiWithFallback().
                        throw error;
                    }

                    if (!isRetryableGeminiStatus(response.status) || attempt >= maxRetries) throw error;
                    await sleep(Math.min(MAX_RETRY_WAIT_MS, 700 + attempt * 900));
                } catch (err) {
                    try { clearTimeout(timeoutId); } catch (_) {}
                    if (err?.name === 'AbortError') { err = Object.assign(new Error('Gemini phản hồi quá lâu và đã được tự ngắt để tránh VILA bị kẹt.'), {status: 408, timeout: true}); }
                    lastError = err;
                    if (err?.status === 429) throw err;
                    if (err?.status && !isRetryableGeminiStatus(err.status)) throw err;
                    if (attempt >= maxRetries) throw err;
                    await sleep(Math.min(MAX_RETRY_WAIT_MS, 700 + attempt * 900));
                }
            }
            throw lastError || new Error('Không thể kết nối Gemini.');
        }

        async function requestGeminiWithFallback(messages) {
            const latestUserText = messages.filter(m => m.role === 'user').slice(-1)[0]?.content || '';
            const models = getSmartModelOrder(latestUserText);
            let lastError = null;
            let quotaHits = 0;

            for (let i = 0; i < models.length; i++) {
                const model = models[i];
                try {
                    const result = await requestGeminiFast(model, messages, 1);
                    if (result.model !== currentModel) {
                        currentModel = result.model;
                        localStorage.setItem('vila_selected_model', currentModel);
                        const a = document.getElementById('modelSelect');
                        const b = document.getElementById('mobileModelSelect');
                        if (a) a.value = currentModel;
                        if (b) b.value = currentModel;
                        showToast(`Đã tự chuyển sang ${currentModel}`, 'success');
                    }
                    return result;
                } catch (err) {
                    lastError = err;
                    const status = Number(err?.status || 0);
                    if (status === 429) {
                        quotaHits++;
                        continue;
                    }
                    const msg = String(err?.message || '').toLowerCase();
                    const canFallback = status === 404 || status === 408 || status >= 500 || (status === 400 && /model|not found|unsupported/.test(msg));
                    if (!canFallback) throw err;
                }
            }

            if (quotaHits > 0) {
                const err = new Error(
                    'Gemini đang hết hạn mức/tốc độ cho API key này. VILA đã thử các model dự phòng nhưng cùng project vẫn bị giới hạn. Hãy chờ quota hồi lại hoặc dùng API key/project có quota khả dụng.'
                );
                err.status = 429;
                err.quota = true;
                throw err;
            }
            throw lastError || new Error('Không có model Gemini khả dụng.');
        }

        function geminiGenerateContentUrl(model) {
            return `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(activeApiKey)}`;
        }

        async function requestGeminiWebSearch(messages) {
            // Search grounding uses the native Gemini generateContent API because
            // Google documents the google_search tool there. The OpenAI compatibility
            // layer does not expose all Gemini-native tools.
            const systemMessage = messages.find(m => m.role === 'system');
            const contents = messages
                .filter(m => m.role === 'user' || m.role === 'assistant')
                .map(m => ({
                    role: m.role === 'assistant' ? 'model' : 'user',
                    parts: [{ text: m.content }]
                }));

            const body = {
                contents,
                tools: [{ google_search: {} }],
                generationConfig: {
                    temperature: 0.2,
                    maxOutputTokens: 4096
                }
            };

            if (systemMessage) {
                body.systemInstruction = {
                    parts: [{ text: systemMessage.content }]
                };
            }

            const model = currentModel || 'gemini-3.8-flash';
            const response = await fetch(geminiGenerateContentUrl(model), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            const raw = await response.text();
            let data = {};
            try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}

            if (!response.ok) {
                const err = new Error(
                    data?.error?.message || `Google Search API lỗi HTTP ${response.status}`
                );
                err.status = response.status;
                throw err;
            }

            const aiReply = (data?.candidates?.[0]?.content?.parts || [])
                .map(p => p.text || '')
                .join('')
                .trim();

            if (!aiReply) throw new Error('Gemini Search không trả về nội dung.');

            // Append compact source list when grounding metadata is available.
            const chunks = data?.groundingMetadata?.groundingChunks || [];
            const sources = chunks
                .map(c => c?.web)
                .filter(w => w?.uri)
                .filter((w, i, arr) => arr.findIndex(x => x.uri === w.uri) === i)
                .slice(0, 8);

            let answer = aiReply;
            if (sources.length) {
                answer += '\n\n### Nguồn Web\n' + sources.map((s, i) =>
                    `${i + 1}. [${s.title || s.uri}](${s.uri})`
                ).join('\n');
            }
            return { aiReply: answer, model };
        }

        function detectCodeFile(rawText) {
            const m = rawText.match(/```([a-zA-Z0-9_-]+)?\s*([\s\S]*?)```/);
            if (!m) return null;
            const lang = (m[1] || '').toLowerCase();
            const extMap = {
                html: 'html', htm: 'html', css: 'css', js: 'js', javascript: 'js',
                json: 'json', py: 'py', python: 'py', txt: 'txt', md: 'md',
                xml: 'xml', svg: 'svg', csv: 'csv'
            };
            const ext = extMap[lang] || 'txt';
            return { code: m[2].trim(), ext, lang: lang || 'txt' };
        }

        window.downloadLatestFile = function() {
            if (!latestGeneratedCode) {
                showToast('Chưa có mã để tạo file.', 'info');
                return;
            }
            downloadTextFile(latestGeneratedCode, `VILA_${Date.now()}.html`, 'text/html');
        };

        function downloadTextFile(content, filename, mime = 'text/plain') {
            const blob = new Blob([content], { type: mime + ';charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            showToast(`Đã tạo file ${filename}`, 'success');
        }

        /* Core Chat Execution */
        async function handleChatSubmit(e) {
            if (e) e.preventDefault();
            if (isProcessing) return;

            const inputEl = document.getElementById('userPrompt');
            if(!inputEl) return;

            let promptText = inputEl.value.trim();
            const usableFiles = pendingAttachments.filter(f=>f.status==='ready');
            if (!promptText && !usableFiles.length) return;
            if (usableFiles.length) {
                const fileContext = usableFiles.map(f=>`\n\n[FILE: ${f.name}]\n${f.content ? f.content : '[Ảnh đính kèm: model hiện tại nhận thông tin file nhưng không trích xuất ảnh trực tiếp trong chế độ này.]'}\n[/FILE]`).join('');
                promptText = (promptText || 'Hãy đọc và phân tích các file tôi đính kèm.') + fileContext;
            }

            if (!activeApiKey) {
                showToast('Vui lòng nhập Gemini API Key!', 'error');
                openSettingsModal();
                return;
            }

            playFuturisticSound('send');
            const displayPrompt = inputEl.value.trim() || 'Hãy đọc và phân tích file đính kèm.';
            appendUserMessage(displayPrompt + (usableFiles.length ? `\n\n📎 ${usableFiles.map(f=>f.name).join(', ')}` : ''));
            inputEl.value = '';
            pendingAttachments = [];
            renderAttachmentTray();
            inputEl.style.height = 'auto';
            document.getElementById('charCounter').innerText = '0 ký tự';
            isProcessing = true;

            const loadingMsgId = appendTypingIndicator();
            conversationHistory.push({ role: 'user', content: promptText });
            refreshSystemPrompt();
            saveConversationMemory();
            const requestMessages = buildSmartRequestMessages(promptText);

            try {
                let result;
                const webToggle = document.getElementById('webSearchToggle');
                const useWebSearch = !!webToggle?.checked;

                if (useWebSearch) {
                    showToast('Đang tìm Web bằng Google Search...', 'info');
                    try {
                        result = await requestGeminiWebSearch(requestMessages);
                    } catch (webErr) {
                        if (Number(webErr?.status) === 429 || Number(webErr?.status) >= 500) {
                            showToast('Web Search đang giới hạn — VILA tự chuyển sang AI thường.', 'info');
                            result = await requestGeminiWithFallback(requestMessages);
                        } else {
                            throw webErr;
                        }
                    }
                } else {
                    result = await requestGeminiWithFallback(requestMessages);
                }

                const aiReply = result.aiReply;
                conversationHistory.push({ role: 'assistant', content: aiReply });
                updateProjectMemoryFromTurn(promptText, aiReply);
                saveConversationMemory();

                removeMessage(loadingMsgId);
                appendAiMessage(aiReply);
                playFuturisticSound('complete');
                extractAndExecuteCode(aiReply);

            } catch (err) {
                removeMessage(loadingMsgId);
                const status = err?.status ? ` (HTTP ${err.status})` : '';
                const friendly = err?.quota || Number(err?.status) === 429
                    ? 'Gemini đang giới hạn quota/rate limit. VILA đã tự thử model dự phòng; không thể vượt quota bằng cách gửi thêm request.'
                    : (err?.message || 'Không thể kết nối Gemini.');
                appendErrorMessage(`Lỗi API${status}: ${friendly}`);
            } finally {
                isProcessing = false;
            }
        }

        function showMobilePanel(which) {
            const previewPanel = document.getElementById('previewPanel');
            const chatPanel = document.getElementById('chatPanel');
            const btn = document.getElementById('toggleLayoutBtn');
            if (!previewPanel || !chatPanel || window.innerWidth >= 768) return;
            const showPreview = which === 'preview';
            previewPanel.classList.toggle('mobile-visible', showPreview);
            previewPanel.classList.toggle('mobile-hidden', !showPreview);
            chatPanel.classList.toggle('mobile-hidden', showPreview);
            chatPanel.classList.toggle('mobile-visible', !showPreview);
            if (btn) {
                btn.innerHTML = showPreview ? '<i class="fa-solid fa-comments"></i>' : '<i class="fa-solid fa-code"></i>';
                btn.title = showPreview ? 'Quay lại trò chuyện' : 'Mở màn hình code';
            }
        }

        function extractAndExecuteCode(rawText) {
            let cleanText = rawText.replace(/<think>[\s\S]*?<\/think>/g, '');
            const codeBlockRegex = /```html([\s\S]*?)```/i;
            const match = cleanText.match(codeBlockRegex);

            if (match && match[1]) {
                latestGeneratedCode = match[1].trim();
                localStorage.setItem(CODE_MEMORY_KEY, latestGeneratedCode);
                runGeneratedCode();

                if (window.innerWidth < 768) {
                    showMobilePanel('preview');
                }
            }
        }

        function runGeneratedCode() {
            if (!latestGeneratedCode) return;
            const iframe = document.getElementById('liveFrame');
            const placeholder = document.getElementById('previewPlaceholder');
            if(!iframe || !placeholder) return;
            
            placeholder.style.display = 'none';

            const doc = iframe.contentWindow?.document;
            if(doc) {
                doc.open();
                doc.write(latestGeneratedCode);
                doc.close();
                showToast('Đã chạy mã thành công!', 'success');
            }
        }

        function inferGeneratedFileMeta(code) {
            const m = String(code || '').match(/^(?:\s*<\!doctype html|\s*<html[\s>])/i);
            if (m) return { ext:'html', mime:'text/html', name:'VILA_App' };
            if (/^\s*[{[]/.test(code) && /["']?[A-Za-z0-9_-]+["']?\s*:/.test(code)) return { ext:'json', mime:'application/json', name:'VILA_Data' };
            if (/^\s*(?:body|html|\.|#|@media|:root)\b[^{]*\{/.test(code)) return { ext:'css', mime:'text/css', name:'VILA_Style' };
            return { ext:'txt', mime:'text/plain', name:'VILA_Code' };
        }

        function downloadCodeAsFile() {
            if (!latestGeneratedCode) {
                showToast('Chưa có mã để tải về!', 'info');
                return;
            }
            const meta = inferGeneratedFileMeta(latestGeneratedCode);
            downloadTextFile(latestGeneratedCode, `${meta.name}_${Date.now()}.${meta.ext}`, meta.mime);
        }

        function reviewCurrentCode() {
            if (!latestGeneratedCode) {
                showToast('Chưa có code để kiểm tra.', 'info');
                return;
            }
            const input = document.getElementById('userPrompt');
            if (!input) return;
            input.value = `Kiểm tra toàn bộ code hiện tại trong Live Preview. Tìm lỗi cú pháp, lỗi logic, lỗi responsive, lỗi API, lỗi bảo mật và lỗi chạy thực tế. Nếu có lỗi, sửa trực tiếp và trả lại bản hoàn chỉnh. Nếu không có lỗi rõ ràng, nêu ngắn gọn các điểm đã kiểm tra.\n\n[CODE HIỆN TẠI]\n${latestGeneratedCode}\n[/CODE HIỆN TẠI]`;
            input.dispatchEvent(new Event('input', {bubbles:true}));
            input.focus();
            showToast('Đã chuẩn bị yêu cầu kiểm tra code.', 'success');
        }

        /* Render Helpers */
        function appendUserMessage(text, doScroll = true) {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return;
            const div = document.createElement('div');
            div.className = "flex gap-4 items-start justify-end group";
            div.innerHTML = `
                <div class="max-w-[85%] space-y-1">
                    <div class="flex items-center justify-end gap-2">
                        <span class="text-[10px] text-gray-500 font-mono">${getCurrentTime()}</span>
                        <span class="font-bold text-xs text-cyan-300">MASTER</span>
                    </div>
                    <div class="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white rounded-2xl rounded-tr-none p-4 text-sm leading-relaxed shadow-lg shadow-purple-900/30">
                        ${escapeHtml(text).replace(/\n/g, '<br>')}
                    </div>
                </div>
                <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-400 to-indigo-600 p-[1px] shrink-0 shadow-md">
                    <div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-white">
                        <i class="fa-solid fa-user text-xs"></i>
                    </div>
                </div>
            `;
            chatBox.appendChild(div);
            if (doScroll) scrollToBottom();
        }

        function appendAiMessage(rawText, doScroll = true) {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return;
            const div = document.createElement('div');
            div.className = "flex gap-4 items-start group";

            rawText = cleanDisplayText(rawText);
            let reasoningContent = "";
            let mainContent = rawText;

            const thinkMatch = rawText.match(/<think>([\s\S]*?)<\/think>/i);
            if (thinkMatch) {
                reasoningContent = thinkMatch[1].trim();
                mainContent = rawText.replace(/<think>[\s\S]*?<\/think>/i, '').trim();
            }

            let formattedHtml = formatMarkdownText(mainContent);
            let reasoningHtml = "";

            if (reasoningContent) {
                reasoningHtml = `
                    <details class="mb-3 rounded-xl bg-black/40 border border-purple-500/20 text-xs text-gray-400 overflow-hidden">
                        <summary class="p-2.5 font-mono cursor-pointer hover:bg-white/5 font-semibold text-purple-300 flex items-center gap-2">
                            <i class="fa-solid fa-brain text-neon-violet"></i> Thấu Quan Trí Tuệ (Reasoning Process)
                        </summary>
                        <div class="p-3 border-t border-purple-500/10 font-mono text-[11px] leading-relaxed whitespace-pre-wrap text-gray-400">
                            ${escapeHtml(reasoningContent)}
                        </div>
                    </details>
                `;
            }

            div.innerHTML = `
                <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1px] shrink-0 shadow-md shadow-purple-500/20">
                    <div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-cyan-300">
                        VILA
                    </div>
                </div>
                <div class="flex-1 space-y-2 overflow-hidden">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-sm text-gradient">VILA AI</span>
                        <span class="text-[10px] text-gray-500 font-mono">${getCurrentTime()}</span>
                    </div>
                    <div class="glass-card rounded-2xl rounded-tl-none p-4 text-sm text-gray-200 leading-relaxed border border-purple-500/20 shadow-xl overflow-x-auto">
                        ${reasoningHtml}
                        ${formattedHtml}
                    </div>
                </div>
            `;
            chatBox.appendChild(div);
            if (doScroll) scrollToBottom();
        }

        function appendTypingIndicator() {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return '';
            const id = 'typing_' + Date.now();
            const div = document.createElement('div');
            div.id = id;
            div.className = "flex gap-4 items-start animate-pulse";
            div.innerHTML = `
                <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1px] shrink-0">
                    <div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-cyan-300">
                        VILA
                    </div>
                </div>
                <div class="glass-card rounded-2xl rounded-tl-none p-4 text-xs font-mono text-cyan-300 border border-purple-500/20 flex items-center gap-3">
                    <i class="fa-solid fa-circle-notch fa-spin text-neon-violet"></i>
                    <span>VILA đang vâng lệnh Master & xử lý yêu cầu...</span>
                </div>
            `;
            chatBox.appendChild(div);
            scrollToBottom();
            return id;
        }

        function appendErrorMessage(msg) {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return;
            const div = document.createElement('div');
            div.className = "flex gap-4 items-start";
            div.innerHTML = `
                <div class="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 shrink-0 flex items-center justify-center text-rose-400">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div class="bg-rose-950/40 border border-rose-500/30 text-rose-300 rounded-2xl p-4 text-xs font-mono leading-relaxed">
                    ${escapeHtml(msg)}
                </div>
            `;
            chatBox.appendChild(div);
            scrollToBottom();
        }

        function removeMessage(id) {
            const el = document.getElementById(id);
            if (el) el.remove();
        }

        function formatMarkdownText(text) {
            return text.replace(/```(html|css|js|javascript|json|python|py|txt|md|xml|svg|csv)?([\s\S]*?)```/gi, (match, lang, code) => {
                const codeId = 'code_' + Math.random().toString(36).substring(2, 10);
                const safeCode = escapeHtml(code.trim());
                const normalized = (lang || 'txt').toLowerCase();
                const ext = ({
                    javascript:'js', python:'py'
                })[normalized] || normalized;

                return `
                    <div class="my-3 rounded-xl bg-dark-base border border-white/10 overflow-hidden font-mono text-xs shadow-xl">
                        <div class="bg-dark-surface/90 px-3 py-2 border-b border-white/10 flex items-center justify-between text-gray-400 text-[11px]">
                            <span class="font-bold text-cyan-400 uppercase">${escapeHtml(ext || 'CODE')}</span>
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="copyCodeToClipboard('${codeId}')" class="hover:text-white flex items-center gap-1 transition-all" title="Sao chép">
                                    <i class="fa-regular fa-copy"></i> Sao chép
                                </button>
                                <button type="button" onclick="downloadCodeBlock('${codeId}','${escapeHtml(ext || 'txt')}')" class="hover:text-cyan-300 flex items-center gap-1 transition-all" title="Tải thành file">
                                    <i class="fa-solid fa-download"></i> File
                                </button>
                            </div>
                        </div>
                        <pre class="p-4 overflow-x-auto text-cyan-200 leading-relaxed"><code id="${codeId}">${safeCode}</code></pre>
                    </div>
                `;
            }).replace(/\n/g, '<br>');
        }

        window.downloadCodeBlock = function(elementId, ext) {
            const el = document.getElementById(elementId);
            if (!el) return;
            const cleanExt = String(ext || 'txt').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'txt';
            const mime = cleanExt === 'html' ? 'text/html' :
                         cleanExt === 'css' ? 'text/css' :
                         cleanExt === 'js' ? 'text/javascript' :
                         cleanExt === 'json' ? 'application/json' : 'text/plain';
            downloadTextFile(el.innerText, `VILA_${Date.now()}.${cleanExt}`, mime);
        };

        window.copyCodeToClipboard = function(elementId) {
            const codeEl = document.getElementById(elementId);
            if (!codeEl) return;
            
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(codeEl.innerText).then(() => {
                    showToast('Đã sao chép mã thành công!', 'success');
                }).catch(err => {
                    fallbackCopy(codeEl.innerText);
                });
            } else {
                fallbackCopy(codeEl.innerText);
            }
        }

        function fallbackCopy(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                showToast('Đã sao chép mã thành công!', 'success');
            } catch (err) {
                showToast('Không thể sao chép!', 'error');
            }
            document.body.removeChild(textarea);
        }

        function autoResizeTextarea(el) {
            el.style.height = 'auto';
            el.style.height = (el.scrollHeight) + 'px';
            const counter = document.getElementById('charCounter');
            if(counter) counter.innerText = `${el.value.length} ký tự`;
        }

        function handleKeyDown(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleChatSubmit();
            }
        }

        function scrollToBottom() {
            const chatBox = document.getElementById('chatMessages');
            if(chatBox) chatBox.scrollTop = chatBox.scrollHeight;
        }

        function getCurrentTime() {
            const d = new Date();
            return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        function escapeHtml(str) {
            return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }

        /* Viewport Switching */
        window.setViewport = function(type) {
            const container = document.getElementById('viewportContainer');
            if(!container) return;
            const btns = document.querySelectorAll('.vp-btn');
            btns.forEach(b => { b.classList.remove('bg-white/10', 'text-white'); b.classList.add('text-gray-400'); });
            const activeBtn = document.getElementById(`vp-${type}`);
            if (activeBtn) { activeBtn.classList.add('bg-white/10', 'text-white'); activeBtn.classList.remove('text-gray-400'); }

            if (type === 'mobile') {
                container.style.width = '375px'; container.style.height = '667px';
            } else if (type === 'tablet') {
                container.style.width = '768px'; container.style.height = '100%';
            } else {
                container.style.width = '100%'; container.style.height = '100%';
            }
        }

        window.toggleFullscreenPreview = function() {
            const previewPanel = document.getElementById('previewPanel');
            if(!previewPanel) return;
            if (!document.fullscreenElement) {
                previewPanel.requestFullscreen().catch(() => showToast('Không thể bật toàn màn hình', 'error'));
            } else {
                document.exitFullscreen();
            }
        }

        window.toggleAppFullscreen = function() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => showToast('Không hỗ trợ toàn màn hình', 'error'));
            } else if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }

        window.openPreviewNewTab = function() {
            if (!latestGeneratedCode) return showToast('Chưa có mã để mở tab mới!', 'info');
            const win = window.open();
            if(win) win.document.write(latestGeneratedCode);
        }

        window.clearChatHistory = function() {
            localStorage.removeItem(MEMORY_KEY);
            localStorage.removeItem(PROJECT_MEMORY_KEY);
            localStorage.removeItem(CODE_MEMORY_KEY);
            latestGeneratedCode = '';
            setupSystemPrompt();
            const chatBox = document.getElementById('chatMessages');
            if(chatBox) {
                chatBox.innerHTML = `
                    <div class="flex gap-4 items-start group">
                        <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1px] shrink-0 shadow-md">
                            <div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-cyan-300">
                                VILA
                            </div>
                        </div>
                        <div class="flex-1 space-y-2">
                            <div class="glass-card rounded-2xl rounded-tl-none p-4 text-sm text-gray-200 border border-purple-500/20">
                                <strong>Đã làm sạch bộ nhớ trò chuyện, thưa Master!</strong> Thần VILA AI sẵn sàng nhận mệnh lệnh mới.
                            </div>
                        </div>
                    </div>
                `;
            }
            showToast('Đã xóa lịch sử trò chuyện', 'info');
        }

        /* Settings Modal & API Key Operations */
        window.openSettingsModal = function() {
            applyProviderPreset(activeProvider);
            const modal = document.getElementById('settingsModal');
            const modalContent = document.getElementById('modalContent');
            if(!modal || !modalContent) return;
            modal.classList.remove('opacity-0', 'pointer-events-none');
            modalContent.classList.remove('scale-95');
            modalContent.classList.add('scale-100');
        }

        window.closeSettingsModal = function() {
            const modal = document.getElementById('settingsModal');
            const modalContent = document.getElementById('modalContent');
            if(!modal || !modalContent) return;
            modal.classList.add('opacity-0', 'pointer-events-none');
            modalContent.classList.remove('scale-100');
            modalContent.classList.add('scale-95');
        }

        window.toggleKeyVisibility = function() {
            const input = document.getElementById('apiKeyInput');
            const icon = document.getElementById('eyeIcon');
            if(!input || !icon) return;
            if (input.type === 'password') {
                input.type = 'text'; icon.className = 'fa-solid fa-eye-slash';
            } else {
                input.type = 'password'; icon.className = 'fa-solid fa-eye';
            }
        }

        window.testApiKey = async function() {
            const inputKey = document.getElementById('apiKeyInput');
            const inputBaseUrl = document.getElementById('apiBaseUrlInput');
            if(!inputKey || !inputBaseUrl) return;

            const testKey = inputKey.value.trim();
            const testBaseUrl = inputBaseUrl.value.trim() || PROVIDERS.gemini.baseUrl;

            if (!testKey) return showToast('Chưa nhập Gemini API Key!', 'error');
            showToast('Đang kiểm tra Gemini Key...', 'info');

            try {
                const testModel = currentModel || 'gemini-3.8-flash';
                const res = await fetch(`${testBaseUrl}/chat/completions`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${testKey}`
                    },
                    body: JSON.stringify({
                        model: testModel,
                        messages: [{ role: 'user', content: 'Trả lời OK.' }],
                        max_tokens: 8
                    })
                });

                const data = await res.json();
                if (res.ok) {
                    showToast('Gemini API Key hợp lệ và model FREE hoạt động!', 'success');
                } else {
                    showToast(`Lỗi: ${data?.error?.message || `HTTP ${res.status}`}`, 'error');
                }
            } catch (e) {
                showToast(`Lỗi mạng/CORS: ${e.message || 'Không thể kết nối Gemini'}`, 'error');
            }
        }

        window.saveSettings = function() {
            const inputKey = document.getElementById('apiKeyInput');
            const inputBaseUrl = document.getElementById('apiBaseUrlInput');
            if(!inputKey || !inputBaseUrl) return;

            const keyVal = inputKey.value.trim();
            const baseUrlVal = inputBaseUrl.value.trim();

            localStorage.setItem('vila_provider', 'gemini');

            if (keyVal) {
                activeApiKey = keyVal;
                localStorage.setItem('vila_api_key', activeApiKey);
            } else {
                activeApiKey = PROVIDERS[activeProvider].defaultKey || '';
                localStorage.removeItem('vila_api_key');
            }

            if (baseUrlVal) {
                activeBaseUrl = baseUrlVal;
                localStorage.setItem('vila_base_url', activeBaseUrl);
            } else {
                activeBaseUrl = PROVIDERS[activeProvider].baseUrl;
                localStorage.removeItem('vila_base_url');
            }

            populateModelOptions();
            updateUIState();
            showToast('Đã lưu cấu hình máy chủ & API Key!', 'success');
            setTimeout(refreshAvailableModels, 150);
            closeSettingsModal();
        }

        /* Toast System */
        function showToast(message, type = 'info') {
            const container = document.getElementById('toastContainer');
            if(!container) return;
            const toast = document.createElement('div');
            
            let bgStyle = 'glass-card border-purple-500/30 text-purple-200';
            let icon = 'fa-circle-info text-neon-violet';

            if (type === 'success') {
                bgStyle = 'glass-card border-emerald-500/40 text-emerald-200';
                icon = 'fa-circle-check text-emerald-400';
            } else if (type === 'error') {
                bgStyle = 'glass-card border-rose-500/40 text-rose-200';
                icon = 'fa-triangle-exclamation text-rose-400';
            }

            toast.className = `flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold shadow-2xl backdrop-blur-xl border transition-all duration-300 transform translate-y-4 opacity-0 ${bgStyle}`;
            toast.innerHTML = `<i class="fa-solid ${icon} text-sm"></i><span>${escapeHtml(message)}</span>`;

            container.appendChild(toast);
            setTimeout(() => toast.classList.remove('translate-y-4', 'opacity-0'), 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-4');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }
    
        // VILA Account: Firebase cloud auth when configured, local profile fallback otherwise.
        let vilaAuth = null;
        function firebaseReady(){ return !!(window.firebase && window.VILA_FIREBASE_CONFIG && window.VILA_FIREBASE_CONFIG.apiKey); }
        function initVilaAuth(){
          try{
            if(firebaseReady()){
              if(!firebase.apps.length) firebase.initializeApp(window.VILA_FIREBASE_CONFIG);
              vilaAuth=firebase.auth();
              vilaAuth.onAuthStateChanged(u=>updateAccountUI(u));
            } else updateAccountUI(null);
          }catch(e){ console.warn('Firebase auth unavailable',e); updateAccountUI(null); }
        }
        function updateAccountUI(user){
          const el=document.getElementById('accountStatus'); if(!el) return;
          const local=JSON.parse(localStorage.getItem('vila_local_account')||'null');
          if(user) el.innerHTML=`Đã đăng nhập: <b>${escapeHtml(user.email||user.displayName||'Google')}</b>`;
          else if(local) el.innerHTML=`Tài khoản thiết bị: <b>${escapeHtml(local.email||local.name||'VILA User')}</b>`;
          else el.textContent='Chưa đăng nhập';
        }
        window.openAccountModal=()=>{ const m=document.getElementById('accountModal'); if(m){m.classList.remove('opacity-0','pointer-events-none'); updateAccountUI(vilaAuth?.currentUser||null);} };
        window.closeAccountModal=()=>{ const m=document.getElementById('accountModal'); if(m){m.classList.add('opacity-0','pointer-events-none');} };
        window.emailRegister=async()=>{
          const email=document.getElementById('accountEmail')?.value.trim(); const pw=document.getElementById('accountPassword')?.value;
          if(!email||!pw) return showToast('Nhập email và mật khẩu.','error');
          if(vilaAuth){ try{await vilaAuth.createUserWithEmailAndPassword(email,pw); showToast('Tạo tài khoản thành công.','success'); return;}catch(e){return showToast(e.message||'Không tạo được tài khoản.','error');} }
          localStorage.setItem('vila_local_account',JSON.stringify({email,createdAt:Date.now()})); updateAccountUI(null); showToast('Đã tạo hồ sơ trên thiết bị.','success');
        };
        window.emailLogin=async()=>{
          const email=document.getElementById('accountEmail')?.value.trim(); const pw=document.getElementById('accountPassword')?.value;
          if(!email||!pw) return showToast('Nhập email và mật khẩu.','error');
          if(vilaAuth){ try{await vilaAuth.signInWithEmailAndPassword(email,pw); showToast('Đăng nhập thành công.','success'); return;}catch(e){return showToast(e.message||'Đăng nhập thất bại.','error');} }
          const local=JSON.parse(localStorage.getItem('vila_local_account')||'null');
          if(local?.email===email){ updateAccountUI(null); showToast('Đã đăng nhập hồ sơ thiết bị.','success'); } else showToast('Chưa có hồ sơ này trên thiết bị.','error');
        };
        window.googleLogin=async()=>{
          if(!vilaAuth) return showToast('Google Login cần cấu hình Firebase cho ứng dụng.','info');
          try{ const provider=new firebase.auth.GoogleAuthProvider(); await vilaAuth.signInWithRedirect(provider); }catch(e){ showToast(e.message||'Google Login thất bại.','error'); }
        };
        window.logoutAccount=async()=>{
          try{ if(vilaAuth) await vilaAuth.signOut(); }catch(e){}
          localStorage.removeItem('vila_local_account'); updateAccountUI(null); showToast('Đã đăng xuất.','info');
        };
        initVilaAuth();
        if (activeApiKey) setTimeout(refreshAvailableModels, 400);

        // Long-term project memory: IndexedDB backup in addition to localStorage.
        const VILA_DB='vila_long_memory_v1';
        function vilaDB(){ return new Promise((resolve,reject)=>{ const r=indexedDB.open(VILA_DB,1); r.onupgradeneeded=()=>{ if(!r.result.objectStoreNames.contains('memory')) r.result.createObjectStore('memory'); }; r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error); }); }
        async function saveLongTermMemory(){ try{ const db=await vilaDB(); const tx=db.transaction('memory','readwrite'); tx.objectStore('memory').put({messages:conversationHistory.filter(m=>m.role!=='system').slice(-2000),projectMemory,latestGeneratedCode,savedAt:Date.now()},'main'); }catch(e){ console.warn('IndexedDB memory error',e); } }
        async function restoreLongTermMemory(){ try{ const db=await vilaDB(); const tx=db.transaction('memory','readonly'); const req=tx.objectStore('memory').get('main'); req.onsuccess=()=>{ const d=req.result; if(!d) return; if(!localStorage.getItem(MEMORY_KEY)&&Array.isArray(d.messages)&&d.messages.length){ conversationHistory=d.messages; refreshSystemPrompt(); renderConversationMessages(d.messages); } if(!projectMemory&&d.projectMemory){projectMemory=d.projectMemory; localStorage.setItem(PROJECT_MEMORY_KEY,projectMemory); refreshSystemPrompt();} if(!latestGeneratedCode&&d.latestGeneratedCode) latestGeneratedCode=d.latestGeneratedCode; }; }catch(e){} }
        const _saveConversationMemory=saveConversationMemory;
        saveConversationMemory=function(){ _saveConversationMemory(); saveLongTermMemory(); };
        restoreLongTermMemory();
