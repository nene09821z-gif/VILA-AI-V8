
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        mono: ['Fira Code', 'monospace'],
                    },
                    colors: {
                        brand: {
                            50: '#f0f3ff',
                            100: '#e1e7fe',
                            500: '#6366f1',
                            600: '#4f46e5',
                            900: '#1e1b4b',
                        },
                        neon: {
                            cyan: '#00f2fe',
                            violet: '#a855f7',
                            pink: '#ec4899',
                            green: '#10b981',
                        },
                        dark: {
                            base: '#030712',
                            surface: '#0b0f19',
                            panel: '#111827',
                            border: '#1f2937',
                        }
                    },
                    animation: {
                        'pulse-glow': 'pulseGlow 3s infinite ease-in-out',
                        'float': 'float 6s ease-in-out infinite',
                    },
                    keyframes: {
                        pulseGlow: {
                            '0%, 100%': { opacity: '0.6', filter: 'drop-shadow(0 0 15px rgba(168, 85, 247, 0.4))' },
                            '50%': { opacity: '1', filter: 'drop-shadow(0 0 25px rgba(0, 242, 254, 0.8))' },
                        },
                        float: {
                            '0%, 100%': { transform: 'translateY(0px)' },
                            '50%': { transform: 'translateY(-6px)' },
                        }
                    }
                }
            }
        }
    