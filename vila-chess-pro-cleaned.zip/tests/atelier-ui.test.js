import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('VILA Atelier stylesheet is loaded after legacy layout without replacing interaction modules', () => {
  const main = read('src/main.js');
  assert.match(main, /import '\.\/style\.css';\s*import '\.\/vila-atelier\.css';/);
  assert.ok(fs.existsSync(path.join(root, 'src/vila-atelier.css')));
  assert.match(main, /function renderBoard\(\)/);
  assert.match(main, /function renderPlayView\(\)/);
  assert.match(main, /function renderReviewView\(\)/);
  assert.match(main, /function renderPuzzleView\(\)/);
});

test('Atelier theme provides unified light surfaces, accessible focus and reduced-motion fallback', () => {
  const css = read('src/vila-atelier.css');
  assert.match(css, /--studio-canvas:#f2f4f1/);
  assert.match(css, /--studio-green:#16764f/);
  assert.match(css, /:focus-visible/);
  assert.match(css, /prefers-reduced-motion:reduce/);
  assert.match(css, /color-scheme:light/);
  assert.doesNotMatch(css, /@import\s+url\(/);
});

test('mobile play screen gives the board priority and prevents double navigation/action bars', () => {
  const css = read('src/vila-atelier.css');
  assert.match(css, /\.play-layout,body\.play-screen-active \.play-layout\{grid-template-columns:minmax\(0,1fr\)!important/);
  assert.match(css, /body\.play-screen-active \.bottom-nav\{display:none!important\}/);
  assert.match(css, /env\(safe-area-inset-bottom,0px\)/);
  assert.match(css, /grid-template-columns:repeat\(5,minmax\(0,1fr\)\)!important/);
  assert.match(css, /body\.play-screen-active \.match-action-bar\{position:static!important/);
  assert.match(css, /body\.play-screen-active #app\{padding-bottom:calc\(20px \+ env\(safe-area-inset-bottom,0px\)\)!important\}/);
  assert.match(css, /body\.play-screen-active \.player-card-opponent,body\.play-screen-active \.player-card-self/);
});

test('the full set of app navigation views remains reachable through More and quick navigation', () => {
  const html = read('index.html');
  const main = read('src/main.js');
  for (const view of ['home','play','ranked','lichess','arena','puzzles','openings','coach','games','missions','shop','leaderboard','friends','inbox','history','health','settings']) {
    assert.ok(html.includes(`data-view="${view}"`), `Missing navigation target ${view}`);
  }
  assert.match(main, /\$\$\('\.tab'\)/);
  assert.match(main, /setAttribute\('aria-current', 'page'\)/);
  assert.match(main, /event\.key !== 'Escape'/);
  assert.match(main, /function setView\(view\)/);
});

test('specialist screens share the Atelier light system for analysis, puzzles, history, social and results', () => {
  const css = read('src/vila-atelier.css');
  for (const selector of [
    '.game-review-page .game-review-header',
    '.history-view .page-heading h1',
    '.puzzle-mode-row',
    '.ranked-stat-grid>div',
    '.progression-summary-main',
    '.social-person-row',
    '.top100-row',
    '.result-modal',
  ]) assert.ok(css.includes(selector), `Missing specialist theme selector ${selector}`);
  assert.match(css, /\.game-review-page \.review-actions/);
  assert.match(css, /@media\(max-width:680px\)/);
});

test('release metadata and offline cache keys use v3.46.2', () => {
  assert.equal(JSON.parse(read('package.json')).version, '3.46.2');
  assert.match(read('index.html'), /Atelier Chess v3\.46\.2/);
  assert.match(read('server/index.js'), /version: '3\.46\.2'/);
  assert.match(read('public/sw.js'), /covua-vila-v3\.46\.2/);
  assert.match(read('public/sw.js'), /favicon\.ico\?v=348/);
  assert.match(read('public/sw.js'), /covua-vila-brand-icon\.png\?v=348/, 'the current brand icon is precached for offline startup');
});
