import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { getPremoveLegalMoves, resolveQueuedPremove } from '../src/premove.js';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');
const main = read('../src/main.js');
const css = read('../src/style.css');

function makeMove(from, to, promotion = undefined) {
  return { from, to, ...(promotion ? { promotion } : {}) };
}

test('premove preview switches to the player side and drops expired en-passant rights', () => {
  let previewFen = '';
  let receivedOptions = null;
  class FakeChess {
    constructor(fen) { previewFen = fen; }
    moves(options) { receivedOptions = options; return [makeMove('e2', 'e4')]; }
  }
  const source = { fen: () => 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq e3 0 1' };
  const result = getPremoveLegalMoves(source, 'w', FakeChess, 'e2');
  assert.equal(previewFen.split(' ')[1], 'w');
  assert.equal(previewFen.split(' ')[3], '-');
  assert.deepEqual(receivedOptions, { square: 'e2', verbose: true });
  assert.deepEqual(result, [makeMove('e2', 'e4')]);
});

test('premove validation checks real turn and legal destination, queen is default promotion', () => {
  const legal = [makeMove('e7', 'e8', 'q'), makeMove('e7', 'e8', 'r'), makeMove('a2', 'a4')];
  const chess = { turn: () => 'w', moves: () => legal };
  assert.deepEqual(resolveQueuedPremove(chess, { from: 'e7', to: 'e8' }, 'w'), makeMove('e7', 'e8', 'q'));
  assert.deepEqual(resolveQueuedPremove(chess, { from: 'e7', to: 'e8', promotion: 'n' }, 'w'), null);
  assert.deepEqual(resolveQueuedPremove(chess, { from: 'a2', to: 'a4' }, 'w'), makeMove('a2', 'a4'));
  assert.equal(resolveQueuedPremove({ ...chess, turn: () => 'b' }, { from: 'a2', to: 'a4' }, 'w'), null);
  assert.equal(resolveQueuedPremove(chess, { from: 'a2', to: 'a5' }, 'w'), null);
});

test('board click and drag are wired to premove queuing during bot thinking', () => {
  assert.match(main, /function isPremoveWindow\(\)/);
  assert.match(main, /if \(isPremoveWindow\(\)\) \{ handlePremoveSquareClick\(square\); return; \}/);
  assert.match(main, /const isPremove = isPremoveWindow\(\)/);
  assert.match(main, /if \(state\.isPremove\) queuePremove\(state\.from, to, promotion\)/);
  assert.match(main, /const premovePlayed = executePendingPremove\(\)/);
  assert.match(main, /resolveQueuedPremove\(game, intent, humanColor\)/);
  assert.match(css, /\.square\.premove-from/);
  assert.match(css, /\.square\.premove-to/);
});

test('clock ticker continues charging the actual side to move and clears premoves on flag', () => {
  const start = main.indexOf('function tickClock()');
  const end = main.indexOf('\nfunction creditClockForMove', start);
  const fn = main.slice(start, end);
  assert.match(main, /setInterval\(tickClock, 100\)/);
  assert.match(fn, /const side = game\.turn\(\)/);
  assert.match(fn, /consumeClockTick\(clockState, side, now\)/);
  assert.match(fn, /clockState\.remaining\[side\] = tick\.remainingMs/);
  assert.doesNotMatch(fn, /if \(botThinking\) return/);
  assert.match(fn, /pendingPremove = null/);
  assert.match(fn, /clockFlagged = side/);
});

test('Stockfish failure uses the bounded offline search before the basic emergency move', () => {
  assert.match(main, /function requestOfflineRescueMove\(/);
  assert.match(main, /resolveOfflineSearchBudget\(profile, \{ \.\.\.settings, botMoveTimeMs:/);
  assert.match(main, /botDepth: Math\.max\(30, Number\(settings\.botDepth\) \|\| 30\)/);
  assert.match(main, /chooseAlternateMoveAsync\(fen/);
  assert.match(main, /const fallback = chooseFallbackMove\(\)/);
  assert.match(main, /tickClock\(\);\n    if \(!isCurrentSearch\(\)\) return;/);
});
