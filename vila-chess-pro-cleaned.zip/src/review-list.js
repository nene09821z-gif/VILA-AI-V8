/** Pure helpers for compact, paired move lists in the post-game review UI. */
export function groupReviewedMoves(rows = []) {
  const ordered = (Array.isArray(rows) ? rows : [])
    .filter(row => row && Number.isInteger(Number(row.ply)) && Number(row.ply) > 0)
    .slice()
    .sort((a, b) => Number(a.ply) - Number(b.ply));
  const groups = new Map();
  for (const row of ordered) {
    const moveNumber = Math.max(1, Number(row.moveNumber) || Math.ceil(Number(row.ply) / 2));
    if (!groups.has(moveNumber)) groups.set(moveNumber, { moveNumber, white: null, black: null });
    const group = groups.get(moveNumber);
    const side = row.mover === 'b' ? 'black' : 'white';
    // If imported legacy data has inconsistent move numbers, never overwrite an earlier ply.
    if (!group[side] || Number(row.ply) < Number(group[side].ply)) group[side] = row;
  }
  return [...groups.values()].sort((a, b) => a.moveNumber - b.moveNumber);
}

export function summarizeReviewSide(rows = [], side = 'w') {
  const categories = ['book', 'best', 'excellent', 'good', 'inaccuracy', 'mistake', 'blunder', 'missed-win'];
  const sideRows = (Array.isArray(rows) ? rows : []).filter(row => row?.mover === side && Number(row.ply) > 0);
  const counts = Object.fromEntries(categories.map(key => [key, 0]));
  for (const row of sideRows) {
    const key = row?.judgement?.key;
    if (Object.hasOwn(counts, key)) counts[key] += 1;
  }
  return { side, total: sideRows.length, rated: sideRows.filter(row => row?.judgement?.key && row.judgement.key !== 'unrated').length, counts };
}
