# VILA AI Studio V38 — file workflow, live task progress, reminders

## What changed
- Kept the existing HTML layout, visual style, HTML element IDs, chat controls, and provider configuration UI unchanged.
- Made the existing thinking panel update live through the request lifecycle, with task-specific progress labels for reasoning, code work, research, and general messages. The panel only shows progress states; it does not expose private internal reasoning.
- Improved file selection callback handling in the Android WebView so the selected file callback is registered before launching Android's picker.
- Improved attachment reading: text/source/config files, ZIP project archives, text-based PDFs, DOCX, XLSX, PPTX, images, and videos (videos are sampled into three image frames using the existing video picker utility).
- When the user explicitly asks to edit an attached text/source/config file, VILA imports it into the editable workspace, preserves the original bytes until it is changed, applies only complete file contents returned in the project-edit protocol, and can export the workspace as a ZIP using existing behavior.
- Added a native Android notification on a repeating 12-hour schedule with the requested text: **HÃY TẬN HƯỞNG VILA ĐI NÀO**. The schedule is restored after device reboot. Notification permission must be granted; Android battery-saving policy may delay inexact alarms.
- Bumped Android version to `38.0.0` / version code `44`.
- Added an active GitHub Actions workflow at `.github/workflows/main.yml` while retaining the root `main.yml` source file.

## Validation completed
- JavaScript syntax checked for each inline script and bundled JS asset.
- Android manifest parsed as XML; duplicate HTML IDs checked (none).
- Verified the 17 existing HTML style blocks and 147 static HTML element IDs match the previous V37 source exactly.
- Existing API-key persistence regression test passed.
- Updated source smoke test passed, including V38 file, reasoning-progress, and notification checks.

## Not claimed
- This environment has no configured Android SDK/Gradle installation, so an APK build/install test was not run here.
- Real API requests, provider quotas, Android notification delivery timing on a physical phone, and reading of scanned/image-only PDFs are not verified by offline source checks.
