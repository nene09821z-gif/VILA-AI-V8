'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');
function extractFunction(name) {
  let marker = `async function ${name}(`;
  let start = html.indexOf(marker);
  if (start < 0) { marker = `function ${name}(`; start = html.indexOf(marker); }
  assert.ok(start >= 0, `Missing function ${name}`);
  const brace = html.indexOf('{', start);
  let depth = 0, quote = '', escape = false, template = false;
  for (let i = brace; i < html.length; i++) {
    const c = html[i];
    if (quote) { if (escape) { escape = false; continue; } if (c === '\\') { escape = true; continue; } if (c === quote) quote = ''; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '`') { template = !template; continue; }
    if (template) continue;
    if (c === '{') depth++;
    else if (c === '}' && --depth === 0) return html.slice(start, i + 1);
  }
  throw new Error(`Unbalanced function ${name}`);
}

const entries = {};
const fakeZip = {
  files: {},
  file(name) { return Object.prototype.hasOwnProperty.call(entries, name) ? { async: async () => entries[name] } : null; }
};
let persistCount = 0;
let lastToast = "";
const context = {
  window: { JSZip: { loadAsync: async () => fakeZip } },
  TextDecoder, TextEncoder, Uint8Array,
  MAX_ARCHIVE_FILES: 12000,
  MAX_FILE_CHARS: 8 * 1024 * 1024,
  MAX_FILE_CHARS_UNUSED: 8 * 1024 * 1024,
  MAX_ARCHIVE_EXPANDED_BYTES: 96 * 1024 * 1024,
  cleanFileText: value => String(value ?? '').replace(/\u0000/g, '').replace(/\r/g, '').slice(0, 8 * 1024 * 1024),
  normalizeProjectPath(value) {
    const raw = String(value || '').replace(/\\/g, '/');
    if (!raw || raw.startsWith('/') || /^[a-z]:\//i.test(raw) || raw.split('/').includes('..')) return '';
    return raw.split('/').filter(part => part && part !== '.').join('/');
  },
  isLikelyTextFile(name) { return /\.(txt|md|json|js|ts|py|java|html?|css|xml|ya?ml|csv|sh|sql|gradle)$/i.test(String(name || '')) || !/\.[a-z0-9]{1,12}$/i.test(String(name || '')); },
  projectWorkspace: {}, projectWorkspaceName: '',
  persistProjectWorkspace() { persistCount++; },
  showToast(message) { lastToast = message; },
  console
};
vm.createContext(context);
for (const name of ['decodeVilaXmlText', 'extractVilaXmlText', 'readOfficeZipFile', 'readPlainTextAttachment', 'isEditableAttachmentFileName', 'importAttachedTextFilesToWorkspace']) {
  vm.runInContext(extractFunction(name), context);
}

(async () => {
  entries['xl/sharedStrings.xml'] = '<sst><si><t>Hello</t></si><si><t>world &amp; more</t></si></sst>';
  entries['xl/worksheets/sheet1.xml'] = '<worksheet><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c><c r="C1"><v>7</v></c></row></sheetData></worksheet>';
  fakeZip.files = { 'xl/sharedStrings.xml': { dir: false }, 'xl/worksheets/sheet1.xml': { dir: false } };
  const xlsx = await context.readOfficeZipFile({ arrayBuffer: async () => new ArrayBuffer(0) }, 'xlsx');
  assert.match(xlsx, /Hello\s+world & more\s+7/);

  entries['ppt/slides/slide1.xml'] = '<p:sld><a:t>VILA</a:t><a:t>slides</a:t></p:sld>';
  fakeZip.files = { 'ppt/slides/slide1.xml': { dir: false } };
  const pptx = await context.readOfficeZipFile({ arrayBuffer: async () => new ArrayBuffer(0) }, 'pptx');
  assert.match(pptx, /VILA slides/);

  const plain = await context.readPlainTextAttachment({ arrayBuffer: async () => new TextEncoder().encode('first\nsecond').buffer });
  assert.equal(plain, 'first\nsecond');
  await assert.rejects(
    context.readPlainTextAttachment({ arrayBuffer: async () => new Uint8Array([0, 1, 0, 1, 0, 1, 0, 1]).buffer }),
    /file nhị phân/
  );

  const item = { name: 'app.js', size: 10, kind: 'text', content: 'console.log("ok");', status: 'ready' };
  const imported = context.importAttachedTextFilesToWorkspace([item]);
  assert.equal(imported.has(item), true);
  assert.equal(context.projectWorkspace['app.js'].content, 'console.log("ok");');
  assert.ok(persistCount >= 1);
  assert.match(lastToast, /workspace/);
  console.log('PASS: XLSX/PPTX extraction, text reader, binary guard, and editable single-file workspace import.');
})().catch(error => { console.error(error); process.exit(1); });
