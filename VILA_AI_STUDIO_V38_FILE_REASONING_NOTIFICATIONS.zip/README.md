> **V37 Full Dashboard:** xem [README_V37_KEY_SAVE_CYAN_UI.md](README_V37_KEY_SAVE_CYAN_UI.md) để biết cách lưu API key, Auto model và giao diện xanh neon. Muốn build APK bằng GitHub Actions, xem [README_GITHUB_BUILD_V28.md](README_GITHUB_BUILD_V28.md). ZIP này là mã nguồn, không phải APK đã build.

---

# VILA AI Studio V37 — Full Neon Dashboard & AI Project Workspace

- Gemini 3.8 Flash là model ưu tiên cho code; tác vụ lập trình tự dùng `reasoning_effort=high`.
- Tăng ngân sách output cho code để giảm tình trạng câu trả lời bị cắt giữa file.
- Trên bản V38, Gemini và các provider API key được lưu trong SharedPreferences riêng của ứng dụng, được đọc lại sau khi mở app và không phụ thuộc Android Keystore. Cách này ổn định hơn trên một số thiết bị nhưng không mã hóa key bằng Keystore; xóa dữ liệu hoặc gỡ ứng dụng sẽ xóa key.
- Gửi ZIP tạo **Project Workspace**: đọc cây file, giữ file binary, giữ nguyên file không sửa và cho AI sửa trực tiếp các file cần thiết.
- AI Code Pro dùng giao thức `<file path="...">FULL CONTENT</file>` / `<delete path="..."/>`, tránh `...`, TODO hoặc placeholder.
- Có kiểm tra nhanh JavaScript/JSON và JavaScript trong HTML trước khi xuất ZIP.
- Xuất lại ZIP giữ toàn bộ project gốc, không còn chỉ đóng gói một file `generated.*`.
- Không tuyên bố build thành công nếu chưa chạy Gradle/build thật; kiểm tra tĩnh chỉ là lớp bảo vệ bổ sung.
- Web search, ảnh, PDF, DOCX, video/Veo và các chức năng Gemini hiện có được giữ nguyên.

## Lưu ý về API key

Key không thể tồn tại sau khi người dùng gỡ app hoặc xóa dữ liệu ứng dụng. Bản V38 dùng SharedPreferences riêng của app để key vẫn được nạp lại sau khi mở app; key không được mã hóa bằng Android Keystore, vì vậy chỉ nên dùng trên thiết bị đáng tin cậy.


## V23 Agent mode
V23 adds an optional `server/` Agent Server. It can keep `GEMINI_API_KEY` off the APK, stream Gemini responses, build uploaded Android ZIPs, return compiler logs and APKs, and support an automatic repair loop. Configure the Agent Server URL in VILA Settings.

For real builds set `ALLOW_UNTRUSTED_BUILDS=true` only on a trusted/isolated server. Also set `VILA_SERVER_TOKEN` and use HTTPS/reverse proxy for remote access.

## V38 additions
See `CHANGELOG_V38_FILE_REASONING_NOTIFICATIONS.md` for the file-reading/editing workflow, live task progress, and native 12-hour reminder details. The interface layout and existing element IDs are preserved. The inexact Android reminder may be delayed by battery optimization and requires notification permission.
