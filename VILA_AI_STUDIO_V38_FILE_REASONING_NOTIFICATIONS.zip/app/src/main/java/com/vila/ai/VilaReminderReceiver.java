package com.vila.ai;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Native 12-hour VILA reminder. Uses an inexact repeating alarm to respect Android battery rules. */
public final class VilaReminderReceiver extends BroadcastReceiver {
    private static final String ACTION_REMINDER = "com.vila.ai.action.REMINDER_12H";
    private static final String CHANNEL_ID = "vila_reminder_channel";
    private static final int REQUEST_CODE = 3812;
    private static final int NOTIFICATION_ID = 3812;
    private static final long INTERVAL_MS = 12L * 60L * 60L * 1000L;

    static void schedule(Context context) {
        schedule(context, false);
    }

    private static void schedule(Context context, boolean force) {
        Context app = context.getApplicationContext();
        createChannel(app);
        Intent intent = new Intent(app, VilaReminderReceiver.class).setAction(ACTION_REMINDER);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent existing = PendingIntent.getBroadcast(app, REQUEST_CODE, intent, PendingIntent.FLAG_NO_CREATE | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        if (existing != null && !force) return;
        PendingIntent pending = PendingIntent.getBroadcast(app, REQUEST_CODE, intent, flags);
        AlarmManager alarms = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        long first = System.currentTimeMillis() + INTERVAL_MS;
        alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, INTERVAL_MS, pending);
    }

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : String.valueOf(intent.getAction());
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            schedule(context, true);
            return;
        }
        if (!ACTION_REMINDER.equals(action)) return;
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent openApp = null;
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            openApp = PendingIntent.getActivity(context, REQUEST_CODE, launch, flags);
        }
        String message = "HÃY TẬN HƯỞNG VILA ĐI NÀO";
        String expanded = message + " ✨\nTiếp tục trò chuyện, khám phá ý tưởng và sáng tạo cùng VILA.";
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, CHANNEL_ID)
            : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("VILA AI Studio")
            .setContentText(message)
            .setStyle(new Notification.BigTextStyle().bigText(expanded))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
            .setOnlyAlertOnce(false);
        if (openApp != null) builder.setContentIntent(openApp);
        manager.notify(NOTIFICATION_ID, builder.build());
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Nhắc nhở VILA", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("Nhắc bạn tận hưởng và tiếp tục sáng tạo cùng VILA sau mỗi 12 giờ.");
        channel.enableVibration(true);
        manager.createNotificationChannel(channel);
    }
}
