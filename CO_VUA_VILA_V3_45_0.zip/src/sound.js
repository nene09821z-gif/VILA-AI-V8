import { playYoutube, stopYoutube, onYoutubeError } from './youtube-music.js';
let audioContext = null;
function getAudioContext() {
  if (typeof window === 'undefined') return null;
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  try { audioContext ||= new Ctor(); return audioContext; } catch { return null; }
}
export function unlockBoardSound() {
  const ctx = getAudioContext();
  if (!ctx) return false;
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return true;
}
/** Pure classifier (unit-testable): which sound a move should make. */
export function soundKindForMove(move, chess) {
  if (!move) return null;
  const flags = String(move.flags || '');
  if (chess?.isCheckmate?.()) return 'checkmate';
  if (chess?.isCheck?.()) return 'check';
  if (move.promotion || flags.includes('p')) return 'promote';
  if (flags.includes('k') || flags.includes('q')) return 'castle';
  if (move.captured || flags.includes('c') || flags.includes('e')) return 'capture';
  return 'move';
}

let noiseBuffer = null;
function getNoiseBuffer(ctx) {
  if (noiseBuffer && noiseBuffer.sampleRate === ctx.sampleRate) return noiseBuffer;
  const length = Math.floor(ctx.sampleRate * 0.12);
  noiseBuffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = noiseBuffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  return noiseBuffer;
}
// A short filtered-noise "wood tap" plus a low sine thump: reads like a piece set on a board.
function woodTap(ctx, at, { volume = 0.16, pitch = 170, brightness = 1400 } = {}) {
  const noise = ctx.createBufferSource();
  noise.buffer = getNoiseBuffer(ctx);
  const filter = ctx.createBiquadFilter();
  filter.type = 'bandpass'; filter.frequency.setValueAtTime(brightness, at); filter.Q.setValueAtTime(0.9, at);
  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(volume, at);
  noiseGain.gain.exponentialRampToValueAtTime(0.0001, at + 0.07);
  noise.connect(filter); filter.connect(noiseGain); noiseGain.connect(ctx.destination);
  noise.start(at); noise.stop(at + 0.09);
  const thump = ctx.createOscillator();
  const thumpGain = ctx.createGain();
  thump.type = 'sine';
  thump.frequency.setValueAtTime(pitch * 1.6, at);
  thump.frequency.exponentialRampToValueAtTime(pitch, at + 0.05);
  thumpGain.gain.setValueAtTime(volume * 0.9, at);
  thumpGain.gain.exponentialRampToValueAtTime(0.0001, at + 0.09);
  thump.connect(thumpGain); thumpGain.connect(ctx.destination);
  thump.start(at); thump.stop(at + 0.1);
}
function tone(ctx, at, hz, { duration = 0.16, volume = 0.07, type = 'sine' } = {}) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type; osc.frequency.setValueAtTime(hz, at);
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.exponentialRampToValueAtTime(volume, at + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(at); osc.stop(at + duration + 0.02);
}
function withContext(play) {
  const ctx = getAudioContext();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    play(ctx, ctx.currentTime);
    return true;
  } catch { return false; }
}

export function playBoardSound(move, chess, enabled = true) {
  if (!enabled || !move) return false;
  const kind = soundKindForMove(move, chess);
  return withContext((ctx, now) => {
    if (kind === 'checkmate') {
      woodTap(ctx, now, { volume: 0.2, pitch: 120 });
      [659, 523, 392, 262].forEach((hz, i) => tone(ctx, now + 0.12 + i * 0.1, hz, { duration: 0.22, volume: 0.06, type: 'triangle' }));
    } else if (kind === 'check') {
      woodTap(ctx, now, { volume: 0.17, pitch: 150, brightness: 1800 });
      tone(ctx, now + 0.07, 880, { duration: 0.14, volume: 0.06 });
      tone(ctx, now + 0.16, 1175, { duration: 0.2, volume: 0.055 });
    } else if (kind === 'promote') {
      woodTap(ctx, now, { volume: 0.14 });
      [523, 659, 784, 1047].forEach((hz, i) => tone(ctx, now + 0.05 + i * 0.06, hz, { duration: 0.16, volume: 0.05 }));
    } else if (kind === 'castle') {
      woodTap(ctx, now, { volume: 0.13, pitch: 190 });
      woodTap(ctx, now + 0.11, { volume: 0.15, pitch: 160 });
    } else if (kind === 'capture') {
      woodTap(ctx, now, { volume: 0.24, pitch: 135, brightness: 1100 });
      woodTap(ctx, now + 0.045, { volume: 0.12, pitch: 210, brightness: 2000 });
    } else {
      woodTap(ctx, now, { volume: 0.15 });
    }
  });
}

/** Non-move sounds: game start/end, flag, illegal move, low-time tick, notification. Fully synthesized (works offline). */
export function playGameSound(kind, enabled = true) {
  if (!enabled || !kind) return false;
  return withContext((ctx, now) => {
    switch (kind) {
      case 'start': [392, 523, 659].forEach((hz, i) => tone(ctx, now + i * 0.09, hz, { duration: 0.2, volume: 0.055 })); break;
      case 'win': [523, 659, 784, 1047].forEach((hz, i) => tone(ctx, now + i * 0.12, hz, { duration: 0.3, volume: 0.06, type: 'triangle' })); break;
      case 'lose': [392, 349, 311, 262].forEach((hz, i) => tone(ctx, now + i * 0.14, hz, { duration: 0.32, volume: 0.055, type: 'triangle' })); break;
      case 'draw': [440, 440].forEach((hz, i) => tone(ctx, now + i * 0.16, hz, { duration: 0.24, volume: 0.05 })); break;
      case 'flag': tone(ctx, now, 220, { duration: 0.5, volume: 0.07, type: 'sawtooth' }); tone(ctx, now + 0.02, 330, { duration: 0.5, volume: 0.03, type: 'square' }); break;
      case 'illegal': tone(ctx, now, 160, { duration: 0.12, volume: 0.06, type: 'square' }); tone(ctx, now + 0.1, 140, { duration: 0.16, volume: 0.05, type: 'square' }); break;
      case 'lowtime': tone(ctx, now, 1000, { duration: 0.07, volume: 0.04 }); break;
      case 'notify': tone(ctx, now, 740, { duration: 0.12, volume: 0.045 }); tone(ctx, now + 0.1, 988, { duration: 0.16, volume: 0.045 }); break;
      default: break;
    }
  });
}


// Optional online piano recording: Gymnopedie No. 1, performed by Kevin MacLeod.
// Audio is only requested after the player presses the music button; a generated
// ambient fallback remains available offline or when a WebView blocks the URL.
const CLASSICAL_MUSIC_URL = 'https://upload.wikimedia.org/wikipedia/commons/2/2a/Gymnopedie_No._1_%28ISRC_USUAN1100787%29.mp3';
let musicAudio = null;
let musicTimer = null;
let musicStep = 0;
let musicEnabled = false;
let synthMusicActive = false;
const MUSIC_TRACK_KEY = 'vila.chess.music-track.v1';
const MUSIC_TRACKS = Object.freeze({
  ambient: { name: 'Piano ambient', melody: [392,493.88,587.33,493.88,440,523.25,659.25,523.25,349.23,440,523.25,440,329.63,392,493.88,392,293.66,369.99,440,369.99,329.63,392,493.88,392,261.63,329.63,392,329.63,293.66,349.23,440,349.23], roots: [130.81,146.83,110,123.47,98,110,87.31,98], interval: 780, leadType: 'sine', volume: 0.012 },
  lofi: { name: 'Lo-fi nhẹ', melody: [261.63,329.63,392,329.63,293.66,349.23,440,349.23,220,261.63,329.63,261.63,196,246.94,293.66,246.94], roots: [98,110,130.81,87.31], interval: 960, leadType: 'triangle', volume: 0.010 },
  epic: { name: 'Đấu trường', melody: [392,392,523.25,587.33,659.25,587.33,523.25,392,349.23,349.23,440,523.25,587.33,523.25,440,349.23], roots: [98,110,82.41,87.31], interval: 700, leadType: 'triangle', volume: 0.011 },
  medieval: { name: 'Trung cổ', melody: [293.66,349.23,392,440,392,349.23,293.66,261.63,293.66,392,440,523.25,440,392,349.23,293.66], roots: [73.42,87.31,98,82.41], interval: 900, leadType: 'sine', volume: 0.011 },
  classical: { name: 'Gymnopédie (internet)', external: true, interval: 780, melody: [], roots: [] }
});
let selectedMusicTrack = (() => { try { const saved = localStorage.getItem(MUSIC_TRACK_KEY); return Object.hasOwn(MUSIC_TRACKS, saved) ? saved : 'ambient'; } catch { return 'ambient'; } })();
const melody = [
  392.00, 493.88, 587.33, 493.88, 440.00, 523.25, 659.25, 523.25,
  349.23, 440.00, 523.25, 440.00, 329.63, 392.00, 493.88, 392.00,
  293.66, 369.99, 440.00, 369.99, 329.63, 392.00, 493.88, 392.00,
  261.63, 329.63, 392.00, 329.63, 293.66, 349.23, 440.00, 349.23
];
const chordRoots = [130.81, 146.83, 110.00, 123.47, 98.00, 110.00, 87.31, 98.00];
function stopSynthMusic() {
  if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
  synthMusicActive = false;
}
function playAmbientStep() {
  const ctx = getAudioContext();
  if (!ctx || !musicEnabled || !synthMusicActive) return;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    const pattern = MUSIC_TRACKS[selectedMusicTrack] && !MUSIC_TRACKS[selectedMusicTrack].external ? MUSIC_TRACKS[selectedMusicTrack] : MUSIC_TRACKS.ambient;
    const notes = pattern.melody.length ? pattern.melody : melody;
    const roots = pattern.roots.length ? pattern.roots : chordRoots;
    const index = musicStep % notes.length;
    const hz = notes[index];
    // Soft bell-like upper voice, with a long attack/release so it feels musical
    // rather than like the short UI click noises.
    const lead = ctx.createOscillator();
    const leadGain = ctx.createGain();
    const tone = ctx.createBiquadFilter();
    lead.type = pattern.leadType || 'sine'; lead.frequency.setValueAtTime(hz, now);
    tone.type = 'lowpass'; tone.frequency.setValueAtTime(1500, now);
    leadGain.gain.setValueAtTime(0.0001, now);
    leadGain.gain.exponentialRampToValueAtTime(pattern.volume || 0.012, now + 0.16);
    leadGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.28);
    lead.connect(tone); tone.connect(leadGain); leadGain.connect(ctx.destination);
    lead.start(now); lead.stop(now + 1.32);
    // Gentle sustained harmony and fifth, fading between steps.
    if (index % 4 === 0) {
      const root = roots[Math.floor(index / 4) % roots.length];
      [root, root * 1.5].forEach((frequency, voice) => {
        const osc = ctx.createOscillator(); const gain = ctx.createGain();
        osc.type = 'triangle'; osc.frequency.setValueAtTime(frequency, now);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.006 / (voice + 1), now + 0.22);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.2);
        osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 2.25);
      });
    }
    musicStep += 1;
  } catch { /* Web Audio may be blocked by the current WebView/device. */ }
}
function startSynthMusic() {
  if (!musicEnabled || synthMusicActive) return;
  try { musicAudio?.pause(); } catch {}
  synthMusicActive = true;
  playAmbientStep();
  musicTimer = setInterval(playAmbientStep, (MUSIC_TRACKS[selectedMusicTrack] || MUSIC_TRACKS.ambient).interval || 780);
}
function getClassicalAudio() {
  if (musicAudio || typeof window === 'undefined' || typeof window.Audio !== 'function') return musicAudio;
  musicAudio = new window.Audio(CLASSICAL_MUSIC_URL);
  musicAudio.loop = true;
  musicAudio.preload = 'none';
  musicAudio.volume = 0.22;
  musicAudio.addEventListener('error', () => { if (musicEnabled) startSynthMusic(); });
  return musicAudio;
}
let youtubeSource = null;
let youtubeFailureHandler = null;
/** Choose the background track: a parsed YouTube source ({videoId,listId}) or null for the built-in piano. */
export function setChessMusicYoutube(source, { onFailure } = {}) {
  youtubeSource = source && (source.videoId || source.listId) ? { videoId: source.videoId || '', listId: source.listId || '' } : null;
  youtubeFailureHandler = typeof onFailure === 'function' ? onFailure : null;
  if (!youtubeSource) { stopYoutube(); }
  if (musicEnabled) {
    try { musicAudio?.pause(); } catch {}
    stopSynthMusic();
    void startChessMusic();
  }
}
export function getChessMusicYoutube() { return youtubeSource; }
export function getChessMusicTrack() { return selectedMusicTrack; }
export function setChessMusicTrack(track) {
  const next = Object.hasOwn(MUSIC_TRACKS, String(track)) ? String(track) : 'ambient';
  selectedMusicTrack = next;
  try { localStorage.setItem(MUSIC_TRACK_KEY, next); } catch {}
  if (musicEnabled) { try { musicAudio?.pause(); } catch {} stopSynthMusic(); void startChessMusic(); }
  return selectedMusicTrack;
}
export function listChessMusicTracks() { return Object.entries(MUSIC_TRACKS).map(([id, item]) => ({ id, name: item.name, external: Boolean(item.external) })); }
onYoutubeError(error => {
  youtubeSource = null; stopYoutube();
  try { youtubeFailureHandler?.(error); } catch {}
  if (musicEnabled) void startChessMusic();
});

async function startChessMusic() {
  if (musicEnabled && youtubeSource) {
    try {
      stopSynthMusic(); try { musicAudio?.pause(); } catch {}
      await playYoutube(youtubeSource);
      return;
    } catch (error) {
      const had = youtubeSource; youtubeSource = null; stopYoutube();
      if (had) { try { youtubeFailureHandler?.(error); } catch {} }
    }
  }
  if (!musicEnabled) return;
  if (selectedMusicTrack !== 'classical') { startSynthMusic(); return; }
  const audio = getClassicalAudio();
  if (!audio) { startSynthMusic(); return; }
  try {
    stopSynthMusic();
    audio.currentTime = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
    await audio.play();
    synthMusicActive = false;
  } catch { startSynthMusic(); }
}
export function isChessMusicPlaying() { return musicEnabled; }
export function setChessMusicPlaying(enabled) {
  musicEnabled = Boolean(enabled);
  if (!musicEnabled) {
    stopSynthMusic();
    stopYoutube();
    try { if (musicAudio) { musicAudio.pause(); musicAudio.currentTime = 0; } } catch {}
    return false;
  }
  unlockBoardSound();
  void startChessMusic();
  return true;
}
