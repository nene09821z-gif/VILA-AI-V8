import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const html = read('index.html');
const main = read('src/main.js');
const css = read('src/style.css');
const pkg = JSON.parse(read('package.json'));

test('home lobby remains redesigned after the v3.35 migration, not straight on the chessboard', () => {
  assert.equal(pkg.version, '3.45.0');
  assert.match(main, /let currentView = 'home'/);
  assert.doesNotMatch(main, /let currentView = 'play'/);
  assert.match(main, /function renderHomeView\(\)/);
  assert.match(main, /home-feature-grid/);
  assert.match(main, /home-mode-grid/);
  assert.match(main, /home-arena-promo/);
  assert.match(main, /document\.body\.classList\.toggle\('home-screen-active', currentView === 'home'\)/);
  assert.match(main, /class=\"home-quick-modes\"/);
  assert.match(html, /id=\"modeRail\"/);
  assert.match(html, /id=\"bottomNav\"/);
  for (const view of ['home', 'play', 'arena', 'puzzles', 'openings', 'coach', 'games', 'lichess']) assert.ok(html.includes(`data-view=\"${view}\"`), `missing ${view} navigation`);
  assert.ok(css.includes('body.home-screen-active .mode-rail')); 
  assert.match(css, /env\(safe-area-inset-bottom/);
});

test('mini-game screen wires Rubik turns, scramble/undo, touch rotation, 2048, memory cards and sliding puzzle', () => {
  assert.match(main, /function renderGamesView\(\)/);
  assert.match(main, /function wireGamesActions\(\)/);
  for (const selector of ['rubikScramble', 'rubikUndo', 'rubikReset', 'rubikViewToggle', 'game2048Grid', 'memoryRestart', 'slidingPuzzleRestart']) assert.ok(main.includes(`id="${selector}"`), `missing ${selector}`);
  assert.match(main, /stage\.addEventListener\('pointerdown'/);
  assert.match(main, /stage\.addEventListener\('pointerup'/);
  assert.match(main, /data-games-mode="rubik"/);
  assert.match(main, /data-games-mode="2048"/);
  assert.match(main, /data-games-mode="memory"/);
  assert.match(main, /id: 'sliding', icon: '15', label: 'Trượt số'/);
  assert.match(main, /function renderSlidingPuzzleGame\(\)/);
  assert.match(main, /moveSlidingPuzzleTile/);
});

test('puzzle progression loads the next puzzle automatically and continues practice after the daily challenge', () => {
  assert.match(main, /\['classic', 'rush', 'survival', 'daily'\]\.includes\(puzzleState\.playMode\)\) setTimeout/);
  assert.match(main, /puzzleState\.playMode === 'rush' \&\& !puzzleState\.rushActive/);
  assert.match(main, /puzzleState\.playMode === 'survival' \&\& puzzleState\.runLives <= 0/);
  assert.match(main, /if \(puzzleState\.playMode === 'daily'\) puzzleState\.playMode = 'classic'/);
});

test('AI arena keeps real engine labels and does not claim that local style profiles are external engines or measured Elo', () => {
  assert.match(main, /function renderArenaView\(\)/);
  for (const id of ['arenaBoard', 'arenaRunMatch', 'arenaRunLeague', 'arenaStop', 'arenaDownloadPGN', 'arenaDepth', 'arenaSkill']) assert.ok(main.includes(`id="${id}"`), `missing ${id}`);
  assert.match(main, /không phải xếp hạng Elo đã benchmark/);
  assert.match(main, /Stockfish được dùng để tìm nước khi sẵn sàng/);
  assert.match(main, /OFFLINE_ENGINE_CATALOG/);
});
