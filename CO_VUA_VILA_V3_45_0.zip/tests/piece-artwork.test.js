import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const piecesSrc = fs.readFileSync(new URL('../src/pieces.js', import.meta.url), 'utf8');
const pieceStart = main.indexOf('function pieceGlyph(piece) {');
const pieceEnd = main.indexOf('\nfunction squareColor(square)', pieceStart);
const renderer = piecesSrc;

test('All six chess types use the local VILA Royal SVG set, shared by every board', () => {
  assert.ok(pieceStart >= 0 && pieceEnd > pieceStart, 'piece renderer must exist');
  assert.match(main.slice(pieceStart, pieceEnd), /pieceSvgMarkup\(piece\)/, 'pieceGlyph must delegate to the shared set');
  assert.match(main, /from '\.\/pieces\.js'/);
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    assert.match(renderer, new RegExp(`\\n\\s+${type}: \\{`), `missing SVG silhouette for ${type}`);
  }
  assert.match(renderer, /piece-svg-\$\{piece\.type\}/);
  assert.match(renderer, /vp-grad-\$\{color\}/);
  assert.match(renderer, /shape\.body/);
  assert.match(renderer, /shape\.detail/);
  assert.doesNotMatch(renderer, /[♔♕♖♗♘♙♚♛♜♝♞♟]/, 'pieces must not depend on platform chess glyph fonts');
});


test('Captured white and black pieces reuse the selected local image artwork', () => {
  const start = main.indexOf('function renderCapturedMaterial(color)');
  const end = main.indexOf('\nfunction updateCapturedMaterialDisplays', start);
  const fn = main.slice(start, end);
  assert.match(fn, /pieceSvgMarkup\(\{ type, color: victimColor \}\)/);
  assert.match(fn, /captured-white-piece/);
  assert.match(fn, /captured-black-piece/);
  assert.match(css, /\.captured-piece-icon \.piece-svg/);
});


test('Twenty-six local/remote piece styles share twelve piece types and have verified source/license wiring', () => {
  assert.match(renderer, /id: 'neon', label: 'Neon · xanh tím phát sáng'/);
  assert.match(renderer, /id: 'wood', label: 'Gỗ · nâu cổ điển'/);
  for (const style of ['pearl', 'jade', 'ruby', 'graphite', 'emerald', 'gold', 'ice', 'rose', 'obsidian', 'copper', 'amethyst', 'sapphire', 'bronze']) {
    assert.match(renderer, new RegExp(`id: '${style}'`));
    for (const side of ['w', 'b']) assert.ok(renderer.includes(`vp-grad-${style}-${side}`), `missing ${style} ${side} gradient`);
  }
  for (const id of ['vp-grad-neon-w', 'vp-grad-neon-b', 'vp-grad-wood-w', 'vp-grad-wood-b', 'vp-grad-emerald-w', 'vp-grad-emerald-b', 'vp-grad-gold-w', 'vp-grad-gold-b']) {
    assert.ok(renderer.includes(id), `missing ${id}`);
  }
  for (const id of ['vp-grad-neon-w', 'vp-grad-neon-b', 'vp-grad-wood-w', 'vp-grad-wood-b', 'vp-grad-emerald-w', 'vp-grad-emerald-b', 'vp-grad-gold-w', 'vp-grad-gold-b']) {
    assert.ok(fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8').includes(id), `index is missing ${id}`);
  }
  assert.match(renderer, /piece-set-\$\{alternateStyle\}/);
  assert.match(renderer, /PIECE_STYLE_IDS = Object\.freeze\(\['flat', 'royal', 'neon', 'wood', 'pearl', 'jade', 'ruby', 'graphite', 'emerald', 'gold', 'ice', 'rose', 'obsidian', 'copper', 'amethyst', 'sapphire', 'bronze', 'fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx', 'kiwen-suwi', 'firi', 'totoy', 'shapes'\]\)/);
  for (const id of ['fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx', 'kiwen-suwi', 'firi', 'totoy', 'shapes']) assert.match(renderer, new RegExp(`id: '${id}'`));
  const fetcher = fs.readFileSync(new URL('../scripts/fetch-piece-sets.mjs', import.meta.url), 'utf8');
  assert.match(fetcher, /REQUIRE_PIECE_SETS/);
  assert.match(fetcher, /raw\.githubusercontent\.com\/lichess-org\/lila/);
  assert.match(fetcher, /Apache-2\.0/);
  assert.match(fetcher, /CC0-1\.0/);
  assert.match(fetcher, /verified SVG pieces/);
  assert.match(renderer, /id: 'emerald', label: 'Emerald/);
  assert.match(renderer, /id: 'amethyst', label: 'Amethyst/);
  assert.match(renderer, /id: 'sapphire', label: 'Sapphire/);
  assert.match(renderer, /id: 'bronze', label: 'Bronze/);
  assert.match(renderer, /id: 'gold', label: 'Royal Gold/);
});

test('Annotation toolbar is fixed in document flow and has no stale drag position', () => {
  const start = main.indexOf('function wireAnnotationWidget()');
  const end = main.indexOf('\nfunction canStartBoardDrag', start);
  const fn = main.slice(start, end);
  assert.match(fn, /Fixed in-flow toolbar/);
  assert.doesNotMatch(fn, /annotationWidgetGrip|translate3d\(|localStorage\.setItem/);
  assert.match(css, /\.board-annotation-toolbar-row\{position:relative!important/);
  assert.match(css, /\.board-annotation-widget\{position:relative!important;inset:auto!important/);
});

test('Manual annotation color classes match the styles for all three colors', () => {
  assert.match(main, /manual-\$\{mark\.type\}-\$\{mark\.color \|\| 'green'\}/);
  for (const type of ['arrow', 'circle']) {
    for (const color of ['green', 'red', 'yellow']) {
      assert.match(css, new RegExp(`\\.manual-${type}-${color}\\s*\\{`), `missing ${type} ${color} style`);
    }
  }
});

test('Android drawing toolbar avoids background blur and SVG filter shadows', () => {
  const widgetRule = css.match(/\.board-annotation-widget\{[^}]*\}/)?.[0] || '';
  const arrowRule = css.match(/\.manual-arrow\{[^}]*\}/)?.[0] || '';
  const circleRule = css.match(/\.manual-circle\{[^}]*\}/)?.[0] || '';
  const svgRule = css.match(/\.piece-svg\{[^}]*\}/)?.[0] || '';
  assert.ok(widgetRule);
  assert.doesNotMatch(widgetRule, /backdrop-filter/);
  assert.match(arrowRule, /filter:none/);
  assert.match(circleRule, /filter:none/);
  assert.match(svgRule, /filter:none/);
  assert.match(css, /\.board-annotation-widget\{position:relative!important/);
  assert.equal(pkg.version, '3.45.0');
});


test('Default board uses Chess.com-inspired green and cream squares', () => {
  assert.match(css, /--board-light:#eeeed2/);
  assert.match(css, /--board-dark:#769656/);
  assert.match(css, /html\[data-board-theme="classic"\]\{--board-light:#eeeed2;--board-dark:#769656/);
  const daily = fs.readFileSync(new URL('../src/daily-progress.js', import.meta.url), 'utf8');
  assert.match(daily, /name: 'Xanh lá & kem'/);
  assert.match(daily, /colors: \['#eeeed2', '#769656'\]/);
});

test('Green/cream palette and original SVG pieces apply across every existing board renderer', () => {
  for (const selector of ['.chessboard .square.light', '.arena-board .arena-square.light', '.ranked-board .ranked-square.light', '.puzzle-board .puzzle-square.light', '.review-replay-board .review-replay-square.review-light']) {
    assert.ok(css.includes(selector), `missing shared light-square styling for ${selector}`);
  }
  for (const selector of ['.chessboard .square.dark', '.arena-board .arena-square.dark', '.ranked-board .ranked-square.dark', '.puzzle-board .puzzle-square.dark', '.review-replay-board .review-replay-square.review-dark']) {
    assert.ok(css.includes(selector), `missing shared dark-square styling for ${selector}`);
  }
  assert.match(css, /\.chessboard \.piece-svg,\.arena-board \.piece-svg,\.ranked-board \.piece-svg,\.puzzle-board \.piece-svg,\.review-replay-board \.piece-svg/);
  assert.equal(pkg.version, '3.45.0');
});
