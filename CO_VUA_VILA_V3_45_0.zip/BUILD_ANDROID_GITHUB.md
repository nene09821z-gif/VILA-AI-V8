# Build APK Cờ Vua ViLa v3.45.0 bằng GitHub Actions

ZIP `CO_VUA_VILA_V3_45_0.zip` chứa mã nguồn web/Capacitor và workflow Android; **không phải APK**. Giải nén thẳng vào repository để `.github/workflows/` và `package.json` nằm ngay ở thư mục gốc.

## Các bước

1. Giải nén ZIP, tạo repository GitHub rồi đẩy toàn bộ nội dung bên trong lên repository. Không bỏ thư mục `.github/workflows/`.
2. Mở tab **Actions**, chọn **Cờ Vua ViLa Android build**, bấm **Run workflow**; workflow này cũng tự chạy trên push/PR.
3. Runner dùng Node.js 22 và Java 21, cài dependencies, kiểm tra cú pháp, chạy toàn bộ `npm test`, tạo kho khai cuộc, tải bộ quân, kiểm tra Stockfish 19 Lite/Full NNUE/ASM-JS và Stockfish 10 cổ điển cùng giấy phép GPL, build web, sync Capacitor và build `assembleDebug`.
4. Nếu tất cả bước bắt buộc đạt, tải artifact **`covua-vila-debug-apk`** để lấy `app-debug.apk`. `test-report` chứa đầu ra test; `covua-vila-android-gradle-source` là gói nguồn Gradle được sinh khi build.

## Nếu workflow thất bại

- Mở step lỗi đầu tiên và tải artifact `test-report`; không tắt test để ép đóng gói APK.
- Nếu thiếu Stockfish 19 hoặc Stockfish 10/giấy phép GPL, xem log của `scripts/copy-engine.mjs` và tên file trong `public/engine/engine-manifest.json`.
- Nếu lỗi bộ quân/kho khai cuộc, kiểm tra runner có thể lấy dữ liệu từ các URL nguồn được ghi trong mã và `public/piece-sets/CREDITS.md`.
- Nếu lỗi Gradle, xem log các bước `cap sync android`, `verify-android-project.mjs` và `assembleDebug`.

## Build cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

Cần Node 22, Java/Android SDK phù hợp và kết nối mạng để tải package/data khi chưa có cache. Full Stockfish NNUE làm APK lớn hơn Lite đáng kể; auto fallback vẫn được giữ cho WebView không khởi tạo được Full.

## Giới hạn xác minh của bản ZIP

Báo cáo chi tiết ở `TEST_REPORT_V3_45_0.md`: 251/251 test tĩnh, 128/128 tệp JS/MJS qua kiểm tra cú pháp, 9/9 test tập trung đạt. Full suite tại môi trường đóng gói là 253/257; bốn bài không khởi chạy do thiếu `chess.js`/`express` khi npm registry không truy cập được. GitHub Actions sẽ cài dependencies trên runner; chưa xác nhận APK hoặc chạy trực tiếp trên điện thoại cho đến khi workflow và kiểm thử thiết bị hoàn tất.
