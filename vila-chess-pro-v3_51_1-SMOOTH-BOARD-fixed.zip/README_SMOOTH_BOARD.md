# Co Vua ViLa v3.51.1 — Smooth Board

## New
- Distance-based piece slide (160-280ms)
- Premove ghost pieces on target squares
- Drag ghost + drag-over highlight CSS
- board-motion module + tests 5/5
- Fix: premove ghost now fades the queued piece on its destination (v3.51.1 never rendered it)

## Test
npm install
node --test tests/board-motion.test.js
