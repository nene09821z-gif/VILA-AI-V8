# Changelog

## v3.1.0 — Opening safety, provider-aware Free Tier and Arena sound unlock
- Validate the complete selected opening on a temporary board before changing the active game.
- Unlock board sound for Arena league tournaments.
- Detect Free Tier from explicit price/catalog metadata, OpenRouter `:free` IDs, and dated official Gemini/Groq allow-lists.
- Static suite expanded to 62 passing cases; full dependency-backed SAN tests and actual APK/device test are still release gates.

## v3.0.0 — Opening book, board sound, voice hint and AI Coach source
- Adds 71 curated opening lines, weighted Stockfish book moves, sound effects, spoken hints, and API/local Stockfish Coach selection.

---

# Changelog

## v3.1.0 — Opening safety, provider-aware Free Tier and Arena sound
- Validates complete opening lines on a temporary board before changing the active game.
- Unlocks Web Audio for Arena round-robin tournaments.
- Adds documented Free Tier classification for Gemini/Groq model IDs, while retaining explicit `:free` and zero-price metadata handling.
- Updates tests to 62 passing static cases. Full dependency-backed tests and on-device checks remain gates.

## v3.0.0 — Varied opening book, board sound and AI Coach
- Adds 71 opening lines, weighted Stockfish opening selection, generated board sounds, Vietnamese spoken hints and API/Stockfish Coach selection.
- See `CHANGELOG_V3_1.md` for this release's full changes.

---

## v2.9.0 — Android responsive board + Stockfish lifecycle optimization (package/backend 2.9.0)

- Added actual container/viewport-based board sizing for main play and Arena boards, including resize/orientation/visual viewport resync.
- Adjusted landscape sizing to respect the actual remaining viewport height instead of forcing a minimum board size that could overflow very short screens.
- Refined mobile Chess.com-inspired board colors, last-move and legal-target states, piece scale, safe areas, touch feedback, and reduced-motion handling.
- Configure Stockfish Threads/Hash/MultiPV once after UCI handshake; stopped resetting Hash before every move and send `ucinewgame` only on fresh games/rounds.
- Prevent late `readyok` from reviving an engine already marked failed; synchronize `/api/health` version to 2.9.0.
- Added responsive board helper tests and source regression guards; `npm run test:static` passes 55/55.
- Full `npm test`, production/Android build, real Stockfish UCI, live APIs, and OPPO A17k validation remain unverified here because npm dependencies could not be installed in time.

# Changelog

## v2.6.1 — Stability Fix (package version 1.6.1)

- Giữ bản nháp AI Coach khi có yêu cầu khác đang chạy.
- Timeout API dùng chung 90 giây và hỗ trợ abort từ caller.
- Kiểm tra cấu hình trước khi vào chế độ AI; không tự chuyển lỗi cấu hình thành nước đi dự phòng mà không cảnh báo.
- Hủy upstream Lichess đúng cách khi client disconnect.
- Xử lý NDJSON record cuối khi không có newline kết thúc.
- Thêm 5 kiểm tra hồi quy tĩnh.
- Đồng bộ phiên bản `/api/health` và tài liệu.
- Xác minh static 36/36; full tests/build bị giới hạn bởi DNS/npm dependency trong môi trường rà soát.

## v2.6.2 — CI test compatibility fix
- Fixed the en-passant test expectation: `Chess#get()` returns `undefined` for an empty square in chess.js 1.4.0, not `null`.
- Kept the en-passant move sequence and board-state assertions intact; this fixes the incorrect test expectation rather than skipping the test.


## v2.7.0 — Stockfish responsiveness + mobile chess UX (package version 1.7.0)

- Replaced depth-only main move searches with bounded `go movetime` searches and watchdog/fallback handling; move budget is configurable from 500–5000 ms.
- Use conservative Hash allocation (16 MB below 4 GB/unknown WebView memory, otherwise 32 MB); retain single-thread UCI for reliable Android WebView operation.
- Added a three-line Stockfish MultiPV panel with score, depth and SAN variations.
- Added bullet/blitz/rapid local clocks with per-move increments and flag-fall handling.
- Tightened 8×8 board geometry and responsive controls for narrow mobile screens.
- Added provider model discovery endpoint and an actual model dropdown for Gemini, Anthropic and OpenAI-compatible endpoints. Gemini uses `GET /v1beta/models` and `:generateContent`; model IDs come from the selected API key and provider response.
- Added dedicated tests for clocks, UCI MultiPV parsing, and provider URL construction; static suite passes 46/46 in this environment.
- Full chess-rule test and production/Android engine build remain unverified because dependencies and Stockfish JS/WASM assets are not installed locally.

## v1.8.0 — Low-latency AI and reliability
- Added provider-specific, bounded chat payload construction for Gemini, Anthropic, and OpenAI-compatible APIs.
- Reduced AI Coach conversation context to the latest six messages and bounded PGN context to the latest 1,800 characters.
- Reduced default AI Coach output to 384 tokens, temperature to at most 0.5, and request timeout to 30 seconds; API move selection retains its tighter 11-second timeout and Stockfish fallback.
- Added server-side request timeout clamping (3–60 seconds) and explicit 504 timeout responses.
- Added regression tests for provider payload mapping, token limits, and context truncation.

## v1.8.1 — Faster API moves and safer fallback
- Reduced API move output budget to a tiny UCI response (8-token minimum supported by payload builder) and set an 11-second upstream timeout / 12-second client timeout for AI move selection.
- Removed automatic retry after transport/provider failures during AI-vs-AI turns; retry is retained only when a successful model response contains invalid UCI, avoiding doubled wait and API cost.
- On normal AI-vs-player API failure, try a short real Stockfish search first; only use the legal-move heuristic if local engine is unavailable/busy.
- AI Coach is bounded to 700 output tokens with a 45-second provider timeout and a 48-second client timeout.
- Added/updated payload-bound tests; static regression suite passes 49/49. Full chess-rule suite and production build still require dependencies/engine assets unavailable in this environment.
