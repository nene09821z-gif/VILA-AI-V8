# Test report — current source v3.1.0

See `TEST_REPORT_V3_1.md` for the exact test matrix and outstanding release gates.

- `npm run test:static`: **62 passed, 0 failed**.
- Full `npm test`: **62 passed, 1 test module failed to load** because `tests/chess.test.js` imports `chess.js`, which is missing from this environment. This is an environment/dependency blocker, not a successful full-suite result.
- Build, Stockfish WASM/UCI, live provider API and OPPO A17k device checks remain unverified.
