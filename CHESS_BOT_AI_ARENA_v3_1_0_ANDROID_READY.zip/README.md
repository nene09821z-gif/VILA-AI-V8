# Chess Bot AI Arena v3.1.0

Chess Bot là ứng dụng cờ vua ưu tiên điện thoại, với Stockfish 19, đấu trường AI, sách khai cuộc đa dạng, phân tích nhiều biến, AI Coach qua API hoặc Stockfish cục bộ, âm thanh bàn cờ, gợi ý đọc tiếng Việt và kết nối Lichess.

> **Đây là ZIP mã nguồn để build bằng GitHub Actions, không phải APK đã biên dịch.** Build/device validation vẫn là cổng bắt buộc trước khi phát hành.

## Có gì trong v3.1.0

- **Bàn cờ Android responsive:** đo theo CSS pixel và kích thước vùng chứa/viewport thật, phản ứng với xoay màn hình, vùng nhìn thay đổi và màn hình ngang thấp; không nhân DPI vật lý lần hai. Bàn cờ giữ tỷ lệ 1:1, lưới 8×8, tọa độ và các ô chạm lớn.
- **Stockfish 19:** tự chọn Lite/Full single dựa vào khả năng thiết bị, có thể chỉnh Skill/Elo/độ sâu/thời gian. Hash và Threads được cấu hình khi khởi tạo UCI, không đặt lại trước mỗi nước.
- **Sách khai cuộc:** 71 đường SAN mẫu có trọng số, chọn nhánh khác nhau giữa các trận khi có lựa chọn; engine tiếp quản khi hết nhánh hoặc đối thủ đi ngoài sách. Khi tải khai cuộc, toàn bộ chuỗi được thử trên bàn tạm trước khi thay thế ván hiện tại.
- **Âm thanh tùy chọn:** tiếng đi quân, ăn quân, nhập thành, chiếu và chiếu hết được tạo cục bộ bằng Web Audio. Không tải file nhạc bên ngoài. Bật/tắt trong Cài đặt.
- **Gợi ý có hướng dẫn:** Stockfish tạo nước ứng viên, có nút áp dụng gợi ý và nút đọc chỉ dẫn tiếng Việt nếu WebView có giọng đọc tiếng Việt.
- **AI Coach:** chuyển đổi giữa API đã cấu hình (Gemini, Anthropic, OpenAI-compatible, Groq, OpenRouter và các endpoint phù hợp) hoặc Stockfish cục bộ. Phân tích Stockfish hiển thị điểm số và tối đa ba biến thể, không gọi API.
- **Danh sách model động:** tải danh sách model từ endpoint đã cấu hình, không giả lập danh sách. Huy hiệu FREE TIER dựa trên `:free`/giá 0 trong metadata, cùng allow-list có ngày rà soát cho Gemini Free Tier và một số model trong Groq Free Plan. Hạn mức thực tế còn tùy tài khoản, khu vực và cấu hình billing.
- **Các chức năng đang có:** đồng hồ và increment, PGN, thư viện khai cuộc, phân tích MultiPV, hồ sơ đối thủ Arena, đấu vòng tròn, cấu hình endpoint/API và Lichess.

## Build Android bằng GitHub

1. Giải nén toàn bộ ZIP lên thư mục gốc của repository GitHub; giữ cả thư mục ẩn `.github/workflows`.
2. Commit và push lên nhánh `main`.
3. Mở **Actions** và chạy **Build Chess Bot APK**.
4. Chỉ tải APK artifact sau khi workflow xanh; không coi ZIP nguồn là APK.
5. Cài lên máy thử và kiểm tra bàn cờ dọc/ngang, chạm đi quân, phong cấp, undo, âm thanh sau lần chạm đầu tiên, giọng đọc, đa dạng khai cuộc, Stockfish, model API, timeout/fallback và Arena.

Hướng dẫn chi tiết: [`BUILD_ANDROID_GUIDE_V3_1.md`](BUILD_ANDROID_GUIDE_V3_1.md).

## Kiểm thử và giới hạn đã biết

- `npm run test:static`: 62/62 bài đạt trong môi trường hiện tại.
- `node --check` cho các tệp JavaScript/MJS: phải đạt trước đóng gói.
- Bộ luật cờ và xác minh 71 chuỗi SAN có trong `tests/chess.test.js`, nhưng cần cài dependency `chess.js` để chạy.
- Trong môi trường tạo ZIP này, npm registry gặp lỗi DNS `EAI_AGAIN`; vì vậy chưa thể xác nhận `npm test` đầy đủ, `npm run build`, Stockfish WASM/UCI thật, Android `assembleDebug`, API key thật hoặc chạy trực tiếp trên OPPO A17k Android 12/DPI 360.

Xem [`TEST_REPORT_V3_1.md`](TEST_REPORT_V3_1.md), [`AUDIT_REPORT_V3_1.md`](AUDIT_REPORT_V3_1.md) và [`CHANGELOG_V3_1.md`](CHANGELOG_V3_1.md).

## Model/API và chi phí

Model ID luôn được tải từ endpoint khi provider hỗ trợ. OpenRouter được đánh dấu free qua model ID `:free` hoặc metadata giá 0. Gemini/Groq có danh sách free-tier theo tài liệu chính thức đã rà soát ngày 2026-10-16; danh sách này có thể thay đổi và không bảo đảm mọi project đều có cùng quota. Kiểm tra chính sách hiện hành:

- OpenRouter: <https://openrouter.ai/models> và <https://openrouter.ai/pricing/>
- Groq: <https://console.groq.com/docs/models> và <https://console.groq.com/docs/rate-limits>
- Gemini API: <https://ai.google.dev/gemini-api/docs/pricing>

Không commit API key lên GitHub công khai. Nếu triển khai backend công khai, bật HTTPS và cấu hình `TUBOR_ACCESS_TOKEN` mạnh.
