# Source audit — current source v3.1.0

Read `AUDIT_REPORT_V3_1.md` for the detailed source review.

The release includes 71 opening lines, transactional opening loading, varied Stockfish book moves, responsive mobile board sizing, generated board SFX, Vietnamese spoken hints, API/Stockfish Coach source selection, current provider model discovery and provider-aware Free Tier labels. Static suite is 62/62. Full SAN legality, APK build, live API and OPPO A17k validation remain outstanding.
