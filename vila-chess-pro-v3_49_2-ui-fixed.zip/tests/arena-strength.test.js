import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { resolveArenaMoveTimeMs, resolveArenaSearchSettings, resolveArenaStyleTolerance } from '../src/arena-strength.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('arena uses one bounded move-time policy for all engine profiles', () => {
  assert.equal(resolveArenaMoveTimeMs(8), 1200);
  assert.equal(resolveArenaMoveTimeMs(12), 1320);
  assert.equal(resolveArenaMoveTimeMs(20), 2200);
  assert.equal(resolveArenaMoveTimeMs(30), 3300);
  assert.equal(resolveArenaMoveTimeMs(999), 3300);
  assert.equal(resolveArenaMoveTimeMs('not-a-number'), 3300);
});

test('arena default is full-strength and shared search settings are normalized', () => {
  assert.deepEqual(resolveArenaSearchSettings(), {
    depth: 30, skill: 20, strengthMode: 'max', elo: 2600, moveTimeMs: 3300, multiPv: 4,
  });
  assert.deepEqual(resolveArenaSearchSettings({ depth: 999, skill: -12, strengthMode: 'elo', elo: 9999 }), {
    depth: 30, skill: 0, strengthMode: 'elo', elo: 3200, moveTimeMs: 3300, multiPv: 4,
  });
});

test('arena styles can only select a near-best line and no longer receive a rookie/mentor strength handicap', () => {
  for (const profile of ['classic', 'rookie', 'mentor', 'berserk', 'chaos', 'ethereal']) {
    assert.equal(resolveArenaStyleTolerance(profile), 18);
  }
  const start = main.indexOf('async function chooseArenaUci');
  const end = main.indexOf('function getArenaOutcome', start);
  const choose = main.slice(start, end);
  assert.doesNotMatch(choose, /profile === 'mentor' \? Math\.min\(5, skill\)/);
  assert.doesNotMatch(choose, /profile === 'rookie' \? Math\.min\(10, skill\)/);
  assert.match(choose, /const moveTimeMs = Number\(options\.moveTimeMs\) \|\| resolveArenaMoveTimeMs\(depth\)/);
  assert.match(choose, /strengthMode: options\.strengthMode \|\| 'max'/);
  assert.match(choose, /multiPv: 4/);
  // v3.49: each contestant consults its own four-line repertoire; the shared book is no longer used here.
  assert.match(choose, /pickPersonaBookMove\(chess, profile, OPENINGS, \{ recentChoices: arenaOpeningChoices \}\)/);
  assert.doesNotMatch(choose, /findOpeningBookMove\(chess, OPENINGS/);
});

test('arena copy explains equal budgets and keeps full strength selected by default', () => {
  assert.match(main, /Mặc định thi đấu tối đa: mọi bot dùng chung độ sâu, thời gian suy nghĩ và Skill Level/);
  assert.match(main, /option value="max" selected>Tối đa · công bằng/);
  assert.match(main, /resolveArenaSearchSettings\(/);
});

test('every bot repertoire resolves to exactly four catalogue openings and the UI copy no longer claims a shared book', async () => {
  const { OPENINGS } = await import('../src/openings.js');
  const { BOT_REPERTOIRES, repertoireLines } = await import('../src/bot-personas.js');
  for (const id of Object.keys(BOT_REPERTOIRES)) {
    assert.equal(repertoireLines(OPENINGS, id).length, 4, `${id} must resolve four opening lines`);
  }
  assert.doesNotMatch(main, /Mọi bot dùng chung sách khai cuộc/);
  assert.match(main, /Mỗi bot có kho 4 khai cuộc riêng/);
});
