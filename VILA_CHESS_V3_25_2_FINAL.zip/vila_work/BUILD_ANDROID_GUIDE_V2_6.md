> **Lưu ý:** Hướng dẫn lịch sử. Với mã nguồn v2.9.0, dùng [`BUILD_ANDROID_GUIDE_V2_9.md`](BUILD_ANDROID_GUIDE_V2_9.md) để tránh nhầm phiên bản.

# Chess Bot v2.6 — cách lấy gói Android Gradle có đủ tệp

**Quan trọng:** `CHESS_BOT_AI_ARENA_v2_6.zip` là ZIP mã nguồn web/Capacitor đầu vào. Nó chưa có `android/settings.gradle` hay `android/gradlew`; không thể đưa trực tiếp ZIP này vào một công cụ chỉ nhận dự án Gradle.

Workflow GitHub Actions mới sẽ tạo dự án Android bằng Capacitor trước, kiểm tra Gradle wrapper, rồi xuất hai artifact:

- `chess-bot-debug-apk`: APK debug để cài thử.
- `chess-bot-android-gradle-source`: ZIP mã nguồn Android đã tạo, gồm `android/settings.gradle`, `android/gradlew`, `android/gradle/wrapper/gradle-wrapper.jar`, `android/gradle/wrapper/gradle-wrapper.properties`, `android/app/build.gradle`, tài nguyên web đã đồng bộ và module native `node_modules/@capacitor/android` được `settings.gradle` tham chiếu.

## Các bước trên điện thoại

1. Tạo một repository GitHub mới hoặc mở repository đang dùng.
2. Tạo file `.github/workflows/build-from-zip.yml` bằng nội dung file cùng tên bên trong ZIP này, rồi commit vào nhánh `main`.
3. Tải `CHESS_BOT_AI_ARENA_v2_6.zip` lên thư mục gốc repository và commit.
4. Mở tab **Actions** → chọn workflow **Build Android from uploaded ZIP** → mở lần chạy mới nhất.
5. Khi bước đóng gói `chess-bot-android-gradle-source` hoàn tất, mở mục **Artifacts** ở cuối trang và tải ZIP có tên `chess-bot-android-gradle-source`. Tải `chess-bot-debug-apk` nếu cần cài APK.

ZIP Gradle được xuất trước bước `assembleDebug`, vì vậy nếu bước build APK thất bại thì mã nguồn Gradle vẫn có thể tải được để xem log/sửa tiếp. Nếu workflow thất bại trước khi hoàn tất bước đóng gói, cần xem lỗi đầu tiên ở `npm install`, `npm test`, `npm run build` hoặc `Capacitor sync`.

Gói Gradle có wrapper thật, nhưng môi trường build vẫn cần Android SDK phù hợp và kết nối mạng để tải Gradle/Android dependencies. APK do workflow tạo là bản **debug**, chưa phải bản release ký số để phát hành cửa hàng.
