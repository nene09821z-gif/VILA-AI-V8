# VILA Chess v3.6.0 — Home Dashboard Refresh

## Visible product changes
- App opens on a new VILA Chess home dashboard instead of placing the user directly on the chessboard.
- Adds primary quick-play flow against Stockfish and direct cards for Play Setup, AI Arena, AI Coach, Opening Library, local Elo/Leaderboard, Lichess, and Settings.
- Rebrands the visible header, assistant label, and Android launcher label to VILA Chess while keeping the existing application ID and game functions.
- Shows local Elo, W/D/L, win rate, selected AI model, and clear notice that local Elo is not an online shared leaderboard.
- Adds responsive home hero, chessboard motif, feature cards, and Android small-screen layouts; the existing play board and tool logic remain in place.

## Existing stability improvements retained
- Keeps the v3.5.0 engine-search serialization, stale FEN/session guards, stop watchdog, analysis result retention, and unit tests.

## Verification notes
- Static tests and syntax checks are included. This release still requires dependency-backed npm test/build and Android/WebView device testing with installed Stockfish assets before it can be described as fully verified.
