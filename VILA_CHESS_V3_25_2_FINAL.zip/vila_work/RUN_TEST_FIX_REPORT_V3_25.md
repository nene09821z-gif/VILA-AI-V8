# VILA Chess V3.25 — Run Test Repair Report

## Repairs applied

1. **Removed unintended random move selection from deterministic engine profiles.** `search-core.js` previously defaulted to a 9-centipawn variation window for normal-strength profiles even when `randomTop` was 1 or absent. Variation now defaults to zero unless the engine/options explicitly configure it or the profile sets `randomTop > 1`.
2. **Corrected the minimax test fixture.** The fake position tree previously stored evaluation scores one ply before the declared depth-3 horizon, so the search never evaluated the values the assertion was intended to compare. Scores now live at the horizon, with a quiet pseudo-move to make quiescence evaluate the synthetic leaves. Close scores plus a fixed RNG catch accidental randomness regressions.
3. **Updated stale version assertions** from `3.24.0` to the actual package version, `3.25.0`.
4. **Updated the offline-engine static assertion** to allow the existing `seen` search-context option after `profile`.

## Verification performed

- `node --check` across all `.js` and `.mjs` files in `src`, `server`, `scripts`, and `tests`: **passed**.
- All tests that do not require unavailable npm dependencies: **191 passed, 0 failed**.
- The complete `npm test` command was also attempted. Four test files could not load because this source ZIP has no `node_modules`: `chess.js` is missing for `tests/alternate-engine.test.js`, `tests/chess.test.js`, and `tests/v3-25-features.test.js`; `express` is missing for `tests/social.test.js`. Installing dependencies was blocked because DNS resolution for `registry.npmjs.org` returned `EAI_AGAIN` in the test environment.

The four dependency-blocked test files are **not reported as passed**. Run `npm install --no-audit --no-fund` in a network-enabled environment, then rerun `npm test` for complete verification.
