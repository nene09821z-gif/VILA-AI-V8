# VILA Chess v3.19.0 — 2D Chess.com-inspired pieces and board

- Set the default board to the familiar cream (`#eeeed2`) and green (`#769656`) palette, including last-move and selected-square colors.
- Removed the default board's wood-grain texture so the board renders as a clean flat 2D board.
- Updated the default owned board cosmetic to “Xanh lá & kem”; users who selected another cosmetic keep that selection.
- Kept the six original locally rendered SVG silhouettes (`k`, `q`, `r`, `b`, `n`, `p`) for both colors. Board pieces are rendered as inline SVG artwork, not Unicode chess glyphs or platform symbol fonts.
- Updated project version and regression tests.

## Validation

- `npm run test:static`: 169 passed, 0 failed.
- Targeted board layout and piece-artwork tests: passed.
- Full production build/device runtime not verified in this environment; the project ZIP does not include installed `node_modules`.
