# VILA Chess v3.6.0 — Test Report

## Passed in this environment
- `npm run test:static`: 88/88 tests passed, including new smoke tests for default home dashboard routes, live home-renderer output with all 64 board squares, and VILA Android app label.
- JavaScript syntax check passed for 41 source, backend, script, and test files.
- JSON files parse successfully.
- Python source compiles successfully.
- ZIP archive integrity check performed after packaging.

## Not claimed as verified
- `npm test` cannot complete in this environment because `chess.js` is not installed (`ERR_MODULE_NOT_FOUND`).
- Production build / APK build not run locally because npm dependencies (including Vite and Stockfish assets) are not installed in this workspace. The GitHub workflow installs dependencies and is configured to run both the full test suite and production build.
- No real Android device/WebView or live API key was available for runtime testing.
