# Offline alternative AI profiles (v3.16.0)

VILA's “AI đa phong cách — offline” mode is now implemented entirely in the app through `src/alternate-engine.js`.

- **Leela-style**: favors central control and positional development.
- **Tactical**: prioritizes captures, promotions, and checks.
- **Aggressive**: gives more value to initiative, checks, and active piece placement.

These are local VILA profiles, not the original upstream Lc0/Ethereal/Berserk engine programs. The original engines are not being falsely represented as included. The profiles use legal moves from `chess.js` and a bounded alpha-beta search, so they need no backend, API key, external engine binary, model weights, or Internet connection. Strength and playing style are not equivalent to the named upstream engines.

To use them: open **Cài đặt** → **Phong cách AI ngoại tuyến**, select a style, then in **Thiết lập trận** choose **AI đa phong cách — offline, không cần backend** and start a game.
