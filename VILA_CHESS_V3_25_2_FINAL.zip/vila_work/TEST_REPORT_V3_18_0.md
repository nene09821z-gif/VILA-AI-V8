# Validation report — VILA Chess v3.18.0

Date: 2026-10-17

## Results

- `node --check src/main.js`: PASS
- `node --check server/social.js`: PASS
- `node --check server/index.js`: PASS
- `node --check src/daily-progress.js`: PASS
- `npm run test:static`: **168 passed / 168 total**
- `npm test`: 168 tests passed; three test files could not start because required packages are absent: `tests/alternate-engine.test.js` and `tests/chess.test.js` need `chess.js`; `tests/social.test.js` needs `express`.
- `npm run build`: blocked during `prebuild` because `chess.js` is absent.
- Attempting to query npm registry failed with DNS error `EAI_AGAIN registry.npmjs.org`; dependency installation and a full web/APK build could not be verified here.
- No Android device/browser visual run was available in this environment.

## Important implementation boundaries

- The random puzzle mode generates legal positions and uses Stockfish for the answer; it is not a claim of a curated external puzzle database of unlimited size.
- VILA's Leela-style/Tactical/Aggressive profiles remain VILA-authored offline search engines; they are not the original Lc0/Ethereal/Berserk binaries or their neural weights.
- AI endpoint presets exist but live API use still requires the user's own provider account, correct model ID and API key. No keys are packaged.
- Admin seed Elo is configurable and labelled as an initial seed, not a certified chess rating.
