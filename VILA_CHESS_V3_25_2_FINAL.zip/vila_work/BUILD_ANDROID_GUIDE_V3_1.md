# Build v3.1.0 with GitHub Actions

1. Extract the full ZIP at the root of a GitHub repository. Keep hidden files and folders, especially `.github/workflows`.
2. Commit and push to `main`.
3. Open **Actions** and run **Build Chess Bot APK**.
4. Wait for dependency installation, all `npm test` suites, Stockfish asset copy, Vite build and Android debug packaging to finish successfully.
5. Download the APK artifact only after the workflow is green.
6. Install on a test device. Verify board sizing on portrait/landscape/short viewport; legal move handling; opening variation across several games; clock and undo; sounds after a user tap; spoken hints; local/API Coach; provider model enumeration; timeout/fallback; Arena and PGN export.

## Important
- This is a source ZIP, not a prebuilt APK or a separate editable Android Studio project.
- The local authoring environment could not resolve npm registry DNS (`EAI_AGAIN`). The static tests ran, but a dependency-backed build and APK have not been verified here.
- Do not commit API keys to a public repository. For a public backend, use HTTPS and a long random `TUBOR_ACCESS_TOKEN`.
- Free Tier labels indicate documented eligibility or catalog pricing, not unlimited or universal account access. Recheck official docs before production use.
