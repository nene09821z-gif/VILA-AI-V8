# v3.25.0
- Pieces on every board are now 80% of the square (Chess.com proportions); drag ghost resized.
- New effects on the main board: pulsing red king + "!" badge when in check, ring + pop on captures, blue glow + O-O/O-O-O tag on castling.
- Offline engine: null-move pruning, check extension, piece-square tables (tapered king), bishop pair, rook open-file bonus; deeper/longer default search (rookie/blitz personas unchanged); opening book reaches 20 plies.
- Opening library: +240 validated lines (≈320 total) in src/openings-extra.js.
- Puzzles: infinite offline generator (src/puzzle-generator.js) with theme + difficulty; Stockfish kept as fallback; any mating move accepted on mate-in-1.
- API: retry with max_completion_tokens / without temperature for newer OpenAI-compatible models; SSRF guard for link-local/metadata endpoints; health version fixed.
- Layout: tighter desktop grid, overflow guards.
# v3.25.1
- Chess.com-style right-click square glow (green; Shift red, Ctrl yellow, Alt blue), arrows kept; analysis marks work before/after the game.
- Offline AI: anti-repetition (penalises positions already seen), PVS search, mating-technique eval, small default move variety.
- NOTE: tests/v3-25-features.test.js was written but could not be executed in the build sandbox (npm registry blocked). Run `npm install && npm test`.
