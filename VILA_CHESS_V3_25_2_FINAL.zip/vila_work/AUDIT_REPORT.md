# Source audit — Chess Bot AI Arena v3.2.0

See [`AUDIT_REPORT_V3_2.md`](AUDIT_REPORT_V3_2.md) for the detailed audit.

Audited app launch/start lifecycle, board Pointer Events, game-result/PGN state, opening-book selection and recognition, API key error redaction, built-in Free Tier catalogue, Stockfish Worker timeout/retry lifecycle and GitHub Actions checks. Static suite reports 77/77 passing. Full SAN verification and build/device gates remain outstanding because the current environment could not install `chess.js` or Stockfish assets.
