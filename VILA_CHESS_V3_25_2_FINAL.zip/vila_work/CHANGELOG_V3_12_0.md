# VILA Chess v3.12.0 — Touch Analysis & Ranked Clock Categories

## Improvements
- Compact draggable annotation toolbar for solo play, with arrow drawing, square circles, and clear-all.
- Annotation widget position persists on the device; drawing tools use pointer events for touch and mouse.
- Ranked view exposes no undo, hint, or new-game controls during a rated match.
- Added Bullet, Blitz, and Rapid Elo pools, a clock selector, live two-player clock display, and server-side clock settling.
- Added more standard clock presets, beginner/experienced onboarding, and random Stockfish opponent Elo for solo practice.
- Kept the puzzle lab using legal generated positions and Stockfish analysis.

## Honest integration boundary
Stockfish is the only bundled offline chess engine in this package. The existing API-AI mode can make legal-move suggestions using a configured provider/model, and Lichess remains an online option. Leela Chess Zero/Maia are not bundled in this release because they require an engine runtime and model weights; the app should not advertise them as installed until those assets and their runtime are actually packaged and tested.

## Verification
- Syntax checks run for application/server modules.
- Pure/static regression tests are run where dependencies are present.
- Android APK build and end-to-end two-user server testing still require dependency installation and a live backend; do not treat the ZIP as a verified release APK.
