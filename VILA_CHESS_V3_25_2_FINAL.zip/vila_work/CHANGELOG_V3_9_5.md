# VILA Chess v3.9.5 — Community & Admin

- Thêm tài khoản cộng đồng username/password, băm mật khẩu scrypt và phiên token HMAC 7 ngày.
- Thêm tìm người chơi, lời mời kết bạn, danh sách bạn bè, sửa hồ sơ và trạng thái hoạt động gần đây.
- Thêm Top 100 phía server, giữ riêng lịch sử Elo cục bộ. Đây là nền tảng bảng xếp hạng hồ sơ; ván PvP được server xác thực và tính Elo trực tuyến chưa được triển khai.
- Thêm giao diện admin và API được bảo vệ bằng role server: tổng quan tiến trình, người dùng, khóa/mở khóa tài khoản thường, nhật ký audit.
- Thêm luồng OAuth Google/GitHub phía backend (cần khai báo Client ID/Secret, public backend URL và callback URLs; không tích hợp Firebase).
- Thêm rate limits, giới hạn payload, token HMAC, lưu dữ liệu JSON ngoài public assets với quyền file hạn chế, cảnh báo khi chưa cấu hình admin.
- Thêm test end-to-end cho đăng ký, đăng nhập, tìm bạn, lời mời, leaderboard, phân quyền admin, khóa/mở khóa và audit.
- Lưu ý: chống DDoS/khả năng sẵn sàng còn phụ thuộc hosting, HTTPS/WAF, persistent disk, backup và kiểm thử tải; OAuth redirect trong APK cần cấu hình deep link riêng.
