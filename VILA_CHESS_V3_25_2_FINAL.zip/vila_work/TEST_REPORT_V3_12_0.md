# VILA Chess v3.12.0 — Test Report

## Scope
This report applies to the source ZIP `VILA_CHESS_v3_12_0_TOUCH_ANALYSIS_RANKED.zip`.

## Checks completed
- JavaScript syntax check: **64 of 64 `.js` / `.mjs` files passed** (`node --check`).
- Targeted automated tests: **34 passed, 0 failed** across `clock.test.js`, `ranked-chess.test.js`, `ranked-online-ui.test.js`, `settings-schema.test.js`, `mobile-performance.test.js`, and `opening-ui.test.js`.
- Covered the time-control list/classifier, ranked active-clock arithmetic and flag-fall helper, per-category rating wiring, rank clock selector, absence of undo/hint/new-game controls in the ranked screen, and touch annotation UI wiring.
- ZIP integrity is verified when packaging.

## Not verified in this environment
- `node_modules` is absent. A full `npm test`, Vite production build, Android Gradle/APK build, and live Express integration test have **not** been run here.
- The server code needs a deployed, persistent backend to test two-user matchmaking, clocks, abandonment and Elo changes end-to-end.
- Physical touch interaction and animation smoothness still need device testing; source checks alone cannot prove zero lag on every Android device.

## Feature boundaries
- Solo board annotation: draggable/collapsible toolbar, arrow, circle, three colors, clear marks; the marks are local visual annotations and are only enabled for solo Stockfish/API-AI play.
- Ranked: matching is scoped to the chosen exact time control; Bullet/Blitz/Rapid rating pools are separated. The server settles time from stored clock timestamps and increments time on accepted moves. Rank UI does not expose undo, hint or new-game controls.
- Solo: expanded clock presets, beginner/experienced choice, optional random Stockfish Elo.
- Stockfish is the bundled offline engine. API-AI and Lichess remain selectable alternatives, but this package does **not** bundle a second offline neural engine such as LC0/Maia.

## Reference notes
- Chess.com describes Bullet, Blitz and Rapid live ratings as separate and classifies the time control using an estimated 40-move game length: https://support.chess.com/en/articles/8705367-why-are-there-different-ratings-in-live-chess
- LC0 browser builds and Maia models require an engine/runtime and model assets that must be packaged and tested before being presented as installed: https://github.com/dignissimus/lc0.js/ and https://github.com/CSSLab/maia3
