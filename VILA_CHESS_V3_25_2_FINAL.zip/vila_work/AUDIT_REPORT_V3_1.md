# Source audit — v3.1.0

## Key paths reviewed
- `src/openings.js`, `src/opening-book.js`: curated 71-line opening book and weighted legal-candidate selection based on current SAN history.
- `src/main.js`: integration with local Stockfish moves and Stockfish Arena seats; transactionally validated opening loading; sound unlock for Arena matches/league; Coach switch, hint actions, model catalog UI and endpoint error handling.
- `src/sound.js`: optional generated board sounds using Web Audio, without external audio assets.
- `src/board-layout.js`, `src/style.css`: actual container/viewport CSS-pixel sizing, responsive 8×8 board, compact touch controls and landscape height limits.
- `server/model-catalog.js`, `server/index.js`: provider catalog free markers plus dated official Gemini/Groq Free Tier allow-lists. Unknown model pricing is not inferred free.
- `tests/`: static regression coverage and `tests/chess.test.js` with full SAN legality replay through `chess.js`.

## Behavior / safety
- API-generated chess moves are checked against legal moves before applying.
- A malformed opening sequence does not cancel or replace the active game; the line must replay successfully first.
- The app does not invent API model IDs. Free Tier metadata indicates eligibility/documented free usage, not unlimited usage; quota, region and billing account still matter.
- Sound is synthesized locally and can be switched off. Android WebView may require a user gesture before audio; Arena buttons unlock its context.
- Stockfish Coach returns evaluation and candidate lines, not natural-language explanations. Select API Coach for conversational explanations.

## Release gates not completed locally
- `tests/chess.test.js` SAN legality suite: blocked by missing `chess.js` after npm registry DNS error.
- Full dependency install, Vite/Capacitor build, Android Gradle packaging, actual WASM/UCI run, live API keys and hardware testing have not been verified.
- Validate final APK on Android 12 / OPPO A17k / DPI 360 before publishing.
