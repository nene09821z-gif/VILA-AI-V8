# Chess Bot AI Arena v3.0.0

## New and improved
- Added a curated book of 71 opening lines across e4, d4, c4, flank openings, Sicilian, French, Caro-Kann, Indian defenses and gambits.
- Added weighted opening selection with recent-position choice memory. The book is used only when a candidate move is legal in the current chess.js position; Stockfish takes over when there is no matching continuation.
- Kept Stockfish Hash/Threads configuration at UCI initialization instead of resetting the transposition table before each move.
- Added generated board sound effects for quiet moves, captures, castling, check and checkmate in the main game and AI Arena. Audio is optional and its AudioContext is unlocked in a tap gesture for Android WebView compatibility.
- Added optional Vietnamese spoken hints (SpeechSynthesis), a use-this-move action, and a Coach source selector: configured API or local Stockfish analysis/MultiPV.
- Added free-model filtering based only on explicit provider metadata (OpenRouter `:free` IDs or zero input/output pricing); model names are fetched from each configured provider rather than hard-coded.
- Added official provider policy links in settings to help users verify plan-specific limits.
- Tightened small-screen button density, hint card styling, and board touch behavior while preserving responsive 8x8 sizing.

## Verification boundary
- `npm run test:static`: 60/60 passing in the local environment.
- Syntax checks: all JavaScript/MJS project files passed.
- Full `npm test`, dependency installation, Vite/Capacitor build, real Stockfish UCI and real provider API requests require dependencies/network access. The environment's npm registry DNS lookup failed (`EAI_AGAIN`), so these are not reported as passed.
- `tests/chess.test.js` contains a real chess.js validation of all 71 opening SAN lines; run it in GitHub Actions after dependencies install before release.
