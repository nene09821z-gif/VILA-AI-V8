# VILA Chess v3.9.5 — Test report

## Checks completed in the ZIP preparation environment
- JavaScript/MJS syntax checks (`node --check`) for project source, server, scripts, and tests.
- Python compilation check for `scripts/package-android-source.py`.
- JSON parse checks for `package.json` and `.env.example`.
- Static structure assertions for friends/admin navigation, Top 100 UI/API, friends API, server-side admin authorization, OAuth endpoint presence, absence of a hardcoded default admin password, persistence directory exclusion, and integration-test registration.
- Added automated integration tests in `tests/social.test.js` for local authentication, friend requests, server leaderboard, admin authorization, ban/unban, and audit records.

## Not verified
- `npm install` timed out in this environment, so `tests/social.test.js` and the complete `npm test` suite could not be executed here.
- Vite production build, Android/Gradle APK build, Google/GitHub OAuth against real provider credentials, production deployment, load testing, backup restoration, and security penetration testing have not been performed.

## Release gate
Run the repository's GitHub Actions workflows with dependency installation and require a green result before shipping an APK or opening the server to public users. Configure HTTPS, persistent storage, secrets, monitoring, backups, and a host-level restart policy. This report does not claim that production behavior or the generated APK has been verified.
