# VILA Chess UI Refresh v3.3.0

## Real source changes
- Reworked the visual system toward a chess-first layout with VILA green/cyan identity, compact header, simpler board frame and cleaner panels.
- Added an Android compact menu button; navigation views now live in a dropdown menu on small screens. Selecting a view closes the menu and updates `aria-expanded`.
- Kept the existing `data-view` navigation contracts so the existing play, arena, openings, coach, Lichess and settings views continue to route through `setView()`.
- Refined mobile board sizing and touch hit area; board uses `touch-action:none` so drag gestures can be handled by the existing board input logic.
- Desktop navigation remains visible; mobile navigation switches to the compact menu under 680px. Tightened spacing for 360 CSS px and small-height landscape screens.

## Validation
- `node --check src/main.js`: passed.
- `npm run test:static`: 77/77 passed.
- Full browser/WebView visual validation and Android APK build still require GitHub Actions/device testing; this package does not claim those were performed locally.
