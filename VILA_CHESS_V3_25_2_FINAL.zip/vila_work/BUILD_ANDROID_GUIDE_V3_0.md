# Build v3.0.0 with GitHub Actions

1. Extract the entire ZIP into the root of a GitHub repository. Include hidden files/folders such as `.github/workflows`.
2. Commit and push to the `main` branch.
3. Open **Actions** and run the workflow **Build Chess Bot APK**. It installs the pinned app dependencies, runs tests, copies the required Stockfish 19 JS/WASM assets and builds the Capacitor Android debug APK.
4. Download the APK artifact only after the workflow is green.
5. Install on a test device and verify: board sizing portrait/landscape, tap-to-move, promotion, undo, audio after first tap, speech hints, opening variety over several games, engine response, AI API model enumeration, API timeout/fallback and Arena result handling.

## Important
- A source ZIP is not a prebuilt APK.
- `npm install` and `npm run build` must run on GitHub with network access. This local environment could not resolve the npm registry; a local static test pass does not replace the GitHub build.
- Keep API keys out of public repositories. For a public backend, configure HTTPS and a long random `TUBOR_ACCESS_TOKEN` before binding beyond loopback.
- The free-model filter is conservative. OpenRouter models explicitly marked `:free` can be identified by their IDs; other providers may omit price fields from the model-list response, and plan-dependent free limits should be checked in the provider's current documentation.
