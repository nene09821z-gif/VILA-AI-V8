# Validation report — VILA Chess v3.17.0

## Checks completed in the authoring environment

- `node --check` passed for `src/main.js`, both alternate-engine entry/core modules, the worker and all `src/engines/*.js` files.
- `npm run test:static`: 165/165 passed.
- `tests/alternate-engine-static.test.js` passed.
- Dependency-free `tests/engine-search-core.test.js` passed for minimax selection, move undo restoration, and distinct finite evaluation scores.
- Project ZIP archive integrity will be checked after packaging.

## Not verified here

- The environment could not resolve `registry.npmjs.org` (`EAI_AGAIN`), so dependencies including `chess.js` were not installed during this run.
- Therefore dependency-backed engine tests (`tests/alternate-engine.test.js`), full `npm test`, Vite production build, Android APK build and actual-device play have **not** been executed. These must pass in GitHub Actions or another environment with npm access before release.
- No head-to-head game suite, Elo rating, or Stockfish parity claim is provided.
