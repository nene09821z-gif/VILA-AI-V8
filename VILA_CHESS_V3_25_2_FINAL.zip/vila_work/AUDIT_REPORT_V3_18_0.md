# Báo cáo rà soát VILA Chess v3.18.0

## Phạm vi
Rà soát các thành phần UI bàn cờ/đánh dấu, luật đi quân, engine ngoại tuyến, luồng cấu hình nhà cung cấp AI, phân tích và xem lại ván, nhiệm vụ/puzzle, social/ranked/admin, cùng trải nghiệm âm thanh.

## Thay đổi đã làm
1. Thanh chú thích mũi tên/vòng tròn không còn được render bên trên bàn cờ. Nó nằm trong hàng riêng sau khung bàn; SVG đánh dấu nước đi vẫn phủ trực tiếp lên bàn để tọa độ khớp ô cờ. Lưu vị trí dùng khóa v2 nhằm bỏ tọa độ cũ được tính từ vùng bàn cờ.
2. Chủ đề miễn phí mặc định đổi sang tông gỗ; ô chọn, ô đi cuối và ô bị chiếu giữ các selector ưu tiên riêng để lớp gỗ không ghi đè trạng thái ván.
3. Nhạc có nút dùng chung cho tiêu đề/trang chủ/màn chơi. Tự bật sau tương tác đầu tiên để tuân thủ chặn autoplay; người dùng có thể tắt. Liên kết YouTube chỉ là điều hướng tìm kiếm bên ngoài.
4. Admin Elo seed cấu hình từ `ADMIN_INITIAL_ELO` và được chặn trong khoảng 100–4000. Chỉ seed một lần nếu tài khoản admin chưa có ván được tính; Elo đã có lịch sử không bị ghi đè. Top 100 đánh dấu Elo khởi tạo.
5. Version package, trang health, title, README và changelog cập nhật lên 3.18.0.

## Tính toàn vẹn / bảo mật
- Không nhúng API key hay mật khẩu admin mặc định. Endpoint/provider API tiếp tục đi qua lớp server-side hiện có.
- Quyền admin vẫn do backend quyết định; nhãn Elo khởi tạo không đồng nghĩa với danh hiệu/đánh giá Elo FIDE/Chess.com được chứng nhận.
- Không xóa các tài liệu lịch sử, test, asset engine hoặc nguồn mở được quản lý chỉ dựa trên phỏng đoán. Thay vào đó, bổ sung test và ghi rõ các giới hạn môi trường.

## Bài kiểm tra
- `node --check` qua cho `src/main.js`, `server/social.js`, `server/index.js`, `src/daily-progress.js`.
- `npm run test:static`: **168/168 đạt**.
- `npm test`: **168 đạt, 3 suite phụ thất bại vì thiếu package cài đặt** (`chess.js` cho `tests/chess.test.js` / `tests/alternate-engine.test.js`; `express` cho `tests/social.test.js`). Registry npm không truy cập được từ môi trường tạo gói (`EAI_AGAIN`), nên không thể cài dependencies để xác minh integration tại đây.
- `npm run build` dừng ở `prebuild` vì thiếu `chess.js`; do đó chưa xác nhận build web/APK hay kiểm thử trên Android thực. Không trình bày các phần này như đã kiểm thử thành công.
