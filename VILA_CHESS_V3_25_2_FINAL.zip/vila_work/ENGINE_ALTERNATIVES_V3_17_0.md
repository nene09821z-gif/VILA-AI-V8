# VILA Chess v3.17.0 — Independent offline engines

The three alternatives are now implemented as separate evaluation engines:

- `src/engines/leela-style.js` — positional evaluation, pawn structure, bishop pair, king safety and endgame king activity.
- `src/engines/tactical.js` — capture-focused evaluation, attacked-piece awareness and central tactical activity.
- `src/engines/aggressive.js` — initiative, attacking-piece placement, king pressure and pawn advance.

`src/engines/search-core.js` provides the shared search infrastructure: iterative deepening, negamax alpha-beta, quiescence, transposition-table bounds, move ordering (TT move, captures, promotions, checks, killers and history), late-move reduction, mate-distance scores and capped time/nodes/memory. All moves are generated and applied through `chess.js`, preserving legal-move rules.

The app uses `src/alternate-engine-worker.js` to run search away from the UI thread. When module workers are unavailable, the wrapper falls back to synchronous in-app search. No engine server, API, neural weights or Internet is required for these VILA implementations.

## Use

1. Open Settings → **Phong cách AI ngoại tuyến** and choose Leela-style, Tactical, or Aggressive.
2. In game setup, choose **AI đa phong cách — offline, không cần backend**.
3. Start the game; the selected engine searches and returns a legal UCI move automatically when it is the AI's turn.

## Honest strength note

These are VILA-built heuristic/search engines. Their architecture includes several techniques also used by strong chess engines, but they are **not Stockfish, Lc0, Ethereal or Berserk**, and no match suite or Elo benchmark has been run. On-device engine strength depends on search time, device performance and position type. Stockfish remains the recommended strongest option in this app.
