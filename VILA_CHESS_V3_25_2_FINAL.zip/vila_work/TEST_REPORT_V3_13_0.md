# VILA Chess v3.13.0 — Test report

## Implemented in this patch
- Added a server-side engine hub for optional UCI subprocesses: Stockfish, Leela Chess Zero (Lc0), Ethereal, Berserk.
- Added `GET /api/engines` which reports readiness from real file paths, not hard-coded success.
- Added `POST /api/engines/analyze`, with engine ID allowlisting, FEN shape validation, 100–5000 ms requested think time, a bounded wall timeout, and `spawn(..., {shell:false})`.
- Lc0 requires both its executable and an existing weights file.
- Kept bundled in-app Stockfish as the offline engine.

## Verification results
- 3/3 new engine-hub tests passed.
- 158/158 static tests passed when excluding `tests/social.test.js`, because the `express` dependency is not installed in this environment.
- Syntax checks passed for `server/engine-hub.js`, `server/index.js`, and `tests/engine-hub.test.js`.
- ZIP structure verified after packaging.

## Not verified / known limits
- `npm install` and Android build were not run successfully in this environment; no APK is provided.
- No server engine binaries or Lc0 weights are bundled. All optional engines report unavailable until real compatible binaries are installed and environment paths are configured.
- No live UCI smoke test was possible because those binaries are absent.
- This patch adds the backend registry and analysis endpoint, but the current game UI has not yet been wired to select a remote engine for bot moves. The app's actual solo gameplay still uses the existing local Stockfish integration. This is an engine backend foundation, not a finished multi-engine UI integration.
- Before public deployment, add per-user auth/authorization, concurrency limits, and a queue for expensive analyses. Use the existing backend access-token setup and do not expose a public engine host without protection.
