# Chess Bot v3.5.0 — Stability & Analysis

## Fixes and reliability
- Serialized cancelled Stockfish searches across analysis, hints, full-game review and bot turns. The app waits for the stopped search's terminal `bestmove` line before allowing another engine search, preventing a late result from being mistaken for the next request.
- Added a bounded stop watchdog. If Stockfish does not acknowledge cancellation, the worker is retired and can be restarted instead of leaving analysis permanently busy.
- Analysis sessions are bound to the exact FEN and game epoch; stale info is ignored and stale completion closes cleanly without applying results to a newer board.
- The analysis control exposes a disabled “stopping” state while the previous UCI search is being closed; controls are re-synchronized when returning to the Play view.
- MultiPV updates retain the deepest seen record per line and render in stable lane order.
- Full-game review ignores a late lower-depth score after a deeper score has already arrived for the same position.
- Kept the analysis panel visible after an attempted search even when Stockfish returns no usable PV, showing a useful explanation instead of silently hiding the panel. Moved the panel directly below its button and increased usable height on mobile.

## Verification
- Added focused unit tests for analysis-session guards and MultiPV merging.
- `npm run test:static` covers static safety checks and pure module tests. Full dependency-backed tests and production build must be run where npm dependencies and Stockfish assets can be installed; actual Android/WebView and live API testing still require the target device and valid user-owned API configuration.
