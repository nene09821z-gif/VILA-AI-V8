# VILA Chess v3.14.0 — Verification report

## Changes checked

- Six SVG piece definitions exist and share one renderer used by the play board, review board, Arena, promotion chooser, ranked board, and puzzles.
- Annotation toolbar drag updates are scheduled via `requestAnimationFrame`, use `translate3d`, and persist the final position once.
- Annotation class names match green/red/yellow arrow and circle styles.
- Static CSS checks guard against reintroducing backdrop blur and SVG drop-shadow filters on the drawing toolbar / pieces.

## Results

The static suite passed 162/162 tests with `npm run test:static`. The Express-dependent social integration test remains included in the full `npm test` run after dependencies are installed. Syntax checks passed for all 66 JavaScript / MJS files; CSS delimiter balance and the annotation style mapping were also checked.

## Not tested in this environment

- The project dependencies were not installed, so no Vite/Capacitor Android build was run.
- No APK install, physical-device testing, or measured FPS / memory test was run.
