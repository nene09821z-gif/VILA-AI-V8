# Test report — VILA Chess v3.16.0

- `node --check` passed for `src/main.js`, `src/alternate-engine.js`, `src/settings-schema.js`, `server/index.js`, `server/engine-hub.js`, and the new tests.
- `npm run test:static`: 163/163 tests passed, including a guard that the alternative-engine mode does not call `/api/engines/analyze`.
- Runtime chess-engine tests were added in `tests/alternate-engine.test.js`, but could not be executed in this authoring environment because `chess.js` is not installed; dependency installation timed out.
- Full Vite/Android build and real-device gameplay therefore remain unverified here; run `npm install`, `npm test`, and `npm run build` in CI before release.
