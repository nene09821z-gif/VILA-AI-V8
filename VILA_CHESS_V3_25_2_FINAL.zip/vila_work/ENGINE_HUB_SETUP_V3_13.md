# VILA Chess — Hybrid engine hub (v3.13.0)

## What is actually implemented
- Stockfish remains the existing in-app offline engine.
- `GET /api/engines` reports server-side engine readiness from configured filesystem paths; it never claims an engine is installed if its executable is absent.
- `POST /api/engines/analyze` accepts a whitelisted engine ID, a validated FEN, and a 100–5000 ms search time. It starts a one-shot UCI process with `shell: false`, applies a hard timeout, and returns the engine's actual `bestmove` plus the last principal-variation info line.
- Supported optional server engine IDs: `stockfish`, `lc0`, `ethereal`, `berserk`.
- Lc0 readiness requires both `LC0_PATH` and `LC0_WEIGHTS_PATH` to point to existing files.
- Tests cover catalogue readiness, FEN validation, ID allowlisting, and honest failure when an engine is not configured.

## Required deployment configuration
Set the absolute paths in the server's private environment:
- `STOCKFISH_PATH=/opt/vila-engines/stockfish`
- `LC0_PATH=/opt/vila-engines/lc0`
- `LC0_WEIGHTS_PATH=/opt/vila-engines/network.pb.gz`
- `ETHEREAL_PATH=/opt/vila-engines/ethereal`
- `BERSERK_PATH=/opt/vila-engines/berserk`

Only set paths for binaries actually installed and executable on the target OS/CPU. These paths are examples, not bundled assets. The service does not download or compile engines automatically. Install binaries from their official repositories, check each license and architecture, and verify each executable manually before enabling it. For Lc0, choose a network compatible with the Lc0 version and available memory.

## Security and limits
- Do not accept executable paths or arbitrary command arguments from the client.
- The HTTP API is protected by the existing backend access-token middleware when `TUBOR_ACCESS_TOKEN` is set; public deployments already require this secret.
- Each analysis is limited to 5 seconds of requested thinking and 10 seconds wall time. This is a basic single-process integration, not a multi-tenant queue; add concurrency limits and a job queue before opening it to a large public audience.
- This backend endpoint does not yet switch the in-app bot's move provider or add an engine-picker screen. The current local game still uses the existing bundled Stockfish engine. Wiring UI selection to these remote endpoints is a separate integration step, and the app must not show unavailable engines as selectable.

## Verification
Run `npm run test:static` and `npm run build` in an environment with dependencies installed. No APK build or live engine integration can be claimed until those commands and a smoke test against each configured binary pass.
