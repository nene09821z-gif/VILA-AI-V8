# VILA Chess v3.10.0 — Test report

## Passed checks in this environment
- `node --check` for JavaScript/MJS source files under `src/`, `server/`, `scripts/`, and `tests/`.
- JSON parse checks for `package.json` and `capacitor.config.json`.
- Python compilation check for `scripts/package-android-source.py`.
- `node --test tests/daily-progress.test.js tests/project-smoke.test.js`: **49/49 passed**.
- Broader dependency-free regression subset (all test files excluding only `tests/chess.test.js` and `tests/social.test.js`, which import external packages): **134/134 passed**.
- New tests cover daily date rollover, consecutive day streak, missed-day reset, one-time claims, progress caps, store overspending prevention, owned/equipped cosmetics, view wiring and clear separation between virtual coins and money.
- Static tests verify the new navigation routes, integration into the home dashboard and the revenue roadmap documentation.

## Not verified
- `npm install --no-audit --no-fund` timed out in this environment; no usable `node_modules` tree was created.
- Tests requiring external `chess.js` and Express packages, full `npm test`, Vite production build, Stockfish asset packaging, Capacitor sync, Gradle APK build and on-device UI testing remain unverified.
- Google/GitHub OAuth with real provider credentials, production server deployment, load testing, penetration testing, Google Play Billing and AdMob were not exercised. Real-money payments and live advertising are intentionally not enabled in this source version.

## Before release
Run the repository GitHub Actions workflows with dependency installation; require the complete test suite, Vite build and Android debug build to pass. Install the resulting APK on Android devices and check board themes, mission progress, daily rollover and storage recovery. Only then configure production monetization using official SDKs, test ads and backend purchase verification. Virtual coins currently live on the device and are neither cash nor synced to the account server.
