# Build guide — Chess Bot AI Arena v3.2.0

1. Extract the ZIP to the root of your GitHub repository. Keep `.github/workflows`, `package.json`, `capacitor.config.json`, `scripts`, `src`, `server`, and `tests`.
2. Commit/push to `main`; open the repository **Actions** tab and run **Build Chess Bot APK**. The workflow also runs on pushes to main.
3. Wait for install, syntax checks, `npm run test:static`, `npm test`, required Stockfish asset copy, Vite build, Capacitor sync, Android project verification, and `assembleDebug` to finish.
4. Download `chess-bot-debug-apk` only from a successful workflow run. The workflow also uploads the generated Android Gradle source as a separate diagnostic artifact.
5. Install the APK on the target phone and validate: launch remains at setup; Start honors mode and side; tap and drag moves work; promotion selector; hint arrow; orientation/rotation at 360 CSS px; sounds after user gesture; clock/timeout; resign and result; PGN; full-game review; Stockfish retry after deliberate asset failure; API invalid key/quota/model errors; and the Gemini/Groq/OpenRouter presets using your own credentials.

## Known release gates

- The ZIP is source code, not a prebuilt APK.
- In the packaging sandbox, `npm run test:static` passed 77/77. `npm test` had 77 passing tests and one failed test-module load because `chess.js` is absent; package registry DNS was unavailable. GitHub Actions needs to install dependencies before SAN legality tests can run.
- No real Stockfish UCI/WASM runtime or API credentials were exercised here, and no OPPO A17k device test is claimed.
- Free Tier preset names do not guarantee access/quota for every account. Never paste provider keys into public issues/logs or commit them to Git.
