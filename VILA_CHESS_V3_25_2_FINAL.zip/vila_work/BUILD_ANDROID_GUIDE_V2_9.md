# Hướng dẫn build Android — Chess Bot AI Arena v2.9.0

ZIP này là **mã nguồn web/Capacitor để GitHub Actions tạo APK**; nó chưa phải một dự án Gradle đã khởi tạo và không phải APK.

## Cách build dễ nhất bằng GitHub

1. Tạo repository mới và tải toàn bộ nội dung trong ZIP lên thư mục gốc repository (bao gồm `.github/workflows/`).
2. Commit/push vào nhánh `main`.
3. Mở tab **Actions** → workflow **Build Chess Bot APK** → **Run workflow** nếu chưa có lần push mới.
4. Chờ workflow chạy hết tất cả bước kiểm thử và build. Đừng dùng artifact nếu bước bắt buộc màu đỏ.
5. Mở run thành công, tải artifact `chess-bot-debug-apk` và giải nén để lấy `app-debug.apk`.
6. Cài APK trên điện thoại và xác nhận quyền cài app ngoài Play Store nếu Android yêu cầu.

Workflow cũng xuất artifact `chess-bot-android-gradle-source` — đây là ZIP dự án native Android/Gradle được sinh ở bước build, không phải gói nguồn web ban đầu.

## Build cục bộ (máy tính)

Yêu cầu Node.js 22+, npm, Java 21 và Android SDK phù hợp.

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
REQUIRE_STOCKFISH=1 npm run build
npx cap add android
npx cap sync android
node scripts/apply-android-branding.mjs
node scripts/verify-android-project.mjs
cd android
./gradlew assembleDebug
```

Nếu thư mục `android/` đã tồn tại, bỏ `npx cap add android` và chạy `npx cap sync android`. Windows dùng `gradlew.bat assembleDebug`.

## Nếu workflow lỗi

- **`chess.js` không tìm thấy:** `npm install` chưa chạy thành công; không bỏ qua test `tests/chess.test.js`.
- **Thiếu Stockfish Lite/Full:** xem log `scripts/copy-engine.mjs`; workflow bật `REQUIRE_STOCKFISH=1` và sẽ dừng thay vì phát hành APK không có engine.
- **Gradle/SDK lỗi:** xem phiên bản Java/Android SDK trong workflow và đầy đủ log của `npx cap sync android`.
- **APK cài được nhưng AI API lỗi:** AI API cần endpoint/backend HTTPS phù hợp và API key có quyền sử dụng model. Backend không được tự chạy trong APK.

## Sau khi cài trên OPPO A17k

- Mở ván mới, thử chạm chọn/di chuyển quân ở cả hai hướng bàn cờ.
- Kiểm tra bàn cờ 8×8 ở dọc/ngang; mở/đóng bảng phân tích và thay đổi xoay màn hình.
- Test nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hoàn tác, đổi màu, đồng hồ và PGN.
- Kiểm tra Stockfish Lite chạy offline; thử Full chỉ nếu máy đủ bộ nhớ và không có dấu hiệu chậm/nóng bất thường.
- Test API bằng key của chính bạn; kiểm tra timeout/fallback khi tắt mạng. Không commit API key vào GitHub.

Build xanh không thay thế được kiểm tra cảm ứng/hiệu năng trên điện thoại thật. Xem `TEST_REPORT.md` để biết chính xác những bài đã thực thi trong môi trường tạo ZIP.
