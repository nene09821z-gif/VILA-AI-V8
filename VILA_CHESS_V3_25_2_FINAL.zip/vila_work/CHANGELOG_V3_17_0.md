# VILA Chess v3.17.0 — Independent Offline Chess Engines

- Split the three selectable alternatives into separate evaluation modules instead of relying only on one basic minimax profile.
- Replaced the fixed shallow minimax pass with iterative deepening and alpha-beta negamax, quiescence extensions for tactical exchanges, transposition-table bounds, killer/history heuristics, capture/promotion/check ordering, and late-move reductions.
- Kept independent positional, tactical and attacking scoring terms and capped each search by both time and node count for phone-browser use.
- Runs searches inside a Vite-bundled module worker so the board UI remains responsive; includes a fallback for unavailable workers.
- Keeps legal move generation/validation delegated to `chess.js`; handles terminal FEN positions and stale asynchronous results.
- Does not claim parity with Stockfish or represent these implementations as original third-party engines. No Elo claims are made without benchmarking.
