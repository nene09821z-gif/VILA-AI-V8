# VILA Chess v3.11.0 — Ranked Matchmaking & Puzzle Lab

## Added
- Expanded daily progression to 17 missions and 8 cosmetic board themes; rewards are virtual coins only.
- Original SVG Staunton-inspired pieces with responsive sizing across the live, puzzle, and replay boards. These are newly authored shapes, not copied Chess.com artwork.
- A distinct random 1v1 ranked queue that chooses compatible Elo opponents and gradually widens the rating window while waiting. Ranked moves are validated by `chess.js` on the backend.
- Server-calculated Elo results after wins, draws, losses, resignations, and disconnect timeouts. The loser who resigns, abandons, or times out receives an additional 15-point penalty (rating remains clamped to 100–4000). Win bonuses vary within bounded limits; rating changes are not purely random.
- A 90-second server-side ranked presence timeout as a fallback for closed tabs or dropped network connections. Leaving the in-app ranked screen or pressing the forfeit button resigns immediately when the request reaches the server.
- Randomly generated legal chess positions assessed by the built-in Stockfish engine, with move selection, best-move hint, answer reveal, analysis, and puzzle mission progress. The generator can keep creating positions; this is not a claim of billions of curated, hand-authored tactics puzzles. Some generated positions can have simple or defensive best moves.
- Game-review board annotations for the last move and engine-derived move-quality symbol, plus a clearer result/review panel.

## Important deployment notes
- Ranked play requires a deployed backend, valid account sessions, and at least two real users online. A local/demo Elo value is not used as ranked authority.
- This version's community store is the existing persistent JSON file store and is intended for one backend instance. Before running multiple server instances or scaling a large tournament, migrate ranked queue, matches, and Elo updates to a transactional shared database.
- Full backend integration/build tests require installing the project's exact npm dependencies. The release test report records what was actually run in the packaging environment.
