# VILA Chess v3.9.0 upgrade plan

## User goals
1. Let the AI use many more opening variations.
2. Bring the full play screen closer to the familiar Chess.com play-room layout.
3. Preserve existing VILA functionality and deliver a ZIP ready for GitHub Actions.

## Implementation

### Opening knowledge
- Keep the curated opening seed as an offline fallback.
- Before Vite production bundling, attempt to fetch `a.tsv` through `e.tsv` from `lichess-org/chess-openings` (CC0-1.0).
- Replay each candidate sequence with `chess.js`; reject invalid sequences, de-duplicate canonical SAN lines and avoid replacing a catalog if fewer than 1,500 valid lines are parsed.
- Bundle the generated catalog as `public/openings-eco.json`. If refresh fails, the build continues with the fallback.
- Load the bundled file after app boot, merge at most 5,000 entries, expose filtered/paginated discovery and invalidate cached search tries after additions.
- Continue using the opening-book only for legal moves that match the full SAN history; Stockfish remains the fallback after a line ends or the game leaves the book.

### Play room UI
- Reorganize the play header and board area with player/context rows, clocks, opening recognition, evaluation, analysis, hints and side panels.
- Use Chess.com-inspired green/cream squares and dark panels without reusing Chess.com branding/assets or claiming official affiliation.
- Keep responsive one-column placement on mobile, current menu routes and existing event handlers.

### Validation
- Add tests for safe catalogue merging, caps, malformed lines, dynamic-cache invalidation, UI layout and workflow wiring.
- Add syntax checks for the catalogue merge module and importer to both GitHub Actions workflows.
- Verify source ZIP integrity and report missing dependency/build/device gates honestly.

## Explicit limits
The build-time download needs outbound Internet access on the GitHub runner. The authoring environment could not populate the remote dataset itself, so its checked-in `public/openings-eco.json` remains an empty external-data placeholder and the curated opening seed remains the immediate offline fallback. The generated APK must be inspected after a successful GitHub run before claiming the external book and full application are validated.
