# Test report — v3.2.0

Date of source pass: 2026-10-17 (UTC date of current session). Tests are separated by what actually ran.

## Ran successfully

- `npm run test:static`: **77 tests passed, 0 failed**.
- `node --check` applied to JS/MJS files under `src`, `server`, `scripts`, and `tests` (run again in final validation).
- Static guards cover responsive board geometry, pointer drag hook, opening book/recognition, move suggestion arrows, start-state wiring, game-result/PGN/review actions, API provider error redaction, built-in Free Tier presets, and Stockfish timeout worker retirement/retry.
- ZIP CRC test, required files and archive membership inspected before delivery (run again for final ZIP).

## Blocked / not claimed

- `npm test`: 77 tests passed, but `tests/chess.test.js` did not load because `chess.js` could not be resolved (`ERR_MODULE_NOT_FOUND`). This sandbox has no installed dependencies and package registry DNS was unavailable in this session. Therefore the opening lines have structural/static checks but all 81 SAN sequences have **not** been proven legal by `chess.js` here.
- `npm run build`: not run to success because Stockfish package assets are not installed/copied in the authoring sandbox.
- Stockfish live UCI search, WASM load, API request with real provider key, GitHub Actions build, Android `assembleDebug`, and OPPO A17k Android 12/DPI 360 hands-on test: not run or not confirmed.

## Meaning of timeout tests

Static tests verify the source terminates a timed-out Worker and clears search identity. These are regression/source tests, not a substitute for a live Worker race test on an Android WebView.
