# VILA Chess v3.22.1 — Audit and stability patch

## Changes in this patch
- Local Elo calculation rejects invalid outcomes. Only `0`, `0.5`, and `1` are accepted; malformed values no longer get silently clamped into an apparent game result.
- Server ranked-Elo calculation applies the same outcome validation, so local and server helpers share the same contract.
- Added regression tests for NaN, Infinity, out-of-range values, fractional non-draw outcomes, and valid draws.

## Verification actually performed
- `node --check` on all 76 JavaScript files: passed.
- `node --test tests/elo.test.js tests/ranked-chess.test.js`: 11 tests passed, 0 failed.
- Full `npm test`: 167 passed, 8 failed. Three failures are dependency-load failures (`chess.js` / `express` are absent); five static checks fail in this extracted archive (including checks expecting older v3.15 identifiers/strings). These failures are not presented as passing and need triage in an installed project environment.

## Audit limitations / remaining work (not claimed complete)
- Dependencies are not included in the supplied archive; no `node_modules` or lockfile was present. A full test suite and production build have not been run.
- The existing recovery code writes a local snapshot but does not wire a complete automatic restore prompt/workflow. Do not treat persistence as full recovery.
- A dedicated end-of-game result surface showing reason, Elo delta, and replay action was not proven complete in this patch.
- Static review and helper tests do not prove server-side idempotency for duplicate ranked-result submissions, API rate limits, reconnect/resume correctness, or real server-authoritative Elo persistence. These require endpoint/integration tests and runtime verification.
- UI behavior for evaluation graph, principal variation, move-by-move navigation, annotation toolbar placement, and responsive analysis popup requires browser/device verification; no claim of full UI verification is made.
- Elo calculations are mathematical helpers, not proof that every actual game-ending path submits exactly one valid result.
