# Source audit — v3.0.0

## Areas changed
- `src/openings.js`, `src/opening-book.js`: 71 curated SAN lines and weighted legal move selection.
- `src/main.js`: integrates the opening book for Stockfish main games and Stockfish seats in Arena; applies sound to human, engine, and Arena moves; includes speech hint actions and API-vs-Stockfish Coach selection.
- `src/sound.js`: browser/WebView Web Audio effects and gesture-based context unlock.
- `src/settings-schema.js`: migration-safe settings for opening book, sound and Coach source.
- `server/model-catalog.js`, `server/index.js`: only labels a model free when the provider catalog explicitly identifies a `:free` route/model or exposes zero input and output pricing.
- `src/style.css`, `src/board-layout.js`: adaptive board sizing, touch interaction and compact mobile controls.

## Safety/behavior notes
- API-generated moves are checked against the legal move list before applying in Arena.
- Model-list calls enumerate the configured provider; the app does not invent model IDs.
- Free-tier access depends on provider/account, region, rate limits and current pricing. If the provider model-list endpoint omits prices, the app intentionally does not infer free status.
- Sound effects are generated locally; no external audio resource or third-party audio request is required.
- The local Stockfish Coach presents scores/variations, not natural-language reasoning. For natural-language explanation, select API mode.

## Open release gates
- SAN legality suite for every opening line must run with installed `chess.js`.
- Build must confirm Stockfish JS/WASM assets are present.
- Exercise real provider API keys and timeouts.
- Confirm layout, sound, speech, touch hitboxes, thermal behavior and FPS on Android 12 / OPPO A17k.
