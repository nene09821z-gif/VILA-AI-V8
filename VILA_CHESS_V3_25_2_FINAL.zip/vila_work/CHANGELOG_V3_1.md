# Chess Bot AI Arena v3.1.0

## Added and corrected
- Added official provider-aware Free Tier classification for the currently published Gemini text models and Groq Free Plan chat models, while keeping `:free`/zero-pricing support for catalog results such as OpenRouter.
- Clarified the app label as “FREE TIER”; plan limits and billing depend on provider account and policy.
- Made opening-line loading transactional: each whole SAN line is replayed on a temporary `Chess` instance before the current game is cancelled/replaced. Invalid catalog data now produces a warning and leaves the current game unchanged.
- Unlocks Web Audio from the tap gesture before the Arena round-robin tournament as well as a single match/rematch.
- Updated static tests for Free Tier provider logic, audio unlock and defensive opening loading.

## Inherited v3.0.0 features
- 71 curated opening lines with weighted variety and a return to Stockfish outside the book.
- Responsive CSS-pixel board measurements, compact controls, local board sound effects, Vietnamese spoken hints, local Stockfish Coach/MultiPV, dynamic provider model lists and retained Lichess/PGN/clock/Arena functionality.
- Hash/Threads configured at UCI initialization, avoiding repeated hash resets before each move.

## Verification
- `npm run test:static`: 62/62 passed locally.
- JavaScript/MJS syntax and repository metadata checks are run separately before packaging.
- Full chess SAN test, full dependency install, Vite/Capacitor production build, real Stockfish WASM, live provider requests and OPPO device testing were not possible in the current environment because npm registry DNS failed (`EAI_AGAIN`). Do not treat the package as device-verified until GitHub Actions and target-device checks pass.
