# VILA Chess v3.7.0 — Android Touch & AI Response Fixes

## Mobile play and board interaction
- Fixed the common play controls to a safe-area-aware bottom action bar on small screens so New Game, Undo and Hint stay reachable while scrolling.
- Collapsed the tall match setup panel on small screens; it can be opened when needed rather than permanently consuming the screen.
- Changed square selection to update only square/highlight DOM instead of rebuilding all 64 board buttons on every tap.
- Delegated square click handling once per board; pointer drags use a cached board rectangle, requestAnimationFrame-coalesced transforms, and a lightweight drag ghost.
- Scoped suppression of synthetic click events to the exact drop square and a short window so rapid follow-up taps on other squares are not discarded.
- Reduced repeated work during complete board rendering by reusing legal-target indexes and cached check/turn state.

## AI text and move generation
- Added a provider response normalizer for OpenAI-compatible, Gemini and Anthropic output structures, including content-block responses and common gateway wrappers.
- Deliberately excludes hidden reasoning/thinking and tool-call blocks from the displayed final answer.
- Returns actionable diagnostics when the upstream response is empty, truncated by a token limit, safety-blocked, or contains only an unsupported tool call.
- AI Coach retries once only after a successful upstream response without textual output, with a bounded higher output budget and timeout.
- AI-vs-bot and AI Arena also retry once for an explicit empty-text response; credentials, quota and network errors are not blindly retried to avoid duplicate costs.
- Increased AI Coach output budget and timeout for slower reasoning models.

## Verification and limitations
- `npm run test:static`: 100/100 tests passed after the latest source changes.
- JavaScript syntax checks, JSON/Python checks and archive integrity are run before release packaging.
- Full `npm test` cannot complete in this local workspace because dependencies are not installed; `npm install` timed out. The failure is recorded in `TEST_REPORT_V3_7.md` rather than being presented as a passing test.
- No live provider API key or physical Android WebView test was available, so model/provider-specific behavior and OPPO A17k touch latency still need runtime confirmation.
