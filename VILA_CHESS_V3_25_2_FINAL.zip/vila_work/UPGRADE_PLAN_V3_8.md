# VILA Chess upgrade plan — v3.8.0

Scope: upgrade directly from the supplied v3.7.0 source ZIP. Preserve existing gameplay, UI routes, Stockfish, Arena, Coach, settings, clock, openings, Elo, PGN and Lichess behavior.

## Ordered priorities

### P0 — AI reports success but returns an empty answer (implemented)
- Normalize standard chat completion content plus Responses-style `output[]` and nested gateway wrappers.
- Parse SSE text chunks if a provider/gateway streams even though the request asked for non-streaming output.
- Preserve inter-chunk whitespace and ignore Gemini thought/reasoning blocks.
- Improve tool-only/token-limit diagnostics and redact keys from thrown fetch/network errors.
- Keep retries restricted to no-text success responses. Do not blindly retry authorization, quota, HTTP or network failures.

### P1 — Chess-piece dragging stutters / gets stuck on Android WebView (implemented in source; device latency unverified)
- Keep pointer movement coalesced to one `requestAnimationFrame` update.
- Remove the dynamic `drop-shadow` filter on the drag ghost; promote transform rendering and contain paint/layout.
- Reset source opacity/ghost on `pointercancel` and `lostpointercapture`.
- Guard delayed promotion choices using the captured game epoch and FEN.

### P2 — Preserve old behavior and avoid regressions (static checks passed)
- Add isolated regression tests for response wrappers, three SSE provider styles, hidden thought blocks, sanitization and pointer cleanup.
- Keep existing delegated click listener, square-only synthetic click suppression, legal move validation, and stale-response guards.
- Keep prior routes/features and update the health/package version consistently.

### P3 — Release/build confidence (partially complete; external build required)
- Add syntax check for the new response parser to both GitHub Actions workflows.
- Static regression suite: 106/106 passed.
- Full `npm test` is blocked locally because package dependencies are not installed (`chess.js` missing); no successful APK build is claimed. GitHub Actions must run full tests and `assembleDebug`.
- Real provider calls and Android touch latency still require API credentials and a physical/device WebView test.
