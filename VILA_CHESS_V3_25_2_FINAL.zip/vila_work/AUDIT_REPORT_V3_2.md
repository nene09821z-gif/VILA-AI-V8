# Source audit — v3.2.0

## Main changes reviewed

- **Fresh start:** `gameStarted` begins false, showing the ready overlay. Both start controls route through `startGameFromSetup()` so selected mode and side are applied before a game begins; model mode requires required endpoint/model/key configuration.
- **Board input:** the UI keeps click/tap selection and adds Pointer Events for drag, legal destination feedback, promotion choice, touch-action control and stale click suppression. Layout sync observes the viewport/rotation/container. Actual phone calibration still must be tested on device.
- **Move display:** hint and first MultiPV line may draw a directed SVG arrow; an evaluation bar reflects a tanh mapping of Stockfish centipawns from White's perspective. It is explicitly a visual cue, not calibrated win probability.
- **Opening system:** current source contains at least 80 curated SAN lines (81 in the checked source), retains book selection by history prefix, weighted choice/recent-choice avoidance, and waits for enough plies to reduce false opening labels. Lines are validated on a temporary `Chess` instance before selected-line application. Since `chess.js` was unavailable here, the full SAN unit test did not execute.
- **Full game review:** result/termination state, resignation and flag fall, PGN headers/download, sequential evaluation and judgement are wired. Result/review requires a completed game except for in-game MultiPV analysis.
- **API:** built-in presets are available without catalog download; remote requests still require user's own key. Provider-specific errors are sanitized to avoid exposing secrets. Built-in free tier lists must be periodically reviewed because provider pricing and IDs can change.
- **Stockfish lifecycle:** UCI options are configured at initialization; timeouts/faults terminate the Worker, clear active search IDs and display fallback status. Status is a button that can retry initialization, guarded against duplicate retry while engine is busy/initializing.

## Test status

- `npm run test:static`: 77/77 passed.
- Full `npm test`: 77 passed; `tests/chess.test.js` failed to load because `chess.js` dependency is not installed in the current sandbox.
- Live Stockfish assets/search, provider API behavior with real credentials, Android APK build and phone UI have not been independently confirmed in this environment.

## Release recommendation

Run the provided GitHub workflow with network access so `npm install` can install `chess.js`, Stockfish and Capacitor; do not publish a release until the full tests and Android build succeed. Then check the APK on the actual target phone and test each API preset with personal credentials and quota-aware error handling.
