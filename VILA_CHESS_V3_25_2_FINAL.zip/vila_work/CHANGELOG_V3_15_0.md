# VILA Chess v3.15.0 — Classic Pieces, Random Side & Alternative Engines

Built from the v3.14.0 source base; existing features are retained.

- Redrew all six chess-piece SVG silhouettes with a cleaner, classic Staunton-inspired appearance. The art is original to VILA and does not copy Chess.com proprietary assets. The renderer is shared across the main board, replay, promotion, arena, ranked and puzzle boards.
- Added a `🎲 Ngẫu nhiên Trắng / Đen` side choice. Each new solo game randomly chooses the human side and keeps board orientation aligned with it.
- Added VILA Classic, a lightweight local alpha-beta/minimax chess AI using `chess.js` legal moves. It runs offline and is independent of Stockfish, though it is not as strong as a dedicated engine.
- Connected the existing Engine Hub selection to Leela Chess Zero (Lc0), Ethereal and Berserk via `/api/engines/analyze`. These engines are optional server installs; Lc0 also requires network weights. They are not falsely marked as bundled/available when missing.
- Added settings validation and regression tests for the new modes and random side choice.

## Verification

JavaScript syntax checks and dependency-free static tests are run in the authoring environment. Full Vite build and tests requiring npm dependencies must be rerun with `npm install` in Termux; optional external engine modes require their respective server binaries (and Lc0 weights).
