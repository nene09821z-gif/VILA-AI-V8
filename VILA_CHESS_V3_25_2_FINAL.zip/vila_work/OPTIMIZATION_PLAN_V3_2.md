# Optimization plan — Chess Bot AI Arena v3.2.0

1. **Play reliability:** launch in setup state; enforce legal moves; cancel stale API and engine tasks after new game, undo, color/mode change, resignation and clock end.
2. **Engine recovery:** keep Hash stable across moves; terminate worker after timeout/fault to avoid a late bestmove racing into a later request; expose a user-triggered retry.
3. **Fast low-RAM profile:** use adaptive Lite/Full engine selection and single-thread defaults, with time-budget searching; validate on OPPO A17k before changing the default.
4. **Clear board UX:** responsive measured board size, pointer drag/tap input, promotion, legal-target indicators, arrow for engine suggestion, moves/clock/results in compact panels.
5. **Opening variety:** weighted book choices tied to exact history and a conservative recognition threshold; let Stockfish take over when the line ends or deviates.
6. **Coach split:** Stockfish is the source of move/eval/MultiPV; LLM API is used to explain or answer natural-language questions, not trusted as an unvalidated move generator.
7. **API transparency:** bundled presets remove the need to load a catalogue to begin configuration; credentials remain user-supplied; distinguish Free Tier eligibility from account-specific quota. Give actionable 401/403/429/model/endpoint messages and redact secret material.
8. **Release gates:** full `npm test` after installing dependencies, required Stockfish asset build, GitHub Actions Android build, API smoke tests with a test key, then hands-on portrait/landscape and touch tests on OPPO A17k.
