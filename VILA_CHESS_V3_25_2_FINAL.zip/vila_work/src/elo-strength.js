/** Map the user's requested 500–3200 target onto Stockfish controls.
 * Stockfish UCI_Elo is supported only around 1320–3190. The sub-1320 band therefore
 * uses Skill Level 0 plus occasional legal heuristic moves; the result is an estimate,
 * not a calibrated rating or a promise of exact playing strength.
 */
export function clampTargetElo(value, fallback = 2600) {
  const n = Number(value);
  const safe = Number.isFinite(n) ? n : fallback;
  return Math.round(Math.max(500, Math.min(3200, safe)));
}

export function resolveStockfishStrength(value) {
  const targetElo = clampTargetElo(value);
  if (targetElo < 1320) {
    const weaknessRatio = (1320 - targetElo) / (1320 - 500);
    // Smoothly increase weak heuristic selections toward beginner targets; the
    // heuristic itself always returns a legal chess.js move, but isn't Stockfish strength.
    const heuristicMoveProbability = Math.max(0.05, Math.min(0.85, 0.85 * Math.pow(weaknessRatio, 0.55)));
    const randomLegalMoveProbability = Math.max(0, Math.min(1, weaknessRatio));
    return { targetElo, limitStrength: false, uciElo: null, skillLevel: 0, heuristicMoveProbability, randomLegalMoveProbability, mode: 'beginner-simulated' };
  }
  return { targetElo, limitStrength: true, uciElo: Math.min(3190, targetElo), skillLevel: 20, mode: 'uci-elo' };
}
