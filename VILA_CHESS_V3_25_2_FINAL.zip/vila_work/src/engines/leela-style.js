import { PIECE_VALUE, centerValue, kingPosition, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, positionalScore, isAttacked } from './evaluation-utils.js';

// Positional, long-term evaluation profile. This is a VILA engine, not Lc0.
export const LEELA_STYLE = Object.freeze({ id: 'lc0', name: 'Leela-style', defaultDepth: 5, maxNodes: 36000, maxTimeMs: 900, multipv: 1, style: 'positional', lateMoveReduction: true, randomTop: 1 });

export function evaluateLeelaStyle(chess) {
  const board = chess.board();
  let score = materialScore(board) + positionalScore(board, 0.7) + pawnStructureScore(board) * 1.15 + kingSafetyScore(board) * 1.35;
  score += pieceActivityScore(board, { knight: 8, bishop: 7, rook: 1.5, queen: 1, pawnAdvance: 3 });
  let whiteBishops = 0; let blackBishops = 0;
  let phase = 0;
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p) continue;
    if (p.type === 'b') p.color === 'w' ? whiteBishops++ : blackBishops++;
    if (p.type === 'q') phase += 4; else if (p.type === 'r') phase += 2; else if (p.type === 'b' || p.type === 'n') phase += 1;
    if (p.type === 'n' && row >= 2 && row <= 5 && col >= 2 && col <= 5) {
      const enemyPawnControls = [-1, 1].some(dc => {
        const rr = row + (p.color === 'w' ? -1 : 1); const cc = col + dc;
        return rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && board[rr][cc]?.color !== p.color && board[rr][cc]?.type === 'p';
      });
      if (!enemyPawnControls) score += p.color === 'w' ? 13 : -13;
    }
  }
  score += (whiteBishops >= 2 ? 32 : 0) - (blackBishops >= 2 ? 32 : 0);
  const whiteKing = kingPosition(board, 'w'); const blackKing = kingPosition(board, 'b');
  if (whiteKing && blackKing && phase <= 8) {
    // In endgames, king activity matters more than staying behind the pawn shield.
    score += (centerValue(whiteKing.row, whiteKing.col) - centerValue(blackKing.row, blackKing.col)) * 8;
  }
  // Penalize exposed high-value pieces slightly, but do not mistake an attacked
  // piece for a lost piece; the full search must resolve exchanges.
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p || p.type === 'p' || p.type === 'k') continue;
    const enemy = p.color === 'w' ? 'b' : 'w';
    if (isAttacked(board, row, col, enemy)) score += (p.color === 'w' ? -1 : 1) * Math.min(10, (PIECE_VALUE[p.type] || 0) / 60);
  }
  return score;
}
