import { PIECE_VALUE } from './evaluation-utils.js';

const MATE_SCORE = 32000;
const INF = 33000;
const TT_EXACT = 0;
const TT_LOWER = 1;
const TT_UPPER = 2;
const DEFAULT_TT_SIZE = 30000;

const uciOf = move => `${move.from}${move.to}${move.promotion || ''}`;
const positionKey = chess => chess.fen().split(' ').slice(0, 4).join(' ');
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

function toTableScore(score, ply) {
  if (score > MATE_SCORE - 1000) return score + ply;
  if (score < -MATE_SCORE + 1000) return score - ply;
  return score;
}
function fromTableScore(score, ply) {
  if (score > MATE_SCORE - 1000) return score - ply;
  if (score < -MATE_SCORE + 1000) return score + ply;
  return score;
}

function moveOrderScore(move, ttMove, ply, ctx) {
  const uci = uciOf(move);
  if (uci === ttMove) return 2_000_000;
  if (move.promotion) return 1_000_000 + (PIECE_VALUE[move.promotion] || 0) * 10;
  if (move.captured) {
    const victim = PIECE_VALUE[move.captured] || 100;
    const attacker = PIECE_VALUE[move.piece] || 100;
    let score = 800_000 + victim * 16 - attacker;
    if (ctx.profile.style === 'tactical') score += victim * 2;
    if (move.san?.includes('#')) score += 900_000;
    if (move.san?.includes('+')) score += 2_000;
    return score;
  }
  if (move.san?.includes('#')) return 1_700_000;
  if (move.san?.includes('+')) return ctx.profile.style === 'aggressive' ? 120_000 : 65_000;
  if (ctx.killers[ply]?.[0] === uci) return 70_000;
  if (ctx.killers[ply]?.[1] === uci) return 60_000;
  const histKey = `${move.piece}${move.to}`;
  return ctx.historyHeuristic.get(histKey) || 0;
}

function orderedMoves(moves, ttMove, ply, ctx, capturesOnly = false) {
  const candidates = capturesOnly ? moves.filter(move => move.captured || move.promotion) : moves;
  return candidates.sort((a, b) => moveOrderScore(b, ttMove, ply, ctx) - moveOrderScore(a, ttMove, ply, ctx));
}

function rememberQuietCutoff(move, depth, ply, ctx) {
  if (move.captured || move.promotion) return;
  const uci = uciOf(move);
  const current = ctx.killers[ply] || [];
  if (current[0] !== uci) ctx.killers[ply] = [uci, current[0]].filter(Boolean).slice(0, 2);
  const key = `${move.piece}${move.to}`;
  ctx.historyHeuristic.set(key, clamp((ctx.historyHeuristic.get(key) || 0) + depth * depth * 12, -100000, 100000));
}

function staticScore(chess, evaluate) {
  const whiteScore = evaluate(chess);
  return chess.turn() === 'w' ? whiteScore : -whiteScore;
}

function stopSearch(ctx) {
  if (ctx.stopped) return true;
  if (ctx.nodes >= ctx.maxNodes) { ctx.stopped = true; return true; }
  // Avoid reading the clock for every node; this is materially cheaper on phones.
  if ((ctx.nodes & 127) === 0 && Date.now() >= ctx.deadline) { ctx.stopped = true; return true; }
  return false;
}

function hasNonPawnMaterial(chess) {
  const side = chess.turn();
  for (const row of chess.board()) for (const piece of row) {
    if (piece && piece.color === side && piece.type !== 'p' && piece.type !== 'k') return true;
  }
  return false;
}

function quiescence(chess, alpha, beta, ply, qply, ctx, evaluate) {
  ctx.nodes += 1;
  if (stopSearch(ctx)) return 0;
  if (chess.isDraw()) return 0;

  const inCheck = chess.isCheck();
  let standPat = -INF;
  if (!inCheck) {
    standPat = staticScore(chess, evaluate);
    if (standPat >= beta) return standPat;
    if (standPat > alpha) alpha = standPat;
    if (qply >= ctx.maxQply) return standPat;
  }

  const legalMoves = chess.moves({ verbose: true });
  if (!legalMoves.length) return inCheck ? -MATE_SCORE + ply : 0;
  if (inCheck && qply >= ctx.maxQply) {
    // At the safety cap, preserve terminal checkmate detection but avoid
    // recursively exploring an unbounded chain of checks.
    return staticScore(chess, evaluate) - 35;
  }
  const moves = inCheck ? orderedMoves(legalMoves, null, ply, ctx) : orderedMoves(legalMoves, null, ply, ctx, true);
  for (const move of moves) {
    if (stopSearch(ctx)) break;
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const score = -quiescence(chess, -beta, -alpha, ply + 1, qply + 1, ctx, evaluate);
    chess.undo();
    if (ctx.stopped) break;
    if (score >= beta) return score;
    if (score > alpha) alpha = score;
  }
  return inCheck && alpha === -INF ? -MATE_SCORE + ply : Math.max(alpha, standPat);
}

function negamax(chess, depth, alpha, beta, ply, ctx, evaluate, allowNull = true) {
  ctx.nodes += 1;
  if (stopSearch(ctx)) return 0;
  if (chess.isDraw()) return 0;
  const inCheck = chess.isCheck();
  if (inCheck && ply < 24) depth += 1; // check extension: never stand pat while in check
  if (depth <= 0) return quiescence(chess, alpha, beta, ply, 0, ctx, evaluate);

  const key = positionKey(chess);
  const entry = ctx.table.get(key);
  const originalAlpha = alpha;
  const originalBeta = beta;
  let ttMove = null;
  if (entry) {
    ttMove = entry.move;
    if (entry.depth >= depth && ply > 0) {
      const ttScore = fromTableScore(entry.score, ply);
      if (entry.flag === TT_EXACT) return ttScore;
      if (entry.flag === TT_LOWER) alpha = Math.max(alpha, ttScore);
      else if (entry.flag === TT_UPPER) beta = Math.min(beta, ttScore);
      if (alpha >= beta) return ttScore;
    }
  }

  // Null-move pruning (guarded): skipped in check, at shallow depth, and in pawn/king-only endings
  // where zugzwang makes it unsafe.
  if (allowNull && !inCheck && depth >= 3 && beta < MATE_SCORE - 1000 && hasNonPawnMaterial(chess)) {
    const fenParts = chess.fen().split(' ');
    fenParts[1] = fenParts[1] === 'w' ? 'b' : 'w';
    fenParts[3] = '-';
    let nullPos = null;
    try { nullPos = new chess.constructor(fenParts.join(' ')); } catch { nullPos = null; }
    if (nullPos) {
      const nullScore = -negamax(nullPos, depth - 3, -beta, -beta + 1, ply + 1, ctx, evaluate, false);
      if (!ctx.stopped && nullScore >= beta) return nullScore;
    }
  }

  // Late-move reduction: only reduce late quiet moves at sufficient depth.
  // (Null-move pruning above is guarded against check, shallow depth and pawn/king-only endings.)
  const moves = orderedMoves(chess.moves({ verbose: true }), ttMove, ply, ctx);
  if (!moves.length) return inCheck ? -MATE_SCORE + ply : 0;

  let bestScore = -INF;
  let bestMove = null;
  let moveIndex = 0;
  for (const move of moves) {
    if (stopSearch(ctx)) break;
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const quiet = !move.captured && !move.promotion && !move.san?.includes('+');
    let nextDepth = depth - 1;
    let score;
    if (ctx.profile.lateMoveReduction && moveIndex >= 4 && depth >= 3 && quiet && !inCheck) {
      score = -negamax(chess, nextDepth - 1, -alpha - 1, -alpha, ply + 1, ctx, evaluate, false);
      if (!ctx.stopped && score > alpha) score = -negamax(chess, nextDepth, -beta, -alpha, ply + 1, ctx, evaluate, false);
    } else if (moveIndex > 0) {
      // Principal-variation search: probe later moves with a null window, re-search only on a fail-high.
      score = -negamax(chess, nextDepth, -alpha - 1, -alpha, ply + 1, ctx, evaluate, true);
      if (!ctx.stopped && score > alpha && score < beta) score = -negamax(chess, nextDepth, -beta, -alpha, ply + 1, ctx, evaluate, true);
    } else {
      score = -negamax(chess, nextDepth, -beta, -alpha, ply + 1, ctx, evaluate, true);
    }
    chess.undo();
    if (ctx.stopped) break;
    moveIndex += 1;
    if (score > bestScore) { bestScore = score; bestMove = uciOf(move); }
    if (score > alpha) alpha = score;
    if (alpha >= beta) {
      if (quiet) rememberQuietCutoff(move, depth, ply, ctx);
      break;
    }
  }

  if (ctx.stopped) return bestScore === -INF ? 0 : bestScore;
  const flag = bestScore <= originalAlpha ? TT_UPPER : bestScore >= originalBeta ? TT_LOWER : TT_EXACT;
  if (ctx.table.size >= ctx.maxTableSize) {
    // Map insertion order is a cheap age approximation; keep memory bounded.
    const removeCount = Math.max(1, Math.floor(ctx.maxTableSize * 0.1));
    const keys = ctx.table.keys();
    for (let i = 0; i < removeCount; i += 1) { const next = keys.next(); if (next.done) break; ctx.table.delete(next.value); }
  }
  ctx.table.set(key, { depth, score: toTableScore(bestScore, ply), flag, move: bestMove });
  return bestScore;
}

/**
 * Iterative-deepening alpha-beta engine with capture quiescence, transposition
 * table, TT/capture/promotion/check/killer/history move ordering, a bounded
 * late-move reduction, and hard time/node limits suitable for phone browsers.
 */
export function searchBestMove(chess, engine, evaluate, options = {}) {
  const legalAtRoot = chess.moves({ verbose: true });
  if (!legalAtRoot.length) return null;
  // v3.25: full-strength personas search deeper/longer by default; beginner/blitz personas stay light.
  const weak = engine.id === 'blitz' || engine.id === 'rookie';
  const boost = weak ? 1 : 2.5;
  const requestedDepth = Number(options.depth) || ((engine.defaultDepth || 5) + (weak ? 0 : 1));
  const maxDepth = clamp(Math.floor(requestedDepth), 1, 9);
  const maxNodes = clamp(Math.floor(Number(options.maxNodes) || (engine.maxNodes || 30000) * boost), 500, 250000);
  const maxTimeMs = clamp(Math.floor(Number(options.maxTimeMs) || (engine.maxTimeMs || 800) * (weak ? 1 : 1.8)), 100, 6000);
  // Optional move variety: engines with randomTop > 1 (or options.varietyCp) pick at random among
  // root moves within a few centipawns of the best, so repeated games do not replay one line.
  const configuredVarietyCp = options.varietyCp ?? engine.varietyCp;
  const randomTop = Math.max(1, Math.floor(Number(engine.randomTop) || 1));
  const defaultVarietyCp = randomTop > 1 ? 14 * (randomTop - 1) : 0;
  const varietyCp = clamp(Math.round(Number(configuredVarietyCp ?? defaultVarietyCp) || 0), 0, 90);
  const startedAt = Date.now();
  const ctx = {
    profile: engine,
    nodes: 0,
    maxNodes,
    deadline: Date.now() + maxTimeMs,
    stopped: false,
    maxQply: clamp(Number(options.maxQply) || 8, 2, 12),
    maxTableSize: clamp(Number(options.maxTableSize) || DEFAULT_TT_SIZE, 1000, 200000),
    table: new Map(),
    killers: [],
    historyHeuristic: new Map(),
    completedDepth: 0
  };
  let bestMove = legalAtRoot[0];
  let bestScore = -INF;
  let previousBest = null;

  // Each completed iteration is a safe answer if the next iteration hits a
  // time/node cap. Root scores reset each depth to avoid a partial iteration
  // overwriting a previous valid best move.
  for (let depth = 1; depth <= maxDepth; depth += 1) {
    if (ctx.stopped || Date.now() >= ctx.deadline || ctx.nodes >= ctx.maxNodes) break;
    const ttEntry = ctx.table.get(positionKey(chess));
    const rootTtMove = ttEntry?.move || previousBest;
    const moves = orderedMoves(chess.moves({ verbose: true }), rootTtMove, 0, ctx);
    let iterationBest = null;
    let iterationScore = -INF;
    let alpha = -INF;
    const beta = INF;
    const scoredRoot = [];
    for (const move of moves) {
      if (stopSearch(ctx)) break;
      chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
      // With variety on, the window floor sits `varietyCp` below the best score so far:
      // every move that lands inside it gets an exact score and can be chosen at random.
      const windowFloor = varietyCp > 0 && iterationScore > -INF ? iterationScore - varietyCp : alpha;
      let score = -negamax(chess, depth - 1, -beta, -windowFloor, 1, ctx, evaluate);
      // Anti-repetition: positions already seen in the real game are penalised unless we are worse
      // (then a repetition is a welcome draw). Prevents shuffling the same moves back and forth.
      if (options.seen && score > -150 && score < MATE_SCORE - 1000) {
        const seenCount = options.seen[positionKey(chess)] || 0;
        if (seenCount > 0) score -= seenCount >= 2 ? 450 : 70 * seenCount;
      }
      chess.undo();
      if (ctx.stopped) break;
      scoredRoot.push({ move, score, exact: score > windowFloor || windowFloor === -INF });
      if (score > iterationScore) { iterationScore = score; iterationBest = move; }
      if (score > alpha) alpha = score;
    }
    if (ctx.stopped || !iterationBest) break;
    if (varietyCp > 0 && Math.abs(iterationScore) < MATE_SCORE - 100) {
      const near = scoredRoot.filter(item => item.exact && item.score >= iterationScore - varietyCp);
      if (near.length > 1) {
        const rng = typeof options.random === 'function' ? options.random : Math.random;
        const pick = near[Math.min(near.length - 1, Math.floor(Math.max(0, Number(rng()) || 0) * near.length))];
        iterationBest = pick.move;
      }
    }
    bestMove = iterationBest;
    bestScore = iterationScore;
    previousBest = uciOf(iterationBest);
    ctx.completedDepth = depth;
    const rootKey = positionKey(chess);
    ctx.table.set(rootKey, { depth, score: toTableScore(bestScore, 0), flag: TT_EXACT, move: previousBest });
    if (Math.abs(bestScore) >= MATE_SCORE - 100) break;
  }

  if (!bestMove) return null;
  return {
    uci: uciOf(bestMove),
    score: Number.isFinite(bestScore) ? bestScore : 0,
    depth: ctx.completedDepth,
    nodes: ctx.nodes,
    elapsedMs: Math.max(1, Date.now() - startedAt),
    nps: Math.round(ctx.nodes * 1000 / Math.max(1, Date.now() - startedAt)),
    stopped: ctx.stopped
  };
}


/**
 * Score every legal root move with a full window (used by the offline puzzle generator).
 * Returns [{ uci, san, score }] sorted best-first, scores from the mover's point of view.
 */
export function scoreRootMoves(chess, evaluate, options = {}) {
  const depth = clamp(Math.floor(Number(options.depth) || 3), 1, 6);
  const ctx = {
    profile: options.profile || { style: 'balanced', lateMoveReduction: false },
    nodes: 0, maxNodes: clamp(Math.floor(Number(options.maxNodes) || 60000), 500, 250000),
    deadline: Date.now() + clamp(Math.floor(Number(options.maxTimeMs) || 1200), 100, 6000),
    stopped: false, maxQply: 8, maxTableSize: 60000, table: new Map(), killers: [], historyHeuristic: new Map(), completedDepth: 0
  };
  const out = [];
  for (const move of chess.moves({ verbose: true })) {
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const score = chess.isCheckmate() ? MATE_SCORE : -negamax(chess, depth - 1, -INF, INF, 1, ctx, evaluate);
    chess.undo();
    if (ctx.stopped) return null;
    out.push({ uci: uciOf(move), san: move.san, score });
  }
  return out.sort((a, b) => b.score - a.score);
}
