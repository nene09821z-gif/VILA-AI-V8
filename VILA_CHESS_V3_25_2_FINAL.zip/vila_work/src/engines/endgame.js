import { centerValue, kingPosition, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, positionalScore } from './evaluation-utils.js';

// Endgame-oriented profile: passed pawns, rooks behind pawns and an active king. This is a VILA engine.
export const ENDGAME = Object.freeze({ id: 'endgame', name: 'VILA Endgame', defaultDepth: 5, maxNodes: 38000, maxTimeMs: 900, multipv: 1, style: 'endgame', lateMoveReduction: true, randomTop: 1 });

export function evaluateEndgame(chess) {
  const board = chess.board();
  let phase = 0;
  for (const row of board) for (const p of row) {
    if (!p) continue;
    phase += p.type === 'q' ? 4 : p.type === 'r' ? 2 : p.type === 'b' || p.type === 'n' ? 1 : 0;
  }
  const late = phase <= 10 ? 1 : phase <= 16 ? 0.5 : 0.15;
  let score = materialScore(board) + positionalScore(board, 0.9) + pawnStructureScore(board) * (1 + late) + kingSafetyScore(board) * (1.2 - late * 0.8);
  score += pieceActivityScore(board, { knight: 5, bishop: 5, rook: 1.5, queen: 0.5, pawnAdvance: 2.5 + late * 4 });
  const wk = kingPosition(board, 'w'); const bk = kingPosition(board, 'b');
  if (wk && bk) score += (centerValue(wk.row, wk.col) - centerValue(bk.row, bk.col)) * 9 * late;
  for (let col = 0; col < 8; col += 1) {
    let whiteRook = false; let blackRook = false; let whitePawn = false; let blackPawn = false;
    for (let row = 0; row < 8; row += 1) {
      const p = board[row][col]; if (!p) continue;
      if (p.type === 'r') p.color === 'w' ? whiteRook = true : blackRook = true;
      if (p.type === 'p') p.color === 'w' ? whitePawn = true : blackPawn = true;
    }
    if (whiteRook && !whitePawn) score += blackPawn ? 12 : 18;
    if (blackRook && !blackPawn) score -= whitePawn ? 12 : 18;
  }
  return score;
}
