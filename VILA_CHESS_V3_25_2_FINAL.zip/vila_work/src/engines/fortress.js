import { PIECE_VALUE, kingPosition, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, positionalScore, isAttacked, countAttackers } from './evaluation-utils.js';

// Solid, defensive profile: king shelter, healthy pawns and no loose pieces. This is a VILA engine.
export const FORTRESS = Object.freeze({ id: 'fortress', name: 'VILA Fortress', defaultDepth: 5, maxNodes: 34000, maxTimeMs: 850, multipv: 1, style: 'solid', lateMoveReduction: true, randomTop: 1 });

export function evaluateFortress(chess) {
  const board = chess.board();
  let score = materialScore(board) + positionalScore(board, 0.8) + pawnStructureScore(board) * 1.5 + kingSafetyScore(board) * 1.9;
  score += pieceActivityScore(board, { knight: 4, bishop: 4, rook: 1, queen: 0, pawnAdvance: 1.4 });
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p || p.type === 'k') continue;
    const enemy = p.color === 'w' ? 'b' : 'w';
    if (!isAttacked(board, row, col, enemy)) continue;
    const defenders = countAttackers(board, row, col, p.color);
    const attackers = countAttackers(board, row, col, enemy);
    const loose = defenders === 0 ? 1 : attackers > defenders ? 0.45 : 0;
    score += (p.color === 'w' ? -1 : 1) * loose * Math.min(34, (PIECE_VALUE[p.type] || 0) * 0.1);
  }
  for (const color of ['w', 'b']) {
    const king = kingPosition(board, color); if (!king) continue;
    // Prefer a king on its home side with pawns in front of it.
    const home = color === 'w' ? 7 : 0;
    if (Math.abs(king.row - home) <= 1) score += color === 'w' ? 10 : -10;
  }
  return score;
}
