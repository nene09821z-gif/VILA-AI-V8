import { Chess } from 'chess.js';
import { searchBestMove } from './engines/search-core.js';
import { LEELA_STYLE, evaluateLeelaStyle } from './engines/leela-style.js';
import { TACTICAL, evaluateTactical } from './engines/tactical.js';
import { AGGRESSIVE, evaluateAggressive } from './engines/aggressive.js';
import { evaluateVilaClassic } from './engines/vila-classic.js';
import { FORTRESS, evaluateFortress } from './engines/fortress.js';
import { ENDGAME, evaluateEndgame } from './engines/endgame.js';
import { DYNAMIC, evaluateDynamic } from './engines/dynamic.js';
import { BLITZ, evaluateBlitz } from './engines/blitz.js';
import { GAMBIT, evaluateGambit, HYPERMODERN, evaluateHypermodern, STRANGLER, evaluateStrangler, TRICKSTER, evaluateTrickster, ROOKIE, evaluateRookie } from './engines/personas.js';

// These are independent VILA evaluation engines sharing a common, stronger
// search kernel. They do not include the original upstream Lc0/Ethereal/Berserk.
export const ALTERNATE_ENGINE_PROFILES = Object.freeze({
  lc0: LEELA_STYLE,
  ethereal: TACTICAL,
  berserk: AGGRESSIVE,
  fortress: FORTRESS,
  endgame: ENDGAME,
  dynamic: DYNAMIC,
  blitz: BLITZ,
  gambit: GAMBIT,
  hyper: HYPERMODERN,
  strangler: STRANGLER,
  trickster: TRICKSTER,
  rookie: ROOKIE,
  classic: Object.freeze({ id: 'classic', name: 'VILA Classic', defaultDepth: 4, maxNodes: 30000, maxTimeMs: 750, style: 'balanced', lateMoveReduction: true, randomTop: 1 })
});

const evaluators = Object.freeze({
  lc0: evaluateLeelaStyle,
  ethereal: evaluateTactical,
  berserk: evaluateAggressive,
  fortress: evaluateFortress,
  endgame: evaluateEndgame,
  dynamic: evaluateDynamic,
  blitz: evaluateBlitz,
  gambit: evaluateGambit,
  hyper: evaluateHypermodern,
  strangler: evaluateStrangler,
  trickster: evaluateTrickster,
  rookie: evaluateRookie,
  classic: evaluateVilaClassic
});

/** Offline engines selectable in bot play and the arena (Stockfish is handled separately). */
export const OFFLINE_ENGINE_CATALOG = Object.freeze([
  { id: 'lc0', label: 'Leela-style', short: 'Leela-style AI', hint: 'định vị, kiểm soát trung tâm' },
  { id: 'ethereal', label: 'Tactical', short: 'Tactical AI', hint: 'ưu tiên chiến thuật' },
  { id: 'berserk', label: 'Aggressive', short: 'Aggressive AI', hint: 'chủ động tấn công' },
  { id: 'fortress', label: 'VILA Fortress', short: 'Fortress AI', hint: 'phòng thủ chắc, vua an toàn' },
  { id: 'endgame', label: 'VILA Endgame', short: 'Endgame AI', hint: 'tàn cuộc, tốt thông, vua hoạt động' },
  { id: 'dynamic', label: 'VILA Dynamic', short: 'Dynamic AI', hint: 'chiếm không gian, phát triển nhanh' },
  { id: 'blitz', label: 'VILA Blitz', short: 'Blitz AI', hint: 'nhanh, nông, hợp máy yếu' },
  { id: 'gambit', label: 'VILA Gambit', short: 'Gambit AI', hint: 'hy sinh tốt, tấn công vua sớm' },
  { id: 'hyper', label: 'VILA Hypermodern', short: 'Hypermodern AI', hint: 'siêu hiện đại, tượng chéo dài' },
  { id: 'strangler', label: 'VILA Strangler', short: 'Strangler AI', hint: 'chiếm không gian, bóp nghẹt' },
  { id: 'trickster', label: 'VILA Trickster', short: 'Trickster AI', hint: 'giăng bẫy, nhiều bất ngờ' },
  { id: 'rookie', label: 'VILA Rookie', short: 'Rookie AI', hint: 'người mới, dễ thở để luyện tập' }
]);
export const OFFLINE_ENGINE_IDS = Object.freeze(OFFLINE_ENGINE_CATALOG.map(item => item.id));
export function offlineEngineShortName(id) {
  return OFFLINE_ENGINE_CATALOG.find(item => item.id === id)?.short || 'AI ngoại tuyến';
}

function profileKey(value) {
  const candidate = String(value || 'classic').toLowerCase();
  return Object.prototype.hasOwnProperty.call(ALTERNATE_ENGINE_PROFILES, candidate) ? candidate : 'classic';
}

/** Return a legal UCI move from an offline VILA engine. */
export function chooseAlternateMove(fen, options = {}) {
  let chess;
  try { chess = new Chess(String(fen || '')); } catch { return null; }
  const key = profileKey(options.profile || options.engine);
  if (chess.isGameOver()) return null;
  const profile = ALTERNATE_ENGINE_PROFILES[key];
  const result = searchBestMove(chess, profile, evaluators[key], options);
  return result?.uci || null;
}

/** Diagnostics are exposed for local tests and optional analysis UI. */
export function analyzeAlternateMove(fen, options = {}) {
  let chess;
  try { chess = new Chess(String(fen || '')); } catch { return null; }
  const key = profileKey(options.profile || options.engine);
  if (chess.isGameOver()) return null;
  return searchBestMove(chess, ALTERNATE_ENGINE_PROFILES[key], evaluators[key], options);
}
