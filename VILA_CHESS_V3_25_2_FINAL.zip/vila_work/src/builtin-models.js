/**
 * Offline-visible quick presets. These entries are a convenience catalogue only;
 * an API key and provider-side quota/account access are still required.
 * Reviewed against official provider model/pricing pages on 2026-10-17. Free-tier access is quota-limited; no provider key is included.
 */
export const BUILTIN_FREE_MODEL_PRESETS = Object.freeze([
  { key: 'gemini-flash', provider: 'gemini', label: 'Gemini 3.8 Flash · Free Tier*', mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com', model: 'gemini-3.8-flash', free: true, note: 'Google AI Studio Free Tier; giới hạn và quyền truy cập tùy tài khoản.' },
  { key: 'gemini-flash-lite-31', provider: 'gemini', label: 'Gemini 3.1 Flash-Lite · Free Tier*', mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com', model: 'gemini-3.1-flash-lite', free: true, note: 'Model stable chi phí thấp theo danh mục chính thức; quota và quyền truy cập tùy tài khoản.' },
  { key: 'gemini-flash-previous', provider: 'gemini', label: 'Gemini 3.6 Flash · Free Tier*', mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com', model: 'gemini-3.6-flash', free: true, note: 'Google AI Studio Free Tier theo bảng giá hiện tại; kiểm tra khả dụng của project.' },
  { key: 'gemini-flash-lite', provider: 'gemini', label: 'Gemini 3.5 Flash-Lite · Free Tier*', mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com', model: 'gemini-3.5-flash-lite', free: true, note: 'Google Gemini API Free Tier; quota và quyền truy cập có thể khác theo tài khoản.' },
  { key: 'groq-oss-20b', provider: 'groq', label: 'Groq · GPT-OSS 20B · Free Plan*', mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1', model: 'openai/gpt-oss-20b', free: true, note: 'Có trong bảng hạn mức Free Plan của Groq; chịu giới hạn RPM/TPM/RPD.' },
  { key: 'groq-oss-120b', provider: 'groq', label: 'Groq · GPT-OSS 120B · Free Plan*', mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1', model: 'openai/gpt-oss-120b', free: true, note: 'Có trong bảng hạn mức Free Plan của Groq; chịu giới hạn RPM/TPM/RPD.' },
  { key: 'groq-oss-safe', provider: 'groq', label: 'Groq · GPT-OSS Safeguard 20B · Free Plan*', mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1', model: 'openai/gpt-oss-safeguard-20b', free: true, note: 'Có trong bảng hạn mức Free Plan của Groq; model kiểm duyệt, không phải lựa chọn chat nhanh nhất.' },
  { key: 'groq-qwen', provider: 'groq', label: 'Groq · Qwen3.8 27B · Free Plan*', mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1', model: 'qwen/qwen3.8-27b', free: true, note: 'Có trong bảng hạn mức Free Plan của Groq; quota và model còn hoạt động tùy nhà cung cấp.' },
  { key: 'openrouter-free', provider: 'openrouter', label: 'OpenRouter · Free Models Router*', mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1', model: 'openrouter/free', free: true, note: 'Router tự chọn một model miễn phí đang khả dụng; model đích và hạn mức thay đổi theo thời điểm.' }
]);

export function freePresetsForProvider({ mode = '', endpoint = '' } = {}) {
  const cleanMode = String(mode).toLowerCase();
  let host = '';
  try { host = new URL(endpoint).hostname.toLowerCase(); } catch {}
  return BUILTIN_FREE_MODEL_PRESETS.filter(item => {
    if (item.mode !== cleanMode) return false;
    try { return new URL(item.endpoint).hostname.toLowerCase() === host; } catch { return false; }
  });
}

export function isLocalNoKeyEndpoint(endpoint = '') {
  try {
    const url = new URL(endpoint);
    return ['localhost', '127.0.0.1', '[::1]', '::1'].includes(url.hostname.toLowerCase());
  } catch { return false; }
}
