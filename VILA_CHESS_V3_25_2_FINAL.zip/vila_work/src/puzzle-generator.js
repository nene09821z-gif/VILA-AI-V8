// Infinite offline puzzle generator (v3.25). No network, no Stockfish: it plays a random
// opening line + a few engine-guided moves, then asks VILA's own search to score every legal
// move. A position becomes a puzzle only when ONE move is clearly best (mate, or a large
// material/tactical gain) and the runner-up is much worse.
import { Chess } from 'chess.js';
import { searchBestMove, scoreRootMoves } from './engines/search-core.js';
import { evaluateVilaClassic } from './engines/vila-classic.js';
import { OPENINGS } from './openings.js';

const MATE = 30000;
const FILLER = Object.freeze({ id: 'puzzle-filler', name: 'filler', defaultDepth: 2, maxNodes: 4000, maxTimeMs: 40, style: 'balanced', lateMoveReduction: false, randomTop: 1 });
const yieldToUi = () => new Promise(resolve => setTimeout(resolve, 0));
const pick = (list, rng) => list[Math.min(list.length - 1, Math.floor(rng() * list.length))];

function buildStartPosition(rng, openings) {
  const chess = new Chess();
  const usable = openings.filter(o => Array.isArray(o.san) && o.san.length >= 4);
  if (usable.length && rng() < 0.85) {
    const line = pick(usable, rng).san;
    const cut = Math.max(4, Math.min(line.length, 4 + Math.floor(rng() * (line.length - 3))));
    for (const san of line.slice(0, cut)) { try { chess.move(san); } catch { break; } }
  }
  // Mix in guided + loose moves so the middlegame is varied and often tactical.
  const extra = 4 + Math.floor(rng() * 14);
  for (let i = 0; i < extra && !chess.isGameOver(); i += 1) {
    const legal = chess.moves({ verbose: true });
    if (!legal.length) break;
    let move;
    if (rng() < 0.45) {
      const found = searchBestMove(chess, FILLER, evaluateVilaClassic, { depth: 2, maxTimeMs: 40, varietyCp: 70, random: rng });
      move = found ? legal.find(m => `${m.from}${m.to}${m.promotion || ''}` === found.uci) : null;
    }
    if (!move) {
      const loud = legal.filter(m => m.captured || m.san.includes('+'));
      move = rng() < 0.3 && loud.length ? pick(loud, rng) : pick(legal, rng);
    }
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  }
  return chess;
}

function classify(chess, best, gap) {
  const move = chess.moves({ verbose: true }).find(m => `${m.from}${m.to}${m.promotion || ''}` === best.uci);
  if (!move) return null;
  const clone = new Chess(chess.fen());
  clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  let theme = 'Chiến thuật';
  if (clone.isCheckmate()) theme = 'Chiếu hết trong 1';
  else if (best.score >= MATE - 200) theme = 'Chiếu hết cưỡng bức';
  else if (move.promotion) theme = 'Phong cấp';
  else if (move.captured && clone.isCheck()) theme = 'Ăn quân kèm chiếu';
  else if (move.captured) theme = 'Thắng quân';
  else if (clone.isCheck()) theme = 'Chiếu mở đường';
  else theme = 'Nước im lặng (quiet move)';
  const level = gap >= 700 ? 'Dễ' : gap >= 350 ? 'Vừa' : 'Khó';
  return { theme, level, san: move.san, mateInOne: clone.isCheckmate() };
}

/**
 * Produce one validated puzzle. Resolves with { fen, best, san, theme, level, plies, mateOnly }
 * or null when the time budget is spent (caller can simply try again).
 */
export async function generateOfflinePuzzle({ rng = Math.random, budgetMs = 6000, openings = OPENINGS } = {}) {
  const deadline = Date.now() + budgetMs;
  while (Date.now() < deadline) {
    await yieldToUi();
    let chess;
    try { chess = buildStartPosition(rng, openings); } catch { continue; }
    if (chess.isGameOver() || chess.moves().length < 3) continue;
    const scored = scoreRootMoves(chess, evaluateVilaClassic, { depth: 3, maxNodes: 40000, maxTimeMs: 700 });
    if (!scored || scored.length < 3) continue;
    const [best, second] = scored;
    const gap = best.score - second.score;
    const mating = best.score >= MATE - 200;
    const winning = best.score >= 220 && best.score < MATE - 200;
    if (!(mating || winning) || gap < 160) continue;
    const info = classify(chess, best, gap);
    if (!info) continue;
    // Skip "free capture of a hanging queen" trivia when a quiet theme was possible: keep variety
    // by occasionally rejecting plain captures so quiet/mating ideas appear more often.
    if (info.theme === 'Thắng quân' && rng() < 0.4) continue;
    // Deeper verification of the single best move reduces horizon-effect false puzzles.
    const verify = scoreRootMoves(chess, evaluateVilaClassic, { depth: 4, maxNodes: 90000, maxTimeMs: 1400 });
    if (!verify || verify[0].uci !== best.uci || verify[0].score - (verify[1]?.score ?? -MATE) < 140) continue;
    return { fen: chess.fen(), best: best.uci, plies: chess.history().length, mateOnly: info.mateInOne, ...info };
  }
  return null;
}
