/** Select a Stockfish profile conservatively for mobile WebViews. */
export function resolveEngineProfile(preference = 'auto', device = {}) {
  if (preference === 'full-single') return 'full-single';
  if (preference === 'lite-single') return 'lite-single';
  // Stockfish 10 (classical eval, pure asm.js) is an optional, lighter engine for fast mistake-finding.
  if (preference === 'sf10') return 'sf10';
  // Lite is the default because Full is ~94 MB and not bundled by default.
  return 'lite-single';
}

/**
 * Initialization-only fallback chain. ASM-JS is slower, but does not depend on
 * WebAssembly and can rescue older/restricted Android WebViews.
 */
export function nextEngineFallback(profile) {
  if (profile === 'full-single') return 'lite-single';
  if (profile === 'sf10') return 'lite-single';
  if (profile === 'lite-single') return 'asm';
  return null;
}

export function engineAssetFile(profile) {
  if (profile === 'full-single') return 'stockfish-19-single.js';
  if (profile === 'asm') return 'stockfish-19-asm.js';
  if (profile === 'sf10') return 'stockfish-10.js';
  return 'stockfish-19-lite-single.js';
}

export function describeEngineProfile(preference = 'auto', device = {}) {
  const selected = resolveEngineProfile(preference, device);
  if (preference === 'auto') return `${selected === 'full-single' ? 'Full' : 'Lite'} (tự động)`;
  if (selected === 'sf10') return 'Stockfish 10 (thủ công)';
  return selected === 'full-single' ? 'Full (thủ công)' : 'Lite (thủ công)';
}
