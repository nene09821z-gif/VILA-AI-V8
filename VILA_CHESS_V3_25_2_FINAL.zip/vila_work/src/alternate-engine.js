import { chooseAlternateMove, analyzeAlternateMove } from './alternate-engine-core.js';
export { ALTERNATE_ENGINE_PROFILES, OFFLINE_ENGINE_CATALOG, OFFLINE_ENGINE_IDS, offlineEngineShortName, chooseAlternateMove, analyzeAlternateMove } from './alternate-engine-core.js';


let offlineWorker = null;
let offlineRequestSequence = 0;
let lastOfflineStats = null;
/** Depth / nodes / speed of the most recent offline search, for the speed chip. */
export function getLastOfflineEngineStats() { return lastOfflineStats; }
const offlineRequests = new Map();

function runOfflineSync(fen, options) {
  const result = analyzeAlternateMove(fen, options);
  if (result) lastOfflineStats = { depth: result.depth, nodes: result.nodes, elapsedMs: result.elapsedMs, nps: result.nps, score: result.score, at: Date.now() };
  return result?.uci || null;
}

function createOfflineWorker() {
  if (typeof Worker === 'undefined') return null;
  try {
    const worker = new Worker(new URL('./alternate-engine-worker.js', import.meta.url), { type: 'module' });
    worker.addEventListener('message', event => {
      const data = event.data || {};
      const pending = offlineRequests.get(data.id);
      if (!pending) return;
      offlineRequests.delete(data.id);
      clearTimeout(pending.timeout);
      if (data.error) pending.reject(new Error(data.error));
      else {
        if (data.stats) lastOfflineStats = { ...data.stats, at: Date.now() };
        pending.resolve(data.uci || null);
      }
    });
    worker.addEventListener('error', () => {
      worker.terminate();
      if (offlineWorker === worker) offlineWorker = null;
      for (const [id, pending] of offlineRequests) {
        offlineRequests.delete(id);
        clearTimeout(pending.timeout);
        // The UI remains functional on browsers without a working module worker.
        try { pending.resolve(runOfflineSync(pending.fen, pending.options)); }
        catch (error) { pending.reject(error); }
      }
    });
    return worker;
  } catch {
    return null;
  }
}

/** Prefer a module worker so deeper searches do not freeze the board animation. */
export function chooseAlternateMoveAsync(fen, options = {}) {
  const worker = offlineWorker || (offlineWorker = createOfflineWorker());
  if (!worker) {
    try { return Promise.resolve(runOfflineSync(fen, options)); }
    catch (error) { return Promise.reject(error); }
  }
  const id = ++offlineRequestSequence;
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      const pending = offlineRequests.get(id);
      if (!pending) return;
      offlineRequests.delete(id);
      reject(new Error('AI ngoại tuyến phản hồi quá thời gian. Hãy thử lại hoặc giảm độ sâu.'));
    }, Math.max(4000, Math.min(10000, Number(options.maxTimeMs || 1000) + 3500)));
    offlineRequests.set(id, { resolve, reject, timeout, fen, options });
    try { worker.postMessage({ id, fen, options }); }
    catch (error) {
      offlineRequests.delete(id);
      clearTimeout(timeout);
      reject(error);
    }
  });
}
