import { findOpeningBookMove } from './opening-book.js';

/**
 * Opening repertoires for the offline VILA bots. Each bot has a "home" family of openings,
 * so Gambit opens with gambits, Hypermodern with flank openings and so on. This only trims
 * the shared opening catalogue; every line is still a real, legal book line.
 *   white: first moves the bot plays as White (SAN)        black: replies keyed by White's 1st move
 *   hint:  optional name pattern; used when it matches enough lines     plies: book depth
 */
export const BOT_REPERTOIRES = Object.freeze({
  lc0:       { white: ['d4', 'c4', 'Nf3'], black: { e4: ['e5'], d4: ['d5', 'Nf6'], other: ['d5', 'Nf6'] }, plies: 10 },
  ethereal:  { white: ['e4'], hint: /italian|giuoco|ruy|spanish|scotch|vienna|evans/i, black: { e4: ['e5'], d4: ['d5', 'Nf6'], other: ['d5', 'e5'] }, plies: 10 },
  berserk:   { white: ['e4'], hint: /gambit|attack/i, black: { e4: ['c5'], d4: ['Nf6', 'd5'], other: ['c5', 'Nf6'] }, plies: 12 },
  fortress:  { white: ['d4', 'Nf3', 'c4'], hint: /london|catalan|queen'?s gambit|reti|english/i, black: { e4: ['c6', 'e6'], d4: ['d5', 'e6'], other: ['d5', 'e6'] }, plies: 10 },
  endgame:   { white: ['c4', 'Nf3', 'd4'], hint: /exchange|petrov|petroff|slav/i, black: { e4: ['e5'], d4: ['d5'], other: ['d5', 'e6'] }, plies: 8 },
  dynamic:   { white: ['e4', 'd4'], black: { e4: ['c5', 'e5'], d4: ['Nf6'], other: ['Nf6', 'c5'] }, plies: 10 },
  blitz:     { white: ['e4', 'd4', 'Nf3', 'c4', 'g3', 'b3', 'f4'], black: { e4: ['e5', 'c5', 'e6', 'c6', 'd5'], d4: ['d5', 'Nf6', 'f5'], other: ['d5', 'Nf6', 'e6'] }, plies: 8 },
  gambit:    { white: ['e4', 'd4', 'c4'], hint: /gambit/i, black: { e4: ['e5', 'd5'], d4: ['d5', 'f5', 'Nf6'], other: ['d5', 'e5'] }, plies: 12 },
  hyper:     { white: ['Nf3', 'c4', 'g3', 'b3'], hint: /indian|reti|english|modern|pirc|gr[uü]e?nfeld|benoni|nimzo|catalan/i, black: { e4: ['g6', 'd6', 'Nf6'], d4: ['Nf6'], other: ['Nf6', 'g6'] }, plies: 10 },
  strangler: { white: ['d4', 'c4'], hint: /queen'?s gambit|slav|catalan|nimzo|london|french|caro/i, black: { e4: ['e6', 'c6'], d4: ['d5', 'e6'], other: ['d5', 'e6'] }, plies: 10 },
  trickster: { white: ['e4', 'd4', 'b4', 'f4'], hint: /trap|gambit|englund|elephant|budapest|danish|latvian|from/i, black: { e4: ['e5', 'd5', 'Nf6'], d4: ['d5', 'f5', 'e5'], other: ['d5', 'e5'] }, plies: 12 },
  rookie:    { white: ['e4', 'd4'], black: { e4: ['e5'], d4: ['d5'], other: ['d5', 'e5'] }, plies: 6 },
  classic:   { white: ['e4', 'd4', 'Nf3', 'c4'], black: { e4: ['e5', 'c5'], d4: ['d5', 'Nf6'], other: ['d5', 'Nf6'] }, plies: 10 }
});

const poolCache = new WeakMap();

/** Opening lines that fit one bot's repertoire for one colour (cached per catalogue array). */
export function repertoireLines(openings, botId, color) {
  const rep = BOT_REPERTOIRES[botId];
  if (!rep || !Array.isArray(openings)) return [];
  let perBot = poolCache.get(openings);
  if (!perBot || perBot.length !== openings.length) { perBot = { length: openings.length, map: new Map() }; poolCache.set(openings, perBot); }
  const key = `${botId}:${color}`;
  if (perBot.map.has(key)) return perBot.map.get(key);
  const family = openings.filter(opening => {
    const san = opening?.san; if (!Array.isArray(san) || !san.length) return false;
    if (color === 'w') return rep.white.includes(san[0]);
    const replies = rep.black[san[0]] || rep.black.other || [];
    return san.length < 2 || replies.includes(san[1]);
  });
  const themed = rep.hint ? family.filter(opening => rep.hint.test(String(opening.name || ''))) : [];
  // Themed lines first, but never starve the book: fall back to the whole family.
  const pool = themed.length >= 4 ? themed : family;
  perBot.map.set(key, pool);
  return pool;
}

/** A legal opening-book move for this bot, or null when the position is out of its book. */
export function pickPersonaBookMove(chess, botId, openings, options = {}) {
  const rep = BOT_REPERTOIRES[botId] || BOT_REPERTOIRES.classic;
  const color = chess.turn();
  const pool = repertoireLines(openings, BOT_REPERTOIRES[botId] ? botId : 'classic', color);
  if (!pool.length) return null;
  return findOpeningBookMove(chess, pool, { maxPlies: rep.plies, recentChoices: options.recentChoices, random: options.random });
}
