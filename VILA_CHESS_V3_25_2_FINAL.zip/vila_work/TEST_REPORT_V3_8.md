# VILA Chess v3.8.0 — Test Report

## Passed in this workspace
- `npm run test:static`: **106/106 passed**.
- JavaScript/MJS syntax checks passed for all files in `src`, `server`, `scripts` and `tests`.
- JSON configuration files parse successfully.
- `scripts/package-android-source.py` compiles successfully.
- Regression coverage includes OpenAI Responses output arrays, nested gateway wrappers, Gemini thought filtering, whitespace-safe SSE assembly for OpenAI-compatible/Gemini/Anthropic, plain-text diagnostics, API-key redaction, drag ghost compositing, lost pointer capture cleanup and stale promotion-dialog guards.

## Blocked / not claimed as verified
- `npm test`: **106 passed, 1 test file failed to load** because `chess.js` is not installed (`ERR_MODULE_NOT_FOUND`, `tests/chess.test.js`). `npm run build` is also blocked because the installed Stockfish package/assets are absent. Dependency install/build has not completed in this environment.
- No live external provider/API request was made; provider key, endpoint, model permission, quota and service behavior were unavailable.
- No physical OPPO A17k / Android 12 WebView test was run, so actual touch latency is not measured here.
- No APK is included in this source ZIP. GitHub Actions must complete dependency installation, full tests, Vite/Stockfish asset build, Capacitor/Gradle generation and `assembleDebug` before the APK can be considered build-verified.
