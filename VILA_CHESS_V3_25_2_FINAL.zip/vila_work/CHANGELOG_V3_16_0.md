# VILA Chess v3.16.0 — Offline AI Profiles

- The alternative chess-AI mode now searches moves locally in the app and no longer calls `/api/engines/analyze`.
- Added three local play profiles: Leela-style positional, tactical, and aggressive. They use VILA's JavaScript search with `chess.js` legal move generation.
- The settings text clarifies that these are VILA profiles inspired by play styles, not the upstream Lc0/Ethereal/Berserk binaries. They require no backend, binary download, neural weights, API, or network connection.
- Existing Stockfish, VILA Classic, online/API, board artwork, and random-side selection remain in place.
- Added tests covering legal UCI moves, checkmate/no-move positions, invalid FEN, and profile configuration.
