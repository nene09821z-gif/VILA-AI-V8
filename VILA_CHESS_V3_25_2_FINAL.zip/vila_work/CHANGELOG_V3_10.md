# VILA Chess v3.10.0 — Daily Progress & Fair Cosmetics

## Added
- Daily check-in, daily missions, consecutive-day streak, claim-once rewards and in-game virtual coins.
- Four missions: check in, finish a game, visit the opening library and visit AI Coach. The game-completion mission is triggered after an eligible local-rated Stockfish/API-AI game is recorded.
- Cosmetic board shop with classic, ocean, walnut and midnight themes. Virtual coins can only buy cosmetic themes; they do not grant competitive advantages.
- Board theme previews, owned/equipped states, no overspending, and persistence in local storage. The selected theme carries into the game board and AI arena.
- Separate Nhiệm vụ and Cửa hàng navigation, home dashboard mission summary, virtual coin balance and activity streak.
- New isolated module `src/daily-progress.js` plus 5 unit tests for day rollover, streaks, reward claims, mission progress, and cosmetic purchases.

## Monetization status
- The virtual-coin shop is a retention feature, not a real-money store. It has no payment SDK, active ad unit, paid purchase or claim that it produces income.
- `MONETIZATION_V3_10.md` records the next launch-safe steps for optional rewarded ads and Google Play digital purchases.

## Not verified yet
- The five daily-progress unit tests pass in this environment. Full dependency installation, full test suite, Vite build, Capacitor/Gradle APK, Android device UI test, production OAuth and hosting/load/security testing have not been completed here. Run the provided GitHub Actions build and require it to pass before release.
