# VILA Chess v3.13.0 — Hybrid Engine Hub

- Kept the existing bundled Stockfish as the offline default.
- Added a real server-side UCI engine registry for Stockfish, Leela Chess Zero (Lc0), Ethereal, and Berserk.
- Added `/api/engines` readiness reporting based on actual executable files; Lc0 also requires an existing weights file.
- Added `/api/engines/analyze` with engine allowlisting, FEN shape validation, bounded think time, bounded wall-clock timeout, and shell-free subprocess launch.
- Added tests that verify engine status reporting and clear failures when optional engines are not configured.
- Added `ENGINE_HUB_SETUP_V3_13.md` and environment variable documentation.

## Not included / not claimed
- Engine binaries and Lc0 weights are not bundled.
- The in-app game UI is not yet wired to choose remote engines; local bot gameplay still uses the existing Stockfish integration.
- No Android APK build or live binary smoke test was performed in this environment.
