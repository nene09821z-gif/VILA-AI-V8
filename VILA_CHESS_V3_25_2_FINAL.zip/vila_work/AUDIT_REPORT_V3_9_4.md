# Audit report — VILA Chess v3.9.4

## Changes made

### Review annotations
- Added a consistent symbol mapper for book, brilliant, best, excellent, good, inaccuracy, mistake and blunder categories.
- Applied the mapper to the initial completed-game review render and to the live DOM update after each analyzed position.
- Added a compact Vietnamese legend and accessible `title`/`aria-label` text. Saved review rows without a judgement remain unannotated rather than receiving a made-up symbol.
- Replay position text appends the stored annotation when an evaluation exists.
- Symbols and judgement labels are local approximations; they are not claimed to be official Chess.com classifications.

### Target strength 500–3200
- Settings schema clamps targets to 500–3200.
- Quick play selection exposes targets every 100 Elo; the numeric Settings input accepts steps of 10; the AI arena uses 500–3200.
- For 1320–3190, the app uses Stockfish `UCI_LimitStrength` + `UCI_Elo`.
- The UI retains 3200 as the requested target but maps it to UCI_Elo 3190, the engine option maximum.
- Below 1320, the app does not send an unsupported UCI_Elo. It sets Skill Level 0 and probabilistically mixes in legal heuristic / random legal moves. The opening book is bypassed in this band so beginner targets are not artificially boosted by memorized openings.
- These numbers are target labels, not certified ratings. Playing strength is not calibrated and will vary with position, time limit and device.

Stockfish option reference: https://official-stockfish.github.io/docs/stockfish-wiki/Stockfish-FAQ.html (`UCI_Elo` has a supported range around 1320–3190; `UCI_LimitStrength` takes precedence over `Skill Level`).

## Checks performed
- `node --check src/main.js`, `src/elo-strength.js`, `src/game-review.js`: passed.
- `node --test tests/game-review.test.js tests/elo-strength.test.js tests/settings-schema.test.js tests/elo.test.js`: 20/20 passed.
- `npm run test:static`: 128/128 passed.
- JSON parse of `package.json`: passed.
- YAML parse of both GitHub Actions workflows: passed; both workflows now syntax-check `src/elo-strength.js`.
- Full `npm test`: 128 passed, one test file could not load because `chess.js` is not installed in this environment.
- `npm run build`: blocked at `prebuild` because `scripts/prepare-openings.mjs` cannot import missing `chess.js`; dependencies were not installed successfully in this environment, so no APK build is claimed.
