# VILA Chess v3.20.0 — Board Consistency Audit

## Scope
- Main play board
- Arena board
- Ranked board
- Puzzle board
- Game-review replay board

## Changes
All board renderers now use the same CSS theme variables for green/cream squares, with separate variables for last-move and selected-square states. The five board renderers share local original SVG piece artwork and consistent sizing rules. Chess logic and move validation were not changed.

## Verification
- Regression tests assert shared palette selectors and SVG-piece styling for every board renderer.
- Targeted test suites were run after the changes.
- Full production build/device verification remains dependent on installing project dependencies and running the app in a browser/Android environment.
