# VILA Chess v3.22.3 — deterministic Elo and release-gate follow-up

## Changes in this revision
- Removed random K-factor and random winner bonus from server-ranked match settlement.
- Server Elo now uses a fixed K-factor of 24 and only the pre-game ratings plus the actual score. Same ratings/result produce a deterministic rating calculation; equal-rated win/loss deltas are symmetric.
- Updated version assertions and project version to 3.22.3.

## Verification in this environment
- `node --check server/ranked-chess.js`: passed.
- `node --check server/social.js`: passed.
- Focused tests for ranked Elo, local Elo, and Elo strength: see current test run results.
- Full `npm test`: cannot pass until dependencies are installed. Current environment has no `node_modules`; `npm install --no-audit --no-fund` timed out. `chess.js` and `express` are missing, causing dependency-based tests to fail to load.
- `npm run build`: blocked in `prebuild` because `chess.js` is missing; no production bundle or Android artifact has been built in this environment.

## Remaining release gates
- Install dependencies successfully and generate/commit a lockfile from a network-enabled environment.
- Run the complete test suite and production build.
- Run browser/Android integration tests for recovery, end-of-game result reasons, analysis graph navigation, API rate limits/timeouts, and server idempotency under retries.
- The server currently persists JSON state in a single process. Multi-instance production deployment still requires transactional shared storage and database-level idempotency.
