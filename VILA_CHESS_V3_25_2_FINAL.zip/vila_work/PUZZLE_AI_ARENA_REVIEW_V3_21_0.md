# VILA Chess v3.21.0 — Puzzle / AI / Arena review

## Changes in this package
- Puzzle generation samples longer random legal positions and evaluates up to seven candidates with the existing Stockfish UCI integration, using depth 16 and a slightly longer search budget.
- Puzzle mode now tracks current streak, best streak, and solve duration in local storage/state; a wrong move resets the current streak.
- Existing puzzle answer validation remains tied to the Stockfish-selected UCI move; legal moves continue to be enforced by chess.js.
- Existing SVG piece renderer is reused.

## Validation
- `node --check src/main.js`: passed.
- This ZIP does not include `node_modules`; full app build, browser interaction, network/API integration, and Android device testing were not run in this environment.
- Random-position puzzles are generated from legal positions and are not a curated/verified tactical puzzle database. They can produce positional puzzles; the app labels these accordingly.
- No external AI API key is embedded. Online AI providers need user-configured endpoint/key and backend-side secret storage.
