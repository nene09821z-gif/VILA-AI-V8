# VILA Chess v3.10.1 — session fixes, notifications, diagnostics

## Changes

- Added a real session persistence function for the existing server authentication flow. Successful login/register responses must contain both a server token and a user profile before the UI reports success.
- Synced the header account control with the authenticated profile and made stale cached profiles disappear when there is no saved session.
- Added a compact in-app notification inbox with unread count, read-all and clear-read operations. This is **in-app storage**, not Android push notifications.
- Added the **Kiểm tra hệ thống** view. It checks observed engine initialization state, Worker API availability, local storage read/write, the current opening count and a real `/api/health` backend response.
- Added user-visible notifications for Stockfish failures and opening-catalog load/validation problems.
- Added a non-blocking V logo fallback if the brand image fails to load.
- Prevented full page redraws on ordinary chess moves, keeping updates focused on the board and move state.
- Added clear native-app errors when a backend URL is missing rather than silently calling a relative URL for login/OAuth.
- Tightened the release build: the official Lichess ECO importer must produce at least 3,000 valid, unique lines, and the generated web build is checked again. A release build fails rather than silently packaging an empty opening catalog.
- Updated the embedded backend health version to 3.10.1 and added authentication, notification and diagnostics regression tests.

## Opening data integrity note

The supplied v3.10.0 ZIP did **not** contain a 3,000+ opening catalog: `src/openings.js` contained 81 curated entries and `public/openings-eco.json` contained an empty `openings` array. The existing curated opening records have been left intact. No fake opening records were generated. The build now obtains the CC0 Lichess ECO catalog when the build environment can reach the upstream repository, validates the resulting lines, and fails release packaging if 3,000 entries are not present.
- Upgraded GitHub Actions dependencies to current Node 24-compatible major releases (`checkout@v7`, `setup-node@v7`, `setup-java@v6`, `upload-artifact@v7`) so the workflow does not keep relying on actions that run on the retired Node 20 runtime.
