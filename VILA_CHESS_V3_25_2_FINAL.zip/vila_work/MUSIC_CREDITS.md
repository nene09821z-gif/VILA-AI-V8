# Music credit

The in-app optional online piano music is **“Gymnopedie No. 1 (ISRC USUAN1100787)”**, performed by Kevin MacLeod. The recording is hosted at Wikimedia Commons and is published under the **Creative Commons Attribution 3.0 Unported (CC BY 3.0)** license.

- Source page: https://commons.wikimedia.org/wiki/File:Gymnopedie_No._1_(ISRC_USUAN1100787).mp3
- Streaming file: https://upload.wikimedia.org/wikipedia/commons/2/2a/Gymnopedie_No._1_%28ISRC_USUAN1100787%29.mp3
- Attribution: “Gymnopedie No. 1” by Kevin MacLeod, licensed under CC BY 3.0.
- License: https://creativecommons.org/licenses/by/3.0/

The app streams the recording only after the user enables music. It is not bundled into the APK. If offline, blocked, or unavailable, the app plays a gentle Web Audio-generated ambient motif instead.
