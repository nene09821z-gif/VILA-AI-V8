# Audit report — Chess Bot AI Arena v2.9.0

## Summary

Version 2.9.0 updates board layout measurement, responsive styles, and Stockfish UCI initialization behavior while retaining existing application features.

## Changes reviewed

- Responsive board geometry is computed from available container width and actual board width in CSS pixels.
- Layout resync is scheduled on `ResizeObserver`, window resize/orientation changes, and `visualViewport.resize`.
- Main and Arena boards use the same 8×8 geometry and derive piece sizing from square size.
- Stockfish thread/hash options are configured once during UCI initialization, avoiding per-move hash resets. `ucinewgame` is reserved for new games/rounds.
- Late `readyok` messages do not clear a failed-engine state.
- Package version and `/api/health` version are 2.9.0.

## Test evidence

- `npm run test:static`: 55/55 pass.
- `npm test`: 55 pass, 1 cannot start because `chess.js` is absent from `node_modules` (`ERR_MODULE_NOT_FOUND`). Dependency installation exceeded the environment time limit.
- Syntax checks pass for `src/main.js`, `src/board-layout.js`, and `server/index.js` at the latest targeted check.

## Residual risks / non-claims

- Full chess-rule tests are not green until dependencies install and `tests/chess.test.js` runs.
- No verified production web/Capacitor/Gradle build or APK was produced in this environment.
- No actual Stockfish WASM UCI benchmark, provider live API benchmark, or OPPO A17k hardware test was performed.
- UI and board-size unit tests are not equivalent to manual touch/FPS/rotation tests on an actual Android WebView.
