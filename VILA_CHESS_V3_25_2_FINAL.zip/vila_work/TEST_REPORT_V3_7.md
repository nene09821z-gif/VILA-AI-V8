# VILA Chess v3.7.0 — Test Report

## Passed
- `npm run test:static`: **100/100 passed, 0 failed**.
- Source includes regression checks for touch-click suppression, fixed mobile controls, compact setup, animation-frame drag updates, board DOM selection updates, and bounded empty-text retries for AI Coach / AI move / AI Arena.
- `node --check` passed for all `.js` and `.mjs` files checked before final packaging.
- JSON configuration files parse successfully.
- Python source files compile successfully.
- ZIP CRC/integrity check passed after the final archive was created.

## Blocked / not claimed as verified
- `npm test`: 98 tests passed, 1 test file failed to load because `chess.js` is not installed (`ERR_MODULE_NOT_FOUND`).
- `npm install --ignore-scripts --no-audit --no-fund` timed out in this environment, so a dependency-backed Vite/Capacitor production build could not be completed locally.
- No live external AI API request was made; the user’s own provider, API key, endpoint, quotas and model permissions are not available for validation.
- No physical OPPO A17k / Android 12 WebView test was run. The input/render optimizations are code-reviewed and statically tested, but actual touch latency must be confirmed on device.

## Release interpretation
This is a **source ZIP for GitHub Actions**, not a compiled APK. The GitHub workflow must finish successfully before treating the resulting APK as build-verified.
