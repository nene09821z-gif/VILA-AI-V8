# Build Android bằng GitHub Actions
1. Đẩy thư mục dự án lên GitHub (nhánh main).
2. Tab **Actions** → chạy **VILA Chess build from ZIP/source** (cũng tự chạy khi push).
3. Tải APK ở mục Artifacts: `vila-chess-debug-apk`.
