# VILA Chess v3.9.0 — Expanded Openings & Chess.com-Inspired Play Room

- Adds a build-time refresher for the CC0 Lichess ECO dataset (`a.tsv`–`e.tsv`). Every candidate move sequence is parsed through `chess.js`; duplicate lines are removed, and a refresh smaller than the safety threshold is rejected. If network refresh fails, the curated catalog remains available.
- Merges up to 5,000 unique opening entries into the curated catalog at runtime without replacing the seed, preserves provider/source metadata, filters malformed SAN strings, and supports paginated search/filter by move text, opening name and ECO code.
- Builds prefix tries for opening-book decisions and opening recognition; caches are refreshed when the shared catalog array grows, so lines loaded after app startup are not ignored.
- Refreshes the play room with a Chess.com-inspired dark board area and green/cream board palette, opponent/profile line, clocks, opening-recognition status, engine analysis, move/context panels, setup disclosure and responsive mobile layout. This is an inspired visual arrangement, not an official Chess.com integration or pixel-perfect clone.
- Preserves existing VILA features: Stockfish, AI/API modes, local two-player, clocks, move history, hints, analysis, Arena, Coach, PGN, Lichess, local Elo and provider configuration.
- Adds regression tests for catalog merging/caps, duplicate and malformed entries, dynamic trie invalidation, opening pagination, responsive play-room structure and CI build wiring. Static suite passes 114/114.
- Does not claim a successful full dependency-backed test, production build, GitHub Actions run, live API request or physical-device test from the authoring environment.
