# Changelog v3.2.0

- Fixed start actions so a fresh app session remains in setup until the user starts a match.
- Kept drag with a finger alongside tap-to-select move controls.
- Added/retained result panel, resignation, PGN output, full-game Stockfish review, move judgement and AI explanation.
- Hardened Stockfish Worker timeout handling: terminate the worker instead of relying only on `stop`, clear request identities, expose retry by tapping engine status.
- Added/retained evaluation bar and arrow overlay from engine suggestion/MultiPV line.
- Shipped bundled free-tier model presets for Gemini, Groq and OpenRouter free router; no API key embedded.
- Expanded static checks and GitHub Actions JS syntax validation.
- Tests: 77/77 static tests pass. Full rule/line validation and actual Android/Stockfish/API runtime remain release gates due to unavailable dependency installation in the authoring environment.
