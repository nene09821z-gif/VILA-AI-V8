# VILA Chess v3.18.0

## Giao diện bàn cờ và ghi chú
- Mặc định bàn cờ dùng tông gỗ vàng/nâu với vân nhẹ, gần bàn cờ gỗ trong ảnh tham chiếu. Bộ quân cờ SVG tự vẽ, đồng nhất giữa nền tảng, vẫn giữ nguyên luật cờ `chess.js`.
- Chuyển thanh công cụ mũi tên/khoanh ô ra hàng riêng dưới bàn cờ để không che ô hay quân. Giữ thao tác kéo bằng Pointer Events, lưu vị trí theo layout mới và tự ẩn cả hàng khi chế độ hiện tại không hỗ trợ chú thích.
- Khi thu gọn, thanh công cụ nhỏ hơn và bỏ tay nắm kéo khỏi chế độ thu gọn.

## Nhạc nền
- Có nút nhạc nền cố định trên thanh trên cùng và nút đồng bộ trên Trang chủ / màn Chơi cờ.
- Tùy chọn tự bật mặc định bắt đầu nhạc sau thao tác đầu tiên của người dùng vì WebView/trình duyệt thường chặn tự phát trước tương tác. Có thể tắt trong Cài đặt.
- Giữ bản piano Gymnopédie No. 1 và nhạc tổng hợp dự phòng offline. Liên kết YouTube chỉ mở tìm kiếm ngoài ứng dụng; không nhúng hoặc tải trái phép bản nhạc trẻ đang thịnh hành.

## Elo, admin và API
- Thêm `ADMIN_INITIAL_ELO` cho backend (mặc định 3200, giới hạn 100–4000); chỉ áp dụng cho admin bootstrap mới hoặc admin cấu hình có 0 ván Elo và chưa đánh dấu seed. Rating của admin đã có ván được giữ nguyên.
- Gắn nhãn minh bạch “Admin · Elo khởi tạo” trong Top 100 để không gây hiểu nhầm đây là rating được chứng nhận.
- Đồng bộ version package, health endpoint và tiêu đề app lên 3.18.0. Không nhúng API key mặc định; cấu hình endpoint và key của nhà cung cấp vẫn phải được người triển khai/người dùng cung cấp.

## Kiểm chứng
- Có regression tests mới cho vị trí thanh chú thích, nhạc nền và Elo admin.
- `npm run test:static`: 168/168 đạt; `node --check` qua cho các tệp JS chính.
- Build web/APK chưa xác nhận: môi trường không có `chess.js`/`express` và npm registry đang lỗi DNS (`EAI_AGAIN`). `npm test` vì thế còn 3 suite tích hợp không thể khởi động. Chưa thử trên thiết bị Android thực.
