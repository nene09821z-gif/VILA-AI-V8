# Test report — v3.0.0

## Local checks
- `npm run test:static`: **60 passed, 0 failed**.
- `node --check` on app/server/test/script JavaScript modules: passed.
- Opening inventory: 71 entries, unique display names, required metadata present.
- ZIP archive integrity: will be verified after packaging.

## Not run / not passed
- Full `npm test`: depends on `chess.js`; this environment has no `node_modules` and registry access failed with DNS `EAI_AGAIN`.
- SAN legality test for all 71 opening lines: test is included in `tests/chess.test.js` and will run in GitHub Actions, but has not run locally here due the same missing dependency.
- `npm run build`, `assembleDebug`, actual Stockfish JS/WASM UCI startup, live Gemini/Groq/OpenRouter API-key requests, device audio, and on-device OPPO A17k/DPI 360 UI checks were not run.

## Release gate
Do not label this release device-verified until GitHub Actions passes `npm test`, `npm run build` and Android debug APK generation, then install/test the APK on the target device.
