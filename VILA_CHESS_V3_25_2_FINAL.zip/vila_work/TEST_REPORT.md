# Test report — Chess Bot AI Arena v3.2.0

See [`TEST_REPORT_V3_2.md`](TEST_REPORT_V3_2.md) for full details.

- Static suite: **77 passed, 0 failed** (`npm run test:static`).
- Full `npm test`: **77 passed, 1 test module failed to load** because `chess.js` is not installed in the current authoring sandbox (`ERR_MODULE_NOT_FOUND`). npm registry access failed here, so this is reported as blocked rather than passed.
- JavaScript syntax checks and ZIP integrity checks are run before packaging.
- Live Stockfish WASM/UCI, provider credentials, Android Gradle build, and OPPO A17k UI/performance remain unverified in this environment.
