# VILA Chess monetization roadmap (v3.10)

## Shipped in this source ZIP
- Daily challenges, activity streaks and cosmetic board themes bought only with local virtual coins.
- No real-money payment or live advertising is enabled. Virtual coins have no cash value and cannot be withdrawn. Do not market them as money.

## Safe sequence to a real revenue test
1. Ship a stable free MVP, collect consent-compliant analytics, test crash-free sessions and see whether new players return after day 1/day 7. Do not buy traffic until retention is credible.
2. If distributing through Google Play, create a developer account and complete store listing, privacy policy, age/content declarations and support contacts.
3. For an optional rewarded-ad experiment, integrate the native Google Mobile Ads SDK through a maintained Capacitor plugin/native bridge; explain the reward before showing an ad, grant it only from the SDK reward callback, provide a skip route, handle no-fill/network failures, and start with Google's test ad unit IDs. Replace test IDs only after an approved production app/ad setup. Never force an ad in the middle of a chess move.
4. For paid digital cosmetics or an ad-free option sold in a Google Play-distributed Android app, integrate Google Play Billing and verify purchases/entitlements on a backend. Do not treat the client success callback alone as proof of a purchase. Configure product IDs/prices in Play Console, test pending/cancelled/refunded flows, and sync transaction state on the server.
5. Keep competitive fairness: no paid Elo, engine strength, match outcome changes or rank boosts. Prefer themes, avatars and optional ad-free access.
6. Before release, publish a privacy policy, request only necessary permissions, document advertising/analytics processing, respect applicable child/privacy rules, and test with Play's internal testing track.

## Official implementation references
- Google AdMob rewarded ads (includes the test ad-unit guidance): https://developers.google.com/admob/android/rewarded
- Google Play Billing integration: https://developer.android.com/distribute/play-billing/
- Google Play Billing backend validation and purchase lifecycle: https://developer.android.com/google/play/billing/backend
- Google Play payments policy: https://support.google.com/googleplay/android-developer/answer/10281818

## Revenue expectation
Revenue is not guaranteed. Ad income depends on eligible impressions, geography, fill rate, user retention and advertiser demand; purchase income depends on product-market fit. Never promise income from the game before it is accepted, published, tested and generating actual sales/ad earnings.
