# VILA Chess v3.14.0 — Board art and Android rendering

- Replaced the simple chess-piece outlines with six original, locally rendered Staunton-style SVG silhouettes for king, queen, rook, bishop, knight, and pawn. All board surfaces share the same renderer.
- Fixed manual analysis annotation color classes so green, red, and yellow arrows/circles use their intended styles.
- Changed the draggable annotation toolbar to coalesce pointer movement with `requestAnimationFrame` and use `translate3d` while moving; final coordinates are committed once at gesture end.
- Removed toolbar backdrop blur and expensive SVG drop-shadow filters from pieces and annotation lines to reduce WebView repaint/compositing work.
- Added static regression tests for all six SVG types, annotation colors, and mobile drag rendering.
- Bumped the app package version to 3.14.0.

## Verification boundaries

- JavaScript syntax and static Node test checks can be run without installing project dependencies.
- No Android APK build or on-device frame-rate measurement is claimed in this release note.
