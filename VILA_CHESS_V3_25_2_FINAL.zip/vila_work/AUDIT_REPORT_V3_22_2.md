# VILA Chess v3.22.2 — focused stability audit

## Fixes in this revision
- Local game recovery is now wired into real lifecycle points: fresh game, every legal move, and `pagehide`.
- Recovery uses a versioned snapshot with a unique game session ID and replayable coordinate moves. Restore replays every move through `chess.js` and verifies the resulting FEN before accepting it; malformed, stale, finished, unsupported-mode, or impossible snapshots are discarded.
- Local Elo idempotency is now based on a unique game-session ID rather than the move sequence. Replaying the same sequence in a new game can count as a new result, while re-rendering a finished game cannot award Elo twice.
- The Elo profile stores processed game IDs in the same localStorage write as the rating update. Game history remains best-effort if the browser denies/quota-fails its separate history write.
- Saved-game archive signatures include the game-session ID so two separate games with identical moves do not collapse into one archive record.
- Added a real evaluation-graph view from completed Stockfish per-position scores (White POV, visibly clamped to ±10 pawns) and a direct “Chơi lại” action on the result panel.
- Project version advanced to 3.22.2; tests that asserted the previous version were updated.

## Verification performed
- `node --check src/main.js`, `node --check server/social.js`, and `node --check server/ranked-chess.js`: passed.
- Focused regression suite including graph/result-panel checks: 89 tests passed, 0 failed.
- Full `npm test` was run after the final changes: 175 passed, 3 failed, all three test files fail to load because required packages are missing (`chess.js` in two test files and `express` in one). No assertion failures were reported in the executed tests.

## Verification not completed
- Installing dependencies timed out in this environment. No `node_modules` directory or lockfile was supplied, so the three dependency-based test files, Vite production build, Android build, and runtime browser/device testing could not be completed.
- Server ranked results are server-authoritative and guarded by match status, but this codebase currently uses a single-instance JSON store. Multi-instance deployment needs a transactional shared database and database-level idempotency/locking before being considered production-safe.
- UI rendering and actual network-disconnect restoration still require manual/integration testing in a browser and Android WebView.
