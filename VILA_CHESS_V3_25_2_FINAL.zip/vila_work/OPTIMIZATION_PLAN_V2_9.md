# V2.9.0 — Kế hoạch tối ưu hóa và trạng thái triển khai

## Mục tiêu

Cân bằng ba yếu tố: phản hồi nhanh trên Android cấp thấp, chất lượng nước đi của Stockfish và giao diện dễ dùng. Không thay thế các chức năng hiện có chỉ để làm lại giao diện; mọi thay đổi phải tương thích WebView và có fallback khi engine/API không sẵn sàng.

## Đã triển khai trong source v2.9.0

### 1. Kích thước bàn cờ theo vùng hiển thị thực tế

- `src/board-layout.js` tính cạnh tối đa từ chiều rộng vùng chứa; các kích thước được hiểu là CSS px. Không nhân hoặc chia tiếp theo DPI thiết bị.
- `syncBoardLayout()` đo `.board-column`, `.board-frame` và `#board`; cỡ quân lấy từ cạnh thực tế của ô thông qua `--square-size`.
- `syncArenaBoardLayout()` áp dụng cùng quy tắc cho bàn đấu Arena.
- `ResizeObserver`, resize/orientation change và `visualViewport.resize` yêu cầu đo lại khi xoay điện thoại, thay đổi cửa sổ hay vùng hiển thị.
- Ở landscape thấp, giới hạn cạnh theo ngân sách chiều cao khả dụng thay vì ép bàn lớn hơn vùng chứa.
- CSS giữ grid 8×8, mỗi ô vuông, hit area dùng `touch-action: manipulation`, có focus nhìn thấy được và hỗ trợ `prefers-reduced-motion`.

### 2. Stockfish UCI và khả năng phản hồi

- Engine dùng Worker để tránh chạy tìm kiếm trên luồng render.
- `Threads=1`, `Hash` bảo thủ 16/32 MB và `MultiPV=1` khởi tạo một lần sau `uciok`; không gửi lại trước từng nước. Điều này tránh làm sạch bảng hash/transposition table không cần thiết.
- Gửi `ucinewgame` tại thời điểm bắt đầu ván/round mới; không gọi trước mọi lần `position`/`go`.
- Giữ tìm kiếm có giới hạn thời gian, watchdog, bỏ kết quả cũ dựa vào epoch/FEN và fallback khi engine gặp lỗi.
- Khi `readyok` đến muộn sau lỗi, không tự đặt engine về trạng thái sẵn sàng.

### 3. AI API và fallback

- Payload của Gemini, Anthropic và OpenAI-compatible được giới hạn bởi module xây dựng request.
- AI Coach cắt ngắn lịch sử và giới hạn đầu ra; chọn nước bằng API dùng timeout ngắn hơn và không retry lỗi vận chuyển một cách mù quáng.
- Cần coi thời gian timeout là giới hạn chờ, không phải cam kết model nhanh. Tốc độ thực vẫn phụ thuộc provider, model, mạng, quota và vị trí máy chủ.
- Nước từ LLM phải được xác thực bằng luật cờ trước khi áp dụng. Fallback Stockfish được ưu tiên khi hoạt động; fallback heuristic không được coi là nước do LLM hoặc Stockfish tìm ra.

### 4. Giao diện sử dụng trên Android

- Bố cục gọn ở 360 CSS px; controls và panels giới hạn theo chiều rộng, tránh các phần tử con đẩy lưới vượt màn hình.
- Palette bàn xanh nhạt/xanh lá với last-move highlight, ô đang chọn, dấu nước hợp lệ/bắt quân, ký hiệu tọa độ và aria-label cho từng ô.
- Các thay đổi CSS thêm ở cuối `src/style.css` để giới hạn rủi ro phá vỡ style cũ.

## Test đã chạy

- `npm run test:static`: 55/55 test đạt.
- `node --check src/main.js`, `node --check src/board-layout.js` và `node --check server/index.js`: đạt ở lần kiểm tra cuối cùng (sau khi sửa tài liệu, cần chạy lại lúc chuẩn bị bàn giao).
- `npm test`: 55 đạt, 1 không khởi chạy vì thiếu `chess.js` trong `node_modules`; bài này không được tính là đạt.

## Việc cần xác nhận trước khi phát hành

1. Chạy `npm install` trên GitHub Actions hoặc môi trường có npm registry.
2. Chạy toàn bộ `npm test`, bao gồm kiểm thử luật cờ thật qua `chess.js`.
3. Build với `REQUIRE_STOCKFISH=1 npm run build`; xác nhận đủ Lite + Full JS/WASM.
4. Chạy UCI worker thật: handshake `uciok` → set options → `isready` → `readyok` → `position` → `go` → `bestmove`, và test timeout/crash.
5. Build APK trên GitHub Actions và cài trên OPPO A17k; test 360 CSS px/DPI 360, xoay dọc/ngang, chọn quân/touch, nhập thành, bắt tốt qua đường, phong cấp, đồng hồ, MultiPV và API timeout/fallback.
6. Đo thời gian trung vị và P95 cho Stockfish/API, đo FPS/ANR và kiểm tra nhiệt sau nhiều ván; không tuyên bố “mượt” hoặc “nhanh hơn X%” khi chưa đo.

## Giới hạn rõ ràng

Bản này là mã nguồn để GitHub build, không chứa APK đã xác minh. Các unit/smoke test xác nhận quy tắc helper và các đường mã tĩnh nhưng không thay thế test thiết bị, live API hoặc engine benchmark thực.
