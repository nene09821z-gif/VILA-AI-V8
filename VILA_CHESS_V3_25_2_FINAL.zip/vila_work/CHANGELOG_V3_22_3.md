# v3.22.3
- Replaced randomized ranked-Elo K-factor and winner bonus with deterministic K=24 Elo based on actual game score.
- Added regression coverage for symmetric equal-rating win/loss deltas and updated ranked backend static assertions.
- Release remains blocked on dependency installation, full test suite, production build, and browser/Android integration testing.
