# VILA Chess v3.9.3

## Gemini Coach fix
- Keeps the selected Gemini model as the primary model.
- If a successful response still contains no usable text after one retry, attempts one bounded fallback request with `gemini-3.6-flash`.
- Does not silently change the saved model preference; if fallback answers, the Coach marks which model actually answered.
- If both models fail, reports that the primary and fallback attempts failed and directs the user to inspect endpoint, model permission, quota and API test diagnostics.
- Updates the static test to verify fallback wiring.

## Validation
- `node --check src/main.js`: passed.
- `npm run test:static`: 122/122 passed.
- Live API request and Android APK build were not verified in this environment; they require the user's API key and successful dependency installation/build environment.
