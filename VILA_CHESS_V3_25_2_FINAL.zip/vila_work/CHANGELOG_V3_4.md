# Chess Bot v3.4.0 — Rating, leaderboard, music and API diagnostics

- Added local Elo rating (initial 1200, K=24) for completed games versus Stockfish or configured AI API. Win/loss/draw updates once per unique finished game; history is local to the browser/device.
- Added a dedicated leaderboard/history view in the navigation. It is a local leaderboard, not a shared online ranking service.
- Added opt-in generated chess ambience using Web Audio; no external audio asset or network request. Browser/WebView requires a user gesture to start audio.
- Improved AI Coach handling for array-form content and improved the settings API test's empty-content diagnostics.
- Existing full-game review and MultiPV analysis UI remain in place; API and Stockfish tests are run before packaging.
