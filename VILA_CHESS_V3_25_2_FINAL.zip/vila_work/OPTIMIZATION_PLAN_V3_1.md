# Optimization plan — v3.1.0

## Delivered changes
1. Use a 71-line weighted opening book for variation; never apply a book move that is not a legal move in the current position. Stockfish continues beyond the book.
2. Validate a selected opening on a temporary board before touching the active game so bad SAN cannot leave a half-loaded position.
3. Use dynamic, account-authenticated provider model discovery, with conservative FREE TIER labelling from explicit pricing, `:free` IDs or curated official Gemini/Groq plan documentation.
4. Unlock generated board SFX from the actual tap handler for single Arena games, rematches and round-robin tournaments.
5. Keep existing responsive CSS-pixel board sizing, Hash lifetime, MultiPV analysis, local Stockfish Coach, Vietnamese spoken hints and game/export features.

## Remaining real-device plan
1. Install dependencies and run `npm test`, validating all 71 SAN sequences through `chess.js`.
2. Run `npm run build` and GitHub Actions Android workflow; verify both required Stockfish JS/WASM assets and APK artifact.
3. Test each configured provider key and endpoint, rate limits, free-tier visibility, API timeouts and fallback.
4. Install APK on Android 12 / OPPO A17k / DPI 360; test portrait, landscape, split-screen, low viewport height, tap targets, sound unlock, TTS, clocks, legal moves and Arena result handling.
5. Benchmark Stockfish Lite/Full response time, memory, temperature and battery across repeated positions before changing default engine/time budgets.
