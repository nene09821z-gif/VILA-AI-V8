# v3.3.0
- Full visual refresh: VILA green accent with familiar chess-first board layout.
- Compact mobile tool menu replaces the always-visible navigation strip on small screens.
- Smaller board chrome, reduced padding, improved mobile controls and responsive board width for Android WebView.
- Existing views and game logic preserved; static suite passes 77/77.
