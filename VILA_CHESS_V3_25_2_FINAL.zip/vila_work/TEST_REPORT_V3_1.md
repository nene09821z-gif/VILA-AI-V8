# Test report — v3.1.0

## Passed locally
- `npm run test:static`: **62 passed, 0 failed**.
- Tests cover API payload bounds, endpoint normalization, timeout/cancellation, UCI/MultiPV parsing, board sizing, clocks, settings migration, opening-book candidate selection, Free Tier classification, compact mobile UI, sounds, spoken hints and the AI Coach source switch.
- `node --check` for JavaScript and MJS modules under `src/`, `server/`, `tests/`, and `scripts/`: see release checks.
- Opening catalogue inspection: 71 entries, unique names, SAN arrays and required metadata.
- YAML workflow, JSON, CSS brace and ZIP integrity validation: see final packaging verification.

## Not passed / not run
- Full `npm test`: **62 passed, 1 test module failed to load** (`tests/chess.test.js`) because `chess.js` is missing. Dependency installation could not complete because npm registry DNS returned `EAI_AGAIN`; no SAN-legality result is claimed for that suite.
- The test that replays every opening SAN line is present but not locally executed here.
- `npm run build`, `cap sync`, Android `assembleDebug`, actual Stockfish JS/WASM UCI startup, real API-key/model responses, audio/TTS hardware behavior and actual OPPO A17k Android 12 / DPI 360 layout/performance are not run in this environment.

## Release gate
Push to GitHub and require the Actions workflow to pass `npm test`, Stockfish asset copy, Vite build and Android debug packaging. Then install on OPPO A17k, inspect portrait/landscape and short viewport layout, play multiple openings, verify move legality, sound after tap, TTS and provider error fallback.
