# Test report — VILA Chess v3.9.4

## Passed
- JavaScript syntax: `src/main.js`, `src/elo-strength.js`, `src/game-review.js`.
- Focused unit tests: review classification/symbols, Elo mapping/schema, local rating: 20 tests passed in the focused run before final static suite.
- `npm run test:static`: **128 tests passed, 0 failed**.
- ZIP integrity validated after packaging.

## Coverage added
- All review symbols: book 📖, brilliant !!, best ★, excellent !, good ✓, inaccuracy ?!, mistake ?, blunder ??.
- Target Elo clamping to 500–3200; low Elo uses Skill Level 0 plus controlled heuristic/random legal moves rather than invalid UCI_Elo; 3200 is mapped to the engine's top UCI_Elo value 3190 while preserving displayed target.
- Settings UI and actual Stockfish code path wiring.

## Not verified here
- Full `npm test` had 128 passing tests and one test file could not load: `tests/chess.test.js` throws `ERR_MODULE_NOT_FOUND` because the `chess.js` dependency is not installed in this environment. This is an environment/dependency blocker, not a passing chess-law test.
- Live Stockfish run inside Android WebView.
- Vite build and Android APK build, because dependencies are not installed in this source-preparation environment.
- Elo values are engine-strength targets/approximations, not certified player ratings.
