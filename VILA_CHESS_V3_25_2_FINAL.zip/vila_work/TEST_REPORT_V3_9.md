# VILA Chess v3.9.0 — Test report

## Passed
- `npm run test:static`: **114/114 passed**.
- Focused opening tests (`tests/opening-catalog.test.js`, `tests/opening-book.test.js`, `tests/opening-recognition.test.js`): **9/9 passed**.
- New static UI/catalog/build workflow regression checks included in the static suite.
- Syntax checks for `src/main.js`, `src/opening-catalog.js`, `src/opening-book.js`, `src/opening-recognition.js`, `scripts/prepare-openings.mjs`, `server/index.js` and other changed JavaScript modules.
- JSON parse and ZIP integrity checked when packaging.

## Not verified
- Full `npm test` was attempted: 114 tests passed and the 1 dependency-backed chess test failed to load because `chess.js` is absent (`ERR_MODULE_NOT_FOUND`); `node_modules` is absent in this authoring environment.
- Production Vite/Stockfish build and `npx cap`/Gradle APK build were not run here.
- The Lichess ECO refresh depends on outbound network access and runs in `prebuild`; network retrieval could not be completed in the authoring environment. The committed fallback remains the curated seed.
- No real provider/API request and no OPPO/Android physical-device touch test were performed.

## Expected GitHub validation sequence
1. Run `npm install --no-audit --no-fund`.
2. Run workflow syntax checks and `npm run test:static`.
3. Run the complete `npm test` suite.
4. Run `npm run build` with `REQUIRE_STOCKFISH=1`; `prebuild` attempts the remote ECO refresh before Vite packaging.
5. Run Capacitor sync, verify Gradle files, then `./gradlew assembleDebug`.
6. Confirm the Actions job/artifacts complete, then install the resulting debug APK for device-level verification.
