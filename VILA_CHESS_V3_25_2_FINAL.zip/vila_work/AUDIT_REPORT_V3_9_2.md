# Rà soát mã nguồn — VILA Chess v3.9.2

## Phạm vi

Đã rà soát đường khởi tạo Stockfish, việc đóng gói engine trong build, endpoint provider và test regression hiện có. Ưu tiên bản này là độ bền của engine trên Android/WebView và tránh để lỗi tải WASM khiến app mất hẳn engine.

## Phát hiện và xử lý

- Trước bản này, lỗi khởi động Lite/WASM sẽ kết thúc ở bot đi nước hợp lệ dự phòng; chưa có engine thứ ba.
- Đã thêm ASM-JS, một asset JavaScript không phụ thuộc WASM, làm phương án cuối. Tên tệp được xác nhận từ tài liệu Stockfish.js 19.0.1.
- Đường fallback giờ là Full (nếu được đóng gói) → Lite single-thread → ASM-JS. Mỗi engine chỉ được thử một lần trong chuỗi; nút thử lại khởi động một chuỗi mới.
- Chỉ chuyển engine khi chưa đạt trạng thái sẵn sàng. Nếu lỗi trong lúc đang phân tích/chơi, app dùng đường cleanup hiện tại thay vì âm thầm tạo worker mới giữa một search.
- Bộ đóng gói xác thực đầy đủ asset bắt buộc trước khi dọn thư mục `public/engine`; thêm test để kiểm tra trường hợp thiếu ASM-JS không xóa bundle cũ.
- Đổi nhãn Full trong Cài đặt để người dùng không hiểu nhầm rằng APK mặc định sẽ tự tải engine 94 MB. Full chỉ hoạt động nếu nhà build chủ động đóng gói.
- Đã bổ sung test kiểm tra fallback chain, asset mapping và script packaging; cập nhật phiên bản app/health endpoint lên 3.9.2.

## Không được khẳng định quá mức

- 122/122 bài của nhóm `test:static` đạt.
- Toàn bộ test luật cờ chưa chạy được trong môi trường này vì thiếu `chess.js`; thao tác `npm install` hết thời gian chờ.
- `npm run build` bị chặn ở bước `prebuild` do dependency nói trên không có. Chưa có APK để cài thử, do đó chưa xác nhận engine trên Android, các API với key thật, nhạc online hay tương tác bàn cờ thực tế.

## Khuyến nghị kiểm thử trước phát hành

1. GitHub Actions phải cài dependency thành công, chạy `npm test`, bundle Stockfish Lite + ASM-JS, hoàn tất Vite/Capacitor và `./gradlew assembleDebug`.
2. Trên Android thật, xác nhận trạng thái Stockfish sẵn sàng, AI đi nước hợp lệ, timeout/retry không treo và xem lại ván vẫn hoạt động sau khi engine được đổi dự phòng.
3. Chạy các trường hợp luật cờ và xuất/nhập PGN; đối chiếu thế cờ trước/sau mỗi nước.
4. Kiểm tra API lỗi key, model 404, quota 429, mất mạng và backend không sẵn sàng bằng key thử nghiệm; tuyệt đối không in key ra log.
