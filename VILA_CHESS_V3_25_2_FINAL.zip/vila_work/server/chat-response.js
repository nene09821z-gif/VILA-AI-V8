/** Normalize common non-streaming and SSE chat response shapes without exposing reasoning fields. */
function tidy(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function isNonAnswerBlock(value) {
  if (!value || typeof value !== 'object') return false;
  const type = String(value.type || value.kind || '').toLowerCase().replace(/[-_\s]/g, '');
  const channel = String(value.channel || value.role || '').toLowerCase();
  return /^(reasoning|thinking|analysis|toolcall|tooluse|functioncall)$/.test(type)
    || value.thought === true || value.is_reasoning === true || value.isReasoning === true
    || value.is_thinking === true || value.isThinking === true
    || ['analysis', 'reasoning', 'thinking'].includes(channel);
}

function textFromContent(value, depth = 0) {
  if (depth > 9 || value == null) return '';
  if (typeof value === 'string') return value.trim();
  if (Array.isArray(value)) return value.map(part => textFromContent(part, depth + 1)).filter(Boolean).join('\n').trim();
  if (typeof value !== 'object' || isNonAnswerBlock(value)) return '';

  // Provider wrappers may expose final text as `text`, `output_text`, or a nested content object.
  if (typeof value.text === 'string' && value.text.trim()) return value.text.trim();
  if (typeof value.output_text === 'string' && value.output_text.trim()) return value.output_text.trim();
  if (typeof value.content === 'string' && value.content.trim()) return value.content.trim();
  for (const key of ['content', 'parts', 'output_text', 'output', 'message', 'response', 'result', 'text', 'value']) {
    const result = textFromContent(value[key], depth + 1);
    if (result) return result;
  }
  return '';
}

function streamTextFromContent(value, depth = 0) {
  if (depth > 8 || value == null) return '';
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(part => streamTextFromContent(part, depth + 1)).join('');
  if (typeof value !== 'object' || isNonAnswerBlock(value)) return '';
  for (const key of ['text', 'content', 'output_text', 'parts', 'value']) {
    const result = streamTextFromContent(value[key], depth + 1);
    if (result) return result;
  }
  return '';
}

function streamTextFromEvent(mode, event) {
  if (!event || typeof event !== 'object') return { text: '', finishReason: '' };
  let text = '';
  let finishReason = '';

  if (mode === 'anthropic') {
    if (event.type === 'content_block_delta' && event.delta?.type === 'text_delta') text = typeof event.delta.text === 'string' ? event.delta.text : '';
    if (event.type === 'message_delta') finishReason = String(event.delta?.stop_reason || '');
    if (event.type === 'message_stop') finishReason ||= 'end_turn';
  } else if (mode === 'gemini') {
    const candidates = Array.isArray(event.candidates) ? event.candidates : [];
    for (const candidate of candidates) {
      const parts = Array.isArray(candidate?.content?.parts) ? candidate.content.parts : [];
      const value = parts.map(part => isNonAnswerBlock(part) || part?.thought === true ? '' : (typeof part?.text === 'string' ? part.text : '')).filter(Boolean).join('');
      if (value) text += value;
      finishReason = String(candidate?.finishReason || finishReason);
    }
    finishReason ||= String(event.promptFeedback?.blockReason || '');
  } else {
    for (const choice of Array.isArray(event.choices) ? event.choices : []) {
      text += streamTextFromContent(choice?.delta?.content)
        || streamTextFromContent(choice?.delta?.text)
        || (typeof choice?.text === 'string' ? choice.text : '');
      finishReason = String(choice?.finish_reason || finishReason);
    }
    if (!text && typeof event.delta?.text === 'string') text = event.delta.text;
    if (!text && typeof event.output_text_delta === 'string') text = event.output_text_delta;
    finishReason ||= String(event.response?.status || event.status || '');
  }
  return { text, finishReason };
}

/** Parse ordinary JSON responses and tolerate providers/gateways that return SSE despite stream:false. */
export function parseChatResponseBody(raw, contentType = '', mode = 'openai-compatible') {
  const body = String(raw || '');
  try { return JSON.parse(body); } catch { /* Try event-stream/plain-text fallback below. */ }

  const isEventStream = /text\/event-stream/i.test(contentType) || /(?:^|\n)data:\s*(?:\{|\[DONE\])/m.test(body);
  if (!isEventStream) return { message: body.slice(0, 1000) };

  const chunks = [];
  let finishReason = '';
  let lastEvent = null;
  for (const line of body.split(/\r?\n/)) {
    if (!line.startsWith('data:')) continue;
    const payload = line.slice(5).trim();
    if (!payload || payload === '[DONE]') continue;
    let event;
    try { event = JSON.parse(payload); } catch { continue; }
    lastEvent = event;
    const parsed = streamTextFromEvent(mode, event);
    if (parsed.text) chunks.push(parsed.text);
    if (parsed.finishReason) finishReason = parsed.finishReason;
  }

  if (chunks.length) return { __normalizedChatText: chunks.join(''), __finishReason: finishReason || 'unknown' };
  if (lastEvent) return lastEvent;
  return { message: body.slice(0, 1000) };
}

export function getChatFinishReason(mode, data) {
  if (data?.__finishReason) return String(data.__finishReason);
  if (mode === 'gemini') return String(data?.candidates?.[0]?.finishReason || data?.promptFeedback?.blockReason || 'unknown');
  if (mode === 'anthropic') return String(data?.stop_reason || 'unknown');
  return String(data?.choices?.[0]?.finish_reason || data?.finish_reason || data?.incomplete_details?.reason || data?.status || 'unknown');
}

export function extractChatText(mode, data) {
  if (!data || typeof data !== 'object') return '';
  if (typeof data.__normalizedChatText === 'string' && data.__normalizedChatText.trim()) return data.__normalizedChatText.trim();

  if (mode === 'gemini') {
    const candidates = Array.isArray(data.candidates) ? data.candidates : [];
    for (const candidate of candidates) {
      const text = textFromContent(candidate?.content?.parts);
      if (text) return text;
    }
    return textFromContent(data.output_text || data.text || data.output || data.response);
  }
  if (mode === 'anthropic') {
    const textBlocks = Array.isArray(data.content)
      ? data.content.filter(block => !block?.type || block.type === 'text' || block.type === 'output_text')
      : data.content;
    const text = textFromContent(textBlocks);
    return text || textFromContent(data.output_text || data.text || data.output || data.response);
  }

  const choices = Array.isArray(data.choices) ? data.choices : [];
  for (const choice of choices) {
    const text = textFromContent(choice?.message?.content)
      || textFromContent(choice?.delta?.content)
      || tidy(choice?.text)
      || tidy(choice?.message?.refusal);
    if (text) return text;
  }
  // OpenAI Responses API and gateways sometimes place output text only in the output-item array.
  return textFromContent(data.output_text)
    || textFromContent(data.output)
    || textFromContent(data.response)
    || textFromContent(data.message?.content)
    || textFromContent(data.result?.content)
    || tidy(data.text)
    || '';
}

export function getChatEmptyHint(mode, data) {
  const finish = getChatFinishReason(mode, data);
  const choices = Array.isArray(data?.choices) ? data.choices : [];
  const hasOpenAiToolCall = choices.some(choice => Array.isArray(choice?.message?.tool_calls) && choice.message.tool_calls.length > 0);
  const hasAnthropicToolCall = mode === 'anthropic' && Array.isArray(data?.content) && data.content.some(block => ['tool_use', 'server_tool_use'].includes(block?.type));
  const hasGeminiToolCall = mode === 'gemini' && Array.isArray(data?.candidates) && data.candidates.some(candidate => candidate?.content?.parts?.some(part => part?.functionCall || part?.function_call));
  if (/length|max.?tokens|token.?limit|max_output_tokens/i.test(finish)) return `Model dừng do giới hạn đầu ra (${finish}). Tăng giới hạn token hoặc chọn model trả lời nhanh hơn.`;
  if (hasOpenAiToolCall || hasAnthropicToolCall || hasGeminiToolCall || /tool.?calls?|function.?calls?/i.test(finish)) return 'Model chỉ trả yêu cầu gọi công cụ; ứng dụng hiện không thực thi tool call tự động. Hãy chọn model chat văn bản hoặc tắt chế độ công cụ.';
  if (/safety|blocked|prohibited/i.test(finish)) return `Nhà cung cấp chặn phần trả lời (${finish}). Hãy đổi cách hỏi hoặc kiểm tra chính sách model.`;
  return `Model không trả trường văn bản tương thích (finish reason: ${finish}). Kiểm tra model ID, quyền chat/generate và định dạng phản hồi của endpoint.`;
}
