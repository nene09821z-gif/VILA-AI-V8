import { spawn } from 'node:child_process';
import fs from 'node:fs';

const DEFINITIONS = Object.freeze([
  { id: 'stockfish', name: 'Stockfish', role: 'default', env: 'STOCKFISH_PATH', note: 'Mặc định; vẫn chạy offline trong app.' },
  { id: 'lc0', name: 'Leela Chess Zero (Lc0)', role: 'neural', env: 'LC0_PATH', weightsEnv: 'LC0_WEIGHTS_PATH', note: 'Cần binary Lc0 và file weights riêng.' },
  { id: 'ethereal', name: 'Ethereal', role: 'classical', env: 'ETHEREAL_PATH', note: 'Cần binary Ethereal tương thích máy chủ.' },
  { id: 'berserk', name: 'Berserk', role: 'classical', env: 'BERSERK_PATH', note: 'Cần binary Berserk tương thích máy chủ.' }
]);
const safeFen = value => typeof value === 'string' && value.length <= 200 && /^(?:[rnbqkpRNBQKP1-8]+\/){7}[rnbqkpRNBQKP1-8]+\s[wb]\s(?:K?Q?k?q?|-)\s(?:[a-h][36]|-)\s\d+\s\d+$/.test(value.trim());
function configured(def) {
  const executable = String(process.env[def.env] || '').trim();
  const weights = def.weightsEnv ? String(process.env[def.weightsEnv] || '').trim() : '';
  const exists = Boolean(executable && fs.existsSync(executable) && fs.statSync(executable).isFile());
  const weightsReady = !def.weightsEnv || Boolean(weights && fs.existsSync(weights) && fs.statSync(weights).isFile());
  return { ...def, executable, weights, ready: exists && weightsReady, status: !executable ? 'not-configured' : !exists ? 'binary-missing' : !weightsReady ? 'weights-missing' : 'ready' };
}
export function listChessEngines() {
  return DEFINITIONS.map(def => {
    const item = configured(def);
    return { id: item.id, name: item.name, role: item.role, available: item.ready, status: item.status, note: item.note };
  });
}

/** Runs a configured UCI binary as a one-shot process. No user-supplied executable or shell command is accepted. */
export function analyzeWithEngine({ id, fen, moveTimeMs = 1200, timeoutMs = 8000 } = {}) {
  if (!safeFen(fen)) return Promise.reject(new Error('FEN không hợp lệ.'));
  const def = DEFINITIONS.find(item => item.id === id);
  if (!def) return Promise.reject(new Error('Engine không nằm trong danh sách cho phép.'));
  const engine = configured(def);
  if (!engine.ready) return Promise.reject(new Error(`${engine.name} chưa được cài cấu hình đầy đủ (${engine.status}).`));
  const thinkMs = Math.max(100, Math.min(5000, Number(moveTimeMs) || 1200));
  const hardTimeout = Math.max(2000, Math.min(10000, Number(timeoutMs) || 8000));
  return new Promise((resolve, reject) => {
    let child;
    let settled = false;
    let buffer = '';
    let bestmove = '';
    let latestInfo = '';
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { child?.kill('SIGKILL'); } catch {}
      if (error) reject(error); else resolve(value);
    };
    try {
      const args = def.id === 'lc0' ? [`--weights=${engine.weights}`] : [];
      child = spawn(engine.executable, args, { shell: false, stdio: ['pipe', 'pipe', 'ignore'], windowsHide: true });
    } catch (error) { reject(new Error(`Không thể khởi chạy ${engine.name}: ${error.message}`)); return; }
    const timer = setTimeout(() => finish(new Error(`${engine.name} quá thời gian phản hồi.`)), hardTimeout);
    child.on('error', error => finish(new Error(`Không thể khởi chạy ${engine.name}: ${error.message}`)));
    child.on('close', code => { if (!settled) finish(new Error(`${engine.name} đã dừng trước khi trả nước đi (mã ${code}).`)); });
    child.stdout.on('data', chunk => {
      buffer += chunk.toString('utf8');
      if (buffer.length > 128_000) buffer = buffer.slice(-32_000);
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || '';
      for (const raw of lines) {
        const line = raw.trim();
        if (line.startsWith('info ') && /\bpv\b/.test(line)) latestInfo = line.slice(0, 4000);
        if (line.startsWith('bestmove ')) {
          bestmove = line.split(/\s+/)[1] || '';
          if (/^(?:[a-h][1-8][a-h][1-8][qrbn]?|0000)$/i.test(bestmove)) finish(null, { engine: def.id, bestmove, info: latestInfo, moveTimeMs: thinkMs });
          else finish(new Error(`${engine.name} trả về nước đi UCI không hợp lệ.`));
        }
      }
    });
    child.stdin.on('error', error => finish(new Error(`Lỗi giao tiếp UCI với ${engine.name}: ${error.message}`)));
    const uci = ['uci'];
    child.stdin.write(`${uci.join(' ')}\n`);
    // UCI engines accept commands in order on stdin; isready ensures initialization is complete.
    child.stdin.write(`isready\nposition fen ${fen.trim()}\ngo movetime ${thinkMs}\n`);
  });
}
