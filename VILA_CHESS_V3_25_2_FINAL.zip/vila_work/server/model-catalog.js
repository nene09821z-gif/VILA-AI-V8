/**
 * Conservative free-tier classifier for model catalogs.
 * Explicit provider pricing or a :free model ID is the strongest signal.
 * Some providers (notably Gemini/Groq) keep plan-level quotas in separate official docs
 * instead of returning pricing in the models endpoint, so we use small, documented
 * allow-lists reviewed on 2026-10-17. Availability and quota still depend on the API account.
 */
function zeroPrice(value) {
  if (value === 0) return true;
  if (typeof value !== 'string' && typeof value !== 'number') return false;
  const number = Number(String(value).trim());
  return Number.isFinite(number) && number === 0 && String(value).trim() !== '';
}

const GEMINI_FREE_TIER_TEXT_MODELS = new Set([
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3-flash-preview',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
]);

// Text-generation IDs currently shown in the official Groq Free Plan Limits table.
const GROQ_FREE_PLAN_TEXT_MODELS = new Set([
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'openai/gpt-oss-safeguard-20b',
  'qwen/qwen3.8-27b',
]);

function getHost(endpoint) {
  try { return new URL(String(endpoint || '')).hostname.toLowerCase(); }
  catch { return ''; }
}

export function isConfirmedFreeModel(item, context = {}) {
  const id = String(item?.id || item?.name || '').trim();
  if (!id) return false;
  if (/:free$/i.test(id)) return true;
  const pricing = item?.pricing;
  if (pricing && typeof pricing === 'object') {
    const prompt = pricing.prompt ?? pricing.input;
    const completion = pricing.completion ?? pricing.output;
    if (prompt !== undefined && completion !== undefined && zeroPrice(prompt) && zeroPrice(completion)) return true;
  }

  const mode = String(context.mode || '').toLowerCase();
  const modelId = id.replace(/^models\//i, '').toLowerCase();
  const host = getHost(context.endpoint);
  if (mode === 'gemini' && host === 'generativelanguage.googleapis.com') {
    return GEMINI_FREE_TIER_TEXT_MODELS.has(modelId);
  }
  if (mode === 'openai-compatible' && host === 'api.groq.com') {
    return GROQ_FREE_PLAN_TEXT_MODELS.has(modelId);
  }
  return false;
}

export const FREE_MODEL_CATALOG_REVIEWED_AT = '2026-10-16';
