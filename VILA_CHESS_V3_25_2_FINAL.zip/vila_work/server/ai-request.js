/** Small, predictable provider payloads for low-latency chess coaching. */
export function normalizeChatOptions(input = {}) {
  const requested = Number(input.maxTokens);
  const maxTokens = Number.isFinite(requested) ? Math.min(1200, Math.max(8, Math.trunc(requested))) : 384;
  const rawTemperature = Number(input.temperature);
  const temperature = Number.isFinite(rawTemperature) ? Math.min(1, Math.max(0, rawTemperature)) : 0.3;
  return { maxTokens, temperature };
}

export function buildChatPayload({ mode, model, messages, system = '', temperature, maxTokens }) {
  const opts = normalizeChatOptions({ temperature, maxTokens });
  const conversation = (Array.isArray(messages) ? messages : []).filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string').slice(-8);
  if (mode === 'gemini') {
    return {
      contents: conversation.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content.slice(0, 6000) }] })),
      generationConfig: { temperature: opts.temperature, maxOutputTokens: opts.maxTokens, candidateCount: 1 },
      ...(system ? { systemInstruction: { parts: [{ text: system.slice(0, 5000) }] } } : {})
    };
  }
  if (mode === 'anthropic') {
    return {
      model,
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      messages: conversation.map(m => ({ role: m.role, content: m.content.slice(0, 6000) })),
      ...(system ? { system: system.slice(0, 5000) } : {})
    };
  }
  return {
    model,
    messages: [...(system ? [{ role: 'system', content: system.slice(0, 5000) }] : []), ...conversation.map(m => ({ role: m.role, content: m.content.slice(0, 6000) }))],
    temperature: opts.temperature,
    max_tokens: opts.maxTokens,
    stream: false
  };
}

/**
 * Newer OpenAI-compatible models reject `max_tokens` (want `max_completion_tokens`) or a custom
 * `temperature`. Given the provider's 400 message, return an adjusted payload to retry once, or null.
 */
export function adaptPayloadForProviderError(payload, detail = '') {
  if (!payload || typeof payload !== 'object') return null;
  const text = String(detail || '');
  const next = { ...payload };
  let changed = false;
  if ('max_tokens' in next && /max_completion_tokens|max_tokens.*(not supported|unsupported|deprecated)|Unsupported parameter.*max_tokens/i.test(text)) {
    next.max_completion_tokens = next.max_tokens; delete next.max_tokens; changed = true;
  }
  if ('temperature' in next && /temperature.*(not support|unsupported|only the default|does not support)|Unsupported (value|parameter).*temperature/i.test(text)) {
    delete next.temperature; changed = true;
  }
  return changed ? next : null;
}
