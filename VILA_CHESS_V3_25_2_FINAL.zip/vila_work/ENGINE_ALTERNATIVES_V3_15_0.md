# VILA Chess — engines other than Stockfish

VILA Chess 3.15.0 exposes these alternatives without pretending that optional binaries are already installed:

- **VILA Classic (offline)** — bundled JavaScript alpha-beta/minimax engine using legal move generation from `chess.js`. No server or engine binary needed. Intended as a casual fallback, not a Stockfish-strength replacement.
- **Leela Chess Zero (Lc0)** — neural-network engine. The backend requires a compatible executable and a separate weights file (`LC0_PATH`, `LC0_WEIGHTS_PATH`).
- **Ethereal** — classical UCI engine, configured by `ETHEREAL_PATH`.
- **Berserk** — classical UCI engine, configured by `BERSERK_PATH`.

The last three are exposed through the existing server Engine Hub endpoint. Set the executable paths in the server environment and make sure the binaries are legal to redistribute/use for your target. Engine availability is reported by `/api/engines`. They cannot all be automatically bundled: platform builds, binary sizes, network weights and license obligations differ.

The SVG pieces are a new VILA-designed Staunton-inspired set. They use the conventional chess silhouette language, but do not copy Chess.com's proprietary piece image files.
