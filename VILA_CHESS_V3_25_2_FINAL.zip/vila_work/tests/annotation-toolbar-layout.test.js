import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

test('Analysis toolbar is outside the chessboard and does not cover playable squares', () => {
  const board = main.indexOf('<div class="board-frame ${!gameStarted');
  const meter = main.indexOf('<div class="evaluation-meter-row"', board);
  const toolbar = main.indexOf('<div class="board-annotation-toolbar-row">', board);
  const widget = main.indexOf('id="boardAnnotationWidget"', board);
  assert.ok(board >= 0 && meter > board && toolbar > board && widget > toolbar);
  const boardMarkup = main.slice(board, toolbar);
  assert.doesNotMatch(boardMarkup, /boardAnnotationWidget/, 'board frame must only contain squares, overlay arrows and game-start overlay');
  assert.match(main.slice(toolbar, meter), /class="board-annotation-widget/);
  assert.match(main, /widget\.closest\('\.board-annotation-toolbar-row'\)/, 'drag uses its own row for bounds');
  assert.match(css, /\.board-annotation-toolbar-row\{position:relative/);
  assert.match(main, /const maxLeft = Math\.max\(0, \(row\?\.clientWidth \|\| widget\.offsetWidth\) - widget\.offsetWidth\)/);
  assert.match(css, /\.board-annotation-toolbar-row\[hidden\]\{display:none!important\}/);
  assert.match(css, /#engineStatus\{width:27px;height:31px;max-width:27px/);
  assert.match(css, /\.board-annotation-widget\.is-collapsed \.annotation-widget-grip\{display:none\}/);
});
