import test from 'node:test';
import assert from 'node:assert/strict';
import { buildChatPayload, normalizeChatOptions } from '../server/ai-request.js';

test('chat options cap output and clamp temperature for low-latency defaults', () => {
  assert.deepEqual(normalizeChatOptions({}), { maxTokens: 384, temperature: 0.3 });
  assert.deepEqual(normalizeChatOptions({ maxTokens: 9000, temperature: 2 }), { maxTokens: 1200, temperature: 1 });
  assert.equal(normalizeChatOptions({ maxTokens: 1 }).maxTokens, 8);
});

test('Gemini payload uses bounded output and maps assistant role', () => {
  const payload = buildChatPayload({ mode: 'gemini', model: 'gemini-fast', messages: [{ role: 'assistant', content: 'hi' }, { role: 'user', content: 'next' }], system: 'coach', maxTokens: 256 });
  assert.equal(payload.generationConfig.maxOutputTokens, 256);
  assert.equal(payload.generationConfig.candidateCount, 1);
  assert.equal(payload.contents[0].role, 'model');
  assert.equal(payload.systemInstruction.parts[0].text, 'coach');
});

test('Anthropic and OpenAI-compatible payloads cap context to eight messages', () => {
  const messages = Array.from({ length: 12 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: String(i) }));
  const anthropic = buildChatPayload({ mode: 'anthropic', model: 'claude-fast', messages, maxTokens: 300 });
  const openai = buildChatPayload({ mode: 'openai-compatible', model: 'fast', messages, maxTokens: 300 });
  assert.equal(anthropic.messages.length, 8);
  assert.equal(anthropic.max_tokens, 300);
  assert.equal(openai.messages.length, 8);
  assert.equal(openai.max_tokens, 300);
  assert.equal(openai.stream, false);
});
