import test from 'node:test';
import assert from 'node:assert/strict';
import { extractChatText, getChatEmptyHint, getChatFinishReason, parseChatResponseBody } from '../server/chat-response.js';

test('OpenAI-compatible string and content-block responses are normalized', () => {
  assert.equal(extractChatText('openai-compatible', { choices: [{ message: { content: 'Nên phát triển mã trước.' }, finish_reason: 'stop' }] }), 'Nên phát triển mã trước.');
  assert.equal(extractChatText('openai-compatible', { choices: [{ message: { content: [{ type: 'text', text: 'Một ý.' }, { type: 'text', text: 'Hai ý.' }] } }] }), 'Một ý.\nHai ý.');
});

test('Hidden reasoning blocks are not exposed as the assistant answer', () => {
  assert.equal(extractChatText('openai-compatible', { choices: [{ message: { content: [{ type: 'reasoning', text: 'private analysis' }] }, finish_reason: 'stop' }] }), '');
});

test('Gemini response parts and Anthropic text blocks are normalized', () => {
  assert.equal(extractChatText('gemini', { candidates: [{ content: { parts: [{ text: 'Đòn chiến thuật.' }, { text: 'Bảo vệ vua.' }] }, finishReason: 'STOP' }] }), 'Đòn chiến thuật.\nBảo vệ vua.');
  assert.equal(extractChatText('anthropic', { content: [{ type: 'text', text: 'Hãy kiểm tra nước đi.' }, { type: 'tool_use', id: 'x', name: 'tool' }], stop_reason: 'end_turn' }), 'Hãy kiểm tra nước đi.');
});

test('Non-standard text wrappers and refusal messages remain visible', () => {
  assert.equal(extractChatText('openai-compatible', { response: { content: 'Wrapped output' } }), 'Wrapped output');
  assert.equal(extractChatText('openai-compatible', { choices: [{ message: { refusal: 'Không thể đáp ứng yêu cầu.' } }] }), 'Không thể đáp ứng yêu cầu.');
});

test('Empty-output diagnostics explain token cutoffs and unsupported tool calls', () => {
  const cutoff = { choices: [{ message: { content: '' }, finish_reason: 'length' }] };
  assert.equal(getChatFinishReason('openai-compatible', cutoff), 'length');
  assert.match(getChatEmptyHint('openai-compatible', cutoff), /giới hạn đầu ra/);
  assert.match(getChatEmptyHint('openai-compatible', { choices: [{ message: { content: '', tool_calls: [{ id: 't' }] }, finish_reason: 'tool_calls' }] }), /không thực thi tool call/);
});


test('Responses API output-item arrays and nested gateway wrappers return final text', () => {
  const responseApi = { output: [{ type: 'message', content: [{ type: 'output_text', text: 'Nước hay là phát triển quân.' }] }] };
  assert.equal(extractChatText('openai-compatible', responseApi), 'Nước hay là phát triển quân.');
  assert.equal(extractChatText('openai-compatible', { result: { content: { text: 'Nội dung từ gateway.' } } }), 'Nội dung từ gateway.');
});

test('Gemini thought parts are excluded instead of being mistaken for the final answer', () => {
  const response = { candidates: [{ content: { parts: [
    { text: 'Private reasoning', thought: true },
    { text: 'Câu trả lời cuối cùng.' }
  ] }, finishReason: 'STOP' }] };
  assert.equal(extractChatText('gemini', response), 'Câu trả lời cuối cùng.');
});

test('SSE output is normalized for OpenAI-compatible, Gemini, and Anthropic providers', () => {
  const openai = parseChatResponseBody([
    'data: {"choices":[{"delta":{"content":"Xin "},"finish_reason":null}]}',
    'data: {"choices":[{"delta":{"content":"chào"},"finish_reason":"stop"}]}',
    'data: [DONE]'
  ].join('\n'), 'text/event-stream', 'openai-compatible');
  assert.equal(extractChatText('openai-compatible', openai), 'Xin chào');
  assert.equal(getChatFinishReason('openai-compatible', openai), 'stop');

  const gemini = parseChatResponseBody([
    'data: {"candidates":[{"content":{"parts":[{"text":"VILA "}]}}]}',
    'data: {"candidates":[{"content":{"parts":[{"text":"Chess"}]},"finishReason":"STOP"}]}'
  ].join('\n'), 'text/event-stream', 'gemini');
  assert.equal(extractChatText('gemini', gemini), 'VILA Chess');
  assert.equal(getChatFinishReason('gemini', gemini), 'STOP');

  const anthropic = parseChatResponseBody([
    'event: content_block_delta',
    'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"Nước "}}',
    'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"đi tốt."}}',
    'data: {"type":"message_delta","delta":{"stop_reason":"end_turn"}}'
  ].join('\n'), 'text/event-stream', 'anthropic');
  assert.equal(extractChatText('anthropic', anthropic), 'Nước đi tốt.');
  assert.equal(getChatFinishReason('anthropic', anthropic), 'end_turn');
});

test('Plain non-JSON provider errors remain bounded and readable', () => {
  assert.deepEqual(parseChatResponseBody('gateway is unavailable', 'text/plain'), { message: 'gateway is unavailable' });
});
