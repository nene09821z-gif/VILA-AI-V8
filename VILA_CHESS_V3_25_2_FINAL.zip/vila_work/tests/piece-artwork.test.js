import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const piecesSrc = fs.readFileSync(new URL('../src/pieces.js', import.meta.url), 'utf8');
const pieceStart = main.indexOf('function pieceGlyph(piece) {');
const pieceEnd = main.indexOf('\nfunction squareColor(square)', pieceStart);
const renderer = piecesSrc;

test('All six chess types use the local VILA Royal SVG set, shared by every board', () => {
  assert.ok(pieceStart >= 0 && pieceEnd > pieceStart, 'piece renderer must exist');
  assert.match(main.slice(pieceStart, pieceEnd), /pieceSvgMarkup\(piece\)/, 'pieceGlyph must delegate to the shared set');
  assert.match(main, /from '\.\/pieces\.js'/);
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    assert.match(renderer, new RegExp(`\\n\\s+${type}: \\{`), `missing SVG silhouette for ${type}`);
  }
  assert.match(renderer, /piece-svg-\$\{piece\.type\}/);
  assert.match(renderer, /vp-grad-\$\{color\}/);
  assert.match(renderer, /shape\.body/);
  assert.match(renderer, /shape\.detail/);
  assert.doesNotMatch(renderer, /[♔♕♖♗♘♙♚♛♜♝♞♟]/, 'pieces must not depend on platform chess glyph fonts');
});

test('Annotation toolbar dragging is frame-coalesced and uses compositor transforms', () => {
  const start = main.indexOf('function wireAnnotationWidget()');
  const end = main.indexOf('\nfunction canStartBoardDrag', start);
  const fn = main.slice(start, end);
  assert.match(fn, /if \(!annotationWidgetRaf\) annotationWidgetRaf = requestAnimationFrame/);
  assert.match(fn, /translate3d\(/);
  assert.match(fn, /Commit the final position once when the gesture ends/);
  assert.match(fn, /localStorage\.setItem\('vila\.chess\.annotation-widget-position\.v2'/);
  assert.equal((fn.match(/getBoundingClientRect\(\)/g) || []).length, 2,
    'geometry reads should happen only at pointer-down, not on every move/end event');
});

test('Manual annotation color classes match the styles for all three colors', () => {
  assert.match(main, /manual-\$\{mark\.type\}-\$\{mark\.color \|\| 'green'\}/);
  for (const type of ['arrow', 'circle']) {
    for (const color of ['green', 'red', 'yellow']) {
      assert.match(css, new RegExp(`\\.manual-${type}-${color}\\s*\\{`), `missing ${type} ${color} style`);
    }
  }
});

test('Android drawing toolbar avoids background blur and SVG filter shadows', () => {
  const widgetRule = css.match(/\.board-annotation-widget\{[^}]*\}/)?.[0] || '';
  const arrowRule = css.match(/\.manual-arrow\{[^}]*\}/)?.[0] || '';
  const circleRule = css.match(/\.manual-circle\{[^}]*\}/)?.[0] || '';
  const svgRule = css.match(/\.piece-svg\{[^}]*\}/)?.[0] || '';
  assert.ok(widgetRule);
  assert.doesNotMatch(widgetRule, /backdrop-filter/);
  assert.match(arrowRule, /filter:none/);
  assert.match(circleRule, /filter:none/);
  assert.match(svgRule, /filter:none/);
  assert.match(css, /\.board-annotation-widget\.is-moving\{will-change:transform/);
  assert.equal(pkg.version, '3.25.0');
});


test('Default board uses Chess.com-inspired green and cream squares', () => {
  assert.match(css, /--board-light:#eeeed2/);
  assert.match(css, /--board-dark:#769656/);
  assert.match(css, /html\[data-board-theme="classic"\]\{--board-light:#eeeed2;--board-dark:#769656/);
  const daily = fs.readFileSync(new URL('../src/daily-progress.js', import.meta.url), 'utf8');
  assert.match(daily, /name: 'Xanh lá & kem'/);
  assert.match(daily, /colors: \['#eeeed2', '#769656'\]/);
});

test('Green/cream palette and original SVG pieces apply across every existing board renderer', () => {
  for (const selector of ['.chessboard .square.light', '.arena-board .arena-square.light', '.ranked-board .ranked-square.light', '.puzzle-board .puzzle-square.light', '.review-replay-board .review-replay-square.review-light']) {
    assert.ok(css.includes(selector), `missing shared light-square styling for ${selector}`);
  }
  for (const selector of ['.chessboard .square.dark', '.arena-board .arena-square.dark', '.ranked-board .ranked-square.dark', '.puzzle-board .puzzle-square.dark', '.review-replay-board .review-replay-square.review-dark']) {
    assert.ok(css.includes(selector), `missing shared dark-square styling for ${selector}`);
  }
  assert.match(css, /\.chessboard \.piece-svg,\.arena-board \.piece-svg,\.ranked-board \.piece-svg,\.puzzle-board \.piece-svg,\.review-replay-board \.piece-svg/);
  assert.equal(pkg.version, '3.25.0');
});
