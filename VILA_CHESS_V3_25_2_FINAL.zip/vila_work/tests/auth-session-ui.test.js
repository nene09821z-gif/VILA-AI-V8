import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');

test('server-authenticated session is persisted and updates the account icon', () => {
  assert.match(main, /function saveSocialSession\(token, user\)/);
  assert.match(main, /localStorage\.setItem\(SOCIAL_SESSION_KEY, nextToken\)/);
  assert.match(main, /localStorage\.setItem\(SOCIAL_USER_KEY, JSON\.stringify\(socialState\.user\)\)/);
  assert.match(main, /function syncSocialNav\(\)/);
  assert.match(main, /#accountAvatar/);
  assert.match(html, /id="accountAvatar"/);
});

test('login and registration never claim success when the server omits token/profile', () => {
  assert.match(main, /Máy chủ không trả token và hồ sơ tài khoản hợp lệ/);
  assert.match(main, /socialApi\('\/auth\/login'/);
  assert.match(main, /socialApi\('\/auth\/register'/);
});

test('native OAuth clearly requires a configured backend rather than a fake relative callback', () => {
  assert.match(main, /function socialBackendBase\(\)/);
  assert.match(main, /Chưa cấu hình URL backend/);
  assert.match(main, /const base = socialBackendBase\(\); location\.href/);
});
