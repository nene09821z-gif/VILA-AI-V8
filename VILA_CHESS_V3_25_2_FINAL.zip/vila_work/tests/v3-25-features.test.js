import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import { OPENINGS } from '../src/openings.js';
import { adaptPayloadForProviderError } from '../server/ai-request.js';
import { generateOfflinePuzzle } from '../src/puzzle-generator.js';
import { chooseAlternateMove } from '../src/alternate-engine-core.js';

test('opening library is larger and every line is legal', () => {
  assert.ok(OPENINGS.length >= 300, `found ${OPENINGS.length}`);
  for (const o of OPENINGS) { const c = new Chess(); for (const san of o.san) c.move(san); }
});
test('pieces are shrunk and board effects exist in CSS', () => {
  const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
  for (const token of ['--piece-fill:80%', '.square.in-check', '.square.fx-capture', '.square.fx-castle']) assert.ok(css.includes(token), token);
});
test('provider payload adapts to max_completion_tokens', () => {
  const next = adaptPayloadForProviderError({ max_tokens: 9, temperature: .3 }, "Unsupported parameter: 'max_tokens'. Use 'max_completion_tokens'");
  assert.equal(next.max_completion_tokens, 9); assert.equal('max_tokens' in next, false);
});
test('offline engine returns a legal move', () => {
  const uci = chooseAlternateMove(new Chess().fen(), { profile: 'classic', depth: 3, maxTimeMs: 400 });
  assert.ok(new Chess().moves({ verbose: true }).some(m => m.from + m.to === uci.slice(0, 4)));
});
test('offline puzzle generator yields a legal single-solution puzzle', async () => {
  const p = await generateOfflinePuzzle({ budgetMs: 20000 });
  assert.ok(p, 'puzzle expected');
  const c = new Chess(p.fen);
  assert.ok(c.moves({ verbose: true }).some(m => m.from + m.to + (m.promotion || '') === p.best));
});
