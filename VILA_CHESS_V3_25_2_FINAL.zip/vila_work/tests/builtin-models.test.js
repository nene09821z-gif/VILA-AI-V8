import test from 'node:test';
import assert from 'node:assert/strict';
import { BUILTIN_FREE_MODEL_PRESETS, freePresetsForProvider, isLocalNoKeyEndpoint } from '../src/builtin-models.js';

test('bundled Free Tier presets are available without downloading provider catalogues', () => {
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.length >= 8);
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'gemini-3.8-flash'));
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'gemini-3.5-flash-lite'));
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'gemini-3.1-flash-lite'));
  assert.ok(!BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'gemini-3.7-flash'), 'do not offer a deprecated Gemini model as a quick preset');
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'gemini-3.6-flash'));
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'openai/gpt-oss-safeguard-20b'));
  assert.equal(BUILTIN_FREE_MODEL_PRESETS.filter(item => item.provider === 'openrouter').length, 1, 'use the current free router instead of fragile hardcoded free model IDs');
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'openai/gpt-oss-20b'));
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.some(item => item.model === 'openrouter/free'));
  assert.ok(BUILTIN_FREE_MODEL_PRESETS.every(item => item.free === true && item.note && item.endpoint));
  assert.ok(!BUILTIN_FREE_MODEL_PRESETS.some(item => item.model.includes('nemotron-3-ultra')), 'avoid hardcoded OpenRouter model variants that can be removed or re-priced');
});

test('preset filtering binds models to their real provider host and mode', () => {
  assert.ok(freePresetsForProvider({ mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' }).some(x => x.model === 'gemini-3.8-flash'));
  assert.ok(freePresetsForProvider({ mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' }).some(x => x.model === 'openai/gpt-oss-20b'));
  assert.deepEqual(freePresetsForProvider({ mode: 'gemini', endpoint: 'https://api.openai.com/v1' }), []);
});

test('only local loopback endpoints may omit an API key in OpenAI-compatible mode', () => {
  assert.equal(isLocalNoKeyEndpoint('http://localhost:11434/v1'), true);
  assert.equal(isLocalNoKeyEndpoint('http://127.0.0.1:11434/v1'), true);
  assert.equal(isLocalNoKeyEndpoint('https://api.groq.com/openai/v1'), false);
  assert.equal(isLocalNoKeyEndpoint('javascript:alert(1)'), false);
});
