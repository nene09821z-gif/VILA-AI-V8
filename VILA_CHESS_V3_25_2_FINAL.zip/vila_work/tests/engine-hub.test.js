import test from 'node:test';
import assert from 'node:assert/strict';
import { listChessEngines, analyzeWithEngine } from '../server/engine-hub.js';

test('hybrid engine catalogue reports real configured status instead of pretending engines are installed', () => {
  const engines = listChessEngines();
  assert.deepEqual(engines.map(engine => engine.id), ['stockfish', 'lc0', 'ethereal', 'berserk']);
  for (const engine of engines) {
    assert.equal(typeof engine.available, 'boolean');
    assert.ok(['ready', 'not-configured', 'binary-missing', 'weights-missing'].includes(engine.status));
  }
});

test('remote engine analysis rejects malformed FEN and unapproved engine IDs', async () => {
  await assert.rejects(analyzeWithEngine({ id: 'stockfish', fen: 'not a FEN' }), /FEN không hợp lệ/);
  await assert.rejects(analyzeWithEngine({ id: 'custom-shell', fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1' }), /không nằm trong danh sách/);
});

test('unconfigured remote engines fail clearly instead of returning fake moves', async () => {
  const item = listChessEngines().find(engine => engine.id === 'lc0');
  if (!item.available) {
    await assert.rejects(analyzeWithEngine({ id: 'lc0', fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1' }), /chưa được cài cấu hình đầy đủ/);
  }
});
