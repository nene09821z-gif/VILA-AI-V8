import test from 'node:test';
import assert from 'node:assert/strict';
import { CLOCK_PRESETS, RANKED_CLOCK_PRESETS, classifyTimeControl, parseClockPreset, formatClockTime } from '../src/clock.js';

test('clock presets cover ultra bullet, bullet, blitz, and rapid without untimed ranked games', () => {
  for (const value of ['untimed', '0.25+0', '0.5+0', '1+0', '2+0', '2+1', '3+0', '3+2', '5+0', '6+0', '10+0', '15+10', '20+0', '25+5', '30+0']) {
    assert.ok(CLOCK_PRESETS.some(item => item.value === value), `missing clock preset ${value}`);
  }
  assert.ok(!RANKED_CLOCK_PRESETS.some(item => item.value === 'untimed'));
  assert.equal(parseClockPreset('3+2').baseMs, 180_000);
  assert.equal(parseClockPreset('3+2').incrementMs, 2_000);
  assert.equal(parseClockPreset('0.25+0').baseMs, 15_000);
  assert.equal(classifyTimeControl('2+1'), 'bullet');
  assert.equal(classifyTimeControl('3+2'), 'blitz');
  assert.equal(classifyTimeControl('10+5'), 'rapid');
  assert.equal(parseClockPreset('not-a-clock').preset, '10+0');
});

test('clock formatting stays readable from untimed to sub-ten-second states', () => {
  assert.equal(formatClockTime(999_999, false), '∞');
  assert.equal(formatClockTime(600_000), '10:00');
  assert.equal(formatClockTime(9_999), '9.9');
  assert.equal(formatClockTime(0), '0.0');
  assert.equal(formatClockTime(-1), '0.0');
});
