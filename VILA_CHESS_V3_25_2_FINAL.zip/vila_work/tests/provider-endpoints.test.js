import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeBaseUrl, openAiChatUrl, openAiModelsUrl, anthropicMessagesUrl,
  anthropicModelsUrl, geminiModelsUrl, geminiGenerateContentUrl
} from '../server/provider-endpoints.js';

test('normalizes only safe HTTP(S) provider base URLs', () => {
  assert.equal(normalizeBaseUrl('https://example.com/v1/'), 'https://example.com/v1');
  assert.throws(() => normalizeBaseUrl('javascript:alert(1)'));
  assert.throws(() => normalizeBaseUrl('https://user:pass@example.com/v1'));
  assert.throws(() => normalizeBaseUrl('https://example.com/v1?key=secret'));
});

test('constructs OpenAI-compatible and Anthropic endpoint paths without duplicate suffixes', () => {
  assert.equal(openAiChatUrl('https://api.openai.com/v1'), 'https://api.openai.com/v1/chat/completions');
  assert.equal(openAiChatUrl('https://host.example/v1/chat/completions'), 'https://host.example/v1/chat/completions');
  assert.equal(openAiModelsUrl('https://api.openai.com/v1'), 'https://api.openai.com/v1/models');
  assert.equal(openAiModelsUrl('https://host.example/v1/chat/completions'), 'https://host.example/v1/models');
  assert.equal(anthropicMessagesUrl('https://api.anthropic.com'), 'https://api.anthropic.com/v1/messages');
  assert.equal(anthropicMessagesUrl('https://api.anthropic.com/v1'), 'https://api.anthropic.com/v1/messages');
  const anthropicList = new URL(anthropicModelsUrl('https://api.anthropic.com', 'claude-sonnet-latest'));
  assert.equal(anthropicList.pathname, '/v1/models');
  assert.equal(anthropicList.searchParams.get('limit'), '1000');
  assert.equal(anthropicList.searchParams.get('after_id'), 'claude-sonnet-latest');
});

test('constructs Gemini model discovery and generateContent endpoints with API key and pagination', () => {
  const list = new URL(geminiModelsUrl('https://generativelanguage.googleapis.com', 'a+b/secret', 'next token'));
  assert.equal(list.pathname, '/v1beta/models');
  assert.equal(list.searchParams.get('key'), 'a+b/secret');
  assert.equal(list.searchParams.get('pageSize'), '1000');
  assert.equal(list.searchParams.get('pageToken'), 'next token');
  const generate = new URL(geminiGenerateContentUrl('https://generativelanguage.googleapis.com', 'gemini-3.8-flash', 'my-key'));
  assert.equal(generate.pathname, '/v1beta/models/gemini-3.8-flash:generateContent');
  assert.equal(generate.searchParams.get('key'), 'my-key');
  assert.equal(new URL(geminiGenerateContentUrl('https://generativelanguage.googleapis.com/v1beta', 'models/gemini-3.8-flash', 'k')).pathname, '/v1beta/models/gemini-3.8-flash:generateContent');
});


test('normalizes a complete Gemini method endpoint before model discovery', () => {
  const inputs = [
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent',
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash',
    'https://generativelanguage.googleapis.com/v1beta/models/'
  ];
  for (const input of inputs) {
    assert.equal(new URL(geminiModelsUrl(input, 'test-key')).pathname, '/v1beta/models');
  }
  assert.equal(new URL(geminiGenerateContentUrl(inputs[0], 'gemini-3.6-flash', 'k')).pathname, '/v1beta/models/gemini-3.6-flash:generateContent');
});
