import test from 'node:test';
import assert from 'node:assert/strict';
import { parseUciInfoLine, formatUciScore } from '../src/analysis-utils.js';

test('parses Stockfish MultiPV UCI records and bounds line length', () => {
  const record = parseUciInfoLine('info depth 17 seldepth 22 multipv 2 score cp -34 nodes 12345 pv g1f3 d7d5 d2d4');
  assert.deepEqual(record, { depth: 17, multipv: 2, scoreType: 'cp', score: -34, pv: ['g1f3', 'd7d5', 'd2d4'] });
  assert.equal(parseUciInfoLine('bestmove g1f3'), null);
  assert.equal(parseUciInfoLine('info depth 3 multipv 9 score cp 10 pv e2e4'), null);
});

test('formats centipawn and mate scores', () => {
  assert.equal(formatUciScore({ scoreType: 'cp', score: 145 }), '+1.45');
  assert.equal(formatUciScore({ scoreType: 'cp', score: -7 }), '-0.07');
  assert.equal(formatUciScore({ scoreType: 'mate', score: 3 }), 'M3');
  assert.equal(formatUciScore({ scoreType: 'cp', score: -145, fen: '8/8/8/8/8/8/8/4k2K b - - 0 1' }), '+1.45');
  assert.equal(formatUciScore({ scoreType: 'mate', score: 3, fen: '8/8/8/8/8/8/8/4k2K b - - 0 1' }), '-M3');
});
