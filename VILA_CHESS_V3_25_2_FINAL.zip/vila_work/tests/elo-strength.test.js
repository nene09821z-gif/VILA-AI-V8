import { readFileSync } from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { clampTargetElo, resolveStockfishStrength } from '../src/elo-strength.js';

test('Elo target is clamped to the requested 500–3200 range', () => {
  assert.equal(clampTargetElo(0), 500);
  assert.equal(clampTargetElo(100), 500);
  assert.equal(clampTargetElo(500), 500);
  assert.equal(clampTargetElo(3200), 3200);
  assert.equal(clampTargetElo(4000), 3200);
});

test('low Elo uses Skill Level 0 plus increasing legal heuristic moves instead of invalid UCI_Elo', () => {
  const beginner = resolveStockfishStrength(500);
  const intermediate = resolveStockfishStrength(1000);
  const nearEngineFloor = resolveStockfishStrength(1310);
  assert.equal(beginner.limitStrength, false);
  assert.equal(beginner.uciElo, null);
  assert.equal(beginner.skillLevel, 0);
  assert.equal(beginner.mode, 'beginner-simulated');
  assert.ok(beginner.heuristicMoveProbability > intermediate.heuristicMoveProbability);
  assert.ok(intermediate.heuristicMoveProbability > nearEngineFloor.heuristicMoveProbability);
  assert.ok(beginner.heuristicMoveProbability <= 0.85);
  assert.equal(beginner.randomLegalMoveProbability, 1);
  assert.ok(intermediate.randomLegalMoveProbability < beginner.randomLegalMoveProbability);
  assert.ok(nearEngineFloor.randomLegalMoveProbability > 0);
  assert.ok(nearEngineFloor.randomLegalMoveProbability < intermediate.randomLegalMoveProbability);
  assert.equal(resolveStockfishStrength(1320).mode, 'uci-elo');
});

test('high Elo maps to Stockfish UCI_Elo supported range while retaining requested target', () => {
  assert.deepEqual(resolveStockfishStrength(2600), { targetElo: 2600, limitStrength: true, uciElo: 2600, skillLevel: 20, mode: 'uci-elo' });
  assert.equal(resolveStockfishStrength(3200).targetElo, 3200);
  assert.equal(resolveStockfishStrength(3200).uciElo, 3190);
});


test('Elo range and review symbols are wired into the actual UI and Stockfish call path', () => {
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  const schema = readFileSync(new URL('../src/settings-schema.js', import.meta.url), 'utf8');
  assert.match(main, /Elo 500–3200/);
  assert.match(main, /min=\"500\" max=\"3200\"/);
  assert.match(schema, /DEFAULTS\.botElo, 500, 3200/);
  assert.match(main, /resolveStockfishStrength\(settings\.botElo\)/);
  assert.match(main, /chooseBeginnerMoveFor\(game, requestedStrength\)/);
  assert.match(main, /randomLegalMoveProbability/);
  assert.match(main, /review-move-symbol symbol-\$\{tone\}/);
  assert.match(main, /review-symbol-legend/);
  assert.match(main, /aria-label=\"Chú giải ký hiệu đánh giá\"/);
});
