import test from 'node:test';
import assert from 'node:assert/strict';
import { isConfirmedFreeModel } from '../server/model-catalog.js';

test('free badge requires zero catalog pricing, a free route ID, or an official plan allow-list', () => {
  assert.equal(isConfirmedFreeModel({ id: 'vendor/model:free' }), true);
  assert.equal(isConfirmedFreeModel({ id: 'model', pricing: { prompt: '0', completion: '0' } }), true);
  assert.equal(isConfirmedFreeModel({ id: 'model', pricing: { prompt: '0.1', completion: '0' } }), false);
  assert.equal(isConfirmedFreeModel({ id: 'gemini-fast' }), false);
  assert.equal(isConfirmedFreeModel({ id: 'groq-model', free: true }), false);
});

test('Gemini official Free Tier text models are recognized only for Gemini endpoints', () => {
  const context = { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' };
  assert.equal(isConfirmedFreeModel({ name: 'models/gemini-3.8-flash' }, context), true);
  assert.equal(isConfirmedFreeModel({ name: 'gemini-2.5-flash-lite' }, context), true);
  assert.equal(isConfirmedFreeModel({ name: 'gemini-4-argon' }, context), false);
  assert.equal(isConfirmedFreeModel({ name: 'gemini-3.6-flash' }, context), true);
  assert.equal(isConfirmedFreeModel({ name: 'gemini-3.1-flash-lite' }, context), true);
  assert.equal(isConfirmedFreeModel({ name: 'gemini-3.7-flash' }, context), false, 'deprecated model must not receive a Free badge');
  assert.equal(isConfirmedFreeModel({ name: 'gemini-3.8-flash' }, { ...context, endpoint: 'https://example.com' }), false);
});

test('Groq Free Plan chat models are recognized only for the official Groq endpoint', () => {
  const context = { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' };
  assert.equal(isConfirmedFreeModel({ id: 'openai/gpt-oss-120b' }, context), true);
  assert.equal(isConfirmedFreeModel({ id: 'openai/gpt-oss-safeguard-20b' }, context), true);
  assert.equal(isConfirmedFreeModel({ id: 'qwen/qwen3.8-27b' }, context), true);
  assert.equal(isConfirmedFreeModel({ id: 'meta-llama/llama-3.3-70b-versatile' }, context), false);
  assert.equal(isConfirmedFreeModel({ id: 'openai/gpt-oss-120b' }, { ...context, endpoint: 'https://api.openai.com/v1' }), false);
});
