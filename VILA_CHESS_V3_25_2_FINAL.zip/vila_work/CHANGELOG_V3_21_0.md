# v3.21.0
- Improved random puzzle sampling and Stockfish evaluation budget.
- Added puzzle streak / best streak tracking and solve-time state.
- Kept legal move validation and existing SVG pieces.
- Added an explicit verification note for unrun integration/build checks.
