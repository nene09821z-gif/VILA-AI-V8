# Optimization plan — v3.0.0

## Included
- Responsive 8×8 board sized from actual CSS-pixel viewport/container measurements, including short-landscape viewport budgeting.
- Compact touch controls, last-move styling, optional synthesized move/capture/castling/check/checkmate sounds.
- Weighted randomized book of 71 opening lines; the candidate is accepted only if legal in the current position, and Stockfish takes over out of book.
- Stockfish Hash/Threads persist across moves instead of clearing the transposition table on every turn.
- Optional Vietnamese spoken hints with a use-this-move button.
- Coach source selector: language-capable API or local Stockfish scores/three PVs.
- Provider model discovery and conservative free-model labels; no guessed model IDs or inferred free tier.

## Release checks still required
1. Install dependencies and run `npm test`, including `tests/chess.test.js` that validates each opening SAN move.
2. Run `npm run build` and the Android GitHub workflow with the required Stockfish JS/WASM assets.
3. Smoke-test each provider's actual endpoint/key and measure API p50/p95 response time.
4. Install the resulting APK on Android 12 / OPPO A17k at DPI 360; test portrait, landscape, split-screen, tap hitboxes, audio unlock, Vietnamese TTS, clocks, undo, promotion, analysis, and arena controls.
5. Benchmark Stockfish Lite/Full latency, RAM, heat and battery at fixed positions; select default settings from measurements rather than assumptions.
