# VILA Chess v3.22.0

- Kept board annotation controls in a compact dedicated row below the board.
- Added responsive toolbar styling for small screens.
- Added collapse/expand for the analysis lines panel.
- Added local game recovery snapshots during board renders.
- Marked locally calculated rating history entries as local-only.
- See `REVIEW_V3_22_0.md` for verification and limitations.
