# VILA Chess v3.9.2 — Stockfish initialization recovery

- Bổ sung Stockfish ASM-JS (`stockfish-19-asm.js`) như lớp dự phòng không cần WebAssembly, dựa theo gói Stockfish.js 19.0.1.
- Chuỗi khởi tạo: Full tùy chọn → Lite single-thread → ASM-JS; Lite mặc định → ASM-JS. Nếu cả các engine đều không khởi động, giao diện báo lỗi rõ và lượt đi có thể dùng nước hợp lệ dự phòng.
- Chỉ chuyển engine dự phòng trong giai đoạn khởi tạo; lỗi lúc đang tìm kiếm đi qua đường dọn dẹp tác vụ hiện có để không đưa kết quả cũ sang worker mới.
- `scripts/copy-engine.mjs` đóng gói cả Lite JS/WASM và ASM-JS, kiểm tra toàn bộ asset trước khi xóa engine cũ. Full single-thread khoảng 94 MB vẫn là tùy chọn build riêng.
- Nâng phiên bản ứng dụng và health endpoint lên 3.9.2; bổ sung unit tests cho fallback chain và kiểm tra asset trong workflow.
- Endpoint API Gemini/Groq và các tính năng xem lại/lưu ván không đổi trong bản này; test tĩnh và cú pháp được chạy lại. APK vẫn cần build thành công trên GitHub Actions và kiểm tra trên Android thật trước khi tuyên bố phát hành.
