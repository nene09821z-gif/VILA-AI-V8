# Báo cáo kiểm thử — VILA Chess v3.9.2

Ngày: 17/10/2026.

## Kết quả đạt

- `npm run test:static`: **122/122 pass, 0 fail**.
- `node --check` trên toàn bộ tệp `.js` và `.mjs` thuộc `src/`, `server/`, `scripts/`, `tests/`: đạt.
- `python3 -m py_compile scripts/package-android-source.py`: đạt.
- JSON parse: `package.json`, `capacitor.config.json`, `public/openings-eco.json`: đạt.
- Hai kiểm thử đóng gói engine chạy trong thư mục fixture tạm: đạt. Thử nghiệm xác nhận bộ đóng gói đưa Lite JS/WASM, ASM-JS và license vào thư mục đích; nếu thiếu asset bắt buộc, script dừng mà không xóa bundle cũ.
- Kiểm thử helper engine xác nhận lựa chọn `auto → Lite`, đường dẫn asset, và chuỗi fallback `Full → Lite → ASM-JS → dừng`.
- Các test regression endpoint provider, lỗi API, lịch sử/xem lại, PGN, nhạc và bố cục di động vẫn đạt trong nhóm static.

## Bị chặn / chưa thể xác minh

- `npm test`: **122 test pass; `tests/chess.test.js` không khởi chạy** vì `ERR_MODULE_NOT_FOUND` với `chess.js`. Đây là lỗi thiếu dependency trong môi trường kiểm thử, không phải kết quả xác nhận các test luật cờ đã chạy.
- `npm install --no-audit --no-fund`: hết thời gian chờ sau 60 giây; `node_modules` không có.
- `npm run build`: dừng ở `prebuild` do không thể import `chess.js`; Vite build chưa chạy.
- Chưa build `app-debug.apk`, chưa chạy Stockfish thật từ package đã cài trong WebView Android, chưa gọi Gemini/Groq bằng API key thật và chưa thử trên điện thoại thật.

## Thay đổi đã kiểm tra trong v3.9.2

1. Đưa Stockfish ASM-JS (bản không cần WebAssembly) thành fallback cuối, theo tên asset được công bố bởi Stockfish.js 19.0.1. Chuỗi khởi tạo là Full tùy chọn → Lite → ASM-JS; mặc định vẫn dùng Lite.
2. Chỉ chuyển engine trong giai đoạn khởi tạo. Lỗi khi engine đang chạy chuyển qua luồng dọn dẹp hiện có, tránh chạy hai worker chồng lấn.
3. Asset Lite và ASM-JS được kiểm tra trước khi xóa bundle cũ. Cập nhật manifest và workflow để bắt buộc có cả Lite lẫn ASM-JS, trong khi Full ~94 MB vẫn là tùy chọn.
4. Thêm test đóng gói với fixture tạm, bao gồm ca thiếu asset phải giữ nguyên bundle cũ.
5. Phiên bản package và health endpoint tăng lên 3.9.2.

## Cần làm trước phát hành

- Chạy GitHub Actions có cài dependencies, qua `npm test`, `npm run build` và `assembleDebug`.
- Cài APK trên thiết bị Android/WebView thực, xác nhận Stockfish Lite nhận `uciok`/`readyok`, thử fallback ASM-JS và chơi một ván đầy đủ.
- Chạy lại kiểm thử luật cờ `tests/chess.test.js`, bao gồm nước đi sai luật, nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hòa và PGN.
- Thử riêng API Gemini/Groq với khóa do chủ ứng dụng cung cấp; không ghi API key vào log hoặc repository.
