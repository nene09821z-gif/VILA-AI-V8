# Báo cáo kiểm thử — VILA Chess v3.9.1

Ngày kiểm thử: 17/10/2026.

## Kết quả đạt

- `npm run test:static`: **120/120 pass, 0 fail**. Nhóm này bao gồm kiểm tra endpoint Gemini, lỗi/key redaction, preset/model catalogues, fallback Stockfish, review/history UI, PGN với FEN tùy chỉnh, nhạc dự phòng và bố cục di động.
- `node --check`: qua với các tệp JavaScript chính ở client, server và scripts.
- Kiểm tra JSON: `package.json`, `capacitor.config.json` parse thành công.
- `python3 -m py_compile scripts/package-android-source.py`: pass.

## Kết quả chưa xác nhận / bị chặn

- `npm test`: 120 bài đạt; 1 file (`tests/chess.test.js`) không khởi chạy được do `ERR_MODULE_NOT_FOUND: Cannot find package 'chess.js'`.
- `npm install --no-audit --no-fund --prefer-offline` bị timeout trong môi trường sửa; `node_modules` không có sau lần thử. Vì vậy không thể hoàn thành production build Vite hoặc build APK tại đây.
- Chưa thực hiện được smoke test gọi API bằng khóa Gemini/Groq thật, tải/chạy Stockfish trong Android WebView thật, phát nhạc trên thiết bị, hay thử kéo quân trên OPPO A17k. Những mục đó cần build thành công và chạy trên GitHub Actions/thiết bị.

## Các thay đổi quan trọng

1. Gemini endpoint được chuẩn hóa cho URL gốc/API root/URL đầy đủ `generateContent`; model hiện chọn trong giao diện được dùng trong đường dẫn.
2. Preset Gemini 3.7 Flash đã deprecated bị loại khỏi quick-pick. Groq dùng base URL tương thích OpenAI, chẳng hạn `https://api.groq.com/openai/v1`; model ID phải là ID được provider trả về.
3. Stockfish Lite là profile tự động mặc định. Full single-thread (~94 MB) không được đóng vào APK mặc định; có thể thêm chủ động bằng `INCLUDE_STOCKFISH_FULL=1`. Lỗi Full/timeout thử fallback Lite.
4. Lưu/xem lại lịch sử ván cờ, điều hướng theo nước đi, phân tích lại, xóa bản lưu và xuất PGN. PGN có SetUp/FEN cho ván bắt đầu ở thế cờ tùy chỉnh.
5. Nhạc Gymnopédie No. 1 được stream theo yêu cầu và có credit/license; Web Audio motif là fallback.
6. Các nhãn sai lầm/tốt nhất/xuất sắc là phân loại theo centipawn loss. `Thiên tài*` chỉ là heuristic dựa trên nước hy sinh ứng viên và đánh giá engine, không tương đương thuật toán riêng hay nhãn chính thức của Chess.com.

## Nguồn endpoint và tài nguyên tham khảo

- Gemini generateContent: https://ai.google.dev/api/generate-content
- Gemini model catalogue / deprecations: https://ai.google.dev/gemini-api/docs/models
- Groq models: https://console.groq.com/docs/models
- Stockfish npm package: https://www.npmjs.com/package/stockfish
- Bản thu Gymnopédie No. 1 và điều kiện cấp phép được ghi trong `MUSIC_CREDITS.md`.
