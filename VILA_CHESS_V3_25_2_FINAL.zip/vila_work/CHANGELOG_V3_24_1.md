# VILA Chess v3.24.1 — Piece artwork update

- Replaced the default flat SVG silhouettes with transparent PNG artwork cropped from the supplied reference image: glossy white and charcoal-black Staunton pieces with the original outline and shading.
- Added all 12 piece assets under `public/pieces/`; each board uses the shared `pieceSvgMarkup()` renderer, so play, analysis, puzzle, arena, promotion, and replay inherit the artwork consistently.
- Kept the Royal SVG style available as an alternate option. The default 2D style remains selectable in Settings.
- Added regression coverage for all 12 colour/type asset combinations.

## Verification
- `npm test`: 191 tests passed; 3 test files could not load because project dependencies (`chess.js`, `express`) are not installed in this environment. No assertion failures were reported in executed tests.
- Full browser build and APK build are not claimed as verified because dependencies were not installed here.
