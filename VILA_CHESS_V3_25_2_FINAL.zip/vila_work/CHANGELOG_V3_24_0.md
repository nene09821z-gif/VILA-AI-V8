# Thay đổi V3.24.0 (trên nền 3.23)

- **Quân 2D phẳng (mặc định, kiểu Chess.com) + Royal (tuỳ chọn trong Cài đặt)**;  (`src/pieces.js`): bộ quân SVG mới, đổ màu, viền tối; dùng chung cho mọi bàn, hộp phong cấp, quân kéo, trang chủ.
- **Ngẫu nhiên Trắng/Đen** là mặc định khi chơi bot; đấu trường AI có công tắc bốc thăm bên cho trận đơn.
- **5 bot offline mới**: VILA Gambit, Hypermodern, Strangler, Trickster, Rookie (`src/engines/personas.js`).
- **Kho khai cuộc riêng cho từng bot** (`src/bot-personas.js`), dùng ở chơi bot và đấu trường AI.
- **Đa dạng nước đi**: engine có `randomTop > 1` chọn ngẫu nhiên giữa các nước gần ngang điểm (`search-core.js`).
- **Nhạc YouTube** (`src/youtube-music.js`): dán link video/livestream/playlist, tự về piano khi lỗi. Nối lại nút bật/tắt nhạc ở trang chủ.

## Chưa kiểm chứng
`npm run test:static` pass 190/190. Chưa chạy `npm install && npm test` (cần chess.js), chưa build Vite, chưa thử trên thiết bị/YouTube thật.
