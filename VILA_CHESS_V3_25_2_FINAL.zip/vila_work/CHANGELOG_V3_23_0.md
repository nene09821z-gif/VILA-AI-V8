# Thay đổi V3.23 (trên nền 3.22.3)

- **Quân cờ**: bộ quân SVG dày nét, bo tròn, dùng chung cho mọi bàn (chơi thường, bot, đấu trường AI, puzzle, xếp hạng, xem lại).
- **Kéo quân mượt hơn**: quân kéo có kích thước đúng một ô (đo 1 lần), đặt ngay dưới ngón tay trước khung hình đầu, nhấc nhẹ lên trên đầu ngón (cảm ứng), ô đích hợp lệ sáng viền khi rê qua, ngưỡng bắt đầu kéo 4px.
- **Thêm 4 engine ngoại tuyến** (ngoài Stockfish): VILA Fortress (phòng thủ), VILA Endgame (tàn cuộc), VILA Dynamic (không gian/phát triển), VILA Blitz (nhanh, nông). Chọn trong Cài đặt → "Phong cách AI ngoại tuyến", chơi với bot (chế độ AI nhiều phong cách) và chọn làm người chơi trong Đấu trường AI. Đây là engine JavaScript riêng của VILA, không phải bản gốc của engine cùng tên.
- **Tốc độ engine**: chip "⚡ Stockfish · d18 · 1.2M nút/giây · 1.4s" dưới bàn cờ và đấu trường (độ sâu, nút/giây, thời gian). Engine ngoại tuyến báo nps/độ sâu qua worker.
- **Bảng kết quả cuối ván** (kiểu Chess.com): thắng/thua/hòa, Elo và biến động, tốc độ engine; nút Chơi lại / Ghép trận mới / Phân tích ván. Có ở chơi thường, xếp hạng và đấu trường AI (Esc hoặc chạm nền để đóng).
- **Mũi tên & bút vẽ chuẩn hoá**: thân mảnh + đầu tam giác, nước đi quân Mã vẽ chữ L, một lớp mờ cho mỗi mũi tên, vẽ lại cùng mũi tên để xoá, đổi màu thì thay màu, thêm màu xanh dương, xem trước khi kéo, chuột phải kéo để vẽ (Shift = đỏ, Ctrl = vàng, Alt = xanh dương), chạm trái xoá hết. Phân tích hiển thị 3 mũi tên cho 3 biến tốt nhất (đậm → nhạt).

## Chưa kiểm chứng
Bộ test `npm run test:static` (181 test) đã chạy và pass. Các test cần `chess.js`/`node_modules` (ví dụ `tests/alternate-engine.test.js`) chưa chạy được trong môi trường tạo bản này (không có mạng để `npm install`); hãy chạy `npm install && npm test` trên máy bạn. Phần kéo quân, mũi tên và bảng kết quả chưa được thử trực tiếp trên trình duyệt/điện thoại.
