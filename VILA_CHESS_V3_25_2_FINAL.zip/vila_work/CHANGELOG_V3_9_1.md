# VILA Chess v3.9.1 — API, Stockfish, Review & Music reliability

- Chuẩn hóa endpoint Gemini cho URL gốc, `/v1beta/models` và URL đầy đủ `models/{model}:generateContent`; model picker quyết định model gọi thực tế, tránh dùng model cũ được nhúng trong URL.
- Loại preset Gemini 3.7 Flash đã deprecated khỏi danh sách nhanh, thay bằng Gemini 3.1 Flash-Lite. Danh sách server và preset client được cập nhật đồng nhất.
- Stockfish Lite single-thread là lựa chọn tự động, giảm tải tải xuống/bộ nhớ. Đóng gói xác thực asset trước khi xóa engine cũ; Full (~94 MB) chỉ đóng gói khi chủ động bật `INCLUDE_STOCKFISH_FULL=1`. Lỗi khởi tạo/timeout của Full sẽ thử Lite.
- Thêm lịch sử các ván hoàn tất trên thiết bị, xem lại theo nước, nhảy nước trong danh sách, phân tích, xóa bản lưu và xuất PGN. Chuẩn hóa PGN header, bảo toàn FEN cho thế cờ khởi đầu tùy chỉnh.
- Thêm nhạc piano Gymnopédie No. 1 có ghi nguồn CC BY 3.0 và giai điệu Web Audio dự phòng khi offline/không phát được audio online.
- Bổ sung nhãn khai cuộc, tốt nhất, xuất sắc và nhãn `Thiên tài*` dựa trên heuristic bảo thủ; `Thiên tài*` không phải phân loại chính thức của Chess.com.
- Kiểm thử cuối: `npm run test:static` 120/120 đạt; `npm test` 120 bài đạt và 1 file không khởi chạy do môi trường thiếu `chess.js`. Không tuyên bố đã build APK hoặc xác thực API thật.
