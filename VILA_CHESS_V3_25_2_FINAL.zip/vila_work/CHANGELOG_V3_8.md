# VILA Chess v3.8.0 — AI Response & Drag Performance

## Priority 1 — AI API empty replies
- Added tolerant parsing for OpenAI Responses-style `output[]` and nested provider/gateway wrappers.
- Added non-streaming fallback parsing for SSE responses from OpenAI-compatible providers, Gemini, and Anthropic.
- Preserved chunk whitespace when concatenating response text; excluded Gemini thought/reasoning blocks from the final answer.
- Improved empty-answer diagnostics for output-token limits and provider tool-only responses.
- Redacted API keys and token query parameters from caught fetch/network diagnostics.
- Kept the existing single bounded retry policy: only no-text responses are eligible; auth, quota and network failures do not automatically retry.

## Priority 2 — Mobile board interaction
- Removed the per-frame `drop-shadow` filter from the dragged-piece ghost, retaining compositor-friendly transform and paint/layout containment.
- Cleans up the drag ghost/source opacity if pointer capture is lost or the pointer is cancelled.
- Guards delayed promotion choices against stale FEN/game epochs so a late dialog cannot move a piece in a newer game.
- Keeps the existing tap fallback, square-scoped synthetic click suppression, delegated listeners, and animation-frame-coalesced movement.

## Priority 3 — Regression/build guardrails
- Added regression tests for nested response wrappers, Gemini thought parts, SSE chunk assembly for three provider modes, error redaction and drag cleanup.
- Updated health endpoint and package version to `3.8.0`.
- Added a syntax check for `server/chat-response.js` to both GitHub Actions workflows.
- All prior gameplay modules and navigation/features remain in place.
