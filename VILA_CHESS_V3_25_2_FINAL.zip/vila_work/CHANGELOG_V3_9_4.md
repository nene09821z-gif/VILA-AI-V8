# VILA Chess v3.9.4

## Xem lại ván — ký hiệu kiểu chess annotation
- Bổ sung ký hiệu trên từng nước trong bảng xem lại: sách khai cuộc 📖, thiên tài* `!!`, tốt nhất `★`, xuất sắc `!`, tốt `✓`, chưa chính xác `?!`, sai lầm `?`, blunder `??`.
- Ký hiệu có mô tả truy cập (`title`/`aria-label`), giữ nhãn tiếng Việt cạnh bên và có chú giải để người dùng di động hiểu nhanh từng ký hiệu. Áp dụng cho cả lượt render ban đầu và cập nhật trực tiếp khi Stockfish phân tích.
- Khi nhảy qua từng vị trí, thông tin nước đi cũng hiển thị ký hiệu đã lưu nếu có.

## Elo 500–3200
- Settings schema hiện chấp nhận và chuẩn hóa Elo mục tiêu 500–3200.
- Thiết lập nhanh khi chơi cho phép chọn theo bước 100 từ 500 đến 3200; Cài đặt chấp nhận nhập bước 10; Đấu trường AI mở rộng cùng phạm vi.
- Thêm `src/elo-strength.js`: dưới 1320 tắt `UCI_LimitStrength`, dùng Skill Level 0 và trộn một xác suất nước heuristic hợp lệ tăng dần khi Elo mục tiêu giảm; ở dải rất thấp có thể chọn ngẫu nhiên một nước hợp lệ để mô phỏng người mới; từ 1320 trở lên dùng UCI_Elo trong phạm vi engine 1320–3190. Mục tiêu 3200 được hiển thị như mức yêu cầu nhưng ánh xạ gần mức tối đa 3190 của engine.
- Không tuyên bố rằng điểm Elo được chứng nhận; sức mạnh thực tế phụ thuộc engine, thời gian, độ sâu và thiết bị.

## Kiểm thử
- `node --check src/main.js`, `src/elo-strength.js`, `src/game-review.js`: đạt.
- `npm run test:static`: 128/128 đạt.
- Build Vite/APK chưa xác nhận vì môi trường tạo ZIP không có `node_modules` đã cài; workflow phải build lại để xác minh các dependencies và APK.
