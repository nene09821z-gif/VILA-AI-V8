# VILA V20.0.0
- Giao diện kiểu DeepSeek: header gọn (menu · model · chat mới), ô nhập có nút Suy nghĩ / Tìm kiếm / mic / + / gửi.
- Nút `+`: Chụp ảnh · Ảnh & video · File & ZIP · Tạo ảnh AI · Tạo video AI. Video được lấy 3 khung hình để AI xem.
- Gemini là engine AI duy nhất; endpoint nằm ở `assets/endpoints.js`, API key được lưu an toàn qua Android Keystore và cấu hình tại Cài đặt. Tìm kiếm web tự động được bật cho các yêu cầu cần thông tin mới/file/link.
- Quyền Android: camera, ảnh, video (Android 13+: READ_MEDIA_*), xin một lần lúc mở app.
- Đăng nhập email/Google: điền `assets/firebase-config.js` (xem FIREBASE_SETUP_V15.txt).

- V20 thêm xuất project ZIP theo yêu cầu, tải file trực tiếp từ kết quả web, mức suy luận low/medium/high và bảo toàn toàn bộ nội dung gốc của `MainActivity.java` (chỉ chèn phần tích hợp mới).
