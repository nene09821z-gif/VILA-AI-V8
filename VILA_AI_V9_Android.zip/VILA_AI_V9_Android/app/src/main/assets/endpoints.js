/* VILA Gemini endpoint configuration. */
window.VILA_ENDPOINTS = Object.freeze({
  gemini: Object.freeze({
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
    nativeBase: 'https://generativelanguage.googleapis.com/v1beta',
    videoModel: 'veo-3.1-generate-preview'
  })
});
