import { chooseAlternateMove } from './alternate-engine-core.js';

self.addEventListener('message', event => {
  const { id, fen, options } = event.data || {};
  if (!Number.isInteger(id)) return;
  try {
    self.postMessage({ id, uci: chooseAlternateMove(fen, options || {}) });
  } catch (error) {
    self.postMessage({ id, error: String(error?.message || 'Không thể tính nước đi.') });
  }
});
