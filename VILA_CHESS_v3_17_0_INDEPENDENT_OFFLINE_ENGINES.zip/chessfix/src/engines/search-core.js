import { PIECE_VALUE } from './evaluation-utils.js';

const MATE_SCORE = 32000;
const INF = 33000;
const TT_EXACT = 0;
const TT_LOWER = 1;
const TT_UPPER = 2;
const DEFAULT_TT_SIZE = 30000;

const uciOf = move => `${move.from}${move.to}${move.promotion || ''}`;
const positionKey = chess => chess.fen().split(' ').slice(0, 5).join(' ');
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

function toTableScore(score, ply) {
  if (score > MATE_SCORE - 1000) return score + ply;
  if (score < -MATE_SCORE + 1000) return score - ply;
  return score;
}
function fromTableScore(score, ply) {
  if (score > MATE_SCORE - 1000) return score - ply;
  if (score < -MATE_SCORE + 1000) return score + ply;
  return score;
}

function moveOrderScore(move, ttMove, ply, ctx) {
  const uci = uciOf(move);
  if (uci === ttMove) return 2_000_000;
  if (move.promotion) return 1_000_000 + (PIECE_VALUE[move.promotion] || 0) * 10;
  if (move.captured) {
    const victim = PIECE_VALUE[move.captured] || 100;
    const attacker = PIECE_VALUE[move.piece] || 100;
    let score = 800_000 + victim * 16 - attacker;
    if (ctx.profile.style === 'tactical') score += victim * 2;
    if (move.san?.includes('#')) score += 900_000;
    if (move.san?.includes('+')) score += 2_000;
    return score;
  }
  if (move.san?.includes('#')) return 1_700_000;
  if (move.san?.includes('+')) return ctx.profile.style === 'aggressive' ? 120_000 : 65_000;
  if (ctx.killers[ply]?.[0] === uci) return 70_000;
  if (ctx.killers[ply]?.[1] === uci) return 60_000;
  const histKey = `${move.piece}${move.to}`;
  return ctx.historyHeuristic.get(histKey) || 0;
}

function orderedMoves(moves, ttMove, ply, ctx, capturesOnly = false) {
  const candidates = capturesOnly ? moves.filter(move => move.captured || move.promotion) : moves;
  return candidates.sort((a, b) => moveOrderScore(b, ttMove, ply, ctx) - moveOrderScore(a, ttMove, ply, ctx));
}

function rememberQuietCutoff(move, depth, ply, ctx) {
  if (move.captured || move.promotion) return;
  const uci = uciOf(move);
  const current = ctx.killers[ply] || [];
  if (current[0] !== uci) ctx.killers[ply] = [uci, current[0]].filter(Boolean).slice(0, 2);
  const key = `${move.piece}${move.to}`;
  ctx.historyHeuristic.set(key, clamp((ctx.historyHeuristic.get(key) || 0) + depth * depth * 12, -100000, 100000));
}

function staticScore(chess, evaluate) {
  const whiteScore = evaluate(chess);
  return chess.turn() === 'w' ? whiteScore : -whiteScore;
}

function stopSearch(ctx) {
  if (ctx.stopped) return true;
  if (ctx.nodes >= ctx.maxNodes) { ctx.stopped = true; return true; }
  // Avoid reading the clock for every node; this is materially cheaper on phones.
  if ((ctx.nodes & 127) === 0 && Date.now() >= ctx.deadline) { ctx.stopped = true; return true; }
  return false;
}

function quiescence(chess, alpha, beta, ply, qply, ctx, evaluate) {
  ctx.nodes += 1;
  if (stopSearch(ctx)) return 0;
  if (chess.isDraw()) return 0;

  const inCheck = chess.isCheck();
  let standPat = -INF;
  if (!inCheck) {
    standPat = staticScore(chess, evaluate);
    if (standPat >= beta) return standPat;
    if (standPat > alpha) alpha = standPat;
    if (qply >= ctx.maxQply) return standPat;
  }

  const legalMoves = chess.moves({ verbose: true });
  if (!legalMoves.length) return inCheck ? -MATE_SCORE + ply : 0;
  if (inCheck && qply >= ctx.maxQply) {
    // At the safety cap, preserve terminal checkmate detection but avoid
    // recursively exploring an unbounded chain of checks.
    return staticScore(chess, evaluate) - 35;
  }
  const moves = inCheck ? orderedMoves(legalMoves, null, ply, ctx) : orderedMoves(legalMoves, null, ply, ctx, true);
  for (const move of moves) {
    if (stopSearch(ctx)) break;
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const score = -quiescence(chess, -beta, -alpha, ply + 1, qply + 1, ctx, evaluate);
    chess.undo();
    if (ctx.stopped) break;
    if (score >= beta) return score;
    if (score > alpha) alpha = score;
  }
  return inCheck && alpha === -INF ? -MATE_SCORE + ply : Math.max(alpha, standPat);
}

function negamax(chess, depth, alpha, beta, ply, ctx, evaluate, allowNull = true) {
  ctx.nodes += 1;
  if (stopSearch(ctx)) return 0;
  if (chess.isDraw()) return 0;
  const inCheck = chess.isCheck();
  if (depth <= 0) return quiescence(chess, alpha, beta, ply, 0, ctx, evaluate);

  const key = positionKey(chess);
  const entry = ctx.table.get(key);
  const originalAlpha = alpha;
  const originalBeta = beta;
  let ttMove = null;
  if (entry) {
    ttMove = entry.move;
    if (entry.depth >= depth && ply > 0) {
      const ttScore = fromTableScore(entry.score, ply);
      if (entry.flag === TT_EXACT) return ttScore;
      if (entry.flag === TT_LOWER) alpha = Math.max(alpha, ttScore);
      else if (entry.flag === TT_UPPER) beta = Math.min(beta, ttScore);
      if (alpha >= beta) return ttScore;
    }
  }

  // Late-move reduction: only reduce late quiet moves at sufficient depth.
  // We intentionally omit null-move pruning because its zugzwang behavior is
  // unreliable in low-material endings and VILA has no tablebase to verify it.
  const moves = orderedMoves(chess.moves({ verbose: true }), ttMove, ply, ctx);
  if (!moves.length) return inCheck ? -MATE_SCORE + ply : 0;

  let bestScore = -INF;
  let bestMove = null;
  let moveIndex = 0;
  for (const move of moves) {
    if (stopSearch(ctx)) break;
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const quiet = !move.captured && !move.promotion && !move.san?.includes('+');
    let nextDepth = depth - 1;
    let score;
    if (ctx.profile.lateMoveReduction && moveIndex >= 4 && depth >= 3 && quiet && !inCheck) {
      score = -negamax(chess, nextDepth - 1, -alpha - 1, -alpha, ply + 1, ctx, evaluate, false);
      if (!ctx.stopped && score > alpha) score = -negamax(chess, nextDepth, -beta, -alpha, ply + 1, ctx, evaluate, false);
    } else {
      score = -negamax(chess, nextDepth, -beta, -alpha, ply + 1, ctx, evaluate, false);
    }
    chess.undo();
    if (ctx.stopped) break;
    moveIndex += 1;
    if (score > bestScore) { bestScore = score; bestMove = uciOf(move); }
    if (score > alpha) alpha = score;
    if (alpha >= beta) {
      if (quiet) rememberQuietCutoff(move, depth, ply, ctx);
      break;
    }
  }

  if (ctx.stopped) return bestScore === -INF ? 0 : bestScore;
  const flag = bestScore <= originalAlpha ? TT_UPPER : bestScore >= originalBeta ? TT_LOWER : TT_EXACT;
  if (ctx.table.size >= ctx.maxTableSize) {
    // Map insertion order is a cheap age approximation; keep memory bounded.
    const removeCount = Math.max(1, Math.floor(ctx.maxTableSize * 0.1));
    const keys = ctx.table.keys();
    for (let i = 0; i < removeCount; i += 1) { const next = keys.next(); if (next.done) break; ctx.table.delete(next.value); }
  }
  ctx.table.set(key, { depth, score: toTableScore(bestScore, ply), flag, move: bestMove });
  return bestScore;
}

/**
 * Iterative-deepening alpha-beta engine with capture quiescence, transposition
 * table, TT/capture/promotion/check/killer/history move ordering, a bounded
 * late-move reduction, and hard time/node limits suitable for phone browsers.
 */
export function searchBestMove(chess, engine, evaluate, options = {}) {
  const legalAtRoot = chess.moves({ verbose: true });
  if (!legalAtRoot.length) return null;
  const requestedDepth = Number(options.depth) || engine.defaultDepth || 5;
  const maxDepth = clamp(Math.floor(requestedDepth), 1, 7);
  const maxNodes = clamp(Math.floor(Number(options.maxNodes) || engine.maxNodes || 30000), 500, 80000);
  const maxTimeMs = clamp(Math.floor(Number(options.maxTimeMs) || engine.maxTimeMs || 800), 100, 2500);
  const ctx = {
    profile: engine,
    nodes: 0,
    maxNodes,
    deadline: Date.now() + maxTimeMs,
    stopped: false,
    maxQply: clamp(Number(options.maxQply) || 8, 2, 12),
    maxTableSize: clamp(Number(options.maxTableSize) || DEFAULT_TT_SIZE, 1000, 80000),
    table: new Map(),
    killers: [],
    historyHeuristic: new Map(),
    completedDepth: 0
  };
  let bestMove = legalAtRoot[0];
  let bestScore = -INF;
  let previousBest = null;

  // Each completed iteration is a safe answer if the next iteration hits a
  // time/node cap. Root scores reset each depth to avoid a partial iteration
  // overwriting a previous valid best move.
  for (let depth = 1; depth <= maxDepth; depth += 1) {
    if (ctx.stopped || Date.now() >= ctx.deadline || ctx.nodes >= ctx.maxNodes) break;
    const ttEntry = ctx.table.get(positionKey(chess));
    const rootTtMove = ttEntry?.move || previousBest;
    const moves = orderedMoves(chess.moves({ verbose: true }), rootTtMove, 0, ctx);
    let iterationBest = null;
    let iterationScore = -INF;
    let alpha = -INF;
    const beta = INF;
    for (const move of moves) {
      if (stopSearch(ctx)) break;
      chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
      const score = -negamax(chess, depth - 1, -beta, -alpha, 1, ctx, evaluate);
      chess.undo();
      if (ctx.stopped) break;
      if (score > iterationScore) { iterationScore = score; iterationBest = move; }
      if (score > alpha) alpha = score;
    }
    if (ctx.stopped || !iterationBest) break;
    bestMove = iterationBest;
    bestScore = iterationScore;
    previousBest = uciOf(iterationBest);
    ctx.completedDepth = depth;
    const rootKey = positionKey(chess);
    ctx.table.set(rootKey, { depth, score: toTableScore(bestScore, 0), flag: TT_EXACT, move: previousBest });
    if (Math.abs(bestScore) >= MATE_SCORE - 100) break;
  }

  if (!bestMove) return null;
  return {
    uci: uciOf(bestMove),
    score: Number.isFinite(bestScore) ? bestScore : 0,
    depth: ctx.completedDepth,
    nodes: ctx.nodes,
    elapsedMs: Math.max(0, maxTimeMs - Math.max(0, ctx.deadline - Date.now())),
    stopped: ctx.stopped
  };
}
