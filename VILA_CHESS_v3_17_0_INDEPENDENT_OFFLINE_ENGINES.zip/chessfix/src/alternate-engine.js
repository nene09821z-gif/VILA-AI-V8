import { chooseAlternateMove } from './alternate-engine-core.js';
export { ALTERNATE_ENGINE_PROFILES, chooseAlternateMove, analyzeAlternateMove } from './alternate-engine-core.js';


let offlineWorker = null;
let offlineRequestSequence = 0;
const offlineRequests = new Map();

function createOfflineWorker() {
  if (typeof Worker === 'undefined') return null;
  try {
    const worker = new Worker(new URL('./alternate-engine-worker.js', import.meta.url), { type: 'module' });
    worker.addEventListener('message', event => {
      const data = event.data || {};
      const pending = offlineRequests.get(data.id);
      if (!pending) return;
      offlineRequests.delete(data.id);
      clearTimeout(pending.timeout);
      if (data.error) pending.reject(new Error(data.error));
      else pending.resolve(data.uci || null);
    });
    worker.addEventListener('error', () => {
      worker.terminate();
      if (offlineWorker === worker) offlineWorker = null;
      for (const [id, pending] of offlineRequests) {
        offlineRequests.delete(id);
        clearTimeout(pending.timeout);
        // The UI remains functional on browsers without a working module worker.
        try { pending.resolve(chooseAlternateMove(pending.fen, pending.options)); }
        catch (error) { pending.reject(error); }
      }
    });
    return worker;
  } catch {
    return null;
  }
}

/** Prefer a module worker so deeper searches do not freeze the board animation. */
export function chooseAlternateMoveAsync(fen, options = {}) {
  const worker = offlineWorker || (offlineWorker = createOfflineWorker());
  if (!worker) {
    try { return Promise.resolve(chooseAlternateMove(fen, options)); }
    catch (error) { return Promise.reject(error); }
  }
  const id = ++offlineRequestSequence;
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      const pending = offlineRequests.get(id);
      if (!pending) return;
      offlineRequests.delete(id);
      reject(new Error('AI ngoại tuyến phản hồi quá thời gian. Hãy thử lại hoặc giảm độ sâu.'));
    }, Math.max(4000, Math.min(10000, Number(options.maxTimeMs || 1000) + 3500)));
    offlineRequests.set(id, { resolve, reject, timeout, fen, options });
    try { worker.postMessage({ id, fen, options }); }
    catch (error) {
      offlineRequests.delete(id);
      clearTimeout(timeout);
      reject(error);
    }
  });
}
