import { Chess } from 'chess.js';
import { searchBestMove } from './engines/search-core.js';
import { LEELA_STYLE, evaluateLeelaStyle } from './engines/leela-style.js';
import { TACTICAL, evaluateTactical } from './engines/tactical.js';
import { AGGRESSIVE, evaluateAggressive } from './engines/aggressive.js';
import { evaluateVilaClassic } from './engines/vila-classic.js';

// These are independent VILA evaluation engines sharing a common, stronger
// search kernel. They do not include the original upstream Lc0/Ethereal/Berserk.
export const ALTERNATE_ENGINE_PROFILES = Object.freeze({
  lc0: LEELA_STYLE,
  ethereal: TACTICAL,
  berserk: AGGRESSIVE,
  classic: Object.freeze({ id: 'classic', name: 'VILA Classic', defaultDepth: 4, maxNodes: 30000, maxTimeMs: 750, style: 'balanced', lateMoveReduction: true, randomTop: 1 })
});

const evaluators = Object.freeze({
  lc0: evaluateLeelaStyle,
  ethereal: evaluateTactical,
  berserk: evaluateAggressive,
  classic: evaluateVilaClassic
});

function profileKey(value) {
  const candidate = String(value || 'classic').toLowerCase();
  return Object.prototype.hasOwnProperty.call(ALTERNATE_ENGINE_PROFILES, candidate) ? candidate : 'classic';
}

/** Return a legal UCI move from an offline VILA engine. */
export function chooseAlternateMove(fen, options = {}) {
  let chess;
  try { chess = new Chess(String(fen || '')); } catch { return null; }
  const key = profileKey(options.profile || options.engine);
  if (chess.isGameOver()) return null;
  const profile = ALTERNATE_ENGINE_PROFILES[key];
  const result = searchBestMove(chess, profile, evaluators[key], options);
  return result?.uci || null;
}

/** Diagnostics are exposed for local tests and optional analysis UI. */
export function analyzeAlternateMove(fen, options = {}) {
  let chess;
  try { chess = new Chess(String(fen || '')); } catch { return null; }
  const key = profileKey(options.profile || options.engine);
  if (chess.isGameOver()) return null;
  return searchBestMove(chess, ALTERNATE_ENGINE_PROFILES[key], evaluators[key], options);
}
