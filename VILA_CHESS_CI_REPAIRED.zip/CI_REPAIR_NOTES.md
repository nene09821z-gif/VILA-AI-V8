# CI repair notes

This package adds a reproducible GitHub Actions Android workflow at `.github/workflows/android.yml`.
It installs dependencies before tests, checks JavaScript syntax, runs the project's full test suite,
builds the web assets, syncs the Capacitor Android project, builds a debug APK, verifies that the APK
exists, and uploads it as an artifact.

## Verification performed in the available workspace

- JavaScript/MJS syntax checks: passed.
- Targeted static tests previously selected: 33/33 passed.
- Full `npm test` in this workspace: 174 passed, 7 failed because dependencies are not installed here
  (`chess.js` and `express` could not be resolved). This environment therefore cannot certify the full
  suite or the APK build. CI will install declared dependencies before executing the suite.

The screenshot from the user's previous CI run reports 193 tests with 4 failures. Those four specific
assertion failures cannot be diagnosed from the screenshot because the failure names and stack traces
are not visible. The workflow intentionally does not suppress or skip failing tests; it will expose the
full failure output and stop before packaging if any test fails.
