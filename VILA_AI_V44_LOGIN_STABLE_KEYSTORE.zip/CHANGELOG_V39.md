# VILA AI Studio V39

- Added keyless discovery of OpenRouter's public model catalog. Chat still requires a valid API key, so model browsing cannot be mistaken for chat authentication.
- Model entries continue to be fetched live from the selected provider's `/models` endpoint where supported, with on-device catalog caching and provider-scoped model selections.
- Tightened Gemini free-tier ranking to include the currently documented `gemini-3.8-flash` and `gemini-3.1-flash-lite` families while not claiming unlimited quota.
- Updated app label and Android version metadata to VILA AI Studio 39.0.0 (versionCode 45).
- Added a mocked runtime regression test for public OpenRouter discovery, pricing-based free flags, and key-required behavior for authenticated providers.
- Clarified that Android's foreground service improves active-request continuity but cannot guarantee 24/7 execution under OS battery policies, device-vendor task killers, or provider/network outages.
