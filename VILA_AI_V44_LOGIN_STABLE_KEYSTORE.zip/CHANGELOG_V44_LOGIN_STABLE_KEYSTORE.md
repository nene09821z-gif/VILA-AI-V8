# V44 — Stable debug signing key, email verification, Google/email account linking

## Root cause fixed: Google Sign-In breaking after every CI build
Every earlier V41–V43 "Google login fix" changelog patched the client code, but the real
reason sign-in kept failing on the debug APK was infrastructure, not code: GitHub Actions'
`android-actions/setup-android` step generates a **fresh, random debug keystore on every run**
(or reuses a runner image default that isn't guaranteed stable release to release). That means
the debug APK's signing certificate SHA-1 fingerprint changed on every workflow run, so the
SHA-1 registered in Firebase Console yesterday almost never matches the APK you downloaded
today. Google's Credential Manager then refuses with `DEVELOPER_ERROR` (reported to the app
as "Google OAuth bị từ chối").

**Fix:** a debug keystore is now committed to the repo at `keystore/vila-debug.keystore`
(standard alias `androiddebugkey`, store/key password `android`, matching Android's own debug
keystore conventions). The workflow copies it to `~/.android/debug.keystore` before Gradle
runs, so **every debug build from CI is now signed with the same certificate**, forever
(`.gitignore` and the source-ZIP step were updated so this file is no longer stripped out).

Its fingerprint — **register this once in Firebase Console → Project settings → Your apps →
`com.vila.ai` → Add fingerprint**, and it only needs to be done once:

```
SHA-1: B8:D7:76:33:39:64:D9:D4:4A:C4:19:A3:C1:E7:35:C8:AD:0A:46:FD
```

After adding it, download the updated `google-services.json` from Firebase Console and replace
`app/google-services.json` in this repo so the `client_type=1` OAuth entry matches — this lets
Firebase Console show the Android client as verified (the Web `client_type=3` entry used for
`webClientId` doesn't change).

The release build is unaffected: it already uses a persistent secret-based keystore
(`ANDROID_KEYSTORE_BASE64`) when configured, and stays unsigned otherwise — see
`FIREBASE_SETUP_V41.txt` for that one-time setup.

## Email verification
- `createUserWithEmailAndPassword` (both native Android and the browser-preview Web SDK path)
  now automatically sends a verification email right after account creation.
- New bridge method `firebaseResendVerification()` / `window.resendVerificationEmail()` lets a
  signed-in user request another verification email.
- The account modal shows an amber "Email chưa xác minh" banner with a **Gửi lại** (resend)
  button whenever the signed-in user's `emailVerified` is false. `accountStatus` also flags
  unverified email inline.
- `firebaseAuthState()` / the Firebase user JSON now include `emailVerified` so the UI can
  react to it.

## Email ↔ Google account linking
Previously, if someone registered with email/password and later tapped "Tiếp tục với Google"
using the same address, Firebase correctly refused the collision but the app only showed a
generic error — there was no way to actually use both sign-in methods on one account.

Now: when Google sign-in collides with an existing email/password account
(`FirebaseAuthUserCollisionException` natively, `auth/account-exists-with-different-credential`
on the Web SDK), VILA keeps the pending Google credential, tells the user to log in once with
their email and password, and **automatically links the Google credential to that account**
right after the password login succeeds — so both methods work afterward.

## Still missing / suggested priority order
1. **Register the SHA-1 above in Firebase Console** — nothing else in this list matters for
   Google Sign-In until that one-time step is done, since it was the actual recurring bug.
2. Gate app usage until email is verified (currently verification is informational only — a
   user can keep using the app with an unverified email).
3. A persistent **release** keystore + `ANDROID_KEYSTORE_BASE64`/password/alias GitHub secrets
   are still optional; without them the release APK stays unsigned and unusable for Google
   Sign-In in production. Debug APK + the SHA-1 above is enough for testing.
4. No rate limiting on password-reset / resend-verification taps beyond the client-side status
   text; Firebase enforces its own server-side throttling, but a short client-side cooldown
   would reduce accidental spamming.
5. No "show password" toggle or password-strength meter on the register field.
6. No deep link / App Link handling for the Firebase password-reset or email-verification links
   (they currently open in the system browser rather than returning to the app).
