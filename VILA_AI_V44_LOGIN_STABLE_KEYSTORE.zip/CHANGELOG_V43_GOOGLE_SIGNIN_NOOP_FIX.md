# V43 — Native Google Sign-In path

- Android Google login invokes Credential Manager and requests the Google account picker with authorized-account filtering disabled.
- Native launch exceptions and asynchronous credential failures are surfaced to the login screen.
- The JavaScript-to-native call is asynchronous: the app stays in a waiting state until Android reports the actual Firebase result. No short timeout is shown while the user is selecting a Google account.
- Real authentication depends on Firebase Google provider, Web OAuth client ID, and the SHA-1 for the certificate signing the installed APK. GitHub Actions emits the fingerprint for the build.
