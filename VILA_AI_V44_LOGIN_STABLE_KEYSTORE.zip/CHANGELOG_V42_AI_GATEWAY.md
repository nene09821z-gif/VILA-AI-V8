# V42 — AI Gateway, Auth Gate, Adaptive Routing, and Diagnostics

## Added
- AI Gateway dashboard inside the existing V41 app; original chat, workspace, file export, direct provider calls and image/video flows are retained.
- Optional Node.js Gateway with normalized OpenAI-style chat API, streaming SSE, model discovery, health state, bounded timeout/retry/fallback, task routing, per-user request limits, and Firebase Admin ID-token verification in production.
- Server provider keys are read from environment/secret manager. Client cannot select an arbitrary server-side Base URL.
- Firebase native ID-token bridge so an authenticated Android user can use the Gateway without persisting Firebase ID tokens.
- Endpoint/model scan and explicit deep chat probe; UI warns that deep probes can consume provider quota.
- HTTPS-only app release URL checking endpoint (`/v1/app/version`) and in-app release page hand-off.
- Node engine unit tests and CI validation step for V42 backend/UI contract.
- Filled the Android Firebase client properties available in the supplied project config (`vila-studio`, `com.vila.ai`).

## Security / accuracy
- Production server refuses `AUTH_MODE=off`; dev open mode is for localhost tests only.
- Authentication/permission failures are not treated as retryable. Fallback is bounded to supported transient/model-unavailable failures and cannot safely swap providers after a response stream has begun.
- No provider API key or Firebase Admin credential is bundled into the server. Keep `.env`, service-account files and release signing secrets out of source control.
- Diagnostics report/fix routing-level recoverable failures only; they do not rewrite arbitrary source code or override provider account restrictions.
- Usage counters are process-memory counters, not a durable billing ledger.
- Update check does not silently install APKs. Android's package installer still requires user interaction; a trusted HTTPS release URL must be configured by the operator.

## Firebase setup still required
- Enable Email/Password and/or Google providers in Firebase Console.
- Google sign-in requires the signing certificate SHA-1 and an OAuth Web Client ID. The updated supplied `google-services.json` includes a Web OAuth client and the build workflow extracts it automatically. Browser preview separately needs the Firebase Web App `appId`.
- Browser preview additionally needs the Firebase Web App `appId`.

## Source validation run
- `node --check` on backend source, JS assets and extracted inline scripts: PASS.
- `node --test server/test/*.test.js`: PASS (5 engine tests).
- `scripts/test-v42-gateway.js`: PASS.
- `scripts/test-firebase-v41.js`: PASS.
- `scripts/test-key-persistence-v37.js`: PASS.
- `scripts/test-endpoints-v38.js`: PASS (24 endpoint tests).
- `scripts/test-openrouter-public-free-v39.js`: PASS.
- `scripts/smoke-test-v32.js`: PASS.
- HTML id/icon coverage, Firebase client-config JSON, Android manifest XML and raster icon decoding: PASS.
- A Gradle APK build was not run in this workspace because the Gradle executable/wrapper script and Android SDK are not installed here. Run the GitHub Actions workflow to verify the actual Android build.
- Live provider calls, Firebase Console provider status, server deployment and Google OAuth sign-in were not tested because no provider keys, Firebase Admin credentials, release URL or OAuth Web Client ID were supplied.
