'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { classifyTask, normalizeOpenAIBase, isRetryableStatus, modelFor, rankProviders } = require('../src/engine');

test('task classifier detects coding, reasoning, research, multimodal and general prompts', () => {
  assert.equal(classifyTask([{role:'user',content:'Sửa code JavaScript giúp tôi'}]), 'coding');
  assert.equal(classifyTask([{role:'user',content:'Hãy phân tích thuật toán này từng bước'}]), 'reasoning');
  assert.equal(classifyTask([{role:'user',content:'Tìm tin tức mới nhất trên web'}]), 'research');
  assert.equal(classifyTask([{role:'user',content:[{type:'image_url',image_url:{url:'data:image/png;base64,AA=='}}]}]), 'multimodal');
  assert.equal(classifyTask([{role:'user',content:'Xin chào'}]), 'general');
});

test('base URL normalizer strips endpoint suffixes and rejects URL credentials', () => {
  assert.equal(normalizeOpenAIBase('https://example.test/v1/chat/completions'), 'https://example.test/v1');
  assert.equal(normalizeOpenAIBase('https://example.test/v1/models/'), 'https://example.test/v1');
  assert.throws(() => normalizeOpenAIBase('https://user:pass@example.test/v1'), /Không đặt API key/);
  assert.throws(() => normalizeOpenAIBase('file:///tmp/api'), /HTTP hoặc HTTPS/);
});

test('retry logic does not retry authentication failures', () => {
  assert.equal(isRetryableStatus(429), true);
  assert.equal(isRetryableStatus(503), true);
  assert.equal(isRetryableStatus(404, 'model not found'), true);
  assert.equal(isRetryableStatus(401, 'invalid API key'), false);
  assert.equal(isRetryableStatus(403, 'forbidden'), false);
});

test('task-specific models use explicit configured environment values', () => {
  const env = { GROQ_GENERAL_MODEL:'fast-model', GROQ_CODING_MODEL:'coder-model', GROQ_REASONING_MODEL:'reasoner-model' };
  assert.equal(modelFor('groq', 'general', env), 'fast-model');
  assert.equal(modelFor('groq', 'coding', env), 'coder-model');
  assert.equal(modelFor('groq', 'reasoning', env), 'reasoner-model');
});

test('adaptive router ranks only configured providers and prioritizes task-appropriate candidates', () => {
  const configured = [
    {id:'groq',configured:true,model:'openai/gpt-oss-120b'},
    {id:'gemini',configured:true,model:'gemini-2.5-flash'},
    {id:'custom',configured:false,model:'private'}
  ];
  assert.equal(rankProviders(configured, 'multimodal')[0].id, 'gemini');
  assert.equal(rankProviders(configured, 'coding')[0].id, 'groq');
  assert.deepEqual(rankProviders(configured, 'general', {provider:'custom'}), []);
});
