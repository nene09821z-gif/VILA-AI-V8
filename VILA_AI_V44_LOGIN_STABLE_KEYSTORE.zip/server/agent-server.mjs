import 'dotenv/config';
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {URL} from 'node:url';

const PORT=Number(process.env.PORT||8787);
const HOST=process.env.HOST||'0.0.0.0';
const GEMINI_KEY=String(process.env.GEMINI_API_KEY||'').trim();
const GEMINI_BASE=(process.env.AGENT_GEMINI_BASE_URL||'https://generativelanguage.googleapis.com/v1beta/openai').replace(/\/$/,'');
const MODEL=process.env.AGENT_GEMINI_MODEL||'gemini-2.5-flash';
const MAX_BODY=Number(process.env.MAX_BODY_BYTES||100*1024*1024);
const WORK=path.join(os.tmpdir(),'vila-agent');
await fsp.mkdir(WORK,{recursive:true});

function json(res,status,data){const b=Buffer.from(JSON.stringify(data));res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':b.length,'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});res.end(b);}
function readBody(req){return new Promise((resolve,reject)=>{let n=0,ch=[];req.on('data',x=>{n+=x.length;if(n>MAX_BODY){reject(new Error('Request quá lớn'));req.destroy();return}ch.push(x)});req.on('end',()=>resolve(Buffer.concat(ch)));req.on('error',reject)});}
function run(cmd,args,{cwd,timeout=300000,env=process.env}={}){return new Promise(resolve=>{const p=spawn(cmd,args,{cwd,shell:false,env:{...env,CI:'1',NONINTERACTIVE:'1'}});let out='',err='',done=false;const finish=(code,signal,timed=false)=>{if(done)return;done=true;clearTimeout(timer);resolve({code:code??-1,signal,stdout:out,stderr:err,timedOut:timed})};p.stdout.on('data',x=>{out+=x.toString();if(out.length>2_000_000)out=out.slice(-2_000_000)});p.stderr.on('data',x=>{err+=x.toString();if(err.length>2_000_000)err=err.slice(-2_000_000)});p.on('close',finish);p.on('error',e=>{err+=e.message;finish(-1)});const timer=setTimeout(()=>{try{p.kill('SIGKILL')}catch{}finish(-1,'SIGKILL',true)},timeout)});}
async function tempDir(prefix='job'){return await fsp.mkdtemp(path.join(WORK,prefix+'-'));}
async function safeExtract(zipFile,dir){const list=await run('unzip',['-Z1',zipFile],{timeout:30000});if(list.code!==0)throw new Error('ZIP không hợp lệ: '+(list.stderr||list.stdout).slice(-2000));for(const raw of list.stdout.split('\n').filter(Boolean)){const n=raw.replace(/\\/g,'/');if(n.startsWith('/')||n.split('/').includes('..')||/^[A-Za-z]:/.test(n))throw new Error('ZIP chứa đường dẫn nguy hiểm: '+raw);}const r=await run('unzip',['-q','-o',zipFile,'-d',dir],{timeout:120000});if(r.code!==0)throw new Error('unzip thất bại: '+(r.stderr||r.stdout).slice(-4000));}
async function zipDir(dir,out){const r=await run('zip',['-q','-r',out,'.'],{cwd:dir,timeout:120000});if(r.code!==0)throw new Error('zip thất bại: '+(r.stderr||r.stdout).slice(-4000));}
async function findAndroidRoot(dir){const q=await run('bash',['-lc',`find . -maxdepth 5 -type f \( -name settings.gradle -o -name settings.gradle.kts \) -print -quit`],{cwd:dir,timeout:20000});if(q.code!==0||!q.stdout.trim())return dir;const f=q.stdout.trim().split('\n')[0];return path.resolve(dir,path.dirname(f));}
async function buildProject(zipB64){const job=await tempDir('build');const zip=path.join(job,'project.zip');await fsp.writeFile(zip,Buffer.from(zipB64,'base64'));const src=path.join(job,'src');await fsp.mkdir(src);await safeExtract(zip,src);const root=await findAndroidRoot(src);let cmd='gradle',args=['assembleDebug','--no-daemon','--stacktrace'];if(fs.existsSync(path.join(root,'gradlew'))){cmd=path.join(root,'gradlew');args=['assembleDebug','--no-daemon','--stacktrace'];try{await fsp.chmod(cmd,0o755)}catch{}}const safeBuildEnv=Object.fromEntries(Object.entries(process.env).filter(([key])=>!/(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|FIREBASE|AWS_|GCP_|AZURE_)/i.test(key)));const r=await run(cmd,args,{cwd:root,timeout:Number(process.env.BUILD_TIMEOUT_MS||600000),env:safeBuildEnv});const apks=[];if(fs.existsSync(path.join(root,'app','build','outputs'))){const q=await run('bash',['-lc',`find app/build/outputs -type f -name '*.apk' -print`],{cwd:root,timeout:20000});for(const x of q.stdout.split('\n').filter(Boolean)){const full=path.resolve(root,x);apks.push({name:path.basename(full),size:(await fsp.stat(full)).size,b64:(await fsp.readFile(full)).toString('base64')})}}return {ok:r.code===0,code:r.code,stdout:r.stdout,stderr:r.stderr,timedOut:r.timedOut,apks,root};}
async function gitDiff(dir){const r=await run('git',['diff','--no-ext-diff','--unified=80'],{cwd:dir,timeout:30000});return r.stdout||r.stderr}
function auth(req){const expected=String(process.env.VILA_SERVER_TOKEN||'').trim();if(!expected)return false;const got=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!got)return false;const a=Buffer.from(got),b=Buffer.from(expected);return a.length===b.length&&crypto.timingSafeEqual(a,b);}
async function handle(req,res){if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end()}
const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
if(u.pathname==='/api/health')return json(res,200,{ok:true,service:'VILA Agent Server',model:MODEL,geminiConfigured:!!GEMINI_KEY,node:process.version,capabilities:['secure-gemini-proxy','streaming','build-test','git-diff','workspace-index']});
if(!auth(req))return json(res,401,{error:'Unauthorized'});
if(req.method==='POST'&&u.pathname==='/api/chat'){if(!GEMINI_KEY)return json(res,503,{error:'GEMINI_API_KEY chưa được cấu hình trên server'});const body=JSON.parse((await readBody(req)).toString('utf8')||'{}');const payload={model:body.model||MODEL,messages:Array.isArray(body.messages)?body.messages:[],max_tokens:Number(body.max_tokens||49152),reasoning_effort:body.reasoning_effort||'high',stream:true};const upstream=await fetch(`${GEMINI_BASE}/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${GEMINI_KEY}`},body:JSON.stringify(payload)});if(!upstream.ok){const detail=(await upstream.text().catch(()=>'' )).slice(0,6000);return json(res,upstream.status,{error:`Gemini upstream HTTP ${upstream.status}`,detail});}res.writeHead(upstream.status,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache','Connection':'keep-alive','Access-Control-Allow-Origin':'*'});if(!upstream.body){res.end();return}for await(const chunk of upstream.body){res.write(chunk)}return res.end();}
if(req.method==='POST'&&u.pathname==='/api/build'){if(String(process.env.ALLOW_UNTRUSTED_BUILDS||'').toLowerCase()!=='true')return json(res,403,{error:'Build Agent đang bị khóa. Đặt ALLOW_UNTRUSTED_BUILDS=true trên server riêng mà bạn kiểm soát.'});const body=JSON.parse((await readBody(req)).toString('utf8')||'{}');if(!body.zipBase64) return json(res,400,{error:'zipBase64 required'});try{return json(res,200,await buildProject(body.zipBase64))}catch(e){return json(res,500,{ok:false,error:e.message})}}
if(req.method==='POST'&&u.pathname==='/api/git/diff'){return json(res,501,{ok:false,error:'Git diff server API dành cho worker nội bộ; VILA thực hiện diff cục bộ trên workspace.'});}
return json(res,404,{error:'Not found'});
}
http.createServer((req,res)=>handle(req,res).catch(e=>json(res,500,{error:e.message||'Server error'}))).listen(PORT,HOST,()=>console.log(`VILA Agent Server listening on http://${HOST}:${PORT}`));
