# VILA AI Gateway backend (V42)

This is the optional server component for central provider keys and adaptive routing. It is a source backend; it is not already deployed by this ZIP.

## Local test

Requires Node.js 20 or newer. From this folder:

```sh
cp .env.example .env
npm install
npm test
npm start
```

With the example configuration, development runs with `AUTH_MODE=off` only for local testing and health checks. Provider-backed requests will fail until at least one provider key and the matching model configuration are set in `.env`. Do not expose this dev configuration to the public Internet.

## Production deployment

1. Deploy to a managed Node.js host or container service with HTTPS.
2. Set `NODE_ENV=production`, `AUTH_MODE=firebase`, `FIREBASE_PROJECT_ID=vila-studio`, and `CORS_ORIGINS` to the exact application/web origins you use. Android WebView may send the literal `null` origin; allow `null` only if required by your native app and still require Firebase bearer-token verification. Production refuses `AUTH_MODE=off`.
3. Configure Firebase Admin using workload/Application Default Credentials on a supported cloud host, or put the full service-account JSON in `FIREBASE_SERVICE_ACCOUNT_JSON` using the host's secret manager. Never commit that secret or place it in the APK.
4. Add only the provider keys you intend to use: `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `GROQ_API_KEY`, `CEREBRAS_API_KEY`, and optionally `CUSTOM_API_KEY` with its administrator-controlled Base URL. All provider keys are server environment secrets.
5. Set `VILA_APP_LATEST_VERSION=42.0.0` and optionally `VILA_APP_RELEASE_URL=https://...` to your trusted HTTPS release page. This powers the in-app update check; Android installation still requires user consent.
6. In VILA's **AI Gateway** panel, enter the deployed HTTPS base URL, check server health, scan configured models, and enable server routing. Keep routing disabled until health/auth are verified.


## Optional Agent Server kept from V41

The project also preserves the existing Agent Server API used by the app's long-response proxy and build/test–repair workflow. It is a separate process from the Gateway and must use a different port, for example:

```sh
PORT=8788 npm run start:agent
```

The app's **Agent Server (optional)** setting should point to the agent server URL and use the same random `VILA_SERVER_TOKEN` set on the host. `GEMINI_API_KEY` is shared, while `AGENT_GEMINI_BASE_URL` and `AGENT_GEMINI_MODEL` configure the proxy independently from the Gateway's Gemini REST adapter. `/api/health` can report status; protected endpoints include `/api/chat` and `/api/build`.

**Build endpoint safety:** `ALLOW_UNTRUSTED_BUILDS` is `false` by default. Enabling it allows submitted project build scripts to execute in the server's environment. Only enable it in an isolated build worker/container you control, with limited permissions, no production secrets mounted into builds, CPU/memory/time limits and temporary storage cleanup. Keep `VILA_SERVER_TOKEN` strong and only expose the service over HTTPS. Do not expose an arbitrary-build worker directly to the public Internet.

## API surface

- `GET /health` — operational health and configured provider count. It does not disclose keys.
- `GET /v1/app/version` — public version/release metadata (never secrets).
- `GET /v1/gateway/providers` — provider configuration and health state; Firebase-authenticated in production.
- `POST /v1/gateway/check` — bounded server-side provider check; authenticated.
- `GET /v1/models` — merged model list from configured providers; authenticated.
- `GET /v1/gateway/usage` — in-memory request counters; authenticated.
- `POST /v1/chat/completions` — normalized chat request and optional SSE stream; authenticated in production.

## Reliability and limitations

- Retry/fallback is bounded and limited to retryable upstream failures. Authentication/permission failures do not trigger retry loops. A stream cannot switch provider after output has begun.
- Rate limits and counters are per process/in-memory; they reset on restart and are not a durable billing ledger. Add a persistent datastore/shared limiter before running multiple replicas or offering paid usage.
- The router only chooses from configured server-side providers; actual model capability, quota, account access, region, prices, and provider availability remain upstream-controlled.
- `CUSTOM_BASE_URL` is administrator-controlled to prevent clients from turning the service into an arbitrary-URL proxy/SSRF primitive. Do not add client-supplied server target URLs.
- A health check cannot repair provider account restrictions, invalid secrets, outages, or unsupported model features. It reports actionable errors rather than silently changing credentials/settings.
- Add HTTPS, rate limits, secret manager, logs with redaction, backups, monitoring, and cost alerts before public release. Configure CORS narrowly.
