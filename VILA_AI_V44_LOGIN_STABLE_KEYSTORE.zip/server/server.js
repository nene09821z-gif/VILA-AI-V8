'use strict';
// Backwards-compatible launcher for the optional Agent Server.
import('./agent-server.mjs').catch(error => { console.error('VILA Agent Server failed to start:', error); process.exitCode = 1; });
