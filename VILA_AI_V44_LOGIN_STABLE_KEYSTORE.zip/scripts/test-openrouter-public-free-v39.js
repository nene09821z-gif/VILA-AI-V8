'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');

function extractFunction(name) {
  const marker = `function ${name}(`;
  const start = html.indexOf(marker);
  assert.ok(start >= 0, `Missing function ${name}`);
  const actualStart = html.slice(Math.max(0, start - 6), start) === 'async ' ? start - 6 : start;
  const signatureEnd = html.indexOf(') {', start);
  assert.ok(signatureEnd >= 0, `Missing function body for ${name}`);
  const brace = signatureEnd + 2;
  let depth = 0, quote = '', escape = false, template = false, lineComment = false, blockComment = false;
  for (let i = brace; i < html.length; i++) {
    const c = html[i], next = html[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && next === '/') { blockComment = false; i++; } continue; }
    if (!quote && !template && c === '/' && next === '/') { lineComment = true; i++; continue; }
    if (!quote && !template && c === '/' && next === '*') { blockComment = true; i++; continue; }
    if (quote) {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if (c === quote) quote = '';
      continue;
    }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '`') { template = !template; continue; }
    if (template) continue;
    if (c === '{') depth++;
    else if (c === '}' && --depth === 0) return html.slice(actualStart, i + 1);
  }
  throw new Error(`Unbalanced function ${name}`);
}

const calls = [];
const responseBody = {
  data: [
    { id: 'nvidia/nemotron-3-ultra-550b-a55b:free', name: 'Nemotron Free', architecture: { input_modalities: ['text'], output_modalities: ['text'], modality: 'text->text' }, pricing: { prompt: '0', completion: '0' } },
    { id: 'openai/example-paid', name: 'Example Paid', architecture: { input_modalities: ['text'], output_modalities: ['text'], modality: 'text->text' }, pricing: { prompt: '0.1', completion: '0.2' } },
    { id: 'vendor/example-embedding', name: 'Example Embedding', architecture: { input_modalities: ['text'], output_modalities: ['text'], modality: 'text->text' }, pricing: { prompt: '0', completion: '0' } }
  ]
};
const context = {
  PROVIDERS: {
    openrouter: { name: 'OpenRouter', baseUrl: 'https://openrouter.ai/api/v1' },
    groq: { name: 'Groq', baseUrl: 'https://api.groq.com/openai/v1' }
  },
  fetch: async (url, options = {}) => {
    calls.push({ url: String(url), headers: options.headers || {} });
    return { status: 200, ok: true, text: async () => JSON.stringify(responseBody) };
  },
  URL,
  AbortController,
  setTimeout,
  clearTimeout,
  console
};
vm.createContext(context);
for (const name of ['apiModelListUrl', 'fetchJsonWithTimeout', 'listProviderModels']) {
  vm.runInContext(extractFunction(name), context, { timeout: 1000 });
}
(async () => {
  const models = await context.listProviderModels('openrouter', '', 'https://openrouter.ai/api/v1');
  assert.equal(calls.length, 1, 'Should only make one catalog request');
  assert.equal(calls[0].url, 'https://openrouter.ai/api/v1/models?output_modalities=text');
  assert.equal(Object.keys(calls[0].headers).some(k => k.toLowerCase() === 'authorization'), false, 'Public catalog scan must not fabricate or send an auth header');
  assert.equal(models.some(m => m.id === 'nvidia/nemotron-3-ultra-550b-a55b:free' && m.isFree), true, 'Zero-price/free-suffix model must be marked free');
  assert.equal(models.some(m => m.id === 'openai/example-paid' && !m.isFree), true, 'Paid model must not be marked free');
  assert.equal(models.some(m => /embedding/i.test(m.id)), false, 'Non-chat models must be filtered');
  assert.equal(models.some(m => m.id === 'openrouter/free' && m.liveAlias && m.isFree), true, 'Documented free-router alias must remain selectable if catalog omits it');
  await assert.rejects(() => context.listProviderModels('groq', '', 'https://api.groq.com/openai/v1'), /Chưa nhập API key/, 'Providers requiring authentication must still require a key');
  console.log('PASS: V39 OpenRouter public model discovery, live free-price classification, chat-model filtering, and authenticated-provider key guard.');
})().catch(e => { console.error(e); process.exitCode = 1; });
