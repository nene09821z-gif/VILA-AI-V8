/* V38 offline tests: endpoint detection + probing with a mocked fetch. Run: node scripts/test-endpoints-v38.js */
const path = require('path'); const assert = require('assert');
const core = require(path.join(__dirname, '..', 'app/src/main/assets/vila-endpoint-core.js'));
let n = 0; const ok = (name, fn) => { try { fn(); n++; } catch (e) { console.error('FAIL', name, '\n ', e.message); process.exitCode = 1; } };
const okA = async (name, fn) => { try { await fn(); n++; } catch (e) { console.error('FAIL', name, '\n ', e.message); process.exitCode = 1; } };

ok('gemini full endpoint', () => { const d = core.detect('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=SECRET'); assert.equal(d.base, 'https://generativelanguage.googleapis.com/v1beta'); assert.equal(d.provider, 'gemini'); assert.equal(d.kind, 'gemini'); assert(d.notes.some(x => /API key/.test(x))); assert(!JSON.stringify(d).includes('SECRET')); });
ok('gemini /openai suffix', () => { const d = core.detect('https://generativelanguage.googleapis.com/v1beta/openai'); assert.equal(d.base, 'https://generativelanguage.googleapis.com/v1beta'); assert.equal(d.kind, 'gemini'); });
ok('gemini host only', () => { assert.equal(core.detect('generativelanguage.googleapis.com').base, 'https://generativelanguage.googleapis.com/v1beta'); });
ok('groq wrong /v1', () => { const d = core.detect('https://api.groq.com/v1/chat/completions'); assert.equal(d.base, 'https://api.groq.com/openai/v1'); assert.equal(d.provider, 'groq'); assert(d.changed); });
ok('groq correct', () => { const d = core.detect('https://api.groq.com/openai/v1'); assert.equal(d.base, 'https://api.groq.com/openai/v1'); assert(!d.changed); });
ok('groq models url', () => { assert.equal(core.detect('https://api.groq.com/openai/v1/models').base, 'https://api.groq.com/openai/v1'); });
ok('cerebras host', () => { assert.equal(core.detect('https://api.cerebras.ai').base, 'https://api.cerebras.ai/v1'); });
ok('openrouter wrong', () => { assert.equal(core.detect('https://openrouter.ai/v1').base, 'https://openrouter.ai/api/v1'); assert.equal(core.detect('https://openrouter.ai/api/v1/chat/completions/').base, 'https://openrouter.ai/api/v1'); });
ok('custom unknown host', () => { const d = core.detect('https://my-gateway.example.com'); assert.equal(d.base, 'https://my-gateway.example.com/v1'); assert.equal(d.provider, 'custom'); assert.equal(d.known, false); });
ok('custom keeps path', () => { assert.equal(core.detect('https://x.example.com/proxy/v1/chat/completions').base, 'https://x.example.com/proxy/v1'); });
ok('openai known', () => { const d = core.detect('https://api.openai.com'); assert.equal(d.base, 'https://api.openai.com/v1'); assert.equal(d.label, 'OpenAI'); assert.equal(d.provider, 'custom'); });
ok('ollama local', () => { const d = core.detect('http://localhost:11434'); assert.equal(d.base, 'http://localhost:11434/v1'); assert(d.local); assert(!d.notes.some(x => /HTTP không mã hoá/.test(x))); });
ok('no scheme', () => { assert.equal(core.detect('api.groq.com/openai/v1').base, 'https://api.groq.com/openai/v1'); });
ok('garbage', () => { assert.equal(core.detect('hello world').ok, false); assert.equal(core.detect('').ok, false); assert.equal(core.detect('ftp://x.com').ok, false); });
ok('quotes+userinfo', () => { const d = core.detect('"https://user:pw@api.cerebras.ai/v1/"'); assert.equal(d.base, 'https://api.cerebras.ai/v1'); });
ok('chat endpoint', () => { assert.equal(core.chatEndpoint(core.detect('https://api.groq.com/openai/v1'), 'x'), 'https://api.groq.com/openai/v1/chat/completions'); assert.equal(core.chatEndpoint(core.detect('https://generativelanguage.googleapis.com/v1beta'), 'gemini-3.8-flash'), 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent'); });
ok('auth headers', () => { assert.deepEqual(core.authHeaders(core.detect('https://api.groq.com'), 'k'), { Authorization: 'Bearer k' }); assert.deepEqual(core.authHeaders(core.detect('https://generativelanguage.googleapis.com'), 'k'), { 'x-goog-api-key': 'k' }); });

const resp = (status, body) => ({ status, ok: status < 300, text: async () => JSON.stringify(body) });
(async () => {
  await okA('probe ok openai', async () => {
    const f = async (url, o) => { assert.equal(url, 'https://api.groq.com/openai/v1/models'); assert.equal(o.headers.Authorization, 'Bearer K'); return resp(200, { data: [{ id: 'openai/gpt-oss-120b' }, { id: 'whisper-large' }] }); };
    const r = await core.probeModels(core.detect('https://api.groq.com'), 'K', { fetch: f }); assert.equal(r.state, 'ok'); assert.equal(r.models, 2);
  });
  await okA('probe gemini', async () => {
    const f = async (url, o) => { assert(url.startsWith('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000')); assert.equal(o.headers['x-goog-api-key'], 'K'); return resp(200, { models: [{ name: 'models/gemini-3.8-flash', supportedGenerationMethods: ['generateContent'] }, { name: 'models/emb', supportedGenerationMethods: ['embedContent'] }] }); };
    const r = await core.probeModels(core.detect('https://generativelanguage.googleapis.com/v1beta'), 'K', { fetch: f }); assert.equal(r.state, 'ok'); assert.deepEqual(r.ids, ['gemini-3.8-flash']);
  });
  await okA('probe states', async () => {
    const d = core.detect('https://api.cerebras.ai/v1');
    for (const [st, want] of [[401, 'auth'], [403, 'auth'], [404, 'notfound'], [429, 'ratelimit'], [503, 'server']]) assert.equal((await core.probeModels(d, 'K', { fetch: async () => resp(st, { error: { message: 'x' } }) })).state, want);
    assert.equal((await core.probeModels(d, 'K', { fetch: async () => { throw new TypeError('Failed to fetch'); } })).state, 'network');
    assert.equal((await core.probeModels(d, '', { fetch: async () => resp(200, {}) })).state, 'nokey');
    assert.equal((await core.probeModels(core.detect('http://localhost:11434'), '', { fetch: async () => resp(200, { data: [{ id: 'llama3' }] }) })).state, 'ok');
  });
  await okA('diagnose auto-discovers custom base', async () => {
    const seen = []; const f = async (url) => { seen.push(url); return url === 'https://gw.example.com/api/v1/models' ? resp(200, { data: [{ id: 'm1' }] }) : resp(404, {}); };
    const r = await core.diagnose('https://gw.example.com', 'K', { fetch: f }); assert.equal(r.verdict, 'ok'); assert.equal(r.fixedBase, 'https://gw.example.com/api/v1'); assert(seen.length > 1);
  });
  await okA('diagnose does not wander on known host', async () => {
    let calls = 0; const r = await core.diagnose('https://api.groq.com/openai/v1', 'K', { fetch: async () => { calls++; return resp(404, {}); } });
    assert.equal(r.verdict, 'bad'); assert.equal(calls, 1);
  });
  await okA('diagnose deep chat + model fallback', async () => {
    const f = async (url, o) => {
      if (url.endsWith('/models')) return resp(200, { data: [{ id: 'dead-model' }, { id: 'good-flash' }] });
      const b = JSON.parse(o.body); return b.model === 'dead-model' ? resp(404, { error: { message: 'model not found' } }) : resp(200, { choices: [] });
    };
    const r = await core.diagnose('https://api.groq.com/openai/v1', 'K', { fetch: f, deep: true, preferredModel: 'dead-model' });
    assert.equal(r.verdict, 'ok'); assert.equal(r.chat.model, 'good-flash');
  });
  await okA('diagnose auth => bad, ratelimit => warn', async () => {
    assert.equal((await core.diagnose('https://api.groq.com', 'K', { fetch: async () => resp(401, { error: { message: 'bad key' } }) })).verdict, 'bad');
    assert.equal((await core.diagnose('https://api.groq.com', 'K', { fetch: async () => resp(429, {}) })).verdict, 'warn');
    assert.equal((await core.diagnose('https://api.groq.com', '', { fetch: async () => resp(200, {}) })).verdict, 'idle');
  });
  console.log(process.exitCode ? 'FAILED' : `OK — ${n} endpoint tests passed`);
})();
