'use strict';

// Fast offline regression checks for VILA V32 routing, reasoning, workspace, image generation and Android UX behavior.
// These checks validate source wiring only; they do not call provider APIs.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const extras = fs.readFileSync(path.join(root, 'app/src/main/assets/vila-extras.js'), 'utf8');
const javaSource = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8');
const gradleSource = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');

function requireText(text, description) {
  assert.ok(html.includes(text), `Missing ${description}: ${text}`);
}

const providersStart = html.indexOf('const PROVIDERS = {');
const providersEnd = html.indexOf('const VILA_MODEL_CATALOG_KEY', providersStart);
assert.ok(providersStart >= 0 && providersEnd > providersStart, 'Provider seed catalog must exist');
const seeds = html.slice(providersStart, providersEnd);

// Verified free-tier seeds as of 2026-10-09; live /models sync still takes precedence.
for (const model of [
  'openrouter/free',
  'nvidia/nemotron-3-ultra-550b-a55b:free',
  'nvidia/nemotron-3.5-lightning:free',
  'poolside/laguna-s-2.1:free',
  'poolside/laguna-xs-2.1:free',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'qwen/qwen3.8-27b',
  'zai-glm-4.7'
]) assert.ok(seeds.includes(model), `Model missing from offline seed catalog: ${model}`);
const gemini35 = seeds.match(/\{id:'gemini-3\.5-flash'([^}]*)\}/);
assert.ok(gemini35 && !gemini35[1].includes('isFree:true'), 'Legacy Gemini 3.5 Flash must not be advertised as free without current pricing confirmation');
const gemini38 = seeds.match(/\{id:'gemini-3\.8-flash'([^}]*)\}/);
assert.ok(gemini38 && gemini38[1].includes('isFree:true'), 'Gemini 3.8 Flash must reflect the current free tier');
for (const model of ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-2.5-flash','gemini-2.5-flash-lite']) {
  const start = seeds.indexOf("{id:'" + model + "'");
  const end = start < 0 ? -1 : seeds.indexOf('}', start);
  const row = start >= 0 && end >= 0 ? seeds.slice(start, end + 1) : '';
  assert.ok(row && row.includes('isFree:true'), `Verified free model must be labeled as such: ${model}`);
}

for (const stale of ['groq/compound', 'groq/compound-mini', 'llama-3.1-8b-instant', 'llama-3.3-70b-versatile', 'qwen/qwen3.6-27b']) {
  assert.ok(!seeds.includes(stale), `Retired Groq model must not be seeded: ${stale}`);
}

// Provider/model isolation and adaptive model preference.
requireText("localStorage.getItem(modelStorageKey(activeProvider))", 'provider-scoped model persistence');
requireText('function getSmartModelOrderForProvider(provider,userText)', 'provider-specific auto-model ranking');
requireText('function classifyTaskForModel(userText)', 'adaptive task classification');
requireText('CHẾ ĐỘ SUY LUẬN NHIỀU BƯỚC', 'multi-step reasoning instructions');
requireText('CHẾ ĐỘ NGHIÊN CỨU/TÌM KIẾM', 'research-first instructions');
requireText('zai-glm-4\\.7', 'GLM 4.7 adaptive reasoning effort');
requireText('function isFreePreferenceEnabled()', 'free model preference');
requireText("localStorage.getItem('vila_prefer_free_models')!=='0'", 'default-on free model preference');
requireText("result=activeProvider==='gemini'?await requestGeminiWithFallback(requestMessages):await requestActiveProvider(requestMessages)", 'normal chat dispatch to currently selected provider');
requireText('result.autoRouted=true', 'auto-model routing feedback');

// Search adapters: native Gemini grounding, OpenRouter server tool, Groq Browser Search,
// and a documented cross-provider bridge for providers without a universal search tool.
requireText("type:'openrouter:web_search'", 'OpenRouter server-side web search tool');
requireText("body.tools=[{type:'browser_search'}]", 'Groq Browser Search tool');
requireText('body.reasoning_effort=body.reasoning_effort||\'low\'', 'Groq search preserves adaptive reasoning effort');
requireText('async function requestGeminiWebSearch(messages,options={})', 'Gemini Google Search grounding adapter');
requireText('async function requestWithWebSearch(messages)', 'async common search router syntax');
requireText('async function requestSearchBridgeForOtherProvider', 'cross-provider search bridge');
requireText('researchOnly:true', 'research-only Gemini search bridge');
requireText("const freeSearchModels=['gemini-2.5-flash','gemini-2.5-flash-lite']", 'free Gemini grounding models');
requireText("const models=(isFreePreferenceEnabled()\n                ? freeSearchModels", 'free preference prevents paid Gemini grounding fallback');
requireText('async function requestWithWebSearch(messages)', 'common web-search router');
requireText("provider==='openrouter'", 'OpenRouter search route');
requireText("provider==='groq'", 'Groq search route');
requireText("provider==='gemini'", 'Gemini search route');
requireText("localStorage.getItem('vila_web_search_mode')==='1'", 'explicit search mode separate from auto-search preference');
requireText('function shouldAutoSearch(text)', 'automatic search heuristics for fresh/current questions');
requireText('isFree:/^gemini-', 'Gemini free-tier model metadata');
requireText("const promptPrice=m?.pricing?.prompt,completionPrice=m?.pricing?.completion", 'OpenRouter live pricing-based free model detection');

// API compatibility fixes: remove unsupported reasoning parameters then retry; use the
// completion-token field expected by Groq GPT-OSS and Cerebras APIs.
requireText('if(Object.keys(reasoningParams).length&&response.status===400&&/reasoning|unsupported|unrecognized|unknown parameter|extra field/i.test(apiMessage))', 'reasoning-parameter compatibility retry for tool and normal calls');
requireText("if(provider==='cerebras'||(provider==='groq'&&/^openai\\/gpt-oss-/i.test(String(model||''))))", 'Cerebras/Groq completion-token API compatibility');

assert.ok(workflow.includes('node scripts/smoke-test-v32.js'), 'GitHub Actions must run the V32 offline regression checks');

// Inherited reasoning, file safety, stop action, direct image output, and UX checks.
for (const [needle, description] of [
  ['function verifyAnswerDraft(messages,draft,useWebSearch)', 'second-pass answer verification'],
  ['function createVilaChatAbortController()', 'cancellable chat requests'],
  ['function stopVilaGeneration()', 'stop button behavior'],

  ['function isImageGenerationIntent(userText)', 'direct image-generation routing'],
  ['appendGeneratedImage(generated,rawPrompt)', 'generated image inline output'],
  ['id="vilaWelcomeSplash"', 'animated 3-second welcome splash'],
  ['XIN CHÀO CÁC BẠN', 'requested welcome text'],
  ['Bảng xếp hạng VILA', 'activity ranking modal'],
  ['function isVilaFullWorkspaceMode()', 'full workspace scope option'],
  ['SCOPE MODE:', 'workspace scope reporting'],
  ['AI · SMART ASSISTANT</small>', 'V35 sidebar brand subtitle']
]) requireText(needle, description);
assert.ok(!html.includes('Cha đẻ dự án là Bảo An'), 'Creator prompt attribution must be removed');
assert.ok(!html.includes('>Bảo An</div>'), 'Creator identity card must be removed');
assert.ok(extras.includes('window.createVilaChatAbortController'), 'Video requests must use the chat cancellation controller');
assert.ok(extras.includes("E.nativeBase.replace(/\\/+$/, '') + '/interactions'"), 'Video requests must use the Gemini Interactions API');
assert.ok(extras.includes('function extractInteractionVideoData(payload)'), 'REST video result parser must support steps[].content[].data');
assert.ok(html.includes('function releaseVilaChatAbortController(controller)'), 'completed and failed requests must release abort controllers');
assert.ok(html.includes('finally{clearTimeout(timer);releaseVilaChatAbortController(controller);}') || html.includes('finally{clearTimeout(timer);releaseVilaChatAbortController(controller);'), 'TTS requests must release their abort controller after completion');
const videoStart = extras.indexOf('function extractInteractionVideoData(payload)');
const videoEnd = extras.indexOf('window.vilaExtractInteractionVideoData', videoStart);
assert.ok(videoStart >= 0 && videoEnd > videoStart, 'Video extractor helper must be isolated for regression tests');
const videoHelperContext = {};
vm.runInNewContext(extras.slice(videoStart, videoEnd) + '\nthis.extract=extractInteractionVideoData;', videoHelperContext);
assert.deepEqual(JSON.parse(JSON.stringify(videoHelperContext.extract({steps:[{type:'model_output',content:[{type:'video',mime_type:'video/mp4',data:'QUJDRA=='}]}]}))), {data:'QUJDRA==',mime:'video/mp4'}, 'REST video data parser should read steps[].content[].data');
assert.deepEqual(JSON.parse(JSON.stringify(videoHelperContext.extract({output_video:{mime_type:'video/mp4',data:'VklMQQ=='}}))), {data:'VklMQQ==',mime:'video/mp4'}, 'Video parser should also tolerate SDK-shaped output');

// Execute pure helper functions against representative runtime cases, not just source-string checks.
function evalRange(startNeedle, endNeedle, exportNames) {
  const start = html.indexOf(startNeedle);
  const end = html.indexOf(endNeedle, start + startNeedle.length);
  assert.ok(start >= 0 && end > start, `Cannot isolate runtime helper range: ${startNeedle}`);
  const context = {};
  vm.runInNewContext(html.slice(start, end) + '\n' + exportNames.map(name => `this.${name}=${name};`).join('\n'), context);
  return context;
}
const imageHelpers = evalRange('function isImageGenerationIntent(userText)', 'function classifyTaskForModel(userText)', ['isImageGenerationIntent']);
for (const prompt of ['tạo ảnh một con mèo', 'vẽ con mèo', 'hãy vẽ một con rồng', 'giúp tôi vẽ phong cảnh']) {
  assert.equal(imageHelpers.isImageGenerationIntent(prompt), true, `Image intent should route directly: ${prompt}`);
}
for (const prompt of ['phân tích ảnh này', 'đọc chữ trong ảnh', 'vẽ sơ đồ kiến trúc', 'giải thích bức hình']) {
  assert.equal(imageHelpers.isImageGenerationIntent(prompt), false, `Non-generation request must stay in chat: ${prompt}`);
}
const imageExtractionHelpers = evalRange('function extractInteractionImage(data)', 'function getVilaImageAspectRatio()', ['extractInteractionImage']);
assert.deepEqual(JSON.parse(JSON.stringify(imageExtractionHelpers.extractInteractionImage({steps:[{type:'model_output',content:[{type:'image',mime_type:'image/png',data:'QUJDRA=='}]}]}))), {data:'QUJDRA==',mime:'image/png'}, 'REST image parser should read model output data');
assert.deepEqual(JSON.parse(JSON.stringify(imageExtractionHelpers.extractInteractionImage({output_image:{data:'VklMQQ==',mime_type:'image/jpeg'}}))), {data:'VklMQQ==',mime:'image/jpeg'}, 'Image parser should accept SDK convenience output');
const freeHelpers = evalRange('function isKnownFreeModel(provider,model,metadata={})', 'function getSmartModelOrder(userText)', ['isKnownFreeModel']);
for (const model of ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-2.5-flash','gemini-2.5-flash-lite']) {
  assert.equal(freeHelpers.isKnownFreeModel('gemini', model, {}), true, `Cached Gemini model should retain verified free-tier classification: ${model}`);
}
assert.equal(freeHelpers.isKnownFreeModel('gemini', 'gemini-3.1-pro-preview', {}), false, 'Paid/preview Gemini model must not be inferred free');
assert.equal(freeHelpers.isKnownFreeModel('gemini', 'gemini-3.5-flash', {}), false, 'Legacy Gemini model without confirmed free-tier classification must not be inferred free');
assert.equal(freeHelpers.isKnownFreeModel('openrouter', 'poolside/laguna-s-2.1:free', {}), true, 'OpenRouter :free models should be recognized');
const taskHelpers = evalRange('function classifyTaskForModel(userText)', 'function getAdaptiveTaskInstruction(userText)', ['classifyTaskForModel']);
assert.equal(taskHelpers.classifyTaskForModel('Hãy suy luận nhiều bước và kiểm tra giả định'), 'reasoning');
assert.equal(taskHelpers.classifyTaskForModel('Tìm kiếm nguồn chính thức mới nhất'), 'research');
assert.equal(taskHelpers.classifyTaskForModel('Sửa code JavaScript và build APK'), 'coding');
const fileHelpers = evalRange('function isLikelyTextFile(name)', 'function cleanProjectText(text)', ['isLikelyTextFile','normalizeProjectPath']);
for (const file of ['app/src/main/java/MainActivity.java','infra/main.tf','config/.env.production','src/component.tsx','Dockerfile']) {
  assert.equal(fileHelpers.isLikelyTextFile(file), true, `Source/config file should be readable as text: ${file}`);
}
assert.equal(fileHelpers.isLikelyTextFile('assets/icon.png'), false, 'Binary image files must not be decoded as text');
assert.equal(fileHelpers.normalizeProjectPath('../secrets.txt'), '', 'Path traversal must be rejected');
assert.equal(fileHelpers.normalizeProjectPath('/absolute/path.js'), '', 'Absolute project paths must be rejected');
assert.equal(fileHelpers.normalizeProjectPath('src\\main.js'), 'src/main.js', 'Windows separators should normalize to safe relative paths');


// V32 Android responsiveness, image controls, source-domain UI, and secure-key save handling.
for (const [needle, description] of [
  ['class="vila-start-brand"', 'compact startup brand replaces oversized splash/banner artwork'],
  ['id="imageAspectRatio"', 'image aspect-ratio selector'],
  ['id="imageSize"', 'image output-size selector'],
  ["localStorage.getItem('vila_image_aspect_ratio')||'16:9'", '16:9 is the default image aspect ratio'],
  ["localStorage.getItem('vila_image_size')||'1K'", '1K is the default safer image size'],
  ['aspect_ratio:aspectRatio,image_size:imageSize', 'image API uses user-selected ratio and size'],
  ['function updateVilaThinkingPanel(text, mode', 'task-stage status panel follows actual app status'],
  ['function buildVilaWebSourceStrip(rawText)', 'real web source favicon strip'],
  ['window.Android.saveProviderApiKey(activeProvider,enteredKey)', 'provider keys persist through the Android bridge'],
  ["if(typeof window.Android.saveProviderApiKey!=='function') throw new Error('Bản Android chưa hỗ trợ lưu key. Hãy cài bản VILA mới.')", 'Android key bridge missing is reported clearly'],
  ['Không thể lưu API key.', 'plain preference save failure is reported clearly'],
  ['function sendImageRequest(body)', 'bounded image request helper and retry logic'],
  ["div.querySelector('.vila-image-save').addEventListener('click',()=>saveGeneratedImageFile(imageToSave))", 'each generated image saves its own image payload'],
  ['image.actualImageSize=String(body?.response_format?.image_size||imageSize)', 'fallback image size is reflected truthfully in UI'],
  ['Dữ liệu ảnh không hợp lệ; không thể hiển thị ảnh an toàn.', 'API image data validated before insertion into DOM'],
  ["if(window.Android){try{if(typeof window.Android.getGeminiApiKey==='function')return String(window.Android.getGeminiApiKey()||'').trim();}", 'Android build reads Gemini key from native local storage'],
  [`if(saved===true){localStorage.removeItem('vila_api_key');localStorage.removeItem('vila_gemini_key');}`, 'legacy Gemini key is removed only after successful native-storage migration']
]) assert.ok(html.includes(needle), `V32 check failed: ${description}`);
assert.ok(!html.includes('<img src="/vila_brand_banner.png" class="vila-start-banner"'), 'Oversized startup banner must not be rendered');
assert.ok(javaSource.includes('public boolean saveGeminiApiKey(String token)'), 'Gemini key bridge must report secure-save success/failure');
assert.ok(gradleSource.includes('versionName "43.0.0"'), 'Android version must be V43');
const endpointSource = fs.readFileSync(path.join(root, 'app/src/main/assets/endpoints.js'), 'utf8');
assert.ok(endpointSource.includes("videoModel: 'gemini-omni-1.1-flash'"), 'Video endpoint should use the stable Gemini Omni Interactions model');
assert.ok(endpointSource.includes("ttsModel: 'gemini-3.8-flash-tts'"), 'TTS endpoint should use the current stable Gemini 3.8 TTS model');
assert.ok(extras.includes("if (typeof window.updateVilaThinkingPanel !== 'function')"), 'legacy extras must not overwrite the V32 task-status UI');

// V36 full dashboard, local SVG icon system, provider-specific key slots, and preview flow.
for (const [needle, description] of [
  ['id="vila-v36-dashboard"', 'V36 dashboard skin'],
  ['id="vila-v36-dashboard-actions"', 'V36 dashboard interactions'],
  ['id="vila-v36-svg-icon-engine"', 'V36 local SVG icon engine'],
  ['id="vilaInfoRail"', 'right-side provider and feature rail'],
  ['id="vilaExploreModal"', 'Explore AI dialog'],
  ['id="vilaToolReasoning"', 'reasoning tool'],
  ['id="vilaToolSearch"', 'web-search tool'],
  ['id="vilaToolCode"', 'coding tool'],
  ['id="vilaToolImage"', 'image tool'],
  ['id="vilaToolVideo"', 'video tool'],
  ['id="vilaToolAttach"', 'top-level file attachment tool'],
  ["function saveActiveProviderKey()", 'per-provider API key persistence'],
  ["window.Android.saveProviderApiKey(activeProvider,enteredKey)", 'native local storage for non-Gemini providers'],
  ["const icon = badge.querySelector('i,svg[data-vila-icon]');", 'status key icon keeps working after SVG conversion'],
  ['#previewPanel.vila-preview-active{display:flex!important', 'explicit code preview visibility'],
]) assert.ok(html.includes(needle), `V36 UI check failed: ${description}`);
assert.ok(!html.includes('font-awesome/'), 'UI icons must not depend on Font Awesome CDN');
assert.ok(gradleSource.includes('versionCode 49') && gradleSource.includes('versionName "43.0.0"'), 'Android version must be V43');
for (const provider of ['gemini','groq','cerebras','openrouter','custom']) {
  assert.ok(html.includes(provider+': { name:'), `Provider registry should include ${provider}`);
}
assert.ok(javaSource.includes('edit.putString("provider_api_key_" + name, value)') && !javaSource.includes('KeyStore.getInstance("AndroidKeyStore")'), 'provider keys use plain SharedPreferences and Android Keystore is removed');
const iconEngineStart = html.indexOf('<script id="vila-v36-svg-icon-engine">');
const iconEngineEnd = html.indexOf('</script>', iconEngineStart);
assert.ok(iconEngineStart >= 0 && iconEngineEnd > iconEngineStart, 'V36 inline SVG icon engine exists');
const iconEngine = html.slice(iconEngineStart, iconEngineEnd);
const iconKeys = new Set([...iconEngine.matchAll(/^\s*'([^']+)':'</gm)].map(m => m[1]));
const iconModifiers = new Set(['fa-solid','fa-regular','fa-brands','fa-light','fa-duotone','fa-fw','fa-xs','fa-sm','fa-lg','fa-xl','fa-2xl','fa-spin','fa-pulse','fa-beat','fa-fade','fa-bounce','fa-shake','fa-flip','fa-swap-opacity','fa-inverse','fa-border','fa-pull-left','fa-pull-right','fa-stack','fa-stack-1x','fa-stack-2x']);
const usedIconKeys = new Set([...html.matchAll(/\bfa-[a-z][a-z0-9-]*\b/g)].map(m=>m[0].slice(3)).filter(k=>!iconModifiers.has('fa-'+k)&&!/^rotate-|^flip-/.test(k)));
const missingIconKeys = [...usedIconKeys].filter(k=>!iconKeys.has(k));
assert.deepEqual(missingIconKeys, [], `Every icon name must have a local SVG path; missing: ${missingIconKeys.join(', ')}`);
assert.ok(!html.includes('font-awesome/'), 'UI icons must not depend on Font Awesome CDN');
const allIds=[...html.matchAll(/\bid=[\"']([^\"']+)[\"']/g)].map(m=>m[1]);
const duplicateIds=[...new Set(allIds.filter((id,i)=>allIds.indexOf(id)!==i))];
assert.deepEqual(duplicateIds, [], `HTML IDs must be unique: ${duplicateIds.join(', ')}`);

// V37 API-key persistence regression: blank input must never overwrite/delete a saved key.
assert.ok(html.includes('const key=enteredKey || existingKey;'), 'Blank API-key field must preserve existing saved key');
assert.ok(html.includes('window.clearActiveProviderKey=function()'), 'Deleting an API key must be an explicit action');
assert.ok(html.includes('getProviderApiKey?.(activeProvider)'), 'Provider key save must verify read-back');
assert.ok(html.includes('getGeminiApiKey?.()'), 'Gemini key save must verify read-back');
assert.ok(html.includes('id="apiKeySavedState"'), 'Unified API settings must display persisted-key state');
assert.ok(html.includes('vila-v37-cyan-ui-fix'), 'V37 cyan/blue visual overrides must exist');
assert.ok(gradleSource.includes('versionCode 49') && gradleSource.includes('versionName "43.0.0"'), 'Android version must be V43');

// V38: endpoint doctor, animated thinking, notifications.
{
  const v38 = fs.readFileSync(path.join(root, 'app/src/main/assets/vila-v38.js'), 'utf8');
  const manifestSrc = fs.readFileSync(path.join(root, 'app/src/main/AndroidManifest.xml'), 'utf8');
  const notifier = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/VilaNotifier.java'), 'utf8');
  assert.ok(html.includes('src="vila-endpoint-core.js"') && html.includes('src="vila-v38.js"'), 'V38 scripts must be loaded by index.html');
  assert.ok(html.indexOf('vila-v38.js') > html.indexOf('vila-extras.js'), 'V38 script must load after the legacy scripts it overrides');
  assert.ok(!/animation-duration:\s*\.001ms\s*!important/.test(html), 'Mobile performance rule must not freeze all animations (spinner bug)');
  assert.ok(html.includes("classes.push('vila-spin')"), 'SVG icon engine must preserve fa-spin');
  for (const fn of ['window.testApiKey', 'window.appendTypingIndicator', 'window.updateVilaThinkingPanel', 'window.normalizeOpenAIEndpoint', 'window.onVilaNotificationPermission'])
    assert.ok(v38.includes(fn), 'V38 must define ' + fn);
  assert.ok(v38.includes('keyOf(provider)'), 'Test button must fall back to the saved key');
  for (const m of ['hasNotificationPermission', 'requestNotificationPermission', 'notifyUser', 'setRequestActive', 'updateRequestStatus', 'isAppVisible', 'openNotificationSettings'])
    assert.ok(javaSource.includes('public ' + (m === 'hasNotificationPermission' || m === 'isAppVisible' ? 'boolean ' : 'void ') + m + '('), 'Android bridge must expose ' + m);
  assert.ok(javaSource.includes('onRequestPermissionsResult') && javaSource.includes('startKeepAlive'), 'Android must handle the permission result and keep-alive');
  assert.ok(!/"android\.permission\.POST_NOTIFICATIONS",\s*"android\.permission\.CAMERA"/.test(javaSource), 'Notification permission is requested by the explainer flow, not bulk at startup');
  assert.ok(manifestSrc.includes('VilaKeepAliveService') && manifestSrc.includes('FOREGROUND_SERVICE_DATA_SYNC') && manifestSrc.includes('POST_NOTIFICATIONS'), 'Manifest must declare notification permission and service');
  assert.ok(notifier.includes('IMPORTANCE_HIGH') && fs.existsSync(path.join(root, 'app/src/main/res/drawable/ic_stat_vila.xml')), 'Notification channel and status icon must exist');
  console.log('PASS: V38 endpoint doctor, animated thinking panel, notification bridge and spinner root-cause fix.');
}

console.log('PASS: V37 key preservation, explicit key deletion, verified read-back, and cyan/blue UI.');
console.log('PASS: V36 UI controls, provider-key SharedPreferences bridge, complete local SVG icon coverage, and code-preview visibility.');
console.log('PASS: provider routing/search, adaptive model selection, multi-step reasoning review, stop/cancel, file-scope safety, direct image flow, welcome splash, local activity ranking, and workflow integration.');
console.log('NOTE: this is an offline source regression test; it does not prove live API access, free quota, or successful APK build.');
