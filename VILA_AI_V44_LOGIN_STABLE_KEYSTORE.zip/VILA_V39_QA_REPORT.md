# VILA AI Studio V39 — QA result

## Passed locally

- `node scripts/test-openrouter-public-free-v39.js` — public OpenRouter catalog path, optional auth header, free pricing markers, free-router alias, non-chat filtering, and API-key guard for authenticated providers.
- `node scripts/test-endpoints-v38.js` — 24 endpoint normalization and diagnostic cases.
- `node scripts/test-key-persistence-v37.js` — protected key bridge read/write behavior and blank-field preservation.
- `node scripts/smoke-test-v32.js` — adaptive task classification, provider/model routing, key persistence, workspace/file-safety checks, and prior UI regression coverage.
- Node syntax checks for all 7 inline HTML scripts and 5 external JS assets.
- Android manifest XML parsed successfully; duplicate HTML element IDs check returned none.
- GitHub Actions workflow contains the new V39 test before Android build steps.

## Not verified in this environment

- No real provider API key was supplied; therefore no live request, provider-specific quota, account eligibility, CORS policy, or ongoing availability was proven.
- A local Android APK build was not run because this environment has no Gradle executable or Android SDK installed. The included GitHub Actions workflow installs its toolchain and performs the Gradle build after the project is pushed/run in GitHub Actions.
- Android cannot guarantee an app stays active 24/7 on every device. Battery optimization, OEM task management, network loss, API rate limits and provider outages can interrupt background work. The foreground progress service is meant for an active request, not endless background generation.

## Important behavior

- OpenRouter's catalog can be browsed with no key if its public models endpoint is reachable; an API key is still needed to chat.
- Other providers are dynamically scanned using the selected Base URL, credentials, and their compatible `/models` endpoint. A custom endpoint needs to implement the expected API protocol; not every provider is automatically interchangeable.
- This feature discovers hosted model IDs. It does not download model weights to the phone.
