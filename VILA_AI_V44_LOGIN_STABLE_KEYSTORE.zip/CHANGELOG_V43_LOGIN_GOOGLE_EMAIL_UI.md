# VILA AI V43 — Login and Google Sign-In cleanup

- Simplified the authentication gate to a clean “Đăng nhập” screen with Email, Mật khẩu, Đăng nhập, Google, Tạo tài khoản and Quên mật khẩu actions. Removed the instructional helper paragraphs and persistent small status text.
- Kept native Android Credential Manager for Google Sign-In with `setFilterByAuthorizedAccounts(false)` so the system can show Google accounts available on the device. Native failures are shown in the gate; the UI no longer declares a false timeout while the user is still choosing an account.
- Added native email-format validation in addition to client validation.
- Email/password login accepts the existing password as entered; new account registration allows letters, numbers, spaces/symbols supported by Firebase, and does not require a six-digit PIN. Firebase's default minimum of six characters for new passwords remains in effect.
- Bumped Android version to 43.0.0 / versionCode 49 and added source regression checks.

## Honest build/auth caveat

Source tests run locally; a real Android APK build and Google account-picker sign-in must still be verified in GitHub Actions on a device. Google sign-in also requires the exact APK signing certificate SHA-1 to be registered for package `com.vila.ai` in the Firebase project and the Google provider enabled.
