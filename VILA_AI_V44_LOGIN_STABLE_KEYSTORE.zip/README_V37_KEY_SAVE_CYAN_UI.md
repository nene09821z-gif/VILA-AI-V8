# VILA AI Studio V37 — API key persistence + cyan UI

## API keys
- One shared API-key field is used for the currently selected provider in one settings screen.
- Saved secrets are never copied back into the visible field; a masked placeholder and saved status are shown.
- A blank key field means **keep the existing key**. It no longer erases a key when the user taps Save.
- Keys are deleted only with the explicit **Xóa key** action for the selected provider.
- Android provider keys are encrypted using Android Keystore AES-GCM; save code verifies the key can be read back.
- Gemini, Groq, Cerebras, OpenRouter, and Custom API keys remain independent.
- Browser-only mode uses localStorage, which is less secure than Android Keystore.

## UI
- Added final cyan/blue visual overrides to replace conflicting legacy gray styles.
- Auto model and Prefer Free toggles remain on by default, use visible cyan active states, and rank models within the selected provider.
- Fixed the duplicate welcome-state HTML ID.

## Validation
Run `node scripts/smoke-test-v32.js` and `node scripts/test-key-persistence-v37.js`. These offline tests check source wiring and API-key save behavior with a mocked bridge; they do not prove live provider credentials, quotas, or successful APK installation. The Gradle wrapper JAR is absent from this source tree; the included GitHub Actions workflow installs Gradle and Android SDK to perform a real build when run.
