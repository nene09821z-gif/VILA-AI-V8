# VILA AI STUDIO V42 QA report

Date: 2026-10-10

## Source checks
- 5 backend engine tests passed with Node's `node:test`.
- V42 Gateway static contract test passed.
- V41 Firebase auth regression test passed and asserts Android version code 48 / version name 42.0.0.
- V37 API-key persistence regression test passed.
- V38 endpoint doctor suite passed all 24 endpoint tests.
- V39 OpenRouter model catalog/free metadata/auth-guard test passed.
- V32/V36/V37/V38 regression smoke suite passed, including local SVG icon coverage, duplicate HTML ID checks, routing, file safety, and workflow integration.
- `node --check` passed for Gateway server, routing engine, optional Agent Server (ESM + compatibility launcher), project JS assets, and all extracted inline scripts.
- AndroidManifest XML and `firebase-config.js` JSON payload parsed successfully; two PNG/JPEG/WebP raster assets were verified by Pillow.
- Root `main.yml` matches the active `.github/workflows/main.yml`; CI includes backend syntax and unit tests. CI itself was not executed in this local workspace.

## Not claimed as verified
- Local APK build: not run because this environment lacks a Gradle executable/wrapper launcher and Android SDK.
- The prebuilt APK from the incoming bundle has a signing certificate SHA-1 that differs from the Android OAuth fingerprint in the supplied `google-services.json`. The updated workflow emits `output/sha1-fingerprint.txt`; register the SHA-1 for the exact APK you install, preferably using a persistent release keystore.
- Server HTTP integration: not run against installed Express/Firebase Admin dependencies or a deployed server.
- No provider API keys were supplied, so live model discovery/chat, image generation and quota status are not claimed to work in this report.
- Email/Google sign-in needs Firebase Console provider configuration. The newly supplied JSON contains the OAuth Web Client ID, but the actual APK signing SHA-1 still must match the certificate registered in Firebase. Browser preview additionally needs the separate Firebase Web App `appId`. Firebase Admin service-account credentials must be configured separately on the backend host.
- Update checking reports versions only after a backend is deployed; configure `VILA_APP_RELEASE_URL` to a trusted HTTPS release page. Android still requires user approval to install an APK.

## How to get a real APK
Push the full project to GitHub and run **VILA AI - Android Build and Verify** in Actions. Download the debug APK artifact when the workflow succeeds. Production release signing requires a stable keystore and the corresponding GitHub secrets.
