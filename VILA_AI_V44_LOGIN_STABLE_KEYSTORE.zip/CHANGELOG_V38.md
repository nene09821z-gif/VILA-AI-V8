# V38 — Endpoint Doctor, suy luận động, thông báo ngoài app

## Gốc lỗi "icon/hiệu ứng suy luận không xoay"
Có **2 nguyên nhân**, đều đã sửa:
1. `index.html` (khối "V13 PERFORMANCE MODE", màn hình ≤767px) ép **mọi** animation thành `.001ms` và chạy 1 lần → toàn bộ spinner/pulse bị đóng băng trên điện thoại. Đã bỏ luật này (chỉ giữ rút ngắn transition; người bật "giảm chuyển động" của hệ thống vẫn được tắt animation).
2. Bộ đổi icon Font Awesome → SVG làm mất class `fa-spin`. Nay giữ lại thành `vila-spin`, và icon `circle-notch`/`spinner` luôn xoay.

## Suy luận động (kiểu trợ lý AI hiện đại)
- Panel mới: vòng orb 2 lớp xoay ngược chiều, tiêu đề shimmer, dòng trạng thái gõ chữ theo ngữ cảnh (code / tìm web / ảnh / toán / chung), đồng hồ thời gian thực, thanh quét, 4 bước tự chạy (hoàn thành ✓, bỏ qua nếu không tìm web).
- Khi câu trả lời xuất hiện: chip **"Đã suy nghĩ N giây"** có thể mở ra xem thời gian từng bước (tôn trọng công tắc "Hiển thị tóm tắt suy luận").
- Không hiển thị chuỗi suy luận riêng tư của model (giữ nguyên chính sách cũ).

## Endpoint Doctor (Cài đặt → dưới ô Base URL)
- Dán **bất kỳ** URL (host, Base URL, `/chat/completions`, `/models`, `:generateContent`, kèm `?key=`) → tự nhận diện cổng + kiểu API, cắt hậu tố, sửa đường dẫn sai (vd Groq phải là `/openai/v1`, OpenRouter `/api/v1`, Gemini bỏ `/openai`), bỏ API key khỏi URL.
- Nhận diện sẵn: Gemini, Groq, Cerebras, OpenRouter, OpenAI, DeepSeek, Mistral, xAI, Together, Fireworks, NVIDIA NIM, SiliconFlow, Perplexity, Ollama / LM Studio (máy local).
- **Quét nhanh** (`/models`) và **Quét sâu** (gửi 1 tin ngắn) cả 5 cổng bằng key đã lưu; hiển thị đúng/sai, độ trễ, số model, lý do lỗi (key sai / 404 / 429 / mạng / CORS) và chấm trạng thái cạnh từng nút nhà cung cấp.
- Cổng Custom bị 404 sẽ **tự dò** Base URL đúng (/v1, /api/v1, /openai/v1…) và đề nghị áp dụng.
- Toàn bộ app (liệt kê model, chat, kiểm tra key) dùng chung bộ nhận diện này.
- **Sửa lỗi nút "Kiểm tra"**: từ V37 ô key luôn trống khi đã lưu nên báo "chưa nhập key"; nay dùng key đã lưu.

## Thông báo ngoài app (Android)
- Xin quyền `POST_NOTIFICATIONS` bằng hộp thoại giải thích trong app (hiện 1 lần, ở yêu cầu đầu tiên) rồi mới tới hộp thoại hệ thống; nếu đã từ chối vĩnh viễn thì mở thẳng Cài đặt thông báo của app.
- Khi bạn rời app lúc AI đang suy luận: hiện thông báo tiến trình ("VILA đang suy luận…", cập nhật theo bước) và **dịch vụ foreground** giữ yêu cầu chạy tiếp.
- Trả lời xong lúc app ở nền: thông báo kèm đoạn xem trước (ẩn nội dung trên màn hình khóa); chạm để mở lại. Lỗi cũng được báo.
- Cài đặt → thẻ "Thông báo ngoài app": trạng thái quyền, công tắc bật/tắt, cấp quyền, gửi thông báo thử, mở cài đặt hệ thống.
- Trình duyệt thường dùng Web Notification API.

## Khác
- Android versionCode 44 / 38.0.0; `launchMode="singleTask"`; thêm `.github/workflows/main.yml` (thư mục ẩn bị thiếu trong zip V37) để test/CI chạy được.
- Test mới: `node scripts/test-endpoints-v38.js` (24 ca), smoke test có thêm kiểm tra V38.

## Chưa kiểm chứng được
Code Java chưa được biên dịch trong môi trường làm việc (không có Android SDK). JS, giao diện và luồng thông báo đã chạy thử với Chromium + bridge giả lập. Hãy build bằng GitHub Actions và thử trên máy thật (Android 13+).
