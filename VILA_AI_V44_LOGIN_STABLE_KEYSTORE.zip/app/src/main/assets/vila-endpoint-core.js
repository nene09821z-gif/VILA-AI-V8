/* VILA V38 — Endpoint Doctor core (pure logic, no DOM).
 * Nhận diện nhà cung cấp + kiểu API từ bất kỳ URL nào người dùng dán vào
 * (host, Base URL, hoặc endpoint đầy đủ như /chat/completions, :generateContent),
 * chuẩn hóa về Base URL đúng, và dò (probe) xem endpoint có thật sự hoạt động không.
 * Dùng được cả trong WebView lẫn Node (để test offline). */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.VilaEndpointCore = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  /* Bảng cổng đã biết. `base` là Base URL chuẩn; `kind`: gemini (native) | openai (Chat Completions). */
  var KNOWN = [
    { id: 'gemini', kind: 'gemini', label: 'Google Gemini', host: /(^|\.)generativelanguage\.googleapis\.com$/i, base: 'https://generativelanguage.googleapis.com/v1beta' },
    { id: 'groq', kind: 'openai', label: 'Groq', host: /(^|\.)api\.groq\.com$/i, base: 'https://api.groq.com/openai/v1' },
    { id: 'cerebras', kind: 'openai', label: 'Cerebras', host: /(^|\.)api\.cerebras\.ai$/i, base: 'https://api.cerebras.ai/v1' },
    { id: 'openrouter', kind: 'openai', label: 'OpenRouter', host: /(^|\.)openrouter\.ai$/i, base: 'https://openrouter.ai/api/v1' },
    /* Các cổng OpenAI-compatible phổ biến — đều chạy qua provider "custom". */
    { id: 'custom', kind: 'openai', label: 'OpenAI', host: /(^|\.)api\.openai\.com$/i, base: 'https://api.openai.com/v1' },
    { id: 'custom', kind: 'openai', label: 'DeepSeek', host: /(^|\.)api\.deepseek\.com$/i, base: 'https://api.deepseek.com/v1' },
    { id: 'custom', kind: 'openai', label: 'Mistral', host: /(^|\.)api\.mistral\.ai$/i, base: 'https://api.mistral.ai/v1' },
    { id: 'custom', kind: 'openai', label: 'xAI', host: /(^|\.)api\.x\.ai$/i, base: 'https://api.x.ai/v1' },
    { id: 'custom', kind: 'openai', label: 'Together AI', host: /(^|\.)api\.together\.(xyz|ai)$/i, base: 'https://api.together.xyz/v1' },
    { id: 'custom', kind: 'openai', label: 'Fireworks', host: /(^|\.)api\.fireworks\.ai$/i, base: 'https://api.fireworks.ai/inference/v1' },
    { id: 'custom', kind: 'openai', label: 'NVIDIA NIM', host: /(^|\.)integrate\.api\.nvidia\.com$/i, base: 'https://integrate.api.nvidia.com/v1' },
    { id: 'custom', kind: 'openai', label: 'SiliconFlow', host: /(^|\.)api\.siliconflow\.(cn|com)$/i, base: 'https://api.siliconflow.cn/v1' },
    { id: 'custom', kind: 'openai', label: 'Perplexity', host: /(^|\.)api\.perplexity\.ai$/i, base: 'https://api.perplexity.ai', noModels: true },
    { id: 'custom', kind: 'openai', label: 'Ollama (máy local)', host: /^(localhost|127\.0\.0\.1|\[::1\]|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+)$/i, port: '11434', base: null, local: true },
    { id: 'custom', kind: 'openai', label: 'LM Studio (máy local)', host: /^(localhost|127\.0\.0\.1|\[::1\]|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+)$/i, port: '1234', base: null, local: true }
  ];

  function pathOf(base) { try { return new URL(base).pathname.replace(/\/+$/, ''); } catch (_) { return ''; } }

  function emptyResult(input, error) {
    return { ok: false, error: error || 'URL không hợp lệ', notes: [], changed: false };
  }

  /* detect(input) → mô tả đầy đủ endpoint. Không bao giờ ném lỗi. */
  function detect(input, hint) {
    var raw = String(input == null ? '' : input).trim().replace(/^["'`]+|["'`]+$/g, '');
    if (!raw) return emptyResult(input, 'Chưa nhập Base URL.');
    var notes = [];
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(raw)) {
      if (/^[^\s/]+\.[^\s/]+|^localhost|^\d+\.\d+\.\d+\.\d+/i.test(raw)) { raw = (/^(localhost|127\.|10\.|192\.168\.)/i.test(raw) ? 'http://' : 'https://') + raw; notes.push('Tự thêm giao thức vào URL.'); }
      else return emptyResult(input, 'Không nhận ra URL. Hãy nhập dạng https://...');
    }
    var u;
    try { u = new URL(raw); } catch (_) { return emptyResult(input, 'Không nhận ra URL. Hãy nhập dạng https://...'); }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return emptyResult(input, 'API URL phải dùng HTTP hoặc HTTPS.');

    /* Không bao giờ giữ API key nằm trong URL. */
    var leakedKey = false;
    ['key', 'api_key', 'apikey', 'access_token', 'token'].forEach(function (k) { if (u.searchParams.has(k)) { u.searchParams.delete(k); leakedKey = true; } });
    if (leakedKey) notes.push('URL có chứa API key — đã bỏ khỏi URL. Hãy nhập key vào ô API Key.');
    if (u.username || u.password) { u.username = ''; u.password = ''; notes.push('Đã bỏ user:pass khỏi URL.'); }

    var host = u.hostname.toLowerCase();
    var path = u.pathname.replace(/\/+$/, '');
    var sawGeminiMethod = /:(?:stream)?generateContent$/i.test(path);

    /* Cắt các hậu tố endpoint để lấy ra Base URL. */
    var before = path;
    path = path.replace(/:(?:stream)?generateContent$/i, '').replace(/:(?:count|embed)[A-Za-z]*$/i, '');
    var geminiHost = KNOWN[0].host.test(host);
    if (geminiHost || sawGeminiMethod) path = path.replace(/\/models(?:\/[^/]*)?$/i, '');
    path = path.replace(/\/(?:chat\/completions|completions|responses|embeddings)$/i, '').replace(/\/models$/i, '');
    path = path.replace(/\/+$/, '');
    if (path !== before.replace(/\/+$/, '')) notes.push('Đã cắt phần endpoint ở cuối, giữ lại Base URL.');

    /* Chọn mục "đã biết" theo host (+ cổng cho server local). */
    var entry = null, i;
    for (i = 0; i < KNOWN.length; i++) {
      var k = KNOWN[i];
      if (!k.host.test(host)) continue;
      if (k.local) { if (u.port === k.port) { entry = k; break; } continue; }
      entry = k; break;
    }
    var kind, provider, label, known = !!entry, base;
    if (entry) {
      kind = entry.kind; provider = entry.id; label = entry.label;
    } else {
      kind = sawGeminiMethod ? 'gemini' : 'openai';
      provider = hint && hint !== 'gemini' ? hint : (kind === 'gemini' ? 'gemini' : 'custom');
      label = kind === 'gemini' ? 'Gemini (proxy tuỳ chỉnh)' : 'OpenAI-compatible (tuỳ chỉnh)';
    }

    if (kind === 'gemini') {
      path = path.replace(/\/openai$/i, function () { notes.push('Gemini native không dùng hậu tố /openai — đã bỏ.'); return ''; });
      if (!/\/v1(?:beta|alpha|beta1)?$/i.test(path)) {
        if (geminiHost) { path = (path ? path : '') + '/v1beta'; notes.push('Thiếu phiên bản API — dùng /v1beta.'); }
      }
      u.pathname = path || '/';
      base = u.origin + path;
    } else {
      var entryPath = entry && entry.base ? pathOf(entry.base) : '';
      if (entry && entry.base && (path === '' || /^\/v\d+$/i.test(path)) && path !== entryPath) {
        notes.push('Đường dẫn chuẩn của ' + entry.label + ' là ' + entryPath + ' — đã sửa.');
        path = entryPath;
      } else if (!entry && path === '') {
        path = '/v1'; notes.push('Không có đường dẫn — giả định chuẩn OpenAI /v1.');
      } else if (entry && entry.local && path === '') {
        path = '/v1';
      }
      base = u.origin + path;
    }

    var chatUrl = kind === 'gemini' ? base + '/models/{model}:generateContent' : base + '/chat/completions';
    var modelsUrl = base + '/models';
    var inputNorm = String(input).trim().replace(/\/+$/, '');
    var changed = base !== inputNorm;
    if (u.protocol === 'http:' && !(entry && entry.local) && !/^(localhost|127\.|10\.|192\.168\.)/.test(host)) notes.push('Đang dùng HTTP không mã hoá — nên đổi sang HTTPS.');

    return {
      ok: true, base: base, kind: kind, provider: provider, label: label, known: known,
      local: !!(entry && entry.local), noModels: !!(entry && entry.noModels),
      host: host, chatUrl: chatUrl, modelsUrl: modelsUrl, notes: notes, changed: changed
    };
  }

  /* URL cụ thể để gọi — thay cho các hàm cũ dễ sai. */
  function chatEndpoint(det, model) {
    if (!det || !det.ok) throw new Error((det && det.error) || 'Base URL không hợp lệ.');
    return det.kind === 'gemini' ? det.base + '/models/' + encodeURIComponent(model || 'MODEL') + ':generateContent' : det.base + '/chat/completions';
  }

  function authHeaders(det, key) {
    var h = {};
    key = String(key || '').trim();
    if (!key) return h;
    if (det.kind === 'gemini') h['x-goog-api-key'] = key; else h.Authorization = 'Bearer ' + key;
    return h;
  }

  /* Các Base URL ứng viên khi cổng tuỳ chỉnh trả 404 — để "tự dò" endpoint đúng. */
  function candidates(det) {
    var out = [det.base], root = det.base.replace(/\/v\d+(?:beta|alpha)?$/i, '');
    function add(x) { if (x && out.indexOf(x) < 0) out.push(x); }
    if (det.kind === 'openai' && !det.known) {
      var origin = new URL(det.base).origin;
      add(root); add(root + '/v1'); add(origin + '/v1'); add(origin + '/openai/v1'); add(origin + '/api/v1'); add(origin);
    }
    return out;
  }

  function classify(status) {
    if (status >= 200 && status < 300) return 'ok';
    if (status === 401 || status === 403) return 'auth';
    if (status === 404 || status === 405 || status === 410) return 'notfound';
    if (status === 429) return 'ratelimit';
    if (status >= 500) return 'server';
    return 'error';
  }

  function withTimeout(fetchImpl, url, opts, ms) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) ctl.abort(); }, ms);
    var o = Object.assign({}, opts || {}); if (ctl) o.signal = ctl.signal;
    return fetchImpl(url, o).then(function (r) { clearTimeout(timer); return r; }, function (e) { clearTimeout(timer); throw e; });
  }

  function parseModels(det, data) {
    var rows = det.kind === 'gemini'
      ? (data && data.models || []).filter(function (m) { return !m.supportedGenerationMethods || m.supportedGenerationMethods.indexOf('generateContent') >= 0; }).map(function (m) { return String(m.name || '').replace(/^models\//, ''); })
      : ((data && (data.data || data.models || data.items)) || []).map(function (m) { return String(m && (m.id || m.name) || ''); });
    return rows.filter(Boolean);
  }

  function pickChatModel(ids, preferred) {
    if (preferred && ids.indexOf(preferred) >= 0) return preferred;
    var bad = /(embed|whisper|tts|speech|transcri|moderation|rerank|guard|image|dall|flux|veo|live|audio|realtime)/i;
    var chatty = ids.filter(function (id) { return !bad.test(id); });
    var fast = chatty.filter(function (id) { return /flash|instant|mini|small|8b|oss-20b|free/i.test(id); });
    return (fast[0] || chatty[0] || ids[0] || preferred || '');
  }

  /* probeModels: GET /models. Trả { state, status, ms, models, ids, url, message }.
   * state: ok | auth | notfound | ratelimit | server | error | network | timeout | nokey */
  function probeModels(det, key, opts) {
    opts = opts || {};
    var f = opts.fetch || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
    if (!f) return Promise.resolve({ state: 'network', ms: 0, message: 'Môi trường không hỗ trợ fetch.' });
    if (!det || !det.ok) return Promise.resolve({ state: 'error', ms: 0, message: (det && det.error) || 'URL không hợp lệ' });
    if (!String(key || '').trim() && !det.local) return Promise.resolve({ state: 'nokey', ms: 0, message: 'Chưa có API key', url: det.modelsUrl });
    var url = det.modelsUrl;
    if (det.kind === 'gemini') url += (url.indexOf('?') < 0 ? '?' : '&') + 'pageSize=1000';
    if (det.provider === 'openrouter') url += (url.indexOf('?') < 0 ? '?' : '&') + 'output_modalities=text';
    var t0 = Date.now();
    return withTimeout(f, url, { method: 'GET', headers: authHeaders(det, key) }, opts.timeout || 12000).then(function (res) {
      var ms = Date.now() - t0, state = classify(res.status);
      return res.text().then(function (txt) {
        var data = {}; try { data = txt ? JSON.parse(txt) : {}; } catch (_) {}
        var ids = state === 'ok' ? parseModels(det, data) : [];
        var msg = (data && data.error && (data.error.message || data.error)) || (data && data.message) || '';
        if (typeof msg !== 'string') { try { msg = JSON.stringify(msg); } catch (_) { msg = ''; } }
        if (state === 'ok' && !ids.length) state = 'error', msg = msg || 'Endpoint /models không trả về model nào.';
        return { state: state, status: res.status, ms: ms, ids: ids, models: ids.length, url: det.modelsUrl, message: String(msg).slice(0, 200) };
      });
    }, function (e) {
      var ms = Date.now() - t0;
      if (e && e.name === 'AbortError') return { state: 'timeout', ms: ms, message: 'Quá thời gian chờ', url: det.modelsUrl };
      return { state: 'network', ms: ms, message: 'Không kết nối được (mạng, DNS hoặc bị chặn CORS)', url: det.modelsUrl };
    });
  }

  /* probeChat: gửi 1 tin nhắn cực ngắn để chứng minh endpoint chat chạy thật. */
  function probeChat(det, key, model, opts) {
    opts = opts || {};
    var f = opts.fetch || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
    if (!f) return Promise.resolve({ state: 'network', ms: 0, message: 'Môi trường không hỗ trợ fetch.' });
    if (!model) return Promise.resolve({ state: 'error', ms: 0, message: 'Chưa có model để thử.' });
    var headers = Object.assign({ 'Content-Type': 'application/json' }, authHeaders(det, key));
    var body = det.kind === 'gemini'
      ? { contents: [{ role: 'user', parts: [{ text: 'Trả lời đúng một từ: OK' }] }], generationConfig: { maxOutputTokens: 32 } }
      : { model: model, messages: [{ role: 'user', content: 'Trả lời đúng một từ: OK' }], max_tokens: 32 };
    var t0 = Date.now(), url = chatEndpoint(det, model);
    return withTimeout(f, url, { method: 'POST', headers: headers, body: JSON.stringify(body) }, opts.timeout || 25000).then(function (res) {
      var ms = Date.now() - t0, state = classify(res.status);
      return res.text().then(function (txt) {
        var data = {}; try { data = txt ? JSON.parse(txt) : {}; } catch (_) {}
        var msg = (data && data.error && (data.error.message || data.error)) || (data && data.message) || '';
        if (typeof msg !== 'string') { try { msg = JSON.stringify(msg); } catch (_) { msg = ''; } }
        return { state: state, status: res.status, ms: ms, model: model, url: url, message: String(msg).slice(0, 200) };
      });
    }, function (e) {
      var ms = Date.now() - t0;
      if (e && e.name === 'AbortError') return { state: 'timeout', ms: ms, model: model, url: url, message: 'Quá thời gian chờ' };
      return { state: 'network', ms: ms, model: model, url: url, message: 'Không kết nối được' };
    });
  }

  /* diagnose: quét 1 cổng. Với cổng tuỳ chỉnh bị 404 sẽ tự thử các Base URL khác.
   * opts: { fetch, deep, preferredModel, timeout }
   * Trả { det, models, chat, verdict: ok|warn|bad|idle, summary, fixedBase } */
  function diagnose(input, key, opts) {
    opts = opts || {};
    var det = detect(input, opts.hint);
    if (!det.ok) return Promise.resolve({ det: det, verdict: 'bad', summary: det.error });
    var list = candidates(det), idx = 0, found = null;
    function next() {
      if (idx >= list.length) return Promise.resolve(found);
      var d = Object.assign({}, det, { base: list[idx], modelsUrl: list[idx] + '/models' });
      d.chatUrl = d.kind === 'gemini' ? d.base + '/models/{model}:generateContent' : d.base + '/chat/completions';
      idx++;
      return probeModels(d, key, opts).then(function (r) {
        if (r.state === 'ok' || r.state === 'auth' || r.state === 'ratelimit') { found = { d: d, r: r }; return found; }
        if (!found) found = { d: d, r: r, fallback: true };
        if (r.state === 'notfound' && idx < list.length) return next();
        return found;
      });
    }
    return next().then(function (f) {
      var d = f.d, m = f.r, out = { det: d, models: m, fixedBase: d.base !== det.base ? d.base : '' };
      if (out.fixedBase) d.notes = (d.notes || []).concat(['Tự dò ra Base URL đúng: ' + d.base]);
      if (det.noModels && m.state === 'notfound') m = out.models = { state: 'ok', ms: m.ms, models: 0, ids: [], message: 'Cổng này không có /models (bình thường).' };
      if (m.state === 'nokey') { out.verdict = 'idle'; out.summary = 'Chưa có API key'; return out; }
      if (m.state !== 'ok') {
        out.verdict = (m.state === 'ratelimit') ? 'warn' : 'bad';
        out.summary = ({
          auth: 'Endpoint đúng nhưng key bị từ chối (HTTP ' + m.status + ')', notfound: 'Không tìm thấy endpoint /models (HTTP ' + m.status + ')',
          ratelimit: 'Endpoint sống nhưng đang bị giới hạn lượt (HTTP 429)', server: 'Máy chủ lỗi (HTTP ' + m.status + ')',
          network: m.message, timeout: m.message, error: m.message || ('HTTP ' + m.status)
        })[m.state] || m.message;
        return out;
      }
      out.verdict = 'ok';
      out.summary = (m.models ? m.models + ' model' : 'Endpoint hoạt động') + ' · ' + m.ms + ' ms';
      if (!opts.deep) return out;
      var model = pickChatModel(m.ids || [], opts.preferredModel);
      return probeChat(d, key, model, opts).then(function (c) {
        if ((c.state === 'notfound' || (c.status === 400)) && m.ids && m.ids.length > 1 && model === opts.preferredModel) {
          var alt = pickChatModel(m.ids.filter(function (x) { return x !== model; }), '');
          return probeChat(d, key, alt, opts);
        }
        return c;
      }).then(function (c) {
        out.chat = c;
        if (c.state === 'ok') out.summary = 'Chat OK · ' + c.model + ' · ' + c.ms + ' ms';
        else if (c.state === 'ratelimit') { out.verdict = 'warn'; out.summary = 'Chat bị giới hạn lượt (429) · endpoint vẫn đúng'; }
        else { out.verdict = 'warn'; out.summary = 'Liệt kê model được nhưng chat lỗi: ' + (c.message || ('HTTP ' + c.status)); }
        return out;
      });
    });
  }

  return {
    KNOWN: KNOWN, detect: detect, chatEndpoint: chatEndpoint, authHeaders: authHeaders, candidates: candidates,
    classify: classify, probeModels: probeModels, probeChat: probeChat, diagnose: diagnose, pickChatModel: pickChatModel
  };
});
