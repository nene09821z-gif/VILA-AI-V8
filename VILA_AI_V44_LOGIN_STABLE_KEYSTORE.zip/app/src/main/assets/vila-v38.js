/* VILA V38
 *  1) Endpoint Doctor  — nhận diện + kiểm tra endpoint của mọi cổng API, tự sửa Base URL.
 *  2) Suy luận động    — panel "đang suy luận" sống động kiểu trợ lý AI hiện đại + chip "Đã suy nghĩ Xs".
 *  3) Thông báo ngoài app — xin quyền, báo khi AI trả lời xong lúc bạn ở app khác, giữ tiến trình chạy nền.
 * File này nạp SAU index.html nên ghi đè an toàn các hàm toàn cục cũ bằng window.xxx = ...
 */
(function () {
  'use strict';
  var Core = window.VilaEndpointCore;
  function $(id) { return document.getElementById(id); }
  function tryDo(fn, fb) { try { return fn(); } catch (_) { return fb; } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(msg, type) { if (typeof window.showToast === 'function') window.showToast(msg, type || 'info'); }
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (_) {} return null; }
  var reduceMotion = tryDo(function () { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }, false);

  /* ================================================================ CSS */
  var css = document.createElement('style');
  css.id = 'vila-v38-style';
  css.textContent = [
    '@keyframes vtSpin{to{transform:rotate(360deg)}}',
    '@keyframes vtSpinRev{to{transform:rotate(-360deg)}}',
    '@keyframes vtCore{0%,100%{transform:scale(.72);opacity:.8}50%{transform:scale(1.08);opacity:1}}',
    '@keyframes vtShimmer{to{background-position:-200% 0}}',
    '@keyframes vtSweep{0%{transform:translateX(-110%)}100%{transform:translateX(280%)}}',
    '@keyframes vtIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}',
    '@keyframes vtCaret{50%{opacity:0}}',
    '@keyframes vtPop{0%{transform:scale(.4);opacity:0}70%{transform:scale(1.25)}100%{transform:scale(1);opacity:1}}',
    '@keyframes vtGlow{0%,100%{box-shadow:0 0 0 0 rgba(34,211,238,.0),0 8px 28px rgba(2,12,28,.55)}50%{box-shadow:0 0 0 3px rgba(34,211,238,.10),0 8px 34px rgba(8,145,178,.28)}}',
    /* Sửa gốc lỗi icon xoay: bộ đổi icon SVG đã làm mất fa-spin. */
    '.vila-spin,svg[data-vila-icon="circle-notch"],svg[data-vila-icon="spinner"]{animation:vtSpin .9s linear infinite;transform-origin:50% 50%}',
    '.vila-thinking-step.active i,.vila-thinking-step.active svg{animation:vtSpin .9s linear infinite!important;transform-origin:50% 50%}',
    /* Panel suy luận */
    '.vt-panel{position:relative;width:min(100%,700px);margin:0 0 18px 42px;padding:13px 15px 12px;border:1px solid rgba(34,211,238,.28);border-radius:16px;background:linear-gradient(140deg,#04162d,#061327);overflow:hidden;animation:vtIn .28s ease-out,vtGlow 3.2s ease-in-out infinite}',
    '.vt-panel::before{content:"";position:absolute;inset:0;pointer-events:none;background:radial-gradient(120% 90% at 0% 0%,rgba(34,211,238,.10),transparent 55%),radial-gradient(90% 90% at 100% 100%,rgba(167,139,250,.09),transparent 60%)}',
    '.vt-head{position:relative;display:flex;align-items:center;gap:12px}',
    '.vt-orb{position:relative;flex:none;width:30px;height:30px}',
    '.vt-orb i{position:absolute;border-radius:50%;box-sizing:border-box}',
    '.vt-orb .r1{inset:0;border:2.5px solid rgba(34,211,238,.14);border-top-color:#22d3ee;border-right-color:#38bdf8;animation:vtSpin .95s linear infinite}',
    '.vt-orb .r2{inset:5px;border:2px solid rgba(167,139,250,.12);border-bottom-color:#a78bfa;border-left-color:#c4b5fd;animation:vtSpinRev 1.5s linear infinite}',
    '.vt-orb .core{inset:11px;background:radial-gradient(circle,#ecfeff,#22d3ee 62%,#0ea5e9);box-shadow:0 0 10px #22d3ee;animation:vtCore 1.5s ease-in-out infinite}',
    '.vt-titles{min-width:0;flex:1;display:flex;flex-direction:column;gap:2px}',
    '.vt-title{font-size:13px;font-weight:700;line-height:1.25;background:linear-gradient(90deg,#7c93ad 0%,#f0fbff 42%,#7c93ad 84%);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;animation:vtShimmer 1.9s linear infinite}',
    '.vt-sub{font-size:11px;color:#8ebfdf;min-height:15px;line-height:1.35;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.vt-sub::after{content:"";display:inline-block;width:6px;height:11px;margin-left:2px;vertical-align:-2px;background:#22d3ee;border-radius:1px;animation:vtCaret .9s steps(1) infinite}',
    '.vt-meta{flex:none;text-align:right;display:flex;flex-direction:column;gap:2px;align-items:flex-end}',
    '.vt-time{font:700 12px/1 ui-monospace,SFMono-Regular,Menlo,monospace;color:#e0f2fe;font-variant-numeric:tabular-nums}',
    '.vt-prov{font-size:9.5px;color:#6ea8cf;max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.vt-bar{position:relative;height:2px;margin:11px 0 10px;border-radius:2px;background:rgba(56,189,248,.12);overflow:hidden}',
    '.vt-bar i{position:absolute;top:0;left:0;height:100%;width:38%;border-radius:2px;background:linear-gradient(90deg,transparent,#22d3ee,#a78bfa,transparent);animation:vtSweep 1.35s ease-in-out infinite}',
    '.vt-steps{position:relative;list-style:none;margin:0;padding:0 0 0 4px;display:grid;gap:7px;border-left:1px solid rgba(100,116,139,.32)}',
    '.vt-step{display:flex;align-items:center;gap:9px;padding-left:12px;font-size:11.5px;line-height:1.35;color:#5f7389;min-height:16px;transition:color .25s}',
    '.vt-step .m{position:relative;flex:none;width:13px;height:13px;margin-left:-19px;border-radius:50%;box-sizing:border-box;background:#04162d;border:1.5px solid #3b4b5f;display:inline-flex;align-items:center;justify-content:center;font-size:9px;line-height:1;color:transparent;transition:all .25s}',
    '.vt-step.active{color:#e0f2fe}',
    '.vt-step.active .m{border-color:rgba(34,211,238,.25);border-top-color:#22d3ee;border-right-color:#22d3ee;animation:vtSpin .8s linear infinite}',
    '.vt-step.done{color:#a9c4dc}',
    '.vt-step.done .m{border-color:#34d399;background:#34d399;color:#03231a;font-weight:900;animation:vtPop .3s ease-out}',
    '.vt-step.done .m::after{content:"\\2713"}',
    '.vt-step.skip{color:#3f4e60;text-decoration:line-through;text-decoration-color:#2b394b}',
    '.vt-step .d{margin-left:auto;font:600 10px/1 ui-monospace,Menlo,monospace;color:#5f8aa8;font-variant-numeric:tabular-nums}',
    /* Chip tổng kết */
    '.vt-chip{width:min(100%,700px);margin:0 0 6px 42px;color:#8ebfdf;font-size:11.5px;animation:vtIn .25s ease-out}',
    '.vt-chip summary{display:inline-flex;align-items:center;gap:7px;cursor:pointer;list-style:none;user-select:none;padding:4px 10px 4px 6px;border-radius:999px;border:1px solid rgba(34,211,238,.22);background:rgba(4,22,45,.7)}',
    '.vt-chip summary::-webkit-details-marker{display:none}',
    '.vt-chip .tick{width:15px;height:15px;border-radius:50%;background:#34d399;color:#03231a;font-size:9px;font-weight:900;display:inline-flex;align-items:center;justify-content:center}',
    '.vt-chip .car{width:6px;height:6px;border-right:1.5px solid #6ea8cf;border-bottom:1.5px solid #6ea8cf;transform:rotate(45deg);margin:-2px 0 0 2px;transition:transform .2s}',
    '.vt-chip[open] .car{transform:rotate(-135deg);margin-top:2px}',
    '.vt-chip ol{list-style:none;margin:7px 0 2px 10px;padding:0 0 0 12px;border-left:1px solid rgba(100,116,139,.32);display:grid;gap:4px}',
    '.vt-chip li{display:flex;gap:10px;color:#9cb9d1}.vt-chip li b{font:600 10px/1.6 ui-monospace,Menlo,monospace;color:#5f8aa8;margin-left:auto}',
    '@media(max-width:767px){.vt-panel,.vt-chip{margin-left:0;width:100%}.vt-panel{padding:11px 12px 10px;border-radius:14px}.vt-title{font-size:12.5px}.vt-prov{display:none}}',
    '@media(prefers-reduced-motion:reduce){.vt-panel,.vt-orb i,.vt-title,.vt-bar i,.vt-step.active .m,.vt-sub::after,.vila-spin,svg[data-vila-icon="circle-notch"]{animation:none!important}.vt-title{color:#e0f2fe;-webkit-text-fill-color:#e0f2fe;background:none}.vt-bar i{width:100%;opacity:.4}}',
    /* Endpoint Doctor */
    '.vep{display:grid;gap:9px;margin-top:2px}',
    '.vep-live{padding:10px 11px;border:1px solid #14527f;border-radius:12px;background:rgba(4,22,45,.75);font-size:11.5px;line-height:1.45;color:#b8d4ea;word-break:break-all}',
    '.vep-live b{color:#e0f2fe}.vep-live code,.vep-row code{display:block;margin-top:3px;font:11px/1.4 ui-monospace,Menlo,monospace;color:#7dd3fc;word-break:break-all}',
    '.vep-live.bad{border-color:#7f1d1d;color:#fecaca}.vep-note{margin-top:5px;color:#fcd34d;font-size:10.5px}',
    '.vep-btns{display:flex;flex-wrap:wrap;gap:7px}',
    '.vep-btn,.vn-btn{appearance:none;border:1px solid #14527f;background:linear-gradient(180deg,#07335c,#052443);color:#e0f2fe;font:600 12px/1 inherit;padding:10px 12px;border-radius:11px;cursor:pointer;min-height:38px}',
    '.vep-btn:active,.vn-btn:active{transform:scale(.97)}.vep-btn.ghost,.vn-btn.ghost{background:transparent;color:#8ebfdf}.vep-btn[disabled],.vn-btn[disabled]{opacity:.5}',
    '.vep-list{display:grid;gap:7px}',
    '.vep-row{display:flex;gap:10px;align-items:flex-start;padding:9px 10px;border:1px solid #103a60;border-radius:12px;background:rgba(3,16,33,.7);cursor:pointer}',
    '.vep-row .t{font-size:12px;font-weight:700;color:#e0f2fe;display:flex;gap:8px;align-items:center}',
    '.vep-row .s{font-size:11px;color:#9cb9d1;margin-top:2px;line-height:1.4}',
    '.vep-row .fix{margin-top:6px}',
    '.vep-dot{flex:none;width:9px;height:9px;margin-top:4px;border-radius:50%;background:#475569;box-shadow:0 0 0 3px rgba(71,85,105,.18)}',
    '.vep-dot[data-s="ok"]{background:#34d399;box-shadow:0 0 0 3px rgba(52,211,153,.18)}',
    '.vep-dot[data-s="warn"]{background:#fbbf24;box-shadow:0 0 0 3px rgba(251,191,36,.18)}',
    '.vep-dot[data-s="bad"]{background:#f87171;box-shadow:0 0 0 3px rgba(248,113,113,.18)}',
    '.vep-dot[data-s="busy"]{background:transparent;border:2px solid rgba(34,211,238,.3);border-top-color:#22d3ee;box-shadow:none;animation:vtSpin .8s linear infinite}',
    '.vep-pdot{display:inline-block;width:7px;height:7px;margin-left:7px;border-radius:50%;background:#475569;vertical-align:middle}',
    '.vep-pdot[data-s="ok"]{background:#34d399}.vep-pdot[data-s="warn"]{background:#fbbf24}.vep-pdot[data-s="bad"]{background:#f87171}',
    /* Thông báo */
    '.vn-card{display:grid;gap:9px}',
    '.vn-row{display:flex;align-items:center;gap:8px;font-size:12px;color:#cfe6f7}',
    '.vn-switch{display:flex;align-items:center;gap:9px;font-size:12px;color:#cfe6f7;margin:0}',
    '.vn-switch input{width:18px;height:18px;accent-color:#22d3ee;flex:none}',
    '.vn-actions{display:flex;flex-wrap:wrap;gap:7px}',
    '.vn-prompt{position:fixed;left:50%;bottom:calc(86px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:70;width:min(94vw,440px);padding:14px;border:1px solid rgba(34,211,238,.35);border-radius:18px;background:linear-gradient(145deg,#06213f,#04132a);box-shadow:0 18px 50px rgba(0,0,0,.6);animation:vtIn .3s ease-out}',
    '.vn-prompt h4{margin:0 0 4px;font-size:13.5px;font-weight:800;color:#f0fbff}.vn-prompt p{margin:0 0 11px;font-size:11.5px;line-height:1.5;color:#9cc4e2}',
    '.vn-prompt .vn-actions{justify-content:flex-end}'
  ].join('\n');
  document.head.appendChild(css);

  /* ============================================================ 1) ENDPOINT DOCTOR */
  var HEALTH_KEY = 'vila_ep_health_v38';
  function loadHealth() { return tryDo(function () { return JSON.parse(store(HEALTH_KEY) || '{}'); }, {}); }
  function saveHealth(h) { store(HEALTH_KEY, JSON.stringify(h)); }
  function providerIds() { return tryDo(function () { return Object.keys(PROVIDERS); }, ['gemini', 'groq', 'cerebras', 'openrouter', 'custom']); }
  function pname(p) { return tryDo(function () { return PROVIDERS[p].name; }, p); }
  function keyOf(p) { return tryDo(function () { return String(getProviderKey(p) || '').trim(); }, ''); }
  function baseOf(p) {
    var typed = (p === tryDo(function () { return activeProvider; }, '')) ? String(($('apiBaseUrlInput') || {}).value || '').trim() : '';
    return typed || tryDo(function () { return getProviderBaseUrl(p); }, '') || tryDo(function () { return PROVIDERS[p].baseUrl; }, '');
  }
  function prefModel(p) { return store('vila_' + p + '_model') || tryDo(function () { return PROVIDERS[p].models[0].id; }, ''); }

  function paintProviderDots() {
    var h = loadHealth();
    providerIds().forEach(function (p) {
      var btn = $('preset' + p.charAt(0).toUpperCase() + p.slice(1) + 'Btn'); if (!btn) return;
      var left = btn.querySelector('.vila-provider-left'); if (!left) return;
      var dot = left.querySelector('.vep-pdot');
      if (!dot) { dot = document.createElement('span'); dot.className = 'vep-pdot'; left.appendChild(dot); }
      var v = h[p] && h[p].verdict;
      dot.setAttribute('data-s', v === 'ok' || v === 'warn' || v === 'bad' ? v : '');
      dot.title = h[p] ? h[p].summary : '';
    });
  }

  function applyBase(p, base) {
    store('vila_' + p + '_base_url', base);
    if (p === 'gemini' && window.Android && typeof window.Android.saveGeminiBaseUrl === 'function') tryDo(function () { window.Android.saveGeminiBaseUrl(base); });
    if (p === tryDo(function () { return activeProvider; })) {
      tryDo(function () { activeBaseUrl = base; });
      if ($('apiBaseUrlInput')) $('apiBaseUrlInput').value = base;
      tryDo(function () { updateEndpointPreview(); });
    }
  }

  function renderLive() {
    var box = $('vepLive'), input = $('apiBaseUrlInput'); if (!box || !input) return;
    var v = String(input.value || '').trim();
    var act = tryDo(function () { return activeProvider; }, 'gemini');
    if (!v) { box.className = 'vep-live'; box.innerHTML = 'Dán Base URL hoặc cả endpoint — VILA tự nhận diện cổng và sửa đường dẫn.'; return; }
    var d = Core.detect(v, act);
    if (!d.ok) { box.className = 'vep-live bad'; box.innerHTML = '<b>Chưa nhận diện được</b><br>' + esc(d.error); return; }
    box.className = 'vep-live';
    var html = '<b>' + esc(d.label) + '</b> · ' + (d.kind === 'gemini' ? 'Gemini native' : 'OpenAI Chat Completions') +
      '<code>chat → ' + esc(d.chatUrl) + '</code><code>models → ' + esc(d.modelsUrl) + '</code>';
    d.notes.forEach(function (n) { html += '<div class="vep-note">• ' + esc(n) + '</div>'; });
    html += '<div class="vep-btns" style="margin-top:8px">';
    if (d.changed) html += '<button type="button" class="vep-btn" data-act="applyurl">Áp dụng URL chuẩn</button>';
    if (d.known && d.provider !== act) html += '<button type="button" class="vep-btn ghost" data-act="switch" data-p="' + esc(d.provider) + '">Chuyển sang ' + esc(d.provider === 'custom' ? 'Custom API' : pname(d.provider)) + '</button>';
    html += '</div>';
    box.innerHTML = html;
    box._det = d;
  }

  function renderRows(results, busyMap) {
    var list = $('vepList'); if (!list) return;
    list.innerHTML = providerIds().map(function (p) {
      var r = results[p], busy = busyMap && busyMap[p];
      var st = busy ? 'busy' : (r ? r.verdict : '');
      var summary = busy ? 'Đang dò endpoint…' : (r ? r.summary : 'Chưa quét');
      var url = r && r.det && r.det.ok ? (r.det.kind === 'gemini' ? r.det.base : r.det.base + '/chat/completions') : '';
      var fix = r && r.fixedBase ? '<div class="fix"><button type="button" class="vep-btn" data-act="fixbase" data-p="' + esc(p) + '" data-base="' + esc(r.fixedBase) + '">Dùng Base URL đúng</button></div>' : '';
      return '<div class="vep-row" data-act="pick" data-p="' + esc(p) + '"><span class="vep-dot" data-s="' + esc(st) + '"></span><div style="min-width:0"><div class="t">' + esc(pname(p)) + '</div><div class="s">' + esc(summary) + '</div>' + (url ? '<code>' + esc(url) + '</code>' : '') + fix + '</div></div>';
    }).join('');
  }

  var scanning = false, lastResults = {};
  async function scanAll(deep) {
    if (scanning) return; scanning = true;
    var ids = providerIds(), busy = {}, results = {}, health = loadHealth();
    var b1 = $('vepQuick'), b2 = $('vepDeep'); if (b1) b1.disabled = true; if (b2) b2.disabled = true;
    ids.forEach(function (p) { busy[p] = true; }); renderRows(results, busy);
    await Promise.all(ids.map(async function (p) {
      var base = baseOf(p), key = keyOf(p), r;
      try {
        if (p === 'custom' && !base) r = { verdict: 'idle', summary: 'Chưa cấu hình Base URL cho Custom API' };
        else r = await Core.diagnose(base, key, { deep: !!deep, preferredModel: prefModel(p), hint: p });
      } catch (e) { r = { verdict: 'bad', summary: String(e && e.message || e) }; }
      results[p] = r; busy[p] = false;
      health[p] = { verdict: r.verdict, summary: r.summary, at: Date.now() };
      renderRows(results, busy);
    }));
    saveHealth(health); lastResults = results; paintProviderDots();
    tryDo(function () { window.vilaUpdateProviderRail && window.vilaUpdateProviderRail(); });
    var okN = ids.filter(function (p) { return results[p] && results[p].verdict === 'ok'; }).length;
    var withKey = ids.filter(function (p) { return keyOf(p); }).length;
    toast('Quét xong: ' + okN + '/' + Math.max(withKey, okN) + ' cổng có key đang hoạt động.', okN ? 'success' : 'info');
    if (b1) b1.disabled = false; if (b2) b2.disabled = false; scanning = false;
  }

  function mountDoctor() {
    var input = $('apiBaseUrlInput'); if (!input || $('vepCard')) return;
    var field = input.closest('.vila-field') || input.parentElement;
    var card = document.createElement('div'); card.id = 'vepCard'; card.className = 'vila-field vep';
    card.innerHTML = '<label>Endpoint Doctor</label><div id="vepLive" class="vep-live"></div>' +
      '<div class="vep-btns"><button type="button" class="vep-btn" id="vepQuick">Quét nhanh các cổng</button><button type="button" class="vep-btn ghost" id="vepDeep">Quét sâu (gửi 1 tin thử)</button></div>' +
      '<div id="vepList" class="vep-list"></div>' +
      '<p class="vila-help">Quét nhanh gọi <code>/models</code> bằng key đã lưu. Quét sâu gửi thêm 1 tin ngắn để chứng minh endpoint chat chạy thật (tốn rất ít quota). Key không bao giờ bị gửi tới nơi nào khác ngoài chính cổng đó.</p>';
    field.insertAdjacentElement('afterend', card);
    card.addEventListener('click', function (e) {
      var t = e.target.closest('[data-act]'); if (!t) return;
      var act = t.getAttribute('data-act');
      if (act === 'applyurl') { var d = $('vepLive')._det; if (d) { input.value = d.base; renderLive(); toast('Đã áp dụng Base URL chuẩn.', 'success'); } }
      else if (act === 'switch') { var p = t.getAttribute('data-p'); tryDo(function () { applyProviderPreset(p); }); var d2 = Core.detect(input.value, p); if (d2.ok) { tryDo(function () { }); } renderLive(); }
      else if (act === 'fixbase') { e.stopPropagation(); applyBase(t.getAttribute('data-p'), t.getAttribute('data-base')); toast('Đã đổi Base URL của ' + pname(t.getAttribute('data-p')) + '.', 'success'); renderLive(); }
      else if (act === 'pick') { var pp = t.getAttribute('data-p'); if (pp && pp !== tryDo(function () { return activeProvider; })) { tryDo(function () { applyProviderPreset(pp); }); renderLive(); } }
    });
    $('vepQuick').addEventListener('click', function () { scanAll(false); });
    $('vepDeep').addEventListener('click', function () { scanAll(true); });
    var timer = null;
    input.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(renderLive, 300); });
    input.addEventListener('paste', function () { setTimeout(function () { normalizeBaseInput(true); renderLive(); }, 30); });
    input.addEventListener('change', function () { normalizeBaseInput(false); renderLive(); });
    renderRows(lastResults, null); renderLive(); paintProviderDots();
  }

  /* Chuẩn hóa ô Base URL: bỏ hậu tố endpoint, bỏ key, sửa đường dẫn sai. */
  function normalizeBaseInput(announce) {
    var input = $('apiBaseUrlInput'); if (!input) return;
    var v = String(input.value || '').trim(); if (!v) return;
    var d = Core.detect(v, tryDo(function () { return activeProvider; }, ''));
    if (d.ok && d.changed && d.base !== v) { input.value = d.base; if (announce !== false) toast('Đã tự chuẩn hóa Base URL → ' + d.base, 'info'); }
  }

  /* Ghi đè các hàm tạo URL cũ để MỌI cổng đều dùng cùng một bộ nhận diện. */
  var _gb = window.getGeminiBaseUrl;
  if (typeof _gb === 'function') window.getGeminiBaseUrl = function () { var v = _gb(); var d = Core.detect(v); return d.ok && d.kind === 'gemini' ? d.base : v; };
  var _ne = window.normalizeOpenAIEndpoint;
  if (typeof _ne === 'function') window.normalizeOpenAIEndpoint = function (v) { var d = Core.detect(v); return d.ok && d.kind === 'openai' ? d.base + '/chat/completions' : _ne(v); };
  var _ml = window.apiModelListUrl;
  if (typeof _ml === 'function') window.apiModelListUrl = function (b) { var d = Core.detect(b); return d.ok && d.kind === 'openai' ? d.modelsUrl : _ml(b); };
  var _pe = window.getProviderEndpoint;
  if (typeof _pe === 'function') window.getProviderEndpoint = function (p, model) {
    if (p === 'gemini') { var d = Core.detect(tryDo(function () { return activeBaseUrl; }, '')); if (d.ok && d.kind === 'gemini') return Core.chatEndpoint(d, model); }
    return _pe(p, model);
  };

  /* Sửa lỗi nút "Kiểm tra": từ V37 ô key luôn trống khi đã lưu nên báo "chưa nhập key". */
  window.testApiKey = async function () {
    var provider = tryDo(function () { return activeProvider; }, 'gemini'), name = pname(provider);
    var typed = String(($('apiKeyInput') || {}).value || '').trim();
    var key = typed || keyOf(provider);
    var baseRaw = String(($('apiBaseUrlInput') || {}).value || '').trim() || tryDo(function () { return PROVIDERS[provider].baseUrl; }, '');
    var det = Core.detect(baseRaw, provider);
    if (!det.ok) { toast(name + ': ' + det.error, 'error'); tryDo(function () { setApiConnectionStatus(false, det.error); }); return; }
    if (!key && !det.local) { toast('Chưa có ' + name + ' API Key — nhập key rồi bấm Kiểm tra.', 'error'); return; }
    toast('Đang kiểm tra ' + name + '…', 'info');
    var btn = $('testApiProviderBtn'); if (btn) btn.disabled = true;
    try {
      var r = await Core.diagnose(baseRaw, key, { deep: true, preferredModel: prefModel(provider), hint: provider });
      var h = loadHealth(); h[provider] = { verdict: r.verdict, summary: r.summary, at: Date.now() }; saveHealth(h); paintProviderDots();
      if (r.fixedBase) { applyBase(provider, r.fixedBase); toast('Đã tự dò ra Base URL đúng: ' + r.fixedBase, 'success'); renderLive(); }
      else if (det.changed && $('apiBaseUrlInput')) { $('apiBaseUrlInput').value = det.base; renderLive(); }
      if (r.verdict === 'ok' || r.verdict === 'warn') {
        tryDo(function () { setApiConnectionStatus(r.verdict === 'ok', name + ' • ' + r.summary); });
        toast(name + (r.verdict === 'ok' ? ' hoạt động tốt.' : ': ' + r.summary), r.verdict === 'ok' ? 'success' : 'info');
        if (r.models && r.models.ids && r.models.ids.length) {
          try {
            var models = await listProviderModels(provider, key, r.det.base);
            persistProviderModelCatalog(provider, models);
            if (provider === activeProvider) populateModelOptions();
          } catch (_) { }
        }
      } else {
        tryDo(function () { setApiConnectionStatus(false, name + ' • ' + r.summary); });
        toast(name + ': ' + r.summary, 'error');
      }
    } catch (e) { toast('Lỗi khi kiểm tra: ' + (e && e.message || e), 'error'); }
    finally { if (btn) btn.disabled = false; }
  };

  var _ss = window.saveSettings;
  if (typeof _ss === 'function') window.saveSettings = function () { normalizeBaseInput(true); return _ss.apply(this, arguments); };

  /* ================================================================ 2) SUY LUẬN ĐỘNG */
  var STEP_LABELS = ['Hiểu yêu cầu và ngữ cảnh', 'Tra cứu nguồn và công cụ khi cần', 'Suy luận bằng model phù hợp', 'Rà soát và soạn câu trả lời'];
  var PHRASES = {
    general: ['Đang đọc kỹ yêu cầu của bạn', 'Liên kết với ngữ cảnh cuộc trò chuyện', 'Cân nhắc vài hướng trả lời', 'Kiểm tra lại logic từng bước', 'Chọn cách diễn đạt rõ ràng nhất'],
    code: ['Đọc cấu trúc mã nguồn', 'Lần theo luồng dữ liệu', 'Soi các lỗi tiềm ẩn', 'Cân nhắc cách sửa gọn nhất', 'Kiểm tra cú pháp và import'],
    search: ['Chọn từ khóa tìm kiếm', 'Đối chiếu nhiều nguồn', 'Loại bỏ thông tin đã cũ', 'Tổng hợp những gì đáng tin'],
    image: ['Dựng bố cục hình ảnh', 'Chọn ánh sáng và màu sắc', 'Tinh chỉnh chi tiết'],
    math: ['Tách bài toán thành các bước', 'Kiểm tra từng phép biến đổi', 'Đối chiếu kết quả lần cuối']
  };
  var VT = window.__vilaThink = { cur: null };

  function lastUserText() {
    var t = tryDo(function () {
      var h = conversationHistory;
      for (var i = h.length - 1; i >= 0; i--) if (h[i] && h[i].role === 'user') { var c = h[i].content; return typeof c === 'string' ? c : (Array.isArray(c) ? c.map(function (x) { return x && x.text || ''; }).join(' ') : ''); }
      return '';
    }, '');
    return t || String(($('userPrompt') || {}).value || '');
  }
  function phraseSet(text) {
    var t = String(text || '').toLowerCase();
    if (/(ảnh|hình ảnh|vẽ|logo|tạo ảnh|image|poster)/.test(t)) return PHRASES.image;
    if (/(code|lỗi|bug|hàm|function|html|css|java|python|gradle|apk|build|script|thuật toán|api)/.test(t)) return PHRASES.code;
    if (/(tìm|tra cứu|tin tức|giá |hôm nay|mới nhất|search|nguồn)/.test(t)) return PHRASES.search;
    if (/(tính|toán|giải|phương trình|xác suất|đạo hàm|tích phân)/.test(t)) return PHRASES.math;
    return PHRASES.general;
  }
  function fmtTime(ms) {
    var s = ms / 1000; if (s < 60) return (s < 10 ? s.toFixed(1) : String(Math.floor(s))) + 's';
    return Math.floor(s / 60) + 'm ' + ('0' + Math.floor(s % 60)).slice(-2) + 's';
  }
  function fmtWords(ms) { var s = Math.max(1, Math.round(ms / 1000)); return s < 60 ? s + ' giây' : Math.floor(s / 60) + ' phút ' + (s % 60 ? (s % 60) + ' giây' : ''); }

  function stopTimers(st) { if (!st) return; (st.timers || []).forEach(function (t) { clearInterval(t); clearTimeout(t); }); st.timers = []; }

  function typeTo(st, text) {
    var el = st.el && st.el.querySelector('.vt-sub'); if (!el) return;
    clearInterval(st.typer);
    if (reduceMotion) { el.textContent = text; return; }
    var i = 0; el.textContent = '';
    st.typer = setInterval(function () { i++; el.textContent = text.slice(0, i); if (i >= text.length) clearInterval(st.typer); }, 22);
    st.timers.push(st.typer);
  }

  function paintSteps(st) {
    var lis = st.el.querySelectorAll('.vt-step');
    lis.forEach(function (li, i) {
      var skipped = st.skipped[i];
      li.classList.toggle('done', i < st.active && !skipped);
      li.classList.toggle('skip', !!skipped && i < st.active);
      li.classList.toggle('active', i === st.active);
      var d = li.querySelector('.d');
      if (d) d.textContent = (i < st.active && !skipped && st.stepAt[i + 1] && st.stepAt[i]) ? fmtTime(st.stepAt[i + 1] - st.stepAt[i]) : '';
    });
  }
  function advance(st, to) {
    if (!st || to <= st.active) return;
    var now = Date.now();
    for (var i = st.active; i < to; i++) { if (i === 1 && !st.searchSeen) st.skipped[1] = true; st.stepAt[i + 1] = st.stepAt[i + 1] || now; }
    st.active = Math.min(to, 4); paintSteps(st);
  }

  window.appendTypingIndicator = function () {
    var box = $('chatMessages'); if (!box) return '';
    if (VT.cur) stopTimers(VT.cur);
    var id = 'typing_' + Date.now();
    var div = document.createElement('div'); div.id = id; div.className = 'vt-panel';
    div.setAttribute('role', 'status'); div.setAttribute('aria-live', 'polite');
    var prov = tryDo(function () { return PROVIDERS[activeProvider].name; }, 'AI');
    div.innerHTML = '<div class="vt-head"><span class="vt-orb" aria-hidden="true"><i class="r1"></i><i class="r2"></i><i class="core"></i></span>' +
      '<div class="vt-titles"><span class="vt-title" data-thinking-title>Đang suy luận…</span><span class="vt-sub" data-thinking-sub></span></div>' +
      '<div class="vt-meta"><span class="vt-time" data-vt-time>0.0s</span><span class="vt-prov" data-thinking-provider>' + esc(prov) + '</span></div></div>' +
      '<div class="vt-bar" aria-hidden="true"><i></i></div><ol class="vt-steps" aria-label="Trạng thái tác vụ">' +
      STEP_LABELS.map(function (s) { return '<li class="vt-step"><span class="m"></span><span>' + esc(s) + '</span><span class="d"></span></li>'; }).join('') + '</ol>';
    box.appendChild(div);
    var st = VT.cur = { id: id, el: div, t0: Date.now(), active: 0, stepAt: [Date.now()], skipped: {}, searchSeen: false, timers: [], phrases: phraseSet(lastUserText()), pi: 0, firstTokenAt: 0 };
    paintSteps(st); typeTo(st, st.phrases[0]);
    st.timers.push(setInterval(function () {
      if (!document.body.contains(st.el) || !st.el.classList.contains('vt-panel')) { stopTimers(st); return; }
      var el = Date.now() - st.t0, tm = st.el.querySelector('[data-vt-time]'); if (tm) tm.textContent = fmtTime(el);
      if (st.active === 0 && el > 1500) advance(st, st.searchSeen ? 1 : 2);
    }, 200));
    st.timers.push(setInterval(function () { if (!document.body.contains(st.el)) return; st.pi = (st.pi + 1) % st.phrases.length; typeTo(st, st.phrases[st.pi]); }, 3000));
    if (typeof window.scrollToBottom === 'function') window.scrollToBottom();
    VN.requestStart();
    return id;
  };

  window.updateVilaThinkingPanel = function (text, mode) {
    var st = VT.cur; text = String(text || '');
    VN.requestStatus(text);
    if (!st || !document.body.contains(st.el) || !st.el.classList.contains('vt-panel')) return;
    var parts = text.split(/[•·]/).map(function (s) { return s.trim(); }).filter(Boolean);
    var title = parts.filter(function (s) { return /đang|rà soát|tìm|tạo|dựng|build|sửa|đọc/i.test(s); })[0] || parts[0] || 'Đang suy luận';
    var tt = st.el.querySelector('[data-thinking-title]'); if (tt) tt.textContent = title;
    var pv = st.el.querySelector('[data-thinking-provider]'); if (pv) pv.textContent = tryDo(function () { return PROVIDERS[activeProvider].name; }, 'AI');
    var t = text.toLowerCase();
    if (/tìm web|tìm kiếm|search|grounding|tra cứu|đọc nguồn/.test(t)) { st.searchSeen = true; st.phrases = PHRASES.search; st.pi = 0; typeTo(st, st.phrases[0]); advance(st, 1); }
    else if (/tạo ảnh|dựng video|xử lý file|đọc file|giải nén|chạy kiểm tra|đang sửa|tự sửa|build/.test(t)) { if (/ảnh|video/.test(t)) { st.phrases = PHRASES.image; st.pi = 0; typeTo(st, st.phrases[0]); } advance(st, 2); }
    else if (/rà soát|độ chính xác|kiểm tra câu trả lời|đối chiếu/.test(t)) advance(st, 3);
    if (mode === 'ready' && /đã sẵn sàng|hoàn tất|đã tạo|đã tìm kiếm/.test(t)) { advance(st, 4); stopTimers(st); }
  };

  /* Token đầu tiên về = hết "suy nghĩ" (panel bị thay bằng khung stream). */
  var _vsa = window.vilaStreamAppend;
  if (typeof _vsa === 'function') window.vilaStreamAppend = function (chunk) {
    var st = VT.cur;
    if (st && !st.firstTokenAt && chunk) { st.firstTokenAt = Date.now(); advance(st, 3); stopTimers(st); }
    return _vsa.apply(this, arguments);
  };

  function thoughtChip(st) {
    var ms = (st.firstTokenAt || Date.now()) - st.t0; if (ms < 700) return null;
    var show = tryDo(function () { return getSecuritySettings().showReasoningSummary !== false; }, true); if (!show) return null;
    var end = st.firstTokenAt || Date.now(), rows = '';
    for (var i = 0; i < 4; i++) {
      if (st.skipped[i]) continue;
      var a = st.stepAt[i], b = (i < 3 ? (st.stepAt[i + 1] || end) : end); if (!a) continue;
      rows += '<li><span>' + esc(STEP_LABELS[i]) + '</span><b>' + fmtTime(Math.max(0, b - a)) + '</b></li>';
    }
    var d = document.createElement('details'); d.className = 'vt-chip';
    d.innerHTML = '<summary><span class="tick">✓</span>Đã suy nghĩ ' + esc(fmtWords(ms)) + '<span class="car"></span></summary><ol>' + rows + '</ol>';
    return d;
  }

  function finishRequest(kind, text) {
    var st = VT.cur; VT.cur = null;
    if (st) stopTimers(st);
    VN.requestEnd(kind, text);
    return st;
  }
  var _aam = window.appendAiMessage;
  if (typeof _aam === 'function') window.appendAiMessage = function (raw) {
    var st = VT.cur, r = _aam.apply(this, arguments);
    if (st) {
      tryDo(function () {
        var chip = thoughtChip(st), box = $('chatMessages');
        if (chip && box && box.lastElementChild) box.insertBefore(chip, box.lastElementChild);
      });
      finishRequest('answer', raw);
    }
    return r;
  };
  var _aem = window.appendErrorMessage;
  if (typeof _aem === 'function') window.appendErrorMessage = function (msg) {
    var st = VT.cur, r = _aem.apply(this, arguments);
    if (st) finishRequest('error', msg);
    return r;
  };

  /* ====================================================== 3) THÔNG BÁO NGOÀI APP */
  var VN = window.VilaNotify = {
    active: false,
    A: function () { return window.Android || null; },
    enabled: function () { return store('vila_notify_enabled') !== '0'; },
    hasPermission: function () {
      var A = VN.A();
      if (A && typeof A.hasNotificationPermission === 'function') return !!tryDo(function () { return A.hasNotificationPermission(); }, false);
      return 'Notification' in window && Notification.permission === 'granted';
    },
    appVisible: function () {
      var A = VN.A();
      if (A && typeof A.isAppVisible === 'function') return !!tryDo(function () { return A.isAppVisible(); }, true);
      return document.visibilityState !== 'hidden';
    },
    request: function () {
      var A = VN.A();
      return new Promise(function (resolve) {
        if (A && typeof A.requestNotificationPermission === 'function') {
          var done = false, t = setTimeout(function () { if (!done) { done = true; resolve(VN.hasPermission()); } }, 45000);
          VN._resolve = function (ok) { if (done) return; done = true; clearTimeout(t); resolve(!!ok); };
          tryDo(function () { A.requestNotificationPermission(); });
        } else if ('Notification' in window) {
          Notification.requestPermission().then(function (p) { resolve(p === 'granted'); }, function () { resolve(false); });
        } else resolve(false);
      });
    },
    openSystemSettings: function () { var A = VN.A(); if (A && typeof A.openNotificationSettings === 'function') tryDo(function () { A.openNotificationSettings(); }); else toast('Hãy bật thông báo cho trang này trong cài đặt trình duyệt.', 'info'); },
    send: function (title, body) {
      var A = VN.A();
      if (A && typeof A.notifyUser === 'function') return tryDo(function () { A.notifyUser(String(title), String(body)); return true; }, false);
      if ('Notification' in window && Notification.permission === 'granted') return tryDo(function () { new Notification(title, { body: body, icon: 'vila_logo_pro.png' }); return true; }, false);
      return false;
    },
    requestStart: function () {
      VN.active = true;
      var A = VN.A();
      if (A && typeof A.setRequestActive === 'function' && VN.enabled() && VN.hasPermission()) tryDo(function () { A.setRequestActive(true, 'VILA đang suy luận…', tryDo(function () { return pname(activeProvider); }, '')); });
      VN.maybePrompt();
    },
    requestStatus: function (text) {
      var A = VN.A(); if (!VN.active || !A || typeof A.updateRequestStatus !== 'function') return;
      tryDo(function () { A.updateRequestStatus(String(text).replace(/\s+/g, ' ').slice(0, 120)); });
    },
    requestEnd: function (kind, text) {
      var wasActive = VN.active; VN.active = false;
      var A = VN.A();
      if (A && typeof A.setRequestActive === 'function') tryDo(function () { A.setRequestActive(false, '', ''); });
      if (!wasActive || kind === 'silent' || !VN.enabled() || !VN.hasPermission() || VN.appVisible()) return;
      var plain = String(text || '').replace(/```[\s\S]*?```/g, ' [mã] ').replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/[#*_`>|]/g, '').replace(/\s+/g, ' ').trim();
      if (kind === 'error') VN.send('VILA gặp lỗi', plain.slice(0, 140) || 'Yêu cầu không hoàn tất.');
      else VN.send('VILA đã trả lời xong', plain.slice(0, 160) || 'Câu trả lời đã sẵn sàng.');
    },
    maybePrompt: function () {
      if (store('vila_notify_prompted') || VN.hasPermission() || !VN.enabled() || $('vnPrompt')) return;
      store('vila_notify_prompted', '1');
      setTimeout(function () {
        var p = document.createElement('div'); p.id = 'vnPrompt'; p.className = 'vn-prompt'; p.setAttribute('role', 'dialog');
        p.innerHTML = '<h4>Bật thông báo cho VILA?</h4><p>Khi bạn chuyển sang app khác, VILA vẫn báo ngay lúc trả lời xong và giữ yêu cầu đang suy luận chạy tiếp ở nền.</p><div class="vn-actions"><button type="button" class="vn-btn ghost" data-a="later">Để sau</button><button type="button" class="vn-btn" data-a="ok">Bật thông báo</button></div>';
        document.body.appendChild(p);
        p.addEventListener('click', function (e) {
          var a = e.target.getAttribute && e.target.getAttribute('data-a'); if (!a) return;
          p.remove();
          if (a === 'ok') VN.request().then(function (ok) { VN.refreshUI(); toast(ok ? 'Đã bật thông báo.' : 'Chưa cấp quyền thông báo. Bạn có thể bật lại trong Cài đặt.', ok ? 'success' : 'info'); });
        });
      }, 1200);
    },
    refreshUI: function () {
      var dot = $('vnDot'), st = $('vnStatus'), tg = $('vnToggle'); if (!dot) return;
      var has = VN.hasPermission(), en = VN.enabled();
      if (tg) tg.checked = en;
      dot.setAttribute('data-s', has && en ? 'ok' : (has ? 'warn' : 'bad'));
      if (st) st.textContent = has ? (en ? 'Đã cấp quyền · đang bật' : 'Đã cấp quyền · đang tắt trong VILA') : 'Chưa cấp quyền thông báo';
      var g = $('vnGrant'); if (g) g.style.display = has ? 'none' : '';
    },
    mountCard: function () {
      var body = document.querySelector('.vila-settings-body'); if (!body || $('vnCard')) return;
      var anchor = body.querySelector('.vila-route-card');
      var card = document.createElement('div'); card.id = 'vnCard'; card.className = 'vila-field vn-card';
      card.innerHTML = '<label>Thông báo ngoài app</label><div class="vn-row"><span class="vep-dot" id="vnDot"></span><span id="vnStatus">…</span></div>' +
        '<label class="vn-switch"><input type="checkbox" id="vnToggle"><span>Báo khi AI trả lời xong lúc bạn ở app khác</span></label>' +
        '<div class="vn-actions"><button type="button" class="vn-btn" id="vnGrant">Cấp quyền thông báo</button><button type="button" class="vn-btn ghost" id="vnTest">Gửi thông báo thử</button><button type="button" class="vn-btn ghost" id="vnSys">Cài đặt hệ thống</button></div>' +
        '<p class="vila-help">Trên Android 13+ hệ thống sẽ hỏi quyền. Khi bạn rời app giữa lúc AI đang suy luận, VILA hiện thông báo tiến trình và giữ yêu cầu chạy tiếp.</p>';
      if (anchor) anchor.insertAdjacentElement('afterend', card); else body.insertBefore(card, body.firstChild);
      $('vnToggle').addEventListener('change', function (e) { store('vila_notify_enabled', e.target.checked ? '1' : '0'); VN.refreshUI(); });
      $('vnGrant').addEventListener('click', function () { VN.request().then(function (ok) { VN.refreshUI(); if (!ok) toast('Quyền chưa được cấp — mở Cài đặt hệ thống để bật thủ công.', 'info'); }); });
      $('vnSys').addEventListener('click', function () { VN.openSystemSettings(); });
      $('vnTest').addEventListener('click', function () {
        if (!VN.hasPermission()) { toast('Hãy cấp quyền thông báo trước.', 'info'); return; }
        var ok = VN.send('VILA', 'Thông báo hoạt động tốt ✓ — bạn sẽ nhận tin khi AI trả lời xong.');
        toast(ok ? 'Đã gửi thông báo thử (kéo thanh trạng thái xuống để xem).' : 'Không gửi được thông báo.', ok ? 'success' : 'error');
      });
      VN.refreshUI();
    }
  };
  /* Java gọi lại sau khi người dùng trả lời hộp thoại quyền của hệ thống. */
  window.onVilaNotificationPermission = function (granted) { if (VN._resolve) VN._resolve(!!granted); VN.refreshUI(); };
  /* Dự phòng: nếu yêu cầu kết thúc mà không qua appendAiMessage (ví dụ dừng giữa chừng). */
  setInterval(function () { try { if (VN.active && typeof isProcessing !== 'undefined' && !isProcessing && !VT.cur) VN.requestEnd('silent'); } catch (_) {} }, 4000);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') VN.refreshUI(); });

  /* ============================================================ KHỞI ĐỘNG */
  function boot() { mountDoctor(); VN.mountCard(); paintProviderDots(); }
  /* Mỗi lần mở Cài đặt: làm tươi trạng thái. */
  var _osm = window.openSettingsModal;
  if (typeof _osm === 'function') window.openSettingsModal = function () { var r = _osm.apply(this, arguments); tryDo(function () { boot(); renderLive(); VN.refreshUI(); paintProviderDots(); }); return r; };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true }); else boot();
})();
