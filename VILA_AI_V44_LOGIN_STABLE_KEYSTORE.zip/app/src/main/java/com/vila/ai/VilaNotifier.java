package com.vila.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Notification helpers for VILA: channels, permission check, "thinking" progress and "answer ready" alerts. */
final class VilaNotifier {
    static final String CH_REPLY = "vila_replies";
    static final String CH_PROGRESS = "vila_progress";
    static final int ID_PROGRESS = 4101;
    static final int ID_DONE = 4102;
    private static final String POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS";

    private VilaNotifier() {}

    static NotificationManager manager(Context c) {
        return (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = manager(c);
        if (nm == null) return;
        NotificationChannel reply = new NotificationChannel(CH_REPLY, "VILA trả lời xong", NotificationManager.IMPORTANCE_HIGH);
        reply.setDescription("Thông báo khi AI trả lời xong lúc bạn đang ở app khác");
        nm.createNotificationChannel(reply);
        NotificationChannel progress = new NotificationChannel(CH_PROGRESS, "VILA đang suy luận", NotificationManager.IMPORTANCE_LOW);
        progress.setDescription("Hiện tiến trình khi VILA đang xử lý yêu cầu ở nền");
        progress.setShowBadge(false);
        nm.createNotificationChannel(progress);
    }

    /** True only when the runtime permission (Android 13+) is granted AND notifications are not switched off in system settings. */
    static boolean canNotify(Context c) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
        NotificationManager nm = manager(c);
        return nm != null && nm.areNotificationsEnabled();
    }

    static PendingIntent openAppIntent(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(c, 0, i, flags);
    }

    @SuppressWarnings("deprecation")
    private static Notification.Builder builder(Context c, String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, channel) : new Notification.Builder(c);
    }

    /** Ongoing, silent notification shown while a request keeps running in the background. */
    @SuppressWarnings("deprecation")
    static Notification progress(Context c, String title, String text) {
        ensureChannels(c);
        Notification.Builder b = builder(c, CH_PROGRESS)
                .setSmallIcon(R.drawable.ic_stat_vila)
                .setContentTitle(title == null || title.isEmpty() ? "VILA đang suy luận…" : title)
                .setContentText(text == null || text.isEmpty() ? "Đang xử lý yêu cầu của bạn" : text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(true)
                .setProgress(0, 0, true)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .setColor(0xFF22D3EE)
                .setContentIntent(openAppIntent(c));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    /** Heads-up notification: the answer is ready (or the request failed). Tapping it reopens VILA. */
    @SuppressWarnings("deprecation")
    static void postDone(Context c, String title, String body) {
        if (!canNotify(c)) return;
        ensureChannels(c);
        String t = title == null || title.isEmpty() ? "VILA" : title;
        String x = body == null ? "" : body;
        Notification.Builder b = builder(c, CH_REPLY)
                .setSmallIcon(R.drawable.ic_stat_vila)
                .setContentTitle(t)
                .setContentText(x)
                .setStyle(new Notification.BigTextStyle().bigText(x))
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setColor(0xFF22D3EE)
                .setContentIntent(openAppIntent(c));
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
            b.setDefaults(Notification.DEFAULT_ALL);
        }
        NotificationManager nm = manager(c);
        if (nm != null) nm.notify(ID_DONE, b.build());
    }

    static void cancelProgress(Context c) {
        NotificationManager nm = manager(c);
        if (nm != null) nm.cancel(ID_PROGRESS);
    }

    static void cancelDone(Context c) {
        NotificationManager nm = manager(c);
        if (nm != null) nm.cancel(ID_DONE);
    }
}
