package com.vila.ai;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * Foreground service that keeps VILA's process alive (and shows a "thinking" notification)
 * while an AI request is still running and the user has switched to another app.
 * It does no work itself; MainActivity starts it in onPause() only when a request is active
 * and stops it as soon as the request finishes or the app returns to the foreground.
 */
public class VilaKeepAliveService extends Service {
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent == null ? null : intent.getStringExtra("title");
        String text = intent == null ? null : intent.getStringExtra("text");
        Notification n = VilaNotifier.progress(this, title, text);
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(VilaNotifier.ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(VilaNotifier.ID_PROGRESS, n);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        try { stopForeground(Service.STOP_FOREGROUND_REMOVE); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
