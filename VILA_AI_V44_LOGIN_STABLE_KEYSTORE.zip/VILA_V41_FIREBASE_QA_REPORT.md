# VILA AI Studio V41 — Firebase Authentication QA

## Source checks

- PASS `scripts/test-firebase-v41.js`: Firebase Android Auth dependencies, native Google Credential Manager path, email/password register/login, password reset, sign-out, configuration fields, GitHub Actions secret mapping, and setup documentation.
- PASS `scripts/smoke-test-v32.js`: inherited app behavior and source regression checks.
- PASS `scripts/test-key-persistence-v37.js`: API-key local preference behavior.
- PASS `scripts/test-endpoints-v38.js`: 24 endpoint tests.
- PASS `scripts/test-openrouter-public-free-v39.js`: model catalog and free-model filtering tests.
- PASS JavaScript syntax checks for all external asset JS files and all 7 inline script blocks in `index.html`.
- PASS HTML ID uniqueness: 147 IDs, no duplicates.
- PASS AndroidManifest XML parse.
- PASS root `main.yml` matches `.github/workflows/main.yml`.
- PASS Firebase config template contains JSON-compatible keys/value structure usable by the native config parser.

## Not verified here

- A full Android Gradle build was not run in this environment because Android SDK and a Gradle installation are not available locally. The project workflow runs Gradle verification/build on GitHub Actions.
- No user's Firebase project configuration or OAuth Web Client ID was supplied, so real network authentication was not tested.
- Google sign-in requires Firebase Email/Password and Google providers enabled as applicable, Android package `com.vila.ai` registered in Firebase, the SHA-1 of the APK's signing certificate, and `FIREBASE_WEB_CLIENT_ID` configured.
- The source ZIP intentionally contains blank Firebase client configuration values. Do not use a service-account JSON or Firebase Admin key in the APK.

## Version details

- App version: `41.0.0`
- Android `versionCode`: `47`
- V40 plain SharedPreferences API-key storage behavior is preserved; Firebase Auth does not change that separate storage decision.
