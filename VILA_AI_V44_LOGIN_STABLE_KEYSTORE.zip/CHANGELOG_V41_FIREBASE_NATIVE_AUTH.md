# VILA AI Studio V41 — Firebase Native Authentication

- Added Firebase Android Auth and Android Credential Manager dependencies.
- Added native Firebase email/password registration and sign-in, password reset, Google ID-token sign-in, sign-out, and persisted auth-state bridge.
- Switched Android Google sign-in from WebView redirect to native Credential Manager, avoiding Google OAuth's embedded-WebView restrictions.
- Kept Firebase Web SDK as a browser-preview/email fallback when native Android config is incomplete.
- Added `androidAppId` and `webClientId` to the Firebase client config schema.
- Added GitHub Actions secret support for `FIREBASE_ANDROID_APP_ID` and `FIREBASE_WEB_CLIENT_ID`.
- Added setup instructions, including package name, OAuth Web client ID, and signing-certificate SHA-1 requirements.
- Preserved V40 API key storage behavior (plain local preferences; no Android Keystore for API-key storage).

Real Firebase sign-in requires project-specific configuration. Source-only tests do not establish that the user's Firebase project or Google OAuth settings are configured correctly.
