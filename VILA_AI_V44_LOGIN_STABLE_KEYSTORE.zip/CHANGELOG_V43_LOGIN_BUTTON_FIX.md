# V43 — Login UI and action feedback

- Simplified the auth gate to a clean login screen and removed the small explanatory paragraphs.
- Validates full email addresses and uses Firebase's minimum password length rule for account creation (at least six characters, not six digits). Existing-password login submits the user's password as entered.
- Native Firebase callbacks reveal an error only when a request fails and restore the controls. Google account selection remains native and can stay open while the user chooses an account.
- Source checks were run locally; a live Firebase login and Android build still need confirmation in GitHub Actions and on a device.
