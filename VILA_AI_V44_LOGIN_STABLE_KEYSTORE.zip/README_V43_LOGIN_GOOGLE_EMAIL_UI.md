# VILA AI V43 — Login, Google account picker, and passwords

The login overlay now displays a compact “Đăng nhập” view, with Email and Mật khẩu fields, a primary login action, a Google action, and secondary create-account/reset-password actions. The small explanatory paragraphs are removed. Status messages show only when an action needs to report progress or an error.

Google sign-in on Android uses the native Android Credential Manager and Firebase Authentication. `GetGoogleIdOption` uses `setFilterByAuthorizedAccounts(false)`, which allows Google accounts available on the device to be offered in the system account picker. The app must still have valid Firebase/OAuth config and the SHA-1 of the APK's signing certificate must be registered under the `com.vila.ai` Android app in Firebase Console. A successful source test is not proof of a live sign-in.

Email addresses are validated before native Firebase calls. Existing-account login accepts the password exactly as entered. New passwords may contain letters, numbers, and symbols; they do not need to be six digits. Firebase's default Email/Password policy requires new passwords to contain at least six characters.

## Build

Upload the contents of this ZIP to the root of the GitHub repository. The canonical workflow is `.github/workflows/main.yml`. Open Actions → **VILA AI - Android Build and Verify** → **Run workflow** and download `VILA-AI-Build-Files-*`. This project package is source code, not an APK. Confirm the Gradle build succeeds before installing the artifact.

After a build, use `sha1-fingerprint.txt` from that same workflow run to verify the certificate fingerprint. For a debug APK, the runner-generated fingerprint may change from one workflow run to the next. For persistent Google sign-in, configure a persistent release keystore in GitHub Actions and register its SHA-1 in Firebase Console. Also make sure Firebase Authentication has Google and Email/Password enabled.
