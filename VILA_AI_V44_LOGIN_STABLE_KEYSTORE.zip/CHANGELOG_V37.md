# V37 changes
- Fixed API key persistence: empty input now preserves the stored key; deletion requires an explicit button.
- Added masked saved-key status without exposing the secret in the input field.
- Added post-save read-back verification for Gemini and other providers through Android Keystore.
- Kept all five provider keys independent while retaining one shared API-key field in one settings screen.
- Added cyan/blue visual overrides, clear focus states, and compact mobile settings.
- Fixed a duplicate welcome-state element ID.
- Synchronized root `main.yml` with the active GitHub Actions workflow so it no longer references a missing test script.
- Bumped Android version to 37.0.0 (versionCode 43).
- Added runtime-mocked key-persistence tests and wired them into CI.
