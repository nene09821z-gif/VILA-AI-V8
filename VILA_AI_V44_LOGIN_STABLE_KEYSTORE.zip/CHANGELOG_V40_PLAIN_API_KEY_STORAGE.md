# VILA AI Studio V40 — Legacy API-key storage

- Removed Android Keystore/AES-GCM dependencies from `MainActivity`.
- Provider API keys, Gemini API key, and GitHub token now use app-private `SharedPreferences` as plain strings, restoring legacy-style persistence.
- Existing JavaScript bridge method names remain unchanged to preserve the UI and provider integrations.
- Clear-key actions remove both new plain preferences and known old encrypted preference entries.
- Security trade-off: plain local storage is less resistant to extraction on a compromised/rooted device. Do not share the APK or device with untrusted users.
- This source update does not include a live-provider test or a verified Android build; run GitHub Actions/build before release.
