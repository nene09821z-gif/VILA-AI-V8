# VILA AI V43 — Đăng nhập Google và Email

## Luồng đăng nhập

- Trên Android, bấm **Tiếp tục với Google** sẽ gọi Android Credential Manager (`GetGoogleIdOption` với `setFilterByAuthorizedAccounts(false)`) để hệ thống đưa ra các tài khoản Google có thể chọn trên thiết bị. Chọn tài khoản xong, Firebase Auth mới xác nhận phiên đăng nhập.
- Màn hình được rút gọn còn tiêu đề Đăng nhập, Email, Mật khẩu, Đăng nhập, Google, Tạo tài khoản và Quên mật khẩu. Chữ hướng dẫn nhỏ đã được bỏ; thông báo chỉ xuất hiện khi cần báo trạng thái/lỗi.
- Email phải là địa chỉ đầy đủ hợp lệ. Mật khẩu đăng nhập tài khoản đã có được gửi nguyên trạng. Mật khẩu mới có thể dùng chữ, số và ký hiệu, không bắt buộc là 6 chữ số; chính sách Email/Password mặc định của Firebase yêu cầu tối thiểu 6 ký tự.

## Điều kiện Firebase bắt buộc

1. Firebase Console → Authentication → Sign-in method: bật **Google** và **Email/Password**.
2. Project settings → ứng dụng Android `com.vila.ai`: đăng ký SHA-1 của chứng thư ký đúng APK đang cài.
3. Dùng OAuth client loại **Web application** làm `webClientId`; workflow điền giá trị từ `client_type=3` trong `app/google-services.json`.
4. Build lại trên GitHub Actions, tải APK và `sha1-fingerprint.txt` từ cùng lần chạy. Nếu đang dùng debug build, khóa ký debug trên runner có thể thay đổi giữa các lần chạy; release keystore cố định phù hợp hơn cho đăng nhập lâu dài.

`Firebase đã sẵn sàng` chỉ có nghĩa Firebase Android khởi tạo được, không bảo đảm cấu hình OAuth và SHA-1 đã đúng.

## Kiểm thử và giới hạn

Các kiểm tra nguồn JavaScript/backend, JSON, XML và YAML đã chạy qua trong môi trường đóng gói. Môi trường này không có Android SDK/Gradle nên chưa thể tuyên bố APK mới build thành công hoặc xác nhận đăng nhập Google thực tế trên điện thoại. Cần xác nhận workflow GitHub Actions và thử trên thiết bị.
