# VILA AI STUDIO V42 — Hướng dẫn sử dụng và triển khai

## Có gì trong V42

Giữ nguyên ứng dụng V41 và thêm trung tâm **AI Gateway**: danh sách provider/model, quét nhanh catalog, quét sâu bằng yêu cầu chat thử, cài đặt URL backend, kiểm tra sức khỏe server, chẩn đoán engine, catalog model server, thống kê lượt gọi, cập nhật phiên bản, bật/tắt định tuyến trung tâm. Các tính năng chat/tệp/workspace/xuất ZIP và tích hợp provider trực tiếp đã có trước đó vẫn nằm trong project.

### Các chế độ hoạt động

- **Provider trực tiếp trên thiết bị:** nhập key trong phần Cài đặt API đang có. Không cần backend riêng, nhưng key phải được bảo vệ và không nên chia sẻ thiết bị.
- **Gateway server:** app gửi Firebase ID token đến backend. Backend xác minh token và gọi provider bằng key quản trị được nạp từ biến môi trường. Cần triển khai server trước khi bật chế độ này.

## 1. Chuẩn bị Firebase

Project giữ `app/google-services.json` từ cấu hình Android client gửi kèm và điền các giá trị Android tương ứng vào `app/src/main/assets/firebase-config.js`, cho Firebase project `vila-studio`, package `com.vila.ai`. Hiện build không phụ thuộc Gradle Google Services plugin; file JS config và FirebaseOptions trong MainActivity được app sử dụng.

Trong Firebase Console, mở **Authentication → Sign-in method**, bật Email/Password và Google nếu cần Google login. Kiểm tra Android app đăng ký đúng package `com.vila.ai`. Với Google login, thêm SHA-1 của chứng thư dùng ký APK trong Firebase Project Settings rồi lấy **OAuth 2.0 Client ID loại Web application** và cung cấp qua `FIREBASE_WEB_CLIENT_ID` khi build hoặc trường `webClientId` trong `app/src/main/assets/firebase-config.js`. Tệp `google-services.json` bạn vừa gửi đã có OAuth client loại Web application và workflow tự điền `webClientId`. Browser preview còn cần Firebase Web App `appId` (`FIREBASE_APP_ID`), giá trị riêng không có trong cấu hình Android.

Không bao giờ đặt Firebase Admin service account, provider secret hoặc private key vào asset/ZIP. Firebase client API key ở ứng dụng không phải service-account secret, nhưng nên giới hạn theo API và cấu hình Firebase Security Rules.

## 2. Chạy test backend

Cài Node.js 20+; trong `server/` chạy:

```sh
cp .env.example .env
npm install
npm test
npm start
```

`.env.example` dùng `AUTH_MODE=off` cho localhost/dev testing. Không public server ở chế độ đó. Mọi yêu cầu chat thật còn cần ít nhất một khóa provider hợp lệ và model được provider cho tài khoản truy cập.

## 3. Triển khai backend dùng thật

Xem đầy đủ ở `server/README.md`. Tối thiểu production phải có HTTPS, `NODE_ENV=production`, `AUTH_MODE=firebase`, `FIREBASE_PROJECT_ID=vila-studio`, Firebase Admin credentials qua Application Default Credentials hoặc secret manager, `CORS_ORIGINS` giới hạn theo origin cần dùng (Android WebView có thể gửi origin `null`, chỉ cho phép giá trị đó nếu app native của bạn thật sự cần), rate limits và provider API keys trong secret environment. Production sẽ từ chối `AUTH_MODE=off`.

Sau khi deploy, copy HTTPS base URL vào **AI Gateway → Kết nối backend trung tâm**, bấm **Lưu URL → Kiểm tra server → Chẩn đoán engine → Quét model server**. Chỉ bật **Định tuyến chat qua Gateway máy chủ** sau khi Firebase login, auth server, health và ít nhất một provider được kiểm tra thành công.

## 4. Agent Server tùy chọn giữ từ V41

VILA vẫn có ô **VILA Agent Server** riêng cho proxy chat dài và luồng build–sửa lỗi trên workspace. Đây không phải Gateway server; hãy chạy riêng bằng `PORT=8788 npm run start:agent` trong thư mục `server/`, sau đó nhập URL/`VILA_SERVER_TOKEN` ở cấu hình Agent Server trong app. `GEMINI_API_KEY` dùng chung, còn `AGENT_GEMINI_BASE_URL` và `AGENT_GEMINI_MODEL` tách biệt.

API build server bị khóa mặc định (`ALLOW_UNTRUSTED_BUILDS=false`). Bật nó có thể chạy Gradle/build script do người gửi ZIP cung cấp; chỉ bật trong build worker/container cách ly, không mount production secrets vào môi trường build và không public server không kiểm soát.

## 5. Kiểm tra cập nhật

Gateway server có endpoint `GET /v1/app/version`. Cấu hình `VILA_APP_LATEST_VERSION` và `VILA_APP_RELEASE_URL` trong môi trường backend để cung cấp bản mới và trang tải. APK được cài thông qua trình cài đặt Android với xác nhận của người dùng; không tuyên bố hay cố gắng cài âm thầm. Nếu chưa cấu hình release URL, app chỉ báo trạng thái/phiên bản.

## 6. Build APK trên GitHub

Đưa toàn bộ project lên GitHub, chạy workflow **VILA AI - Android Build and Verify** trong tab **Actions** và tải artifact debug APK. Workflow cũng chạy kiểm tra JS/backend. Release APK phải ký bằng một keystore ổn định; cần thiết lập GitHub secrets theo `FIREBASE_SETUP_V41.txt`. Không có bằng chứng build thực tế cho đến khi workflow hoàn tất màu xanh.

## 7. Giới hạn được công khai

- Không có một “AI engine” duy nhất tự tạo quyền truy cập vào Gemini/ChatGPT hay model trả phí; từng provider vẫn yêu cầu API key/quyền riêng. Router chỉ chọn trong các cổng đã cấu hình.
- Quét sâu gửi yêu cầu thật và có thể tiêu thụ quota. Retry/fallback có giới hạn; lỗi xác thực không bị lặp vô hạn.
- Bảng thống kê backend hiện lưu trong bộ nhớ tiến trình, reset khi restart và không phải hóa đơn dùng thật. Muốn bán quota cần thêm DB, bộ giới hạn dùng chung và đồng bộ giá.
- Chẩn đoán phát hiện vấn đề và đưa lỗi dễ hiểu, không tự thay đổi khóa, tự sửa mọi lỗi từ bên thứ ba, hoặc chạy code tùy ý có thể phá dữ liệu.
- V42 chưa phải bằng chứng rằng tất cả provider, mọi model, email/Google sign-in và build APK đã được live-tested. Hãy dùng test report và GitHub Actions để xác nhận trên môi trường thật.
