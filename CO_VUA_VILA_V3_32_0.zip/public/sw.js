/* Cờ Vua ViLa service worker (v3.32.0): lets the app shell, engines and openings work without a network. */
const VERSION = 'covua-vila-v3.32.0';
const CORE_CACHE = `${VERSION}-core`;
const RUNTIME_CACHE = `${VERSION}-runtime`;
const scopeUrl = path => new URL(path, self.registration.scope).href;

// Core shell + engine files. Each is cached independently so one missing optional file
// (for example Stockfish 10 or the 94 MB Full build) can never abort installation.
const PIECE_SETS = ['fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx'];
const PIECE_CODES = ['K', 'Q', 'R', 'B', 'N', 'P'];
const LICENSED_PIECE_FILES = PIECE_SETS.flatMap(set => ['w', 'b'].flatMap(color => PIECE_CODES.map(piece => `./piece-sets/${set}/${color}${piece}.svg`)));

const CORE_FILES = [
  './', './index.html', './favicon.ico?v=331', './favicon.png?v=331', './covua-vila-icon.png', './covua-vila-logo.webp', './favicon-48.png?v=331', './openings-eco.json',
  './engine/engine-manifest.json',
  './engine/stockfish-19-lite-single.js', './engine/stockfish-19-lite-single.wasm',
  './engine/stockfish-19-asm.js', './engine/stockfish-10.js',
  './pieces/w_p.png', './pieces/b_p.png', './pieces/w_n.png', './pieces/b_n.png',
  './pieces/w_b.png', './pieces/b_b.png', './pieces/w_r.png', './pieces/b_r.png',
  './pieces/w_q.png', './pieces/b_q.png', './pieces/w_k.png', './pieces/b_k.png',
  ...LICENSED_PIECE_FILES, './piece-sets/CREDITS.md'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CORE_CACHE);
    await Promise.allSettled(CORE_FILES.map(async file => {
      const response = await fetch(scopeUrl(file), { cache: 'reload' });
      if (response.ok) await cache.put(scopeUrl(file), response);
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keep = new Set([CORE_CACHE, RUNTIME_CACHE]);
    for (const key of await caches.keys()) if ((key.startsWith('vila-chess-') || key.startsWith('covua-vila-')) && !keep.has(key)) await caches.delete(key);
    await self.clients.claim();
  })());
});

async function networkFirst(request, fallbackKey) {
  try {
    const response = await fetch(request);
    if (response.ok) (await caches.open(RUNTIME_CACHE)).put(request, response.clone());
    return response;
  } catch (error) {
    return (await caches.match(request)) || (fallbackKey && await caches.match(scopeUrl(fallbackKey))) || Response.error();
  }
}

async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok) (await caches.open(RUNTIME_CACHE)).put(request, response.clone());
  return response;
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;          // never touch AI / social / CDN calls
  if (url.pathname.includes('/api/')) return;               // live server APIs stay network-only
  if (url.pathname.endsWith('/sw.js')) return;
  if (request.mode === 'navigate') { event.respondWith(networkFirst(request, './index.html')); return; }
  if (/\/(engine|pieces|piece-sets|assets)\//.test(url.pathname) || /\.(?:wasm|png|webp|ico|svg|woff2?)$/.test(url.pathname)) {
    event.respondWith(cacheFirst(request)); return;
  }
  event.respondWith(networkFirst(request));
});
