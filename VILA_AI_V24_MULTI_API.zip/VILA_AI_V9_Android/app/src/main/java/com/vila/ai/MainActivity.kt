package com.vila.ai

import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebView

/**
 * Thin Kotlin entry point.
 * The original V23 Android bridge/file/voice/GitHub implementation lives in
 * MainActivityLegacy so the existing UI does not lose native features.
 */
class MainActivity : MainActivityLegacy() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Deprecated("Android back handling is kept compatible with the V23 WebView.")
    override fun onBackPressed() {
        val w: WebView? = try {
            findViewById(android.R.id.content).findFocus() as? WebView
        } catch (_: Exception) {
            null
        }
        if (w != null && w.canGoBack()) {
            w.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
