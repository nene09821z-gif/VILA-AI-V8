import test from 'node:test';
import assert from 'node:assert/strict';
import { versionAtLeast } from './version-helper.js';

test('versionAtLeast compares numeric semver parts, not strings', () => {
  assert.equal(versionAtLeast('3.24.2', '3.24.0'), true);
  assert.equal(versionAtLeast('3.24.0', '3.24.0'), true);
  assert.equal(versionAtLeast('3.100.0', '3.24.0'), true);
  assert.equal(versionAtLeast('4.0.0', '3.24.9'), true);
  assert.equal(versionAtLeast('3.23.9', '3.24.0'), false);
  assert.equal(versionAtLeast('3.9.5', '3.24.0'), false);
});
