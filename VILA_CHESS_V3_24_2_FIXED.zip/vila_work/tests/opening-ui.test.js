import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { versionAtLeast } from './version-helper.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const prepare = fs.readFileSync(new URL('../scripts/prepare-openings.mjs', import.meta.url), 'utf8');
const workflow = fs.readFileSync(new URL('../.github/workflows/build-from-zip.yml', import.meta.url), 'utf8');

test('expanded Lichess ECO catalog is merged after startup and is bounded/deduplicated', () => {
  assert.match(main, /async function loadExternalOpeningCatalog\(\)/);
  assert.match(main, /mergeOpeningEntries\(OPENINGS, entries, 5000\)/);
  assert.match(main, /OPENINGS\.push\(\.\.\.additions\)/);
  assert.match(main, /id=\"playOpeningCount\"/);
  assert.match(main, /playCount\.textContent = OPENINGS\.length\.toLocaleString\(\)/);
  assert.match(main, /void loadExternalOpeningCatalog\(\)/);
  assert.match(prepare, /lichess-org\/chess-openings/);
  assert.match(prepare, /CC0-1\.0/);
  assert.match(prepare, /openings\.length < requiredCount/);
});

test('opening browser paginates large catalogs and can replay a selected line', () => {
  assert.match(main, /function renderOpeningCards\(filter = '', family = 'all', limit = openingPageLimit\)/);
  assert.match(main, /filtered\.slice\(0, Math\.max\(1, Number\(limit\) \|\| 48\)\)/);
  assert.match(main, /id="loadMoreOpenings"/);
  assert.match(main, /data-load-opening="\$\{OPENINGS\.indexOf\(o\)\}"/);
  assert.match(main, /function loadOpening\(index\)/);
});

test('play room contains board, clocks, move context, engine analysis, and compact mobile layout', () => {
  for (const value of ['play-room-heading', 'opponent-line', 'clock-face-row', 'boardArrows', 'analysisPanel', 'move-list', 'game-setup']) {
    assert.ok(main.includes(value), `Missing play-room element ${value}`);
  }
  assert.match(css, /#ebecd0/);
  assert.match(css, /#779952/);
  assert.match(css, /@media\(max-width:680px\)/);
  assert.match(css, /play-screen-active \.play-layout\{grid-template-columns:1fr/);
});

test('v3.15 version and GitHub ZIP build checks include catalog refresh', () => {
  assert.ok(versionAtLeast(pkg.version, '3.24.0'), `package version ${pkg.version} must be at least 3.24.0`);
  assert.match(pkg.scripts.prebuild, /prepare-openings\.mjs/);
  assert.match(workflow, /node --check src\/opening-catalog\.js/);
  assert.match(workflow, /node --check scripts\/prepare-openings\.mjs/);
  assert.match(workflow, /npm run build/);
});
