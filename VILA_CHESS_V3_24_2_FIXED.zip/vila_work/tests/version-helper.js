// Shared helper: version assertions should say "at least X", not "exactly X", so that
// every release does not require editing five unrelated test files.
export function versionAtLeast(actual, minimum) {
  const parse = value => String(value).split('.').map(part => Number.parseInt(part, 10) || 0);
  const a = parse(actual);
  const b = parse(minimum);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const diff = (a[i] || 0) - (b[i] || 0);
    if (diff !== 0) return diff > 0;
  }
  return true;
}
