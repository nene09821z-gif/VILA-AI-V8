import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import { chooseAlternateMove, OFFLINE_ENGINE_IDS } from '../src/alternate-engine-core.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('every AI request in main.js sends a model that is actually in scope (modelOverride regression)', () => {
  const main = read('src/main.js');
  // modelOverride only exists as a parameter of requestCoach(); using it anywhere else throws a ReferenceError
  // (it broke "play vs AI via API" and the "Kiểm tra kết nối AI" button in v3.24.0/3.24.1).
  const uses = [...main.matchAll(/model:\s*modelOverride/g)];
  assert.equal(uses.length, 1, 'modelOverride may only be used by the coach request that declares it');
  const at = uses[0].index;
  assert.match(main.slice(Math.max(0, at - 400), at), /modelOverride = settings\.model/);
  // The two plain requests must use the configured model.
  assert.match(main, /apiKey: settings\.apiKey, model: settings\.model,\n\s+temperature: 0, maxTokens: retry \? 180 : 96/);
  assert.match(main, /apiKey: settings\.apiKey, model: settings\.model, messages: \[\{ role: 'user', content: 'Trả lời đúng một từ: OK' \}\]/);
});

test('health endpoint reports the real package version instead of a hard-coded one', () => {
  const server = read('server/index.js');
  assert.doesNotMatch(server, /version:\s*'3\.\d+\.\d+'/);
  assert.match(server, /version: APP_VERSION/);
  assert.match(server, /readFileSync\(path\.join\(root, 'package\.json'\)/);
});

test('quiescence keeps the full draw check so stand-pat cut-offs cannot hide a stalemate', () => {
  const core = read('src/engines/search-core.js');
  const quiescence = core.slice(core.indexOf('function quiescence'), core.indexOf('function negamax'));
  assert.match(quiescence, /chess\.isDraw\(\)/);
  assert.doesNotMatch(quiescence, /isDrawFast/);
});

const PUZZLES = [
  { name: 'back-rank mate in one', fen: '6k1/5ppp/8/8/8/8/8/R3K3 w Q - 0 1', best: ['a1a8'] },
  { name: 'wins the hanging queen', fen: 'rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3', best: ['f3h4'] },
  { name: 'captures the undefended rook', fen: '4k3/8/8/3r4/8/8/3R4/4K3 w - - 0 1', best: ['d2d5'] },
  { name: 'returns a legal move in a promotion race', fen: '8/P6k/8/8/8/8/8/K7 w - - 0 1' },
  { name: 'does not stalemate with an extra queen', fen: '7k/5Q2/6K1/8/8/8/8/8 w - - 0 1', avoidStalemate: true }
];

test('all offline engines solve basic tactics and never stalemate a won ending', () => {
  for (const engine of [...OFFLINE_ENGINE_IDS, 'classic']) {
    for (const puzzle of PUZZLES) {
      const uci = chooseAlternateMove(puzzle.fen, { profile: engine, maxTimeMs: 400, random: () => 0 });
      const chess = new Chess(puzzle.fen);
      const legal = chess.moves({ verbose: true }).find(m => `${m.from}${m.to}${m.promotion || ''}` === uci);
      assert.ok(legal, `${engine}: illegal or missing move "${uci}" for ${puzzle.name}`);
      if (puzzle.best) assert.ok(puzzle.best.includes(uci), `${engine}: expected ${puzzle.best.join('/')} for ${puzzle.name}, got ${uci}`);
      if (puzzle.avoidStalemate) {
        chess.move(legal.san);
        assert.equal(chess.isStalemate(), false, `${engine} stalemated a won position with ${uci}`);
      }
    }
  }
});
