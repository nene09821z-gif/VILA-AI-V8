# Test report — v3.24.2

Environment: Node 22, sandbox without access to the npm registry.

| Check | Result |
|---|---|
| `node --check` on every `src/ server/ scripts/ tests/` file | pass |
| Relative-import resolution across the project | pass (no missing files) |
| ESLint `no-undef` etc. on `src/ server/ scripts/` | 2 real errors found and fixed (`modelOverride` x2) + 1 no-op self-assign |
| `npm test` (full) | see below |
| Headless Chromium smoke test: all 17 views render, no `pageerror` | pass |
| Headless Chromium: human vs offline engine (1.e4 e5) | pass |
| Headless Chromium: *Kiểm tra kết nối AI* + play vs AI API against a local mock | fails on v3.24.1 (`modelOverride is not defined`), passes on v3.24.2 |

## Caveats — what was NOT verified here
- `chess.js` 1.4.0 was built from its GitHub source with a stub PGN parser, and `express` was replaced by a ~100-line local shim, both only to run tests in the sandbox (neither is shipped in this package). Run `npm install && npm test` in CI to confirm with the real packages.
- `stockfish` (npm) could not be installed: the Stockfish Lite/ASM engine, `npm run build` (Vite) and the Android/Gradle APK build were not run. In the browser test Stockfish was therefore reported as unavailable, as expected.
- No `package-lock.json` is shipped (it cannot be generated offline), so CI installs floating `^` versions of `express` and `vite`.
