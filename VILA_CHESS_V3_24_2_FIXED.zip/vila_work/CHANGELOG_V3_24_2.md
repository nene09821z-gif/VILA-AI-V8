# VILA Chess v3.24.2 — Bug-fix release

## Fixed
- **`src/main.js`: `ReferenceError: modelOverride is not defined`** in two places that were copied from the Coach request:
  - *Play vs AI via API*: every AI move request threw before leaving the browser, so the game silently fell back to Stockfish / a legal-move fallback and showed "AI API lỗi: modelOverride is not defined".
  - *Settings → Kiểm tra kết nối AI* always failed with the same message.
  Both now send `settings.model`. Reproduced on the original v3.24.1 build in headless Chromium against a local OpenAI-compatible mock, and verified fixed.
- `server/provider-endpoints.js`: removed a no-op self-assignment (`base = base`) in `anthropicModelsUrl`.
- `server/index.js`: `/api/health` reported a hard-coded `3.18.0`; it now reads `package.json`.
- `index.html`: removed the stale `v3.18` from the page title.

## Improved
- `src/engines/search-core.js`: `negamax` no longer calls `chess.isDraw()` (which regenerates every legal move through `isStalemate()`); it checks the 50-move rule, insufficient material and repetition directly and still scores stalemate from the move list. `quiescence` keeps the full check because stand-pat cut-offs return before moves are generated.
- Tests: the five `assert.equal(pkg.version, '3.24.0')` pins became `versionAtLeast(...)` (`tests/version-helper.js`) so a release no longer breaks unrelated test files.

## Added tests
- `tests/v3-24-2-fixes.test.js`: guards the `modelOverride` scope, the health version, the quiescence draw check, and runs all 12 offline engines + VILA Classic through mate-in-one, free-rook, hanging-queen and "do not stalemate a won ending" positions.
- `tests/version-helper.test.js`.
