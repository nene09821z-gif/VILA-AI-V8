import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const required = process.env.REQUIRE_STOCKFISH === '1' || process.argv.includes('--required');
const packageRoot = path.join(root, 'node_modules', 'stockfish');
const destination = path.join(root, 'public', 'engine');
const engineFiles = [
  'stockfish-19-lite-single.js',
  'stockfish-19-lite-single.wasm',
  'stockfish-19-single.js',
  'stockfish-19-single.wasm'
];
function findFile(dir, file, depth = 0) {
  if (!fs.existsSync(dir) || depth > 6) return null;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
  for (const entry of entries) {
    if (entry.isFile() && entry.name === file) return path.join(dir, entry.name);
  }
  for (const entry of entries) {
    if (entry.isDirectory() && !entry.name.startsWith('.')) {
      const found = findFile(path.join(dir, entry.name), file, depth + 1);
      if (found) return found;
    }
  }
  return null;
}

fs.mkdirSync(destination, { recursive: true });
// `public/engine` is dedicated to Stockfish runtime assets. Clear the whole
// directory first, not just today's filenames, so older-version JS/WASM files
// cannot accidentally leak into the next production bundle.
for (const entry of fs.readdirSync(destination)) {
  fs.rmSync(path.join(destination, entry), { recursive: true, force: true });
}
if (!fs.existsSync(packageRoot)) {
  const message = '[Chess Bot] Stockfish package not installed. Run npm install before building.';
  if (required) { console.error(message); process.exit(1); }
  console.warn(message);
  process.exit(0);
}
let copied = 0;
for (const file of engineFiles) {
  const source = findFile(packageRoot, file);
  if (source) {
    fs.copyFileSync(source, path.join(destination, file));
    copied++;
  } else {
    console.warn(`[Chess Bot] Did not find ${file} in stockfish package.`);
  }
}
for (const licenseName of ['Copying.txt', 'COPYING.txt', 'COPYING', 'LICENSE.txt', 'LICENSE']) {
  const licensePath = findFile(packageRoot, licenseName);
  if (licensePath) {
    fs.copyFileSync(licensePath, path.join(destination, 'STOCKFISH-LICENSE.txt'));
    break;
  }
}
const missing = engineFiles.filter(file => !fs.existsSync(path.join(destination, file)));
if (missing.length === 0) {
  console.log(`[Chess Bot] Full + Lite Stockfish assets ready (${engineFiles.length} files).`);
} else {
  const message = `[Chess Bot] Missing Stockfish assets: ${missing.join(', ')}`;
  if (required) { console.error(message); process.exit(1); }
  console.warn(`${message}. The app may fall back to a simple legal-move bot.`);
}
