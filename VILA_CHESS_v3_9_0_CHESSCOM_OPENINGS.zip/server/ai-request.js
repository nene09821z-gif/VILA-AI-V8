/** Small, predictable provider payloads for low-latency chess coaching. */
export function normalizeChatOptions(input = {}) {
  const requested = Number(input.maxTokens);
  const maxTokens = Number.isFinite(requested) ? Math.min(1200, Math.max(8, Math.trunc(requested))) : 384;
  const rawTemperature = Number(input.temperature);
  const temperature = Number.isFinite(rawTemperature) ? Math.min(1, Math.max(0, rawTemperature)) : 0.3;
  return { maxTokens, temperature };
}

export function buildChatPayload({ mode, model, messages, system = '', temperature, maxTokens }) {
  const opts = normalizeChatOptions({ temperature, maxTokens });
  const conversation = (Array.isArray(messages) ? messages : []).filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string').slice(-8);
  if (mode === 'gemini') {
    return {
      contents: conversation.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content.slice(0, 6000) }] })),
      generationConfig: { temperature: opts.temperature, maxOutputTokens: opts.maxTokens, candidateCount: 1 },
      ...(system ? { systemInstruction: { parts: [{ text: system.slice(0, 5000) }] } } : {})
    };
  }
  if (mode === 'anthropic') {
    return {
      model,
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      messages: conversation.map(m => ({ role: m.role, content: m.content.slice(0, 6000) })),
      ...(system ? { system: system.slice(0, 5000) } : {})
    };
  }
  return {
    model,
    messages: [...(system ? [{ role: 'system', content: system.slice(0, 5000) }] : []), ...conversation.map(m => ({ role: m.role, content: m.content.slice(0, 6000) }))],
    temperature: opts.temperature,
    max_tokens: opts.maxTokens,
    stream: false
  };
}
