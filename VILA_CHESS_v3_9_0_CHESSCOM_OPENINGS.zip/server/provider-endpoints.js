/** Provider endpoint normalization shared by runtime routes and regression tests. */
export function normalizeBaseUrl(raw) {
  const value = typeof raw === 'string' ? raw.trim().slice(0, 2000) : '';
  if (!value) throw new Error('Bạn cần nhập endpoint API.');
  let url;
  try { url = new URL(value); } catch { throw new Error('Endpoint không đúng định dạng URL.'); }
  if (!['http:', 'https:'].includes(url.protocol) || !url.hostname) throw new Error('Endpoint chỉ được dùng HTTP hoặc HTTPS và phải có máy chủ.');
  if (url.username || url.password || url.search || url.hash) throw new Error('Endpoint không được nhúng thông tin đăng nhập, query hoặc fragment trong URL cơ sở.');
  return url.toString().replace(/\/$/, '');
}

export function openAiChatUrl(endpoint) {
  const base = normalizeBaseUrl(endpoint);
  if (/\/chat\/completions$/i.test(base)) return base;
  return `${base}/chat/completions`;
}

export function anthropicMessagesUrl(endpoint) {
  const base = normalizeBaseUrl(endpoint || 'https://api.anthropic.com');
  if (/\/v1\/messages$/i.test(base)) return base;
  if (/\/v1$/i.test(base)) return `${base}/messages`;
  return `${base}/v1/messages`;
}

export function openAiModelsUrl(endpoint) {
  let base = normalizeBaseUrl(endpoint || 'https://api.openai.com/v1');
  base = base.replace(/\/chat\/completions$/i, '').replace(/\/+$/, '');
  return /\/models$/i.test(base) ? base : `${base}/models`;
}

export function anthropicModelsUrl(endpoint, afterId = '') {
  let base = normalizeBaseUrl(endpoint || 'https://api.anthropic.com');
  base = base.replace(/\/v1\/messages$/i, '').replace(/\/+$/, '');
  if (/\/v1\/models$/i.test(base)) base = base;
  else if (/\/v1$/i.test(base)) base = `${base}/models`;
  else base = `${base}/v1/models`;
  const parsed = new URL(base);
  parsed.searchParams.set('limit', '1000');
  if (afterId) parsed.searchParams.set('after_id', afterId);
  return parsed.toString();
}

export function geminiModelsUrl(endpoint, apiKey, pageToken = '') {
  const parsed = new URL(normalizeBaseUrl(endpoint || 'https://generativelanguage.googleapis.com'));
  const path = parsed.pathname.replace(/\/+$/, '');
  if (/\/v1beta\/models$/i.test(path)) parsed.pathname = path;
  else if (/\/v1beta$/i.test(path)) parsed.pathname = `${path}/models`;
  else if (/\/models$/i.test(path)) parsed.pathname = path;
  else parsed.pathname = `${path === '' || path === '/' ? '' : path}/v1beta/models`;
  parsed.searchParams.set('pageSize', '1000');
  if (apiKey) parsed.searchParams.set('key', apiKey);
  if (pageToken) parsed.searchParams.set('pageToken', pageToken);
  return parsed.toString();
}

export function geminiGenerateContentUrl(endpoint, model, apiKey) {
  const parsed = new URL(normalizeBaseUrl(endpoint || 'https://generativelanguage.googleapis.com'));
  let path = parsed.pathname.replace(/\/+$/, '');
  const modelId = String(model || '').replace(/^models\//i, '');
  if (!modelId && !/:generateContent$/i.test(path)) throw new Error('Gemini cần Model ID hợp lệ.');
  if (/:generateContent$/i.test(path)) {
    // Full method URLs remain supported; only the API-key query is appended below.
  } else if (/\/v1beta\/models$/i.test(path)) {
    path += `/${encodeURIComponent(modelId)}:generateContent`;
  } else if (/\/v1beta$/i.test(path)) {
    path += `/models/${encodeURIComponent(modelId)}:generateContent`;
  } else if (/\/v1beta\/models\/[^/]+$/i.test(path)) {
    path += ':generateContent';
  } else {
    path = `${path === '' || path === '/' ? '' : path}/v1beta/models/${encodeURIComponent(modelId)}:generateContent`;
  }
  parsed.pathname = path;
  if (apiKey) parsed.searchParams.set('key', apiKey);
  return parsed.toString();
}
