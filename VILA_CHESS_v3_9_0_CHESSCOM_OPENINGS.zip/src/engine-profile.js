/**
 * Select a Stockfish profile conservatively for mobile WebViews.
 * Browser deviceMemory is a coarse estimate (when supported); unknown values
 * deliberately fall back to Lite to avoid memory pressure and app crashes.
 */
export function resolveEngineProfile(preference = 'auto', device = {}) {
  if (preference === 'full-single') return 'full-single';
  if (preference === 'lite-single') return 'lite-single';

  const memory = Number(device.deviceMemory);
  const cores = Number(device.hardwareConcurrency);
  if (Number.isFinite(memory) && Number.isFinite(cores) && memory >= 6 && cores >= 6) {
    return 'full-single';
  }
  return 'lite-single';
}

export function describeEngineProfile(preference = 'auto', device = {}) {
  const selected = resolveEngineProfile(preference, device);
  if (preference === 'auto') return `${selected === 'full-single' ? 'Full' : 'Lite'} (tự động)`;
  return selected === 'full-single' ? 'Full (thủ công)' : 'Lite (thủ công)';
}
