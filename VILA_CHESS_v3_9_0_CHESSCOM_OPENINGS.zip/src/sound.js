let audioContext = null;
function getAudioContext() {
  if (typeof window === 'undefined') return null;
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  try { audioContext ||= new Ctor(); return audioContext; } catch { return null; }
}
export function unlockBoardSound() {
  const ctx = getAudioContext();
  if (!ctx) return false;
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return true;
}
export function playBoardSound(move, chess, enabled = true) {
  if (!enabled || !move) return false;
  const ctx = getAudioContext();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    let notes;
    if (chess?.isCheckmate?.()) notes = [660, 523, 392];
    else if (chess?.isCheck?.()) notes = [660, 880];
    else if (move.captured || String(move.flags || '').includes('c') || String(move.flags || '').includes('e')) notes = [480, 620];
    else if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) notes = [520, 740];
    else notes = [460];
    notes.forEach((hz, index) => {
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(hz, now + index * 0.055);
      gain.gain.setValueAtTime(0.0001, now + index * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.055, now + index * 0.055 + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.055 + 0.095);
      oscillator.connect(gain); gain.connect(ctx.destination);
      oscillator.start(now + index * 0.055); oscillator.stop(now + index * 0.055 + 0.11);
    });
    return true;
  } catch { return false; }
}


// Gentle generated chess-room motif. It uses Web Audio only after a user gesture;
// no external audio file or network request is needed.
let musicTimer = null;
let musicStep = 0;
let musicEnabled = false;
const musicNotes = [261.63, 329.63, 392.00, 329.63, 293.66, 349.23, 440.00, 349.23, 246.94, 329.63, 392.00, 329.63, 220.00, 293.66, 369.99, 293.66];
function playMusicNote() {
  const ctx = getAudioContext();
  if (!ctx || !musicEnabled) return;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    const hz = musicNotes[musicStep % musicNotes.length];
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'triangle'; osc.frequency.setValueAtTime(hz, now);
    gain.gain.setValueAtTime(0.0001, now); gain.gain.exponentialRampToValueAtTime(0.018, now + 0.08); gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.72);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 0.75);
    // A quiet fifth gives the melody a calm, chamber-music feel.
    if (musicStep % 4 === 0) {
      const pad = ctx.createOscillator(); const pg = ctx.createGain();
      pad.type = 'sine'; pad.frequency.setValueAtTime(hz / 2, now);
      pg.gain.setValueAtTime(0.0001, now); pg.gain.exponentialRampToValueAtTime(0.008, now + 0.1); pg.gain.exponentialRampToValueAtTime(0.0001, now + 1.05);
      pad.connect(pg); pg.connect(ctx.destination); pad.start(now); pad.stop(now + 1.1);
    }
    musicStep += 1;
  } catch { /* Audio may be blocked by WebView or device policy. */ }
}
export function isChessMusicPlaying() { return musicEnabled; }
export function setChessMusicPlaying(enabled) {
  musicEnabled = Boolean(enabled);
  if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
  if (musicEnabled) {
    unlockBoardSound();
    playMusicNote();
    musicTimer = setInterval(playMusicNote, 760);
  }
  return musicEnabled;
}
