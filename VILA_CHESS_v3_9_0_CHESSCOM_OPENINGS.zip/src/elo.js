/** Local Elo rating helpers. Ratings are estimates for this device, not official FIDE/Chess.com ratings. */
export function expectedScore(rating, opponentRating) {
  const a = Number(rating), b = Number(opponentRating);
  if (!Number.isFinite(a) || !Number.isFinite(b)) throw new TypeError('Ratings must be finite numbers.');
  return 1 / (1 + (10 ** ((b - a) / 400)));
}
export function calculateEloChange(rating, opponentRating, score, kFactor = 24) {
  const result = Math.max(0, Math.min(1, Number(score)));
  const k = Math.max(1, Math.min(64, Number(kFactor) || 24));
  const raw = k * (result - expectedScore(rating, opponentRating));
  // Preserve a visible positive/negative change for a decisive result even when
  // facing a much higher-rated engine would otherwise round the delta to zero.
  if (result === 1 && raw > 0 && Math.round(raw) === 0) return 1;
  if (result === 0 && raw < 0 && Math.round(raw) === 0) return -1;
  return Math.round(raw);
}
export function applyEloResult(profile, opponentRating, score) {
  const current = Math.max(100, Math.min(4000, Number(profile?.elo) || 1200));
  const change = calculateEloChange(current, opponentRating, score);
  return { ...profile, elo: Math.max(100, Math.min(4000, current + change)), lastChange: Math.max(100, Math.min(4000, current + change)) - current, games: (Number(profile?.games) || 0) + 1, wins: (Number(profile?.wins) || 0) + (score === 1 ? 1 : 0), draws: (Number(profile?.draws) || 0) + (score === 0.5 ? 1 : 0), losses: (Number(profile?.losses) || 0) + (score === 0 ? 1 : 0) };
}
