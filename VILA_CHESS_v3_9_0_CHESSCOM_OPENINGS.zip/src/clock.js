export const CLOCK_PRESETS = [
  { value: 'untimed', label: 'Không giới hạn', baseSeconds: 0, incrementSeconds: 0 },
  { value: '1+0', label: 'Bullet · 1+0', baseSeconds: 60, incrementSeconds: 0 },
  { value: '3+2', label: 'Blitz · 3+2', baseSeconds: 180, incrementSeconds: 2 },
  { value: '5+0', label: 'Blitz · 5+0', baseSeconds: 300, incrementSeconds: 0 },
  { value: '10+0', label: 'Rapid · 10+0', baseSeconds: 600, incrementSeconds: 0 },
  { value: '15+10', label: 'Rapid · 15+10', baseSeconds: 900, incrementSeconds: 10 }
];

export function parseClockPreset(value = '10+0') {
  const preset = CLOCK_PRESETS.find(item => item.value === value) || CLOCK_PRESETS.find(item => item.value === '10+0');
  return {
    preset: preset.value,
    enabled: preset.value !== 'untimed',
    baseMs: preset.baseSeconds * 1000,
    incrementMs: preset.incrementSeconds * 1000
  };
}

export function formatClockTime(milliseconds, enabled = true) {
  if (!enabled) return '∞';
  const remaining = Math.max(0, Number(milliseconds) || 0);
  if (remaining < 10_000) return `${(Math.floor(remaining / 100) / 10).toFixed(1)}`;
  const seconds = Math.ceil(remaining / 1000);
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return `${minutes}:${String(rest).padStart(2, '0')}`;
}
