import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyCentipawnLoss, estimateMoveLoss, scoreSideToWhiteCentipawns } from '../src/game-review.js';

test('move-loss classifier separates good moves, inaccuracies, mistakes and blunders', () => {
  assert.equal(classifyCentipawnLoss(10).key, 'good');
  assert.equal(classifyCentipawnLoss(30).key, 'inaccuracy');
  assert.equal(classifyCentipawnLoss(100).key, 'mistake');
  assert.equal(classifyCentipawnLoss(180).key, 'blunder');
});

test('review scores use White POV and estimate loss from the mover perspective', () => {
  assert.equal(scoreSideToWhiteCentipawns(40, 'w', 'cp'), 40);
  assert.equal(scoreSideToWhiteCentipawns(40, 'b', 'cp'), -40);
  assert.equal(estimateMoveLoss(70, 20, 'w'), 50);
  assert.equal(estimateMoveLoss(20, 70, 'b'), 50);
  assert.equal(estimateMoveLoss(null, 70, 'b'), null);
});
