import test from 'node:test';
import assert from 'node:assert/strict';
import { CLOCK_PRESETS, parseClockPreset, formatClockTime } from '../src/clock.js';

test('clock presets include common bullet, blitz, and rapid controls', () => {
  assert.deepEqual(CLOCK_PRESETS.map(item => item.value), ['untimed', '1+0', '3+2', '5+0', '10+0', '15+10']);
  assert.equal(parseClockPreset('3+2').baseMs, 180_000);
  assert.equal(parseClockPreset('3+2').incrementMs, 2_000);
  assert.equal(parseClockPreset('not-a-clock').preset, '10+0');
});

test('clock formatting stays readable from untimed to sub-ten-second states', () => {
  assert.equal(formatClockTime(999_999, false), '∞');
  assert.equal(formatClockTime(600_000), '10:00');
  assert.equal(formatClockTime(9_999), '9.9');
  assert.equal(formatClockTime(0), '0.0');
  assert.equal(formatClockTime(-1), '0.0');
});
