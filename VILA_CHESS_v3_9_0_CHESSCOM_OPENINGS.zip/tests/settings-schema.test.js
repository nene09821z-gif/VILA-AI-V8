import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULTS, normalizeSettings } from '../src/settings-schema.js';

test('empty or malformed storage falls back to safe defaults', () => {
  assert.equal(normalizeSettings(null).aiMode, DEFAULTS.aiMode);
  assert.equal(normalizeSettings([]).endpoint, DEFAULTS.endpoint);
  assert.equal(normalizeSettings({ endpoint: null, model: {}, aiMode: 'not-a-provider' }).model, DEFAULTS.model);
  assert.equal(normalizeSettings({ endpoint: null, aiMode: 'not-a-provider' }).aiMode, 'gemini');
});

test('numeric settings are clamped to supported ranges', () => {
  const value = normalizeSettings({ temperature: 99, botSkill: -2, botElo: 99999, botDepth: 0 });
  assert.equal(value.temperature, 1.5);
  assert.equal(value.botSkill, 0);
  assert.equal(value.botElo, 3190);
  assert.equal(value.botDepth, 5);
});

test('legacy implicit Lite setting migrates to adaptive mode but explicit choice is retained', () => {
  assert.equal(normalizeSettings({ botEngine: 'lite-single' }).botEngine, 'auto');
  assert.equal(normalizeSettings({ botEngine: 'lite-single', botEnginePreferenceSet: true }).botEngine, 'lite-single');
  assert.equal(normalizeSettings({ botEngine: 'mystery' }).botEngine, 'auto');
});

test('invalid AI profiles are discarded and valid profile IDs are normalized uniquely', () => {
  const value = normalizeSettings({ aiProfiles: [
    null,
    { id: 'current', name: 'Bad reserved id', endpoint: 'https://example.com/v1', model: 'x' },
    { id: 'good id', name: 'Valid', endpoint: 'https://example.com/v1/', model: 'model-a', apiKey: 'secret', aiMode: 'openai-compatible' },
    { id: 'good id', name: 'Duplicate', endpoint: 'https://example.com/v1', model: 'model-b' },
    { name: 'No endpoint', model: 'invalid' }
  ] });
  assert.equal(value.aiProfiles.length, 3);
  assert.notEqual(value.aiProfiles[0].id, 'current');
  assert.equal(value.aiProfiles[0].endpoint, 'https://example.com/v1');
  assert.notEqual(value.aiProfiles[0].id, value.aiProfiles[1].id);
});

test('AI profiles remain capped at twenty and only HTTP(S) endpoints are accepted', () => {
  const many = Array.from({ length: 25 }, (_, i) => ({
    id: `p${i}`, name: `Profile ${i}`, endpoint: 'https://example.com/v1', model: `m${i}`
  }));
  many[0].endpoint = 'file:///etc/passwd';
  const value = normalizeSettings({ aiProfiles: many });
  assert.equal(value.aiProfiles.length, 19);
  assert.ok(value.aiProfiles.every(p => /^https?:\/\//i.test(p.endpoint)));
});


test('malformed numeric values and unsafe endpoint schemes fall back safely', () => {
  const value = normalizeSettings({
    temperature: null,
    botSkill: '',
    botElo: false,
    botDepth: 'not-a-number',
    endpoint: 'javascript:alert(1)',
    backendUrl: 'file:///tmp/backend',
    aiProfiles: [
      { name: 'Unsafe credentials', endpoint: 'https://user:pass@example.com/v1', model: 'm' },
      { name: 'Unsafe query', endpoint: 'https://example.com/v1?key=secret', model: 'm' }
    ]
  });
  assert.equal(value.temperature, DEFAULTS.temperature);
  assert.equal(value.botSkill, DEFAULTS.botSkill);
  assert.equal(value.botElo, DEFAULTS.botElo);
  assert.equal(value.botDepth, DEFAULTS.botDepth);
  assert.equal(value.endpoint, DEFAULTS.endpoint);
  assert.equal(value.backendUrl, '');
  assert.deepEqual(value.aiProfiles, []);
});


test('move-time, analysis-time, and clock settings are clamped and migrated safely', () => {
  const fast = normalizeSettings({ botMoveTimeMs: 10, analysisMoveTimeMs: 90000, clockPreset: 'broken' });
  assert.equal(fast.botMoveTimeMs, 500);
  assert.equal(fast.analysisMoveTimeMs, 8000);
  assert.equal(fast.clockPreset, '10+0');
  const normal = normalizeSettings({ botMoveTimeMs: 1600, analysisMoveTimeMs: 3200, clockPreset: '3+2' });
  assert.equal(normal.botMoveTimeMs, 1600);
  assert.equal(normal.analysisMoveTimeMs, 3200);
  assert.equal(normal.clockPreset, '3+2');
});
