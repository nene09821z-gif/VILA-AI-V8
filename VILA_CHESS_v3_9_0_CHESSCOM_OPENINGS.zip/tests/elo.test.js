import test from 'node:test';
import assert from 'node:assert/strict';
import { expectedScore, calculateEloChange, applyEloResult } from '../src/elo.js';
test('equal ratings expect a draw', () => assert.equal(expectedScore(1200, 1200), 0.5));
test('wins gain Elo and losses lose Elo', () => { assert.ok(calculateEloChange(1200, 1200, 1) > 0); assert.ok(calculateEloChange(1200, 1200, 0) < 0); assert.ok(calculateEloChange(1200, 2200, 0) < 0); });
test('rating profile tracks results and bounds rating', () => { const p = applyEloResult({ elo: 1200 }, 1200, 1); assert.equal(p.elo, 1212); assert.equal(p.wins, 1); assert.equal(p.games, 1); });
