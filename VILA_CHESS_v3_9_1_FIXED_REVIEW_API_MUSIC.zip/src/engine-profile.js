/**
 * Select a Stockfish profile conservatively for mobile WebViews.
 * Browser deviceMemory is a coarse estimate (when supported); unknown values
 * deliberately fall back to Lite to avoid memory pressure and app crashes.
 */
export function resolveEngineProfile(preference = 'auto', device = {}) {
  if (preference === 'full-single') return 'full-single';
  if (preference === 'lite-single') return 'lite-single';

  // The Full single-thread build is roughly 94 MB and is not bundled in the
  // default APK. Auto must therefore remain deterministic and use the small
  // Lite artifact; Full remains an explicit opt-in with a runtime Lite fallback.
  return 'lite-single';
}

export function describeEngineProfile(preference = 'auto', device = {}) {
  const selected = resolveEngineProfile(preference, device);
  if (preference === 'auto') return `${selected === 'full-single' ? 'Full' : 'Lite'} (tự động)`;
  return selected === 'full-single' ? 'Full (thủ công)' : 'Lite (thủ công)';
}
