/** Pure helpers for the post-game review panel; move legality is checked by chess.js in the caller. */
export function classifyCentipawnLoss(lossCp) {
  const loss = Math.max(0, Number(lossCp) || 0);
  if (loss <= 5) return { label: 'Tốt nhất', key: 'best' };
  if (loss <= 15) return { label: 'Xuất sắc', key: 'excellent' };
  if (loss < 25) return { label: 'Tốt', key: 'good' };
  if (loss < 70) return { label: 'Chưa chính xác', key: 'inaccuracy' };
  if (loss < 150) return { label: 'Sai lầm', key: 'mistake' };
  return { label: 'Blunder', key: 'blunder' };
}

export function scoreSideToWhiteCentipawns(score, sideToMove, scoreType = 'cp') {
  const value = Number(score) || 0;
  const signed = sideToMove === 'b' ? -value : value;
  if (scoreType === 'mate') return Math.sign(signed || 1) * (10000 - Math.min(999, Math.abs(signed)) * 10);
  return signed;
}

export function estimateMoveLoss(previousWhiteCp, currentWhiteCp, mover) {
  if (previousWhiteCp == null || currentWhiteCp == null || previousWhiteCp === '' || currentWhiteCp === '' ||
      !Number.isFinite(Number(previousWhiteCp)) || !Number.isFinite(Number(currentWhiteCp))) return null;
  const delta = mover === 'w' ? Number(previousWhiteCp) - Number(currentWhiteCp) : Number(currentWhiteCp) - Number(previousWhiteCp);
  return Math.max(0, Math.round(delta));
}

/** A deliberately conservative heuristic, not an official Chess.com classification. */
export function classifyReviewedMove(lossCp, sacrificeCandidate = false, bookMove = false) {
  if (bookMove) return { label: 'Khai cuộc', key: 'book' };
  if (sacrificeCandidate && lossCp != null && Number.isFinite(Number(lossCp)) && Number(lossCp) <= 25) {
    return { label: 'Thiên tài*', key: 'brilliant' };
  }
  return classifyCentipawnLoss(lossCp);
}


/** Build SAN-prefix keys from the current opening catalogue for quick book tagging. */
export function buildOpeningBookPrefixes(openings = []) {
  const prefixes = new Set();
  for (const opening of openings) {
    if (!Array.isArray(opening?.san)) continue;
    const path = [];
    for (const san of opening.san) {
      if (typeof san !== 'string' || !san.trim()) break;
      path.push(san.trim());
      prefixes.add(path.join(' '));
    }
  }
  return prefixes;
}
