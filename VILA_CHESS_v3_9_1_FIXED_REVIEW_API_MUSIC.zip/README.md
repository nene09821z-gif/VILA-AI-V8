# VILA Chess AI Arena v3.9.1

VILA Chess là app cờ vua ưu tiên Android/WebView, dùng Stockfish 19 để tính nước, luật cờ qua `chess.js`, AI Coach qua Gemini/các API tương thích, sách khai cuộc có trọng số, đánh giá MultiPV, âm thanh bàn cờ, gợi ý có mũi tên, phân tích toàn ván, đồng hồ, PGN và Lichess.

> **Đây là ZIP mã nguồn để build bằng GitHub Actions, không phải APK đã biên dịch.** Build phụ thuộc cài đặt thành công và xác thực thiết bị là cổng bắt buộc trước khi phát hành.

## Có gì trong v3.9.1

- Chuẩn hóa endpoint Gemini khi người dùng nhập URL method đầy đủ; loại preset Gemini 3.7 đã bị deprecated khỏi danh sách nhanh.
- Stockfish Lite là profile tự động, kiểm tra tệp trước khi dọn engine cũ và thử fallback Lite nếu Full lỗi.
- Lưu lịch sử ván đã kết thúc vào thiết bị, xem lại từng nước, mở phân tích, xóa bản lưu và xuất PGN; PGN giữ FEN cho thế cờ tùy chỉnh.
- Nhạc piano Gymnopédie No. 1 có ghi công/giấy phép và nhạc Web Audio dự phòng khi offline.
- Test tĩnh sau chỉnh sửa: **120/120 đạt**. Full suite có 120 bài đạt; một file luật cờ không khởi chạy vì môi trường hiện tại thiếu `chess.js`. Cài dependencies bị timeout nên APK chưa được build/xác minh tại đây.


- **Kho khai cuộc mở rộng:** trước bước Vite build, workflow thử tải năm nhóm ECO `a.tsv`–`e.tsv` từ `lichess-org/chess-openings` (CC0-1.0), kiểm tra biến bằng `chess.js`, loại dòng trùng và đóng gói `public/openings-eco.json`. Khi dữ liệu ngoài không lấy được, 81 đường khai cuộc mẫu hiện có vẫn hoạt động.
- **AI dùng kho rộng hơn:** sách khai cuộc và nhận diện chạy qua cây tiền tố; cache được xây lại sau khi kho động tải thêm, tránh tình trạng giao diện đếm nhiều dòng nhưng AI còn dùng cache cũ. Kho giao diện tìm theo tên/mã ECO/nước đi, lọc hệ khai cuộc và tải thêm từng trang.
- **Phòng chơi kiểu Chess.com:** khu bàn cờ tông xanh lá/kem, hàng người chơi/đối thủ, đồng hồ, nhãn khai cuộc, phân tích engine, lịch sử nước và công cụ bên cạnh; bố cục tự co về một cột trên điện thoại. Đây là bố cục lấy cảm hứng, không phải bản sao chính thức.

- **Trang chủ VILA Chess mới:** app mở vào dashboard thay vì nhảy thẳng vào bàn cờ; có nút chơi nhanh, thiết lập ván, Đấu trường AI, AI Coach, Thư viện khai cuộc, Elo/xếp hạng và Lichess.
- **Thao tác Android nhanh hơn:** thanh Ván mới/Hoàn tác/Gợi ý cố định ở đáy màn hình; thiết lập trận được thu gọn; chọn ô chỉ cập nhật highlight thay vì dựng lại toàn bộ 64 ô; kéo quân dùng `requestAnimationFrame` và bỏ qua sự kiện click tổng hợp theo đúng ô.
- **Sửa trường hợp API trả rỗng:** đọc thêm định dạng OpenAI Responses `output[]`, wrapper của gateway và phản hồi `text/event-stream` của OpenAI-compatible, Gemini, Anthropic; giữ nguyên dấu cách khi ghép chunk, bỏ qua khối Gemini `thought`, và cải thiện chẩn đoán finish reason. Lỗi mạng được làm sạch key trước khi đưa ra giao diện.
- **Kéo quân trên WebView:** bỏ bộ lọc `drop-shadow` thay đổi theo từng frame, giữ chuyển động bằng transform compositor; dọn trạng thái khi mất pointer capture và bỏ nước đi đang chờ phong cấp nếu thế cờ/phiên ván đã đổi.
- **Giao diện di động:** hero cờ vua, thẻ công cụ responsive, thống kê Elo cục bộ và trạng thái cấu hình API; tối ưu bố cục nhỏ cho Android WebView.
- **Nhãn Android:** tên ứng dụng launcher chuyển thành `VILA Chess`, giữ nguyên application ID để không tự ý đổi định danh gói.
- **Phân tích Stockfish ổn định hơn (v3.5):** tuần tự hóa lượt tìm kiếm bị hủy, bỏ qua kết quả cũ theo FEN/phiên ván, watchdog khi engine không xác nhận dừng và giữ bảng phân tích với thông báo hữu ích khi thiếu biến thể.
- **Tính năng được giữ lại:** chơi với Stockfish, AI qua API, bàn cờ vuốt quân, đồng hồ, phân tích 3 biến, phân tích toàn ván, gợi ý, sách khai cuộc, nhạc nền, Elo cục bộ, đấu trường AI, PGN, Lichess và cấu hình provider.

## Build Android qua GitHub Actions

**Cách A — build trực tiếp từ ZIP đã tải:** tải `VILA_CHESS_v3_9_1_FIXED_REVIEW_API_MUSIC.zip`, đưa chính file ZIP này vào thư mục gốc repository GitHub rồi commit/push. Workflow **Build VILA Chess APK from uploaded ZIP** sẽ giải nén và build từ ZIP. Bản ZIP này đặt `package.json`, `index.html` và `.github/workflows` ngay tại gốc archive, không lồng thêm thư mục `work_v32`.

**Cách B — build từ các tệp đã giải nén:** giải nén mọi file vào gốc repository, giữ lại các file ẩn và `.github/workflows`; commit/push lên `main`, rồi chạy **Build VILA Chess APK** trong tab Actions.

Workflow cài dependencies, chạy static/full tests, yêu cầu asset Stockfish Lite, build Vite, tạo/sync Capacitor Android, xác minh Gradle rồi build APK debug. Chỉ lấy APK artifact khi workflow hoàn tất thành công. ZIP nguồn không phải APK.

## Trạng thái kiểm thử trong môi trường tạo ZIP

- `npm run test:static`: **120/120 bài đạt** trong lần chạy cuối, gồm regression cho endpoint API, Stockfish fallback, lịch sử/xem lại, PGN thế cờ tùy chỉnh, nhạc, model catalogue và bố cục di động.
- JavaScript syntax checks, JSON configuration checks, Python compile checks và ZIP integrity được chạy khi đóng gói. `prebuild` tải dữ liệu khai cuộc qua mạng; nếu truy cập nguồn lỗi, build tiếp tục với kho mẫu.
- `npm test`: **120 bài đạt, 1 file kiểm thử bị chặn** vì `tests/chess.test.js` không thể import `chess.js` (`ERR_MODULE_NOT_FOUND`) khi dependencies chưa được cài. `npm install --no-audit --no-fund --prefer-offline` bị timeout trong môi trường sửa. Vì vậy production build/APK, API gọi bằng key thật, engine trong Android WebView và thao tác kéo quân trên thiết bị chưa được xác nhận; cần workflow GitHub hoàn tất thành công và kiểm thử thiết bị trước khi phát hành.

## Model/API và an toàn

Trang chính thức có thể đổi model/giá bất kỳ lúc nào; hãy kiểm tra trước khi dùng:

- Gemini models/pricing: <https://ai.google.dev/gemini-api/docs/models> · <https://ai.google.dev/gemini-api/docs/pricing>
- Groq models/rate limits: <https://console.groq.com/docs/models> · <https://console.groq.com/docs/rate-limits>
- OpenRouter free router: <https://openrouter.ai/openrouter/free> · <https://openrouter.ai/pricing/>

Không commit API key vào repository công khai. Key được người dùng tự nhập trên thiết bị; không có khóa nhà cung cấp chung tích hợp sẵn. Backend public cần HTTPS và `TUBOR_ACCESS_TOKEN` mạnh. Đọc kỹ chính sách chia sẻ dữ liệu của từng provider.
