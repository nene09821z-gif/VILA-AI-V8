import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveEngineProfile, describeEngineProfile } from '../src/engine-profile.js';

test('auto engine uses Lite when device information is missing', () => {
  assert.equal(resolveEngineProfile('auto', {}), 'lite-single');
});

test('auto engine uses Lite on a modest phone', () => {
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 4, hardwareConcurrency: 8 }), 'lite-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 4 }), 'lite-single');
});

test('auto engine remains Lite even on powerful devices because Full is optional and very large', () => {
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 6, hardwareConcurrency: 6 }), 'lite-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 8 }), 'lite-single');
});

test('manual engine choice overrides device heuristic', () => {
  assert.equal(resolveEngineProfile('full-single', { deviceMemory: 2, hardwareConcurrency: 2 }), 'full-single');
  assert.equal(resolveEngineProfile('lite-single', { deviceMemory: 12, hardwareConcurrency: 12 }), 'lite-single');
});

test('profile description makes auto choice clear', () => {
  assert.equal(describeEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 8 }), 'Lite (tự động)');
  assert.equal(describeEngineProfile('auto', {}), 'Lite (tự động)');
});
