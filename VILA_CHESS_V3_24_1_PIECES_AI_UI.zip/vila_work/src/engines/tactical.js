import { PIECE_VALUE, centerValue, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, isAttacked, countAttackers } from './evaluation-utils.js';

// Tactics-focused evaluator plus the common engine's capture quiescence search.
// This is a VILA engine, not the original Ethereal engine.
export const TACTICAL = Object.freeze({ id: 'ethereal', name: 'Tactical', defaultDepth: 5, maxNodes: 40000, maxTimeMs: 950, multipv: 1, style: 'tactical', lateMoveReduction: true, randomTop: 1 });

export function evaluateTactical(chess) {
  const board = chess.board();
  let score = materialScore(board) + pawnStructureScore(board) * 0.7 + kingSafetyScore(board) * 1.05;
  score += pieceActivityScore(board, { knight: 5, bishop: 4, rook: 1, queen: 0.5, pawnAdvance: 2.2 });
  // A modest hanging-piece penalty encourages tactical awareness without
  // replacing search with unreliable static assumptions about exchanges.
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p || p.type === 'p' || p.type === 'k') continue;
    const enemy = p.color === 'w' ? 'b' : 'w';
    if (!isAttacked(board, row, col, enemy)) continue;
    const enemyCount = countAttackers(board, row, col, enemy);
    const friendlyCount = countAttackers(board, row, col, p.color);
    const exposure = friendlyCount === 0 ? 20 : enemyCount > friendlyCount ? 8 : 0;
    score += (p.color === 'w' ? -1 : 1) * Math.min(exposure, (PIECE_VALUE[p.type] || 0) * 0.07);
  }
  // Give a small reward to occupying/attacking the central four squares.
  for (const [row, col] of [[3,3],[3,4],[4,3],[4,4]]) {
    const p = board[row][col];
    if (p) score += (p.color === 'w' ? 1 : -1) * (p.type === 'p' ? 8 : 4);
  }
  return score;
}
