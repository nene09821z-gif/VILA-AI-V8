// Position-analysis primitives shared by VILA's independent offline engines.
// Scores are expressed from White's point of view in centipawns.
export const PIECE_VALUE = Object.freeze({ p: 100, n: 325, b: 335, r: 500, q: 950, k: 0 });

export function centerValue(row, col) {
  return 7 - (Math.abs(3.5 - row) + Math.abs(3.5 - col));
}

export function kingPosition(board, color) {
  for (let row = 0; row < 8; row += 1) {
    for (let col = 0; col < 8; col += 1) {
      const piece = board[row][col];
      if (piece?.color === color && piece.type === 'k') return { row, col };
    }
  }
  return null;
}

// Does `byColor` attack a square? This is a board-geometry test, not a move
// legality test; pinned attackers still count for king-safety heuristics.
export function isAttacked(board, targetRow, targetCol, byColor) {
  const pawnSourceRow = targetRow + (byColor === 'w' ? 1 : -1);
  for (const dc of [-1, 1]) {
    const col = targetCol + dc;
    if (pawnSourceRow >= 0 && pawnSourceRow < 8 && col >= 0 && col < 8 &&
        board[pawnSourceRow][col]?.color === byColor && board[pawnSourceRow][col]?.type === 'p') return true;
  }
  for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
    const row = targetRow + dr; const col = targetCol + dc;
    const p = row >= 0 && row < 8 && col >= 0 && col < 8 ? board[row][col] : null;
    if (p?.color === byColor && p.type === 'n') return true;
  }
  for (const [dr, dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
    let row = targetRow + dr; let col = targetCol + dc; let distance = 1;
    while (row >= 0 && row < 8 && col >= 0 && col < 8) {
      const p = board[row][col];
      if (p) {
        if (p.color === byColor) {
          if (p.type === 'q' || (distance === 1 && p.type === 'k') ||
              (dr === 0 || dc === 0 ? p.type === 'r' : p.type === 'b')) return true;
        }
        break;
      }
      row += dr; col += dc; distance += 1;
    }
  }
  return false;
}

export function countAttackers(board, targetRow, targetCol, byColor) {
  let count = 0;
  const pawnSourceRow = targetRow + (byColor === 'w' ? 1 : -1);
  for (const dc of [-1, 1]) {
    const col = targetCol + dc;
    if (pawnSourceRow >= 0 && pawnSourceRow < 8 && col >= 0 && col < 8 &&
        board[pawnSourceRow][col]?.color === byColor && board[pawnSourceRow][col]?.type === 'p') count += 1;
  }
  for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
    const row = targetRow + dr; const col = targetCol + dc;
    const p = row >= 0 && row < 8 && col >= 0 && col < 8 ? board[row][col] : null;
    if (p?.color === byColor && p.type === 'n') count += 1;
  }
  for (const [dr, dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
    let row = targetRow + dr; let col = targetCol + dc; let distance = 1;
    while (row >= 0 && row < 8 && col >= 0 && col < 8) {
      const p = board[row][col];
      if (p) {
        if (p.color === byColor && (p.type === 'q' || (distance === 1 && p.type === 'k') ||
            (dr === 0 || dc === 0 ? p.type === 'r' : p.type === 'b'))) count += 1;
        break;
      }
      row += dr; col += dc; distance += 1;
    }
  }
  return count;
}

export function materialScore(board) {
  let score = 0;
  for (const row of board) for (const piece of row) {
    if (piece) score += (piece.color === 'w' ? 1 : -1) * (PIECE_VALUE[piece.type] || 0);
  }
  return score;
}

export function pawnStructureScore(board) {
  let score = 0;
  for (const color of ['w', 'b']) {
    const sign = color === 'w' ? 1 : -1;
    const pawnsByFile = Array(8).fill(0);
    const pawnSquares = [];
    for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
      const p = board[row][col];
      if (p?.color === color && p.type === 'p') {
        pawnsByFile[col] += 1;
        pawnSquares.push({ row, col });
      }
    }
    for (let col = 0; col < 8; col += 1) {
      if (pawnsByFile[col] > 1) score -= sign * 13 * (pawnsByFile[col] - 1); // doubled pawns
      if (pawnsByFile[col] && !(pawnsByFile[col - 1] || 0) && !(pawnsByFile[col + 1] || 0)) score -= sign * 11; // isolated
    }
    for (const pawn of pawnSquares) {
      let passed = true;
      for (let row = 0; row < 8 && passed; row += 1) for (let col = Math.max(0, pawn.col - 1); col <= Math.min(7, pawn.col + 1); col += 1) {
        const enemy = board[row][col];
        if (enemy?.color !== (color === 'w' ? 'b' : 'w') || enemy.type !== 'p') continue;
        if (color === 'w' ? row < pawn.row : row > pawn.row) { passed = false; break; }
      }
      if (passed) score += sign * (8 + (color === 'w' ? 6 - pawn.row : pawn.row - 1) * 7);
    }
  }
  return score;
}

export function kingSafetyScore(board) {
  let score = 0;
  for (const color of ['w', 'b']) {
    const sign = color === 'w' ? 1 : -1;
    const king = kingPosition(board, color);
    if (!king) continue;
    const enemy = color === 'w' ? 'b' : 'w';
    let attackedNeighbors = 0;
    let friendlyShield = 0;
    for (let dr = -1; dr <= 1; dr += 1) for (let dc = -1; dc <= 1; dc += 1) {
      if (!dr && !dc) continue;
      const row = king.row + dr; const col = king.col + dc;
      if (row < 0 || row > 7 || col < 0 || col > 7) continue;
      if (isAttacked(board, row, col, enemy)) attackedNeighbors += 1;
      const p = board[row][col];
      if (p?.color === color && p.type === 'p') friendlyShield += 1;
    }
    score += sign * (friendlyShield * 5 - attackedNeighbors * 11);
  }
  return score;
}

export function pieceActivityScore(board, options = {}) {
  const scoreByPiece = { n: options.knight ?? 5, b: options.bishop ?? 3, r: options.rook ?? 1, q: options.queen ?? 0, p: options.pawn ?? 0, k: options.king ?? -1 };
  let score = 0;
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col];
    if (!p) continue;
    const sign = p.color === 'w' ? 1 : -1;
    const center = centerValue(row, col);
    const advance = p.color === 'w' ? 6 - row : row - 1;
    score += sign * (center * (scoreByPiece[p.type] || 0) + (p.type === 'p' ? advance * (options.pawnAdvance ?? 0) : 0));
  }
  return score;
}
