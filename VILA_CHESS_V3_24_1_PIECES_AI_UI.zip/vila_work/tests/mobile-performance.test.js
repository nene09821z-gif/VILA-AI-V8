import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server/index.js', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('Mobile game action bar stays reachable while the board is scrolled', () => {
  assert.match(main, /body\.classList\.toggle\('play-screen-active', currentView === 'play'\)/);
  assert.match(css, /body\.play-screen-active \.play-layout \.mobile-action-row\s*\{\s*position:fixed/);
  assert.match(css, /env\(safe-area-inset-bottom/);
});

test('Mobile game setup uses a compact disclosure instead of a permanently tall panel', () => {
  assert.match(main, /<details class="panel game-setup" id="gameSetupPanel"/);
  assert.match(main, /game-setup-summary/);
  assert.match(css, /\.game-setup\[open\] \.setup-chevron/);
});

test('Chess input is delegated, drag rendering is frame-coalesced, and tap fallback is explicit', () => {
  assert.match(main, /function wireBoardSquareClicks\(board\)/);
  assert.match(main, /dragMoveFrame = requestAnimationFrame/);
  assert.match(main, /handleSquareClick\(state\.from\)/);
  assert.match(main, /new Map\(\$\$\('\.square\[data-square\]', board\)\.map/);
  assert.match(css, /\.square,\.chessboard\{touch-action:none/);
  const clickStart = main.indexOf('function handleSquareClick(');
  const clickEnd = main.indexOf('\nfunction choosePromotion', clickStart);
  const clickHandler = main.slice(clickStart, clickEnd);
  assert.match(clickHandler, /updateDragSelection\(board, selected, selectedTargets\)/);
});

test('One player move triggers one primary view refresh instead of two consecutive redraws', () => {
  const start = main.indexOf('function onMoveComplete()');
  const end = main.indexOf('\nfunction resignCurrentGame()', start);
  const fn = main.slice(start, end);
  assert.equal((fn.match(/renderView\(\)/g) || []).length, 1);
});

test('Chat response normalization remains wired into the v3.15 project', () => {
  assert.match(server, /extractChatText\(mode, data\)/);
  assert.match(main, /const requestCoach = \(retry = false, modelOverride = settings\.model\)/);
  assert.match(main, /data = await requestCoach\(true\)/);
  assert.match(main, /requestCoach\(true, 'gemini-3\.6-flash'\)/);
  assert.match(main, /Phản hồi dự phòng từ/);
  assert.equal(pkg.version, '3.24.0');
});

test('Synthetic touch-click suppression is scoped to one square and a short window', () => {
  assert.match(main, /let suppressSquareClick = null/);
  assert.match(main, /Date\.now\(\) <= suppress\.until && square\.dataset\.square === suppress\.square/);
  assert.match(main, /suppressSquareClick = \{ square: state\.from, until: Date\.now\(\) \+ 160 \}/);
  assert.doesNotMatch(main, /suppressSquareClickUntil = Date\.now\(\) \+ 450/);
});

test('AI move and Arena requests retry once only for provider responses with no text', () => {
  assert.match(main, /const requestAiMove = \(retry = false\)/);
  assert.match(main, /response = await requestAiMove\(true\)/);
  assert.match(main, /attempt === 0 && \/chưa có câu trả lời văn bản\|không trả trường văn bản tương thích\|không có nội dung văn bản\/i\.test/);
  assert.match(main, /timeoutMs: retry \? 48_000 : 28_000/);
});


test('Drag ghost uses a compositor-friendly transform without per-frame shadow filters', () => {
  assert.match(css, /\.drag-ghost\{[^}]*will-change:transform[^}]*backface-visibility:hidden/);
  assert.match(css, /\.drag-ghost\{left:0;top:0;will-change:transform;filter:none\}/);
  assert.match(main, /lostpointercapture/);
  assert.match(main, /epoch: gameEpoch, fen: game\.fen\(\), moved: false/);
  assert.match(main, /state\.epoch !== gameEpoch \|\| state\.fen !== game\.fen\(\)/);
});
