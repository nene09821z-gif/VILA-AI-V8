# VILA AI Studio V39 — Adaptive Model Discovery & Android Source

VILA is an Android WebView app that connects to real AI provider APIs. This ZIP contains the source project, not a prebuilt APK.

## New in V39

- OpenRouter's public `/models` catalog can be scanned without entering a key so you can see the current text-capable catalog and models whose live metadata identifies them as free. A valid OpenRouter API key is still required to send chat requests.
- Gemini model discovery marks documented free-tier families when the live model endpoint exposes them. Free-tier eligibility is not a promise of unlimited quota; availability, account restrictions, region and rate limits remain controlled by the provider.
- Custom/OpenAI-compatible endpoints remain supported: choose **Custom API**, enter the provider's Base URL and API key, then tap **Tải model mới nhất từ API**. This works only if that endpoint exposes a compatible `/models` listing and chat-completions endpoint. Some providers require a provider-specific API protocol or CORS/network permissions and may not work as an arbitrary OpenAI-compatible endpoint.
- The model catalog is cached on-device so the last successful list remains visible when temporarily offline. A successful refresh replaces that cached catalog.
- Android Internet permission and the foreground progress notification are already enabled. The foreground service is intended to keep an active request visible while the user switches apps; Android battery optimization, OEM task killers, network interruptions, provider outages and service limits mean no app can guarantee uninterrupted 24/7 execution on every device.

## Build

Use GitHub Actions: push the extracted project to a GitHub repository, open **Actions**, choose **VILA AI - Android Build and Verify**, then **Run workflow**. Download the debug APK artifact for installation and testing. Release APK signing requires Android signing secrets; without them, the release APK is unsigned.

See `README_GITHUB_BUILD_V28.md` for the detailed workflow. The workflow runs offline source/runtime checks and Android Gradle builds. A green result demonstrates that the selected build completed in CI, not that every external provider or API key works.

## Provider setup

1. Open **Settings / API**.
2. Choose Gemini, Groq, Cerebras, OpenRouter, or Custom API.
3. Enter the endpoint's API key (except when only scanning OpenRouter's public catalog).
4. For Custom API, enter its Base URL. The endpoint must support the protocol shown by that provider.
5. Tap **Tải model mới nhất từ API**, then choose a model. Use **Kiểm tra kết nối** to verify chat access.

Never paste API keys into public issue reports or share screenshots that reveal a key. Keys stored through the Android bridge use the project's protected local-storage mechanism; uninstalling the app or clearing app data can remove them.

## Model status accuracy

- OpenRouter `:free` suffix and price metadata are treated as catalog indicators, not a guarantee of uninterrupted availability.
- For Gemini, model availability is read from the official authenticated model list when synced. Model-specific free-tier eligibility and quota are controlled by Google's current project/account policies.
- Groq, Cerebras and custom gateways expose the model IDs available to their API credentials; the app does not assume that an ID listed elsewhere is enabled for your account.
- No model is downloaded into the phone by this feature. It discovers hosted API model IDs; downloading/running local model weights is a separate feature with substantial device-storage and RAM requirements.
