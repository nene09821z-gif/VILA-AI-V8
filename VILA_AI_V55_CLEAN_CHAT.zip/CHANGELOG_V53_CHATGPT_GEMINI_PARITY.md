# VILA AI V53.0.0 — Image, web, video, reasoning upgrades

## Bug fixed
- **Web search sources never appeared.** `requestGeminiWebSearch` read `data.groundingMetadata`, but Gemini returns it at `candidates[0].groundingMetadata`. Fixed (the server gateway already read it correctly).

## Web browsing
- Inline citation markers `[1][2]` placed after grounded sentences (UTF-8 byte offsets handled for Vietnamese text).
- Shows the queries Gemini searched ("🔎 Đã tìm: …").
- Links pasted by the user are opened with Gemini `url_context` alongside Google Search.

## Reasoning
- Gemini 3.x / 2.5 now request `includeThoughts`; the thought summary appears in the collapsible "Tóm tắt suy luận" panel and is kept out of the answer text. Respects the "show reasoning summary" setting; skipped on low effort.

## Image generation
- Aspect ratio inferred from the prompt (dọc / vuông / ngang / 3:2 …).
- Follow-up edits: right after an image, "đổi nền thành màu xanh" edits that image (kept aspect ratio) instead of making a new one.
- "Tạo lại" (regenerate) button on every generated image.

## Video (Veo)
- Prompt options: video dọc (9:16), 4/6/8 seconds, 1080p (forces 8s; image-to-video is 8s).
- Falls back to `veo-3.1-fast-generate-preview` if the main model is unavailable (404/403/400).
- Polling survives up to 4 transient network/429/5xx errors; status shows elapsed time.

## Housekeeping
- Version bumped to 53.0.0 (versionCode 63). Seven older tests pinned stale version numbers (they failed on the V52.2 zip); updated. Added `scripts/test-v53-media-search-reasoning.js`.

## Not verified
No live Gemini/Veo calls were possible here (no API key, restricted network). Logic is unit-tested; field names follow the Gemini API docs but should be smoke-tested on a device with a real key. Model availability (`veo-3.1-fast-generate-preview`) depends on the account.

## V53.1 — thinking panel, permissions, creativity
- **Thinking panel:** forced `flex:0 0 auto`, `min-height:max-content`, aligned with the message column (52px desktop, full width mobile) so it can't shrink or be clipped in the chat flex column; live seconds counter; finished answers show "Đã suy nghĩ N giây · Tóm tắt suy luận".
- **Permissions (Settings → Bảo mật & tự động hóa), all default ON:** auto-scan models at startup, auto-open pasted links (url_context), creative mode, image-prompt enrichment. The Android manifest already declares INTERNET/notifications/camera/mic/media.
- **Auto web search** now also triggers for "ai là…", current office-holders, years 2024–2029, results/scores, prices, changelogs and any pasted URL; skips pure code/translate/maths asks.
- **Creative mode:** viết thơ/truyện/slogan/đặt tên/ý tưởng… get a creativity prompt (3 distinct options, concrete imagery) and temperature 1.0 (Gemini) / 0.95 (OpenAI-compatible, non-reasoning models).
- **Image prompt enrichment:** short ideas are rewritten into a detailed art-directed prompt (12s timeout, falls back to the original); skipped for edits/reference images.

## V53.2 — live reasoning process
- Gemini calls with thinking now use `streamGenerateContent?alt=sse`: the model's reasoning summary streams LIVE into a purple "thinking" box inside the thinking panel (with the seconds counter) while it works; the answer then appears, with the collapsible "Đã suy nghĩ N giây · Tóm tắt suy luận" kept above it.
- Any non-OK status or streaming error falls back to the previous non-streaming request (user Stop/timeout still aborts). Unit-tested with a mocked SSE stream split mid-UTF-8.
- Limit: the live box shows Gemini's *summarised* thoughts (the API does not expose raw chain-of-thought) and only on the direct Gemini path, not Gateway or other providers.

## V53.3 — fix
- Image aspect ratio hints ("ảnh dọc", "3:2", "vuông") were read from the *enriched* English prompt, so they were ignored and images came out 16:9. Now read from the user's original text. Verified in headless Chromium with a mocked Gemini API (text→image and follow-up edit).
