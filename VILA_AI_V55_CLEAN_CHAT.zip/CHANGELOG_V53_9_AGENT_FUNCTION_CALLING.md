# VILA AI V53.9.0 — Opt-in Function Calling / Agent Mode

## Added
- An opt-in **Agent** toggle in the chat composer; default remains off.
- OpenAI-compatible function calling for configured providers that support tool calls.
- Three server-side allowlisted tools: safe arithmetic calculator, current time by IANA timezone, and text statistics.
- Bounded tool execution loop (default max 4 actual tool executions), structured tool results, malformed-argument handling, and forced final-answer request when the call budget is reached.
- Agent requests use non-streaming responses so tool-call round trips can be resolved before the answer is displayed.
- Agent mode skips the current Gemini adapter because this release implements the OpenAI-compatible tool-call protocol; normal Gemini chat remains available with Agent off.

## Safety and limits
- Tool names are allowlisted; arbitrary shell/code execution, filesystem access, and arbitrary network requests are not exposed.
- Agent mode disables the separate web-search toggle for that request because provider-specific web-search tools and general function calls are not merged in this release.
- Provider must be configured with a compatible model that supports function calling. Unsupported providers/models may reject tool schemas; live provider calls were not performed in the offline test environment.
- Function calling does not make the model inherently more intelligent; it enables bounded, verifiable tool use.
