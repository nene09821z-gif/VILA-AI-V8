# VILA AI V53.8.0 — Experimental DeepSeek App Bridge

- Added an explicit **Bot DS** action that attempts to automate the installed DeepSeek app through Android AccessibilityService.
- Added opt-in accessibility service metadata and user-facing description. The service only acts after the user taps Bot DS and only inspects visible accessibility nodes in the target app.
- Attempts to fill the prompt, press a visible send control/IME action, wait for stable visible response text, and return it to VILA.
- Adds a 90-second timeout and reports errors instead of inventing successful answers.
- Keeps the original Sharesheet button and server-side DeepSeek API/provider fallback.
- Added package visibility declarations for Android 11+.
- Limitations: experimental; no Gradle/Android SDK is installed in the editing environment, and no live-device test was possible. DeepSeek UI updates, login/captcha, inaccessible WebView text, package-name changes, or app policy restrictions can prevent automation.
- Accessibility access is powerful. Enable it only if you understand and consent to the visible UI automation described by Android settings.
