# VILA AI Studio V54.0 — Agent Tools, Memory & Android App

> **Current source version: V54.0.0 (versionCode 69).** The gateway includes a bounded tool-calling loop, calculator/time/text tools, optional web search/fetch, per-user memory and document retrieval, a guarded opt-in code runner, provider fallback, and multi-team reasoning. Provider API calls, cloud deployment, Firebase sign-in, and Android installation still require external configuration and validation. This archive is source code, not a prebuilt APK.

VILA is an Android WebView app that connects to real AI provider APIs. This ZIP contains the source project, not a prebuilt APK.

## V52.0 — Multi-team reasoning, evidence-first search, and dedicated team engines

- Adds task-aware multi-team orchestration: specialist/coder/researcher, independent critic, and synthesizer. Simple prompts stay single-call; complex prompts can be reviewed or deeply orchestrated.
- Adds per-team provider/model engine pinning through environment variables such as `VILA_TEAM_RESEARCHER_PROVIDER`, `VILA_TEAM_CODER_MODEL` and `VILA_TEAM_CRITIC_PROVIDER`. When a pin is missing/unavailable, bounded fallback can use other configured providers. No model weights are bundled or trained by this feature.
- Search-enabled research uses provider web-search tools and only trusts structured citation/grounding metadata for verified-looking source links. A model-written URL is not treated as proof a page was visited. Availability depends on the configured provider/model and key.
- Adds deadline-aware team-stage HTTP timeouts, bounded call counts, weighted rate-limit units, per-user/global concurrency limits, fallback to standard routing, health endpoints, operational counters and graceful shutdown.
- Adds Docker Compose with restart policy/health check as a deployment starting point. This improves recovery from process exit but does **not** by itself guarantee 24/7 service: deploy to a continuously running host, configure HTTPS reverse proxy, Firebase Admin credentials, monitoring, backups and a tested release/rollback procedure.
- Adds a user-triggered, bounded scan of common AI servers on the phone's loopback interface: llama.cpp, Ollama, LM Studio, vLLM and LocalAI. It does not scan the Internet or a LAN and does not discover every private/proprietary gateway.
- `privacy-policy.html` and `account-deletion.html` remain **draft templates** until all placeholders are replaced, the actual data practices are audited, deletion procedures are implemented and verified end-to-end, and pages are hosted publicly over HTTPS.
- Target SDK 36 is set. The APK must still be built by GitHub Actions, tested on real devices and reviewed in Play Console; this source archive is not an approved store release.

### Dedicated engine configuration

The following optional environment variables pin specialists to a provider (`gemini`, `openrouter`, `groq`, `cerebras`, `custom`) and a provider-specific model ID. Keep both set to `auto` for adaptive selection. Never put these keys in the Android app or commit real provider secrets.

| Team | Provider variable | Model variable |
|---|---|---|
| Research/search | `VILA_TEAM_RESEARCHER_PROVIDER` | `VILA_TEAM_RESEARCHER_MODEL` |
| General expert | `VILA_TEAM_EXPERT_PROVIDER` | `VILA_TEAM_EXPERT_MODEL` |
| Coding/debug | `VILA_TEAM_CODER_PROVIDER` | `VILA_TEAM_CODER_MODEL` |
| Vision analysis (image sent once in deep mode) | `VILA_TEAM_VISION_PROVIDER` | `VILA_TEAM_VISION_MODEL` |
| Critic/verifier | `VILA_TEAM_CRITIC_PROVIDER` | `VILA_TEAM_CRITIC_MODEL` |
| Final synthesis | `VILA_TEAM_SYNTHESIZER_PROVIDER` | `VILA_TEAM_SYNTHESIZER_MODEL` |

### Run locally / deploy with Compose

1. Use Node.js 20+ and run `cd server && npm install && npm test`.
2. Copy `.env.production.example` to a private `.env`; enter the real Firebase project ID, service-account credentials through a secret manager where possible, and only the provider API keys you own. Configure CORS for the app origin actually observed in production. Do not commit `.env`.
3. Review `compose.yaml`; it binds to loopback. Put a properly configured HTTPS reverse proxy in front for external users, and use a persistent host. For more than one replica, replace the in-memory counters/circuit state with shared Redis/database-backed coordination before relying on global limits or billing.
4. Run `docker compose up -d --build`, then verify `/health/live`, `/health/ready`, authenticated `/v1/gateway/status`, provider keys, and deep-mode calls. Set alerts on elevated fallback/error rates and provider quota failures.
5. Run `.github/workflows/main.yml` and test the generated APK on actual supported Android versions. Do not publish until privacy policy, Data safety, account deletion, app signing, terms/contact and provider licensing are complete.

See `VILA_AI_V52_TECHNOLOGY_MAP.md`, `CHANGELOG_V52_AI_TEAMS.md`, and `PLAY_STORE_READINESS_V52.md` for capabilities, explicit limits, and release blockers.


## V51.1 — audited baseline (historical release source)

- Historical Android metadata was `51.1.0` (`versionCode 59`). The current project metadata is V54.0.0 (`versionCode 69`); see `CHANGELOG_V54_0_REAL_TOOLS.md` and `VILA_AI_FULL_SYSTEM_SETUP_V54.md`.
- The audited Android source encrypts provider keys, Gemini key, GitHub token and Agent Server token with AES-GCM using an Android Keystore-managed key; readable legacy preferences are migrated when they can be read and safely encrypted.
- The DeepSeek local connector can discover and query a running OpenAI-compatible local server without requiring a cloud API key. VILA does not ship model weights or automatically start llama.cpp/Ollama.
- Production Gateway refuses unauthenticated mode and wildcard CORS; JSON request errors use appropriate 400/413 responses.
- Historical release checks are retained; current checks include `node --test server/test/*.test.js` plus scripts under `scripts/`. Android Gradle build, Firebase live login, hosted APIs and local inference still need CI/real-device verification.

## V46 — Login screen and classic device Google account picker

- The first-run gate is simplified to a clean **Đăng nhập** screen with Email, Mật khẩu, Đăng nhập, Google, Tạo tài khoản and Quên mật khẩu. The small explanatory paragraphs have been removed; status text appears only when an operation needs to report a result or error.
- On Android, **Tiếp tục với Google** calls native Android Credential Manager using `GetGoogleIdOption` with authorized-account filtering disabled so the account picker can offer Google accounts available on the device. Authentication completes through Firebase Auth; the UI does not report success until Firebase confirms it.
- Email fields require a complete email address. Existing-account login accepts the saved password exactly as entered. New passwords can use letters, numbers and symbols and do **not** need to be six digits; Firebase's default policy still requires at least six characters for new accounts.
- Source regression tests cover the new login form and native Google flow. This source ZIP is not a prebuilt APK; the Android build and real device sign-in must be confirmed by GitHub Actions and on the target phone.


## New in V41

- Firebase email/password registration and sign-in, password-reset email, and sign-out use Firebase Android Authentication when the native Firebase Android config is present.
- Google sign-in on Android uses Credential Manager to select a Google account and exchange its ID token with Firebase Auth. This avoids relying on embedded-WebView Google OAuth redirects.
- The project supports two additional Firebase client settings: `androidAppId` and `webClientId`. Configure them through GitHub Actions secrets or `app/src/main/assets/firebase-config.js`.
- Real sign-in requires a Firebase project with Email/Password and Google providers enabled. Google sign-in additionally requires registering package `com.vila.ai`, adding the signing certificate SHA-1, and supplying the OAuth Web client ID.
- Browser preview retains Firebase Web SDK authentication fallback; an Android APK with incomplete native settings reports that Google sign-in needs setup instead of pretending it succeeded.
- V51 stores Gemini, provider API keys, and GitHub tokens encrypted with AES-GCM using a key held by Android Keystore. On Android, existing plaintext entries are migrated when they can be read and encrypted successfully; browser preview still uses browser localStorage and is not equivalent to Android Keystore protection.


## V42 — AI Gateway and central routing

- The **AI Gateway** screen adds a Multi-API dashboard, provider/model scan, deep diagnostic (chat probe can consume provider quota), health check, request statistics, optional server routing, and an app-update check endpoint.
- The optional Node.js backend exposes a normalized OpenAI-style `/v1/chat/completions` API, model discovery, per-user rate limits, timeouts, bounded retry/fallback, task-aware provider ranking, and Firebase Admin ID-token verification in production. Supported server-side adapters are Gemini REST and OpenAI-compatible endpoints (OpenRouter, Groq, Cerebras, Custom).
- The backend stores provider secrets only in environment variables/secret manager. The browser/app sends Firebase ID tokens to the backend and does not send server provider keys. Direct per-user provider settings remain available when server routing is disabled.
- The diagnostic engine reports endpoint/model state and handles recoverable upstream failures; it does not edit unknown source code or perform unreviewed destructive repairs. Server usage figures are in-memory operational counters, not a durable invoice/accounting ledger.
- The app version endpoint `/v1/app/version` can report a configured release version and HTTPS release page. Android cannot silently install APK updates; the app can direct users to the release page and the OS installer still requires confirmation. Configure `VILA_APP_RELEASE_URL` on the backend to enable that hand-off.
- Automated source regressions and backend engine tests are run in GitHub Actions. A local source test does not demonstrate that upstream API keys, Firebase provider settings, external network access, or every model are live.

The supplied Android config is retained at `app/google-services.json`; the app runtime uses `app/src/main/assets/firebase-config.js` and the native FirebaseOptions bridge. See `README_V42_AI_GATEWAY.md` and `server/README.md` for deployment and Firebase setup. The provided Firebase Android config is prefilled for project `vila-studio`; the current `google-services.json` includes the OAuth Web client ID and the workflow copies it into the native config automatically. Google sign-in still requires the installed APK signing-certificate SHA-1 to be registered in Firebase Console. Browser preview also needs the separate Firebase Web App `appId`.



## V47 — Powerful AI Gateway

- Adds per-provider circuit breaking: after repeated transient failures a provider is paused briefly and then tested with one half-open probe.
- Fixes auto fallback across providers for provider-specific authentication/quota errors and availability failures, while avoiding retries for invalid request payloads.
- Adds per-account concurrent-request limits, a cap on auto-routing attempts, server-generated request IDs, and metadata-only request logs that never write prompts or bearer tokens.
- Adds an authenticated Gateway reliability panel backed by `GET /v1/gateway/status`, including provider circuit state and active limits.
- Circuit state and counters remain per-process and reset on restart; do not use them as a durable billing ledger or shared rate limit for multiple replicas.

## Adaptive models (inherited from V39)

- OpenRouter's public `/models` catalog can be scanned without entering a key so you can see the current text-capable catalog and models whose live metadata identifies them as free. A valid OpenRouter API key is still required to send chat requests.
- Gemini model discovery marks documented free-tier families when the live model endpoint exposes them. Free-tier eligibility is not a promise of unlimited quota; availability, account restrictions, region and rate limits remain controlled by the provider.
- Custom/OpenAI-compatible endpoints remain supported: choose **Custom API**, enter the provider's Base URL and API key, then tap **Tải model mới nhất từ API**. This works only if that endpoint exposes a compatible `/models` listing and chat-completions endpoint. Some providers require a provider-specific API protocol or CORS/network permissions and may not work as an arbitrary OpenAI-compatible endpoint.
- The model catalog is cached on-device so the last successful list remains visible when temporarily offline. A successful refresh replaces that cached catalog.
- Android Internet permission and the foreground progress notification are already enabled. The foreground service is intended to keep an active request visible while the user switches apps; Android battery optimization, OEM task killers, network interruptions, provider outages and service limits mean no app can guarantee uninterrupted 24/7 execution on every device.

## Build

Use GitHub Actions: push the extracted project to a GitHub repository, open **Actions**, choose **VILA AI - Android Build and Verify**, then **Run workflow**. Download the debug APK artifact for installation and testing. Release APK signing requires Android signing secrets; without them, the release APK is unsigned.

See `README_GITHUB_BUILD_V28.md` for the detailed workflow. The workflow runs offline source/runtime checks and Android Gradle builds. A green result demonstrates that the selected build completed in CI, not that every external provider or API key works.

## Provider setup

1. Open **Settings / API**.
2. Choose Gemini, Groq, Cerebras, OpenRouter, or Custom API.
3. Enter the endpoint's API key (except when only scanning OpenRouter's public catalog).
4. For Custom API, enter its Base URL. The endpoint must support the protocol shown by that provider.
5. Tap **Tải model mới nhất từ API**, then choose a model. Use **Kiểm tra kết nối** to verify chat access.

Never paste API keys into public issue reports or share screenshots that reveal a key. On Android, API keys, GitHub tokens, and the Agent Server token are encrypted at rest with AES-GCM using an Android Keystore key. The browser preview uses localStorage and does not receive that native protection. Uninstalling the app or clearing app data can remove them.

## Model status accuracy

- OpenRouter `:free` suffix and price metadata are treated as catalog indicators, not a guarantee of uninterrupted availability.
- For Gemini, model availability is read from the official authenticated model list when synced. Model-specific free-tier eligibility and quota are controlled by Google's current project/account policies.
- Groq, Cerebras and custom gateways expose the model IDs available to their API credentials; the app does not assume that an ID listed elsewhere is enabled for your account.
- No model is downloaded into the phone by this feature. It discovers hosted API model IDs; downloading/running local model weights is a separate feature with substantial device-storage and RAM requirements.

## Firebase account setup (V41)

Follow `FIREBASE_SETUP_V41.txt`. GitHub Actions supports these additional secrets for native Google sign-in:

- `FIREBASE_ANDROID_APP_ID`: `mobilesdk_app_id` from the Firebase Android app configuration (package must be `com.vila.ai`).
- `FIREBASE_WEB_CLIENT_ID`: OAuth 2.0 client ID for a Web application, ending in `.apps.googleusercontent.com`.

The existing web configuration secrets remain `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_STORAGE_BUCKET`, `FIREBASE_MESSAGING_SENDER_ID`, and `FIREBASE_APP_ID`. The workflow fills Android-native Firebase fields from `app/google-services.json` by default and lets defined GitHub Secrets override them. Browser preview still needs the separate Firebase Web App `appId`. If native Android values are absent, browser email auth may still work when web config is valid, while Google sign-in in the APK displays setup guidance.

Native Google sign-in also depends on Firebase Console provider settings and the SHA-1 of the certificate that signs the installed APK. The old prebuilt APK supplied in the incoming ZIP has a different signing SHA-1 from the Android OAuth fingerprint in `google-services.json`, so build a fresh APK and make sure its signer SHA-1 is registered in Firebase. CI writes `output/sha1-fingerprint.txt`; prefer a release APK signed with a persistent keystore for repeatable tests. Setup steps are in `FIREBASE_SETUP_V41.txt`.


## V48 media/file output fixes

Image requests now route to the image API; video requests use Veo asynchronous generation and polling. Edited files are attached individually with their real file extensions. Full project ZIP is generated automatically only when requested; the ZIP button remains available for full exports. Live generation still requires valid Gemini/Veo access and quota. See `CHANGELOG_V48_MEDIA_AND_ARTIFACT_FIX.md`.


## V49 — Chat reliability and Gateway connection (previous release)

Android version: `49.0.0` (`versionCode 56`). This ZIP is source code, not a prebuilt APK. Run GitHub Actions to verify the actual Android Gradle build.

- Fixed the thinking/status panel lookup so the panel itself is updated, not only its descendants.
- Direct Gemini fallback now shows the model currently being tried instead of leaving the same status visible.
- Gateway requests now have a whole-request deadline covering response streaming, always release their abort controller, report connection errors clearly, and reject empty/malformed responses instead of appearing to hang silently.
- Synchronized Android, Gateway server, and app-update metadata to `49.0.0`.
- Gateway is source included in this ZIP, but it is **not automatically deployed**. Configure provider API keys and Firebase Admin credentials in the hosting provider's secret settings, deploy over HTTPS, then enter the deployed URL in the app's AI Gateway panel.

See `CHANGELOG_V49_GATEWAY_RELIABILITY.md` and `server/README.md`.


## V50 — Gateway panel and live model discovery (previous release)

Android version: `50.0.0` (`versionCode 57`). This is source code, not a prebuilt APK. Run GitHub Actions to verify the actual Android Gradle build.

- Fixed the Gateway modal sizing: its content now fills the remaining flex height and scrolls independently on compact Android screens. The thinking/status card also expands to show all rows instead of being paint-contained and clipped by some WebViews.
- Added live model catalogue discovery from server-configured providers. Gemini discovery follows paginated `nextPageToken`; OpenAI-compatible endpoints (including OpenRouter, Groq, Cerebras and Custom when configured) expose their available `/models` IDs. The app does not invent IDs if a provider's live catalog fails.
- Added catalogue search, context/provider metadata, and the ability to pin an exact live server model for Gateway chat or switch back to automatic routing.
- Metadata was synchronized to `50.0.0`; the server remains source-only until deployed with provider API keys and Firebase Admin credentials stored in hosting secrets.

See `CHANGELOG_V50_GATEWAY_UI_LIVE_MODELS.md` and `server/README.md`.

## V51 — reliability, security and DeepSeek local connector

Android version: `52.0.0` (`versionCode 60`). This ZIP contains source code, not a prebuilt APK. GitHub Actions must complete before the APK can be considered build-verified.

- Added the DeepSeek-R1 Local preset for an OpenAI-compatible local `llama.cpp`/Ollama-style server. The model runtime and weights are **not** bundled, installed, or launched by VILA; the user must run a compatible local server first.
- Synchronized Android, app-update checker, Gateway backend and package metadata to `52.0.0`.
- Production Gateway now fails closed for `CORS_ORIGINS=*`; when production CORS is omitted, browser cross-origin requests are denied. Local development retains the wildcard example.
- Request parsing now returns clearer `400`/`413` responses for invalid JSON, aborted requests and oversized payloads instead of misreporting these client errors as `500`.
- Added backend regression tests for production CORS/auth settings and request-error classification.

See `CHANGELOG_V51_COMPREHENSIVE_FIXES.md`, `DEEPSEEK_R1_LOCAL_SETUP.md`, and `server/README.md`.
