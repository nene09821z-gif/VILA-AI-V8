# VILA AI V53.4 — Audit fixes (no version bump)

All fixes were reproduced before changing code; each has a regression test
(`server/test/audit-v53-4.test.js`, `scripts/test-v53-4-audit.js`).

## Bugs fixed
1. **Multi-team mode never ran (server).** `server.js` called `containsImagePayload` without importing it, so every
   reviewed/deep request threw `ReferenceError` and silently fell back to a single call (`X-VILA-Team-Mode: fallback-single`).
   Verified with a mocked-provider harness: before = fallback, after = `coder:ok,critic:ok,synthesizer:ok`.
   A wiring test now fails whenever a teams/engine helper is used but not imported.
2. **Long streams were cut off (server).** The upstream timeout (default 45 s) also covered the streaming body. Now it only
   covers time-to-headers; streams use a 60 s idle watchdog (`UPSTREAM_STREAM_IDLE_MS`). On a mid-stream error the SSE is
   closed with `[DONE]`; on client disconnect the upstream request is cancelled.
3. **Answer truncation (server).** The “unverified references” stripper matched any line starting with `Sources…`/`References…`
   and deleted everything after it. It now only cuts a line that is *just* a reference heading.
4. **agent-server build could not find nested projects.** `\(` inside a JS template literal reached bash as `(` → syntax
   error → fallback to the wrong root. Now `find` is called directly (no shell). Invalid JSON now returns 400, and the chat
   stream stops when the client disconnects.
5. **XSS / attribute injection (web UI).** `escapeHtml` did not escape quotes but is used inside `title="…"` of web-source
   chips built from model/web text, in a WebView that exposes the native `Android` bridge. Now escapes `" '` too.
6. **Android:** links leaving the WebView are limited to http/https/mailto/tel (no `intent:`, `file:`, `content:`…);
   the loopback asset server no longer allocates up to 64 MB per connection for an unused request body (cap 1 MB, streamed drain).

7. **Local model discovery always failed (web UI).** `localProtocol` was declared with `let` inside an `else` block but read after it,
   so every scan of Ollama / llama.cpp / LM Studio / DeepSeek-local threw `ReferenceError`. Found by linting all page scripts together
   (`no-undef`); runtime test added.

8. **Android file names:** `saveTextFile`, `saveBase64File` and `downloadUrl` now share `safeFileName()` (strips separators,
   control characters and leading dots; blank/dots-only names fall back to a default). Previously an empty name made the
   MediaStore insert fail. The helper was compiled and run with `javac` against hostile inputs.

## Improvements
- Circuit breaker: a provider in `auth-error` is re-probed once per `authRetryMs` (default 5 min) instead of staying skipped
  until restart after a transient 401/403.
- **Rate-limit aware routing:** upstream `Retry-After` (seconds or date) is parsed. A short wait (≤ 2 s) triggers one retry on the same
  provider; a longer one opens that provider's circuit immediately and fails over. Verified with a mocked provider: 429+`Retry-After: 1`
  → retried after ~1.1 s and succeeded; 429+`Retry-After: 30` → instant failover. `/v1/gateway/usage` now reports `retryCount`.
- Task classifier: bare words `project`/`build` no longer route ordinary chat to the coding model/team (explicit test added).
- Whole-page lint (all inline + asset scripts in load order, ~20 rule groups) is clean apart from the bug fixed above.
- Team plan is computed once per request (was serialising up to ~18 MB of conversation twice).
- Markdown citation links survive URLs containing `(` `)`.
- CI runs the new audit script.

## Not verified here
`npm install` was unreachable in the audit sandbox, so the real Express server and the Gradle/Android build were not run.
The gateway was exercised with stub `express/cors/helmet/firebase-admin` modules and a mocked `fetch`.
Run `cd server && npm i && npm test` and the GitHub Actions build to confirm.
