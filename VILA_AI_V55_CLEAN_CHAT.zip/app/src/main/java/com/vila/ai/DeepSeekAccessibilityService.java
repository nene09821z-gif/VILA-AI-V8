package com.vila.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Experimental, user-triggered bridge for the installed DeepSeek Android app.
 * It only works on visible accessibility nodes. DeepSeek UI changes can break automation.
 * No private app storage, auth token, hidden API, or network traffic is accessed.
 */
public final class DeepSeekAccessibilityService extends AccessibilityService {
    private static final String TARGET = "com.deepseek.chat";
    private static final String PREFS = "vila_deepseek_bridge";
    private static final String KEY_PROMPT = "pending_prompt";
    private static volatile DeepSeekAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String prompt = "";
    private String lastCandidate = "";
    private String sentPackage = "";
    private String baselineVisibleText = "";
    private long startedAt = 0L;
    private long lastCandidateAt = 0L;
    private boolean sent = false;
    private boolean finished = true;

    public static boolean isEnabled(Context c) {
        String enabled = android.provider.Settings.Secure.getString(c.getContentResolver(), android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.toLowerCase(Locale.ROOT).contains(c.getPackageName().toLowerCase(Locale.ROOT) + "/" + DeepSeekAccessibilityService.class.getName().toLowerCase(Locale.ROOT));
    }

    public static boolean start(Context c, String text) {
        String p = text == null ? "" : text.trim();
        if (p.isEmpty()) return false;
        if (!isEnabled(c)) {
            Intent settings = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
            settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(settings);
            Toast.makeText(c, "Bật ‘VILA DeepSeek Bridge’ trong Trợ năng, rồi quay lại VILA và bấm lại.", Toast.LENGTH_LONG).show();
            return false;
        }
        Intent launch = c.getPackageManager().getLaunchIntentForPackage(TARGET);
        if (launch == null) launch = c.getPackageManager().getLaunchIntentForPackage("com.deepseek.ai");
        if (launch == null) {
            Toast.makeText(c, "Không tìm thấy ứng dụng DeepSeek chính thức đã cài. Hãy cài/cập nhật DeepSeek rồi thử lại.", Toast.LENGTH_LONG).show();
            return false;
        }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_PROMPT, p).apply();
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(launch);
        Toast.makeText(c, "Đang thử gửi câu hỏi sang DeepSeek…", Toast.LENGTH_SHORT).show();
        if (instance != null) instance.begin(p);
        return true;
    }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED | AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED | AccessibilityEvent.TYPE_VIEW_SCROLLED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            setServiceInfo(info);
        }
    }

    private void begin(String p) {
        prompt = p;
        sent = false;
        finished = false;
        lastCandidate = "";
        sentPackage = "";
        baselineVisibleText = "";
        startedAt = SystemClock.elapsedRealtime();
        lastCandidateAt = 0L;
        handler.removeCallbacks(timeout);
        handler.postDelayed(timeout, 800L);
    }

    private final Runnable timeout = new Runnable() {
        @Override public void run() {
            if (finished) return;
            long elapsed = SystemClock.elapsedRealtime() - startedAt;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
                if (isTarget(pkg)) {
                    if (!sent) trySend(root);
                    else tryCapture(root);
                }
                root.recycle();
            }
            if (elapsed > 90000L) {
                finish("", "Hết thời gian chờ DeepSeek. Giao diện có thể đã thay đổi hoặc không cho phép tự động hóa.");
                return;
            }
            handler.postDelayed(this, 700L);
        }
    };

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || finished) return;
        CharSequence packageName = event.getPackageName();
        String pkg = packageName == null ? "" : packageName.toString();
        if (!isTarget(pkg)) return;
        if (prompt.isEmpty()) {
            String pending = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PROMPT, "");
            if (!pending.isEmpty()) begin(pending);
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            if (!sent) trySend(root); else tryCapture(root);
        } finally { root.recycle(); }
    }

    private boolean isTarget(String pkg) { return pkg != null && (pkg.equals(TARGET) || pkg.equals("com.deepseek.ai")); }

    private void trySend(AccessibilityNodeInfo root) {
        if (prompt.isEmpty() || sent) return;
        if (baselineVisibleText.isEmpty()) baselineVisibleText = collectVisibleText(root);
        AccessibilityNodeInfo edit = findEditable(root);
        if (edit == null) return;
        android.os.Bundle args = new android.os.Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, prompt);
        boolean set = edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        if (!set) {
            ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("VILA prompt", prompt));
                edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                edit.performAction(AccessibilityNodeInfo.ACTION_PASTE);
            }
        }
        AccessibilityNodeInfo send = findSendButton(root);
        if (send != null) {
            boolean clicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            send.recycle();
            if (clicked) {
                sent = true;
                sentPackage = root.getPackageName() == null ? TARGET : root.getPackageName().toString();
                lastCandidateAt = SystemClock.elapsedRealtime();
                return;
            }
        }
        // Avoid repeated accidental sends. If the button was not found, try IME action once and wait for UI change.
        if (set && android.os.Build.VERSION.SDK_INT >= 30) {
            boolean submitted = edit.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
            if (submitted) {
                sent = true;
                sentPackage = root.getPackageName() == null ? TARGET : root.getPackageName().toString();
                lastCandidateAt = SystemClock.elapsedRealtime();
            }
        }
        edit.recycle();
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable() && node.isEnabled()) return AccessibilityNodeInfo.obtain(node);
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child=node.getChild(i);
            AccessibilityNodeInfo found=findEditable(child);
            if (child!=null) child.recycle();
            if(found!=null)return found;
        }
        return null;
    }

    private AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String t = textOf(node).toLowerCase(Locale.ROOT);
        String id = node.getViewIdResourceName() == null ? "" : node.getViewIdResourceName().toLowerCase(Locale.ROOT);
        boolean send = t.equals("send") || t.equals("发送") || t.equals("发送消息") || t.equals("send message") || t.equals("submit") || id.contains("send") || id.contains("submit");
        if (send && node.isEnabled() && (node.isClickable() || node.getParent() != null)) {
            AccessibilityNodeInfo result = AccessibilityNodeInfo.obtain(node);
            if (!result.isClickable() && result.getParent() != null) {
                AccessibilityNodeInfo parent = result.getParent();
                result.recycle();
                result = parent;
            }
            return result;
        }
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child=node.getChild(i);
            AccessibilityNodeInfo found=findSendButton(child);
            if(child!=null)child.recycle();
            if(found!=null)return found;
        }
        return null;
    }

    private String textOf(AccessibilityNodeInfo n) {
        StringBuilder b = new StringBuilder();
        if (n.getText()!=null) b.append(n.getText()).append(' ');
        if (n.getContentDescription()!=null) b.append(n.getContentDescription()).append(' ');
        return b.toString().trim();
    }

    private void tryCapture(AccessibilityNodeInfo root) {
        long now = SystemClock.elapsedRealtime();
        String candidate = removeBaselineLines(collectVisibleText(root));
        if (candidate.length() < 32 || candidate.equals(prompt) || candidate.contains(prompt)) return;
        String low = candidate.toLowerCase(Locale.ROOT);
        if (low.contains("new chat") && candidate.length() < 80) return;
        if (!candidate.equals(lastCandidate)) {
            lastCandidate = candidate;
            lastCandidateAt = now;
            return;
        }
        // Require stable visible text after sending; never report an empty/unchanged prompt as an answer.
        if (now - lastCandidateAt >= 2600L && now - startedAt >= 4500L) {
            finish(candidate, "");
        }
    }

    private String collectVisibleText(AccessibilityNodeInfo root) {
        List<String> texts = new ArrayList<>();
        collect(root, texts, 0);
        List<String> cleaned = new ArrayList<>();
        for (String s : texts) {
            String t = s.replaceAll("\\s+", " ").trim();
            if (t.length() < 18 || t.equals(prompt) || t.equalsIgnoreCase("DeepSeek") || t.equalsIgnoreCase("copy") || t.equalsIgnoreCase("regenerate")) continue;
            if (!cleaned.contains(t)) cleaned.add(t);
        }
        // The full visible page is useful where DeepSeek exposes its conversation as a WebView tree.
        StringBuilder joinedBuilder = new StringBuilder();
        for (String t : cleaned) {
            if (joinedBuilder.length() > 0) joinedBuilder.append('\n');
            joinedBuilder.append(t);
            if (joinedBuilder.length() > 12000) break;
        }
        String joined = joinedBuilder.toString();
        if (joined.length() > 12000) joined = joined.substring(joined.length()-12000);
        return joined;
    }

    private String removeBaselineLines(String candidate) {
        if (candidate == null || candidate.isEmpty()) return "";
        java.util.Set<String> baseline = new java.util.HashSet<>();
        for (String line : baselineVisibleText.split("\n")) {
            String t = line.trim();
            if (t.length() >= 8) baseline.add(t);
        }
        List<String> delta = new ArrayList<>();
        for (String line : candidate.split("\n")) {
            String t = line.trim();
            if (t.length() < 18 || t.equals(prompt) || t.contains(prompt) || baseline.contains(t)) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.equals("deepseek") || low.equals("new chat") || low.equals("copy") || low.equals("regenerate") || low.equals("share")) continue;
            if (!delta.contains(t)) delta.add(t);
        }
        StringBuilder out = new StringBuilder();
        for (String line : delta) {
            if (out.length() > 0) out.append('\n');
            out.append(line);
        }
        return out.toString();
    }

    private void collect(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || depth > 35) return;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        if (text != null) out.add(text.toString());
        if (desc != null) out.add(desc.toString());
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child=node.getChild(i);
            collect(child,out,depth+1);
            if(child!=null)child.recycle();
        }
    }

    private void finish(String answer, String error) {
        if (finished) return;
        finished = true;
        handler.removeCallbacks(timeout);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_PROMPT).apply();
        Intent back = new Intent(this, MainActivity.class);
        back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        back.putExtra("vila_deepseek_prompt", prompt);
        back.putExtra("vila_deepseek_answer", answer == null ? "" : answer);
        back.putExtra("vila_deepseek_error", error == null ? "" : error);
        startActivity(back);
        prompt = "";
    }

    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        handler.removeCallbacks(timeout);
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
