package com.vila.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.app.DownloadManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.content.ContentValues;
import android.os.Environment;
import android.widget.*;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import android.speech.tts.UtteranceProgressListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.util.Base64;
import org.json.JSONObject;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    Uri camUri;
    LocalProxy proxy;
    android.content.SharedPreferences prefs;
    SpeechRecognizer speechRecognizer;
    TextToSpeech textToSpeech;
    private FirebaseAuth vilaFirebaseAuth;
    private FirebaseAuth.AuthStateListener vilaFirebaseAuthStateListener;
    private CredentialManager vilaCredentialManager;
    private JSONObject vilaFirebaseConfig = new JSONObject();
    private String vilaFirebaseInitError = "Firebase chưa được cấu hình cho Android.";
    private String vilaFirebaseWebClientId = "";
    // V44: when Google sign-in collides with an existing email/password account, Firebase hands back
    // the Google credential so it can be linked after the user proves ownership with their password.
    private AuthCredential vilaPendingGoogleCredential;
    private String vilaPendingGoogleEmail = "";
    static final int PORT = 18787;
    static final int REQ_NOTIFICATIONS = 1001;
    // V38 notification state. appVisible is false while the activity is stopped (user is in another app).
    volatile boolean appVisible = true;
    volatile boolean requestActive = false;
    volatile boolean keepAliveRunning = false;
    volatile String requestTitle = "VILA đang suy luận…";
    volatile String requestText = "";
    // Secrets are encrypted with an AES/GCM key protected by Android Keystore.
    // Plaintext preferences are read only for one-time migration from older VILA builds.
    static final String GITHUB_TOKEN_PREF = "github_token";
    static final String GEMINI_KEY_PREF = "gemini_api_key";
    static final String GEMINI_BASE_URL_PREF = "gemini_base_url";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vila", MODE_PRIVATE);
        // V54: GitHub token support was removed; wipe any token stored by older versions.
        try { clearSecretPreference(GITHUB_TOKEN_PREF, "github_token_plain"); } catch (Exception ignored) {}
        initVilaFirebaseAuth();
        VilaNotifier.ensureChannels(this);
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                int lang = textToSpeech.setLanguage(new Locale("vi", "VN"));
                textToSpeech.setSpeechRate(0.94f);
                textToSpeech.setPitch(1.02f);
                textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { evaluateVoice("tts_start", ""); }
                    @Override public void onDone(String utteranceId) { evaluateVoice("tts_done", ""); }
                    @Override public void onError(String utteranceId) { evaluateVoice("tts_error", ""); }
                });
            }
        });
        proxy = new LocalProxy(this, PORT);
        proxy.bind();
        proxy.onBindFailed = () -> runOnUiThread(() -> {
            try { Toast.makeText(MainActivity.this, "Không thể khởi động máy chủ cục bộ của VILA (cổng đang bận). Đang thử lại…", Toast.LENGTH_LONG).show(); } catch (Exception ignored) {}
            retryLoadLocalPage();
        });
        proxy.start();
        web = new WebView(this);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setBackgroundColor(Color.rgb(3,7,18));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setOffscreenPreRaster(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            // Only the local app (and Google/Firebase sign-in) may load inside the WebView that owns the JS bridge.
            private boolean openExternal(String url) {
                if (url == null) return false;
                Uri u = Uri.parse(url);
                String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
                String path = u.getPath() == null ? "" : u.getPath();
                boolean local = sc.equals("http") && (host.equals("127.0.0.1") || host.equals("localhost")) && u.getPort() == PORT;
                boolean auth = sc.equals("https") && (host.equals("accounts.google.com") || (host.endsWith(".firebaseapp.com") && path.startsWith("/__/auth/")));
                if (local || auth || sc.equals("blob") || sc.equals("data") || sc.equals("about") || sc.equals("javascript")) return false;
                // Links come from model output and web search, so they are untrusted. Hand only ordinary
                // user-facing schemes to other apps; intent:, file:, content:, android-app: etc. could
                // otherwise start arbitrary activities or expose local files.
                boolean safeExternal = sc.equals("http") || sc.equals("https") || sc.equals("mailto") || sc.equals("tel");
                if (!safeExternal) return true;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return openExternal(url); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return openExternal(r.getUrl().toString()); }
            // The local proxy server can briefly refuse connections right after app start (the
            // background accept-loop thread hasn't finished its own startup yet, or a prior bind
            // attempt was still retrying) or recycle its socket if the process was backgrounded
            // and trimmed. Without this, that first failed connection left the WebView showing a
            // bare "ERR_CONNECTION_REFUSED" page with no way back in short of a manual app restart.
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r != null && r.isForMainFrame()) retryLoadLocalPage();
            }
            @Override public void onPageFinished(WebView v, String url) { localPageRetryCount = 0; }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (params.isCaptureEnabled()) {
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.CAMERA"}, 1003);
                        Toast.makeText(MainActivity.this, "Hãy cấp quyền Camera rồi bấm Chụp ảnh lại", Toast.LENGTH_LONG).show();
                        callback.onReceiveValue(null); return true;
                    }
                    try {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "VILA_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        cam.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        if (fileCallback != null) { try { fileCallback.onReceiveValue(null); } catch (Exception ignored) {} fileCallback = null; }
                        fileCallback = callback; startActivityForResult(cam, 2002); return true;
                    } catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return true; }
                }
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                if (fileCallback != null) { try { fileCallback.onReceiveValue(null); } catch (Exception ignored) {} fileCallback = null; }
                try { startActivityForResult(intent, 2001); fileCallback = callback; return true; }
                catch (Exception e) { callback.onReceiveValue(null); return false; }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                req.setDescription("VILA AI đang tải file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
                dm.enqueue(req);
                Toast.makeText(this, "Đang tải file vào thư mục Downloads", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Không thể tải file", Toast.LENGTH_SHORT).show(); }
        });
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(web);
        web.loadUrl("http://127.0.0.1:" + PORT + "/");
        if (Build.VERSION.SDK_INT >= 23) {
            String[] want = Build.VERSION.SDK_INT >= 33
                ? new String[]{"android.permission.CAMERA", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"}
                : (Build.VERSION.SDK_INT <= 28
                    ? new String[]{"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}
                    : new String[]{"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE"});
            ArrayList<String> need = new ArrayList<>();
            for (String p : want) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
            if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1004);
        }
    }


    // ---- V41 native Firebase Authentication. Configuration is read from the bundled client config.
    private void initVilaFirebaseAuth() {
        try {
            String source;
            try (InputStream in = getAssets().open("firebase-config.js"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[4096]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                source = out.toString("UTF-8");
            }
            int marker = source.indexOf("window.VILA_FIREBASE_CONFIG");
            int eq = marker >= 0 ? source.indexOf('=', marker) : -1;
            int start = eq >= 0 ? source.indexOf('{', eq) : -1;
            int end = source.lastIndexOf('}');
            if (start < 0 || end < start) {
                vilaFirebaseInitError = "Không đọc được firebase-config.js.";
                return;
            }
            vilaFirebaseConfig = new JSONObject(source.substring(start, end + 1));
            String apiKey = vilaFirebaseConfig.optString("apiKey", "").trim();
            String projectId = vilaFirebaseConfig.optString("projectId", "").trim();
            String senderId = vilaFirebaseConfig.optString("messagingSenderId", "").trim();
            String androidAppId = vilaFirebaseConfig.optString("androidAppId", "").trim();
            vilaFirebaseWebClientId = vilaFirebaseConfig.optString("webClientId", "").trim();
            if (apiKey.isEmpty() || projectId.isEmpty() || senderId.isEmpty() || androidAppId.isEmpty()) {
                vilaFirebaseInitError = "Thiếu apiKey, projectId, messagingSenderId hoặc androidAppId trong firebase-config.js.";
                return;
            }
            FirebaseOptions.Builder options = new FirebaseOptions.Builder()
                    .setApiKey(apiKey)
                    .setApplicationId(androidAppId)
                    .setProjectId(projectId)
                    .setGcmSenderId(senderId);
            String storageBucket = vilaFirebaseConfig.optString("storageBucket", "").trim();
            if (!storageBucket.isEmpty()) options.setStorageBucket(storageBucket);
            FirebaseApp app;
            try { app = FirebaseApp.getInstance(); }
            catch (IllegalStateException missingDefaultApp) { app = FirebaseApp.initializeApp(this, options.build()); }
            if (app == null) {
                vilaFirebaseInitError = "Firebase không thể khởi tạo. Kiểm tra cấu hình dự án.";
                return;
            }
            vilaFirebaseAuth = FirebaseAuth.getInstance(app);
            vilaCredentialManager = CredentialManager.create(this);
            vilaFirebaseAuthStateListener = auth -> {
                JSONObject user = vilaFirebaseUserJson();
                String userValue = user == null ? "null" : user.toString();
                String js = "window.onNativeFirebaseAuthStateChanged && window.onNativeFirebaseAuthStateChanged(" + userValue + ");";
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
            };
            vilaFirebaseAuth.addAuthStateListener(vilaFirebaseAuthStateListener);
            vilaFirebaseInitError = "";
        } catch (Exception e) {
            vilaFirebaseAuth = null;
            vilaFirebaseInitError = "Không thể khởi tạo Firebase. Kiểm tra Firebase client config.";
            android.util.Log.e("VILA-Firebase", "Firebase init failed", e);
        }
    }

    private JSONObject vilaFirebaseUserJson() {
        try {
            FirebaseUser user = vilaFirebaseAuth == null ? null : vilaFirebaseAuth.getCurrentUser();
            if (user == null) return null;
            JSONObject value = new JSONObject();
            value.put("uid", user.getUid());
            value.put("email", user.getEmail() == null ? "" : user.getEmail());
            value.put("displayName", user.getDisplayName() == null ? "" : user.getDisplayName());
            value.put("photoURL", user.getPhotoUrl() == null ? "" : user.getPhotoUrl().toString());
            value.put("emailVerified", user.isEmailVerified());
            return value;
        } catch (Exception ignored) { return null; }
    }

    private String vilaFirebaseStateJson() {
        JSONObject state = new JSONObject();
        try {
            state.put("ready", vilaFirebaseAuth != null);
            state.put("error", vilaFirebaseAuth != null ? "" : vilaFirebaseInitError);
            state.put("webClientIdSet", !vilaFirebaseWebClientId.isEmpty());
            JSONObject user = vilaFirebaseUserJson();
            state.put("user", user == null ? JSONObject.NULL : user);
        } catch (Exception ignored) {}
        return state.toString();
    }

    private void sendVilaFirebaseResult(String action, boolean success, String message) {
        JSONObject user = vilaFirebaseUserJson();
        String userValue = user == null ? "null" : user.toString();
        String js = "window.onNativeFirebaseAuthResult && window.onNativeFirebaseAuthResult(" +
                JSONObject.quote(action) + "," + success + "," + JSONObject.quote(message == null ? "" : message) + "," + userValue + ");";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private String vilaFirebaseErrorText(Exception exception) {
        String code = exception instanceof FirebaseAuthException ? ((FirebaseAuthException) exception).getErrorCode() : "";
        if (code == null) code = "";
        switch (code) {
            case "ERROR_INVALID_EMAIL": return "Địa chỉ email không hợp lệ.";
            case "ERROR_EMAIL_ALREADY_IN_USE": return "Email này đã có tài khoản. Hãy đăng nhập.";
            case "ERROR_WEAK_PASSWORD": return "Mật khẩu quá yếu; hãy dùng ít nhất 6 ký tự.";
            case "ERROR_INVALID_CREDENTIAL":
            case "ERROR_WRONG_PASSWORD":
            case "ERROR_USER_NOT_FOUND": return "Email hoặc mật khẩu không đúng.";
            case "ERROR_USER_DISABLED": return "Tài khoản này đã bị vô hiệu hóa.";
            case "ERROR_OPERATION_NOT_ALLOWED": return "Hãy bật phương thức đăng nhập này trong Firebase Console.";
            case "ERROR_TOO_MANY_REQUESTS": return "Quá nhiều lần thử. Hãy đợi rồi thử lại.";
            case "ERROR_NETWORK_REQUEST_FAILED": return "Không kết nối được Firebase. Kiểm tra Internet.";
            case "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL": return "Email đã được đăng ký bằng phương thức khác.";
            default:
                String message = exception == null ? "" : exception.getMessage();
                return (message == null || message.trim().isEmpty()) ? "Xác thực Firebase thất bại. Hãy thử lại." : message;
        }
    }

    private boolean ensureVilaFirebaseAuth(String action) {
        if (vilaFirebaseAuth != null) return true;
        String message = (vilaFirebaseInitError == null || vilaFirebaseInitError.isEmpty())
                ? "Firebase Android chưa được cấu hình." : vilaFirebaseInitError;
        sendVilaFirebaseResult(action, false, message + " Thực hiện FIREBASE_SETUP_V41.txt rồi build lại APK.");
        return false;
    }

    private void doVilaEmailAuth(String action, String email, String password) {
        if (!ensureVilaFirebaseAuth(action)) return;
        String cleanEmail = email == null ? "" : email.trim();
        String cleanPassword = password == null ? "" : password;
        if (cleanEmail.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            sendVilaFirebaseResult(action, false, "Địa chỉ email không hợp lệ. Hãy nhập email đầy đủ."); return;
        }
        if ((action.equals("register") || action.equals("login")) && cleanPassword.isEmpty()) {
            sendVilaFirebaseResult(action, false, "Nhập mật khẩu."); return;
        }
        // Firebase Email/Password normally requires at least 6 characters for new accounts.
        // Passwords may contain any mix of letters, digits and symbols; login has no length restriction here.
        if (action.equals("register") && cleanPassword.length() < 6) {
            sendVilaFirebaseResult(action, false, "Mật khẩu phải có ít nhất 6 ký tự theo chính sách Firebase; không cần là 6 chữ số."); return;
        }
        if (action.equals("register")) {
            vilaFirebaseAuth.createUserWithEmailAndPassword(cleanEmail, cleanPassword)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser newUser = task.getResult() == null ? null : task.getResult().getUser();
                        if (newUser != null) {
                            newUser.sendEmailVerification().addOnCompleteListener(ignored -> {});
                        }
                        sendVilaFirebaseResult(action, true, "Đã tạo tài khoản Firebase thành công. Đã gửi email xác minh tới " + cleanEmail + ".");
                    } else {
                        sendVilaFirebaseResult(action, false, vilaFirebaseErrorText(task.getException()));
                    }
                });
        } else if (action.equals("login")) {
            vilaFirebaseAuth.signInWithEmailAndPassword(cleanEmail, cleanPassword)
                .addOnCompleteListener(this, task -> {
                    if (!task.isSuccessful()) {
                        sendVilaFirebaseResult(action, false, vilaFirebaseErrorText(task.getException()));
                        return;
                    }
                    // V44: if a Google sign-in attempt earlier found this same email already registered
                    // with a password, finish the merge now that the password has been verified.
                    if (vilaPendingGoogleCredential != null && cleanEmail.equalsIgnoreCase(vilaPendingGoogleEmail)) {
                        AuthCredential pending = vilaPendingGoogleCredential;
                        vilaPendingGoogleCredential = null; vilaPendingGoogleEmail = "";
                        FirebaseUser current = vilaFirebaseAuth.getCurrentUser();
                        if (current != null) {
                            current.linkWithCredential(pending).addOnCompleteListener(linkTask ->
                                sendVilaFirebaseResult(action, true, linkTask.isSuccessful()
                                    ? "Đăng nhập thành công và đã liên kết tài khoản Google với email này."
                                    : "Đăng nhập Firebase thành công, nhưng không thể liên kết Google: " + vilaFirebaseErrorText(linkTask.getException())));
                            return;
                        }
                    }
                    sendVilaFirebaseResult(action, true, "Đăng nhập Firebase thành công.");
                });
        } else if (action.equals("reset")) {
            vilaFirebaseAuth.sendPasswordResetEmail(cleanEmail)
                .addOnCompleteListener(this, task -> sendVilaFirebaseResult(action, task.isSuccessful(), task.isSuccessful()
                    ? "Đã gửi email đặt lại mật khẩu." : vilaFirebaseErrorText(task.getException())));
        }
    }

    private void startVilaGoogleLogin() {
        if (!ensureVilaFirebaseAuth("google")) return;
        if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) {
            sendVilaFirebaseResult("google", false, "VILA AI đang đóng. Hãy mở lại ứng dụng rồi thử đăng nhập Google.");
            return;
        }
        if (vilaFirebaseWebClientId.isEmpty() || !vilaFirebaseWebClientId.matches("^[0-9]+-[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com$")) {
            sendVilaFirebaseResult("google", false, "Google OAuth Web Client ID chưa hợp lệ. Hãy kiểm tra client_type=3 trong google-services.json rồi build lại APK.");
            return;
        }
        try {
            if (vilaCredentialManager == null) vilaCredentialManager = CredentialManager.create(this);
            GetGoogleIdOption googleOption = new GetGoogleIdOption.Builder()
                    .setServerClientId(vilaFirebaseWebClientId)
                    .setFilterByAuthorizedAccounts(false)
                    .setAutoSelectEnabled(false)
                    .build();
            GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(googleOption).build();
            android.os.CancellationSignal cancellation = new android.os.CancellationSignal();
            vilaCredentialManager.getCredentialAsync(this, request, cancellation, command -> runOnUiThread(command),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override public void onResult(GetCredentialResponse result) {
                        try {
                            Credential credential = result.getCredential();
                            if (!(credential instanceof CustomCredential) ||
                                    !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                                sendVilaFirebaseResult("google", false, "Google không trả về Google ID token hợp lệ. Kiểm tra OAuth Web Client ID và SHA-1 của APK.");
                                return;
                            }
                            GoogleIdTokenCredential token = GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
                            finishGoogleFirebaseSignIn(GoogleAuthProvider.getCredential(token.getIdToken(), null));
                        } catch (Exception e) {
                            android.util.Log.e("VILA-Firebase", "Google credential result failed", e);
                            sendVilaFirebaseResult("google", false, googleLoginDiagnostic(e));
                        }
                    }
                    @Override public void onError(GetCredentialException e) {
                        android.util.Log.e("VILA-Firebase", "Google Credential Manager failed: " + (e == null ? "unknown" : e.getClass().getSimpleName()), e);
                        // Credential Manager's "Sign in with Google" sheet doesn't surface a
                        // picker on every OEM/Play-services combo. Fall back to the classic
                        // Google Sign-In account chooser (the "chọn tài khoản" screen) instead
                        // of just showing an error message.
                        launchClassicGoogleSignIn();
                    }
                });
        } catch (Exception e) {
            android.util.Log.e("VILA-Firebase", "Unable to launch Google Credential Manager", e);
            sendVilaFirebaseResult("google", false, googleLoginDiagnostic(e));
        }
    }

    private void finishGoogleFirebaseSignIn(AuthCredential firebaseCredential) {
        vilaFirebaseAuth.signInWithCredential(firebaseCredential).addOnCompleteListener(MainActivity.this, task -> {
            if (task.isSuccessful()) {
                sendVilaFirebaseResult("google", true, "Đăng nhập Google thành công.");
                return;
            }
            Exception ex = task.getException();
            if (ex instanceof FirebaseAuthUserCollisionException) {
                FirebaseAuthUserCollisionException collision = (FirebaseAuthUserCollisionException) ex;
                vilaPendingGoogleCredential = collision.getUpdatedCredential();
                vilaPendingGoogleEmail = collision.getEmail() == null ? "" : collision.getEmail();
                if (vilaPendingGoogleCredential != null && !vilaPendingGoogleEmail.isEmpty()) {
                    sendVilaFirebaseResult("google", false, "Email " + vilaPendingGoogleEmail +
                        " đã có tài khoản với mật khẩu. Hãy đăng nhập bằng email và mật khẩu đó một lần; VILA sẽ tự liên kết Google sau khi đăng nhập thành công.");
                    return;
                }
            }
            sendVilaFirebaseResult("google", false, vilaFirebaseErrorText(ex));
        });
    }

    private static final int REQ_CLASSIC_GOOGLE_SIGNIN = 3003;
    private GoogleSignInClient vilaClassicGoogleClient;

    /** Classic Google Sign-In picker — shows the native "Chọn tài khoản" chooser with every
     *  Google account on the device (same screen as Settings/Gmail), then returns an ID token
     *  usable with Firebase. Used as a fallback when the newer Credential Manager sheet fails
     *  to surface a picker (common on some OEM Android builds / older Play services). */
    private void launchClassicGoogleSignIn() {
        if (vilaFirebaseWebClientId.isEmpty() || !vilaFirebaseWebClientId.matches("^[0-9]+-[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com$")) {
            sendVilaFirebaseResult("google", false, "Google OAuth Web Client ID chưa hợp lệ. Hãy kiểm tra client_type=3 trong google-services.json rồi build lại APK.");
            return;
        }
        try {
            if (vilaClassicGoogleClient == null) {
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(vilaFirebaseWebClientId)
                        .requestEmail()
                        .build();
                vilaClassicGoogleClient = GoogleSignIn.getClient(this, gso);
            }
            // Force the account chooser every time instead of silently reusing the last account.
            vilaClassicGoogleClient.signOut().addOnCompleteListener(ignored ->
                startActivityForResult(vilaClassicGoogleClient.getSignInIntent(), REQ_CLASSIC_GOOGLE_SIGNIN));
        } catch (Exception e) {
            android.util.Log.e("VILA-Firebase", "Unable to launch classic Google Sign-In", e);
            sendVilaFirebaseResult("google", false, googleLoginDiagnostic(e));
            maybeOfferAddGoogleAccount(e);
        }
    }

    private void handleClassicGoogleSignInResult(Intent data) {
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            String idToken = account == null ? null : account.getIdToken();
            if (idToken == null || idToken.isEmpty()) {
                sendVilaFirebaseResult("google", false, "Google không trả về ID token hợp lệ. Kiểm tra OAuth Web Client ID và SHA-1 của APK.");
                return;
            }
            finishGoogleFirebaseSignIn(GoogleAuthProvider.getCredential(idToken, null));
        } catch (ApiException e) {
            android.util.Log.e("VILA-Firebase", "Classic Google Sign-In failed: code=" + e.getStatusCode(), e);
            int code = e.getStatusCode();
            if (code == 12501) { // SIGN_IN_CANCELLED
                sendVilaFirebaseResult("google", false, "Bạn đã hủy đăng nhập Google. Bấm nút Google để thử lại.");
            } else if (code == 12500) { // SIGN_IN_FAILED
                sendVilaFirebaseResult("google", false, "Google OAuth bị từ chối. SHA-1 của chứng thư ký APK và package com.vila.ai phải được thêm đúng trong Firebase Console.");
            } else if (code == 4) { // SIGN_IN_REQUIRED — no account chosen/available
                sendVilaFirebaseResult("google", false, "Không có tài khoản Google nào trên thiết bị.");
                maybeOfferAddGoogleAccount(new Exception("no credential"));
            } else {
                sendVilaFirebaseResult("google", false, "Đăng nhập Google thất bại (mã " + code + "). Kiểm tra OAuth Web Client ID, SHA-1 của APK và Google Play services.");
            }
        }
    }

    private void maybeOfferAddGoogleAccount(Exception e) {
        if (e == null) return;
        String kind = e.getClass().getSimpleName();
        String detail = e.getMessage() == null ? "" : e.getMessage().trim();
        String lower = (kind + " " + detail).toLowerCase(Locale.ROOT);
        if (!(lower.contains("no credential") || lower.contains("nocredential"))) return;
        try {
            Intent addAccount = new Intent(android.provider.Settings.ACTION_ADD_ACCOUNT);
            addAccount.putExtra(android.provider.Settings.EXTRA_ACCOUNT_TYPES, new String[]{"com.google"});
            addAccount.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (addAccount.resolveActivity(getPackageManager()) != null) {
                runOnUiThread(() -> {
                    android.widget.Toast.makeText(this,
                        "Thêm tài khoản Google vào máy, sau đó quay lại VILA AI và bấm 'Tiếp tục với Google' lần nữa.",
                        android.widget.Toast.LENGTH_LONG).show();
                    startActivity(addAccount);
                });
            }
        } catch (Exception ex) {
            android.util.Log.e("VILA-Firebase", "Unable to open Add Google Account screen", ex);
        }
    }

    private String googleLoginDiagnostic(Exception e) {
        if (e == null) return "Không thể mở Google Sign-In. Kiểm tra Google Play services và thử lại.";
        String kind = e.getClass().getSimpleName();
        String detail = e.getMessage() == null ? "" : e.getMessage().trim();
        String lower = (kind + " " + detail).toLowerCase(Locale.ROOT);
        if (lower.contains("cancel")) return "Bạn đã hủy đăng nhập Google. Bấm nút Google để thử lại.";
        if (lower.contains("no credential") || lower.contains("nocredential"))
            return "Không tìm thấy thông tin đăng nhập Google trên thiết bị. Kiểm tra Google Play services và tài khoản Google.";
        if (lower.contains("developer_error") || lower.contains("developer error") || lower.contains("10: "))
            return "Google OAuth bị từ chối. SHA-1 của chứng thư ký APK và package com.vila.ai phải được thêm đúng trong Firebase Console.";
        if (lower.contains("network") || lower.contains("unavailable"))
            return "Không kết nối được dịch vụ đăng nhập Google. Kiểm tra Internet rồi thử lại.";
        if (!detail.isEmpty()) return "Đăng nhập Google thất bại (" + kind + "): " + detail;
        return "Đăng nhập Google thất bại (" + kind + "). Kiểm tra OAuth Web Client ID, SHA-1 của APK và Google Play services.";
    }


    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CLASSIC_GOOGLE_SIGNIN) {
            handleClassicGoogleSignInResult(data);
            return;
        }
        if (requestCode == 2002 && fileCallback != null) {
            Uri[] shot = null;
            if (resultCode == RESULT_OK && camUri != null) shot = new Uri[]{camUri};
            else if (camUri != null) { try { getContentResolver().delete(camUri, null, null); } catch (Exception ignored) {} }
            fileCallback.onReceiveValue(shot); fileCallback = null; camUri = null;
            return;
        }
        if (requestCode == 2001 && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
    private static final String SECRET_SUFFIX = "_secure_v1";
    private static final String SECRET_KEY_ALIAS = "com.vila.ai.secret.key.v1";

    /** Store secrets encrypted at rest; preserve compatibility by migrating old plaintext entries. */
    private synchronized String getSecretPreference(String key, String... legacyKeys) {
        String encrypted = prefs.getString(key + SECRET_SUFFIX, "");
        if (!encrypted.isEmpty()) {
            try { return decryptSecret(encrypted); }
            catch (Exception e) { android.util.Log.e("VILA", "Unable to decrypt saved secret; keeping it unavailable rather than exposing plaintext.", e); return ""; }
        }
        String value = prefs.getString(key, "");
        if (value.isEmpty()) {
            for (String legacy : legacyKeys) {
                value = prefs.getString(legacy, "");
                if (!value.isEmpty()) break;
            }
        }
        if (!value.isEmpty()) {
            try {
                String sealed = encryptSecret(value);
                SharedPreferences.Editor edit = prefs.edit().putString(key + SECRET_SUFFIX, sealed).remove(key);
                for (String legacy : legacyKeys) edit.remove(legacy);
                edit.remove(key + "_enc").remove(key + "_iv").apply();
                return value;
            } catch (Exception e) {
                // Do not delete legacy data if Keystore is temporarily unavailable.
                android.util.Log.e("VILA", "Unable to migrate a legacy secret to Android Keystore.", e);
            }
        }
        return value;
    }

    private synchronized boolean saveSecretPreference(String key, String value, String... legacyKeys) {
        String cleaned = value == null ? "" : value.trim();
        SharedPreferences.Editor edit = prefs.edit();
        if (cleaned.isEmpty()) {
            edit.remove(key).remove(key + SECRET_SUFFIX).remove(key + "_enc").remove(key + "_iv");
            for (String legacy : legacyKeys) edit.remove(legacy);
            edit.apply();
            return true;
        }
        try {
            edit.putString(key + SECRET_SUFFIX, encryptSecret(cleaned)).remove(key).remove(key + "_enc").remove(key + "_iv");
            for (String legacy : legacyKeys) edit.remove(legacy);
            edit.apply();
            return true;
        } catch (Exception e) {
            android.util.Log.e("VILA", "Unable to encrypt secret with Android Keystore.", e);
            return false;
        }
    }

    private synchronized void clearSecretPreference(String key, String... legacyKeys) {
        SharedPreferences.Editor edit = prefs.edit().remove(key).remove(key + SECRET_SUFFIX).remove(key + "_enc").remove(key + "_iv");
        for (String legacy : legacyKeys) edit.remove(legacy);
        edit.apply();
    }

    private javax.crypto.SecretKey getOrCreateSecretKey() throws Exception {
        java.security.KeyStore keyStore = java.security.KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        java.security.Key existing = keyStore.getKey(SECRET_KEY_ALIAS, null);
        if (existing instanceof javax.crypto.SecretKey) return (javax.crypto.SecretKey) existing;
        javax.crypto.KeyGenerator generator = javax.crypto.KeyGenerator.getInstance(
            android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec = new android.security.keystore.KeyGenParameterSpec.Builder(
            SECRET_KEY_ALIAS,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private String encryptSecret(String plaintext) throws Exception {
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] iv = cipher.getIV();
        byte[] ciphertext = cipher.doFinal(plaintext.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return "v1:" + android.util.Base64.encodeToString(iv, android.util.Base64.NO_WRAP) + ":" +
            android.util.Base64.encodeToString(ciphertext, android.util.Base64.NO_WRAP);
    }

    private String decryptSecret(String encoded) throws Exception {
        String[] pieces = encoded.split(":", 3);
        if (pieces.length != 3 || !"v1".equals(pieces[0])) throw new java.security.GeneralSecurityException("Unsupported encrypted secret format");
        byte[] iv = android.util.Base64.decode(pieces[1], android.util.Base64.DEFAULT);
        byte[] ciphertext = android.util.Base64.decode(pieces[2], android.util.Base64.DEFAULT);
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(javax.crypto.Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new javax.crypto.spec.GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(ciphertext), java.nio.charset.StandardCharsets.UTF_8);
    }

    static String safeFileName(String raw, String fallback, int max) {
        // Strip path separators, control characters and leading dots; a blank/dots-only name would otherwise
        // produce an empty DISPLAY_NAME (save fails) or a hidden/relative file name.
        String n = (raw == null ? "" : raw).replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim().replaceFirst("^\\.+", "");
        if (n.isEmpty()) n = fallback;
        return n.length() > max ? n.substring(0, max) : n;
    }

        public class AndroidBridge {

        // V53.7: user-triggered handoff to the external DeepSeek app via Android Sharesheet.
        // The prompt is only shared after an explicit tap; VILA does not read the other app's session/history.
        @android.webkit.JavascriptInterface public void shareToDeepSeek(String prompt) {
            final String text = prompt == null ? "" : prompt.trim();
            runOnUiThread(() -> {
                if (text.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Nhập câu hỏi trước khi gửi sang DeepSeek.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    send.putExtra(Intent.EXTRA_TITLE, "Câu hỏi từ VILA AI");
                    startActivity(Intent.createChooser(send, "Chia sẻ câu hỏi tới DeepSeek"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Không mở được menu chia sẻ. Hãy cập nhật Android hoặc thử lại.", Toast.LENGTH_LONG).show();
                }
            });
        }

        // V53.8: user-triggered experimental accessibility bridge to the installed DeepSeek app.
        @android.webkit.JavascriptInterface public void startDeepSeekBot(String prompt) {
            final String text = prompt == null ? "" : prompt.trim();
            runOnUiThread(() -> {
                if (text.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Nhập câu hỏi trước khi chạy Bot DeepSeek.", Toast.LENGTH_SHORT).show();
                    return;
                }
                DeepSeekAccessibilityService.start(MainActivity.this, text);
            });
        }

        @android.webkit.JavascriptInterface public void openDeepSeekAccessibilitySettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Không mở được cài đặt Trợ năng.", Toast.LENGTH_LONG).show(); }
            });
        }

        // Opens the official DeepSeek chat URL. Android may route it to the installed app if its
        // verified app-link handling is available; otherwise it opens the browser.
        @android.webkit.JavascriptInterface public void openDeepSeek() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chat.deepseek.com/"))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Không mở được DeepSeek.", Toast.LENGTH_LONG).show(); }
            });
        }

        // ---- V41 Firebase Authentication bridge (native Google Credential Manager + Firebase Auth) ----
        @android.webkit.JavascriptInterface public String firebaseAuthState() { return vilaFirebaseStateJson(); }
        // V42: asynchronously provide a short-lived Firebase ID token to the optional server Gateway.
        // The token is never persisted in local storage or written to logs.
        @android.webkit.JavascriptInterface public void requestFirebaseIdToken() {
            FirebaseUser user = vilaFirebaseAuth == null ? null : vilaFirebaseAuth.getCurrentUser();
            if (user == null) {
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.onVilaGatewayIdToken && window.onVilaGatewayIdToken('');", null); });
                return;
            }
            user.getIdToken(false).addOnCompleteListener(task -> {
                String token = "";
                if (task.isSuccessful() && task.getResult() != null) token = task.getResult().getToken();
                final String callbackValue = token;
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("window.onVilaGatewayIdToken && window.onVilaGatewayIdToken(" + JSONObject.quote(callbackValue) + ");", null);
                });
            });
        }
        @android.webkit.JavascriptInterface public void firebaseEmailRegister(String email, String password) {
            runOnUiThread(() -> doVilaEmailAuth("register", email, password));
        }
        @android.webkit.JavascriptInterface public void firebaseEmailLogin(String email, String password) {
            runOnUiThread(() -> doVilaEmailAuth("login", email, password));
        }
        @android.webkit.JavascriptInterface public void firebasePasswordReset(String email) {
            runOnUiThread(() -> doVilaEmailAuth("reset", email, ""));
        }
        @android.webkit.JavascriptInterface public void firebaseGoogleLogin() {
            runOnUiThread(() -> startVilaGoogleLogin());
        }
        @android.webkit.JavascriptInterface public void firebaseResendVerification() {
            runOnUiThread(() -> {
                FirebaseUser user = vilaFirebaseAuth == null ? null : vilaFirebaseAuth.getCurrentUser();
                if (user == null) { sendVilaFirebaseResult("verify", false, "Chưa đăng nhập."); return; }
                if (user.isEmailVerified()) { sendVilaFirebaseResult("verify", true, "Email đã được xác minh."); return; }
                user.sendEmailVerification().addOnCompleteListener(task -> sendVilaFirebaseResult("verify", task.isSuccessful(),
                    task.isSuccessful() ? "Đã gửi lại email xác minh tới " + (user.getEmail() == null ? "" : user.getEmail()) + "."
                        : vilaFirebaseErrorText(task.getException())));
            });
        }
        @android.webkit.JavascriptInterface public void firebaseLogout() {
            runOnUiThread(() -> {
                vilaPendingGoogleCredential = null; vilaPendingGoogleEmail = "";
                if (vilaFirebaseAuth == null) {
                    sendVilaFirebaseResult("logout", false, "Firebase Android chưa được cấu hình.");
                    return;
                }
                vilaFirebaseAuth.signOut();
                sendVilaFirebaseResult("logout", true, "Đã đăng xuất Firebase.");
                try {
                    if (vilaCredentialManager != null) {
                        vilaCredentialManager.clearCredentialStateAsync(
                            new androidx.credentials.ClearCredentialStateRequest(),
                            new android.os.CancellationSignal(), command -> runOnUiThread(command),
                            new CredentialManagerCallback<Void, androidx.credentials.exceptions.ClearCredentialException>() {
                                @Override public void onResult(Void result) { }
                                @Override public void onError(androidx.credentials.exceptions.ClearCredentialException e) { }
                            });
                    }
                } catch (Exception ignored) { }
            });
        }

        /** Deletes the signed-in Firebase account; recent-login failures are reported to the UI. */
        @android.webkit.JavascriptInterface public void firebaseDeleteAccount() {
            runOnUiThread(() -> {
                FirebaseUser user = vilaFirebaseAuth == null ? null : vilaFirebaseAuth.getCurrentUser();
                if (user == null) {
                    sendVilaFirebaseResult("delete", false, "Bạn chưa đăng nhập tài khoản Firebase.");
                    return;
                }
                user.delete().addOnCompleteListener(MainActivity.this, task -> {
                    if (task.isSuccessful()) {
                        sendVilaFirebaseResult("delete", true, "Đã xóa tài khoản Firebase. Dữ liệu cục bộ sẽ được xóa tiếp theo.");
                    } else {
                        Exception error = task.getException();
                        String message = error instanceof com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException
                            ? "Firebase yêu cầu đăng nhập lại gần đây. Hãy đăng xuất, đăng nhập lại rồi thử xóa tài khoản một lần nữa."
                            : vilaFirebaseErrorText(error);
                        sendVilaFirebaseResult("delete", false, message);
                    }
                });
            });
        }

        // ---- V38 notification bridge (called from JS as window.Android.*) ----
        @android.webkit.JavascriptInterface public boolean hasNotificationPermission() {
            return VilaNotifier.canNotify(MainActivity.this);
        }

        @android.webkit.JavascriptInterface public boolean isAppVisible() {
            return appVisible;
        }

        /** Shows the system permission dialog (Android 13+). If it was denied permanently, opens system settings instead. */
        @android.webkit.JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                final String perm = "android.permission.POST_NOTIFICATIONS";
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
                    boolean asked = prefs.getBoolean("notif_asked", false);
                    if (asked && !shouldShowRequestPermissionRationale(perm)) {
                        openNotificationSettingsScreen();
                    } else {
                        prefs.edit().putBoolean("notif_asked", true).apply();
                        requestPermissions(new String[]{perm}, REQ_NOTIFICATIONS);
                    }
                } else if (!VilaNotifier.canNotify(MainActivity.this)) {
                    openNotificationSettingsScreen();
                } else {
                    notifyPermissionState(true);
                }
            });
        }

        @android.webkit.JavascriptInterface public void openNotificationSettings() {
            runOnUiThread(() -> openNotificationSettingsScreen());
        }

        @android.webkit.JavascriptInterface public void notifyUser(String title, String body) {
            try { VilaNotifier.postDone(MainActivity.this, title, body); } catch (Exception ignored) {}
        }

        /** JS tells us a request started/finished. While active, leaving the app starts the keep-alive service. */
        @android.webkit.JavascriptInterface public void setRequestActive(boolean active, String title, String text) {
            requestActive = active;
            if (active) {
                if (title != null && !title.isEmpty()) requestTitle = title;
                requestText = text == null ? "" : text;
            } else {
                runOnUiThread(() -> stopKeepAlive());
            }
        }

        @android.webkit.JavascriptInterface public void updateRequestStatus(String text) {
            requestText = text == null ? "" : text;
            if (keepAliveRunning) {
                try {
                    NotificationManager nm = VilaNotifier.manager(MainActivity.this);
                    if (nm != null) nm.notify(VilaNotifier.ID_PROGRESS, VilaNotifier.progress(MainActivity.this, requestTitle, requestText));
                } catch (Exception ignored) {}
            }
        }

        // Provider API keys and tokens are encrypted with AES-GCM; the AES key is protected by Android Keystore.
        private String cleanProviderName(String provider) {
            String value = provider == null ? "" : provider.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "");
            if (value.isEmpty() || value.length() > 32) return "custom";
            return value;
        }

        @android.webkit.JavascriptInterface public String getProviderApiKey(String provider) {
            String name = cleanProviderName(provider);
            return getSecretPreference("provider_api_key_" + name, "provider_api_key_" + name + "_plain");
        }

        @android.webkit.JavascriptInterface public boolean saveProviderApiKey(String provider, String token) {
            String name = cleanProviderName(provider);
            String value = token == null ? "" : token.trim();
            return saveSecretPreference("provider_api_key_" + name, value, "provider_api_key_" + name + "_plain");
        }

        @android.webkit.JavascriptInterface public void clearProviderApiKey(String provider) {
            String name = cleanProviderName(provider);
            clearSecretPreference("provider_api_key_" + name, "provider_api_key_" + name + "_plain");
        }

        @android.webkit.JavascriptInterface public void saveTextFile(String filename, String content, String mimeType) {
            try {
                String safeName = safeFileName(filename, "VILA_File.txt", 120);
                byte[] bytes = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);
                String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "text/plain" : mimeType.trim();
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mime);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Không tạo được file Downloads");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new IOException("Không mở được file"); out.write(bytes); }
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Không tạo được thư mục Downloads");
                    File file = new File(dir, safeName);
                    try (OutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Không thể lưu file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @android.webkit.JavascriptInterface public void startVoiceInput() {
            runOnUiThread(() -> MainActivity.this.startVoiceRecognition());
        }

        @android.webkit.JavascriptInterface public void stopVoiceInput() {
            runOnUiThread(() -> {
                if (speechRecognizer != null) {
                    try { speechRecognizer.stopListening(); } catch (Exception ignored) {}
                }
            });
        }

        @android.webkit.JavascriptInterface public void speakText(String text) {
            runOnUiThread(() -> speakSmoothText(text));
        }

        private void speakSmoothText(String text) {
            if (textToSpeech == null) return;
            String value = text == null ? "" : text.trim();
            if (value.isEmpty()) return;
            try {
                value = value.replaceAll("```[\\s\\S]*?```", "");
                value = value.replaceAll("[#*_`>]+", " ");
                value = value.replaceAll("\\s{2,}", " ").trim();
                if (value.isEmpty()) return;
                textToSpeech.setLanguage(new Locale("vi", "VN"));
                textToSpeech.setSpeechRate(0.94f);
                textToSpeech.setPitch(1.02f);
                textToSpeech.stop();
                final int maxChars = 3200;
                ArrayList<String> chunks = new ArrayList<>();
                String remaining = value;
                while (remaining.length() > maxChars) {
                    int cut = remaining.lastIndexOf('.', maxChars);
                    if (cut < 1200) cut = remaining.lastIndexOf('!', maxChars);
                    if (cut < 1200) cut = remaining.lastIndexOf('?', maxChars);
                    if (cut < 1200) cut = remaining.lastIndexOf(' ', maxChars);
                    if (cut <= 0) cut = maxChars;
                    chunks.add(remaining.substring(0, cut + (cut < remaining.length() && ".!?".indexOf(remaining.charAt(cut)) >= 0 ? 1 : 0)).trim());
                    remaining = remaining.substring(Math.min(remaining.length(), cut + 1)).trim();
                }
                if (!remaining.isEmpty()) chunks.add(remaining);
                for (int i = 0; i < chunks.size(); i++) {
                    String id = "VILA_REPLY_" + System.nanoTime() + "_" + i;
                    textToSpeech.speak(chunks.get(i), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, id);
                }
            } catch (Exception ignored) {}
        }

        @android.webkit.JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> {
                if (textToSpeech != null) {
                    try { textToSpeech.stop(); } catch (Exception ignored) {}
                }
            });
        }

        @android.webkit.JavascriptInterface public String getAgentServerToken() {
            return getSecretPreference("agent_server_token", "agent_server_token_plain");
        }

        @android.webkit.JavascriptInterface public boolean saveAgentServerToken(String token) {
            return saveSecretPreference("agent_server_token", token, "agent_server_token_plain");
        }

        @android.webkit.JavascriptInterface public void clearAgentServerToken() {
            clearSecretPreference("agent_server_token", "agent_server_token_plain");
        }

        private byte[] readAllStream(InputStream i) throws IOException {
            if (i == null) return new byte[0];
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] x = new byte[8192]; int k;
            while ((k = i.read(x)) > 0) b.write(x, 0, k);
            try { i.close(); } catch (Exception ignored) {}
            return b.toByteArray();
        }

        @android.webkit.JavascriptInterface public void saveBase64File(String filename, String base64, String mimeType) {
            try {
                String safeName = safeFileName(filename, "VILA_Image.png", 120);
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType.trim();
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mime);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Không tạo được file Downloads");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IOException("Không mở được file");
                        out.write(bytes);
                    }
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Không tạo được thư mục Downloads");
                    try (OutputStream out = new FileOutputStream(new File(dir, safeName))) { out.write(bytes); }
                }
                final String savedName = safeName;
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Đã lưu " + savedName + " vào Downloads", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Không thể lưu file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @android.webkit.JavascriptInterface public void setImmersiveMode(boolean enabled) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowInsetsController controller = getWindow().getInsetsController();
                    if (controller != null) {
                        if (enabled) {
                            controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                            controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        } else {
                            controller.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                        }
                        return;
                    }
                }
                int flags = enabled ? (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE) : View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                getWindow().getDecorView().setSystemUiVisibility(flags);
            });
        }

        // Gemini configuration and file automation bridge.
        @android.webkit.JavascriptInterface public String getGeminiApiKey() {
            return getGeminiApiKeyStored();
        }

        @android.webkit.JavascriptInterface public boolean hasGeminiApiKey() {
            return !getGeminiApiKeyStored().isEmpty();
        }

        @android.webkit.JavascriptInterface public boolean saveGeminiApiKey(String token) {
            String value = token == null ? "" : token.trim();
            if (value.isEmpty()) { clearGeminiApiKey(); return true; }
            return saveSecretPreference(GEMINI_KEY_PREF, value, "gemini_api_key_plain");
        }

        @android.webkit.JavascriptInterface public void clearGeminiApiKey() {
            clearSecretPreference(GEMINI_KEY_PREF, "gemini_api_key_plain");
        }

        @android.webkit.JavascriptInterface public String getGeminiBaseUrl() {
            return prefs.getString(GEMINI_BASE_URL_PREF, "https://generativelanguage.googleapis.com/v1beta/openai");
        }

        @android.webkit.JavascriptInterface public void saveGeminiBaseUrl(String baseUrl) {
            String value = baseUrl == null ? "" : baseUrl.trim();
            if (value.isEmpty()) value = "https://generativelanguage.googleapis.com/v1beta/openai";
            value = value.replaceAll("/+$", "");
            if (!(value.startsWith("https://") || value.startsWith("http://"))) value = "https://generativelanguage.googleapis.com/v1beta/openai";
            prefs.edit().putString(GEMINI_BASE_URL_PREF, value).apply();
        }

        @android.webkit.JavascriptInterface public void downloadUrl(String url, String fileName) {
            try {
                Uri uri = Uri.parse(url == null ? "" : url.trim());
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if (!(scheme.equals("https") || scheme.equals("http"))) throw new IllegalArgumentException("URL không hợp lệ");
                String guessed = URLUtil.guessFileName(uri.toString(), null, null);
                String safeName = safeFileName((fileName == null || fileName.trim().isEmpty()) ? guessed : fileName, "VILA_Download", 140);
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request req = new DownloadManager.Request(uri);
                req.setTitle(safeName);
                req.setDescription("VILA AI đang tải file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName);
                dm.enqueue(req);
                final String savedName = safeName;
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("window.onVilaFileDownload && window.onVilaFileDownload(" + JSONObject.quote(savedName) + ",true)", null);
                    Toast.makeText(MainActivity.this, "Đang tải " + savedName + " vào Downloads", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                final String message = e.getMessage() == null ? "Không thể tải file" : e.getMessage();
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("window.onVilaFileDownload && window.onVilaFileDownload(" + JSONObject.quote(message) + ",false)", null);
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        }

        private String getGeminiApiKeyStored() {
            return getSecretPreference(GEMINI_KEY_PREF, "gemini_api_key_plain");
        }

    }

    private void startVoiceRecognition() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 1003);
            Toast.makeText(this, "Cho phép micro rồi bấm mic lại", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Thiết bị chưa có dịch vụ nhận dạng giọng nói", Toast.LENGTH_LONG).show();
            return;
        }
        if (speechRecognizer != null) { try { speechRecognizer.destroy(); } catch (Exception ignored) {} }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { evaluateVoice("ready", ""); }
            @Override public void onBeginningOfSpeech() { evaluateVoice("listening", ""); }
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { evaluateVoice("processing", ""); }
            @Override public void onError(int error) { evaluateVoice("error", ""); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                evaluateVoice("result", text);
            }
            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> matches = partialResults == null ? null : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) evaluateVoice("partial", matches.get(0));
            }
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try { speechRecognizer.startListening(intent); } catch (Exception e) { Toast.makeText(this, "Không thể khởi động micro", Toast.LENGTH_SHORT).show(); }
    }

    private void evaluateVoice(String state, String text) {
        if (web == null) return;
        String js = "window.onVilaVoiceResult && window.onVilaVoiceResult(" + JSONObject.quote(state) + "," + JSONObject.quote(text == null ? "" : text) + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    // ---- V38: notifications outside the app --------------------------------------------------------
    @Override protected void onStart() { super.onStart(); appVisible = true; }
    @Override protected void onStop() { super.onStop(); appVisible = false; }

    @Override protected void onPause() {
        super.onPause();
        // Leaving the app while an answer is still being generated: keep the process alive and show progress.
        if (requestActive && VilaNotifier.canNotify(this)) startKeepAlive();
    }

    @Override protected void onResume() {
        super.onResume();
        appVisible = true;
        stopKeepAlive();
        VilaNotifier.cancelDone(this);
        // The user may have toggled notifications in system settings while away; tell the page.
        notifyPermissionState(VilaNotifier.canNotify(this));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            boolean ok = grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            notifyPermissionState(ok && VilaNotifier.canNotify(this));
        }
    }

    void notifyPermissionState(boolean granted) {
        if (web == null) return;
        final String js = "window.onVilaNotificationPermission && window.onVilaNotificationPermission(" + (granted ? "true" : "false") + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    void startKeepAlive() {
        if (keepAliveRunning) return;
        try {
            Intent i = new Intent(this, VilaKeepAliveService.class);
            i.putExtra("title", requestTitle);
            i.putExtra("text", requestText);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            keepAliveRunning = true;
        } catch (Exception e) {
            // Background-start restrictions: fall back to a plain ongoing notification.
            try {
                NotificationManager nm = VilaNotifier.manager(this);
                if (nm != null) { nm.notify(VilaNotifier.ID_PROGRESS, VilaNotifier.progress(this, requestTitle, requestText)); keepAliveRunning = true; }
            } catch (Exception ignored) {}
        }
    }

    void stopKeepAlive() {
        if (!keepAliveRunning) return;
        keepAliveRunning = false;
        try { stopService(new Intent(this, VilaKeepAliveService.class)); } catch (Exception ignored) {}
        VilaNotifier.cancelProgress(this);
    }

    void openNotificationSettingsScreen() {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 26) {
                i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getPackageName());
            } else {
                i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Không mở được cài đặt thông báo", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){return !!(window.isVilaPreviewOpen && window.isVilaPreviewOpen());})()", value -> {
            boolean previewOpen = "true".equals(value);
            if (previewOpen) {
                web.evaluateJavascript("window.closeLivePreview && window.closeLivePreview();", null);
            } else if (web.canGoBack()) {
                web.goBack();
            } else {
                MainActivity.super.onBackPressed();
            }
        });
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.hasExtra("vila_deepseek_prompt")) {
            String p = intent.getStringExtra("vila_deepseek_prompt");
            String a = intent.getStringExtra("vila_deepseek_answer");
            String e = intent.getStringExtra("vila_deepseek_error");
            final String js = "window.onVilaDeepSeekBotResult && window.onVilaDeepSeekBotResult(" + JSONObject.quote(p == null ? "" : p) + "," + JSONObject.quote(a == null ? "" : a) + "," + JSONObject.quote(e == null ? "" : e) + ");";
            new Handler(Looper.getMainLooper()).postDelayed(() -> { if (web != null) web.evaluateJavascript(js, null); }, 500L);
        }
    }

    @Override protected void onDestroy(){
        requestActive=false; stopKeepAlive();
        if(vilaFirebaseAuth!=null && vilaFirebaseAuthStateListener!=null){try{vilaFirebaseAuth.removeAuthStateListener(vilaFirebaseAuthStateListener);}catch(Exception ignored){}}
        if(speechRecognizer!=null){try{speechRecognizer.destroy();}catch(Exception ignored){}}
        if(textToSpeech!=null){try{textToSpeech.stop();textToSpeech.shutdown();}catch(Exception ignored){}}
        if(proxy!=null) proxy.stopServer();
        super.onDestroy();
    }

    // Bounded retry for loading the local page: covers both a proxy bind failure (see
    // LocalProxy.onBindFailed) and a transient connection refusal (see onReceivedError below).
    // Capped and backed off (via localPageRetryCount, reset on a successful onPageFinished) so a
    // genuinely broken state surfaces as one clear message instead of silently retrying forever
    // or hammering the local socket with a fresh attempt=0 on every single failure.
    private static final int MAX_LOCAL_PAGE_RETRIES = 6;
    private int localPageRetryCount = 0;
    private void retryLoadLocalPage() {
        if (isFinishing() || isDestroyed()) return;
        if (localPageRetryCount >= MAX_LOCAL_PAGE_RETRIES) {
            try { Toast.makeText(this, "VILA không thể khởi động giao diện. Hãy đóng hẳn và mở lại ứng dụng.", Toast.LENGTH_LONG).show(); } catch (Exception ignored) {}
            return;
        }
        long delayMs = Math.min(3000L, 250L * (localPageRetryCount + 1));
        localPageRetryCount++;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing() || isDestroyed() || web == null) return;
            try { web.loadUrl("http://127.0.0.1:" + PORT + "/"); } catch (Exception ignored) {}
        }, delayMs);
    }

    static class LocalProxy extends Thread {
        final MainActivity ctx; final int port; volatile boolean running=true; ServerSocket ss;
        // Previously a single bind() failure (e.g. the port still in TIME_WAIT right after an app
        // restart, or briefly held by another process) left ss permanently null: run() returned
        // immediately, the WebView's loadUrl() had nothing to connect to, and the user saw a
        // permanently blank/white screen with zero feedback and no way to recover without force-
        // closing the app. bind() now retries with backoff before giving up, and reports failure
        // via onBindFailed so the caller can inform the user instead of failing silently.
        volatile Runnable onBindFailed;
        LocalProxy(MainActivity c,int p){ctx=c;port=p;}
        void bind(){if(ss!=null&&ss.isBound())return; try{ss=new ServerSocket(); ss.setReuseAddress(true); ss.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),port));}catch(Exception e){try{if(ss!=null)ss.close();}catch(Exception ignored){} ss=null;}}
        public void run(){
            if(ss==null){
                for(int attempt=0; attempt<20 && ss==null && running; attempt++){
                    bind();
                    if(ss==null){ try{ Thread.sleep(150); }catch(InterruptedException ignored){ return; } }
                }
            }
            if(ss==null){
                Runnable cb = onBindFailed;
                if(cb != null) try{ cb.run(); }catch(Exception ignored){}
                return;
            }
            while(running){try{Socket s=ss.accept(); new Thread(()->handle(s)).start();}catch(Exception ignored){}}
        }
        void handle(Socket s){try{s.setSoTimeout(15000); BufferedInputStream in=new BufferedInputStream(s.getInputStream()); OutputStream out=s.getOutputStream(); String request=readLine(in); if(request==null){s.close();return;} String[] p=request.split(" "); String method=p[0], path=p[1]; Map<String,String> headers=new HashMap<>(); String line; while((line=readLine(in))!=null&&!line.isEmpty()){int i=line.indexOf(':');if(i>0)headers.put(line.substring(0,i).toLowerCase(),line.substring(i+1).trim());}
            String hostH=headers.getOrDefault("host","").toLowerCase(Locale.ROOT); if(!(hostH.equals("127.0.0.1:"+port)||hostH.equals("localhost:"+port))){write(out,403,"text/plain; charset=utf-8","Forbidden".getBytes(StandardCharsets.UTF_8));s.close();return;}
            int len=0; try{len=Integer.parseInt(headers.getOrDefault("content-length","0"));}catch(Exception ignored){} if(len<0||len>1024*1024){write(out,413,"text/plain; charset=utf-8","Too large".getBytes(StandardCharsets.UTF_8));s.close();return;} /* This loopback server only serves static assets and never uses a request body; drain it in small chunks instead of allocating up to len bytes per connection. */ byte[] drain=new byte[8192]; int left=len; while(left>0){int n=in.read(drain,0,Math.min(drain.length,left));if(n<0)break;left-=n;}
            if(path.startsWith("/api/")){write(out,404,"text/plain; charset=utf-8","Not found".getBytes(StandardCharsets.UTF_8));}
            else {
                String cleanPath = path.indexOf('?')>=0 ? path.substring(0,path.indexOf('?')) : path;
                String assetPath = cleanPath.equals("/") ? "index.html" : cleanPath.substring(1);
                if(assetPath.contains("..") || assetPath.contains("\\")){
                    write(out,400,"text/plain; charset=utf-8","Bad path".getBytes(StandardCharsets.UTF_8));
                } else {
                    try {
                        byte[] data=asset(assetPath);
                        write(out,200,mimeType(assetPath),data);
                    } catch(Exception missing) {
                        write(out,404,"text/plain; charset=utf-8","Not found".getBytes(StandardCharsets.UTF_8));
                    }
                }
            }
            s.close();}catch(Exception ignored){try{s.close();}catch(Exception x){}}}
        String readLine(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();int c,prev=-1;while((c=in.read())!=-1){if(prev=='\r'&&c=='\n'){b.write('\r');break;}b.write(c);prev=c;if(b.size()>8192)break;}String x=b.toString("ISO-8859-1");return x.replace("\r","").replace("\n","");}
        byte[] asset(String n)throws IOException{InputStream i=ctx.getAssets().open(n);try{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}finally{try{i.close();}catch(Exception ignored){}}}
        String mimeType(String n){String x=n.toLowerCase(Locale.ROOT);if(x.endsWith(".html"))return "text/html; charset=utf-8";if(x.endsWith(".js"))return "application/javascript; charset=utf-8";if(x.endsWith(".css"))return "text/css; charset=utf-8";if(x.endsWith(".json"))return "application/json; charset=utf-8";if(x.endsWith(".png"))return "image/png";if(x.endsWith(".jpg")||x.endsWith(".jpeg"))return "image/jpeg";if(x.endsWith(".webp"))return "image/webp";if(x.endsWith(".svg"))return "image/svg+xml";if(x.endsWith(".ico"))return "image/x-icon";if(x.endsWith(".woff2"))return "font/woff2";if(x.endsWith(".woff"))return "font/woff";if(x.endsWith(".ttf"))return "font/ttf";return "application/octet-stream";}
        byte[] readAll(InputStream i)throws IOException{if(i==null)return new byte[0];ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}
        void write(OutputStream o,int code,String ct,byte[] data)throws IOException{String h="HTTP/1.1 "+code+" "+(code==200?"OK":code==503?"Service Unavailable":"Error")+"\r\nContent-Type: "+ct+"\r\nContent-Length: "+data.length+"\r\nConnection: close\r\n\r\n";o.write(h.getBytes(StandardCharsets.ISO_8859_1));o.write(data);o.flush();}
        void stopServer(){running=false;try{if(ss!=null)ss.close();}catch(Exception ignored){}}
    }
}
