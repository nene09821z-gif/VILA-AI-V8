# VILA AI Gateway backend (V54.0.0)

This is the optional server component for central provider keys and adaptive routing. It is a source backend; it is not already deployed by this ZIP.

## Local test

Requires Node.js 20 or newer. From this folder:

```sh
cp .env.example .env
npm install
npm test
npm start
```

With the example configuration, development runs with `AUTH_MODE=off` only for local testing and health checks. Provider-backed requests will fail until at least one provider key and the matching model configuration are set in `.env`. Do not expose this dev configuration to the public Internet.

## Production deployment

1. Deploy to a managed Node.js host or container service with HTTPS.
2. Set `NODE_ENV=production`, `AUTH_MODE=firebase`, `FIREBASE_PROJECT_ID=vila-studio`, and `CORS_ORIGINS` to the exact application/web origins you use. Android WebView may send the literal `null` origin; allow `null` only if required by your native app and still require Firebase bearer-token verification. Production refuses `AUTH_MODE=off` and wildcard CORS (`CORS_ORIGINS=*`). If `CORS_ORIGINS` is omitted in production, cross-origin browser requests are denied by default. List only the exact origins your clients use; keep bearer-token verification enabled even when allowing an origin.
3. Configure Firebase Admin using workload/Application Default Credentials on a supported cloud host, or put the full service-account JSON in `FIREBASE_SERVICE_ACCOUNT_JSON` using the host's secret manager. Never commit that secret or place it in the APK.
4. Add only provider keys you intend to use: `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `OPENAI_API_KEY`, `DEEPSEEK_API_KEY`, `MISTRAL_API_KEY`, `TOGETHER_API_KEY`, `FIREWORKS_API_KEY`, `GROQ_API_KEY`, `CEREBRAS_API_KEY`, and optionally `CUSTOM_API_KEY` with its administrator-controlled Base URL. All provider keys are server environment secrets. The new OpenAI-compatible providers also require valid provider-specific model IDs (for example `OPENAI_GENERAL_MODEL`); they are not usable merely by adding a key.
5. Set `VILA_APP_LATEST_VERSION=52.0.0` and optionally `VILA_APP_RELEASE_URL=https://...` to your trusted HTTPS release page. This powers the in-app update check; Android installation still requires user consent.
6. In VILA's **AI Gateway** panel, enter the deployed HTTPS base URL, check server health, scan configured models, and enable server routing. Keep routing disabled until health/auth are verified.


## Container deployment (V52)

The project root includes `compose.yaml` and `.env.production.example` for an initial V52 deployment. Copy the example to a private `.env`, replace all placeholders, then run `docker compose up -d --build`. The Compose file binds the Gateway to `127.0.0.1:8787` and uses `/health/live`; put a correctly configured HTTPS reverse proxy in front before allowing public access. Do not expose raw port 8787 directly to the Internet.

The container uses `restart: unless-stopped`, liveness checks and graceful shutdown to improve recovery. These features are **not** an uptime/SLA guarantee. The source does not provision a cloud server, certificate, alerting system or multi-region failover. Rate-limit windows, breaker state and counters remain in memory; use shared storage/coordination before deploying multiple replicas or implementing paid usage accounting.

## Optional Agent Server kept from V41

The project also preserves the existing Agent Server API used by the app's long-response proxy and build/test–repair workflow. It is a separate process from the Gateway and must use a different port, for example:

```sh
PORT=8788 npm run start:agent
```

The app's **Agent Server (optional)** setting should point to the agent server URL and use the same random `VILA_SERVER_TOKEN` set on the host. `GEMINI_API_KEY` is shared, while `AGENT_GEMINI_BASE_URL` and `AGENT_GEMINI_MODEL` configure the proxy independently from the Gateway's Gemini REST adapter. `/api/health` can report status; protected endpoints include `/api/chat` and `/api/build`.

**Build endpoint safety:** `ALLOW_UNTRUSTED_BUILDS` is `false` by default. Enabling it allows submitted project build scripts to execute in the server's environment. Only enable it in an isolated build worker/container you control, with limited permissions, no production secrets mounted into builds, CPU/memory/time limits and temporary storage cleanup. Keep `VILA_SERVER_TOKEN` strong and only expose the service over HTTPS. Do not expose an arbitrary-build worker directly to the public Internet.

## V52 multi-team reasoning and per-team engines

The Gateway can keep simple questions on a single model and allocate harder prompts to a bounded researcher/expert-or-coder/critic/synthesizer workflow. The UI's **Suy nghĩ** option requests deep mode only when the app is using a deployed V52 Gateway; direct-provider mode does not silently run these server-side teams.

Optional environment variables can pin a team to a provider and a provider-specific model ID:

- Research: `VILA_TEAM_RESEARCHER_PROVIDER` / `VILA_TEAM_RESEARCHER_MODEL`
- General expert: `VILA_TEAM_EXPERT_PROVIDER` / `VILA_TEAM_EXPERT_MODEL`
- Coding: `VILA_TEAM_CODER_PROVIDER` / `VILA_TEAM_CODER_MODEL`
- Vision/text: `VILA_TEAM_VISION_PROVIDER` / `VILA_TEAM_VISION_MODEL`
- Critic: `VILA_TEAM_CRITIC_PROVIDER` / `VILA_TEAM_CRITIC_MODEL`
- Synthesis: `VILA_TEAM_SYNTHESIZER_PROVIDER` / `VILA_TEAM_SYNTHESIZER_MODEL`

Use provider IDs `gemini`, `openrouter`, `openai`, `deepseek`, `mistral`, `together`, `fireworks`, `groq`, `cerebras`, or `custom`; `auto` leaves the choice to the task-aware router. Model IDs are provider-specific and must be enabled for the account. The reviewer prefers a different configured provider when possible; if stages reuse a provider, the result carries a caveat. Multi-team calls can increase latency, token consumption and external API charges. Search source URLs are taken from provider grounding/citation metadata only; no model can guarantee factual accuracy.

For operating limits, health checks, privacy implications and the 20 integrated techniques, read the root `VILA_AI_V52_TECHNOLOGY_MAP.md` and `CHANGELOG_V52_AI_TEAMS.md`.

## API surface

- `GET /health/live` — process liveness only.
- `GET /health/ready` — readiness of Firebase Admin and at least one configured provider (not a live provider ping).
- `GET /health` — basic operational health and configured provider count. It does not disclose keys.
- `GET /v1/app/version` — public version/release metadata (never secrets).
- `GET /v1/gateway/providers` — provider configuration and health state; Firebase-authenticated in production.
- `POST /v1/gateway/check` — bounded server-side provider check; authenticated.
- `GET /v1/models` — merged model list from configured providers; authenticated.
- `GET /v1/gateway/usage` — in-memory request counters; authenticated.
- `GET /v1/gateway/status` — provider health, circuit-breaker snapshots, and active limits; authenticated.
- `POST /v1/chat/completions` — normalized chat request and optional SSE stream; authenticated in production.

## Gateway reliability controls

- The router uses a process-local circuit breaker: after `CIRCUIT_BREAKER_FAILURE_THRESHOLD` retryable failures, a provider is temporarily skipped for `CIRCUIT_BREAKER_COOLDOWN_MS`; after cooldown, only one half-open probe is allowed.
- Auto-routing can move to another configured provider after provider-specific authentication/quota failures (401/402/403), retryable availability errors, and model-not-found errors. It will not retry invalid request payloads (400/422). Explicit provider selection remains explicit and does not silently switch providers.
- `MAX_CONCURRENT_REQUESTS_PER_USER` limits simultaneous chat requests; `MAX_PROVIDER_ATTEMPTS` bounds auto-routing attempts (1–10; default 8), so the expanded provider pool can be tried without unbounded retries. `X-VILA-Request-Id` appears on all responses and metadata-only logs omit prompts, credentials, and bearer tokens.
- `GET /v1/gateway/status` reports circuit states and limits without revealing provider keys.

## Reliability and limitations

- Retry/fallback is bounded and limited to retryable upstream failures. Authentication/permission failures do not trigger retry loops. A stream cannot switch provider after output has begun.
- Rate limits, circuit-breaker state, concurrency counters, and usage counters are per process/in-memory; they reset on restart and are not a durable billing ledger. Add a persistent datastore/shared limiter before running multiple replicas or offering paid usage.
- The router only chooses from configured server-side providers; actual model capability, quota, account access, region, prices, and provider availability remain upstream-controlled.
- `CUSTOM_BASE_URL` is administrator-controlled to prevent clients from turning the service into an arbitrary-URL proxy/SSRF primitive. Do not add client-supplied server target URLs.
- A health check cannot repair provider account restrictions, invalid secrets, outages, or unsupported model features. It reports actionable errors rather than silently changing credentials/settings.
- Add HTTPS, rate limits, secret manager, logs with redaction, backups, monitoring, and cost alerts before public release. Configure CORS narrowly.


## Live model catalog and layout reliability

- `GET /v1/models` discovers chat-capable model IDs from each configured provider's live `/models` API. Gemini discovery follows `nextPageToken` for up to 10 pages; compatible providers are queried using their `/models` endpoint.
- Catalog output includes provider ID, context-length metadata when supplied upstream, modality information, and free-tier hints when provider metadata explicitly indicates zero price. These are discovery hints, not a guarantee of quota or access.
- The Android Gateway console allows searching the server catalog and pinning an exact `provider:model-id` for chat, or returning to auto-routing. A model is only selectable from the live server catalog, not from stale local-only names.
- The modal content area now owns the remaining height in its flex layout and scrolls independently, preventing the lower half from being clipped on small Android WebViews.


## V53.6 provider-pool expansion

The Gateway now supports optional OpenAI-compatible adapters for OpenAI, DeepSeek, Mistral, Together AI, and Fireworks AI alongside Gemini, OpenRouter, Groq, Cerebras, and administrator-configured Custom API. The router still only calls providers with a configured key, valid base URL, and usable model ID. No cloud servers, API accounts, keys, quotas, or free usage are provisioned by this source ZIP. Add credentials through the deployment platform's secret manager, then set task-specific model IDs and use `/v1/gateway/check` and `/v1/models` to validate availability. The adaptive router and multi-team review remain bounded; multiple calls may cost more and do not guarantee correctness.
