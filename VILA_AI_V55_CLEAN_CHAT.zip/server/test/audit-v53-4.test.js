'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const teams = require('../src/teams');
const engine = require('../src/engine');
const { ProviderCircuitBreaker } = require('../src/reliability');

test('server.js imports every teams/engine helper it uses (a missing import silently disabled multi-team mode)', () => {
  const src = fs.readFileSync(path.join(__dirname, '../src/server.js'), 'utf8');
  for (const [mod, exported] of [['./teams', Object.keys(teams)], ['./engine', Object.keys(engine)]]) {
    const m = src.match(new RegExp(`const \\{([^}]*)\\} = require\\('${mod.replace('.', '\\.')}'\\)`));
    assert.ok(m, `server.js must destructure ${mod}`);
    const imported = new Set(m[1].split(',').map(x => x.trim()).filter(Boolean));
    const body = src.replace(m[0], '');
    for (const name of exported) {
      if (!/^[a-z]/.test(name)) continue;
      const used = new RegExp(`(^|[^.\\w])${name}\\s*\\(`).test(body);
      if (used) assert.ok(imported.has(name), `${name} is used in server.js but not imported from ${mod}`);
    }
  }
});

test('stripUnverifiedReferenceSection removes only a trailing reference heading, never ordinary prose', () => {
  const strip = teams.stripUnverifiedReferenceSection;
  const prose = 'Câu trả lời dài.\nSources of error include A and B.\nKết luận quan trọng.';
  assert.equal(strip(prose), prose);
  assert.equal(strip('Nội dung.\n\n**Nguồn tham khảo**\n- https://a.example'), 'Nội dung.');
  assert.equal(strip('Nội dung.\n\n## References:\n1. foo'), 'Nội dung.');
  assert.equal(strip('Nội dung.\nSources\n- x'), 'Nội dung.');
  assert.equal(strip('References are discussed in the text. Fine.'), 'References are discussed in the text. Fine.');
});

test('citation block keeps URLs with parentheses clickable in Markdown', () => {
  const block = teams.formatCitationBlock([{ title: 'Wiki', url: 'https://en.wikipedia.org/wiki/Foo_(bar)' }]);
  assert.match(block, /\(https:\/\/en\.wikipedia\.org\/wiki\/Foo_%28bar%29\)/);
});

test('auth-error providers are re-probed once after the retry window instead of being skipped forever', () => {
  let now = 1000;
  const cb = new ProviderCircuitBreaker({ authRetryMs: 10000, now: () => now });
  cb.failure('gemini', { retryable: false, status: 403, message: 'permission' });
  assert.equal(cb.acquire('gemini').allowed, false);
  now += 10001;
  const probe = cb.acquire('gemini');
  assert.equal(probe.allowed, true);
  assert.equal(cb.acquire('gemini').allowed, false, 'only one probe at a time');
  cb.failure('gemini', { retryable: false, status: 403, message: 'still bad' });
  assert.equal(cb.acquire('gemini').allowed, false, 'a failed probe restarts the window');
  now += 10001;
  assert.equal(cb.acquire('gemini').allowed, true);
  cb.success('gemini');
  assert.equal(cb.snapshot('gemini').state, 'closed');
});

test('Retry-After parsing and circuit breaker honour a provider-supplied back-off', () => {
  const { parseRetryAfterMs } = require('../src/reliability');
  assert.equal(parseRetryAfterMs('2'), 2000);
  assert.equal(parseRetryAfterMs('0.5'), 500);
  assert.equal(parseRetryAfterMs(''), 0);
  assert.equal(parseRetryAfterMs('garbage'), 0);
  assert.equal(parseRetryAfterMs('99999'), 120000);
  assert.equal(parseRetryAfterMs(new Date(10000).toUTCString(), 4000), 6000);
  let now = 1000;
  const cb = new ProviderCircuitBreaker({ failureThreshold: 5, cooldownMs: 30000, now: () => now });
  cb.failure('groq', { retryable: true, status: 429, message: 'quota', retryAfterMs: 8000 });
  assert.equal(cb.acquire('groq').allowed, false, 'opens at once on an explicit Retry-After, without waiting for 5 failures');
  now += 8001;
  assert.equal(cb.acquire('groq').allowed, true);
});

test('task classifier no longer treats everyday words like "project"/"build" as coding', () => {
  const { classifyTask } = engine;
  const ask = text => classifyTask([{ role: 'user', content: text }]);
  assert.equal(ask('Tôi đang quản lý một project xây nhà, build the team thế nào?'), 'general');
  assert.equal(ask('Fix lỗi build apk bằng gradle giúp mình'), 'coding');
  assert.equal(ask('viết code python sắp xếp mảng'), 'coding');
});
