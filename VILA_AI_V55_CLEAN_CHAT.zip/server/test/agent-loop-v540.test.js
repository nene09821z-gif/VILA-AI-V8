'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createAgentLoop } = require('../src/agent-loop');
const { runAgentTool } = require('../src/tools');

const tc = (id, name, args) => ({ id, type: 'function', function: { name, arguments: typeof args === 'string' ? args : JSON.stringify(args) } });
const reply = (message) => ({ choices: [{ message }] });
function harness(script, max = 8) {
  const sent = []; let i = 0;
  const loop = createAgentLoop({
    upstreamFor: async (_p, _m, body) => { sent.push(body); const r = script[Math.min(i++, script.length - 1)]; return { ok: true, text: async () => JSON.stringify(r) }; },
    releaseResponse() {}, toOpenAIShape: x => x, runAgentTool, maxCalls: () => max
  });
  return { loop, sent };
}
test('multi-step: calculator result feeds a second tool, then final answer', async () => {
  const { loop, sent } = harness([
    reply({ content: null, tool_calls: [tc('a', 'vila_calculate', { expression: '6*7' })] }),
    reply({ content: null, tool_calls: [tc('b', 'vila_analyze_text', { text: 'một hai ba' })] }),
    reply({ content: 'Xong: 42, 3 từ' })
  ]);
  const initial = reply({ content: null, tool_calls: [tc('0', 'vila_calculate', { expression: '1+1' })] });
  const r = await loop({ type: 'openai' }, 'm', initial, { messages: [{ role: 'user', content: 'x' }] }, { uid: 'u' });
  assert.equal(r.toolCalls, 3); assert.equal(r.data.choices[0].message.content, 'Xong: 42, 3 từ');
  assert.deepEqual(r.trace.map(t => t.tool), ['vila_calculate', 'vila_calculate', 'vila_analyze_text']);
  const toolMsgs = sent[0].messages.filter(m => m.role === 'tool'); assert.equal(JSON.parse(toolMsgs[0].content).result.result, 2);
});
test('budget is enforced and a perpetual tool-caller is cut off with forced final answer', async () => {
  const forever = reply({ content: null, tool_calls: [tc('x', 'vila_calculate', { expression: '1+1' })] });
  const { loop, sent } = harness([forever], 3);
  const r = await loop({ type: 'openai' }, 'm', forever, { messages: [{ role: 'user', content: 'x' }] });
  assert.equal(r.toolCalls, 3); assert.equal(sent.at(-1)._vilaForceFinal, true); assert.ok(sent.length <= 5);
});
test('malformed args, unknown tools and disabled tools become error results, not crashes', async () => {
  const { loop, sent } = harness([reply({ content: 'ok' })]);
  const initial = reply({ content: null, tool_calls: [tc('1', 'vila_calculate', '{bad'), tc('2', 'rm_rf', {}), tc('3', 'vila_run_code', { language: 'python', code: 'print(1)' })] });
  const r = await loop({ type: 'openai' }, 'm', initial, { messages: [] });
  const tools = sent[0].messages.filter(m => m.role === 'tool').map(m => JSON.parse(m.content));
  assert.equal(tools[0].ok, false); assert.equal(tools[1].ok, false); assert.equal(tools[2].ok, false); assert.equal(r.data.choices[0].message.content, 'ok');
});
test('upstream failure during a tool round is surfaced so the gateway can fall back', async () => {
  const loop = createAgentLoop({ upstreamFor: async () => ({ ok: false, status: 429, text: async () => 'rate' }), releaseResponse() {}, toOpenAIShape: x => x, runAgentTool, maxCalls: () => 4 });
  await assert.rejects(() => loop({ type: 'openai' }, 'm', reply({ tool_calls: [tc('1', 'vila_calculate', { expression: '1' })] }), { messages: [] }), /HTTP 429/);
});

test('context compaction shortens old tool outputs but keeps the latest ones intact', () => {
  const { compactMessages } = require('../src/agent-loop');
  const big = 'x'.repeat(5000);
  const msgs = [{ role: 'user', content: 'q' }, { role: 'tool', content: big }, { role: 'tool', content: big }, { role: 'tool', content: big }, { role: 'tool', content: big }];
  const n = compactMessages(msgs, 8000, 2);
  assert.ok(n >= 1); assert.match(msgs[1].content, /rút gọn/); assert.equal(msgs[4].content.length, 5000); assert.equal(msgs[3].content.length, 5000);
  assert.equal(compactMessages([{ role: 'user', content: 'short' }], 8000), 0);
});
test('per-user tool quota blocks excess calls and isolates users', async () => {
  const env = { VILA_TOOL_CALLS_PER_MIN: '3' };
  for (let i = 0; i < 3; i++) assert.equal((await runAgentTool('vila_calculate', { expression: '1+1' }, { uid: 'q1', env })).out.ok, true);
  const blocked = await runAgentTool('vila_calculate', { expression: '1+1' }, { uid: 'q1', env });
  assert.equal(blocked.out.ok, false); assert.match(blocked.out.error, /hạn mức/);
  assert.equal((await runAgentTool('vila_calculate', { expression: '1+1' }, { uid: 'q2', env })).out.ok, true);
});
