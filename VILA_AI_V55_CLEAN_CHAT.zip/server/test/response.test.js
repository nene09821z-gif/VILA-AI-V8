'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { openAIContent, hasAssistantContent, sseLineHasAssistantText, emptyAssistantResponseMessage } = require('../src/response');

test('blank and missing assistant content is not treated as a completed answer', () => {
  for (const data of [
    {},
    { choices: [] },
    { choices: [{ message: { role: 'assistant', content: '' }, finish_reason: 'stop' }] },
    { choices: [{ message: { role: 'assistant', content: '   ' }, finish_reason: 'length' }] },
    { choices: [{ message: { role: 'assistant' } }] }
  ]) {
    assert.equal(openAIContent(data), '');
    assert.equal(hasAssistantContent(data), false);
  }
  assert.match(emptyAssistantResponseMessage('Gemini', { choices: [{ finish_reason: 'length' }] }), /Gemini.*không có nội dung.*finish_reason=length.*không coi.*thành công/);
});

test('assistant text extraction accepts string and typed content parts', () => {
  assert.equal(openAIContent({ choices: [{ message: { content: '  Xin chào  ' } }] }), 'Xin chào');
  assert.equal(openAIContent({ choices: [{ message: { content: [{ type: 'text', text: 'VILA' }, { text: ' AI' }] } }] }), 'VILA AI');
  assert.equal(hasAssistantContent({ choices: [{ message: { content: [{ text: 'có câu trả lời' }] } }] }), true);
});

test('stream detector only counts assistant text, not [DONE], metadata, or empty deltas', () => {
  assert.equal(sseLineHasAssistantText('data: [DONE]'), false);
  assert.equal(sseLineHasAssistantText('event: message'), false);
  assert.equal(sseLineHasAssistantText('data: {"choices":[{"delta":{}}]}'), false);
  assert.equal(sseLineHasAssistantText('data: {"choices":[{"delta":{"content":" \n"}}]}'), false);
  assert.equal(sseLineHasAssistantText('data: {"choices":[{"delta":{"content":"Xin chào"}}]}'), true);
  assert.equal(sseLineHasAssistantText('data: {"choices":[{"message":{"content":[{"text":"VILA"}]}}]}'), true);
});

test('chat handler validates content before recording a successful provider answer and falls over on empty output', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/server.js'), 'utf8');
  const validation = source.indexOf('if (!hasAssistantContent(data))');
  const success = source.indexOf('recordProviderSuccess();', validation);
  const fallback = source.indexOf('if (!shouldFallback(requestedProvider, 502, lastFailure.message)) break;', validation);
  assert.ok(validation >= 0, 'the direct-response route must reject empty assistant content');
  assert.ok(fallback > validation && success > validation, 'empty output must be handled before success is recorded');
  assert.match(source.slice(validation, success), /healthCache\.set\(provider\.id, \{ state: 'empty-response'/);
  assert.match(source, /sseLineHasAssistantText/);
});
