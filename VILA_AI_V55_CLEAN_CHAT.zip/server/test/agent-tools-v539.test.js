'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { TOOL_DEFINITIONS, calculate, safeExecuteTool } = require('../src/agent-tools');

test('Agent exposes only bounded allowlisted function schemas', () => {
  assert.equal(TOOL_DEFINITIONS.length, 3);
  assert.ok(TOOL_DEFINITIONS.every(x => x.type === 'function' && x.function.parameters.additionalProperties === false));
});
test('calculator handles precedence, parentheses, and unary operators', () => {
  assert.equal(calculate('(12 + 8) * 3').result, 60);
  assert.equal(calculate('-2 + 8 / 4').result, 0);
});
test('calculator rejects arbitrary code and division by zero', () => {
  assert.throws(() => calculate('process.exit()'));
  assert.throws(() => calculate('4/0'));
});
test('text tool returns counts and enforces input bounds', () => {
  const result = safeExecuteTool('vila_analyze_text', { text: 'hello world\nVILA' });
  assert.deepEqual(result, { ok: true, result: { characters: 16, words: 3, lines: 2 } });
  assert.equal(safeExecuteTool('vila_analyze_text', { text: 'x'.repeat(20001) }).ok, false);
});
test('unknown tool names are rejected', () => {
  assert.equal(safeExecuteTool('run_shell', { command: 'id' }).ok, false);
});
test('timezone tool validates IANA timezone', () => {
  assert.equal(safeExecuteTool('vila_get_current_time', { timezone: 'Asia/Ho_Chi_Minh' }).ok, true);
  assert.equal(safeExecuteTool('vila_get_current_time', { timezone: 'bad/timezone' }).ok, false);
});
