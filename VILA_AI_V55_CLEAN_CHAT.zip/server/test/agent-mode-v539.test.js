'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');

test('Agent mode is opt-in in UI and forces non-streaming for tool rounds', () => {
  const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
  assert.match(html, /id="agentModeToggle"/);
  assert.match(html, /agentMode:\!\!document\.getElementById\('agentModeToggle'\)/);
  assert.match(html, /const stream=options\.stream!==false&&!options\.agentMode/);
  assert.match(html, /agentMode\?false:stream/);
});
test('Gateway uses allowlisted tools, bounds calls, and skips incompatible Gemini provider for agent mode', () => {
  const server = fs.readFileSync(path.join(root, 'server/src/server.js'), 'utf8');
  assert.match(server, /reqBody\.tools = getToolDefinitions\(\)/);
  assert.match(server, /VILA_AGENT_MAX_TOOL_CALLS/);
  assert.match(server, /body\.agentMode === true\) candidates = candidates\.filter\(p => p\.type !== 'gemini'\)/);
  assert.match(server, /delete body\._vilaForceFinal/);
});
