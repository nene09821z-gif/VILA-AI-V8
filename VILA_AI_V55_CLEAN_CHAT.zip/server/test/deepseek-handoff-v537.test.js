'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');
const activity = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server/src/server.js'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');

test('DeepSeek external handoff is explicit user-initiated Android share, not private session access', () => {
  assert.match(activity, /JavascriptInterface public void shareToDeepSeek\(String prompt\)/);
  assert.match(activity, /Intent\.ACTION_SEND/);
  assert.match(activity, /Intent\.createChooser\(send, "Chia sẻ câu hỏi tới DeepSeek"\)/);
  assert.match(activity, /https:\/\/chat\.deepseek\.com\//);
  assert.match(html, /id="deepSeekExternalBtn"/);
  assert.match(html, /window\.Android\.shareToDeepSeek\(prompt\)/);
});

test('DeepSeek API remains server-side configured and fallback gateway remains enabled', () => {
  const env = fs.readFileSync(path.join(root, 'server/.env.example'), 'utf8');
  assert.match(env, /^DEEPSEEK_API_KEY=$/m);
  assert.match(env, /^DEEPSEEK_BASE_URL=https:\/\/api\.deepseek\.com\/v1$/m);
  assert.match(server, /make\('deepseek', 'DeepSeek', 'openai', 'DEEPSEEK_API_KEY'/);
  assert.match(server, /rankProviders\(providerList, task/);
});

test('app and gateway versions are synchronized to 54.0.0', () => {
  assert.match(gradle, /versionName "54\.0\.0"/);
  assert.match(server, /const APP_VERSION = '54\.0\.0'/);
});


test('V53.8 has an explicit opt-in accessibility bot and preserves manual share/API paths', () => {
  const service = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/DeepSeekAccessibilityService.java'), 'utf8');
  const manifest = fs.readFileSync(path.join(root, 'app/src/main/AndroidManifest.xml'), 'utf8');
  assert.match(manifest, /android\.permission\.BIND_ACCESSIBILITY_SERVICE/);
  assert.match(service, /ACTION_SET_TEXT/);
  assert.match(service, /90000L/);
  assert.match(activity, /startDeepSeekBot\(String prompt\)/);
  assert.match(html, /id="deepSeekBotBtn"/);
  assert.match(html, /onVilaDeepSeekBotResult/);
  assert.match(html, /sharePromptToDeepSeek/);
  assert.match(server, /make\('deepseek', 'DeepSeek', 'openai', 'DEEPSEEK_API_KEY'/);
});
