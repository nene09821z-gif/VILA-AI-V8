'use strict';
// Code execution tool. DEFENSE IN DEPTH, NOT A SECURITY BOUNDARY:
// for hostile multi-tenant use, run the whole gateway in a container with no network/no secrets.
// Enabled only when VILA_ENABLE_CODE_EXEC=true.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const MAX_CODE = 20000;
const MAX_OUT = 8000;
const DEFAULT_TIMEOUT = 5000;

// JS: user code runs inside a fresh vm context that has NO host objects (console is defined inside
// the context and results are read back as a plain string, so no host Function can leak).
// Child is also started with Node's permission model (no fs / child_process / worker) and a heap cap.
const JS_RUNNER = `
const vm = require('node:vm');
const code = process.env.VILA_CODE; const timeout = Number(process.env.VILA_TIMEOUT) || 5000;
delete process.env.VILA_CODE;
const ctx = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });
const prelude = 'var __out=[];var console={log:function(){__out.push(Array.prototype.map.call(arguments,function(a){try{return typeof a==="string"?a:JSON.stringify(a)}catch(e){return String(a)}}).join(" "))}};console.error=console.warn=console.info=console.log;';
vm.runInContext(prelude, ctx);
let err = '';
try { vm.runInContext(code, ctx, { timeout, displayErrors: false }); } catch (e) { err = String((e && e.message) || e).slice(0, 500); }
const out = vm.runInContext('__out.join("\\\\n")', ctx);
process.stdout.write(JSON.stringify({ out: String(out).slice(0, ${MAX_OUT}), err }));
`;

const PY_RUNNER = String.raw`
import sys, os, json, io, resource, builtins
resource.setrlimit(resource.RLIMIT_AS, (256*1024*1024,)*2)
resource.setrlimit(resource.RLIMIT_CPU, (int(os.environ.get("VILA_CPU","5")),)*2)
resource.setrlimit(resource.RLIMIT_NPROC, (0,0)) if hasattr(resource,"RLIMIT_NPROC") else None
resource.setrlimit(resource.RLIMIT_FSIZE, (1_000_000,)*2)
code = os.environ.pop("VILA_CODE","")
STDLIB = tuple(os.path.realpath(p)+os.sep for p in {os.path.dirname(os.__file__), sys.prefix, sys.base_prefix} if p)
BLOCK = ("socket.","subprocess.","os.system","os.exec","os.posix_spawn","os.spawn","os.fork","os.forkpty","ctypes.","os.remove","os.rename","os.rmdir","os.mkdir","os.chmod","os.chown","os.symlink","os.link","os.truncate","shutil.","os.putenv","os.kill","pty.","fcntl.","mmap.","webbrowser.","ensurepip","sqlite3.connect","winreg.","signal.","os.listdir","os.scandir","os.chdir","os.walk","glob.","tempfile.","urllib.","http.","ftplib.","smtplib.","telnetlib.","multiprocessing.","concurrent.","_thread.start_new_thread","threading.Thread")
def hook(ev,args):
    if ev=="open":
        p=args[0]; mode=args[1] if len(args)>1 and isinstance(args[1],str) else "r"; flags=args[2] if len(args)>2 and isinstance(args[2],int) else 0
        writing = any(c in (mode or "") for c in "wax+") or (flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_APPEND))
        try: rp=os.path.realpath(p if isinstance(p,(str,bytes)) else "") if not isinstance(p,int) else None
        except Exception: rp=""
        if isinstance(rp,bytes): rp=rp.decode(errors="ignore")
        if writing or (rp is not None and not rp.startswith(STDLIB)): raise PermissionError("blocked: file access")
        return
    for b in BLOCK:
        if ev.startswith(b) or ev==b.rstrip("."): raise PermissionError("blocked: "+ev)
buf=io.StringIO(); real=sys.stdout; sys.stdout=buf; sys.stderr=buf
for m in ("math","json","re","statistics","itertools","functools","collections","datetime","decimal","fractions","random","string","textwrap","heapq","bisect","operator","time","hashlib","base64","csv","unicodedata"):
    try: __import__(m)
    except Exception: pass
sys.addaudithook(hook)
err=""
try:
    exec(compile(code,"<agent>","exec"),{"__name__":"__main__","__builtins__":builtins})
except BaseException as e:
    err=(type(e).__name__+": "+str(e))[:500]
sys.stdout=real
real.write(json.dumps({"out":buf.getvalue()[:8000],"err":err}))
`;

function runChild(cmd, args, { code, timeoutMs, extraEnv = {}, cwd }) {
  return new Promise(resolve => {
    const env = { PATH: process.env.PATH || '/usr/bin:/bin', VILA_CODE: code, VILA_TIMEOUT: String(timeoutMs), VILA_CPU: String(Math.ceil(timeoutMs / 1000) + 1), ...extraEnv };
    const p = spawn(cmd, args, { cwd, env, shell: false, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '', err = ''; let done = false;
    const finish = r => { if (done) return; done = true; clearTimeout(timer); resolve(r); };
    p.stdout.on('data', d => { out += d; if (out.length > 200000) { try { p.kill('SIGKILL'); } catch {} } });
    p.stderr.on('data', d => { err += d; if (err.length > 20000) err = err.slice(-20000); });
    p.on('error', e => finish({ ok: false, error: `Không chạy được: ${e.message}` }));
    p.on('close', (c, sig) => {
      try { const j = JSON.parse(out); finish({ ok: true, ...j }); }
      catch { finish({ ok: false, error: sig ? `Tiến trình bị dừng (${sig}).` : `Lỗi chạy mã (exit ${c}): ${err.slice(-300)}` }); }
    });
    const timer = setTimeout(() => { try { p.kill('SIGKILL'); } catch {} finish({ ok: false, error: 'Hết thời gian chạy.' }); }, timeoutMs + 1500);
  });
}

async function runCode({ language, code }, env = process.env) {
  if (String(env.VILA_ENABLE_CODE_EXEC || '').toLowerCase() !== 'true') throw new Error('Chạy mã đang tắt trên server (đặt VILA_ENABLE_CODE_EXEC=true trong môi trường được cô lập).');
  const lang = String(language || '').toLowerCase();
  const src = String(code || ''); if (!src.trim() || src.length > MAX_CODE) throw new Error(`Mã trống hoặc vượt ${MAX_CODE} ký tự.`);
  const timeoutMs = Math.max(500, Math.min(15000, Number(env.VILA_CODE_TIMEOUT_MS) || DEFAULT_TIMEOUT));
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'vila-run-'));
  try {
    let r;
    if (lang === 'javascript' || lang === 'js') {
      r = await runChild(process.execPath, ['--permission', '--max-old-space-size=64', '-e', JS_RUNNER], { code: src, timeoutMs, cwd });
      if (!r.ok && /permission|ERR_ACCESS_DENIED|unknown option|bad option/i.test(r.error || '')) r = await runChild(process.execPath, ['--max-old-space-size=64', '-e', JS_RUNNER], { code: src, timeoutMs, cwd });
    } else if (lang === 'python' || lang === 'py') {
      r = await runChild('python3', ['-I', '-S', '-c', PY_RUNNER], { code: src, timeoutMs, cwd });
    } else throw new Error('Chỉ hỗ trợ language = "javascript" hoặc "python".');
    if (!r.ok) throw new Error(r.error);
    return { language: lang, stdout: r.out, error: r.err || undefined };
  } finally { try { fs.rmSync(cwd, { recursive: true, force: true }); } catch {} }
}
module.exports = { runCode };
