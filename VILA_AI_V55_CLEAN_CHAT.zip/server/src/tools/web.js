'use strict';
// Real web tools: SSRF-safe fetch + pluggable search. Node built-ins only.
const dns = require('node:dns').promises;
const net = require('node:net');
const http = require('node:http');
const https = require('node:https');
const { Readable } = require('node:stream');

const MAX_BYTES = Number(process.env.VILA_FETCH_MAX_BYTES || 1_500_000);
const TIMEOUT_MS = Number(process.env.VILA_FETCH_TIMEOUT_MS || 12000);
const MAX_REDIRECTS = 3;
const MAX_TEXT_CHARS = 12000;

function ipv4ToInt(ip) { return ip.split('.').reduce((a, b) => (a * 256) + Number(b), 0); }
function inCidr4(ip, base, bits) {
  const mask = bits === 0 ? 0 : (0xFFFFFFFF << (32 - bits)) >>> 0;
  return ((ipv4ToInt(ip) & mask) >>> 0) === ((ipv4ToInt(base) & mask) >>> 0);
}
const BLOCKED_V4 = [['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10], ['127.0.0.0', 8], ['169.254.0.0', 16], ['172.16.0.0', 12], ['192.0.0.0', 24], ['192.0.2.0', 24], ['192.168.0.0', 16], ['198.18.0.0', 15], ['198.51.100.0', 24], ['203.0.113.0', 24], ['224.0.0.0', 4], ['240.0.0.0', 4]];

function isBlockedIp(ip) {
  const v = net.isIP(ip);
  if (v === 4) return BLOCKED_V4.some(([b, n]) => inCidr4(ip, b, n));
  if (v === 6) {
    const l = ip.toLowerCase();
    const mapped = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isBlockedIp(mapped[1]);
    const hexMapped = l.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
    if (hexMapped) { const a = parseInt(hexMapped[1], 16), b = parseInt(hexMapped[2], 16); return isBlockedIp(`${a >> 8}.${a & 255}.${b >> 8}.${b & 255}`); }
    if (l === '::' || l === '::1') return true;
    if (/^(fc|fd)/.test(l) || /^fe[89ab]/.test(l) || /^ff/.test(l)) return true;
    if (/^64:ff9b:/.test(l) || /^2001:db8:/.test(l)) return true;
    return false;
  }
  return true; // not an IP -> refuse
}

async function assertPublicUrl(rawUrl, { lookup = dns.lookup.bind(dns) } = {}) {
  let u;
  try { u = new URL(String(rawUrl)); } catch { throw new Error('URL không hợp lệ.'); }
  if (!/^https?:$/.test(u.protocol)) throw new Error('Chỉ hỗ trợ http/https.');
  if (u.username || u.password) throw new Error('URL không được chứa thông tin đăng nhập.');
  if (u.port && !['80', '443', '8080', '8443'].includes(u.port)) throw new Error('Cổng không được phép.');
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (/^(localhost|.*\.localhost|.*\.local|.*\.internal|metadata\.google\.internal)$/i.test(host)) throw new Error('Máy chủ nội bộ bị chặn.');
  const addrs = net.isIP(host) ? [{ address: host }] : await lookup(host, { all: true, verbatim: true });
  if (!addrs.length) throw new Error('Không phân giải được tên miền.');
  for (const a of addrs) if (isBlockedIp(a.address)) throw new Error('Địa chỉ nội bộ/riêng tư bị chặn (SSRF).');
  return { url: u, addresses: addrs.map(a => a.address) };
}

function decodeEntities(s) {
  return s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => { try { return String.fromCodePoint(Number(n)); } catch { return ''; } })
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => { try { return String.fromCodePoint(parseInt(n, 16)); } catch { return ''; } });
}
function htmlToText(html) {
  let s = String(html);
  const title = (s.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '';
  s = s.replace(/<(script|style|noscript|svg|template|iframe)[\s\S]*?<\/\1>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ');
  s = s.replace(/<\/(p|div|li|tr|h[1-6]|section|article|br)>|<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ' ');
  s = decodeEntities(s).replace(/[ \t\f\v]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  return { title: decodeEntities(title).trim().slice(0, 200), text: s };
}

async function readLimited(resp, maxBytes) {
  const reader = resp.body.getReader(); const chunks = []; let n = 0; let truncated = false;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    n += value.length;
    if (n > maxBytes) { chunks.push(value.slice(0, value.length - (n - maxBytes))); truncated = true; try { await reader.cancel(); } catch {} break; }
    chunks.push(value);
  }
  return { buf: Buffer.concat(chunks), truncated };
}

// Redirects are followed manually so every hop is re-validated.

// fetch-compatible client that connects ONLY to the IP we validated (closes the DNS-rebinding window
// between "check" and "connect"). TLS still verifies the certificate against the original hostname.
function pinnedFetch(rawUrl, init = {}, { lookup, allowPrivate = false } = {}) {
  return new Promise(async (resolve, reject) => {
    let u, addrs;
    try {
      if (allowPrivate) { u = new URL(rawUrl); addrs = [u.hostname]; }
      else ({ url: u, addresses: addrs } = await assertPublicUrl(rawUrl, { lookup }));
    } catch (e) { return reject(e); }
    const addr = addrs[0]; const family = net.isIP(addr);
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request({
      protocol: u.protocol, hostname: u.hostname.replace(/^\[|\]$/g, ''), port: u.port || undefined, path: u.pathname + u.search, method: init.method || 'GET',
      headers: init.headers || {}, servername: net.isIP(u.hostname) ? undefined : u.hostname, signal: init.signal,
      lookup: (_h, _o, cb) => cb(null, addr, family)
    }, res => {
      const headers = new Headers();
      for (const [k, v] of Object.entries(res.headers)) if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(', ') : String(v));
      const nullBody = [204, 205, 304].includes(res.statusCode) || (res.statusCode >= 300 && res.statusCode < 400);
      if (nullBody) res.resume();
      resolve(new Response(nullBody ? null : Readable.toWeb(res), { status: res.statusCode, headers }));
    });
    req.on('error', reject);
    if (init.body) req.write(init.body);
    req.end();
  });
}

async function safeFetch(rawUrl, { fetchImpl, lookup, maxBytes = MAX_BYTES, headers = {}, timeoutMs = TIMEOUT_MS } = {}) {
  const doFetch = fetchImpl || ((u, i) => pinnedFetch(u, i, { lookup }));
  let current = rawUrl;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const { url } = await assertPublicUrl(current, { lookup });
    const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    let resp;
    try {
      resp = await doFetch(url.href, { redirect: 'manual', signal: ctrl.signal, headers: { 'User-Agent': 'Mozilla/5.0 (compatible; VILA-Agent/1.0)', Accept: 'text/html,application/json,text/plain;q=0.9,*/*;q=0.5', ...headers } });
    } catch (e) { clearTimeout(timer); throw new Error(e?.name === 'AbortError' ? 'Hết thời gian chờ.' : `Không tải được: ${String(e?.message || e).slice(0, 120)}`); }
    if ([301, 302, 303, 307, 308].includes(resp.status)) {
      clearTimeout(timer);
      const loc = resp.headers.get('location'); if (!loc) throw new Error('Chuyển hướng không có Location.');
      current = new URL(loc, url).href; continue;
    }
    try {
      const { buf, truncated } = await readLimited(resp, maxBytes);
      return { status: resp.status, ok: resp.ok, finalUrl: url.href, contentType: resp.headers.get('content-type') || '', body: buf, truncated };
    } finally { clearTimeout(timer); }
  }
  throw new Error('Quá nhiều lần chuyển hướng.');
}

async function webFetch({ url, max_chars }, deps = {}) {
  const limit = Math.max(500, Math.min(MAX_TEXT_CHARS, Number(max_chars) || 8000));
  const r = await safeFetch(url, deps);
  if (!r.ok) throw new Error(`Máy chủ trả HTTP ${r.status}.`);
  const ct = r.contentType.toLowerCase();
  if (!/text\/|json|xml|html/.test(ct) && ct) throw new Error(`Loại nội dung không hỗ trợ: ${ct.slice(0, 60)}`);
  const raw = r.body.toString('utf8');
  const { title, text } = /html/.test(ct) || /^\s*<(!doctype|html)/i.test(raw) ? htmlToText(raw) : { title: '', text: raw };
  return { url: r.finalUrl, title, content: text.slice(0, limit), contentTruncated: text.length > limit || r.truncated, untrusted: true };
}

// ---- Search ----
function parseDuckDuckGoHtml(html) {
  const out = [];
  const re = /<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]+class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>)?/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 10) {
    let href = decodeEntities(m[1]);
    const uddg = href.match(/[?&]uddg=([^&]+)/); if (uddg) href = decodeURIComponent(uddg[1]);
    if (href.startsWith('//')) href = 'https:' + href;
    if (!/^https?:\/\//.test(href)) continue;
    out.push({ title: decodeEntities(m[2].replace(/<[^>]+>/g, '')).trim(), url: href, snippet: decodeEntities((m[3] || '').replace(/<[^>]+>/g, '')).trim() });
  }
  return out;
}

async function webSearch({ query, max_results }, deps = {}, env = process.env) {
  const q = String(query || '').trim(); if (!q || q.length > 300) throw new Error('Truy vấn không hợp lệ.');
  const n = Math.max(1, Math.min(8, Number(max_results) || 5));
  const f = deps.fetchImpl || fetch;
  const json = async (url, init) => { const r = await f(url, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS) }); if (!r.ok) throw new Error(`Search HTTP ${r.status}`); return r.json(); };
  if (env.TAVILY_API_KEY) {
    const d = await json('https://api.tavily.com/search', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.TAVILY_API_KEY}` }, body: JSON.stringify({ query: q, max_results: n }) });
    return { engine: 'tavily', results: (d.results || []).slice(0, n).map(x => ({ title: x.title, url: x.url, snippet: String(x.content || '').slice(0, 400) })) };
  }
  if (env.BRAVE_API_KEY) {
    const d = await json(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}&count=${n}`, { headers: { 'X-Subscription-Token': env.BRAVE_API_KEY, Accept: 'application/json' } });
    return { engine: 'brave', results: ((d.web && d.web.results) || []).slice(0, n).map(x => ({ title: x.title, url: x.url, snippet: String(x.description || '').replace(/<[^>]+>/g, '').slice(0, 400) })) };
  }
  if (env.SEARXNG_URL) {
    const base = env.SEARXNG_URL.replace(/\/$/, '');
    const d = await json(`${base}/search?q=${encodeURIComponent(q)}&format=json`, {});
    return { engine: 'searxng', results: (d.results || []).slice(0, n).map(x => ({ title: x.title, url: x.url, snippet: String(x.content || '').slice(0, 400) })) };
  }
  // Keyless best-effort fallback; scraping can break or be rate-limited, so say so.
  const r = await f(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; VILA-Agent/1.0)' }, signal: AbortSignal.timeout(TIMEOUT_MS) });
  if (!r.ok) throw new Error(`DuckDuckGo HTTP ${r.status}. Hãy cấu hình TAVILY_API_KEY, BRAVE_API_KEY hoặc SEARXNG_URL.`);
  const results = parseDuckDuckGoHtml(await r.text()).slice(0, n);
  if (!results.length) throw new Error('Không đọc được kết quả (có thể bị giới hạn). Hãy cấu hình TAVILY_API_KEY, BRAVE_API_KEY hoặc SEARXNG_URL.');
  return { engine: 'duckduckgo-html (best-effort)', results };
}

module.exports = { pinnedFetch, isBlockedIp, assertPublicUrl, safeFetch, htmlToText, webFetch, webSearch, parseDuckDuckGoHtml };
