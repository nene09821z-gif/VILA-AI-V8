'use strict';

/** Small process-local circuit breaker for upstream providers.
 * This deliberately is not a distributed breaker or billing ledger.
 */
class ProviderCircuitBreaker {
  constructor({ failureThreshold = 3, cooldownMs = 30000, authRetryMs = 300000, now = () => Date.now() } = {}) {
    this.authRetryMs = Math.max(5000, Math.min(3600000, Number(authRetryMs) || 300000));
    this.failureThreshold = Math.max(1, Math.min(20, Number(failureThreshold) || 3));
    this.cooldownMs = Math.max(1000, Math.min(600000, Number(cooldownMs) || 30000));
    this.now = now;
    this.states = new Map();
  }

  acquire(providerId, { force = false } = {}) {
    const id = String(providerId || '');
    const state = this.states.get(id);
    const now = this.now();
    if (!state) return { allowed: true, state: 'closed', probe: false };
    if (force) return { allowed: true, state: state.openUntil > now ? 'forced-open' : 'closed', probe: false };
    if (state.state === 'auth-error') {
      // A 401/403 can be transient (key rotated, quota/permission hiccup). Without a retry window a provider
      // would stay skipped by automatic routing until the process restarted, so allow one probe per window.
      const sinceFailure = now - (Number(state.lastFailureAt) || 0);
      if (sinceFailure < this.authRetryMs || state.probeInFlight) return { allowed: false, state: 'auth-error', retryAfterMs: Math.max(0, this.authRetryMs - sinceFailure) };
      state.probeInFlight = true;
      return { allowed: true, state: 'auth-error', probe: true };
    }
    if (state.openUntil > now) {
      return { allowed: false, state: 'open', retryAfterMs: state.openUntil - now };
    }
    if (state.openUntil > 0) {
      if (state.probeInFlight) return { allowed: false, state: 'half-open', retryAfterMs: 1000 };
      state.probeInFlight = true;
      return { allowed: true, state: 'half-open', probe: true };
    }
    return { allowed: true, state: 'closed', probe: false };
  }

  success(providerId, details = '') {
    const id = String(providerId || '');
    const previous = this.states.get(id) || {};
    this.states.set(id, {
      failures: 0, openUntil: 0, probeInFlight: false, state: 'closed',
      lastSuccessAt: this.now(), lastFailureAt: previous.lastFailureAt || null,
      lastError: '', message: String(details || 'Request thành công').slice(0, 180)
    });
  }

  failure(providerId, { retryable = true, status = 0, message = '', retryAfterMs = 0 } = {}) {
    const id = String(providerId || '');
    const now = this.now();
    const previous = this.states.get(id) || { failures: 0, openUntil: 0, probeInFlight: false };
    const next = { ...previous, probeInFlight: false, lastFailureAt: now, lastStatus: Number(status) || 0, lastError: String(message || '').slice(0, 180) };
    if (!retryable) {
      const authError = Number(status) === 401 || Number(status) === 403;
      next.state = authError ? 'auth-error' : (previous.openUntil > now ? 'open' : 'closed');
      if (authError || previous.openUntil <= now) {
        next.openUntil = 0;
        next.failures = 0;
      }
      this.states.set(id, next);
      return this.snapshot(id);
    }
    next.failures = (Number(previous.failures) || 0) + 1;
    const hinted = Math.max(0, Math.min(120000, Number(retryAfterMs) || 0));
    if (hinted > 0) {
      // The provider told us exactly how long to back off: honour it immediately instead of
      // sending more requests until the generic failure threshold is reached.
      next.openUntil = now + Math.max(hinted, 1000);
      next.state = 'open';
    } else if (previous.probeInFlight || next.failures >= this.failureThreshold) {
      next.openUntil = now + this.cooldownMs;
      next.state = 'open';
    } else {
      next.state = 'closed';
    }
    this.states.set(id, next);
    return this.snapshot(id);
  }

  snapshot(providerId) {
    const id = String(providerId || '');
    const state = this.states.get(id);
    if (!state) return { provider: id, state: 'closed', failures: 0, retryAfterMs: 0, lastSuccessAt: null, lastFailureAt: null, lastError: '' };
    const now = this.now();
    let label = state.state || 'closed';
    if (state.state === 'auth-error') label = 'auth-error';
    else if (state.openUntil > now) label = 'open';
    else if (state.openUntil > 0) label = state.probeInFlight ? 'half-open' : 'half-open-ready';
    else if (state.state === 'auth-error') label = 'auth-error';
    return {
      provider: id, state: label, failures: Number(state.failures) || 0,
      retryAfterMs: Math.max(0, (Number(state.openUntil) || 0) - now),
      lastSuccessAt: state.lastSuccessAt || null, lastFailureAt: state.lastFailureAt || null,
      lastError: String(state.lastError || '').slice(0, 180), lastStatus: Number(state.lastStatus) || 0
    };
  }

  all(providerIds) { return (Array.isArray(providerIds) ? providerIds : []).map(id => this.snapshot(id)); }
}

/** Parses an HTTP Retry-After header (delta-seconds or HTTP-date) into milliseconds, capped at 2 minutes. 0 = absent/invalid. */
function parseRetryAfterMs(value, now = Date.now()) {
  const raw = String(value == null ? '' : value).trim();
  if (!raw) return 0;
  let ms = 0;
  if (/^\d+(?:\.\d+)?$/.test(raw)) ms = Math.round(Number(raw) * 1000);
  else { const at = Date.parse(raw); if (Number.isFinite(at)) ms = at - now; }
  return Math.max(0, Math.min(120000, ms || 0));
}

function shouldFallback(requestedProvider, status, message = '') {
  if (String(requestedProvider || 'auto').toLowerCase() !== 'auto') return false;
  const code = Number(status) || 0;
  // These errors are provider-specific and another configured provider may succeed.
  if ([401, 402, 403].includes(code)) return true;
  if ([400, 422].includes(code)) return false;
  if (code === 404 && /model|not found|unsupported/i.test(String(message))) return true;
  return [0, 408, 425, 429, 500, 502, 503, 504].includes(code);
}

module.exports = { ProviderCircuitBreaker, shouldFallback, parseRetryAfterMs };
