'use strict';

/** Extracts text returned in the OpenAI-compatible chat-completion shape. */
function openAIContent(data) {
  const content = data?.choices?.[0]?.message?.content;
  if (typeof content === 'string') return content.trim();
  if (Array.isArray(content)) {
    return content.map(part => typeof part === 'string' ? part : String(part?.text || '')).join('').trim();
  }
  return '';
}

/** Empty output is a provider failure, not a successful assistant answer. */
function hasAssistantContent(data) {
  return openAIContent(data).length > 0;
}

function emptyAssistantResponseMessage(providerName, data = {}) {
  const finishReason = String(data?.choices?.[0]?.finish_reason || '').trim();
  const reason = finishReason ? ` (finish_reason=${finishReason.slice(0, 50)})` : '';
  return `${String(providerName || 'Nhà cung cấp')} trả phản hồi nhưng không có nội dung văn bản${reason}. VILA không coi phản hồi rỗng là câu trả lời thành công.`;
}

/** Detects visible assistant text from one OpenAI-compatible SSE data line. */
function sseLineHasAssistantText(line) {
  const raw = String(line || '').trim();
  if (!raw.startsWith('data:')) return false;
  const payload = raw.slice(5).trim();
  if (!payload || payload === '[DONE]') return false;
  let parsed;
  try { parsed = JSON.parse(payload); } catch (_) { return false; }
  for (const choice of (Array.isArray(parsed?.choices) ? parsed.choices : [])) {
    const value = choice?.delta?.content ?? choice?.message?.content ?? '';
    if (typeof value === 'string' && value.trim()) return true;
    if (Array.isArray(value) && value.some(part => String(typeof part === 'string' ? part : part?.text || '').trim())) return true;
  }
  return false;
}

module.exports = { openAIContent, hasAssistantContent, emptyAssistantResponseMessage, sseLineHasAssistantText };
