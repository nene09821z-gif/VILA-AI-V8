'use strict';

const MAX_EXPRESSION_LENGTH = 160;
const TOOL_DEFINITIONS = [
  { type: 'function', function: { name: 'vila_calculate', description: 'Calculate a numeric arithmetic expression. Supports + - * / parentheses and decimal numbers.', parameters: { type: 'object', properties: { expression: { type: 'string', description: 'Arithmetic expression, e.g. (12+8)*3' } }, required: ['expression'], additionalProperties: false } } },
  { type: 'function', function: { name: 'vila_get_current_time', description: 'Get the current date and time in an IANA timezone such as Asia/Ho_Chi_Minh.', parameters: { type: 'object', properties: { timezone: { type: 'string', description: 'IANA timezone; defaults to Asia/Ho_Chi_Minh' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'vila_analyze_text', description: 'Count words, characters, and lines in supplied text.', parameters: { type: 'object', properties: { text: { type: 'string', description: 'Text to analyze', maxLength: 20000 } }, required: ['text'], additionalProperties: false } } }
];

function tokenizeExpression(input) {
  const source = String(input || '').trim();
  if (!source || source.length > MAX_EXPRESSION_LENGTH || !/^[0-9+\-*/().\s]+$/.test(source)) throw new Error('Biểu thức không hợp lệ.');
  const tokens = source.match(/\d+(?:\.\d+)?|[()+\-*/]/g) || [];
  if (tokens.join('').replace(/\s/g, '') !== source.replace(/\s/g, '')) throw new Error('Biểu thức chứa ký tự không hỗ trợ.');
  return tokens;
}
function calculate(expression) {
  const tokens = tokenizeExpression(expression); let i = 0;
  function primary() {
    const t = tokens[i++];
    if (t === '+') return primary();
    if (t === '-') return -primary();
    if (t === '(') { const v = sum(); if (tokens[i++] !== ')') throw new Error('Thiếu dấu đóng ngoặc.'); return v; }
    if (!t || !/^\d+(?:\.\d+)?$/.test(t)) throw new Error('Thiếu số trong biểu thức.');
    return Number(t);
  }
  function product() { let v = primary(); while (tokens[i] === '*' || tokens[i] === '/') { const op=tokens[i++], rhs=primary(); if(op==='/' && rhs===0) throw new Error('Không thể chia cho 0.'); v=op==='*'?v*rhs:v/rhs; } return v; }
  function sum() { let v=product(); while(tokens[i]==='+'||tokens[i]==='-'){const op=tokens[i++],rhs=product();v=op==='+'?v+rhs:v-rhs;}return v; }
  const value=sum(); if(i!==tokens.length || !Number.isFinite(value)) throw new Error('Biểu thức không hợp lệ hoặc kết quả vượt giới hạn.');
  return { result: value };
}
function executeTool(name, args = {}) {
  if (name === 'vila_calculate') return calculate(args.expression);
  if (name === 'vila_get_current_time') {
    const timezone = String(args.timezone || 'Asia/Ho_Chi_Minh');
    let formatted;
    try { formatted = new Intl.DateTimeFormat('vi-VN', { dateStyle: 'full', timeStyle: 'long', timeZone: timezone }).format(new Date()); }
    catch { throw new Error('Múi giờ không hợp lệ.'); }
    return { timezone, iso: new Date().toISOString(), local: formatted };
  }
  if (name === 'vila_analyze_text') {
    const text = String(args.text || ''); if (text.length > 20000) throw new Error('Văn bản vượt giới hạn 20.000 ký tự.');
    return { characters: [...text].length, words: (text.trim().match(/\S+/g) || []).length, lines: text ? text.split(/\r?\n/).length : 0 };
  }
  throw new Error('Công cụ không nằm trong danh sách cho phép.');
}
function safeExecuteTool(name, args) {
  try { return { ok: true, result: executeTool(name, args) }; }
  catch (error) { return { ok: false, error: String(error?.message || error).slice(0, 240) }; }
}
module.exports = { TOOL_DEFINITIONS, executeTool, safeExecuteTool, calculate };
