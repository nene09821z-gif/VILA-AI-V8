'use strict';
// Bounded multi-step tool loop (OpenAI-compatible function calling). Dependencies are injected so it is unit-testable.
// Deterministic context compaction: when the transcript grows past the budget, older tool outputs
// (never the latest round) are shortened so long research sessions do not overflow the model context.
function compactMessages(messages, budgetChars, keepLast = 2) {
  const size = () => messages.reduce((n, m) => n + String(typeof m.content === 'string' ? m.content : JSON.stringify(m.content || '')).length, 0);
  if (size() <= budgetChars) return 0;
  const toolIdx = messages.map((m, i) => (m.role === 'tool' ? i : -1)).filter(i => i >= 0);
  let shrunk = 0;
  for (const i of toolIdx.slice(0, Math.max(0, toolIdx.length - keepLast))) {
    const c = String(messages[i].content);
    if (c.length > 600) { messages[i] = { ...messages[i], content: c.slice(0, 500) + `…[đã rút gọn ${c.length - 500} ký tự để tiết kiệm ngữ cảnh]` }; shrunk++; }
    if (size() <= budgetChars) break;
  }
  return shrunk;
}

function createAgentLoop({ upstreamFor, releaseResponse, toOpenAIShape, runAgentTool, maxCalls }) {
  return async function resolveAgentToolCalls(provider, model, initialData, originalBody, ctx = {}) {
    let data = initialData;
    const messages = [...originalBody.messages];
    let toolCalls = 0;
    const trace = [];
    const max = maxCalls();
    // Hard ceiling on provider round-trips so a model that keeps emitting tool_calls cannot loop forever.
    for (let round = 0; round < max + 2; round++) {
      const message = data?.choices?.[0]?.message;
      const calls = Array.isArray(message?.tool_calls) ? message.tool_calls : [];
      if (!calls.length) return { data, toolCalls, trace };
      messages.push({ role: 'assistant', content: message.content || null, tool_calls: calls });
      for (const call of calls) {
        const name = String(call?.function?.name || '');
        let args = null;
        try { args = JSON.parse(String(call?.function?.arguments || '{}')); } catch { args = null; }
        let content;
        if (toolCalls >= max) content = JSON.stringify({ ok: false, error: 'Đã đạt giới hạn số lần gọi công cụ cho lượt này.' });
        else if (args && typeof args === 'object' && !Array.isArray(args)) {
          const ran = await runAgentTool(name, args, { uid: ctx.uid, env: process.env });
          content = ran.json; trace.push(ran.trace); toolCalls++;
        } else { content = JSON.stringify({ ok: false, error: 'Tham số công cụ không phải JSON object hợp lệ.' }); }
        messages.push({ role: 'tool', tool_call_id: String(call.id || `vila-tool-${toolCalls}`), name, content });
      }
      compactMessages(messages, Number(process.env.VILA_AGENT_CONTEXT_CHARS || 120000));
      const exhausted = toolCalls >= max;
      if (exhausted) messages.push({ role: 'user', content: 'Đã đạt giới hạn công cụ của lượt này. Hãy trả lời dựa trên kết quả công cụ đã có và nêu rõ nếu còn thiếu dữ liệu.' });
      const nextBody = { ...originalBody, messages, stream: false, agentMode: true, _vilaForceFinal: exhausted };
      const response = await upstreamFor(provider, model, nextBody, false);
      if (!response.ok) {
        const raw = await response.text().catch(() => '');
        releaseResponse(response);
        throw new Error(`Agent tool follow-up HTTP ${response.status}: ${raw.slice(0, 180)}`);
      }
      const raw = await response.text(); releaseResponse(response);
      try { data = JSON.parse(raw); } catch { throw new Error('Agent tool follow-up trả JSON không hợp lệ.'); }
      if (provider.type === 'gemini') data = toOpenAIShape(data, model);
      if (exhausted) return { data, toolCalls, trace };
    }
    return { data, toolCalls, trace };
  };
}
module.exports = { createAgentLoop, compactMessages };
