# VILA AI V53.6.0 — expanded provider pool

- Added optional OpenAI-compatible server adapters for OpenAI, DeepSeek, Mistral AI, Together AI, and Fireworks AI. Existing Gemini, OpenRouter, Groq, Cerebras, and Custom API paths remain.
- Expanded task-aware provider ranking for coding and reasoning model names.
- Increased the bounded automatic provider-attempt ceiling from 5 to 10 (default 8) so failover can reach more configured providers; no retry loop is unbounded.
- Added environment examples and deployment guidance. Provider keys remain server-side secrets; each provider requires a valid account/key and a model ID available to that account.
- Bumped Android versionName to 53.6.0 and versionCode to 65; synchronized Gateway version and update checker.

## Verification

- `npm test` in `server/`: 34/34 passed.
- Android Gradle build and live calls to external providers were not run in this environment. This source ZIP does not deploy cloud servers or supply API keys.
