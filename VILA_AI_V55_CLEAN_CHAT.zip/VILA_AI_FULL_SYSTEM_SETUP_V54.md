# VILA AI V54 — Full-system setup and release checklist

This guide describes what the source contains, what must be configured by the project owner, and how to validate it. It does not claim a live provider, Firebase login, or Android build works until those checks are actually run.

## 1. System layout

- **Android client:** `app/` — WebView interface, native Firebase Authentication integration, encrypted local key storage, optional accessibility handoff service, and local model/gateway settings.
- **AI Gateway:** `server/src/server.js` — authenticated API gateway, provider selection/fallback, request limits, model discovery, and chat endpoint.
- **Agent loop:** `server/src/agent-loop.js` — bounded function-call loop with a call ceiling and transcript compaction.
- **Tools:** `server/src/tools/` — arithmetic, date/time, text analysis, opt-in code execution, web search/fetch, per-user memory, and document search.
- **Optional agent proxy:** `server/agent-server.mjs` — separate optional service; do not expose arbitrary project-build execution to the public Internet.
- **CI:** `.github/workflows/main.yml` — JavaScript regression checks and Android build/signing/artifact steps on GitHub-hosted runners.

The app does not contain or train a frontier-scale model. It calls a configured model/provider, or a compatible local model server that the user starts separately. More tool calls and more specialist stages may improve task handling but increase latency and provider charges; they do not guarantee correctness.

## 2. Run backend checks locally

Requirements: Node.js 20 or newer.

```sh
cd server
npm install
npm test
```

The server's unit tests do not require live provider API keys. They cannot prove provider quota, account access, Firebase production configuration, or real network availability.

For a local development-only gateway:

```sh
cd server
npm run dev
```

Development mode disables auth for local testing. **Do not deploy `AUTH_MODE=off` to a public server.**

## 3. Configure provider credentials safely

1. Copy `.env.production.example` to a private `.env` on a trusted server or use your hosting provider's secret manager.
2. Set `NODE_ENV=production`, `AUTH_MODE=firebase`, a real `FIREBASE_PROJECT_ID`, and Firebase Admin credentials. Use a workload identity where supported; otherwise store the service-account JSON in the host's secret manager and pass it as `FIREBASE_SERVICE_ACCOUNT_JSON`.
3. Add only the provider keys you personally own and intend to use, such as `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `DEEPSEEK_API_KEY`, `OPENAI_API_KEY`, `GROQ_API_KEY`, or others listed in the example environment file.
4. Set provider-specific model IDs when required by the chosen adapter. A key alone does not guarantee model access, free quota, or availability.
5. Set `CORS_ORIGINS` to exact browser origins if a browser client needs CORS. Do not use `*` in production.
6. Keep `.env`, provider API keys, Firebase service-account credentials, and release signing passwords out of source control, APK assets, screenshots, and chat messages.

A client-side Firebase config is not a substitute for Firebase Admin credentials on the server. Firebase Authentication must be enabled for the sign-in methods the app offers. Google sign-in requires the correct Android package, OAuth Web client ID, and signing certificate fingerprint in Firebase.

## 4. Deploy the Gateway

The root `compose.yaml` is a starting point for a single-host deployment. Review it and the server Dockerfile before use. The default service binding is loopback-oriented; place an HTTPS reverse proxy in front if remote devices need access. Do not expose a raw development port directly to the Internet.

After deployment, check:

- `GET /health/live` for process liveness.
- `GET /health/ready` for configured readiness (not proof every provider is live).
- Authenticated `GET /v1/gateway/status` and `GET /v1/models`.
- A small authenticated chat request with a configured provider.

Before public use, configure HTTPS, access control, quotas, monitoring, cost alerts, backups, and a rollback path. Rate-limit/circuit state and memory/document storage are not a durable multi-replica database; use shared persistent infrastructure before scaling or charging users.

## 5. Keystore: test key versus release key

- The project contains `keystore/vila-debug.keystore` for **testing/debug identity only**. It is not a production signing key and should not be treated as secret release signing material.
- For a release APK, create your own private release keystore and keep a secure offline backup. Losing it can prevent updates to an app signed with that key.
- In GitHub repository **Settings → Secrets and variables → Actions**, configure these secrets if you want a signed release APK:
  - `ANDROID_KEYSTORE_BASE64` — Base64 text of your release `.jks` file.
  - `ANDROID_KEYSTORE_PASSWORD` — keystore password.
  - `ANDROID_KEY_ALIAS` — alias inside the keystore.
  - `ANDROID_KEY_PASSWORD` — key password.
- If these are not configured, the workflow is intended to produce an installable debug APK and an **unsigned release APK**. Do not distribute an unsigned release APK as a production release.
- The workflow prints certificate fingerprints in its build artifacts. Register the fingerprint matching the exact APK variant you install in Firebase. Debug and release certificates are different.

Never upload a real release keystore or passwords to a public repository. The included debug keystore is reused for stable debug Google sign-in testing, not for app-store publishing.

## 6. Build APKs with GitHub Actions

1. Upload/extract this source project at the repository root so `app/build.gradle`, `server/`, and `.github/workflows/main.yml` are at the expected paths.
2. Commit and push to `main` or `master`, or open **Actions → VILA AI - Android Build and Verify → Run workflow**.
3. Wait for the workflow to finish. If it fails, open the failed step and inspect `output/gradle-build.log` or the test output.
4. Download the workflow artifact named `VILA-AI-Build-Files-<run number>` from that run. The workflow should contain APKs, source archive, checksums, and signing diagnostics when the build reaches packaging.
5. Install the debug APK first and test on the target phone. Confirm sign-in, API configuration, chat, tool calling, document/memory features, permissions, and app lifecycle before relying on it.

The workflow is the authoritative Android build check. Local Node tests are not a substitute for a successful Gradle build and on-device testing.

## 7. Agent tools and safe defaults

- Code execution is **off by default**. Enable it only for a trusted, isolated server environment. The code sandbox is defense-in-depth, not a complete security boundary; use a dedicated container/worker with CPU, memory, filesystem, and network restrictions.
- Web fetch output is untrusted input. The model must not treat web pages as instructions or as verified facts solely because they were fetched.
- Memory and uploaded documents are per-user in the current store. Review retention/deletion behavior and storage persistence before production; back up only with appropriate access controls.
- Tool calls are bounded per request and quota-limited. Increase limits only after measuring latency, cost, and abuse risk.
- Optional Android accessibility automation must be user-enabled in Android settings and can be brittle as third-party app interfaces change. The normal API path and user-initiated share/handoff should remain available.

## 8. Verification status

Run `npm test` in `server/` and the `node scripts/test-*.js` regression scripts. The repository workflow also performs Gradle build/lint tasks on GitHub's runner. Do not describe the app as production-ready until a successful workflow run, a real-device test, Firebase sign-in checks, live provider calls, security/privacy review, and release-signature validation are complete.
