# VILA AI V53.6.0 — provider pool and regression report

## Implemented

- Added server-side OpenAI-compatible adapters for OpenAI, DeepSeek, Mistral AI, Together AI, and Fireworks AI. Existing Gemini, OpenRouter, Groq, Cerebras, and Custom API adapters remain.
- Updated adaptive provider ranking for coding/reasoning model families.
- Raised automatic fallback ceiling to 8 attempts by default, bounded at 10; retries remain bounded.
- Added provider environment examples and deployment notes.
- Synchronized Android/Gateway version to `53.6.0`, Android `versionCode 65`, and update-check metadata.
- Added regression tests for provider registry, provider ordering, and exclusion of unconfigured providers.

## Verified in this environment

- Backend unit tests: 36/36 passed.
- Existing source regression scripts: 16/16 passed.
- JavaScript syntax checks passed across the project; Android Gradle build was not run because this environment does not have the Android SDK/Gradle toolchain available.
- No live external provider calls were made. API key validity, model access, quotas, billing, Firebase sign-in, and actual APK installation remain unverified.

## Important limits

This ZIP adds adapters and routing code only. It does not create or rent cloud servers, provide API accounts/keys, or guarantee that a provider offers free usage. Each added provider requires its own valid key and an accessible model ID configured on the backend. Keep keys in deployment secrets, never in the APK or repository. More providers improve fallback options but do not guarantee every answer is correct or always available.
