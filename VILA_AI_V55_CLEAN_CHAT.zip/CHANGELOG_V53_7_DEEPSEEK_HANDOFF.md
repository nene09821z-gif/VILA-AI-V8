# VILA AI V53.7.0 — DeepSeek API + external app handoff

- Kept the server-side DeepSeek API provider configuration; keys remain in backend environment variables, not in the APK.
- Added an explicit DeepSeek share button to the chat composer. On Android it invokes the native Sharesheet with the current prompt; the user chooses DeepSeek if installed/available.
- Added an external official DeepSeek chat URL opener as a native bridge method for future UI use. Android may open the installed app if app-link handling is registered; otherwise it opens a browser.
- Added a browser fallback using Web Share API when available.
- Updated Android and gateway version strings to 53.7.0; preserved versionCode 65 to avoid unexpectedly changing the existing release numbering.
- Added regression tests for the native handoff, API config and version synchronization.

## Limitations

- VILA cannot access DeepSeek app private login state, history, or responses. Sharing happens only after the user taps the button.
- Sharing behavior depends on Android Sharesheet and the installed DeepSeek app's share-target support. If DeepSeek is not listed, the user can choose another app or open DeepSeek web.
- DeepSeek API calls are not live-verified here; a valid server-side API key, supported model ID, deployed backend, and Firebase/auth configuration are required.
- Android APK build has not been run in this environment; this change has source-level tests only.
