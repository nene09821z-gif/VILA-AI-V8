'use strict';
// V53.4 audit regression checks (source-level; no network or Android SDK needed).
const fs = require('fs');
const assert = require('assert');
const { spawnSync } = require('child_process');
const read = p => fs.readFileSync(p, 'utf8');

// 1. agent-server must not shell out to bash with a JS-template-escaped "\(" (it becomes "(" and bash fails).
const agent = read('server/agent-server.mjs');
assert(!/bash'?,\s*\['-lc'/.test(agent), 'agent-server should not use bash -lc for find');
assert(/run\('find',\['\.','-maxdepth','5'/.test(agent), 'findAndroidRoot should call find directly');
const tmp = fs.mkdtempSync(require('os').tmpdir() + '/vila-find-');
fs.mkdirSync(tmp + '/proj/app', { recursive: true });
fs.writeFileSync(tmp + '/proj/settings.gradle', '');
const r = spawnSync('find', ['.', '-maxdepth', '5', '-type', 'f', '(', '-name', 'settings.gradle', '-o', '-name', 'settings.gradle.kts', ')', '-print', '-quit'], { cwd: tmp });
assert.strictEqual(r.status, 0); assert(r.stdout.toString().includes('proj/settings.gradle'));
assert(/e\.status=400/.test(agent), 'invalid JSON should yield HTTP 400');

// 2. Android: only ordinary schemes may leave the WebView; loopback proxy must not allocate attacker-sized bodies.
const java = read('app/src/main/java/com/vila/ai/MainActivity.java');
assert(/safeExternal = sc\.equals\("http"\) \|\| sc\.equals\("https"\) \|\| sc\.equals\("mailto"\) \|\| sc\.equals\("tel"\)/.test(java));
assert(!/byte\[\] body=new byte\[len\]/.test(java), 'proxy must not allocate len bytes per connection');
assert(/len>1024\*1024/.test(java));

assert(/static String safeFileName\(/.test(java) && (java.match(/safeFileName\(/g) || []).length >= 4, 'all three save/download paths must use safeFileName');

// 3. Front-end escapeHtml must escape quotes (used inside attributes).
const html = read('app/src/main/assets/index.html');
const fn = html.match(/function escapeHtml\(str\) \{[\s\S]*?\n        \}/)[0];
const escapeHtml = new Function(fn + ';return escapeHtml')();
assert.strictEqual(escapeHtml('a"b\'c<d>&'), 'a&quot;b&#39;c&lt;d&gt;&amp;');
assert.strictEqual(escapeHtml(null), '');

// 4. Gateway: streaming timeout must not cover the stream body; idle watchdog + client-disconnect abort exist.
const server = read('server/src/server.js');
assert(/streaming && response\.ok\) clearTimeout\(timer\)/.test(server));
assert(/readWithIdle\(reader\)/.test(server));
assert(/__vilaAbort/.test(server));

// 5. Local-model discovery: `localProtocol` was declared inside an else-block but read outside it (ReferenceError).
{
  const h = html;
  const i = h.indexOf('function apiModelListUrl');
  const j = h.indexOf('async function listProviderModels');
  const m = /\n        (?:async )?function \w+/.exec(h.slice(j + 40));
  const code = h.slice(i, j + 40 + m.index);
  const run = new Function('PROVIDERS', 'fetch', 'Response', code + ';return listProviderModels;');
  const PROVIDERS = { local: { name: 'Local' } };
  const fakeFetch = async u => String(u).endsWith('/api/tags') ? new Response(JSON.stringify({ models: [{ name: 'llama3' }] }), { status: 200 }) : new Response('{}', { status: 404 });
  run(PROVIDERS, fakeFetch, Response)('local', '', 'http://127.0.0.1:11434/v1').then(rows => {
    assert.strictEqual(rows[0].id, 'llama3');
    assert.strictEqual(rows[0].localProtocol, 'ollama');
    console.log('V53.4 local discovery runtime test passed');
  }).catch(e => { console.error(e); process.exit(1); });
}
console.log('V53.4 audit regression tests passed');
