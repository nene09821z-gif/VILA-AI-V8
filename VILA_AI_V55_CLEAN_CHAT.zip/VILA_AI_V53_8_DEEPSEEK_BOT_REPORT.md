# VILA AI V53.8.0 — DeepSeek App Bot (experimental)

## Implemented in source
- Adds an explicit `Bot DS` button beside the existing manual DeepSeek share button.
- Adds an opt-in Android `AccessibilityService` with user-visible description and settings flow.
- Attempts to launch the installed DeepSeek app (`com.deepseek.chat`, with a legacy fallback package), fill the prompt, press a visible send control/IME action, watch visible accessibility text for a stable response, and return the result to VILA.
- Adds a 90-second timeout and surfaces failure instead of pretending a response was received.
- Preserves the original DeepSeek Sharesheet action, server-side DeepSeek API integration, provider routing, and fallback behavior.
- Adds Android package visibility declarations for supported DeepSeek package names.

## Checks actually run
- Backend test suite: **40/40 passed** (`npm test`).
- AndroidManifest.xml and accessibility service XML: parsed successfully.
- Embedded JavaScript: **9 script blocks** passed Node syntax compilation.
- ZIP integrity checked after packaging.

## Not verified
- Android/Gradle build could not run: neither `./gradlew` nor system `gradle` exists in this environment.
- No physical Oppo A17k or emulator was available to test the DeepSeek app's actual package name, input/send controls, accessibility tree, login/captcha, or answer capture.
- Therefore the app-bridge automation is a **prototype**, not a guaranteed working integration. DeepSeek may render its interface in a way that hides text from AccessibilityService, and app updates can change UI labels. If that happens, use the existing official DeepSeek API mode or manual share/copy fallback.

## First-run steps
1. Build and install the debug APK from GitHub Actions.
2. Open VILA and tap `Bot DS` with a test prompt.
3. In Android Accessibility settings, enable `VILA DeepSeek Bridge` only if you consent to the described UI automation. Return to VILA and tap `Bot DS` again.
4. Check whether DeepSeek opens, the prompt is sent, and the answer returns to VILA. If it times out, disable the accessibility service and use API/manual sharing.

The service does not access DeepSeek's private app database, session tokens, or hidden APIs. It can only attempt interaction with visible accessibility nodes after the user explicitly taps the bot button.
