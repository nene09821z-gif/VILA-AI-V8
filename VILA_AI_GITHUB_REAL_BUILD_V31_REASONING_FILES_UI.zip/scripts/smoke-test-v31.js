'use strict';

// Fast offline regression checks for VILA V31 routing, reasoning, workspace and UX behavior.
// These checks validate source wiring only; they do not call provider APIs.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const extras = fs.readFileSync(path.join(root, 'app/src/main/assets/vila-extras.js'), 'utf8');

function requireText(text, description) {
  assert.ok(html.includes(text), `Missing ${description}: ${text}`);
}

const providersStart = html.indexOf('const PROVIDERS = {');
const providersEnd = html.indexOf('const VILA_MODEL_CATALOG_KEY', providersStart);
assert.ok(providersStart >= 0 && providersEnd > providersStart, 'Provider seed catalog must exist');
const seeds = html.slice(providersStart, providersEnd);

// Verified free-tier seeds as of 2026-10-09; live /models sync still takes precedence.
for (const model of [
  'openrouter/free',
  'nvidia/nemotron-3-ultra-550b-a55b:free',
  'nvidia/nemotron-3.5-lightning:free',
  'poolside/laguna-s-2.1:free',
  'poolside/laguna-xs-2.1:free',
  'gemini-3.7-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'qwen/qwen3.8-27b',
  'zai-glm-4.7'
]) assert.ok(seeds.includes(model), `Model missing from offline seed catalog: ${model}`);
const gemini35 = seeds.match(/\{id:'gemini-3\.5-flash'([^}]*)\}/);
assert.ok(gemini35 && gemini35[1].includes('isFree:true'), 'Gemini 3.5 Flash must reflect the current free tier');
const gemini38 = seeds.match(/\{id:'gemini-3\.8-flash'([^}]*)\}/);
assert.ok(gemini38 && gemini38[1].includes('isFree:true'), 'Gemini 3.8 Flash must reflect the current free tier');
for (const model of ['gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-2.5-flash','gemini-2.5-flash-lite']) {
  const start = seeds.indexOf("{id:'" + model + "'");
  const end = start < 0 ? -1 : seeds.indexOf('}', start);
  const row = start >= 0 && end >= 0 ? seeds.slice(start, end + 1) : '';
  assert.ok(row && row.includes('isFree:true'), `Verified free model must be labeled as such: ${model}`);
}

for (const stale of ['groq/compound', 'groq/compound-mini', 'llama-3.1-8b-instant', 'llama-3.3-70b-versatile', 'qwen/qwen3.6-27b']) {
  assert.ok(!seeds.includes(stale), `Retired Groq model must not be seeded: ${stale}`);
}

// Provider/model isolation and adaptive model preference.
requireText("localStorage.getItem(modelStorageKey(activeProvider))", 'provider-scoped model persistence');
requireText('function getSmartModelOrderForProvider(provider,userText)', 'provider-specific auto-model ranking');
requireText('function classifyTaskForModel(userText)', 'adaptive task classification');
requireText('CHẾ ĐỘ SUY LUẬN NHIỀU BƯỚC', 'multi-step reasoning instructions');
requireText('CHẾ ĐỘ NGHIÊN CỨU/TÌM KIẾM', 'research-first instructions');
requireText('zai-glm-4\\.7', 'GLM 4.7 adaptive reasoning effort');
requireText('function isFreePreferenceEnabled()', 'free model preference');
requireText("localStorage.getItem('vila_prefer_free_models')!=='0'", 'default-on free model preference');
requireText("result=activeProvider==='gemini'?await requestGeminiWithFallback(requestMessages):await requestActiveProvider(requestMessages)", 'normal chat dispatch to currently selected provider');
requireText('result.autoRouted=true', 'auto-model routing feedback');

// Search adapters: native Gemini grounding, OpenRouter server tool, Groq Browser Search,
// and a documented cross-provider bridge for providers without a universal search tool.
requireText("type:'openrouter:web_search'", 'OpenRouter server-side web search tool');
requireText("body.tools=[{type:'browser_search'}]", 'Groq Browser Search tool');
requireText('body.reasoning_effort=body.reasoning_effort||\'low\'', 'Groq search preserves adaptive reasoning effort');
requireText('async function requestGeminiWebSearch(messages,options={})', 'Gemini Google Search grounding adapter');
requireText('async function requestWithWebSearch(messages)', 'async common search router syntax');
requireText('async function requestSearchBridgeForOtherProvider', 'cross-provider search bridge');
requireText('researchOnly:true', 'research-only Gemini search bridge');
requireText("const freeSearchModels=['gemini-2.5-flash','gemini-2.5-flash-lite']", 'free Gemini grounding models');
requireText("const models=(isFreePreferenceEnabled()\n                ? freeSearchModels", 'free preference prevents paid Gemini grounding fallback');
requireText('async function requestWithWebSearch(messages)', 'common web-search router');
requireText("provider==='openrouter'", 'OpenRouter search route');
requireText("provider==='groq'", 'Groq search route');
requireText("provider==='gemini'", 'Gemini search route');
requireText("localStorage.getItem('vila_web_search_mode')==='1'", 'explicit search mode separate from auto-search preference');
requireText('function shouldAutoSearch(text)', 'automatic search heuristics for fresh/current questions');
requireText('isFree:/^gemini-', 'Gemini free-tier model metadata');
requireText("const promptPrice=m?.pricing?.prompt,completionPrice=m?.pricing?.completion", 'OpenRouter live pricing-based free model detection');

// API compatibility fixes: remove unsupported reasoning parameters then retry; use the
// completion-token field expected by Groq GPT-OSS and Cerebras APIs.
requireText('if(Object.keys(reasoningParams).length&&response.status===400&&/reasoning|unsupported|unrecognized|unknown parameter|extra field/i.test(apiMessage))', 'reasoning-parameter compatibility retry for tool and normal calls');
requireText("if(provider==='cerebras'||(provider==='groq'&&/^openai\\/gpt-oss-/i.test(String(model||''))))", 'Cerebras/Groq completion-token API compatibility');

assert.ok(workflow.includes('node scripts/smoke-test-v31.js'), 'GitHub Actions must run the V31 offline regression checks');

// V31 reasoning, file safety, stop action, direct image output, and UX checks.
for (const [needle, description] of [
  ['function verifyAnswerDraft(messages,draft,useWebSearch)', 'second-pass answer verification'],
  ['function createVilaChatAbortController()', 'cancellable chat requests'],
  ['function stopVilaGeneration()', 'stop button behavior'],

  ['function isImageGenerationIntent(userText)', 'direct image-generation routing'],
  ['appendGeneratedImage(generated,rawPrompt)', 'generated image inline output'],
  ['id="vilaWelcomeSplash"', 'animated 3-second welcome splash'],
  ['XIN CHÀO CÁC BẠN', 'requested welcome text'],
  ['Bảng xếp hạng VILA', 'activity ranking modal'],
  ['function isVilaFullWorkspaceMode()', 'full workspace scope option'],
  ['SCOPE MODE:', 'workspace scope reporting'],
  ['AI Workspace</small>', 'creator attribution removed from sidebar']
]) requireText(needle, description);
assert.ok(!html.includes('Cha đẻ dự án là Bảo An'), 'Creator prompt attribution must be removed');
assert.ok(!html.includes('>Bảo An</div>'), 'Creator identity card must be removed');
assert.ok(extras.includes('window.createVilaChatAbortController'), 'Video requests must use the chat cancellation controller');
assert.ok(extras.includes('waitOrAbort(10000)'), 'Video polling delay must be abortable');

// Execute pure helper functions against representative runtime cases, not just source-string checks.
function evalRange(startNeedle, endNeedle, exportNames) {
  const start = html.indexOf(startNeedle);
  const end = html.indexOf(endNeedle, start + startNeedle.length);
  assert.ok(start >= 0 && end > start, `Cannot isolate runtime helper range: ${startNeedle}`);
  const context = {};
  vm.runInNewContext(html.slice(start, end) + '\n' + exportNames.map(name => `this.${name}=${name};`).join('\n'), context);
  return context;
}
const imageHelpers = evalRange('function isImageGenerationIntent(userText)', 'function classifyTaskForModel(userText)', ['isImageGenerationIntent']);
for (const prompt of ['tạo ảnh một con mèo', 'vẽ con mèo', 'hãy vẽ một con rồng', 'giúp tôi vẽ phong cảnh']) {
  assert.equal(imageHelpers.isImageGenerationIntent(prompt), true, `Image intent should route directly: ${prompt}`);
}
for (const prompt of ['phân tích ảnh này', 'đọc chữ trong ảnh', 'vẽ sơ đồ kiến trúc', 'giải thích bức hình']) {
  assert.equal(imageHelpers.isImageGenerationIntent(prompt), false, `Non-generation request must stay in chat: ${prompt}`);
}
const freeHelpers = evalRange('function isKnownFreeModel(provider,model,metadata={})', 'function getSmartModelOrder(userText)', ['isKnownFreeModel']);
for (const model of ['gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-2.5-flash','gemini-2.5-flash-lite']) {
  assert.equal(freeHelpers.isKnownFreeModel('gemini', model, {}), true, `Cached Gemini model should retain verified free-tier classification: ${model}`);
}
assert.equal(freeHelpers.isKnownFreeModel('gemini', 'gemini-3.1-pro-preview', {}), false, 'Paid/preview Gemini model must not be inferred free');
assert.equal(freeHelpers.isKnownFreeModel('openrouter', 'poolside/laguna-s-2.1:free', {}), true, 'OpenRouter :free models should be recognized');
const taskHelpers = evalRange('function classifyTaskForModel(userText)', 'function getAdaptiveTaskInstruction(userText)', ['classifyTaskForModel']);
assert.equal(taskHelpers.classifyTaskForModel('Hãy suy luận nhiều bước và kiểm tra giả định'), 'reasoning');
assert.equal(taskHelpers.classifyTaskForModel('Tìm kiếm nguồn chính thức mới nhất'), 'research');
assert.equal(taskHelpers.classifyTaskForModel('Sửa code JavaScript và build APK'), 'coding');
const fileHelpers = evalRange('function isLikelyTextFile(name)', 'function cleanProjectText(text)', ['isLikelyTextFile','normalizeProjectPath']);
for (const file of ['app/src/main/java/MainActivity.java','infra/main.tf','config/.env.production','src/component.tsx','Dockerfile']) {
  assert.equal(fileHelpers.isLikelyTextFile(file), true, `Source/config file should be readable as text: ${file}`);
}
assert.equal(fileHelpers.isLikelyTextFile('assets/icon.png'), false, 'Binary image files must not be decoded as text');
assert.equal(fileHelpers.normalizeProjectPath('../secrets.txt'), '', 'Path traversal must be rejected');
assert.equal(fileHelpers.normalizeProjectPath('/absolute/path.js'), '', 'Absolute project paths must be rejected');
assert.equal(fileHelpers.normalizeProjectPath('src\\main.js'), 'src/main.js', 'Windows separators should normalize to safe relative paths');

console.log('PASS: provider routing/search, adaptive model selection, multi-step reasoning review, stop/cancel, file-scope safety, direct image flow, welcome splash, local activity ranking, and workflow integration.');
console.log('NOTE: this is an offline source regression test; it does not prove live API access, free quota, or successful APK build.');
