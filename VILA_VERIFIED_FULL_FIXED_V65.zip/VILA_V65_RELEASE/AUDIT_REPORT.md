# VILA AI Studio 65.0.0 — Audit report

**Date:** 2026-10-15  
**Scope:** static source checks, regression suite, Android/Firebase configuration consistency. This report distinguishes local checks from builds or live services that were not run.

## Fixes applied

1. **Release version alignment:** synchronized the Android app, root/Gateway package metadata, Gateway runtime, container tag, and sample latest-version setting to `65.0.0`.
2. **Update-check bug:** replaced the version comparison that could produce `NaN` when a server version contained an edition suffix. Numeric version components are now compared explicitly, and regression tests cover equal, newer, older, and suffix-bearing versions.
3. **CSS isolation:** scoped image/video and broken-image styling to the simple UI and its knowledge dialog rather than applying those rules globally.
4. **Missing local icons:** added SVG paths for the `cube` and `waveform` icons used by the app, so they do not depend on an unavailable icon-font glyph.
5. **Model picker:** trimmed leading/trailing search whitespace, aligned the initial count with the documented 60-item page size, and kept large catalogs virtualized.
6. **Regression/CI checks:** aligned historical source checks with the central `scripts/run-all.js` runner, removed stale release-version assertions, and corrected generic capability checks so they do not retain a removed provider-specific name.

## Checks that passed locally

- `node scripts/run-all.js`: **29/29 groups passed**, including the Gateway unit-test group and source regression scripts.
- Inline JavaScript in `index.html`: **16 blocks parsed, 0 syntax errors**.
- `node --check` for `server/src/*.js`, `server/*.mjs`, and `scripts/*.js`: passed.
- Android manifest and resource XML: **5 files parsed successfully**.
- Firebase configuration JSON and Android/Web app identifiers: passed consistency checks.
- Bundled debug certificate SHA-1 against the Android OAuth client in `google-services.json`: matched.
- Release metadata synchronization across package files, Gradle config, Gateway runtime, Docker Compose, environment sample, and update checker: passed.
- Original ZIP integrity was valid; the updated ZIP is checked again after packaging.

## Not verified — do not treat these as completed

- **No APK was built in this workspace.** There is no installed Gradle executable, Android SDK/ADB, or complete Gradle Wrapper (the archive has only `gradle-wrapper.properties`). The repository's GitHub Actions workflow includes an actual Gradle build path, but it has not been executed from this environment.
- `npm install` for the Gateway dependencies timed out here. The regression tests passed without installing those runtime packages, but starting the full Express Gateway and checking live endpoints was not possible locally.
- No live provider API calls, quota checks, image generation, Puter login, or real Firebase sign-in were performed. Those depend on external service configuration, valid credentials, quotas, and remote project settings.
- `privacy-policy.html` and `account-deletion.html` remain templates with fields the project owner must fill before public distribution, as noted in the app documentation.

This is a source-code improvement package, **not an APK** and not a claim that every external integration is live.
