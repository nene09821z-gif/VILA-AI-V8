# VILA AI Studio 65.0.0 — Power Gateway + Voice Studio

## V65 Power
### Máy chủ
- `GET /v1/audio/voices` — danh sách engine TTS
- `POST /v1/audio/speech` — proxy TTS (TTS_API_KEY / OPENAI_API_KEY)
- Giữ routing, team, agent, redis cache, degraded, unified models

### Giọng nói
- **Voice Studio**: chọn engine (auto/browser/gateway/gemini), giọng hệ thống, tốc độ, cao độ, gateway voice
- Lưu **profile giọng riêng** trên máy (`vila_voice_profile_v1`)
- Tự dùng profile khi đọc câu trả lời (auto voice)
- Mic Power API (`vilaStartPowerMic`)

### UI đã có (giữ nguyên)
- NetAI theme, sidebar, Max Mode, virtual Model Hub, nén ảnh, Stop, light/dark

# VILA AI Studio 64.2.0-Complete — Full remaining roadmap

## 64.2 Complete
- **Virtual Model Hub**: windowing khi >80 model (chỉ vẽ hàng visible).
- **Nén ảnh** khi đính kèm (JPEG maxSide 1600).
- **Max Mode** gắn vào payload Gateway + globals reasoning/team.
- **Degraded mode**: banner + tắt agent/team/web khi gateway degraded.
- **Quota**: cảnh báo token ước lượng trước gửi.
- **Sidebar lịch sử** + nút chat mới.
- **Light/Dark theme** toggle.
- **Nút Dừng** khi đang sinh câu trả lời.
- CI vẫn `run-all.js`; không xóa file chức năng gốc.

# VILA AI Studio 64.1.0-NetAI — UI AI hiện đại · Model network · CI gọn

## 64.1 NetAI
- Giao diện **Modern AI 2026**: nền #212121, bubble user xám, assistant phẳng, composer bo 26px, accent #10a37f (kiểu ChatGPT).
- Model Hub catalog: page 100, virtual helper giữ cho danh mục lớn.
- CI: regression gộp `node scripts/run-all.js` (không xóa script — vẫn chạy đủ qua run-all).
- Giữ nguyên toàn bộ Java, assets, server tools, workflow android build.

# VILA AI Studio 64.0.0-Ultimate — Full roadmap delivery

## Đã triển khai toàn bộ gợi ý cải tiến

### Build & CI
- `docs/BUILD_GITHUB_KEYSTORE.md` — Secrets keystore cố định, SHA-1 Firebase

### Model Hub
- Virtual list helper (`vilaVirtualModelList`) + PAGE_SIZE 80
- Cloud favorites/recent theo uid (`vilaPushFavoritesCloud` / `vilaPullFavoritesCloud`)

### Gateway
- Redis tùy chọn (`VILA_REDIS_URL`) + memory LRU fallback
- `GET /v1/gateway/degraded` — chế độ offline/degraded cho app
- Ước lượng token header `X-VILA-Est-Tokens`
- Edition Ultimate, version 64.0.0

### Client UX
- **Max Mode** một nút (reasoning high + team deep)
- Nén ảnh trước vision (`vilaCompressImageDataUrl`)
- Ảnh lỗi: retry 1 lần + khung broken an toàn
- Multi-tab chat nhẹ (`vilaChatTabs` / `vilaNewChatTab`)
- Cảnh báo quota ngữ cảnh lớn
- Tóm tắt reasoning thống nhất (không lộ CoT thô)

### Tests
- `server/test/ultimate-v64.test.js` — dynamic reasoning + ranking

### Bảo mật
- Không inject quy tắc chủ nhân mặc định (giữ từ V63.1)
- Redis/cache không lưu API key; log metadata-only

# VILA AI Studio 63.1.0-VIP — Dynamic reasoning toàn API · Xóa quy tắc chủ nhân

## V63.1 VIP
- **Xóa quy tắc chủ nhân mặc định**: `DEFAULT_OWNER_RULES` trống; system prompt không còn khối “QUY TẮC RIÊNG CỦA CHỦ” trừ khi người dùng tự nhập.
- **Suy luận động cho mọi API**: `dynamicReasoningProfile()` trên server + `getProviderReasoningParams()` trên client.
  - Gemini: thinkingBudget / thinkingLevel / includeThoughts theo effort
  - OpenRouter: `reasoning.effort`
  - OpenAI / Groq / Cerebras / Together / Fireworks / Mistral / Custom / Puter: `reasoning_effort`
  - Tự nâng `high` khi task = coding/reasoning hoặc prompt dài
- Phân loại task mạnh hơn (prompt dài / nhiều câu hỏi → reasoning).
- Header phản hồi: `X-VILA-Reasoning-Effort`, `X-VILA-Task`.
- Rank provider ưu tiên model reasoning (o1/o3/r1/opus/…).

# VILA AI Studio 63.0.0-Max — Premium UI · Virtual Server Max · Unified API

## V63 Max (2026-10-15)
### Giao diện (sáng tạo lại theme)
- Theme **Max Premium**: nền sâu `#07080c`, accent cyan→violet, glass panel 18px blur, chat bubble gradient, composer tối.
- **Khóa ảnh cứng**: mọi `img/video/canvas` `max-width:100%`, `object-fit:contain`, khung lỗi gọn; chặn img rỗng; avatar/logo/kết quả AI không còn tràn.
- Model Hub Turbo Ultra (V62.1) giữ nguyên: infinite scroll, sort, đếm filter, debounce, ↑↓ keyboard.

### Máy chủ ảo (Gateway Max)
- Phiên bản `63.0.0-Max`.
- **Response cache** in-memory (LRU, TTL cấu hình `VILA_RESPONSE_CACHE_TTL_MS`, max `VILA_RESPONSE_CACHE_MAX`) cho prompt giống nhau (non-stream).
- Endpoint mới **`GET /v1/models/unified`**: gom catalog mọi provider đã cấu hình thành một danh sách phẳng + metadata provider.
- Health/status trả `edition: Max`, `responseCacheSize`.
- Header `X-VILA-Edition: Max` trên unified models.

### Kết nối API
- Giữ toàn bộ provider: Gemini, Groq, Cerebras, OpenRouter, OpenAI, Mistral, Together, Fireworks, Custom.
- Adaptive routing + circuit breaker + team orchestration (researcher/expert/coder/vision/critic/synthesizer).
- Agent tools: sandbox, web search (SSRF-safe), memory/docs store.
- Rate limit / concurrency / Retry-After không đổi; `REQUESTS_PER_MINUTE=0` vẫn tắt RPM nội bộ.

### Ghi chú
- Cache response chỉ an toàn cho non-stream, cùng user context; không cache agentMode/team.
- Ảnh asset gốc đã kiểm tra hợp lệ (512 / 1024 PNG).

# VILA AI Studio 62.1.0 — Model Hub Turbo Ultra + Image resilience

## V62.1 — Nâng cấp Model Hub thực thụ (2026-10-15)
- **Infinite scroll** trong danh sách model (cuộn gần cuối tự tải thêm 60 model) + nút “Hiện thêm”.
- **Sắp xếp**: Thông minh (đang dùng / yêu thích / gần đây / FREE* / khả năng), Tên A→Z, FREE* trước, Theo provider.
- **Đếm số model** trên từng bộ lọc (yêu thích, gần đây, code, ảnh, suy luận, web, FREE*).
- **Tìm kiếm debounce 140ms**, bỏ dấu tiếng Việt, tìm theo tên/id/provider/mô tả.
- **Điều hướng bàn phím**: mũi tên ↑↓ chọn model trong hộp thoại; Escape / Tab vòng focus giữ nguyên.
- **Yêu thích** mở rộng lên 2000 mục; lịch sử gần đây 40 mục.
- **Cứng hóa ảnh toàn cục**: mọi `<img>` mới sinh ra được gắn handler lỗi → khung xám gọn “Ảnh không tải được”, không tràn layout; CSS `object-fit:contain` cho avatar/logo/kết quả tạo ảnh.
- Ảnh asset gốc (`vila_avatar.png` 512×512, `vila_logo_pro.png` 1024×1024) đã kiểm tra hợp lệ, không hỏng.

# VILA AI Studio 62.0.0 — Model Hub Turbo, Preview diagnostics & mobile polish

## V62 — Model Hub Turbo + Preview resilience (2026-10-15)
- Thêm bộ lọc tác vụ cho Model Hub: tất cả, yêu thích, gần đây, model có metadata ảnh/suy luận/web, model lập trình (metadata/tên gợi ý) và nhãn FREE*. Nhãn FREE* không hứa hẹn quota/giá ở thời điểm dùng.
- Thêm yêu thích và danh sách dùng gần đây được lưu cục bộ theo cặp provider/model. Tìm kiếm bỏ dấu tiếng Việt, thêm alias, giữ model đang hoạt động lên đầu.
- Render theo từng đợt 60 model thay vì tạo hàng trăm/hàng nghìn nút cùng lúc; nút “Hiện thêm” giúp giảm giật trên điện thoại và danh mục Puter lớn.
- Tăng khả năng tiếp cận: vòng focus trong hộp thoại, khôi phục focus/vị trí cuộn, shortcut `/` không chiếm phím khi đang nhập, trạng thái bộ lọc bằng `aria-pressed`.
- Nếu trình duyệt chặn lưu trữ, vẫn cho chọn model tạm trong phiên; báo rõ khi không lưu được yêu thích. Bổ sung xử lý lỗi dựng Preview để không để khung trắng im lặng.
- Đồng bộ metadata Android/Gateway/package lên 62.0.0 (versionCode 77) và thêm test V62.

# VILA AI Studio 61.0.0 — 360px UI, Preview and HTTP 429 recovery

- Tối ưu header, các nút chế độ và vùng chat cho màn hình Android rộng 360 CSS px.
- Đặt khung Preview Điện thoại về 360px; thu gọn thanh công cụ và tránh tràn ngang.
- Nhận diện HTTP 429 rõ hơn; tôn trọng Retry-After, cooldown riêng cho từng provider/model, thử model khác trong cùng provider khi phù hợp.
- Sửa Gemini streaming 429: đọc nội dung lỗi, đánh dấu cooldown và không phát sinh yêu cầu generateContent thứ hai gây lặp tải.
- Gateway hiển thị Retry-After qua CORS; có thể đặt REQUESTS_PER_MINUTE=0 để bỏ giới hạn RPM nội bộ VILA (không bỏ quota nhà cung cấp hoặc giới hạn đồng thời).
- Không vượt giới hạn billing/quota của nhà cung cấp. Khi quota tài khoản hết, cần chờ quota hồi hoặc dùng một provider khác đã cấu hình hợp lệ.
- Nút chế độ và thao tác Preview tăng vùng chạm trên màn hình 360px; thanh Preview thu gọn nhưng vẫn giữ thao tác đóng/mở.
- Nâng metadata Android/Gateway lên 61.0.0 (versionCode 76); thêm kiểm thử V60 cho responsive, Retry-After và cooldown.

# VILA AI Studio 59.0.0 — Preview + Gemini fallback fixes

- Chạy lệnh Preview thuần cục bộ, không gọi API; tự mở bảng xem trước trên điện thoại kể cả khi chưa có code.
- Preview nhận HTML từ `index.html`, thẻ `<file>`, code fence hoặc HTML thuần; tải HTML từ workspace khi chưa có code cache.
- Cải thiện fallback Gemini: sau các model tích hợp, truy vấn catalog đang khả dụng và thử tối đa ba model mới khi auto-model bật. Lỗi 503 phía Google vẫn có thể xảy ra nếu toàn bộ dịch vụ/quota đều không khả dụng.
- Sửa CSS status panel và vùng preview trên Android WebView để tránh co/cắt nội dung.
- Nâng metadata Android/Gateway lên 59.0.0 (versionCode 74).

## V58 — Preview đa định dạng, ảnh ổn định và cuộn chat mượt (2026-10-14)
- Preview nhận HTML, SVG, CSS, JavaScript, JSON, Markdown và văn bản; thêm lựa chọn khung Desktop/Tablet/Điện thoại trên màn hình nhỏ. JavaScript Preview có bảng console trong iframe cô lập; lỗi runtime hiển thị trạng thái thay vì báo chạy thành công sớm.
- Giữ mã Preview trong sandbox; mở tab riêng bằng `data:` URL với `noopener,noreferrer`, tránh `document.write` vào trang `about:blank` cùng nguồn với ứng dụng.
- Ảnh API chuẩn hoá MIME/Base64/Base64URL và nhận biết chữ ký PNG/JPEG/WebP; trạng thái tải ảnh có xử lý lỗi giải mã và cuộn lại sau khi ảnh tải. Gỡ `content-visibility:auto` khỏi ảnh để tránh lỗi vẽ ảnh trên một số Android WebView.
- Cuộn chat theo khung hình khi nội dung đổi kích thước, ưu tiên theo câu trả lời mới nhưng tôn trọng thao tác vuốt lên đọc tin cũ; xử lý nhiều khối `<think>` để phần suy luận không làm vỡ câu trả lời.
- Thêm `scripts/test-v58-preview-image-scroll.js`; giữ toàn bộ bộ kiểm tra hiện có chạy qua. Nâng metadata Android/Gateway lên 58.0.0 (versionCode 73).

## V57 — Cải tiến từng model Puter, markdown an toàn, siết tải file (2026-10-14)
**Puter: mỗi model có "hồ sơ năng lực" riêng** (`puterModelProfile`, suy ra từ metadata catalog trực tiếp rồi mới đến họ model):
- Nhận diện họ model (Claude, OpenAI, gpt-oss, Gemini, Gemma, Grok, Llama/Muse, Qwen, Mistral, GLM, Kimi, MiniMax, Nemotron, Cohere, Sonar, Nova, Phi), bậc (⚡ nhanh / cân bằng / flagship) và đời model để sắp xếp: đời mới nhất lên đầu, flagship trước bản nhanh (4.10 xếp trên 4.8).
- Khả năng ảnh (👁) và suy luận (🧠) chính xác hơn. Trước đây mọi model có chữ "opus" đều bị coi là suy luận và mọi model có chữ "image" đều bị coi là đọc được ảnh. Metadata khai báo luôn thắng; khả năng chưa rõ giữ `null` thay vì đoán.
- Loại model không phải chat khỏi danh mục (embedding, moderation, TTS, whisper, rerank, tạo ảnh/video) để không chọn nhầm.
- Tham số theo model, đúng tài liệu Puter: `max_tokens` theo ngân sách tác vụ và giới hạn của chính model (trước đây không đặt, mặc định thành tối đa của model); model suy luận được nới thêm chỗ cho token suy nghĩ; `temperature` không gửi cho model suy luận OpenAI; `reasoning_effort` chỉ gửi cho OpenAI/Muse Spark; `verbosity` thấp ở chế độ nhanh cho GPT-5/6.
- Độ tin cậy: tự thử lại một lần khi lỗi mạng/quá tải/đứt luồng, tự chuyển sang model cùng họ khi model không khả dụng, và chuyển sang model đọc được ảnh nếu model đang chọn không hỗ trợ ảnh. Nếu đã có văn bản hiện ra rồi mới đứt, giữ lại phần đó thay vì thử lại gây lặp. Luồng treo bị cắt sau 90 giây (240 giây với model suy luận).
- Theo dõi sức khoẻ từng model (lưu cục bộ): model báo "không tồn tại" bị bỏ qua 30 phút, lỗi 2 lần liên tiếp bị tạm nghỉ 10 phút và hiện dấu ⚠ trong danh sách.
- Phân loại lỗi rõ hơn (quota, đăng nhập, model, an toàn nội dung, timeout, mạng, quá tải) với hướng dẫn riêng.
- **Sửa lỗi:** model dự phòng offline ghim `provider: anthropic`, trong khi catalog Puter dùng `claude`; nay không ghim nhà cung cấp. Nút "Kiểm tra kết nối" dùng `max_tokens: 8` nên model suy luận dễ báo rỗng; nay dùng ngân sách phù hợp, đo độ trễ và hiển thị khả năng của model. Mở danh sách model không còn làm thay đổi catalog (chèn model nhập tay).
- Danh sách model hiển thị 👁 🧠 ⚡ và ⚠.

**Toàn dự án**
- Khung chat hiển thị markdown an toàn: tiêu đề, **đậm**, *nghiêng*, `code`, gạch đầu dòng và link https. Văn bản được escape trước, chỉ sinh các thẻ cố định; link `javascript:` hoặc chèn thuộc tính không thể tạo ra (có test).
- Trình tải file của WebView chỉ nhận http(s) và làm sạch tên file, giống cầu nối `downloadUrl`.
- Thêm CSP tối thiểu (`object-src 'none'; base-uri 'self'`).
- Đồng bộ phiên bản 57.0.0 (versionCode 72) và cập nhật các test phụ thuộc phiên bản. Thêm `scripts/test-v57-puter-profiles.js`; mở rộng `test-v56-markdown-xss.js`.
- Không đổi `usesCleartextTraffic` vì Local AI qua LAN cần HTTP. APK chưa được build ở đây (không có Android SDK); hãy chạy GitHub Actions để xác nhận phần Java.

## V56 — Bảo mật: XSS trong khung chat, SSRF qua đường hầm IPv6 (2026-10-14)
- **Lỗi nghiêm trọng đã sửa — XSS khi hiển thị câu trả lời của AI:** `formatMarkdownText()` chỉ escape nội dung bên trong khối ```code```; toàn bộ phần văn bản còn lại (nội dung model/web, không đáng tin) được chèn thẳng vào `innerHTML`. Một câu trả lời chứa HTML (kể cả do prompt-injection từ trang web đã fetch) có thể thực thi ngay trong WebView — nơi có cầu nối JS gốc `window.Android` (đăng nhập Firebase, v.v.). Đã viết lại để escape toàn bộ văn bản, giữ nguyên cách hiển thị khối code; thêm `scripts/test-v56-markdown-xss.js`.
- **Lỗi đã sửa — SSRF né được qua IPv6:** `isBlockedIp()` ở `vila_web_fetch`/`vila_web_search` chặn đúng các dải IPv4/IPv6 riêng tư, nhưng chưa giải mã địa chỉ IPv6 dạng đường hầm 6to4 (`2002::/16`) và Teredo (`2001:0::/32`), vốn nhúng một địa chỉ IPv4 bất kỳ (kể cả riêng tư/loopback) bên trong một địa chỉ IPv6 trông như công khai. Đã thêm giải mã; mở rộng test trong `tools-v540.test.js`.
- Đồng bộ lại phiên bản 56.0.0 (versionCode 71) trên toàn bộ Android/Gateway/`package.json`/`.env` mẫu/`compose.yaml`/chuỗi hiển thị trong app, và sửa ~8 script kiểm tra cũ còn gán cứng chuỗi phiên bản "55.0.0"/versionCode 70 (sẽ luôn fail ngay khi đổi phiên bản nếu không sửa).

## V55 — Puter AI Hub hardening (2026-10-14)
- Bỏ màn hình chọn provider/cấu hình khi mở app; quản lý nhà cung cấp tập trung trong Cài đặt.
- Tách Puter AI Hub khỏi Claude-only; đồng bộ catalog model chat đa nhà cung cấp theo dữ liệu thực của Puter.
- Thêm tìm kiếm catalog Puter, provider-scoped model IDs, lưu cache gọn và fallback catalog gần nhất.
- Truyền provider/model metadata đúng khi gọi `puter.ai.chat`, bao gồm messages/media overloads.
- Thêm lối tắt Puter AI Hub trên bảng provider; cập nhật tài liệu và kiểm thử hồi quy.

# Changelog

Một file duy nhất thay cho hơn 50 changelog/báo cáo theo từng phiên bản trước đây.

## Bản vá tích hợp Claude/Puter — V55 source revision
- Đồng bộ danh mục Claude dự phòng với model hiện hành; catalog trực tiếp của Puter được ưu tiên và sắp xếp ổn định khi tải thành công.
- Claude nhận ảnh ở lượt đang gửi qua media API của Puter, thay vì biến dữ liệu ảnh thành một đoạn văn bản giả. Ảnh ở lượt cũ không tự tải lên lại.
- Sửa trạng thái cấu hình Claude: không hiển thị sai “thiếu API key”, không yêu cầu Base URL, lưu lựa chọn model không tạo khóa giả.
- Nút kiểm tra Claude gửi một yêu cầu thử nghiệm ngắn thật; lỗi đăng nhập, quota/rate limit, model và mạng có hướng dẫn riêng.
- Thêm hướng dẫn vận hành và kiểm tra hồi quy; không bỏ qua xác thực hay quota của Puter/Anthropic.

## 55.0.0 (versionCode 70) — Dọn dẹp và hoàn thiện
- Xoá ~90 file cũ tích tụ: changelog, README, báo cáo QA và hướng dẫn build theo từng phiên bản (V15–V54), `VILA_PRO_V17_QA_AUDIT.json`, ảnh `ic_launcher_preview.png` không được tham chiếu.
- Tài liệu còn dùng được chuyển vào `docs/`: Firebase, đăng nhập Google, Play Store, Gateway, bản đồ kỹ thuật, quy tắc chủ sở hữu, build bằng GitHub Actions.
- Tạo lại `.github/workflows/main.yml`: workflow bị thiếu trong gói zip nên 9 script kiểm tra không chạy được. Workflow gồm job kiểm tra (test Gateway và script nguồn) và job build Android.
- Đồng bộ phiên bản về 55.0.0 trong Android, Gateway, `package.json`, hai file `.env` mẫu, `compose.yaml` và bộ kiểm tra. Trước đó các file ghi lệch nhau (52.0.0, 53.6.0, 54.0.0, 54.0.2).
- Thêm `npm test` ở thư mục gốc để chạy toàn bộ test Gateway và script nguồn cùng lúc (`scripts/run-all.js`).
- Thêm `.gitignore`.
- **Định tuyến thích ứng cho Gateway:** đo độ trễ (EWMA) và tỉ lệ thành công của từng provider theo thời gian thực. Điểm xếp hạng được cộng cho provider nhanh, ổn định và trừ cho provider chập chờn hoặc chậm (giới hạn -30 đến +20, cần ít nhất 3 mẫu). Chỉ số hiển thị trong `circuit.performance` của trạng thái provider. Có test mới `adaptive-routing-v55.test.js`.
- Bộ kiểm tra không còn phụ thuộc vào các file tài liệu theo phiên bản đã xoá.

- **Giao diện gọn hơn, hết lỗi hình ảnh:** nguyên nhân là kích thước ảnh phụ thuộc Tailwind tải từ CDN; khi CDN chậm hoặc mất mạng ảnh hiện to bằng kích thước gốc và tràn màn hình. Đã chuyển sang CSS thường (ảnh đính kèm, ảnh VILA tạo, ảnh trong câu trả lời, logo, avatar), thêm "preflight" tối thiểu, sửa lệch ngang 8px trên điện thoại và thanh công cụ ô nhập bị cắt nút gửi. Ảnh lỗi hiện khung xám gọn, chạm để thử lại (tự thử lại một lần với ảnh nội bộ). Máy chủ nội bộ trong app thêm Cache-Control cho ảnh và `nosniff`. Bảng, code, danh sách, trích dẫn trong câu trả lời được căn gọn và cuộn ngang thay vì tràn.

## 54.x — Công cụ thật, Puter Claude, dọn provider
- 54.0: công cụ agent thật (sandbox JS/Python, tìm web có chặn SSRF và DNS rebinding, kho lưu trữ).
- 54.1: sửa lỗi sau audit. 54.2: tích hợp Claude qua Puter.js, cho phép popup đăng nhập trong WebView.
- 54.4: gỡ provider không mong muốn, bỏ token GitHub khỏi giao diện, giao diện đơn giản (`vila-simple`).

## 53.x — Provider pool và agent
- Pool provider (OpenAI, Mistral, Together, Fireworks), kiểm tra câu trả lời rỗng, fallback, lỗi SSE rõ ràng.
- Function calling cho agent mode, tìm kiếm và tạo ảnh/video.

## 52.x — Đa đội suy luận
- Điều phối nhiều đội (chuyên gia, nghiên cứu, lập trình, phản biện, tổng hợp), gắn provider/model riêng cho từng đội.
- Giới hạn tốc độ có trọng số, health endpoints, tắt máy an toàn, Docker Compose.
- Quét máy chủ AI cục bộ (llama.cpp, Ollama, LM Studio, vLLM, LocalAI) trên loopback.

## V50–V51 — Gateway UI, danh mục model trực tiếp
- Danh mục model tìm kiếm được, phân trang bằng `nextPageToken`, giao diện responsive cho Gateway.
- Khoá API lưu bằng AES-GCM trong Android Keystore; Gateway production từ chối chế độ không xác thực và CORS wildcard.

## 41–49 — Đăng nhập và độ tin cậy
- Firebase Auth gốc (email/mật khẩu, Google qua Credential Manager), keystore debug ổn định, reset mật khẩu.
- Deadline và dọn dẹp cho Gateway, gateway phục hồi proxy cục bộ.

## 15–40 — Nền tảng
- WebView Android, nhiều API, định tuyến thông minh, tìm kiếm, ảnh, file, dashboard, biểu tượng SVG.

Lưu ý: APK chưa được build trong môi trường chỉnh sửa này (không có Android SDK/Gradle). Hãy chạy GitHub Actions để xác nhận.
