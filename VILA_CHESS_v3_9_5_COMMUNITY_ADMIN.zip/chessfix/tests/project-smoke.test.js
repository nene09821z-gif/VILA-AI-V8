import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('Persisted settings are normalized by a standalone, testable schema', () => {
  const schema = read('src/settings-schema.js');
  const main = read('src/main.js');
  assert.match(schema, /export function normalizeSettings/);
  assert.match(schema, /botDepth/);
  assert.match(schema, /sourceProfiles\.slice\(0, 20\)/);
  assert.match(main, /import \{ DEFAULTS, normalizeSettings \} from '\.\/settings-schema\.js'/);
  assert.match(main, /Settings could not be stored/);
});

test('Curated opening library is separated into an independently testable module', () => {
  const openings = read('src/openings.js');
  assert.match(openings, /export const OPENINGS = \[\s*\{/);
  assert.match(read('src/main.js'), /import \{ OPENINGS \} from '\.\/openings\.js'/);
  assert.match(read('tests/chess.test.js'), /curated opening lines are legal/);
});

test('AI Coach requests are guarded against duplicate sends and stale responses', () => {
  const main = read('src/main.js');
  assert.match(main, /coachRequestActive/);
  assert.match(main, /coachAbortController\?\.abort\(\)/);
  assert.match(main, /requestId !== coachRequestId/);
});

test('Stockfish hint flow uses the shared worker handler and has a timeout', () => {
  const main = read('src/main.js');
  assert.match(main, /pendingHintRequest/);
  assert.match(main, /Stockfish chưa phản hồi gợi ý kịp thời/);
  assert.doesNotMatch(main, /const oldHandler = engineWorker\.onmessage/);
});

test('Download and clipboard helpers handle unsupported mobile APIs safely', () => {
  const main = read('src/main.js');
  assert.match(main, /function downloadTextFile/);
  assert.match(main, /document\.execCommand\?\.\('copy'\)/);
  assert.match(main, /setTimeout\(\(\) => URL\.revokeObjectURL\(url\), 1500\)/);
});

test('Auto engine stays on Lite while Full remains an explicit optional profile', () => {
  const helper = read('src/engine-profile.js');
  const main = read('src/main.js');
  assert.match(helper, /return 'lite-single'/);
  assert.match(helper, /preference === 'full-single'/);
  assert.match(main, /value="auto"/);
  assert.match(main, /resolveEngineProfile/);
  assert.match(main, /forceLite: nextProfile === 'lite-single', forceAsm: nextProfile === 'asm', isFallback: true/);
  assert.match(main, /Stockfish ASM-JS/);
  assert.match(main, /tryEngineInitFallback\(selectedEngine\)/);
});

test('Stockfish Lite + ASM-JS assets are mandatory while the very large Full bundle is optional', () => {
  const script = read('scripts/copy-engine.mjs');
  for (const name of ['stockfish-19-lite-single.js', 'stockfish-19-lite-single.wasm']) {
    assert.ok(script.includes(name), `Missing required engine asset declaration: ${name}`);
  }
  for (const name of ['stockfish-19-single.js', 'stockfish-19-single.wasm']) assert.ok(script.includes(name));
  assert.match(script, /INCLUDE_STOCKFISH_FULL/);
  assert.ok(script.includes('stockfish-19-asm.js'), 'ASM-JS recovery engine must be included in app assets');
  assert.match(script, /asmFallback: true/);
  assert.match(script, /Validate sources BEFORE clearing/);
  assert.match(script, /REQUIRE_STOCKFISH/);
});

test('Android workflow fails instead of silently shipping without Stockfish', () => {
  const workflow = read('.github/workflows/build-android.yml');
  assert.match(workflow, /REQUIRE_STOCKFISH:\s*'1'/);
  assert.match(workflow, /ASM-JS recovery/i);
  assert.match(workflow, /npm test/);
  assert.match(workflow, /assembleDebug/);
});

test('Chessboard renders file coordinates on all eight bottom squares in either orientation', () => {
  const main = read('src/main.js');
  assert.match(main, /rowIndex === 7 \? `<span class=\"coord file-coord\">\$\{file\}<\/span>` : ''/);
  assert.match(main, /const files = orientation === 'w' \? \['a','b','c','d','e','f','g','h'\] : \['h','g','f','e','d','c','b','a'\]/);
  assert.match(main, /rowIndex === 7 \? `<span class=\"coord file-coord\">\$\{file\}<\/span>` : ''/);
  assert.match(main, /const rows = \[8,7,6,5,4,3,2,1\], files = \['a','b','c','d','e','f','g','h'\]/);
});

test('UI includes core Play, Arena, Openings, Coach, Lichess and Settings views', () => {
  const html = read('index.html');
  for (const view of ['play', 'arena', 'openings', 'coach', 'lichess', 'leaderboard', 'history', 'settings']) {
    assert.ok(html.includes(`data-view="${view}"`), `Missing ${view} navigation`);
  }
});

test('Backend protects public binds with access token', () => {
  const server = read('server/index.js');
  assert.match(server, /TUBOR_ACCESS_TOKEN/);
  assert.match(server, /HOST/);
});


test('VILA Chess branding assets and Android resource pipeline are present', () => {
  const html = read('index.html');
  const config = JSON.parse(read('capacitor.config.json'));
  const packageJson = JSON.parse(read('package.json'));
  const brandingScript = read('scripts/apply-android-branding.mjs');
  const androidWorkflow = read('.github/workflows/build-android.yml');
  const zipWorkflow = read('.github/workflows/build-from-zip.yml');
  const style = read('src/style.css');
  assert.equal(config.appName, 'VILA Chess');
  assert.equal(packageJson.name, 'chess-bot-ai');
  assert.match(packageJson.scripts['android:init'], /apply-android-branding\.mjs/);
  assert.match(style, /--accent:#4bbfff/);
  assert.match(html, /chess-bot-icon\.webp/);
  assert.match(html, /VILA Chess — AI Chess Arena/);
  assert.match(html, /name=\"theme-color\" content=\"#050A14\"/);
  for (const asset of [
    'public/chess-bot-logo.webp', 'public/chess-bot-icon.png', 'public/chess-bot-icon.webp', 'public/favicon.ico',
    'resources/android-icons/mipmap-mdpi/ic_launcher.png',
    'resources/android-icons/mipmap-xxxhdpi/ic_launcher.png',
    'resources/android-icons/mipmap-anydpi-v26/ic_launcher.xml'
  ]) assert.ok(fs.existsSync(path.join(root, asset)), `Missing branding asset: ${asset}`);
  assert.match(brandingScript, /ic_launcher_foreground/);
  assert.ok(brandingScript.includes('<string name="app_name">VILA Chess</string>'));
  assert.match(androidWorkflow, /apply-android-branding\.mjs/);
  assert.match(zipWorkflow, /apply-android-branding\.mjs/);
});


test('main bot timers are epoch/FEN/mode guarded and old hint queue is preserved correctly', () => {
  const main = read('src/main.js');
  assert.match(main, /function scheduleBotMove/);
  assert.match(main, /expectedEpoch !== gameEpoch \|\| expectedFen !== game\.fen\(\) \|\| expectedMode !== mode/);
  assert.match(main, /const resumeQueuedMainMove = queuedMainEngineMove/);
  assert.match(main, /function cancelMainEngineSearch/);
  assert.match(main, /if \(mode !== 'stockfish' \|\| !botThinking \|\| game\.isGameOver\(\) \|\| clockFlagged \|\| game\.turn\(\) === humanColor\) return/);
});

test('engine copy script validates required assets before clearing old outputs', () => {
  const script = read('scripts/copy-engine.mjs');
  assert.match(script, /Validate sources BEFORE clearing/);
  assert.match(script, /for \(const entry of fs\.readdirSync\(destination\)\)/);
  assert.match(script, /fs\.rmSync\(path\.join\(destination, entry\), \{ recursive: true, force: true \}\)/);
  assert.match(read('package.json'), /"build": "node scripts\/copy-engine\.mjs --required && vite build"/);
});


test('stale Opening Explorer responses cannot overwrite a newer board position', () => {
  const main = read('src/main.js');
  assert.match(main, /let explorerRequestId = 0/);
  assert.match(main, /requestId !== explorerRequestId \|\| expectedFen !== game\.fen\(\)/);
  assert.match(main, /Array\.isArray\(data\?\.moves\)/);
});

test('AI settings and arena profiles validate endpoint URLs before claiming success', () => {
  const main = read('src/main.js');
  assert.match(main, /function isSafeHttpEndpoint/);
  assert.match(main, /if \(!isSafeHttpEndpoint\(endpointInput\)\)/);
  assert.match(main, /if \(!isSafeHttpEndpoint\(endpoint\)\)/);
  assert.equal((main.match(/addEventListener\('click', challengeLichessUser\)/g) || []).length, 1);
  assert.match(main, /function safeLichessUrl/);
  assert.match(main, /!parsed\.username && !parsed\.password && !parsed\.port/);
  assert.match(read('server/provider-endpoints.js'), /url\.username \|\| url\.password \|\| url\.search \|\| url\.hash/);
});


test('Lichess challenge result does not create duplicate button IDs', () => {
  const main = read('src/main.js');
  assert.equal((main.match(/id=\"playLichessHere\"/g) || []).length, 1, 'The active-game panel owns the single playLichessHere ID');
  assert.equal((main.match(/id=\"playLichessChallenge\"/g) || []).length, 2, 'Challenge result variants use their own distinct ID');
  assert.equal((main.match(/\$\('#playLichessChallenge'\)\?\.addEventListener\('click', startOnlinePlay\)/g) || []).length, 2);
});

test('Lichess disconnect clears local session and aborts active stream', () => {
  const main = read('src/main.js');
  const forgetStart = main.indexOf("$('#forgetLichess')?.addEventListener('click'");
  const forgetEnd = main.indexOf("$('#challengeLichessAI')?.addEventListener", forgetStart);
  assert.ok(forgetStart >= 0 && forgetEnd > forgetStart, 'Lichess forget handler must exist');
  const forgetHandler = main.slice(forgetStart, forgetEnd);
  assert.match(forgetHandler, /stopOnlineStream\(\)/);
  assert.match(forgetHandler, /activeLichessToken = ''/);
  assert.match(forgetHandler, /activeOnlineGame = null/);
  assert.match(forgetHandler, /safeSessionRemove\(lichessTokenKey\)/);
});

test('Late Lichess stream responses cannot update a newer game session', () => {
  const main = read('src/main.js');
  const start = main.indexOf('async function listenOnlineGame()');
  const end = main.indexOf('function processLichessEvent(event)', start);
  assert.ok(start >= 0 && end > start, 'Online stream handler must exist');
  const stream = main.slice(start, end);
  assert.match(stream, /const streamGameId = String\(activeOnlineGame\?\.id \|\| ''\)/);
  assert.match(stream, /const isCurrentStream = \(\) => !controller\.signal\.aborted && activeOnlineGame\?\.id === streamGameId && onlineStreamController === controller/);
  assert.match(stream, /if \(!isCurrentStream\(\)\) return/);
  assert.match(stream, /while \(isCurrentStream\(\)\)/);
  assert.match(stream, /if \(isCurrentStream\(\) && error\?\.name !== 'AbortError'\)/);
});

test('Android build workflow validates Gradle files and exports generated native source ZIP', () => {
  const workflow = read('.github/workflows/build-android.yml');
  const zipWorkflow = read('.github/workflows/build-from-zip.yml');
  const verifier = read('scripts/verify-android-project.mjs');
  const packager = read('scripts/package-android-source.py');
  for (const source of [workflow, zipWorkflow]) {
    assert.match(source, /scripts\/verify-android-project\.mjs/);
    assert.match(source, /scripts\/package-android-source\.py/);
    assert.match(source, /vila-chess-android-gradle-source/);
  }
  assert.match(verifier, /gradle-wrapper\.jar/);
  assert.match(verifier, /GradleWrapperMain/);
  assert.match(verifier, /settings\.gradle/);
  assert.match(packager, /gradle-wrapper\.jar/);
  assert.match(packager, /node_modules.*@capacitor.*android/s);
  assert.match(packager, /GradleWrapperMain\.class/);
  assert.match(packager, /parts\[:2\] == \('public', 'engine'\)/);
  assert.match(packager, /Output ZIP verification failed/);
});

test('API requests have a timeout and preserve caller cancellation', () => {
  const main = read('src/main.js');
  const start = main.indexOf('async function apiFetch(path, options = {})');
  const end = main.indexOf('\nfunction aiRequestConfigured()', start);
  assert.ok(start >= 0 && end > start, 'Shared API helper must be present');
  const helper = main.slice(start, end);
  assert.match(helper, /new AbortController\(\)/);
  assert.match(helper, /90_000/);
  assert.match(helper, /callerSignal\?\.addEventListener\('abort', abortFromCaller/);
  assert.match(helper, /callerSignal\?\.removeEventListener\('abort', abortFromCaller/);
  assert.match(helper, /Yêu cầu quá thời gian chờ.*timeoutMs/);
  assert.match(helper, /Number\(options\.timeoutMs\)/);
});

test('AI Coach keeps a draft if a request is already active', () => {
  const main = read('src/main.js');
  const start = main.indexOf("$('#coachForm')?.addEventListener('submit'");
  const end = main.indexOf("$('#clearChat')?.addEventListener", start);
  assert.ok(start >= 0 && end > start, 'Coach form handler must exist');
  const handler = main.slice(start, end);
  assert.ok(handler.indexOf('if (coachRequestActive)') < handler.indexOf("input.value = ''"), 'Guard must run before clearing the input');
  assert.match(handler, /Tin nhắn mới vẫn được giữ trong ô nhập/);
});

test('AI game mode is guarded when its provider requires a missing API key', () => {
  const main = read('src/main.js');
  assert.match(main, /function aiRequestConfigured\(\)/);
  assert.match(main, /const needsKey = settings\.aiMode === 'gemini' \|\| settings\.aiMode === 'anthropic'/);
  assert.match(main, /chosen === 'ai' && !aiRequestConfigured\(\)/);
  assert.match(main, /selectedMode === 'ai' && !aiRequestConfigured\(\)/);
  assert.match(main, /if \(mode === 'ai' && !aiRequestConfigured\(\)\) \{/);
});

test('Lichess proxy aborts its upstream request and destroys the locked stream on disconnect', () => {
  const server = read('server/index.js');
  const start = server.indexOf("app.post('/api/lichess/stream'");
  const end = server.indexOf("app.get('/api/openings/explorer'", start);
  assert.ok(start >= 0 && end > start, 'Lichess streaming route must exist');
  const route = server.slice(start, end);
  assert.match(route, /new AbortController\(\)/);
  assert.match(route, /res\.once\('close', abortUpstream\)/);
  assert.match(route, /signal: upstreamController\.signal/);
  assert.match(route, /upstreamStream\.destroy\(\)/);
  assert.doesNotMatch(route, /upstream\.body\.cancel\(\)/);
});

test('Lichess client flushes the final NDJSON record when the stream ends without a newline', () => {
  const main = read('src/main.js');
  const start = main.indexOf('async function listenOnlineGame()');
  const end = main.indexOf('function processLichessEvent(event)', start);
  assert.ok(start >= 0 && end > start, 'Lichess client stream handler must exist');
  const stream = main.slice(start, end);
  assert.match(stream, /if \(done\) \{\s*pending \+= decoder\.decode\(\);\s*if \(pending\.trim\(\)\) handleStreamLine\(pending\)/);
  assert.match(stream, /const handleStreamLine = line =>/);
});


test('mobile chess UI includes clock controls and a Stockfish MultiPV panel', () => {
  const main = read('src/main.js');
  const css = read('src/style.css');
  assert.match(main, /CLOCK_PRESETS/);
  assert.match(main, /id=\"clock\$\{color === 'w' \? 'White' : 'Black'\}\"/);
  assert.match(main, /setoption name MultiPV value 3/);
  assert.match(main, /Phân tích 3 biến/);
  assert.match(main, /điểm theo Trắng/);
  assert.match(main, /id="apiModelList"/);
  assert.match(main, /const shown = freeOnly \? models\.filter/);
  assert.match(main, /Không có model free được xác nhận trong danh sách này/);
  assert.match(main, /list\.innerHTML/);
  assert.match(css, /grid-template-rows:repeat\(8,minmax\(0,1fr\)\)/);
  assert.match(main, /go movetime \${moveTimeMs} depth \${depth}/);
  assert.match(main, /calculateBoardFrameMaxWidth/);
  assert.match(main, /ResizeObserver/);
  assert.match(main, /accessibleSquareLabel/);
  assert.match(main, /function syncArenaBoardLayout\(\)/);
  assert.match(main, /line\.includes\('readyok'\) && !engineFailed/);
});

test('provider model inventory and Gemini endpoint normalization exist as real backend routes', () => {
  const server = read('server/index.js');
  const endpoints = read('server/provider-endpoints.js');
  assert.match(server, /app\.post\('\/api\/ai\/models'/);
  assert.match(server, /geminiModelsUrl/);
  assert.match(server, /supportedGenerationMethods/);
  assert.match(server, /data\?\.has_more === true/);
  assert.match(endpoints, /v1beta\/models/);
  assert.match(endpoints, /:generateContent/);
});


test('Stockfish hash and thread options are initialized once rather than resetting the hash before every move', () => {
  const main = read('src/main.js');
  assert.equal((main.match(/setoption name Hash value/g) || []).length, 1, 'Hash should be configured once on UCI initialization');
  const moveStart = main.indexOf('function askStockfishMove()');
  const moveEnd = main.indexOf('function chooseFallbackMove()', moveStart);
  assert.ok(moveStart >= 0 && moveEnd > moveStart);
  const moveHandler = main.slice(moveStart, moveEnd);
  assert.doesNotMatch(moveHandler, /ucinewgame/);
  assert.doesNotMatch(moveHandler, /setoption name Hash/);
  assert.match(main, /if \(line\.includes\('readyok'\) && !engineFailed\) \{[\s\S]{0,160}engineReady = true/);
});

test('board layout module is wired into the app and defines exact square geometry', () => {
  const main = read('src/main.js');
  const layout = read('src/board-layout.js');
  assert.match(main, /import \{ calculateBoardFrameMaxWidth, calculateChessSquareSize \}/);
  assert.match(main, /window\.visualViewport\?\.addEventListener\('resize'/);
  assert.match(layout, /viewportW > viewportH/);
  assert.match(layout, /width \/ 8/);
});


test('v3 opening diversity, board sound, spoken hints, and local Coach controls are wired', () => {
  const main = read('src/main.js');
  const openings = read('src/openings.js');
  const sound = read('src/sound.js');
  const settings = read('src/settings-schema.js');
  assert.match(main, /findOpeningBookMove\(game, OPENINGS/);
  assert.match(main, /findOpeningBookMove\(chess, OPENINGS/);
  assert.match(main, /playBoardSound\(made, arenaGame, settings.soundEnabled\)/);
  assert.match(main, /id="speakHint"/);
  assert.match(main, /speechSynthesis\.speak\(utterance\)/);
  assert.match(main, /id="coachEngineMode"/);
  assert.match(main, /analyzeLocallyForCoach\(\)/);
  assert.match(main, /id="openingBookEnabledSetting"/);
  assert.match(main, /id="soundEnabledSetting"/);
  assert.match(sound, /AudioContext \|\| window\.webkitAudioContext/);
  assert.match(sound, /export function unlockBoardSound/);
  assert.match(main, /unlockBoardSound\(\); startArenaMatch/);
  assert.match(main, /arenaRunLeague.*addEventListener\('click', \(\) => \{ unlockBoardSound\(\); runArenaLeague\(\); \}\)/s);
  assert.match(main, /const candidateGame = new Chess\(\)/);
  assert.match(main, /Validate the whole line on a temporary board before touching the active game/);
  assert.match(main, /!Array\.isArray\(opening\.san\) \|\| opening\.san\.length === 0/);
  assert.match(main, /Biến \$\{opening\.name\} có nước không hợp lệ/);
  assert.match(settings, /soundEnabled: true/);
  assert.match(settings, /openingBookEnabled: true/);
  const names = [...openings.matchAll(/\{\s*(?:name:|"name":)/g)];
  assert.ok(names.length >= 70, `Expected at least 70 opening lines, found ${names.length}`);
});


test('fresh launches stay in ready state and Start honors the selected game mode and color', () => {
  const main = read('src/main.js');
  assert.match(main, /function startGameFromSetup\(\)/);
  assert.match(main, /\$\('#startGameOverlay'\)\?\.addEventListener\('click', startGameFromSetup\)/);
  assert.match(main, /\$\('#newGameSetup'\)\?\.addEventListener\('click', startGameFromSetup\)/);
  assert.match(main, /let gameStarted = false/);
  assert.match(main, /id="startGameOverlay"/);
  assert.match(main, /function wireBoardPointerDrag\(board\)/);
  assert.match(main, /document\.elementFromPoint\(event\.clientX, event\.clientY\)/);
  assert.match(main, /if \(!gameStarted\) \{ toast\('Nhấn “Bắt đầu ván mới”/);
  assert.match(main, /id="boardArrows"/);
});

test('completed games provide an actual result, resignation control and full game Stockfish review', () => {
  const main = read('src/main.js');
  assert.match(main, /function getGameResult\(\)/);
  assert.match(main, /function startFullGameReview\(\)/);
  assert.match(main, /function resignCurrentGame\(\)/);
  assert.match(main, /id="reviewGameBtn"/);
  assert.match(main, /id="resignBtn"/);
  assert.match(main, /manualGameResult/);
});

test('API key errors are provider-aware and redact secrets before returning to UI', () => {
  const helper = read('server/provider-errors.js');
  const server = read('server/index.js');
  assert.match(helper, /sanitizeProviderDetail/);
  assert.match(helper, /redacted API key/);
  assert.match(server, /friendlyProviderFailure\(upstream\.status, detail, providerLabel\(mode, endpoint\), apiKey\)/);
});


test('Stockfish timeout retires the worker and exposes an accessible retry control', () => {
  const main = read('src/main.js');
  const html = read('index.html');
  assert.match(main, /function retireStockfishWorker\(message = 'Stockfish không khả dụng\.'/);
  assert.match(main, /retired\?\.terminate\(\)/);
  assert.match(main, /if \(engineWorker !== worker\) return/);
  assert.match(main, /engineWorker = null/);
  assert.match(main, /function retryStockfishEngine\(\)/);
  assert.match(main, /\$\('#engineStatus'\)\?\.addEventListener\('click', retryStockfishEngine\)/);
  assert.match(html, /<button type="button" id="engineStatus" class="status-chip"/);
  assert.match(main, /retireStockfishWorker\('Stockfish quá thời gian suy nghĩ\.'/);
});

test('Evaluation meter is labeled as a visual cue rather than a win probability', () => {
  const main = read('src/main.js');
  assert.match(main, /function updateEvaluationMeter\(scoreType, scoreValue, sideToMove\)/);
  assert.match(main, /not win probability/);
  assert.match(main, /id="evaluationMeterWhite"/);
});


test('v3.4 local Elo and leaderboard are connected to completed game rendering', () => {
  const main = read('src/main.js');
  assert.match(main, /function maybeRecordRatedGame\(/);
  assert.match(main, /maybeRecordRatedGame\(\);/);
  assert.match(main, /function renderLeaderboardView\(/);
  assert.match(main, /rating-result-strip/);
  assert.match(main, /setChessMusicPlaying/);
  assert.match(read('src/elo.js'), /calculateEloChange/);
});

test('AI proxy uses tested provider-specific response normalization and reports empty-output diagnostics', () => {
  const server = read('server/index.js');
  const parser = read('server/chat-response.js');
  assert.match(server, /extractChatText\(mode, data\)/);
  assert.match(server, /getChatEmptyHint\(mode, data\)/);
  assert.match(parser, /export function extractChatText/);
  assert.match(parser, /finish reason/);
});


test('v3.5 analysis sessions reject stale positions and serialize cancelled Stockfish searches', () => {
  const main = read('src/main.js');
  const helper = read('src/analysis-session.js');
  assert.match(main, /engineStopPending/);
  assert.match(main, /Stockfish đang kết thúc lượt phân tích trước/);
  assert.match(main, /Consume the terminal line for the cancelled search/);
  assert.match(main, /function requestEngineStop\(\)/);
  assert.match(main, /cancelled job emits its terminal line/);
  assert.match(main, /isCurrentAnalysisSession/);
  assert.match(main, /mergeAnalysisVariation/);
  assert.match(main, /button.disabled = engineStopPending/);
  assert.match(main, /analysisVisible = true/);
  assert.match(main, /panel.hidden = !\(analysisVisible \\|\| analysisActive \\|\| analysisVariants.length\)/);
  assert.ok(main.indexOf('id=\"analysisPanel\"') < main.indexOf('class=\"hint-card\"'), 'Analysis panel should be shown before the hint card on mobile');
  assert.match(main, /reviewSession.currentDepth/);
  assert.match(main, /pendingCoachAnalysis = null;\s*clearTimeout\(request.timeout\);\s*engineSearchActive = false;\s*mainEngineSearchEpoch = -1;\s*mainEngineSearchFen = '';/);
  assert.match(helper, /sessionFen === currentFen/);
  assert.match(read('package.json'), /tests\/analysis-session\.test\.js/);
});


test('VILA Chess opens on a real home dashboard with working routes to existing tools', () => {
  const html = read('index.html');
  const main = read('src/main.js');
  const style = read('src/style.css');
  assert.match(html, /data-view="home"/);
  assert.match(html, /<b>VILA CHESS<\/b>/);
  assert.match(main, /let currentView = 'home'/);
  assert.match(main, /function renderHomeView\(\)/);
  assert.match(main, /data-home-action="quickplay"/);
  for (const view of ['play', 'arena', 'coach', 'openings', 'leaderboard', 'lichess', 'settings']) assert.match(main, new RegExp(`data-home-view=\"${view}\"`));
  assert.match(style, /\.home-hero/);
  assert.match(style, /\.home-feature-grid/);
});

test('Home dashboard renderer produces a complete 8x8 feature board', () => {
  const main = read('src/main.js');
  const start = main.indexOf('function renderHomeView() {');
  const end = main.indexOf('\nfunction wireHomeActions()', start);
  assert.ok(start >= 0 && end > start, 'Home renderer must exist as a standalone function');
  const renderHomeView = new Function('readRatingProfile', 'settings', 'esc', `${main.slice(start, end)}; return renderHomeView();`);
  const html = renderHomeView(() => ({ elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, lastChange: 0 }), { model: 'test-model' }, value => String(value ?? ''));
  assert.equal((html.match(/class="home-sq-(?:light|dark)"/g) || []).length, 64, 'Home illustration should render exactly 64 squares');
  for (const text of ['Mỗi nước đi', 'Chơi với Stockfish', 'Đấu trường AI', 'AI phân tích', 'Khai cuộc', 'Elo & xếp hạng', 'Lichess trực tuyến']) assert.ok(html.includes(text), `Home dashboard is missing: ${text}`);
});


test('Saved-game archive, clickable review replay and heuristic brilliant-move labels are wired', () => {
  const main = read('src/main.js');
  const html = read('index.html');
  const styles = read('src/style.css');
  assert.match(html, /data-view="history"/);
  assert.match(main, /function maybeArchiveCompletedGame/);
  assert.match(main, /localStorage\.setItem\(GAME_HISTORY_KEY/);
  assert.match(main, /data-history-review/);
  assert.match(main, /data-history-analyze/);
  assert.match(main, /data-review-step/);
  assert.match(main, /data-review-ply/);
  assert.match(main, /classifyReviewedMove/);
  assert.match(styles, /\.review-replay-board/);
  assert.match(styles, /\.verdict-brilliant/);
});

test('Chess music streams a licensed piano track and keeps an offline generated fallback', () => {
  const sound = read('src/sound.js');
  const credits = read('MUSIC_CREDITS.md');
  assert.match(sound, /upload\.wikimedia\.org/);
  assert.match(sound, /function startSynthMusic/);
  assert.match(sound, /audio\.play\(\)/);
  assert.match(credits, /CC BY 3\.0/);
  assert.match(credits, /Kevin MacLeod/);
});

test('PGN export writes one canonical header set and preserves custom FEN starts', () => {
  const main = read('src/main.js');
  const start = main.indexOf('function gamePgnWithResult() {');
  const end = main.indexOf('\nfunction downloadPgn()', start);
  assert.ok(start >= 0 && end > start, 'PGN export function must exist');
  const pgn = main.slice(start, end);
  assert.match(pgn, /\[SetUp \"1\"\]/);
  assert.match(pgn, /\[FEN \"\$\{pgnEscape\(gameStartFen\)\}\"\]/);
  assert.match(pgn, /indexOf\('\\n\\n'\)/);
  assert.match(main, /data-play-view=\"history\"/);
});
