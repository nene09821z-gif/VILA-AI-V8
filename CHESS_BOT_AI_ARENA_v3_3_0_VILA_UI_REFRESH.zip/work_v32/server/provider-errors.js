import { isLocalNoKeyEndpoint } from '../src/builtin-models.js';

export function providerKeyRequired(mode, endpoint) {
  if (mode === 'gemini' || mode === 'anthropic') return true;
  return mode === 'openai-compatible' && !isLocalNoKeyEndpoint(endpoint);
}

function sanitizeProviderDetail(detail, apiKey = '') {
  let text = String(detail || '');
  if (apiKey && apiKey.length >= 4) text = text.split(apiKey).join('[redacted API key]');
  return text
    .replace(/(authorization|api[_ -]?key|bearer)\s*[:=]\s*[^\s,;"']+/ig, '$1=[redacted]')
    .replace(/((?:[?&](?:key|api_key|token|access_token)=))[^&\s]+/ig, '$1[redacted]')
    .replace(/https?:\/\/[^\s"']+/ig, match => {
      try {
        const url = new URL(match);
        for (const key of ['key', 'api_key', 'token', 'access_token']) if (url.searchParams.has(key)) url.searchParams.set(key, '[redacted]');
        return url.toString();
      } catch { return '[provider URL redacted]'; }
    })
    .replace(/[\r\n\t]+/g, ' ')
    .slice(0, 240);
}

export function friendlyProviderFailure(status, detail = '', provider = 'AI', apiKey = '') {
  const code = Number(status) || 0;
  const raw = sanitizeProviderDetail(detail, apiKey);
  const detailText = raw ? ` Chi tiết: ${raw}` : '';
  if (code === 401) return { status: 401, message: `API key không hợp lệ hoặc đã hết hiệu lực. Hãy tạo key mới tại trang chính thức của ${provider}, kiểm tra đúng nhà cung cấp rồi thử lại.${detailText}` };
  if (code === 403) return { status: 403, message: `Nhà cung cấp từ chối quyền truy cập. Kiểm tra quyền của key, billing/Free Tier, khu vực và quyền dùng model.${detailText}` };
  if (code === 404) return { status: 404, message: `Không tìm thấy model hoặc endpoint. Kiểm tra Model ID và Base URL trong Cài đặt.${detailText}` };
  if (code === 429) return { status: 429, message: `Nhà cung cấp đã giới hạn tần suất hoặc hết quota. Chờ hết thời gian giới hạn, giảm yêu cầu hoặc chọn model khác.${detailText}` };
  if (code === 400) return { status: 400, message: `Yêu cầu API bị từ chối. Model có thể không hỗ trợ kiểu chat/generate, hoặc tham số không hợp lệ.${detailText}` };
  if (code >= 500) return { status: 502, message: `Dịch vụ ${provider} đang lỗi hoặc quá tải. Thử lại sau; Stockfish nội bộ vẫn có thể chơi cờ.${detailText}` };
  return { status: code >= 400 ? code : 502, message: `${provider} trả về lỗi${code ? ` HTTP ${code}` : ''}.${detailText}` };
}
