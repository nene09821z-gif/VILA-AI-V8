import { Chess } from 'chess.js';
import { resolveEngineProfile } from './engine-profile.js';
import { formatUciScore, parseUciInfoLine } from './analysis-utils.js';
import { calculateBoardFrameMaxWidth, calculateChessSquareSize } from './board-layout.js';
import { CLOCK_PRESETS, formatClockTime, parseClockPreset } from './clock.js';
import { OPENINGS } from './openings.js';
import { findOpeningBookMove } from './opening-book.js';
import { recognizeOpening } from './opening-recognition.js';
import { classifyCentipawnLoss, estimateMoveLoss, scoreSideToWhiteCentipawns } from './game-review.js';
import { BUILTIN_FREE_MODEL_PRESETS, freePresetsForProvider, isLocalNoKeyEndpoint } from './builtin-models.js';
import { playBoardSound, unlockBoardSound } from './sound.js';
import { DEFAULTS, normalizeSettings } from './settings-schema.js';
import './style.css';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const STORAGE_KEY = 'tubor.chess.settings.v1';
const lichessTokenKey = 'tubor.chess.lichessToken.session';
function safeSessionGet(key) {
  try { return sessionStorage.getItem(key) || ''; } catch { return ''; }
}
function safeSessionSet(key, value) {
  try { sessionStorage.setItem(key, String(value ?? '')); return true; } catch { return false; }
}
function safeSessionRemove(key) {
  try { sessionStorage.removeItem(key); return true; } catch { return false; }
}
function getLichessToken() {
  return String($('#lichessToken')?.value?.trim() || activeLichessToken || safeSessionGet(lichessTokenKey) || '').trim();
}

let settings = loadSettings();
let currentView = 'play';
let game = new Chess();
let gameStartFen = game.fen();
let reviewStatus = '';
let gameStarted = false; // New launches always wait for explicit Start.
let manualGameResult = null; // Resign/agree-draw result; does not falsify chess.js move history.
let reviewSession = null;
let completedReviewRows = [];
let dragState = null;
let dragGhost = null;
let suppressSquareClickUntil = 0;
let mode = 'stockfish'; // stockfish, ai, local
let humanColor = 'w';
let orientation = 'w';
let selected = null;
let selectedTargets = [];
let botThinking = false;
let currentOpening = null;
let lastHintMove = null;
const recentOpeningChoices = new Map();
let pendingCoachAnalysis = null;
let loadedApiModels = [];
let loadedModelContext = ''; 
let lastMove = null;
let engineWorker = null;
let engineReady = false;
let engineUciInitialized = false;
let engineFailed = false;
let boardResizeObserver = null;
let boardResizeRaf = 0;
let engineQueue = [];
let engineSearchActive = false;
let pendingEngineRequest = null;
let pendingHintRequest = null;
let apiMoveAbortController = null;
let mainEngineTimer = null;
let mainBotKickTimer = null;
let gameEpoch = 0;
let mainEngineSearchEpoch = -1;
let mainEngineSearchFen = '';
let queuedMainEngineMove = false;
let clockState = { enabled: false, running: false, remaining: { w: 0, b: 0 }, incrementMs: 0, lastTickAt: 0 };
let clockFlagged = null;
let clockInterval = null;
let analysisActive = false;
let analysisFen = '';
let analysisEpoch = -1;
let analysisVariants = [];
let analysisTimeout = null;
let analysisLastPaintAt = 0;
let arenaGame = new Chess();
let arenaRunning = false;
let arenaStopRequested = false;
let arenaAbortController = null;
let arenaLastMove = null;
let arenaPgnHeaders = {};
let arenaLastPgnResult = '*';
let arenaPgnArchive = [];
let arenaLastResult = '';
let arenaCurrentPlayers = { w: null, b: null };
let arenaGameCounter = 0;
let arenaLastNote = '';
let arenaTournamentSummary = '';
let arenaSelectedLeague = new Set(['stockfish', 'current']);
let arenaFallbackMoves = new Map();
let activeOnlineGame = null;
let activeLichessUsername = safeSessionGet('tubor.chess.lichessUsername');
let activeLichessToken = safeSessionGet(lichessTokenKey);
let onlineStreamController = null;
let lastExplorerData = null;
let explorerRequestId = 0;
let chatMessages = [];
let coachRequestActive = false;
let coachRequestId = 0;
let coachAbortController = null;
let toastTimer = null;

function loadSettings() {
  try {
    return normalizeSettings(JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'));
  } catch {
    return normalizeSettings(DEFAULTS);
  }
}
function saveSettings() {
  try {
    const normalized = normalizeSettings(settings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    settings = normalized;
    return true;
  } catch (error) {
    console.warn('[Chess Bot] Settings could not be stored:', error);
    toast('Không lưu được cài đặt trên thiết bị này. Hãy kiểm tra dung lượng hoặc quyền lưu trữ.');
    return false;
  }
}
function apiUrl(path) {
  const base = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  return `${base}${path}`;
}
function isSafeHttpEndpoint(value) {
  try {
    const parsed = new URL(String(value || '').trim());
    return ['http:', 'https:'].includes(parsed.protocol) && Boolean(parsed.hostname) &&
      !parsed.username && !parsed.password && !parsed.search && !parsed.hash;
  } catch {
    return false;
  }
}
function safeLichessUrl(value, gameId) {
  const cleanId = String(gameId || '').trim();
  const fallback = cleanId ? `https://lichess.org/${encodeURIComponent(cleanId)}` : 'https://lichess.org/';
  try {
    const parsed = new URL(String(value || fallback));
    return parsed.protocol === 'https:' && parsed.hostname === 'lichess.org' && !parsed.username && !parsed.password && !parsed.port ? parsed.href : fallback;
  } catch {
    return fallback;
  }
}
async function apiFetch(path, options = {}) {
  // Bound ordinary API requests so a broken backend/network cannot leave chat,
  // settings or arena controls in a permanent loading state.
  const controller = new AbortController();
  const callerSignal = options.signal;
  let timedOut = false;
  const abortFromCaller = () => controller.abort();
  if (callerSignal?.aborted) controller.abort();
  else callerSignal?.addEventListener('abort', abortFromCaller, { once: true });
  const timeoutMs = Math.max(1000, Math.min(90_000, Number(options.timeoutMs) || 90_000));
  const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
  try {
    const { signal: _callerSignal, timeoutMs: _timeoutMs, ...fetchOptions } = options;
    const response = await fetch(apiUrl(path), {
      ...fetchOptions,
      signal: controller.signal,
      headers: {
        ...(options.headers || {}),
        ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}),
        ...(options.body && typeof options.body === 'string' ? { 'Content-Type': 'application/json' } : {})
      }
    });
    const type = response.headers.get('content-type') || '';
    const data = type.includes('application/json') ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
    if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (timedOut) throw new Error(`Yêu cầu quá thời gian chờ ${Math.round(timeoutMs / 1000)} giây. Hãy kiểm tra mạng/model rồi thử lại.`);
    throw error;
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener('abort', abortFromCaller);
  }
}

function aiRequestConfigured() {
  const endpoint = String(settings.endpoint || '').trim();
  const needsKey = settings.aiMode === 'gemini' || settings.aiMode === 'anthropic' || !isLocalNoKeyEndpoint(endpoint);
  return Boolean(endpoint && String(settings.model || '').trim() && (!needsKey || String(settings.apiKey || '').trim()));
}
function providerNeedsKey(mode, endpoint) {
  return mode === 'gemini' || mode === 'anthropic' || !isLocalNoKeyEndpoint(endpoint);
}
function friendlyApiError(message) {
  const text = String(message || 'Lỗi không xác định.').trim();
  if (/API key.*(không hợp lệ|invalid|thiếu)|invalid api key|invalid_api_key|api_key_invalid|unauthorized|\b401\b/i.test(text)) return 'API key sai, hết hạn hoặc không thuộc endpoint đang chọn. Kiểm tra key ở nhà cung cấp và lưu lại; không đăng key lên GitHub.';
  if (/\b403\b|forbidden|permission|billing|not allowed/i.test(text)) return 'Nhà cung cấp từ chối quyền truy cập. Kiểm tra quyền API, billing, khu vực và quyền sử dụng model.';
  if (/\b404\b|model.*not found|unknown model|endpoint.*not found/i.test(text)) return 'Không tìm thấy model hoặc endpoint. Chọn đúng model ID và Base URL của cùng nhà cung cấp.';
  if (/\b429\b|quota|rate.?limit|resource exhausted|too many requests/i.test(text)) return 'API đã vượt quota hoặc giới hạn tốc độ. Chờ rồi thử lại, hoặc chọn model Free Tier khác.';
  if (/quá thời gian|timeout|timed out|aborterror|econn|fetch failed|network/i.test(text)) return 'Yêu cầu API quá chậm hoặc mất kết nối. Kiểm tra mạng, endpoint và backend rồi thử lại.';
  return text.slice(0, 450);
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function makeMessageId() {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch { /* Some embedded WebViews restrict crypto APIs outside secure contexts. */ }
  return `message-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function toast(message, type = '') {
  const element = $('#toast');
  if (!element) return;
  element.textContent = message;
  element.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.className = 'toast'; }, 3300);
}
function setHintSuggestion(move, source = 'Stockfish') {
  if (!move) return;
  lastHintMove = { fen: game.fen(), from: move.from, to: move.to, promotion: move.promotion || null, san: move.san, source };
  const output = $('#hintSuggestionText');
  if (output) output.textContent = `${source}: ${move.san} · ${move.from} → ${move.to}${move.promotion ? ` · phong cấp ${move.promotion.toUpperCase()}` : ''}`;
  $('#speakHint')?.removeAttribute('disabled');
  $('#useHint')?.removeAttribute('disabled');
  renderHintArrow();
}
function speakTextVietnamese(text) {
  const clean = String(text || '').trim();
  if (!clean) return;
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    toast('Thiết bị/WebView chưa hỗ trợ đọc chỉ dẫn bằng giọng nói.'); return;
  }
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = 'vi-VN'; utterance.rate = 0.94; utterance.pitch = 1;
    const voice = window.speechSynthesis.getVoices().find(item => /^vi(-|_)/i.test(item.lang));
    if (voice) utterance.voice = voice;
    utterance.onerror = () => toast('Không thể phát giọng đọc trên thiết bị này.');
    window.speechSynthesis.speak(utterance);
  } catch { toast('Không thể khởi chạy giọng đọc trên WebView này.'); }
}
function speakCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Hãy lấy gợi ý mới cho thế cờ hiện tại trước.'); return; }
  speakTextVietnamese(`Gợi ý ${lastHintMove.source}. Đi nước ${lastHintMove.san}. Di chuyển quân từ ô ${lastHintMove.from} đến ô ${lastHintMove.to}.`);
}
function applyCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Gợi ý đã cũ. Hãy tính lại ở thế cờ hiện tại.'); return; }
  if (arenaRunning || game.isGameOver() || botThinking || clockFlagged) { toast('Chưa thể áp dụng gợi ý trong trạng thái hiện tại.'); return; }
  if (mode !== 'local' && game.turn() !== humanColor) { toast('Chỉ áp dụng gợi ý khi đến lượt của bạn.'); return; }
  const move = game.moves({ verbose: true }).find(candidate => candidate.from === lastHintMove.from && candidate.to === lastHintMove.to && (candidate.promotion || null) === (lastHintMove.promotion || null));
  if (!move) { toast('Nước gợi ý không còn hợp lệ ở vị trí hiện tại.'); return; }
  playMove(move.from, move.to, move.promotion);
}
function clockPlayerName(color) {
  if (mode === 'lichess') return color === humanColor ? 'Bạn' : 'Đối thủ';
  if (mode === 'local') return color === 'w' ? 'Trắng' : 'Đen';
  return color === humanColor ? 'Bạn' : (mode === 'ai' ? 'AI qua API' : 'Stockfish');
}
function resetClock(preset = settings.clockPreset) {
  const parsed = parseClockPreset(preset);
  const enabled = parsed.enabled && mode !== 'lichess';
  clockFlagged = null;
  clockState = {
    enabled,
    running: enabled && gameStarted && !game.isGameOver() && !manualGameResult,
    remaining: { w: parsed.baseMs, b: parsed.baseMs },
    incrementMs: parsed.incrementMs,
    lastTickAt: typeof performance !== 'undefined' ? performance.now() : Date.now()
  };
  renderClockDisplay();
}
function stopClock() {
  clockState.running = false;
  renderClockDisplay();
}
function renderClockDisplay() {
  const white = $('#clockWhite');
  const black = $('#clockBlack');
  if (!white || !black) return;
  for (const [color, element] of [['w', white], ['b', black]]) {
    const value = clockState.enabled ? formatClockTime(clockState.remaining[color], true) : (mode === 'lichess' ? 'Lichess' : '∞');
    element.textContent = value;
    element.classList.toggle('is-active', clockState.enabled && clockState.running && game.turn() === color && !clockFlagged);
    element.classList.toggle('is-flagged', clockFlagged === color);
    element.setAttribute('aria-label', `${clockPlayerName(color)}: ${value}`);
  }
  const whiteName = $('#clockWhiteName');
  const blackName = $('#clockBlackName');
  if (whiteName) whiteName.textContent = clockPlayerName('w');
  if (blackName) blackName.textContent = clockPlayerName('b');
  const hint = $('#clockHint');
  if (hint) hint.textContent = clockFlagged ? `${clockPlayerName(clockFlagged)} đã hết giờ` : clockState.enabled ? `Thời gian + ${Math.round(clockState.incrementMs / 1000)} giây cộng mỗi nước` : (mode === 'lichess' ? 'Đồng hồ do Lichess quản lý' : 'Đồng hồ không giới hạn');
}
function tickClock() {
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (arenaRunning) { clockState.lastTickAt = now; return; }
  if (!clockState.enabled || !clockState.running || clockFlagged || mode === 'lichess' || game.isGameOver()) return;
  const elapsed = Math.max(0, now - clockState.lastTickAt);
  clockState.lastTickAt = now;
  const side = game.turn();
  clockState.remaining[side] = Math.max(0, clockState.remaining[side] - elapsed);
  if (clockState.remaining[side] <= 0) {
    clockFlagged = side;
    clockState.running = false;
    botThinking = false;
    cancelScheduledBotMove();
    cancelPendingHint();
    stopAnalysis(true);
    cancelMainEngineSearch();
    if (currentView === 'play') renderView();
    toast(`${clockPlayerName(side)} hết giờ. Ván cờ kết thúc.`, 'success');
    return;
  }
  renderClockDisplay();
}
function creditClockForMove(mover) {
  if (!clockState.enabled || clockFlagged) return;
  clockState.remaining[mover] += clockState.incrementMs;
  clockState.lastTickAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
  renderClockDisplay();
}
function stopAnalysis(clearResults = true) {
  const wasActive = analysisActive;
  analysisActive = false;
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  if (wasActive) {
    try { engineWorker?.postMessage('stop'); } catch {}
    try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
    if (!pendingEngineRequest && !pendingHintRequest) engineSearchActive = false;
  }
  analysisFen = '';
  analysisEpoch = -1;
  if (clearResults) analysisVariants = [];
  renderAnalysisPanel();
}
function uciPvToSan(fen, pv) {
  const clone = new Chess(fen);
  const san = [];
  for (const uci of pv) {
    try {
      const move = clone.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!move) break;
      san.push(move.san);
    } catch { break; }
  }
  return san;
}
function renderAnalysisPanel() {
  const panel = $('#analysisPanel');
  const lines = $('#analysisLines');
  const button = $('#analyzePosition');
  if (!panel || !lines) return;
  panel.hidden = !analysisActive && !analysisVariants.length;
  if (button) button.textContent = analysisActive ? '■ Dừng phân tích' : '♙ Phân tích 3 biến';
  if (analysisActive && !analysisVariants.length) {
    lines.innerHTML = '<div class="analysis-empty">Stockfish đang phân tích nhiều phương án…</div>';
    renderHintArrow();
    return;
  }
  if (!analysisVariants.length) {
    lines.innerHTML = '<div class="analysis-empty">Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.</div>';
    renderHintArrow();
    return;
  }
  const expectedFen = analysisVariants[0]?.fen || game.fen();
  lines.innerHTML = analysisVariants.sort((a, b) => a.multipv - b.multipv).map(variation => {
    const san = uciPvToSan(expectedFen, variation.pv).slice(0, 8).join(' ');
    return `<div class="analysis-line"><b>${variation.multipv}</b><strong>${esc(formatUciScore(variation))}</strong><span>Độ sâu ${variation.depth}</span><small>${esc(san || 'Đang tìm biến…')}</small></div>`;
  }).join('');
  renderHintArrow();
}
function receiveAnalysisInfo(line) {
  if (!analysisActive || analysisFen !== game.fen() || analysisEpoch !== gameEpoch) return;
  const parsed = parseUciInfoLine(line);
  if (!parsed) return;
  const record = { ...parsed, fen: analysisFen };
  const existing = analysisVariants.findIndex(item => item.multipv === record.multipv);
  if (existing === -1) analysisVariants.push(record);
  else if (record.depth >= analysisVariants[existing].depth) analysisVariants[existing] = record;
  const now = Date.now();
  if (now - analysisLastPaintAt >= 180) {
    analysisLastPaintAt = now;
    renderAnalysisPanel();
  }
}
function toggleAnalysis() {
  if (!gameStarted) { toast('Bắt đầu ván trước khi phân tích.'); return; }
  if (analysisActive) { stopAnalysis(false); toast('Đã dừng phân tích.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi phân tích bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged) { toast('Ván cờ đã kết thúc; hãy bắt đầu ván mới để phân tích tiếp.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng. Kiểm tra engine rồi thử lại.'); return; }
  if (botThinking || engineSearchActive || pendingEngineRequest || pendingHintRequest) { toast('Đợi Stockfish hoàn tất nước đi hoặc gợi ý trước khi phân tích.'); return; }
  analysisActive = true;
  analysisFen = game.fen();
  analysisEpoch = gameEpoch;
  analysisVariants = [];
  analysisLastPaintAt = 0;
  engineSearchActive = true;
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  renderAnalysisPanel();
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 3');
    engineWorker.postMessage(`position fen ${analysisFen}`);
    const budget = Math.max(1000, Math.min(8000, Number(settings.analysisMoveTimeMs) || 2600));
    engineWorker.postMessage(`go movetime ${budget}`);
    analysisTimeout = setTimeout(() => {
      if (!analysisActive) return;
      stopAnalysis(false);
      retireStockfishWorker('Stockfish không hoàn tất phân tích đúng hạn.');
      reviewStatus = 'Đã dừng phân tích vì Stockfish quá thời gian.';
      updateReviewPanel();
      toast('Stockfish quá thời gian phân tích; chạm trạng thái engine ở đầu trang để thử tải lại.');
    }, budget + 3500);
  } catch (error) {
    stopAnalysis(true);
    toast(`Không thể khởi chạy phân tích: ${error.message || error}`);
  }
}
function analyzeLocallyForCoach() {
  return new Promise((resolve, reject) => {
    if (!engineWorker || !engineReady || engineFailed) return reject(new Error('Stockfish chưa sẵn sàng. Hãy chờ trạng thái engine sẵn sàng rồi thử lại.'));
    if (botThinking || engineSearchActive || pendingEngineRequest || pendingHintRequest || analysisActive || pendingCoachAnalysis) {
      return reject(new Error('Engine đang bận. Đợi nước đi hoặc phân tích hiện tại kết thúc rồi thử lại.'));
    }
    const request = { fen: game.fen(), epoch: gameEpoch, variants: new Map(), resolve, reject, timeout: null };
    pendingCoachAnalysis = request;
    engineSearchActive = true;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    const budget = Math.max(1200, Math.min(5000, Number(settings.analysisMoveTimeMs) || 2600));
    request.timeout = setTimeout(() => {
      if (pendingCoachAnalysis !== request) return;
      pendingCoachAnalysis = null;
      engineSearchActive = false;
      retireStockfishWorker('Stockfish quá thời gian phân tích.');
      reject(new Error('Stockfish quá thời gian phân tích. Engine đã dừng để bỏ qua kết quả cũ; hãy chạm trạng thái engine để thử lại.'));
    }, budget + 3000);
    try {
      engineWorker.postMessage('stop');
      engineWorker.postMessage('setoption name MultiPV value 3');
      engineWorker.postMessage(`position fen ${request.fen}`);
      engineWorker.postMessage(`go movetime ${budget}`);
    } catch (error) {
      clearTimeout(request.timeout); pendingCoachAnalysis = null; engineSearchActive = false;
      try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
      reject(error);
    }
  });
}
function receiveCoachAnalysisInfo(line) {
  const request = pendingCoachAnalysis;
  if (!request || request.epoch !== gameEpoch || request.fen !== game.fen()) return;
  const parsed = parseUciInfoLine(line);
  if (!parsed || !parsed.pv?.length) return;
  const old = request.variants.get(parsed.multipv);
  if (!old || parsed.depth >= old.depth) request.variants.set(parsed.multipv, { ...parsed, fen: request.fen });
}
function ensureClockTicker() {
  if (clockInterval) return;
  clockInterval = setInterval(tickClock, 100);
}
function preferredHashMb() {
  const memory = Number(navigator?.deviceMemory || 0);
  // Unknown WebView memory should take the safer allocation on low-RAM phones.
  return memory >= 4 ? 32 : 16;
}
function cancelScheduledBotMove() {
  if (mainBotKickTimer) {
    clearTimeout(mainBotKickTimer);
    mainBotKickTimer = null;
  }
}
function cancelApiMoveRequest() {
  if (!apiMoveAbortController) return;
  const controller = apiMoveAbortController;
  apiMoveAbortController = null;
  try { controller.abort(); } catch {}
}
function cancelMainEngineWatchdog() {
  if (mainEngineTimer) {
    clearTimeout(mainEngineTimer);
    mainEngineTimer = null;
  }
}
function scheduleBotMove(delay = 220) {
  cancelScheduledBotMove();
  const expectedEpoch = gameEpoch;
  const expectedFen = game.fen();
  const expectedMode = mode;
  mainBotKickTimer = setTimeout(() => {
    mainBotKickTimer = null;
    if (expectedEpoch !== gameEpoch || expectedFen !== game.fen() || expectedMode !== mode ||
        !botThinking || game.isGameOver() || game.turn() === humanColor) return;
    if (expectedMode === 'stockfish') askStockfishMove();
    else if (expectedMode === 'ai') askAiMove();
  }, Math.max(0, Math.min(5000, Number(delay) || 0)));
}
function cancelPendingHint() {
  if (!pendingHintRequest) return false;
  clearTimeout(pendingHintRequest.timeout);
  pendingHintRequest = null;
  if (engineSearchActive && !pendingEngineRequest) {
    try { engineWorker?.postMessage('stop'); } catch {}
    engineSearchActive = false;
  }
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  return true;
}
function cancelMainEngineSearch() {
  cancelMainEngineWatchdog();
  if (engineSearchActive && !pendingEngineRequest) {
    try { engineWorker?.postMessage('stop'); } catch {}
    engineSearchActive = false;
  }
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
}
function setView(view) {
  currentView = view;
  $$('.tab').forEach(tab => tab.classList.toggle('active', tab.dataset.view === view));
  $('#mainMenu')?.classList.remove('menu-open');
  $('#openMenu')?.setAttribute('aria-expanded', 'false');
  renderView();
}
function pieceGlyph(piece) {
  const map = { wk: '♔', wq: '♕', wr: '♖', wb: '♗', wn: '♘', wp: '♙', bk: '♚', bq: '♛', br: '♜', bb: '♝', bn: '♞', bp: '♟' };
  return map[`${piece.color}${piece.type}`] || '';
}
function squareColor(square) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 1 ? 'dark' : 'light';
}
function syncBoardLayout() {
  const board = $('#board');
  const frame = board?.closest('.board-frame');
  const column = board?.closest('.board-column');
  if (!board || !frame || !column) return;

  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: column.getBoundingClientRect().width,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';

  // Derive piece scale from the actual inner board width rather than vw/DPI
  // heuristics; this survives Android WebView inset and split-screen changes.
  const boardWidth = board.getBoundingClientRect().width;
  const squareSize = calculateChessSquareSize(boardWidth);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function syncArenaBoardLayout() {
  const board = $('#arenaBoard');
  const frame = board?.closest('.arena-board-frame');
  const container = frame?.parentElement;
  if (!board || !frame || !container) return;
  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: container.clientWidth,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';
  const squareSize = calculateChessSquareSize(board.getBoundingClientRect().width);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function scheduleBoardLayoutSync() {
  if (boardResizeRaf) cancelAnimationFrame(boardResizeRaf);
  boardResizeRaf = requestAnimationFrame(() => { boardResizeRaf = 0; syncBoardLayout(); syncArenaBoardLayout(); });
}
function watchBoardLayout() {
  boardResizeObserver?.disconnect();
  boardResizeObserver = null;
  const column = $('.board-column');
  if (column && typeof ResizeObserver !== 'undefined') {
    boardResizeObserver = new ResizeObserver(scheduleBoardLayoutSync);
    boardResizeObserver.observe(column);
  }
  scheduleBoardLayoutSync();
}

function renderHintArrow() {
  const svg = $('#boardArrowLines');
  const overlay = $('#boardArrows');
  if (!svg || !overlay) return;
  let move = null;
  if (lastHintMove && lastHintMove.fen === game.fen()) move = lastHintMove;
  else if (analysisVariants.length && analysisVariants[0]?.fen === game.fen() && analysisVariants[0]?.pv?.length) {
    const uci = analysisVariants[0].pv[0];
    if (uci && /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) move = { from: uci.slice(0, 2), to: uci.slice(2, 4), source: 'analysis' };
  }
  if (!move) { svg.innerHTML = ''; overlay.hidden = true; return; }
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const point = square => {
    if (!/^[a-h][1-8]$/.test(String(square || ''))) return null;
    const x = files.indexOf(square[0]); const y = ranks.indexOf(Number(square[1]));
    return x < 0 || y < 0 ? null : { x: x + .5, y: y + .5 };
  };
  const a = point(move.from), b = point(move.to);
  if (!a || !b) { svg.innerHTML = ''; overlay.hidden = true; return; }
  overlay.hidden = false;
  svg.innerHTML = `<line class="hint-arrow-line ${move.source === 'analysis' ? 'analysis-arrow' : ''}" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" marker-end="url(#hintArrowHead)"/>`;
}

function canStartBoardDrag(piece) {
  return Boolean(gameStarted && !manualGameResult && piece && !arenaRunning && !game.isGameOver() && !clockFlagged && !botThinking &&
    (mode === 'local' ? piece.color === game.turn() : game.turn() === humanColor && piece.color === humanColor) && piece.color === game.turn());
}
function clearDragGhost() {
  dragGhost?.remove(); dragGhost = null;
  document.body.classList.remove('board-dragging');
}
function wireBoardPointerDrag(board) {
  if (!board || board.dataset.dragWired === 'true') return;
  board.dataset.dragWired = 'true';
  board.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    const square = event.target?.closest?.('.square[data-square]');
    if (!square) return;
    const from = square.dataset.square;
    const piece = game.get(from);
    if (!canStartBoardDrag(piece)) return;
    const legal = game.moves({ square: from, verbose: true });
    if (!legal.length) return;
    dragState = { from, pointerId: event.pointerId, x: event.clientX, y: event.clientY, moved: false, legal };
    selected = from; selectedTargets = legal;
    // Update highlights in place; do not recreate buttons while pointer capture is active.
    $$('.square', board).forEach(cell => {
      const sq = cell.dataset.square;
      cell.classList.toggle('selected', sq === from);
      const targetMoves = legal.filter(m => m.to === sq);
      cell.classList.toggle('legal-target', targetMoves.length > 0 && !game.get(sq));
      cell.classList.toggle('capture-target', targetMoves.length > 0 && Boolean(game.get(sq)));
      const dot = cell.querySelector('.move-dot');
      if (targetMoves.length && !game.get(sq) && !dot) cell.insertAdjacentHTML('beforeend', '<span class="move-dot"></span>');
      if ((!targetMoves.length || game.get(sq)) && dot) dot.remove();
    });
    try { board.setPointerCapture(event.pointerId); } catch {}
  }, { passive: true });

  board.addEventListener('pointermove', event => {
    if (!dragState || dragState.pointerId !== event.pointerId) return;
    if (!dragState.moved && Math.hypot(event.clientX - dragState.x, event.clientY - dragState.y) < 8) return;
    dragState.moved = true;
    event.preventDefault?.();
    if (!dragGhost) {
      const piece = game.get(dragState.from);
      if (!piece) return;
      dragGhost = document.createElement('span');
      dragGhost.className = `drag-ghost piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}`;
      dragGhost.textContent = pieceGlyph(piece);
      board.closest('.board-surface')?.appendChild(dragGhost);
      document.body.classList.add('board-dragging');
    }
    const surface = board.closest('.board-surface') || board;
    const rect = surface.getBoundingClientRect();
    dragGhost.style.left = `${event.clientX - rect.left}px`;
    dragGhost.style.top = `${event.clientY - rect.top}px`;
    const sourceSquare = board.querySelector(`[data-square="${dragState.from}"] .piece`);
    if (sourceSquare) sourceSquare.style.opacity = '.22';
  }, { passive: false });

  const finish = async event => {
    if (!dragState || dragState.pointerId !== event.pointerId) return;
    const state = dragState; dragState = null;
    const sourcePiece = board.querySelector(`[data-square="${state.from}"] .piece`);
    if (sourcePiece) sourcePiece.style.opacity = '';
    clearDragGhost();
    if (!state.moved) return; // Let click/tap selection path handle a simple tap.
    event.preventDefault?.();
    suppressSquareClickUntil = Date.now() + 450;
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest?.('.square[data-square]');
    const to = target?.dataset.square;
    const choices = to ? state.legal.filter(m => m.to === to) : [];
    if (!choices.length) { selected = state.from; selectedTargets = state.legal; renderBoard(); return; }
    let promotion = choices.find(m => m.promotion)?.promotion || null;
    if (choices.some(m => m.promotion)) promotion = await choosePromotion(game.turn());
    if (promotion || !choices.some(m => m.promotion)) playMove(state.from, to, promotion);
  };
  board.addEventListener('pointerup', finish, { passive: false });
  board.addEventListener('pointercancel', event => {
    if (dragState?.pointerId !== event.pointerId) return;
    dragState = null; clearDragGhost(); renderBoard();
  }, { passive: true });
}

function getGameResult() {
  if (!gameStarted) return { token: '*', title: 'Chưa bắt đầu', detail: 'Bắt đầu ván để chơi và ghi lại kết quả.' };
  if (manualGameResult) return { ...manualGameResult };
  if (clockFlagged) {
    const winner = clockFlagged === 'w' ? 'Đen' : 'Trắng';
    const token = clockFlagged === 'w' ? '0-1' : '1-0';
    return { token, title: `${winner} thắng do hết giờ`, detail: `${clockPlayerName(clockFlagged)} đã hết thời gian.` };
  }
  if (game.isCheckmate()) {
    const winner = game.turn() === 'w' ? 'Đen' : 'Trắng';
    return { token: winner === 'Trắng' ? '1-0' : '0-1', title: `Chiếu hết — ${winner} thắng`, detail: 'Vua bên thua không còn nước đi hợp lệ để thoát chiếu.' };
  }
  if (game.isStalemate()) return { token: '1/2-1/2', title: 'Hòa do hết nước đi', detail: 'Bên tới lượt không bị chiếu nhưng không có nước đi hợp lệ.' };
  if (game.isThreefoldRepetition()) return { token: '1/2-1/2', title: 'Hòa do lặp thế cờ', detail: 'Thế cờ đã lặp lại ba lần.' };
  if (game.isInsufficientMaterial()) return { token: '1/2-1/2', title: 'Hòa do không đủ quân chiếu hết', detail: 'Không còn đủ lực lượng để chiếu hết theo luật cờ.' };
  if (game.isDraw()) return { token: '1/2-1/2', title: 'Ván cờ hòa', detail: 'Ván đấu kết thúc theo luật cờ vua.' };
  return { token: '*', title: 'Ván cờ đang diễn ra', detail: '' };
}
function reviewMoveLabel(row) {
  const number = Math.ceil(row.ply / 2);
  return row.mover === 'w' ? `${number}. ${row.san}` : (row.lastWhite ? `${number}... ${row.san}` : `${number}... ${row.san}`);
}
function renderFullGameResultPanel() {
  const result = getGameResult();
  const reviewRows = completedReviewRows.slice(-160);
  const done = reviewRows.filter(row => row.ply > 0).length;
  const blunders = reviewRows.filter(row => row.judgement?.key === 'blunder').length;
  const mistakes = reviewRows.filter(row => row.judgement?.key === 'mistake').length;
  const rowHtml = reviewRows.filter(row => row.ply > 0).map(row => {
    const tone = row.judgement?.key || 'neutral';
    const evalText = Number.isFinite(row.scoreWhiteCp) ? `${row.scoreWhiteCp >= 0 ? '+' : ''}${(row.scoreWhiteCp / 100).toFixed(1)}` : '—';
    const lossText = Number.isFinite(row.lossCp) ? `−${(row.lossCp / 100).toFixed(1)}` : '—';
    return `<div class="review-move-row"><span class="review-ply">${esc(reviewMoveLabel(row))}</span><span class="review-verdict verdict-${tone}">${esc(row.judgement?.label || 'Chưa đánh giá')}</span><span class="review-eval">${evalText}</span><small>${lossText}</small></div>`;
  }).join('');
  const reviewing = Boolean(reviewSession);
  const reviewSummary = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish…`
    : reviewStatus || (done ? `Đã phân tích ${done} nửa nước · ${mistakes} sai lầm · ${blunders} blunder.` : 'Chưa phân tích ván. Bấm “Phân tích toàn ván” để đánh giá từng nửa nước bằng Stockfish nội bộ.');
  return `<section class="panel full-game-result" id="fullGameResult"><div class="panel-heading"><div><small class="eyebrow">KẾT QUẢ & ĐÁNH GIÁ</small><h2>${esc(result.title)}</h2></div><span class="result-token">${esc(result.token)}</span></div><p class="result-detail">${esc(result.detail)}</p><div class="result-stats"><span><small>Số nước</small><b>${game.history().length}</b></span><span><small>Khai cuộc</small><b>${esc(recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định')}</b></span><span><small>Engine</small><b>Stockfish</b></span></div><div class="review-progress" id="reviewProgress">${esc(reviewSummary)}</div><div class="review-move-list" id="reviewMoveAnalysis">${rowHtml || '<div class="empty-state small-empty">Khi phân tích xong, đánh giá từng nước sẽ hiện ở đây.</div>'}</div><div class="review-actions"><button id="reviewGameBtn" type="button" class="primary-btn" ${reviewing ? 'disabled' : ''}>♞ Phân tích toàn ván</button><button id="stopReviewBtn" type="button" class="secondary-btn" ${reviewing ? '' : 'disabled'}>Dừng</button><button id="reviewDownloadPGN" type="button" class="secondary-btn">Tải PGN</button><button id="explainGameBtn" type="button" class="secondary-btn">Giải thích bằng AI</button></div></section>`;
}
function updateReviewPanel() {
  const progress = $('#reviewProgress');
  const list = $('#reviewMoveAnalysis');
  if (!progress || !list) { if (currentView === 'play') renderView(); return; }
  const rows = completedReviewRows.filter(row => row.ply > 0);
  const reviewing = Boolean(reviewSession);
  progress.textContent = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish…`
    : reviewStatus || `Đã phân tích ${rows.length} nửa nước.`;
  list.innerHTML = rows.slice(-160).map(row => {
    const tone = row.judgement?.key || 'neutral';
    const score = Number.isFinite(row.scoreWhiteCp) ? `${row.scoreWhiteCp >= 0 ? '+' : ''}${(row.scoreWhiteCp / 100).toFixed(1)}` : '—';
    const loss = Number.isFinite(row.lossCp) ? `−${(row.lossCp / 100).toFixed(1)}` : '—';
    return `<div class="review-move-row"><span class="review-ply">${esc(reviewMoveLabel(row))}</span><span class="review-verdict verdict-${tone}">${esc(row.judgement?.label || 'Chưa đánh giá')}</span><span class="review-eval">${score}</span><small>${loss}</small></div>`;
  }).join('') || '<div class="empty-state small-empty">Khi phân tích xong, đánh giá từng nước sẽ hiện ở đây.</div>';
}
function stopFullGameReview(announce = false) {
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  const wasReviewing = Boolean(reviewSession);
  reviewSession = null;
  if (wasReviewing) {
    try { engineWorker?.postMessage('stop'); engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
    engineSearchActive = false;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
  }
  if (announce && wasReviewing) { reviewStatus = 'Đã dừng phân tích theo yêu cầu.'; updateReviewPanel(); }
}
function beginReviewPosition() {
  if (!reviewSession) return;
  if (reviewSession.index >= reviewSession.positions.length) {
    reviewStatus = `Hoàn tất phân tích ${completedReviewRows.filter(row => row.ply > 0).length} nửa nước.`;
    reviewSession = null;
    engineSearchActive = false;
    try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
    updateReviewPanel();
    return;
  }
  if (!engineWorker || !engineReady || engineFailed) {
    reviewStatus = 'Không thể tiếp tục: Stockfish chưa sẵn sàng.';
    reviewSession = null; engineSearchActive = false; updateReviewPanel(); return;
  }
  const position = reviewSession.positions[reviewSession.index];
  reviewSession.currentScoreWhite = null;
  reviewSession.waiting = true;
  engineSearchActive = true;
  mainEngineSearchEpoch = -3;
  mainEngineSearchFen = position.fen;
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 1');
    engineWorker.postMessage(`position fen ${position.fen}`);
    engineWorker.postMessage('go movetime 220');
    reviewSession.timeout = setTimeout(() => finishReviewPosition(true), 5000);
    updateReviewPanel();
  } catch {
    finishReviewPosition(true);
  }
}
function receiveReviewInfo(line) {
  if (!reviewSession?.waiting) return;
  const match = line.match(/\bscore\s+(cp|mate)\s+(-?\d+)/);
  if (!match) return;
  const position = reviewSession.positions[reviewSession.index];
  const turn = String(position.fen).split(/\s+/)[1] || 'w';
  reviewSession.currentScoreWhite = scoreSideToWhiteCentipawns(Number(match[2]), turn, match[1]);
}
function finishReviewPosition(timedOut = false) {
  if (!reviewSession?.waiting) return;
  const session = reviewSession;
  if (session.timeout) clearTimeout(session.timeout);
  session.timeout = null;
  session.waiting = false;
  const position = session.positions[session.index];
  const scoreWhiteCp = Number.isFinite(session.currentScoreWhite) ? session.currentScoreWhite : null;
  if (timedOut) {
    reviewStatus = `Dừng tại ${session.index}/${session.positions.length}: Stockfish không phản hồi kịp. Các kết quả đã có vẫn được giữ; chạm trạng thái engine để thử khởi tạo lại.`;
    retireStockfishWorker(reviewStatus);
    updateReviewPanel();
    return;
  }
  if (session.index === 0) {
    completedReviewRows = [{ ply: 0, san: '', mover: '', scoreWhiteCp, lossCp: null, judgement: null }];
  } else {
    const lossCp = estimateMoveLoss(session.lastScoreWhite, scoreWhiteCp, position.mover);
    completedReviewRows.push({ ply: position.ply, san: position.san, mover: position.mover, scoreWhiteCp, lossCp, judgement: lossCp == null ? null : classifyCentipawnLoss(lossCp) });
  }
  if (scoreWhiteCp != null) session.lastScoreWhite = scoreWhiteCp;
  session.index += 1;
  mainEngineSearchEpoch = -1; mainEngineSearchFen = '';
  engineSearchActive = false;
  try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
  updateReviewPanel();
  setTimeout(beginReviewPosition, 20);
}
function startFullGameReview() {
  if (!gameStarted || game.history().length < 1) { toast('Chơi ít nhất một nước rồi mới có thể phân tích toàn ván.'); return; }
  if (!game.isGameOver() && !clockFlagged && !manualGameResult) { toast('Phân tích toàn ván khả dụng sau khi trận kết thúc. Bạn vẫn có thể dùng “Phân tích 3 biến” giữa ván.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng; hãy kiểm tra tệp engine và thử lại.'); return; }
  if (arenaRunning || botThinking || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || engineSearchActive) { toast('Đợi tác vụ Stockfish hiện tại kết thúc rồi mới phân tích ván.'); return; }
  stopFullGameReview(false);
  completedReviewRows = [];
  reviewStatus = 'Đang chuẩn bị phân tích…';
  const replay = new Chess(gameStartFen);
  const history = game.history({ verbose: true });
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '' }];
  const maxPlies = Math.min(history.length, 160);
  for (let i = 0; i < maxPlies; i += 1) {
    const move = history[i];
    const made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    if (!made) { toast(`Không thể dựng lại lịch sử ở nửa nước ${i + 1}; phân tích đã hủy.`); return; }
    positions.push({ fen: replay.fen(), ply: i + 1, san: made.san, mover: made.color });
  }
  reviewSession = { positions, index: 0, rows: [], lastScoreWhite: null, currentScoreWhite: null, waiting: false, timeout: null };
  if (history.length > maxPlies) reviewStatus = 'Giới hạn phân tích ở 160 nửa nước để giữ ổn định trên điện thoại.';
  updateReviewPanel();
  beginReviewPosition();
}
function explainCompletedGame() {
  if (!gameStarted) { toast('Chưa có ván để giải thích.'); return; }
  const result = getGameResult();
  const review = completedReviewRows.filter(row => row.ply > 0).slice(-60).map(row => `${reviewMoveLabel(row)}: ${row.judgement?.label || 'chưa đánh giá'}, đánh giá ${Number.isFinite(row.scoreWhiteCp) ? (row.scoreWhiteCp / 100).toFixed(1) : '—'}`).join('\n');
  const prompt = `Hãy giải thích ván cờ đã kết thúc bằng tiếng Việt, nêu 3 thời điểm quan trọng, các lỗi lớn và cách cải thiện. Không bịa phân tích engine nếu chưa có. Kết quả: ${result.title}. PGN:\n${gamePgnWithResult().slice(-7000)}\nĐánh giá Stockfish theo từng nửa nước:\n${review || 'Chưa có phân tích Stockfish từng nước.'}`;
  setView('coach');
  setTimeout(() => {
    const input = $('#coachInput');
    if (input) input.value = '';
    // Whole-game natural-language explanation must use the configured provider,
    // even if ordinary Coach questions are currently set to local engine mode.
    void sendCoachMessage(prompt, { forceApi: true });
  }, 0);
}

function renderBoard() {
  const board = $('#board');
  if (!board) return;
  const rows = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const legalTargetSet = new Set(selectedTargets.map(move => move.to));
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = game.get(sq);
    const isLastFrom = lastMove && (lastMove.from === sq || lastMove.to === sq);
    const checkKing = game.isCheck() && piece?.type === 'k' && piece.color === game.turn();
    const isSelected = selected === sq;
    const targetMoves = selectedTargets.filter(move => move.to === sq);
    const capture = targetMoves.length && piece;
    const classes = ['square', squareColor(sq), isSelected ? 'selected' : '', legalTargetSet.has(sq) ? (capture ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-move' : '', checkKing ? 'in-check' : ''].filter(Boolean).join(' ');
    const pieceName = piece ? ({ k: 'vua', q: 'hậu', r: 'xe', b: 'tượng', n: 'mã', p: 'tốt' }[piece.type] || 'quân') : '';
    const glyph = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}" aria-hidden="true">${pieceGlyph(piece)}</span>` : '';
    const accessibleSquareLabel = `Ô ${sq}${piece ? `, ${piece.color === 'w' ? 'quân Trắng' : 'quân Đen'} ${pieceName}` : ''}${isSelected ? ', đang chọn' : ''}${legalTargetSet.has(sq) ? ', nước đi hợp lệ' : ''}`;
    // Rank labels stay on the left; every square on the bottom row gets its
    // file label. `files` is already reversed when the board is flipped.
    const coord = (colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : '') + (rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : '');
    html += `<button type="button" class="${classes}" data-square="${sq}" aria-label="${accessibleSquareLabel}">${glyph}${targetMoves.length && !capture ? '<span class="move-dot"></span>' : ''}${coord}</button>`;
  }));
  board.innerHTML = html;
  syncBoardLayout();
  $$('.square', board).forEach(square => {
    square.addEventListener('click', event => {
      if (Date.now() < suppressSquareClickUntil) { event.preventDefault(); return; }
      handleSquareClick(square.dataset.square);
    });
  });
  wireBoardPointerDrag(board);
  renderHintArrow();
  $('#boardStatus')?.replaceChildren(document.createTextNode(gameStarted ? positionStatus() : 'Sẵn sàng — nhấn Bắt đầu ván mới để chơi.'));
  const moveList = $('#moveList');
  if (moveList) renderMoveList(moveList);
  const fenBox = $('#fenText');
  if (fenBox) fenBox.textContent = game.fen();
  const pgnBox = $('#pgnText');
  if (pgnBox) pgnBox.textContent = game.pgn();
  const evalBox = $('#evalNumber');
  if (evalBox && !engineSearchActive) evalBox.textContent = '—';
  $('#turnChip')?.replaceChildren(document.createTextNode(game.turn() === 'w' ? 'Lượt Trắng' : 'Lượt Đen'));
  $('#resignBtn')?.toggleAttribute('disabled', !gameStarted || game.isGameOver() || Boolean(clockFlagged) || Boolean(manualGameResult));
  renderClockDisplay();
  renderAnalysisPanel();
}
function positionStatus(chess = game) {
  if (chess === game && clockFlagged) return `Hết giờ — ${clockPlayerName(clockFlagged)} thua`;
  if (chess.isCheckmate()) return `Chiếu hết — ${chess.turn() === 'w' ? 'Đen' : 'Trắng'} thắng`;
  if (chess.isStalemate()) return 'Hòa do hết nước đi';
  if (chess.isThreefoldRepetition()) return 'Hòa do lặp lại thế cờ';
  if (chess.isInsufficientMaterial()) return 'Hòa do không đủ quân chiếu hết';
  if (chess.isDraw()) return 'Ván cờ hòa';
  return `${chess.turn() === 'w' ? 'Trắng' : 'Đen'} đang đi${chess.isCheck() ? ' — đang bị chiếu!' : ''}`;
}
function renderMoveList(element) {
  const history = game.history();
  if (!history.length) { element.innerHTML = '<div class="empty-state">Nước đi của bạn sẽ xuất hiện ở đây.</div>'; return; }
  let rows = '';
  for (let i = 0; i < history.length; i += 2) {
    rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2) + 1}.</span><span class="move-san">${esc(history[i])}</span><span class="move-san">${esc(history[i + 1] || '…')}</span></div>`;
  }
  element.innerHTML = rows;
  element.scrollTop = element.scrollHeight;
}
function handleSquareClick(square) {
  if (!gameStarted) { toast('Nhấn “Bắt đầu ván mới” để bắt đầu trận.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (arenaRunning) { toast('Đấu trường AI đang dùng Stockfish; hãy dừng trận trước khi chơi bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged || botThinking) return;
  if (mode !== 'local' && game.turn() !== humanColor) { toast(mode === 'lichess' ? 'Đang chờ đối thủ đi.' : 'Đang đến lượt bot.'); return; }
  const piece = game.get(square);
  if (selected && selectedTargets.some(m => m.to === square)) {
    const choices = selectedTargets.filter(m => m.to === square);
    const promotion = choices.find(m => m.promotion)?.promotion;
    if (promotion) choosePromotion(game.turn()).then(type => type && playMove(selected, square, type));
    else playMove(selected, square);
    return;
  }
  if (piece && (mode === 'local' || piece.color === game.turn())) {
    selected = square;
    selectedTargets = game.moves({ square, verbose: true });
  } else {
    selected = null;
    selectedTargets = [];
  }
  renderBoard();
}
function choosePromotion(color) {
  return new Promise(resolve => {
    const root = $('#modalRoot');
    root.innerHTML = `<div class="modal-backdrop"><div class="modal-card"><h3>Phong cấp tốt</h3><p>Chọn quân muốn phong cấp.</p><div class="promotion-options">${['q','r','b','n'].map(type => `<button data-promotion="${type}" class="promotion-choice ${color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph({ color, type })}<small>${({ q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã' })[type]}</small></button>`).join('')}</div><button id="cancelPromotion" class="secondary-btn full-width">Hủy</button></div></div>`;
    $$('[data-promotion]', root).forEach(button => button.addEventListener('click', () => { root.innerHTML = ''; resolve(button.dataset.promotion); }));
    $('#cancelPromotion', root).addEventListener('click', () => { root.innerHTML = ''; resolve(null); });
  });
}
function playMove(from, to, promotion) {
  if (!gameStarted) { toast('Bắt đầu ván mới trước khi đi quân.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (clockFlagged) { toast('Ván cờ đã kết thúc do hết giờ.'); return; }
  tickClock();
  if (clockFlagged) return;
  stopAnalysis(true);
  const mover = game.turn();
  try {
    const move = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!move) return;
    playBoardSound(move, game, settings.soundEnabled);
    lastHintMove = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: move.from, to: move.to };
    selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null;
    if (mode === 'lichess') submitLichessMove(`${move.from}${move.to}${move.promotion || ''}`);
    onMoveComplete();
  } catch (error) { toast(`Nước đi không hợp lệ: ${error.message}`); }
}
function onMoveComplete() {
  renderView();
  if (game.isGameOver()) {
    botThinking = false;
    stopClock();
    const outcome = game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.';
    toast(outcome, 'success');
    return;
  }
  if (['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor) {
    if (mode === 'ai' && !aiRequestConfigured()) {
      botThinking = false;
      toast('AI qua API chưa được cấu hình đầy đủ. Hãy hoàn tất Cài đặt hoặc đổi sang Stockfish.');
      renderView();
      return;
    }
    botThinking = true;
    renderView();
    scheduleBotMove(220);
  }
  if (currentView === 'play') queryOpeningExplorer(false);
}
function resignCurrentGame() {
  if (!gameStarted || game.isGameOver() || clockFlagged || manualGameResult) return;
  if (mode === 'lichess') { toast('Đầu hàng trong ván Lichess phải thực hiện trên dịch vụ Lichess.'); return; }
  const resigning = mode === 'local' ? game.turn() : humanColor;
  const winner = resigning === 'w' ? 'Đen' : 'Trắng';
  if (typeof window.confirm === 'function' && !window.confirm(`Đầu hàng? ${winner} sẽ thắng ván này.`)) return;
  cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
  gameEpoch += 1; botThinking = false; queuedMainEngineMove = false;
  manualGameResult = {
    token: resigning === 'w' ? '0-1' : '1-0',
    title: `Đầu hàng — ${winner} thắng`,
    detail: `${resigning === 'w' ? 'Trắng' : 'Đen'} đã đầu hàng. Lịch sử nước đi được giữ nguyên để xem lại.`,
    reason: 'resignation'
  };
  stopClock(); renderView();
}

function freshGame({ startFen = null } = {}) {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi tạo ván khác.'); return; }
  if (mode === 'ai' && !aiRequestConfigured()) {
    toast('AI qua API chưa được cấu hình đầy đủ. Hãy hoàn tất Cài đặt trước khi bắt đầu ván.');
    setView('settings');
    return;
  }
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  manualGameResult = null;
  if (mode === 'lichess') mode = 'stockfish';
  stopOnlineStream();
  game = startFen ? new Chess(startFen) : new Chess();
  gameStartFen = game.fen();
  completedReviewRows = []; reviewStatus = '';
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  selected = null; selectedTargets = []; lastMove = null; lastHintMove = null; botThinking = false; currentOpening = null;
  resetClock(settings.clockPreset);
  renderView();
  if (['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true;
    scheduleBotMove(250);
  }
}
function undoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi hoàn tác.'); return; }
  if (mode === 'lichess') { toast('Không thể tự hoàn tác ván Lichess; hãy dùng chức năng takeback trên Lichess.'); return; }
  if (!game.history().length || botThinking) return;
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  game.undo();
  if (mode !== 'local' && game.history().length && game.turn() !== humanColor) game.undo();
  manualGameResult = null;
  gameEpoch += 1;
  completedReviewRows = []; reviewStatus = '';
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null; lastHintMove = null;
  resetClock(settings.clockPreset);
  renderView();
}

function updateEvaluationMeter(scoreType, scoreValue, sideToMove) {
  const fill = $('#evaluationMeterWhite');
  const meter = $('#evaluationMeter');
  if (!fill || !meter) return;
  const whiteCp = scoreSideToWhiteCentipawns(Number(scoreValue), sideToMove, scoreType);
  if (!Number.isFinite(whiteCp)) return;
  // Smoothly map centipawns to a bounded share. This is a visual cue, not win probability.
  const share = Math.max(4, Math.min(96, 50 + 46 * Math.tanh(whiteCp / 500)));
  fill.style.width = `${share.toFixed(1)}%`;
  meter.setAttribute('aria-label', `Thanh đánh giá: ${whiteCp > 0 ? 'Trắng hơn' : whiteCp < 0 ? 'Đen hơn' : 'cân bằng'}`);
}

function retireStockfishWorker(message = 'Stockfish không khả dụng.') {
  // Terminate rather than only sending `stop`: a late bestmove from a timed-out
  // search must never be mistaken for the next request's result.
  const retired = engineWorker;
  engineWorker = null;
  try { retired?.terminate(); } catch {}
  engineReady = false;
  engineFailed = true;
  engineUciInitialized = false;
  engineSearchActive = false;
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  cancelMainEngineWatchdog();
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  analysisActive = false;
  if (pendingHintRequest) { clearTimeout(pendingHintRequest.timeout); pendingHintRequest = null; }
  if (pendingEngineRequest) {
    const pending = pendingEngineRequest;
    pendingEngineRequest = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (pendingCoachAnalysis) {
    const pending = pendingCoachAnalysis;
    pendingCoachAnalysis = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  if (reviewSession) {
    reviewSession = null;
    reviewStatus = message;
    updateReviewPanel();
  }
  const status = $('#engineStatus');
  if (status) {
    status.innerHTML = '<i></i> Stockfish lỗi · chạm để tải lại';
    status.classList.remove('ready');
    status.title = message;
  }
  renderAnalysisPanel();
  console.warn('[Chess Bot] Stockfish worker retired:', message);
}

function retryStockfishEngine() {
  if (engineSearchActive || botThinking || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || reviewSession) {
    toast('Đợi tác vụ cờ hiện tại kết thúc rồi mới tải lại engine.');
    return;
  }
  if (engineWorker && engineReady && !engineFailed) {
    toast('Stockfish đã sẵn sàng.');
    return;
  }
  if (engineWorker && !engineReady && !engineFailed) {
    toast('Stockfish đang khởi tạo; chờ thêm một chút trước khi thử lại.');
    return;
  }
  retireStockfishWorker('Đang tải lại Stockfish…');
  engineFailed = false;
  const status = $('#engineStatus');
  if (status) {
    status.innerHTML = '<i></i> Đang tải Stockfish…';
    status.title = 'Đang khởi tạo engine';
  }
  initEngine();
  toast('Đang thử khởi tạo lại Stockfish…');
}

function initEngine() {
  try {
    const selectedEngine = resolveEngineProfile(settings.botEngine, { deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency });
    const engineFile = selectedEngine === 'full-single' ? 'stockfish-19-single.js' : 'stockfish-19-lite-single.js';
    const enginePath = new URL(`${import.meta.env.BASE_URL}engine/${engineFile}`, window.location.href).href;
    const worker = new Worker(enginePath);
    engineWorker = worker;
    worker.onmessage = event => {
      // A retired worker may have a queued message task; never let it mutate the
      // state or feed a result to the newly-created worker session.
      if (engineWorker !== worker) return;
      const line = typeof event.data === 'string' ? event.data : String(event.data?.data || event.data || '');
      if (line.includes('uciok') && !engineUciInitialized) {
        engineUciInitialized = true;
        engineReady = false;
        // Configure memory and threads once. Re-setting Hash before every move
        // can flush the transposition table and waste time on low-RAM phones.
        engineWorker.postMessage('setoption name Threads value 1');
        engineWorker.postMessage(`setoption name Hash value ${preferredHashMb()}`);
        engineWorker.postMessage('setoption name MultiPV value 1');
        engineWorker.postMessage('isready');
      }
      if (line.includes('readyok') && !engineFailed) {
        engineReady = true;
        const status = $('#engineStatus');
        if (status) {
          status.innerHTML = `<i></i> Stockfish ${selectedEngine === 'full-single' ? 'Full' : 'Lite'} · sẵn sàng`;
          status.classList.add('ready');
          status.title = 'Stockfish đang sẵn sàng. Chạm để kiểm tra hoặc tải lại khi gặp lỗi.';
        }
        runEngineQueue();
      }
      if (/\binfo\b/.test(line) && analysisActive) receiveAnalysisInfo(line);
      if (/\binfo\b/.test(line) && reviewSession?.waiting) receiveReviewInfo(line);
      if (/\binfo\b/.test(line) && pendingCoachAnalysis) receiveCoachAnalysisInfo(line);
      const scoreMatch = line.match(/\bscore (cp|mate) (-?\d+)/);
      if (scoreMatch && engineSearchActive && !analysisActive && !reviewSession) {
        const rawScore = Number(scoreMatch[2]);
        const whiteScore = rawScore * (game.turn() === 'b' ? -1 : 1);
        const score = scoreMatch[1] === 'mate'
          ? `${whiteScore < 0 ? '-' : ''}M${Math.abs(whiteScore)}`
          : `${whiteScore > 0 ? '+' : ''}${(whiteScore / 100).toFixed(1)}`;
        const label = $('#evalNumber');
        if (label) label.textContent = score;
        updateEvaluationMeter(scoreMatch[1], rawScore, game.turn());
      }
      const bestMatch = line.match(/\bbestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000)/i);
      if (bestMatch) {
        cancelMainEngineWatchdog();
        engineSearchActive = false;
        const uci = bestMatch[1].toLowerCase();
        if (reviewSession?.waiting) { finishReviewPosition(false); return; }
        if (pendingEngineRequest) {
          const pending = pendingEngineRequest;
          pendingEngineRequest = null;
          clearTimeout(pending.timeout);
          if (uci === '0000') pending.reject(new Error('Stockfish không trả về nước đi trong thế cờ này.'));
          else pending.resolve(uci);
          return;
        }
        if (pendingHintRequest) {
          const hint = pendingHintRequest;
          pendingHintRequest = null;
          clearTimeout(hint.timeout);
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          const resumeQueuedMainMove = queuedMainEngineMove;
          queuedMainEngineMove = false;
          if (hint.epoch === gameEpoch && hint.fen === game.fen()) {
            const move = hint.legal.find(candidate => uciForMove(candidate) === uci);
            if (move) setHintSuggestion(move, 'Stockfish');
            toast(move ? `Gợi ý Stockfish: ${move.san} (${uci})` : 'Stockfish chưa trả về được gợi ý hợp lệ.', move ? 'success' : '');
            if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
            if ($('#evalNumber')) $('#evalNumber').textContent = '—';
          }
          // A human move/new turn may have been queued while the hint search was running.
          if (resumeQueuedMainMove && botThinking && mode === 'stockfish' && !game.isGameOver() && game.turn() !== humanColor) {
            scheduleBotMove(0);
          }
          return;
        }
        if (pendingCoachAnalysis) {
          const request = pendingCoachAnalysis;
          pendingCoachAnalysis = null;
          clearTimeout(request.timeout);
          engineSearchActive = false;
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
          if (request.epoch !== gameEpoch || request.fen !== game.fen()) request.reject(new Error('Thế cờ đã thay đổi trong khi Stockfish phân tích; hãy gửi lại câu hỏi.'));
          else request.resolve([...request.variants.values()].sort((a, b) => a.multipv - b.multipv));
          return;
        }
        if (analysisActive && analysisEpoch === gameEpoch && analysisFen === game.fen()) {
          analysisActive = false;
          if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
          try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
          renderAnalysisPanel();
          return;
        }
        const searchedEpoch = mainEngineSearchEpoch;
        const searchedFen = mainEngineSearchFen;
        mainEngineSearchEpoch = -1;
        mainEngineSearchFen = '';
        // Discard stale results when the player starts a new game or changes mode during a search.
        if (searchedEpoch !== gameEpoch || !searchedFen || searchedFen !== game.fen()) {
          if (queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && game.turn() !== humanColor) {
            queuedMainEngineMove = false;
            scheduleBotMove(0);
          }
          return;
        }
        if (botThinking && mode === 'stockfish' && !game.isGameOver()) {
          botThinking = false;
          applyUciMove(uci);
        }
      }
    };
    worker.onerror = () => {
      if (engineWorker !== worker) return;
      failEngine('Không tải được tệp Stockfish. Hãy chạy npm install rồi npm run build.');
    };
    worker.postMessage('uci');
  } catch (error) { failEngine('Stockfish chưa được tải. Bot dự phòng vẫn có thể đi nước hợp lệ.'); }
}
function failEngine(message) {
  const wasThinking = botThinking && mode === 'stockfish' && !game.isGameOver();
  retireStockfishWorker(message);
  // Do not leave a human waiting forever if the engine fails during their turn.
  if (wasThinking) {
    botThinking = false;
    const move = chooseFallbackMove();
    if (move) applyUciMove(uciForMove(move));
    else renderView();
    toast('Stockfish bị lỗi; đã chuyển sang bot dự phòng với nước đi hợp lệ.');
  }
}

function runEngineQueue() {
  if (!engineWorker || !engineReady || !engineQueue.length) return;
  const next = engineQueue.shift();
  if (next) next();
}
function askStockfishMove() {
  if (mode !== 'stockfish' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  if (settings.openingBookEnabled && game.history().length < 14) {
    const bookMove = findOpeningBookMove(game, OPENINGS, { maxPlies: 14, recentChoices: recentOpeningChoices });
    if (bookMove) {
      botThinking = false;
      applyUciMove(uciForMove(bookMove));
      return;
    }
  }
  if (pendingEngineRequest) { toast('Stockfish đang xử lý một ván khác.'); return; }
  if (engineSearchActive) { queuedMainEngineMove = true; return; }
  if (!engineWorker || !engineReady || engineFailed) {
    const move = chooseFallbackMove();
    botThinking = false;
    if (move) {
      applyUciMove(uciForMove(move));
      toast('Stockfish chưa sẵn sàng — đang dùng bot dự phòng.', '');
    } else {
      renderView();
    }
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = gameEpoch;
  mainEngineSearchFen = game.fen();
  const skill = Math.max(0, Math.min(20, Number(settings.botSkill ?? 8)));
  const depth = Math.max(5, Math.min(30, Number(settings.botDepth || 18)));
  $('#boardStatus') && ($('#boardStatus').textContent = 'Stockfish đang suy nghĩ…');
  $('#evalNumber') && ($('#evalNumber').textContent = '…');
  engineWorker.postMessage('stop');
  if (settings.botStrengthMode === 'elo') {
    engineWorker.postMessage('setoption name UCI_LimitStrength value true');
    engineWorker.postMessage(`setoption name UCI_Elo value ${Math.max(1320, Math.min(3190, Number(settings.botElo) || 2600))}`);
  } else {
    engineWorker.postMessage('setoption name UCI_LimitStrength value false');
    engineWorker.postMessage(`setoption name Skill Level value ${skill}`);
  }
  engineWorker.postMessage('setoption name MultiPV value 1');
  engineWorker.postMessage(`position fen ${game.fen()}`);
  const moveTimeMs = Math.max(500, Math.min(5000, Number(settings.botMoveTimeMs) || 1200));
  engineWorker.postMessage(`go movetime ${moveTimeMs} depth ${depth}`);
  if (mainEngineTimer) clearTimeout(mainEngineTimer);
  const watchdogMs = Math.max(12000, Math.min(30000, moveTimeMs * 6));
  mainEngineTimer = setTimeout(() => {
    mainEngineTimer = null;
    if (!botThinking || mode !== 'stockfish' || pendingEngineRequest || !engineSearchActive) return;
    botThinking = false;
    retireStockfishWorker('Stockfish không phản hồi đúng hạn.');
    const fallback = chooseFallbackMove();
    if (fallback) applyUciMove(uciForMove(fallback));
    else renderView();
    toast('Stockfish không phản hồi đúng hạn; đã dùng bot dự phòng. Chạm trạng thái engine để thử tải lại.');
  }, watchdogMs);
}
function chooseFallbackMove() { return chooseFallbackMoveFor(game); }
function chooseFallbackMoveFor(chess) {
  const moves = chess.moves({ verbose: true });
  if (!moves.length) return null;
  // A small material/capture/center heuristic keeps the legal-move fallback useful, but it is not Stockfish strength.
  const values = { p: 1, n: 3.1, b: 3.3, r: 5, q: 9, k: 0 };
  const scored = moves.map(move => {
    let score = Math.random() * 1.6;
    if (move.captured) score += 2 + values[move.captured] * 0.9 - values[move.piece] * 0.1;
    if (move.san.includes('+')) score += 1.1;
    if (move.san.includes('#')) score += 500;
    if (move.promotion) score += 8;
    const file = move.to.charCodeAt(0) - 97, rank = Number(move.to[1]) - 1;
    score += (3.5 - Math.abs(3.5 - file)) * 0.07 + (3.5 - Math.abs(3.5 - rank)) * 0.07;
    return { move, score };
  }).sort((a,b) => b.score - a.score);
  return scored[Math.floor(Math.random() * Math.min(4, scored.length))]?.move || scored[0].move;
}
function applyUciMove(uci) {
  if (clockFlagged) { botThinking = false; return; }
  tickClock();
  if (clockFlagged) { botThinking = false; return; }
  const mover = game.turn();
  try {
    const from = uci.slice(0, 2), to = uci.slice(2, 4), promotion = uci[4];
    const made = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!made) throw new Error('Stockfish returned an invalid move.');
    playBoardSound(made, game, settings.soundEnabled);
    lastHintMove = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: made.from, to: made.to };
    currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening;
    botThinking = false;
    renderView();
    if (game.isGameOver()) { stopClock(); toast(game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.', 'success'); }
    else if (currentView === 'play') queryOpeningExplorer(false);
  } catch (error) { botThinking = false; toast(`Lỗi nước đi engine: ${error.message}`); renderView(); }
}
function chessUciHistory() { return game.history({ verbose: true }).map(m => `${m.from}${m.to}${m.promotion || ''}`).join(','); }

async function askAiMove() {
  if (mode !== 'ai' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const requestEpoch = gameEpoch;
  const requestedFen = game.fen();
  const legal = game.moves({ verbose: true });
  if (!legal.length) { botThinking = false; renderView(); return; }
  const moveController = new AbortController();
  apiMoveAbortController = moveController;
  const prompt = `Bạn là engine cờ vua. Chỉ chọn đúng MỘT nước trong danh sách nước hợp lệ sau, ở định dạng UCI 4 hoặc 5 ký tự (ví dụ e7e8q). Không giải thích, không Markdown. FEN: ${requestedFen}\nNước hợp lệ: ${legal.map(m => `${m.from}${m.to}${m.promotion || ''}`).join(' ')}\nHãy trả lời chỉ bằng UCI.`;
  try {
    const response = await apiFetch('/api/ai/chat', { method: 'POST', signal: moveController.signal, timeoutMs: 12_000, body: JSON.stringify({ mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: settings.model, temperature: 0, maxTokens: 16, timeoutMs: 11_000, system: 'Chỉ xuất đúng một mã UCI từ danh sách hợp lệ. Không giải thích, không Markdown.', messages: [{ role: 'user', content: prompt }] }) });
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    const uci = String(response.text || '').match(/[a-h][1-8][a-h][1-8][qrbn]?/i)?.[0]?.toLowerCase();
    const allowed = legal.some(m => `${m.from}${m.to}${m.promotion || ''}` === uci);
    if (!allowed) throw new Error('AI trả về nước không hợp lệ.');
    botThinking = false; applyUciMove(uci);
  } catch (error) {
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    botThinking = false;
    let fallbackUci = '';
    // Keep the game playable: use the real local engine when available, not a random legal move.
    try {
      if (engineWorker && engineReady && !engineFailed && !pendingEngineRequest && !engineSearchActive) {
        fallbackUci = await requestStockfishUci(requestedFen, { skill: settings.botSkill, depth: 16, moveTimeMs: 900, timeoutMs: 7000 });
      }
    } catch { /* Continue to the legal-move fallback below. */ }
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    toast(`AI API lỗi: ${friendlyApiError(error.message || error)}. ${fallbackUci ? 'Đã chuyển sang Stockfish nội bộ.' : 'Đang dùng nước hợp lệ dự phòng; đây không phải nước Stockfish tính.'}`);
    if (fallbackUci && legal.some(m => `${m.from}${m.to}${m.promotion || ''}` === fallbackUci)) applyUciMove(fallbackUci);
    else { const move = chooseFallbackMove(); if (move) applyUciMove(uciForMove(move)); else renderView(); }
  } finally {
    if (apiMoveAbortController === moveController) apiMoveAbortController = null;
  }
}

// Arena: each configured model plays by proposing one UCI move from the legal-move list.
// chess.js validates every move, while Stockfish remains the tactical engine.
function arenaCandidates() {
  const candidates = [
    { id: 'stockfish', name: 'Stockfish 19 Lite · nội bộ', type: 'stockfish' },
    { id: 'current', name: `AI hiện tại · ${settings.model || 'chưa đặt model'}`, type: 'llm', aiMode: settings.aiMode, endpoint: settings.endpoint, model: settings.model, apiKey: settings.apiKey }
  ];
  for (const profile of (Array.isArray(settings.aiProfiles) ? settings.aiProfiles : []).slice(0, 20)) {
    candidates.push({ ...profile, type: 'llm' });
  }
  return candidates;
}
function arenaPlayer(id) {
  return arenaCandidates().find(player => player.id === id) || null;
}
function renderArenaOptions(selectedId) {
  return arenaCandidates().map(player => `<option value="${esc(player.id)}" ${player.id === selectedId ? 'selected' : ''}>${esc(player.name)}${player.type === 'stockfish' ? ' · engine' : ' · API'}</option>`).join('');
}
function renderArenaProfiles() {
  const profiles = (Array.isArray(settings.aiProfiles) ? settings.aiProfiles : []).slice(0, 20);
  if (!profiles.length) return '<div class="empty-state small-empty">Chưa thêm AI riêng. Hãy thêm endpoint/model bên dưới, hoặc chọn AI hiện tại trong cài đặt.</div>';
  return profiles.map(profile => `<div class="arena-profile-row"><div class="arena-profile-avatar">✦</div><div class="arena-profile-info"><b>${esc(profile.name)}</b><small>${esc(profile.model)} · ${esc(profile.aiMode === 'gemini' ? 'Gemini' : profile.aiMode === 'anthropic' ? 'Anthropic' : 'OpenAI-compatible')}</small><small class="arena-endpoint">${esc(profile.endpoint)}</small></div><button class="mini-primary arena-test-profile" type="button" data-test-profile="${esc(profile.id)}">Kiểm tra</button><button class="tiny-btn arena-delete-profile" type="button" data-delete-profile="${esc(profile.id)}" aria-label="Xóa ${esc(profile.name)}">×</button></div>`).join('');
}
function renderArenaView() {
  const players = arenaCandidates();
  const validLeague = new Set(players.map(p => p.id));
  for (const id of [...arenaSelectedLeague]) if (!validLeague.has(id)) arenaSelectedLeague.delete(id);
  if (!arenaSelectedLeague.size) { arenaSelectedLeague.add('stockfish'); arenaSelectedLeague.add('current'); }
  const leagueChecks = players.map(player => `<label class="arena-check"><input type="checkbox" class="arena-participant-check" value="${esc(player.id)}" ${arenaSelectedLeague.has(player.id) ? 'checked' : ''}/><span><b>${esc(player.name)}</b><small>${player.type === 'stockfish' ? 'Engine cục bộ · không tốn API' : `${esc(player.aiMode === 'gemini' ? 'Gemini' : player.aiMode === 'anthropic' ? 'Anthropic' : 'API tương thích OpenAI')} · gọi API theo từng lượt`}</small></span></label>`).join('');
  return `<section class="content-page arena-page">
    <div class="page-intro"><div class="eyebrow">CHESS BOT ARENA</div><h1>Đấu trường giao lưu AI</h1><p>Cho Stockfish và nhiều mô hình AI đấu với nhau tự động. Mỗi AI nhận FEN cùng danh sách nước hợp lệ; ứng dụng xác thực nước bằng luật cờ trước khi đi. Bạn có thể ghép bất kỳ hai AI đã cấu hình, hoặc chạy một giải vòng tròn giữa các AI đã chọn.</p></div>
    <div class="arena-warning"><span>ⓘ</span><p><b>Minh bạch:</b> Stockfish là engine cờ chuyên dụng; các LLM chỉ chọn nước qua API và có thể yếu hơn, chậm hoặc trả lỗi. Chess Bot sẽ kiểm tra nước đi và dùng nước dự phòng hợp lệ nếu API hỏng. Mỗi lượt LLM có thể tiêu thụ hạn mức API.</p></div>
    <div class="arena-layout">
      <div class="arena-left">
        <section class="panel arena-board-panel"><div class="arena-live-heading"><div><small class="eyebrow">VÁN ĐANG DIỄN RA</small><h2 id="arenaMatchTitle">${esc(arenaCurrentPlayers.w?.name || 'Stockfish')} vs ${esc(arenaCurrentPlayers.b?.name || 'AI hiện tại')}</h2></div><span id="arenaLiveBadge" class="arena-live-badge ${arenaRunning ? 'is-live' : ''}">${arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'}</span></div>
          <div class="arena-board-frame"><div id="arenaBoard" class="arena-board" aria-label="Bàn cờ đấu trường AI"></div></div>
          <div class="arena-status-row"><span id="arenaStatus">${esc(arenaLastResult || positionStatus(arenaGame))}</span><b id="arenaPlyCount">${arenaGame.history().length} nửa nước đi</b></div><div id="arenaFallbackNote" class="arena-fallback-note">${esc(arenaLastNote || 'Nước đi của từng AI sẽ hiển thị tại đây.')}</div>
          <div class="arena-controls"><button id="arenaRunMatch" class="primary-btn" ${arenaRunning ? 'disabled' : ''}>▶ Đấu trận này</button><button id="arenaRunLeague" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>⚔ Giải giao lưu</button><button id="arenaStop" class="danger-btn" ${arenaRunning ? '' : 'disabled'}>■ Dừng</button></div>
          <div class="arena-controls secondary-arena-controls"><button id="arenaSwapRematch" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>⇄ Đổi màu & đấu lại</button><button id="arenaReset" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>↺ Ván mới</button><button id="arenaDownloadPGN" class="secondary-btn" ${(arenaGame.history().length || arenaPgnArchive.length) ? '' : 'disabled'}>↓ Tải PGN</button></div>
          <div id="arenaLeagueSummary" class="arena-league-summary">${esc(arenaTournamentSummary || 'Chọn các đối thủ bên phải để bắt đầu giải giao lưu.')}</div>
        </section>
        <section class="panel arena-moves-panel"><div class="panel-heading"><div><small class="eyebrow">BIÊN BẢN</small><h2>Nước đi đã xác thực</h2></div><span class="small-counter" id="arenaMoveCounter">0</span></div><div id="arenaMoveList" class="move-list arena-move-list"></div></section>
      </div>
      <div class="arena-right">
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">GHÉP CẶP</small><h2>Chọn hai đối thủ</h2></div><span class="context-icon">⚔</span></div>
          <label class="field-label" for="arenaWhite">Quân Trắng</label><select id="arenaWhite" class="field">${renderArenaOptions('stockfish')}</select>
          <label class="field-label" for="arenaBlack">Quân Đen</label><select id="arenaBlack" class="field">${renderArenaOptions('current')}</select>
          <div class="two-fields"><div><label class="field-label" for="arenaDepth">Độ sâu Stockfish</label><select id="arenaDepth" class="field">${[12,16,18,20,22,24,26,28,30].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}</option>`).join('')}</select></div><div><label class="field-label" for="arenaDelay">Khoảng nghỉ</label><select id="arenaDelay" class="field"><option value="0">Nhanh nhất</option><option value="350" selected>0,35 giây</option><option value="800">0,8 giây</option><option value="1500">1,5 giây</option></select></div></div>
          <div class="two-fields"><div><label class="field-label" for="arenaPlyLimit">Giới hạn nửa nước</label><select id="arenaPlyLimit" class="field"><option value="80">80</option><option value="120" selected>120</option><option value="180">180</option><option value="240">240</option></select></div><div><label class="field-label" for="arenaSkill">Skill Stockfish</label><select id="arenaSkill" class="field">${[10,14,18,20].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}/20</option>`).join('')}</select></div></div>
          <div class="two-fields"><div><label class="field-label" for="arenaEngineMode">Giới hạn sức mạnh</label><select id="arenaEngineMode" class="field"><option value="max" selected>Tối đa</option><option value="elo">Giới hạn Elo</option></select></div><div><label class="field-label" for="arenaEngineElo">Elo mục tiêu</label><select id="arenaEngineElo" class="field">${[1320,1500,1800,2200,2600,3000,3190].map(n=>`<option value="${n}" ${n===2600?'selected':''}>${n}</option>`).join('')}</select></div></div><div class="field-hint">Skill 20 + độ sâu cao sẽ mạnh hơn nhưng chậm hơn trên điện thoại. Chọn Tối đa để Stockfish chơi hết sức; Elo chỉ là mức giới hạn ước lượng, không phải xếp hạng được chứng nhận.</div>
        </section>
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">GIẢI VÒNG TRÒN</small><h2>Chọn những AI tham gia</h2></div><span class="small-counter">${players.length}</span></div><div class="arena-participant-list">${leagueChecks}</div><div class="field-hint">Mỗi cặp chơi hai ván và đổi màu để công bằng hơn. Tối đa 6 AI (tối đa 30 ván cho một giải); mỗi nước LLM có thể tiêu thụ API. Nếu API lỗi, nước dự phòng sẽ được đánh dấu trong kết quả.</div></section>
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">THÊM NHÀ CUNG CẤP</small><h2>Thêm AI giao lưu</h2></div><span class="context-icon">＋</span></div>
          <label class="field-label" for="arenaProfileName">Tên hiển thị</label><input id="arenaProfileName" class="field" maxlength="40" placeholder="Ví dụ: DeepSeek Chess"/>
          <label class="field-label" for="arenaProviderPreset">Nhà cung cấp nhanh</label><select id="arenaProviderPreset" class="field"><option value="custom">Endpoint tùy chỉnh</option><option value="openrouter">OpenRouter · nhiều model</option><option value="openai">OpenAI API</option><option value="anthropic">Anthropic API</option><option value="gemini">Google Gemini API</option><option value="groq">Groq</option><option value="deepseek">DeepSeek</option><option value="mistral">Mistral AI</option><option value="cerebras">Cerebras</option><option value="xai">xAI</option><option value="ollama">Ollama local</option><option value="together">Together AI</option><option value="fireworks">Fireworks AI</option></select>
          <label class="field-label" for="arenaProfileMode">Kiểu API</label><select id="arenaProfileMode" class="field"><option value="openai-compatible">OpenAI-compatible</option><option value="gemini">Google Gemini</option><option value="anthropic">Anthropic Messages API</option></select>
          <label class="field-label" for="arenaProfileEndpoint">Endpoint / Base URL</label><input id="arenaProfileEndpoint" class="field" placeholder="https://api.openai.com/v1"/>
          <label class="field-label" for="arenaProfileModel">Model ID</label><input id="arenaProfileModel" class="field" placeholder="ID chính xác từ nhà cung cấp"/>
          <label class="field-label" for="arenaProfileKey">API key</label><input id="arenaProfileKey" type="password" autocomplete="off" class="field" placeholder="Key của AI này"/>
          <div class="field-hint">Hồ sơ được lưu trên thiết bị trong localStorage để dễ dùng; đừng dùng trên máy dùng chung. Bảo vệ tốt hơn bằng backend riêng, xác thực và quota.</div>
          <button id="arenaAddProfile" class="primary-btn full-width">＋ Lưu AI vào đấu trường</button><div id="arenaProfileNotice" class="connection-result"></div>
          <div class="arena-profile-list">${renderArenaProfiles()}</div>
        </section>
      </div>
    </div>
  </section>`;
}
function renderArenaPosition() {
  const board = $('#arenaBoard');
  if (!board) return;
  const rows = [8,7,6,5,4,3,2,1], files = ['a','b','c','d','e','f','g','h'];
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = arenaGame.get(sq);
    const last = arenaLastMove && (arenaLastMove.from === sq || arenaLastMove.to === sq);
    html += `<div class="arena-square ${squareColor(sq)} ${last ? 'arena-last-move' : ''}" aria-label="${sq}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</div>`;
  }));
  board.innerHTML = html;
  syncArenaBoardLayout();
  const status = $('#arenaStatus');
  if (status) status.textContent = arenaRunning ? `${arenaCurrentPlayers[arenaGame.turn()]?.name || 'AI'} đang suy nghĩ…` : (arenaLastResult || positionStatus(arenaGame));
  const title = $('#arenaMatchTitle');
  if (title) title.textContent = `${arenaCurrentPlayers.w?.name || 'Stockfish'} vs ${arenaCurrentPlayers.b?.name || 'AI hiện tại'}`;
  const badge = $('#arenaLiveBadge');
  if (badge) { badge.textContent = arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'; badge.classList.toggle('is-live', arenaRunning); }
  const ply = $('#arenaPlyCount'); if (ply) ply.textContent = `${arenaGame.history().length} nửa nước đi`;
  const counter = $('#arenaMoveCounter'); if (counter) counter.textContent = String(arenaGame.history().length);
  const note = $('#arenaFallbackNote'); if (note) note.textContent = arenaLastNote || 'Các nước của AI sẽ hiện tại đây.';
  const moveList = $('#arenaMoveList');
  if (moveList) {
    const history = arenaGame.history();
    if (!history.length) moveList.innerHTML = '<div class="empty-state">Chưa có nước đi. Bắt đầu một trận để hai AI chơi tự động.</div>';
    else {
      let rows = '';
      for (let i = 0; i < history.length; i += 2) rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2)+1}.</span><span class="move-san">${esc(history[i])}</span><span class="move-san">${esc(history[i+1] || '…')}</span></div>`;
      moveList.innerHTML = rows; moveList.scrollTop = moveList.scrollHeight;
    }
  }
  ['arenaRunMatch','arenaRunLeague','arenaSwapRematch','arenaReset','arenaDownloadPGN'].forEach(id => { const button = $(`#${id}`); if (button) button.disabled = arenaRunning || (id === 'arenaDownloadPGN' && !arenaGame.history().length && !arenaPgnArchive.length); });
  const stop = $('#arenaStop'); if (stop) stop.disabled = !arenaRunning;
}
function wireArenaActions() {
  $('#arenaRunMatch')?.addEventListener('click', () => { unlockBoardSound(); startArenaMatch($('#arenaWhite').value, $('#arenaBlack').value); });
  $('#arenaRunLeague')?.addEventListener('click', () => { unlockBoardSound(); runArenaLeague(); });
  $('#arenaStop')?.addEventListener('click', stopArenaMatch);
  $('#arenaReset')?.addEventListener('click', () => { if (arenaRunning) return; arenaGame = new Chess(); arenaLastMove = null; arenaLastResult = ''; arenaLastNote = ''; arenaLastPgnResult = '*'; arenaPgnArchive = []; renderArenaPosition(); });
  $('#arenaSwapRematch')?.addEventListener('click', () => { if (arenaRunning) return; unlockBoardSound(); const w = $('#arenaWhite').value; $('#arenaWhite').value = $('#arenaBlack').value; $('#arenaBlack').value = w; startArenaMatch($('#arenaWhite').value, $('#arenaBlack').value); });
  $('#arenaDownloadPGN')?.addEventListener('click', downloadArenaPgn);
  $$('.arena-participant-check').forEach(input => input.addEventListener('change', () => { if (input.checked) arenaSelectedLeague.add(input.value); else arenaSelectedLeague.delete(input.value); }));
  $$('[data-test-profile]').forEach(button => button.addEventListener('click', () => testArenaProfile(button.dataset.testProfile, button)));
  $$('[data-delete-profile]').forEach(button => button.addEventListener('click', () => {
    if (arenaRunning) return;
    const id = button.dataset.deleteProfile;
    settings.aiProfiles = (settings.aiProfiles || []).filter(profile => profile.id !== id);
    arenaSelectedLeague.delete(id); const saved = saveSettings(); renderView(); toast(saved ? 'Đã xóa hồ sơ AI khỏi đấu trường.' : 'Đã xóa trong phiên hiện tại, nhưng không lưu được vào thiết bị.');
  }));
  const presets = {
    custom: null,
    openai: { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' },
    openrouter: { mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1' },
    anthropic: { mode: 'anthropic', endpoint: 'https://api.anthropic.com' },
    gemini: { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' },
    groq: { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' },
    deepseek: { mode: 'openai-compatible', endpoint: 'https://api.deepseek.com/v1' },
    mistral: { mode: 'openai-compatible', endpoint: 'https://api.mistral.ai/v1' },
    cerebras: { mode: 'openai-compatible', endpoint: 'https://api.cerebras.ai/v1' },
    xai: { mode: 'openai-compatible', endpoint: 'https://api.x.ai/v1' },
    ollama: { mode: 'openai-compatible', endpoint: 'http://localhost:11434/v1' },
    together: { mode: 'openai-compatible', endpoint: 'https://api.together.xyz/v1' },
    fireworks: { mode: 'openai-compatible', endpoint: 'https://api.fireworks.ai/inference/v1' }
  };
  $('#arenaProviderPreset')?.addEventListener('change', event => {
    const preset = presets[event.target.value]; if (!preset) return;
    $('#arenaProfileMode').value = preset.mode; $('#arenaProfileEndpoint').value = preset.endpoint;
    const labels = { openai:'OpenAI', openrouter:'OpenRouter', anthropic:'Anthropic', gemini:'Gemini', groq:'Groq', deepseek:'DeepSeek', mistral:'Mistral', cerebras:'Cerebras', xai:'xAI', ollama:'Ollama', together:'Together AI', fireworks:'Fireworks AI' };
    if (!$('#arenaProfileName').value.trim()) $('#arenaProfileName').value = labels[event.target.value] || '';
  });
  $('#arenaProfileMode')?.addEventListener('change', event => {
    if (event.target.value === 'gemini') $('#arenaProfileEndpoint').value = 'https://generativelanguage.googleapis.com';
    else if (event.target.value === 'anthropic') $('#arenaProfileEndpoint').value = 'https://api.anthropic.com';
    else if (!$('#arenaProfileEndpoint').value.trim() || ['https://generativelanguage.googleapis.com','https://api.anthropic.com'].includes($('#arenaProfileEndpoint').value.trim())) $('#arenaProfileEndpoint').value = 'https://api.openai.com/v1';
  });
  $('#arenaAddProfile')?.addEventListener('click', saveArenaProfile);
}
async function testArenaProfile(id, button) {
  const player = arenaPlayer(id);
  if (!player) return;
  const original = button?.textContent || 'Kiểm tra';
  if (button) { button.disabled = true; button.textContent = 'Đang thử…'; }
  try {
    const response = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: player.aiMode, endpoint: player.endpoint, apiKey: player.apiKey || '', model: player.model, temperature: 0, system: 'Trả lời thật ngắn.', messages: [{ role: 'user', content: 'Reply exactly: CHESS_BOT_OK' }] }) });
    toast(`${player.name}: kết nối được (${String(response.text || '').trim().slice(0, 40)})`, 'success');
  } catch (error) { toast(`${player.name}: ${String(error.message || error).slice(0, 140)}`); }
  finally { if (button) { button.disabled = false; button.textContent = original; } }
}
function saveArenaProfile() {
  if (arenaRunning) { toast('Không thể thay đổi hồ sơ trong lúc đang đấu.'); return; }
  const name = $('#arenaProfileName')?.value.trim();
  const aiMode = $('#arenaProfileMode')?.value || 'openai-compatible';
  const endpoint = $('#arenaProfileEndpoint')?.value.trim();
  const model = $('#arenaProfileModel')?.value.trim();
  const apiKey = $('#arenaProfileKey')?.value.trim() || '';
  const notice = $('#arenaProfileNotice');
  if (!name || !endpoint || !model) { if (notice) notice.textContent = 'Hãy nhập tên, endpoint và model ID.'; return; }
  if (aiMode !== 'openai-compatible' && !apiKey) { if (notice) notice.textContent = 'Nhà cung cấp này cần API key.'; return; }
  if (!isSafeHttpEndpoint(endpoint)) { if (notice) notice.textContent = 'Endpoint phải là URL HTTP(S) hợp lệ, không chứa tên đăng nhập hoặc mật khẩu.'; return; }
  const profiles = Array.isArray(settings.aiProfiles) ? settings.aiProfiles : [];
  if (profiles.length >= 20) { if (notice) notice.textContent = 'Đã đạt giới hạn 20 hồ sơ AI riêng. Hãy xóa hồ sơ không dùng trước.'; return; }
  const id = `profile-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
  settings.aiProfiles = [...profiles, { id, name, aiMode, endpoint: endpoint.replace(/\/$/, ''), model, apiKey }];
  const saved = saveSettings(); arenaSelectedLeague.add(id); renderView(); toast(saved ? `Đã thêm ${name} vào đấu trường.` : `Đã thêm ${name} trong phiên hiện tại nhưng chưa lưu được.`, saved ? 'success' : '');
}
function arenaDelay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function requestStockfishUci(fen, { skill = 20, depth = 18, strengthMode = 'max', elo = 3190, moveTimeMs = null, timeoutMs = null } = {}) {
  const effectiveMoveTimeMs = Math.max(700, Math.min(4000, Number(moveTimeMs) || Math.round(Math.max(5, Math.min(30, Number(depth) || 18)) * 75)));
  const effectiveTimeoutMs = Number(timeoutMs) || Math.max(12000, Math.min(30000, effectiveMoveTimeMs * 6));
  if (!engineWorker || engineFailed) throw new Error('Stockfish chưa sẵn sàng; kiểm tra gói engine sau npm install.');
  const readyStarted = Date.now();
  while (!engineReady && !engineFailed && Date.now() - readyStarted < 20000) await arenaDelay(100);
  if (!engineReady || engineFailed) throw new Error('Chờ Stockfish quá lâu hoặc engine lỗi.');
  if (pendingEngineRequest || engineSearchActive) throw new Error('Stockfish đang xử lý một yêu cầu khác. Hãy thử lại sau.');
  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (pendingEngineRequest?.resolve === resolve) {
        pendingEngineRequest = null;
        engineSearchActive = false;
        retireStockfishWorker('Stockfish quá thời gian suy nghĩ.');
        reject(new Error('Stockfish quá thời gian suy nghĩ; engine đã được dừng để tránh nhầm kết quả cũ.'));
      }
    }, effectiveTimeoutMs);
    pendingEngineRequest = { resolve, reject, timeout };
    engineSearchActive = true;
    engineWorker.postMessage('stop');
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strengthMode === 'elo' ? 'true' : 'false'}`);
    if (strengthMode === 'elo') engineWorker.postMessage(`setoption name UCI_Elo value ${Math.max(1320, Math.min(3190, Number(elo) || 2600))}`);
    engineWorker.postMessage(`setoption name Skill Level value ${Math.max(0, Math.min(20, Number(skill) || 20))}`);
    engineWorker.postMessage('setoption name MultiPV value 1');
    engineWorker.postMessage(`position fen ${fen}`);
    engineWorker.postMessage(`go movetime ${effectiveMoveTimeMs}`);
  });
}
function uciForMove(move) { return `${move.from}${move.to}${move.promotion || ''}`; }
async function requestModelUci(player, chess) {
  if (!player.endpoint || !player.model) throw new Error(`${player.name}: cần endpoint và model ID.`);
  if (player.aiMode !== 'openai-compatible' && !player.apiKey) throw new Error(`${player.name}: chưa có API key.`);
  const legal = chess.moves({ verbose: true });
  if (!legal.length) throw new Error('Không còn nước đi hợp lệ.');
  const legalUci = legal.map(uciForMove);
  const history = chess.history({ verbose: true }).slice(-16).map(uciForMove).join(' ');
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    if (arenaStopRequested) throw new DOMException('Đã dừng trận đấu.', 'AbortError');
    const retryHint = attempt ? '\nLần trước trả về sai định dạng. Lần này chỉ được chọn chính xác một chuỗi từ danh sách legal UCI.' : '';
    const prompt = `Bạn đang trực tiếp chơi cờ vua với vai ${chess.turn() === 'w' ? 'Trắng' : 'Đen'}. Chọn nước mạnh nhất bạn có thể tìm được.\nFEN: ${chess.fen()}\nCác nước trước đó (UCI): ${history || '(ván mới)'}\nDANH SÁCH NƯỚC HỢP LỆ UCI: ${legalUci.join(' ')}\nChỉ trả lời MỘT UCI chính xác từ danh sách, không giải thích.${retryHint}`;
    try {
      const response = await apiFetch('/api/ai/chat', {
        method: 'POST',
        signal: arenaAbortController?.signal,
        timeoutMs: 12_000, body: JSON.stringify({ mode: player.aiMode || 'openai-compatible', endpoint: player.endpoint, apiKey: player.apiKey || '', model: player.model, temperature: 0, maxTokens: 16, timeoutMs: 11_000, system: 'Chọn đúng một UCI từ danh sách. Không giải thích, không Markdown.', messages: [{ role: 'user', content: prompt }] })
      });
      const raw = String(response.text || '').replace(/```/g, '').trim().toLowerCase();
      const candidates = raw.match(/[a-h][1-8][a-h][1-8][qrbn]?/g) || [];
      const exact = candidates.find(uci => legalUci.includes(uci));
      if (exact) return exact;
      lastError = new Error(`${player.name} không trả về nước UCI hợp lệ.`);
    } catch (error) {
      if (error?.name === 'AbortError' || arenaStopRequested) throw error;
      // Network/provider errors are not retried: a second request doubles latency and may double cost.
      // Retry is reserved for a successful response that contained an invalid UCI above.
      lastError = error;
      throw error;
    }
  }
  throw lastError || new Error(`${player.name} không chọn được nước hợp lệ.`);
}
async function chooseArenaUci(player, chess, depth, skill, options = {}) {
  if (player.type === 'stockfish') {
    if (settings.openingBookEnabled && chess.history().length < 14) {
      const bookMove = findOpeningBookMove(chess, OPENINGS, { maxPlies: 14, recentChoices: recentOpeningChoices });
      if (bookMove) return uciForMove(bookMove);
    }
    return requestStockfishUci(chess.fen(), { skill, depth, moveTimeMs: Math.max(700, Math.min(2200, Number(depth || 18) * 75)), strengthMode: options.strengthMode || 'max', elo: options.elo || 2600 });
  }
  try { return await requestModelUci(player, chess); }
  catch (error) {
    if (error?.name === 'AbortError' || arenaStopRequested) throw error;
    arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
    arenaLastNote = `${player.name} gặp lỗi API (${String(error.message || error).slice(0, 110)}); Chess Bot đang dùng nước dự phòng hợp lệ.`;
    renderArenaPosition();
    if (engineReady && !engineFailed && !pendingEngineRequest && !engineSearchActive) {
      try { return await requestStockfishUci(chess.fen(), { skill: 20, depth: Math.max(18, depth) }); } catch {}
    }
    const fallback = chooseFallbackMoveFor(chess);
    if (!fallback) throw new Error('Không tìm thấy nước dự phòng.');
    return uciForMove(fallback);
  }
}
function getArenaOutcome(chess, plyLimit) {
  if (chess.isCheckmate()) return { winner: chess.turn() === 'w' ? 'b' : 'w', result: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'Chiếu hết' };
  if (chess.isDraw()) return { winner: null, result: '1/2-1/2', reason: chess.isStalemate() ? 'Hòa pat' : 'Ván hòa theo luật cờ' };
  if (chess.history().length >= plyLimit) return { winner: null, result: '1/2-1/2', reason: `Chạm giới hạn ${plyLimit} nửa nước — tạm tính hòa` };
  return null;
}
async function playArenaCore(white, black, options = {}) {
  const depth = options.depth || 20, skill = options.skill ?? 20, delayMs = options.delayMs ?? 350, plyLimit = options.plyLimit || 120;
  arenaGame = new Chess(); arenaLastMove = null; arenaLastNote = ''; arenaLastResult = '';
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  arenaCurrentPlayers = { w: white, b: black };
  renderArenaPosition();
  while (arenaRunning && !arenaStopRequested && !arenaGame.isGameOver() && arenaGame.history().length < plyLimit) {
    const player = arenaCurrentPlayers[arenaGame.turn()];
    arenaLastNote = `${player.name} đang tính nước đi…`; renderArenaPosition();
    let uci;
    try { uci = await chooseArenaUci(player, arenaGame, depth, skill, options); }
    catch (error) {
      if (arenaStopRequested || error?.name === 'AbortError') break;
      if (player.type === 'stockfish') arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
      arenaLastNote = `Lỗi ${player.name}: ${String(error.message || error).slice(0, 150)}`;
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      uci = uciForMove(fallback);
    }
    if (arenaStopRequested || !arenaRunning) break;
    const legal = arenaGame.moves({ verbose: true }).map(uciForMove);
    if (!legal.includes(uci)) {
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      arenaLastNote = `${player.name} trả nước không hợp lệ; đã thay bằng một nước hợp lệ.`;
      uci = uciForMove(fallback);
    }
    try {
      const made = arenaGame.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!made) throw new Error('Nước đi bị luật cờ từ chối.');
      arenaLastMove = { from: made.from, to: made.to };
      playBoardSound(made, arenaGame, settings.soundEnabled);
    } catch (error) {
      arenaLastNote = `Bỏ qua nước không hợp lệ: ${error.message}`;
      continue;
    }
    renderArenaPosition();
    await arenaDelay(delayMs);
  }
  if (arenaGame.isGameOver() || arenaGame.history().length >= plyLimit) {
    const outcome = getArenaOutcome(arenaGame, plyLimit) || { result: '*', reason: positionStatus(arenaGame) };
    arenaLastPgnResult = outcome.result || '*';
    archiveArenaGame(white, black, arenaLastPgnResult, outcome.reason);
    arenaLastResult = `${outcome.reason} · ${outcome.result} · ${white.name} vs ${black.name}`;
    return { ...outcome, white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn() };
  }
  arenaLastPgnResult = '*';
  if (arenaGame.history().length) archiveArenaGame(white, black, '*', 'Đã dừng');
  arenaLastResult = `Đã dừng ván tại ${arenaGame.history().length} nửa nước.`;
  return { winner: null, result: '*', reason: 'Đã dừng', white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn(), stopped: true };
}
async function startArenaMatch(whiteId, blackId) {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish ở bàn Chơi cờ kết thúc rồi mới khởi động đấu trường.'); return; }
  const white = arenaPlayer(whiteId), black = arenaPlayer(blackId);
  if (!white || !black) { toast('Không tìm thấy một trong hai AI.'); return; }
  if (white.type === 'llm' && (!white.endpoint || !white.model || (white.aiMode !== 'openai-compatible' && !white.apiKey))) { toast(`Hãy cấu hình endpoint/model/API key cho ${white.name}.`); return; }
  if (black.type === 'llm' && (!black.endpoint || !black.model || (black.aiMode !== 'openai-compatible' && !black.apiKey))) { toast(`Hãy cấu hình endpoint/model/API key cho ${black.name}.`); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController(); arenaGameCounter++; arenaFallbackMoves = new Map(); arenaPgnArchive = []; arenaLastPgnResult = '*';
  renderArenaPosition();
  try {
    const result = await playArenaCore(white, black, readArenaOptions());
    if (!result.stopped) {
      const fallbackCount = arenaFallbackMoves.get(white.id) || 0;
      const otherFallback = arenaFallbackMoves.get(black.id) || 0;
      const fallbackTag = fallbackCount + otherFallback ? ` · ${fallbackCount + otherFallback} nước dùng dự phòng khi AI lỗi` : '';
      arenaTournamentSummary = `${result.white} ${result.result} ${result.black} · ${result.reason} · ${result.plies} nửa nước${fallbackTag}`;
    }
    else arenaTournamentSummary = result.reason;
    arenaLastResult = result.reason + (result.result && result.result !== '*' ? ` · ${result.result}` : '');
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Trận lỗi: ${String(error.message || error).slice(0, 180)}`; arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function readArenaOptions() {
  return { depth: Number($('#arenaDepth')?.value || 20), skill: Number($('#arenaSkill')?.value || 20), strengthMode: $('#arenaEngineMode')?.value === 'elo' ? 'elo' : 'max', elo: Number($('#arenaEngineElo')?.value || 2600), delayMs: Number($('#arenaDelay')?.value ?? 350), plyLimit: Number($('#arenaPlyLimit')?.value || 120) };
}
function stopArenaMatch() {
  if (!arenaRunning) return;
  arenaStopRequested = true;
  arenaAbortController?.abort();
  if (pendingEngineRequest && engineWorker) { try { engineWorker.postMessage('stop'); } catch {} }
  if ($('#arenaStatus')) $('#arenaStatus').textContent = 'Đang dừng sau khi yêu cầu hiện tại kết thúc…';
}
async function runArenaLeague() {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish hiện tại kết thúc.'); return; }
  const selected = [...arenaSelectedLeague].map(arenaPlayer).filter(Boolean);
  if (selected.length < 2) { toast('Hãy chọn ít nhất hai AI tham gia giải.'); return; }
  if (selected.length > 6) { toast('Để kiểm soát chi phí API, mỗi giải giới hạn tối đa 6 AI. Bỏ chọn bớt model rồi thử lại.'); return; }
  const unconfigured = selected.find(p => p.type === 'llm' && (!p.endpoint || !p.model || (p.aiMode !== 'openai-compatible' && !p.apiKey)));
  if (unconfigured) { toast(`Hãy hoàn thiện cấu hình ${unconfigured.name} trước khi chạy giải.`); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController();
  arenaPgnArchive = []; arenaLastPgnResult = '*';
  const options = readArenaOptions();
  const scores = new Map(selected.map(player => [player.id, { id: player.id, name: player.name, points: 0, wins: 0, draws: 0, losses: 0, games: 0 }]));
  const pairings = [];
  for (let i=0;i<selected.length;i++) for (let j=i+1;j<selected.length;j++) {
    pairings.push({ a:selected[i], b:selected[j], reverse:false });
    pairings.push({ a:selected[i], b:selected[j], reverse:true });
  }
  arenaFallbackMoves = new Map();
  let complete = 0;
  arenaTournamentSummary = `Đang chạy giải: 0/${pairings.length} ván · mỗi cặp đổi màu hai lượt.`;
  renderArenaPosition();
  try {
    for (let i=0;i<pairings.length;i++) {
      if (arenaStopRequested) break;
      const { a, b, reverse } = pairings[i];
      const white = reverse ? b : a, black = reverse ? a : b;
      const result = await playArenaCore(white, black, options);
      if (result.stopped) break;
      if (result.result === '1-0') { scores.get(white.id).points += 1; scores.get(white.id).wins++; scores.get(black.id).losses++; }
      else if (result.result === '0-1') { scores.get(black.id).points += 1; scores.get(black.id).wins++; scores.get(white.id).losses++; }
      else if (result.result === '1/2-1/2') { scores.get(white.id).points += .5; scores.get(black.id).points += .5; scores.get(white.id).draws++; scores.get(black.id).draws++; }
      scores.get(white.id).games++; scores.get(black.id).games++;
      complete++;
      arenaTournamentSummary = `Giải đang chạy: ${complete}/${pairings.length} ván đã xong.`;
      if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = `${arenaTournamentSummary} ${result.white} ${result.result} ${result.black}`;
      renderArenaPosition();
      await arenaDelay(200);
    }
    const table = [...scores.values()].sort((a,b)=>b.points-a.points).map((x,i)=>`${i+1}. ${x.name}: ${x.points.toFixed(1)} điểm · ${x.wins} thắng / ${x.draws} hòa / ${x.losses} thua${arenaFallbackMoves.get(x.id) ? ` · ${arenaFallbackMoves.get(x.id)} nước dự phòng` : ''}`).join('\n');
    arenaTournamentSummary = `${arenaStopRequested ? 'Giải đã dừng' : 'KẾT QUẢ GIẢI VÒNG TRÒN'} (${complete}/${pairings.length} ván)\n${table}`;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    arenaLastResult = arenaStopRequested ? 'Giải đã dừng theo yêu cầu.' : `Giải hoàn tất · ${complete} ván.`;
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Giải gặp lỗi: ${String(error.message || error).slice(0, 180)}`;
    arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function pgnEscape(value) { return String(value || '').replace(/[\\"]+/g, '').slice(0, 120); }
function archiveArenaGame(white, black, result, reason) {
  const outcome = result || '*';
  const moves = (arenaGame.pgn() || '').trim();
  const gamePgn = moves && /(?:1-0|0-1|1\/2-1\/2|\*)$/.test(moves) ? moves : `${moves}${moves ? ' ' : ''}${outcome}`;
  const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(white?.name || 'White')}"]\n[Black "${pgnEscape(black?.name || 'Black')}"]\n[Result "${outcome}"]\n[Annotator "${pgnEscape(reason || 'AI Arena')}"]`;
  arenaPgnArchive.push(`${headers}\n\n${gamePgn}`);
}
function downloadArenaPgn() {
  const pgn = arenaPgnArchive.length ? arenaPgnArchive.join('\n\n') : (() => {
    const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(arenaCurrentPlayers.w?.name || 'White')}"]\n[Black "${pgnEscape(arenaCurrentPlayers.b?.name || 'Black')}"]\n[Result "${arenaLastPgnResult}"]\n[Annotator "${pgnEscape(arenaLastResult || 'AI Arena')}"]`;
    return `${headers}\n\n${arenaGame.pgn() || '*'}`;
  })();
  downloadTextFile(pgn, 'chess-bot-ai-arena.pgn', 'application/x-chess-pgn;charset=utf-8');
}



function renderView() {
  const root = $('#mainView');
  if (!root) return;
  if (currentView === 'play') root.innerHTML = renderPlayView();
  else if (currentView === 'openings') root.innerHTML = renderOpeningsView();
  else if (currentView === 'coach') root.innerHTML = renderCoachView();
  else if (currentView === 'arena') root.innerHTML = renderArenaView();
  else if (currentView === 'lichess') root.innerHTML = renderLichessView();
  else root.innerHTML = renderSettingsView();
  wireCommonActions();
  if (currentView === 'play') {
    renderBoard();
    watchBoardLayout();
    wirePlayActions();
  } else {
    boardResizeObserver?.disconnect();
    boardResizeObserver = null;
  }
  if (currentView === 'openings') wireOpeningActions();
  if (currentView === 'coach') wireCoachActions();
  if (currentView === 'arena') { renderArenaPosition(); wireArenaActions(); }
  if (currentView === 'lichess') wireLichessActions();
  if (currentView === 'settings') wireSettingsActions();
}
function renderPlayView() {
  const modeLabel = mode === 'stockfish' ? 'Stockfish' : mode === 'ai' ? 'AI qua API' : mode === 'lichess' ? 'Lichess trực tuyến' : 'Hai người chơi';
  const clockFace = color => `<div class="clock-face ${color === humanColor ? 'user-clock' : 'opponent-clock'}"><span id="clock${color === 'w' ? 'White' : 'Black'}Name">${esc(clockPlayerName(color))}</span><strong id="clock${color === 'w' ? 'White' : 'Black'}">${clockState.enabled ? formatClockTime(clockState.remaining[color]) : (mode === 'lichess' ? 'Lichess' : '∞')}</strong></div>`;
  const topClockColor = humanColor === 'w' ? 'b' : 'w';
  const bottomClockColor = humanColor === 'w' ? 'w' : 'b';
  return `<section class="play-layout">
    <div class="board-column">
      <div class="opponent-line"><div class="avatar">${mode === 'local' ? '♙' : mode === 'ai' ? '✦' : mode === 'lichess' ? '↗' : '♞'}</div><div class="opponent-meta"><b>${mode === 'local' ? 'Người chơi Đen / Trắng' : mode === 'ai' ? 'Chess Bot AI' : mode === 'lichess' ? `Lichess · ${esc(activeOnlineGame?.opponent || 'đối thủ trực tuyến')}` : 'Stockfish'}</b><small>${modeLabel} · ${mode === 'stockfish' ? `Skill ${settings.botSkill}/20` : mode === 'ai' ? esc(settings.model) : mode === 'lichess' ? `Ván ${esc(activeOnlineGame?.id || '')}` : 'Cùng thiết bị'}</small></div><span id="turnChip" class="turn-chip">Lượt Trắng</span></div>
      <div class="clock-face-row">${clockFace(topClockColor)}<label class="clock-setting-inline" for="clockPreset">Thời gian<select id="clockPreset" class="field">${CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${settings.clockPreset === preset.value ? 'selected' : ''}>${preset.label}</option>`).join('')}</select></label></div>
      <div class="board-frame ${!gameStarted ? 'is-prestart' : ''}"><div class="board-surface"><div id="board" class="chessboard" role="grid" aria-label="Bàn cờ vua"></div><svg id="boardArrows" class="board-arrows" viewBox="0 0 8 8" preserveAspectRatio="none" aria-hidden="true"><defs><marker id="hintArrowHead" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker></defs><g id="boardArrowLines"></g></svg>${!gameStarted ? '<div class="board-start-overlay"><span class="start-icon">♟</span><b>Sẵn sàng vào trận?</b><small>Chọn chế độ và màu quân, sau đó bắt đầu ván mới.</small><button id="startGameOverlay" type="button" class="primary-btn">▶ Bắt đầu chơi</button></div>' : ''}</div></div><div class="evaluation-meter-row" aria-label="Thanh đánh giá thế cờ"><span>TRẮNG</span><div id="evaluationMeter" class="evaluation-meter" role="img" aria-label="Lợi thế ước tính của Trắng"><span id="evaluationMeterWhite"></span></div><span>ĐEN</span></div><div class="opening-recognition" id="openingRecognition">${(recognizeOpening(game.history(), OPENINGS, { minPlies: 5 }) || (currentOpening && game.history().length >= 4 ? { name: currentOpening } : null)) ? `Khai cuộc nhận diện: ${esc((recognizeOpening(game.history(), OPENINGS, { minPlies: 5 }) || { name: currentOpening }).name)}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước')}</div>
      <div class="clock-face-row clock-bottom-row">${clockFace(bottomClockColor)}<small id="clockHint" class="clock-hint">${clockState.enabled ? `Thời gian + ${Math.round(clockState.incrementMs / 1000)} giây cộng mỗi nước` : 'Đồng hồ không giới hạn'}</small></div>
      <div class="board-bottom"><span id="boardStatus">Trắng đang đi</span><div class="board-bottom-actions"><button id="flipBoard" class="text-btn">⇅ Đảo bàn</button><button id="resignBtn" class="text-btn resign-btn" type="button" ${!gameStarted || game.isGameOver() || clockFlagged || manualGameResult ? 'disabled' : ''}>⚑ Đầu hàng</button></div></div>
      <div class="analysis-action-row"><button id="analyzePosition" class="secondary-btn">♙ Phân tích 3 biến</button><small>Stockfish · PV × 3</small></div>
      <section class="hint-card" aria-live="polite"><div class="hint-card-heading"><b>Gợi ý nước đi</b><small>Stockfish nội bộ</small></div><p id="hintSuggestionText">${lastHintMove && lastHintMove.fen === game.fen() ? `${esc(lastHintMove.source)}: ${esc(lastHintMove.san)} · ${esc(lastHintMove.from)} → ${esc(lastHintMove.to)}` : 'Nhấn “Gợi ý” để tính nước hợp lệ cho thế cờ hiện tại.'}</p><div class="hint-card-actions"><button type="button" id="speakHint" class="tiny-action-btn" ${lastHintMove && lastHintMove.fen === game.fen() ? '' : 'disabled'}>🔊 Phát chỉ dẫn</button><button type="button" id="useHint" class="tiny-action-btn" ${lastHintMove && lastHintMove.fen === game.fen() ? '' : 'disabled'}>Dùng nước này</button></div></section>
      <section id="analysisPanel" class="analysis-panel" ${analysisActive || analysisVariants.length ? '' : 'hidden'}><div class="analysis-panel-heading"><b>Phân tích Stockfish</b><span>MultiPV 3 · điểm theo Trắng</span></div><div id="analysisLines" class="analysis-lines"><div class="analysis-empty">Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.</div></div></section>
      <div class="mobile-action-row"><button class="primary-btn" id="newGame">＋ Ván mới</button><button class="secondary-btn" id="undoMove">↶ Hoàn tác</button><button class="secondary-btn" id="hintMove">✦ Gợi ý</button></div>
    </div>
    <aside class="side-column">
      <section class="panel game-setup"><div class="panel-heading"><div><small class="eyebrow">VÁN CỜ</small><h2>Thiết lập trận</h2></div><span class="live-dot"></span></div>
        <label class="field-label" for="modeSelect">Chế độ chơi</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish — chơi với máy</option><option value="ai" ${mode === 'ai' ? 'selected' : ''}>AI qua API — thử nghiệm</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người trên cùng máy</option></select>
        <div class="two-fields"><div><label class="field-label" for="colorSelect">Bạn cầm quân</label><select id="colorSelect" class="field" ${mode === 'lichess' ? 'disabled' : ''}><option value="w" ${humanColor === 'w' ? 'selected' : ''}>Trắng</option><option value="b" ${humanColor === 'b' ? 'selected' : ''}>Đen</option></select></div><div><label class="field-label" for="skillSelect">Sức mạnh bot</label><select id="skillSelect" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất · không giới hạn Elo</option><option value="1320" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 1320 ? 'selected' : ''}>Elo giới hạn 1320</option><option value="1500" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 1500 ? 'selected' : ''}>Elo giới hạn 1500</option><option value="1800" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 1800 ? 'selected' : ''}>Elo giới hạn 1800</option><option value="2200" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 2200 ? 'selected' : ''}>Elo giới hạn 2200</option><option value="2600" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 2600 ? 'selected' : ''}>Elo giới hạn 2600</option><option value="3000" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 3000 ? 'selected' : ''}>Elo giới hạn 3000</option><option value="3190" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 3190 ? 'selected' : ''}>Elo giới hạn 3190</option></select></div></div>
        <button id="newGameSetup" class="primary-btn full-width">Bắt đầu ván mới <span>→</span></button>
        <div class="stats-row"><div><small>Đánh giá</small><b id="evalNumber">—</b></div><div><small>Số nước</small><b>${game.history().length}</b></div><div><small>Trạng thái</small><b class="status-text">${!gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged) ? 'Kết thúc' : 'Đang chơi'}</b></div></div>
      </section>
      <section class="panel moves-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ</small><h2>Nước đi</h2></div><div class="panel-icons"><button class="tiny-btn" id="copyPGN" title="Sao chép PGN">⧉</button><button class="tiny-btn" id="downloadPGN" title="Tải PGN">↓</button></div></div><div id="moveList" class="move-list"></div></section>
      ${(gameStarted && (game.isGameOver() || clockFlagged || manualGameResult)) ? renderFullGameResultPanel() : ''}
      <section class="panel quick-tools"><h3>Phân tích nhanh</h3><div class="tool-grid"><button id="explainPosition" class="tool-btn"><span>✦</span><b>Giải thích</b><small>Hỏi AI về thế cờ</small></button><button id="queryExplorer" class="tool-btn"><span>⌘</span><b>Khai cuộc</b><small>Dữ liệu Lichess</small></button></div><div id="explorerResult" class="explorer-result"></div></section>
    </aside>
  </section>`;
}
function renderOpeningsView() {
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">HỌC CỜ CÓ HỆ THỐNG</div><h1>Thư viện khai cuộc</h1><p>Kho khai cuộc mở rộng với các biến mẫu để phát lại trên bàn cờ. Dữ liệu khai cuộc trực tuyến có thể tra thêm qua Lichess Opening Explorer.</p></div>
    <div class="opening-toolbar"><input id="openingSearch" class="field search-field" placeholder="Tìm tên khai cuộc, mã ECO…"/><select id="openingFilter" class="field"><option value="all">Tất cả hệ thống</option><option value="Mở e4">Khai cuộc 1.e4</option><option value="Mở d4">Khai cuộc 1.d4</option><option value="Phòng thủ">Phòng thủ</option><option value="Tấn công">Tấn công</option><option value="Mở c4">Khai cuộc 1.c4</option></select></div>
    <div id="openingGrid" class="opening-grid">${renderOpeningCards()}</div>
    <div class="note-banner"><span>✦</span><div><b>Cách dùng biến</b><p>Chọn “Xem biến” để nạp chuỗi nước đi hợp lệ lên bàn cờ. Đây là các đường mẫu để học, không phải toàn bộ biến có thể có của từng khai cuộc.</p></div></div>
  </section>`;
}
function renderOpeningCards(filter = '', family = 'all') {
  return OPENINGS.filter(o => (family === 'all' || o.family === family) && `${o.name} ${o.eco} ${o.note}`.toLowerCase().includes(filter.toLowerCase())).map((o, i) => `<article class="opening-card"><div class="opening-card-top"><span class="eco-tag">${o.eco}</span><span class="family-tag">${esc(o.family)}</span></div><h3>${esc(o.name)}</h3><p>${esc(o.note)}</p><div class="opening-line">${esc(o.line)}</div><div class="opening-card-bottom"><span>${o.san.length} nửa nước đi</span><button class="mini-primary" data-load-opening="${OPENINGS.indexOf(o)}">Xem biến ↗</button></div></article>`).join('') || '<div class="empty-state">Không tìm thấy khai cuộc phù hợp.</div>';
}
function renderCoachView() {
  return `<section class="content-page coach-page"><div class="page-intro"><div class="eyebrow">TRỢ LÝ CỜ VUA</div><h1>AI phân tích & huấn luyện</h1><p>Hỏi về vị trí hiện tại, ý tưởng chiến thuật, khai cuộc hoặc gửi một đoạn PGN. Chọn Stockfish nội bộ để phân tích không cần Internet/API, hoặc chọn model API để được giải thích bằng ngôn ngữ tự nhiên.</p></div>
    <div class="coach-source-row"><label class="field-label" for="coachEngineMode">Nguồn phân tích / trả lời</label><select id="coachEngineMode" class="field"><option value="api" ${settings.coachEngineMode === 'api' ? 'selected' : ''}>AI qua API · dùng endpoint/model/API key</option><option value="stockfish" ${settings.coachEngineMode === 'stockfish' ? 'selected' : ''}>Stockfish nội bộ · phân tích cờ, không chat tự do</option></select><small>${settings.coachEngineMode === 'stockfish' ? 'Stockfish tính điểm và biến thể nước cờ cục bộ; muốn giải thích bằng tiếng Việt hoặc hỏi kiến thức chung hãy chọn API.' : `Đang chọn ${esc(settings.model)}. Tốc độ tùy mạng, nhà cung cấp và hạn mức API.`}</small></div>
    <div class="coach-layout"><section class="panel coach-context"><div class="panel-heading"><div><small class="eyebrow">THẾ CỜ HIỆN TẠI</small><h2>Thông tin bàn cờ</h2></div><span class="context-icon">♞</span></div><div class="context-stat"><span>FEN</span><code>${esc(game.fen())}</code><button id="copyFen" class="tiny-btn">⧉</button></div><div class="context-stat"><span>PGN</span><code class="truncate-code">${esc(game.pgn() || 'Chưa có nước đi')}</code><button id="copyPgnCoach" class="tiny-btn">⧉</button></div><div class="coach-suggestions"><button data-prompt="Giải thích kế hoạch tốt nhất cho bên đang tới lượt trong thế cờ hiện tại.">Ý tưởng tốt nhất?</button><button data-prompt="Hãy chỉ ra các quân bị treo và các đòn chiến thuật trong thế cờ hiện tại.">Quân bị treo?</button><button data-prompt="Phân tích khai cuộc hiện tại, nêu nguyên tắc phát triển quân cho người mới học.">Phân tích khai cuộc</button><button data-prompt="Đưa ra kế hoạch phòng thủ an toàn cho bên đang tới lượt.">Kế hoạch phòng thủ</button></div></section>
      <section class="panel chat-panel"><div class="chat-header"><div class="avatar ai-avatar">✦</div><div><b>Chess Bot Coach</b><small>${settings.coachEngineMode === 'stockfish' ? 'Stockfish nội bộ · không gọi API' : `Đang dùng ${esc(settings.model)} · ${settings.aiMode === 'gemini' ? 'Gemini' : settings.aiMode === 'anthropic' ? 'Anthropic' : 'OpenAI-compatible'}`}</small></div><button id="clearChat" class="tiny-btn" title="Cuộc trò chuyện mới">＋</button></div><div id="chatTranscript" class="chat-transcript">${chatMessages.length ? renderChatMessages() : '<div class="welcome-chat"><div class="welcome-spark">✦</div><h3>Cùng phân tích ván cờ</h3><p>Mình sẽ giải thích bằng tiếng Việt, từng bước dễ hiểu.</p><div class="starter-prompts"><button data-prompt="Tôi mới chơi cờ. Hãy chỉ tôi 3 nguyên tắc quan trọng nhất ở khai cuộc.">Tôi mới học cờ ♟</button><button data-prompt="Dựa trên FEN hiện tại, giải thích các nước ứng viên dễ hiểu.">Giải thích vị trí này ✦</button></div></div>'}</div><form id="coachForm" class="chat-composer"><textarea id="coachInput" rows="2" placeholder="Hỏi về nước đi, chiến thuật, khai cuộc…"></textarea><button id="sendCoach" class="send-btn" type="submit" aria-label="Gửi tin nhắn" ${coachRequestActive ? 'disabled' : ''}>${coachRequestActive ? '…' : '↑'}</button></form><div class="chat-footnote">AI có thể sai; hãy kiểm tra nước đi bằng luật cờ và Stockfish.</div></section></div>
  </section>`;
}
function renderChatMessages() {
  return chatMessages.map(m => `<div class="chat-message ${m.role === 'user' ? 'user-message' : 'assistant-message'}"><div class="message-role">${m.role === 'user' ? 'Bạn' : 'Chess Bot AI'}</div><div class="message-content">${esc(m.content).replace(/\n/g, '<br>')}</div><button class="copy-message" data-copy-message="${m.id}">Sao chép</button></div>`).join('');
}
function renderLichessView() {
  const token = activeLichessToken || safeSessionGet(lichessTokenKey) || '';
  const activeLichessUrl = activeOnlineGame ? safeLichessUrl(activeOnlineGame.url, activeOnlineGame.id) : 'https://lichess.org/';
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">CHƠI TRỰC TUYẾN</div><h1>Kết nối Lichess</h1><p>Kết nối tài khoản bằng Personal Access Token. Token chỉ giữ trong phiên trình duyệt và được gửi tới backend đã cấu hình; không đưa token lên GitHub. Bot API cần tài khoản đã được nâng cấp thành Bot và đúng scope.</p></div>
    <div class="lichess-layout"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Kết nối Lichess.org</h2></div><div class="lichess-logo">♞</div></div><label class="field-label" for="lichessToken">Personal Access Token</label><input id="lichessToken" type="password" autocomplete="off" class="field" placeholder="Dán token có quyền phù hợp" value="${esc(token)}"/><div class="field-hint">Dùng quyền cần thiết cho cách chơi bạn muốn: đọc tài khoản và chơi ván cờ. Không dán token vào nơi công khai.</div><label class="field-label" for="lichessApiMode">Kiểu API chơi ván</label><select id="lichessApiMode" class="field"><option value="board">Tài khoản thông thường (Board API)</option><option value="bot">Tài khoản Lichess Bot (Bot API)</option></select><div class="field-hint">Chọn Bot API chỉ khi tài khoản đã được nâng cấp thành bot; tài khoản thường dùng Board API.</div><div class="button-row"><button id="connectLichess" class="primary-btn">Kiểm tra kết nối</button><button id="forgetLichess" class="secondary-btn">Xóa token</button></div><div id="lichessAccountResult" class="connection-result">${token ? 'Token đang lưu tạm trong phiên này; hãy kiểm tra kết nối.' : 'Chưa kết nối tài khoản.'}</div><div class="form-divider"></div><h3>Thử đấu AI của Lichess</h3><div class="two-fields"><div><label class="field-label" for="lichessLevel">Độ khó AI (1–8)</label><select id="lichessLevel" class="field">${[1,2,3,4,5,6,7,8].map(n=>`<option value="${n}" ${n===3?'selected':''}>Cấp ${n}</option>`).join('')}</select></div><div><label class="field-label" for="lichessClock">Thời gian (giây)</label><select id="lichessClock" class="field"><option value="60">1 phút</option><option value="180">3 phút</option><option value="300" selected>5 phút</option><option value="600">10 phút</option><option value="0">Không giới hạn</option></select></div></div><button id="challengeLichessAI" class="primary-btn full-width">Tạo ván với AI Lichess ↗</button><div class="form-divider"></div><h3>Thách đấu người chơi</h3><label class="field-label" for="lichessUsername">Tên người chơi Lichess</label><input id="lichessUsername" class="field" placeholder="Ví dụ: username"/><button id="challengeLichessUser" class="secondary-btn full-width">Gửi lời mời đấu ↗</button><div id="lichessChallengeResult" class="connection-result"></div></section>
    <section class="panel lichess-info"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI THỰC TẾ</small><h2>Trạng thái & hướng dẫn</h2></div><span class="online-indicator"></span></div><div class="info-row"><span class="info-icon">✓</span><div><b>Dữ liệu khai cuộc</b><p>Tra thống kê nước đi trong tab Khai cuộc qua Lichess Opening Explorer; không cần token cho truy vấn công khai.</p></div></div><div class="info-row"><span class="info-icon">↗</span><div><b>Ván trực tuyến</b><p>Sau khi gửi thử thách, mở trang ván trên Lichess để chấp nhận/chơi. Đồng bộ nước đi trong ứng dụng cần token, đúng API scope và backend có thể truy cập Lichess.</p></div></div><div class="info-row"><span class="info-icon">!</span><div><b>Bot Lichess không giống AI Stockfish nội bộ</b><p>API Bot chỉ hoạt động với tài khoản bot đủ điều kiện. Không dùng tài khoản thường để tự động hóa qua Bot API.</p></div></div><a class="external-link" href="https://lichess.org/account/oauth/token" target="_blank" rel="noopener noreferrer">Mở trang quản lý token ↗</a><a class="external-link" href="https://lichess-org.github.io/api/" target="_blank" rel="noopener noreferrer">Tài liệu API chính thức ↗</a><div id="lichessActiveGame" class="active-game-card">${activeOnlineGame ? `Ván vừa tạo: <b>${esc(activeOnlineGame.id || '')}</b><br><a href="${esc(activeLichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a><br><button id="playLichessHere" class="mini-primary">Kết nối ván trong Chess Bot</button>` : 'Chưa tạo ván nào trong phiên này.'}</div></section></div>
  </section>`;
}
function renderSettingsView() {
  return `<section class="content-page settings-page"><div class="page-intro"><div class="eyebrow">CẤU HÌNH ỨNG DỤNG</div><h1>AI, engine & máy chủ</h1><p>Không có một endpoint chung cho mọi AI. Hãy chọn API tương thích OpenAI, Google Gemini hoặc Anthropic và nhập endpoint/model theo nhà cung cấp. API key được lưu trên thiết bị này; không đưa vào kho mã nguồn. Google AI Studio, Groq và một số model OpenRouter có thể có hạn mức miễn phí tùy gói/tài khoản. Ứng dụng chỉ gắn nhãn Free khi API trả tín hiệu miễn phí rõ ràng; hãy kiểm tra giá và giới hạn trước khi dùng.</p></div>
    <div class="settings-layout"><section class="panel settings-panel"><div class="panel-heading"><div><small class="eyebrow">AI PROVIDER</small><h2>Kết nối mô hình ngôn ngữ</h2></div><span class="context-icon">✦</span></div><label class="field-label" for="freeModelPreset">Model miễn phí chọn sẵn (không cần tải danh sách)</label><select id="freeModelPreset" class="field"><option value="">Chọn model free tier tích hợp sẵn…</option>${BUILTIN_FREE_MODEL_PRESETS.map(item => `<option value="${esc(item.key)}">${esc(item.label)}</option>`).join('')}</select><div class="field-hint">Danh sách gọn đã được đóng gói trong ứng dụng, không cần tải catalog trước. Cần tự nhập API key của nhà cung cấp; ứng dụng không chứa key miễn phí dùng chung.</div><label class="field-label" for="providerPreset">Chọn nhanh nhà cung cấp</label><select id="providerPreset" class="field"><option value="custom">Custom endpoint</option><option value="openai">OpenAI API</option><option value="openrouter">OpenRouter · nhiều model</option><option value="anthropic">Anthropic API</option><option value="groq">Groq</option><option value="deepseek">DeepSeek</option><option value="together">Together AI</option><option value="mistral">Mistral AI</option><option value="fireworks">Fireworks AI</option><option value="cerebras">Cerebras</option><option value="xai">xAI</option><option value="ollama">Ollama local</option><option value="gemini">Google Gemini API</option></select><div class="field-hint">Chọn nhanh URL nền. Tên model và quyền truy cập vẫn phải đúng theo tài khoản/nhà cung cấp.</div><label class="field-label" for="aiMode">Kiểu API</label><select id="aiMode" class="field"><option value="openai-compatible" ${settings.aiMode === 'openai-compatible' ? 'selected' : ''}>OpenAI-compatible (OpenAI, OpenRouter, Groq, DeepSeek, Together, Cerebras, xAI, Ollama…)</option><option value="gemini" ${settings.aiMode === 'gemini' ? 'selected' : ''}>Google Gemini API</option><option value="anthropic" ${settings.aiMode === 'anthropic' ? 'selected' : ''}>Anthropic Messages API</option></select><label class="field-label" for="apiEndpoint">Endpoint / Base URL</label><input id="apiEndpoint" class="field" value="${esc(settings.endpoint)}" placeholder="https://api.openai.com/v1"/><div class="field-hint">Ví dụ Ollama: http://localhost:11434/v1. API cần được nhà cung cấp cho phép gọi từ máy chủ đã cài đặt.</div><label class="field-label" for="apiModel">Model ID</label><div class="model-picker-row"><input id="apiModel" class="field" list="apiModelSuggestions" value="${esc(settings.model)}" placeholder="Bấm tải danh sách hoặc nhập Model ID"/><datalist id="apiModelSuggestions"></datalist><button id="loadModels" type="button" class="secondary-btn">Tải model</button></div><select id="apiModelList" class="field model-list-select" aria-label="Danh sách model từ nhà cung cấp"><option value="">Model chọn nhanh và model đã tải sẽ xuất hiện ở đây</option></select><label class="free-model-filter"><input id="freeModelsOnly" type="checkbox"/> Chỉ hiện model có Free Tier/giá 0 được công bố</label><div class="field-hint">Huy hiệu FREE TIER dựa trên ID :free/giá 0 trong catalog hoặc danh sách Free Tier chính thức cho một số model Gemini/Groq. Hạn mức và điều kiện áp dụng phụ thuộc tài khoản, khu vực và billing; xác minh tại trang chính thức: <a href="https://openrouter.ai/models" target="_blank" rel="noopener noreferrer">OpenRouter catalog</a> · <a href="https://console.groq.com/docs/rate-limits" target="_blank" rel="noopener noreferrer">Groq Free Plan limits</a> · <a href="https://ai.google.dev/gemini-api/docs/pricing" target="_blank" rel="noopener noreferrer">Gemini pricing/free tier</a>.</div><label class="field-label" for="apiKey">API key</label><div class="secret-input"><input id="apiKey" type="password" class="field" autocomplete="off" value="${esc(settings.apiKey)}" placeholder="Dán API key tại đây"/><button id="toggleApiKey" type="button" class="tiny-btn">Hiện</button></div><div class="field-hint">Không chia sẻ ảnh chụp màn hình có API key. Nếu từng lộ key, hãy thu hồi và tạo key mới.</div><div class="form-divider"></div><label class="field-label" for="botEngineSetting">Engine Stockfish</label><select id="botEngineSetting" class="field"><option value="auto" ${!['lite-single','full-single'].includes(settings.botEngine) ? 'selected' : ''}>Tự động theo thiết bị · khuyến nghị</option><option value="lite-single" ${settings.botEngine === 'lite-single' ? 'selected' : ''}>Lite Single · nhẹ, phù hợp điện thoại</option><option value="full-single" ${settings.botEngine === 'full-single' ? 'selected' : ''}>Full Single · mạnh hơn, tải khoảng 94 MB</option></select><div class="field-hint">Tự động chọn Full khi trình duyệt báo ít nhất 6 GB RAM và 6 luồng CPU; nếu thiếu thông tin hoặc thiết bị yếu, dùng Lite để giảm nguy cơ chậm/nóng. Bản Single không dùng đa luồng UCI; Lite tải nhanh hơn nhiều.</div><div class="two-fields"><div><label class="field-label" for="botSkillSetting">Stockfish Skill (0–20)</label><input id="botSkillSetting" type="number" class="field" min="0" max="20" value="${Number(settings.botSkill)}"/></div><div><label class="field-label" for="botDepthSetting">Độ sâu tối đa (5–30)</label><input id="botDepthSetting" type="number" class="field" min="5" max="30" value="${Number(settings.botDepth)}"/></div></div><div class="two-fields"><div><label class="field-label" for="botMoveTimeSetting">Thời gian mỗi nước (ms)</label><input id="botMoveTimeSetting" type="number" class="field" min="500" max="5000" step="100" value="${Number(settings.botMoveTimeMs)}"/></div><div><label class="field-label" for="analysisMoveTimeSetting">Phân tích 3 biến (ms)</label><input id="analysisMoveTimeSetting" type="number" class="field" min="1000" max="8000" step="100" value="${Number(settings.analysisMoveTimeMs)}"/></div></div><div class="field-hint">Thời gian mỗi nước là giới hạn thực tế để tránh chờ depth cố định lâu trên điện thoại; tăng thời gian để tìm nước mạnh hơn nhưng máy sẽ phân tích lâu hơn.</div><div class="preference-grid"><label class="preference-toggle"><input id="openingBookEnabledSetting" type="checkbox" ${settings.openingBookEnabled ? 'checked' : ''}/><span><b>Đa dạng khai cuộc</b><small>Chọn ngẫu nhiên có trọng số trong kho khai cuộc hợp lệ; Stockfish sẽ tiếp quản khi hết nhánh.</small></span></label><label class="preference-toggle"><input id="soundEnabledSetting" type="checkbox" ${settings.soundEnabled ? 'checked' : ''}/><span><b>Âm thanh bàn cờ</b><small>Tiếng đi quân, ăn quân và chiếu/chiếu hết; âm thanh tổng hợp, không tải nhạc ngoài.</small></span></label></div><div class="two-fields"><div><label class="field-label" for="botStrengthModeSetting">Chế độ sức mạnh</label><select id="botStrengthModeSetting" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Tối đa (không giới hạn Elo)</option><option value="elo" ${settings.botStrengthMode === 'elo' ? 'selected' : ''}>Giới hạn Elo</option></select></div><div><label class="field-label" for="botEloSetting">Elo giới hạn (1320–3190)</label><input id="botEloSetting" type="number" class="field" min="1320" max="3190" step="10" value="${Number(settings.botElo || 2600)}"/></div></div><label class="field-label" for="backendUrl">API backend URL (để trống khi chạy cùng máy)</label><input id="backendUrl" class="field" value="${esc(settings.backendUrl)}" placeholder="https://api-cua-ban.example"/><label class="field-label" for="backendAccessToken">Mã truy cập backend (nếu máy chủ yêu cầu)</label><input id="backendAccessToken" type="password" autocomplete="off" class="field" value="${esc(settings.backendAccessToken)}" placeholder="Không bắt buộc khi backend chạy cục bộ"/><div class="field-hint">Khi đóng gói APK, AI/Lichess cần backend được triển khai có HTTPS. Chơi cờ và engine được đóng gói có thể chạy cục bộ.</div><div class="button-row"><button id="saveSettings" class="primary-btn">Lưu cấu hình</button><button id="testAI" class="secondary-btn">Kiểm tra AI</button></div><div id="settingsTestResult" class="connection-result"></div></section>
    <aside class="panel settings-about"><div class="panel-heading"><div><small class="eyebrow">CHESS BOT ENGINE</small><h2>Thông tin hệ thống</h2></div></div><div class="brand-showcase"><img src="./chess-bot-logo.webp" alt="Logo Chess Bot" loading="lazy" decoding="async" /></div><div class="info-row"><span class="info-icon">♞</span><div><b>Stockfish 19 · tự chọn Lite/Full</b><p>Engine UCI chạy trong Web Worker. Chế độ tự động dùng Full khi navigator báo ít nhất 6 GB RAM và 6 luồng CPU; nếu không, chọn Lite. Có thể chọn thủ công trong cài đặt. Độ sâu đến 30 có thể tốn thời gian và pin; engine cần các tệp JS/WASM được copy khi cài dependencies.</p></div></div><div class="info-row"><span class="info-icon">♟</span><div><b>Luật cờ tiêu chuẩn</b><p>Được kiểm tra bởi chess.js: nước hợp lệ, nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hòa và lặp thế cờ.</p></div></div><div class="info-row"><span class="info-icon">⌘</span><div><b>Kho khai cuộc</b><p>${OPENINGS.length} đường khai cuộc mẫu kèm mã ECO tham khảo và tích hợp Opening Explorer.</p></div></div><div class="info-row"><span class="info-icon">🔐</span><div><b>Bảo vệ khóa</b><p>Khóa không được đóng cứng vào mã. Trình duyệt lưu cài đặt cục bộ; khi triển khai công khai cần cấu hình xác thực, giới hạn truy cập và HTTPS cho backend.</p></div></div><div class="license-note"><b>Giấy phép thư viện</b><p>chess.js theo BSD-2-Clause. Stockfish theo GPL-3.0; xem giấy phép và thông báo bản quyền đi kèm bản phân phối Stockfish trước khi phát hành.</p></div><button id="resetSettings" class="danger-btn full-width">Đặt lại cài đặt AI</button></aside></div>
  </section>`;
}

function wireCommonActions() {
  // Global navigation listeners are attached once during boot; the views below are re-rendered.
}
function startGameFromSetup() {
  unlockBoardSound();
  const selectedMode = $('#modeSelect')?.value || mode;
  if (selectedMode === 'ai' && !aiRequestConfigured()) {
    toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt trước.');
    setView('settings');
    return;
  }
  if (selectedMode === 'lichess') {
    if (!activeOnlineGame?.id) {
      toast('Hãy kết nối Lichess và tạo ván trực tuyến trước.');
      setView('lichess');
      return;
    }
    mode = 'lichess';
    startOnlinePlay();
    return;
  }
  mode = selectedMode;
  humanColor = $('#colorSelect')?.value === 'b' ? 'b' : 'w';
  orientation = humanColor;
  freshGame();
}

function wirePlayActions() {
  const modeSelect = $('#modeSelect');
  modeSelect?.addEventListener('change', () => {
    const chosen = modeSelect.value;
    if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi đổi chế độ bàn cờ.'); modeSelect.value = mode; return; }
    if (chosen === 'ai' && !aiRequestConfigured()) {
      modeSelect.value = mode;
      toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt trước khi chọn AI qua API.');
      setView('settings');
      return;
    }
    if ((mode === 'lichess' && chosen !== 'lichess') || (chosen === 'lichess' && !activeOnlineGame?.id)) stopOnlineStream();
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    if (chosen === 'lichess' && !activeOnlineGame?.id) {
      toast('Kết nối Lichess và tạo ván trước.'); mode = 'stockfish'; modeSelect.value = mode;
    } else {
      const previousMode = mode;
      mode = chosen;
      if (mode === 'lichess') {
        gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
        resetClock('untimed');
        startOnlinePlay(); return;
      }
      if (previousMode === 'lichess') resetClock(settings.clockPreset);
    }
    gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
    if (mode === 'ai' && !aiRequestConfigured()) toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt.');
    renderView();
    if (gameStarted && ['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor && !(mode === 'ai' && !aiRequestConfigured())) {
      botThinking = true; renderView();
      scheduleBotMove(220);
    }
  });
  $('#colorSelect')?.addEventListener('change', event => {
    if (mode === 'lichess') { toast('Màu quân trong ván Lichess do Lichess quyết định.'); renderView(); return; }
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    humanColor = event.target.value;
    orientation = humanColor;
    gameEpoch += 1; // Invalidate any engine result calculated for the old player-to-move setup.
    queuedMainEngineMove = false;
    botThinking = false;
    renderView();
    if (gameStarted && ['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor && !game.isGameOver()) {
      if (mode === 'ai' && !aiRequestConfigured()) {
        toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt trước khi bot đi.')
        return;
      }
      botThinking = true;
      renderView();
      scheduleBotMove(220);
    }
  });
  $('#skillSelect')?.addEventListener('change', event => {
    const value = event.target.value;
    if (value === 'max') { settings.botStrengthMode = 'max'; settings.botSkill = 20; }
    else { settings.botStrengthMode = 'elo'; settings.botElo = Math.max(1320, Math.min(3190, Number(value) || 2600)); settings.botSkill = 20; }
    const saved = saveSettings(); toast(saved ? (settings.botStrengthMode === 'max' ? 'Stockfish đang ở sức mạnh tối đa.' : `Đã giới hạn Stockfish ở khoảng Elo ${settings.botElo}.`) : 'Cấu hình có hiệu lực trong phiên này nhưng chưa lưu được.');
  });
  $('#newGame')?.addEventListener('click', () => freshGame());
  $('#resignBtn')?.addEventListener('click', resignCurrentGame);
  $('#startGameOverlay')?.addEventListener('click', startGameFromSetup);
  $('#reviewGameBtn')?.addEventListener('click', startFullGameReview);
  $('#stopReviewBtn')?.addEventListener('click', () => stopFullGameReview(true));
  $('#clockPreset')?.addEventListener('change', event => {
    const nextPreset = parseClockPreset(event.target.value).preset;
    settings.clockPreset = nextPreset;
    saveSettings();
    toast(`Đã chọn ${CLOCK_PRESETS.find(item => item.value === nextPreset)?.label || nextPreset}. Đồng hồ áp dụng từ ván mới.`);
  });
  $('#newGameSetup')?.addEventListener('click', startGameFromSetup);
  $('#undoMove')?.addEventListener('click', undoMove);
  $('#analyzePosition')?.addEventListener('click', toggleAnalysis);
  $('#flipBoard')?.addEventListener('click', () => { orientation = orientation === 'w' ? 'b' : 'w'; renderBoard(); });
  $('#hintMove')?.addEventListener('click', requestHint);
  $('#speakHint')?.addEventListener('click', speakCurrentHint);
  $('#useHint')?.addEventListener('click', applyCurrentHint);
  $('#copyPGN')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
  $('#downloadPGN')?.addEventListener('click', downloadPgn);
  $('#reviewDownloadPGN')?.addEventListener('click', downloadPgn);
  $('#explainGameBtn')?.addEventListener('click', explainCompletedGame);
  $('#explainPosition')?.addEventListener('click', () => { setView('coach'); setTimeout(() => { $('#coachInput') && ($('#coachInput').value = 'Phân tích thế cờ hiện tại của tôi: điểm mạnh, điểm yếu và kế hoạch đơn giản nhất.'); $('#coachInput')?.focus(); }, 0); });
  $('#queryExplorer')?.addEventListener('click', () => queryOpeningExplorer(true));
}
function wireOpeningActions() {
  const update = () => { $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch').value, $('#openingFilter').value); wireOpeningButtons(); };
  $('#openingSearch')?.addEventListener('input', update);
  $('#openingFilter')?.addEventListener('change', update);
  wireOpeningButtons();
}
function wireOpeningButtons() {
  $$('[data-load-opening]').forEach(button => button.addEventListener('click', () => loadOpening(Number(button.dataset.loadOpening))));
}
function loadOpening(index) {
  const opening = OPENINGS[index];
  if (!opening) return;
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi nạp khai cuộc.'); return; }
  if (!Array.isArray(opening.san) || opening.san.length === 0) {
    toast(`Biến ${opening.name || 'khai cuộc'} chưa có danh sách nước đi hợp lệ. Ván hiện tại vẫn được giữ nguyên.`);
    return;
  }

  // Validate the whole line on a temporary board before touching the active game.
  // A malformed catalogue item must never leave the player with a partial opening.
  const candidateGame = new Chess();
  for (let ply = 0; ply < opening.san.length; ply += 1) {
    const san = opening.san[ply];
    try {
      candidateGame.move(san);
    } catch (error) {
      console.error('Rejected invalid opening line:', opening.name, `ply ${ply + 1}`, san, error);
      toast(`Biến ${opening.name} có nước không hợp lệ (${san}). Ván hiện tại vẫn được giữ nguyên.`);
      return;
    }
  }

  if (mode === 'lichess') stopOnlineStream();
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  game = candidateGame;
  gameStartFen = new Chess().fen();
  manualGameResult = null;
  completedReviewRows = []; reviewStatus = '';
  currentOpening = opening.name;
  lastHintMove = null;
  mode = 'local';
  selected = null; selectedTargets = []; lastMove = null; humanColor = 'w'; orientation = 'w'; botThinking = false;
  resetClock(settings.clockPreset);
  setView('play');
  toast(`Đã nạp biến mẫu: ${opening.name}. Bạn có thể tiếp tục nước đi từ thế cờ này.`, 'success');
}
function wireCoachActions() {
  $('#coachEngineMode')?.addEventListener('change', event => {
    settings.coachEngineMode = event.target.value === 'stockfish' ? 'stockfish' : 'api';
    saveSettings();
    const info = $('.coach-source-row small');
    if (info) info.textContent = settings.coachEngineMode === 'stockfish' ? 'Chạy phân tích cục bộ, hiển thị điểm số và ba biến thể tốt nhất.' : `Đang chọn ${settings.model}. Tốc độ tùy mạng, nhà cung cấp và hạn mức API.`;
  });
  $('#coachForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const input = $('#coachInput');
    const content = input.value.trim();
    if (!content) return;
    if (coachRequestActive) {
      toast('Đang chờ Chess Bot trả lời. Tin nhắn mới vẫn được giữ trong ô nhập.');
      return;
    }
    input.value = '';
    await sendCoachMessage(content);
  });
  $('#clearChat')?.addEventListener('click', () => { coachRequestId += 1; coachAbortController?.abort(); coachAbortController = null; coachRequestActive = false; chatMessages = []; renderView(); });
  $$('[data-prompt]').forEach(button => button.addEventListener('click', () => { const input = $('#coachInput'); input.value = button.dataset.prompt; input.focus(); }));
  $$('[data-copy-message]').forEach(button => button.addEventListener('click', () => { const m = chatMessages.find(x => x.id === button.dataset.copyMessage); if (m) copyText(m.content); }));
  $('#copyFen')?.addEventListener('click', () => copyText(game.fen()));
  $('#copyPgnCoach')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
}
function wireSettingsActions() {
  const presetForEndpoint = {
    'https://api.openai.com/v1': 'openai',
    'https://api.anthropic.com': 'anthropic',
    'https://api.cerebras.ai/v1': 'cerebras',
    'https://api.x.ai/v1': 'xai',
    'https://openrouter.ai/api/v1': 'openrouter',
    'https://api.groq.com/openai/v1': 'groq',
    'https://api.deepseek.com/v1': 'deepseek',
    'https://api.together.xyz/v1': 'together',
    'https://api.mistral.ai/v1': 'mistral',
    'https://api.fireworks.ai/inference/v1': 'fireworks',
    'http://localhost:11434/v1': 'ollama',
    'https://generativelanguage.googleapis.com': 'gemini'
  };
  const currentPreset = settings.aiMode === 'gemini' ? 'gemini' : (presetForEndpoint[settings.endpoint.replace(/\/$/, '')] || 'custom');
  if ($('#providerPreset')) $('#providerPreset').value = currentPreset;
  const clearProviderModelList = () => { loadedApiModels = []; loadedModelContext = ''; };
  const applyProvider = (preset, chooseFreeModel = true) => {
    if (!preset) { clearProviderModelList(); renderApiModelList(); return; }
    const oldHost = (() => { try { return new URL($('#apiEndpoint')?.value || settings.endpoint).hostname; } catch { return ''; } })();
    const newHost = (() => { try { return new URL(preset.endpoint).hostname; } catch { return ''; } })();
    $('#aiMode').value = preset.mode;
    $('#apiEndpoint').value = preset.endpoint;
    if (oldHost && newHost && oldHost !== newHost) {
      $('#apiKey').value = '';
      const result = $('#settingsTestResult');
      if (result) { result.textContent = 'Đã đổi nhà cung cấp nên đã xóa API key trên biểu mẫu để tránh gửi nhầm khóa. Hãy nhập key của nhà cung cấp mới.'; result.className = 'connection-result'; }
    }
    clearProviderModelList();
    const candidates = freePresetsForProvider(preset);
    const currentModel = String($('#apiModel')?.value || '').trim();
    const validCurrent = candidates.some(item => item.model === currentModel);
    if (chooseFreeModel && candidates.length && !validCurrent && $('#apiModel')) $('#apiModel').value = candidates[0].model;
    else if (preset.mode === 'gemini' && !$('#apiModel').value) $('#apiModel').value = 'gemini-3.8-flash';
    else if (preset.mode === 'anthropic' && !$('#apiModel').value) $('#apiModel').value = 'claude-sonnet-latest';
    else if (preset.mode === 'openai-compatible' && !$('#apiModel').value) $('#apiModel').value = 'gpt-4o-mini';
    const result = $('#settingsTestResult');
    if (result) { result.textContent = candidates.length ? `Đã nạp sẵn ${candidates.length} lựa chọn Free Tier cho ${preset.endpoint}; không cần tải catalog để chọn model. Vẫn cần API key hợp lệ.` : 'Nhà cung cấp này chưa có preset free được xác nhận trong ứng dụng. Hãy kiểm tra bảng giá và tải catalog nếu cần.'; result.className = 'connection-result'; }
    renderApiModelList();
  };
  const providerEndpoints = {
    custom: null,
    openai: { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' },
    anthropic: { mode: 'anthropic', endpoint: 'https://api.anthropic.com' },
    cerebras: { mode: 'openai-compatible', endpoint: 'https://api.cerebras.ai/v1' },
    xai: { mode: 'openai-compatible', endpoint: 'https://api.x.ai/v1' },
    openrouter: { mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1' },
    groq: { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' },
    deepseek: { mode: 'openai-compatible', endpoint: 'https://api.deepseek.com/v1' },
    together: { mode: 'openai-compatible', endpoint: 'https://api.together.xyz/v1' },
    mistral: { mode: 'openai-compatible', endpoint: 'https://api.mistral.ai/v1' },
    fireworks: { mode: 'openai-compatible', endpoint: 'https://api.fireworks.ai/inference/v1' },
    ollama: { mode: 'openai-compatible', endpoint: 'http://localhost:11434/v1' },
    gemini: { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' }
  };
  $('#providerPreset')?.addEventListener('change', event => {
    const preset = providerEndpoints[event.target.value];
    if (!preset) { clearProviderModelList(); renderApiModelList(); return; }
    applyProvider(preset, true);
  });
  $('#freeModelPreset')?.addEventListener('change', event => {
    const preset = BUILTIN_FREE_MODEL_PRESETS.find(item => item.key === event.target.value);
    if (!preset) return;
    const oldHost = (() => { try { return new URL($('#apiEndpoint')?.value || settings.endpoint).hostname; } catch { return ''; } })();
    const newHost = (() => { try { return new URL(preset.endpoint).hostname; } catch { return ''; } })();
    if (oldHost && newHost && oldHost !== newHost) $('#apiKey').value = '';
    $('#aiMode').value = preset.mode;
    $('#apiEndpoint').value = preset.endpoint;
    $('#apiModel').value = preset.model;
    if ($('#providerPreset')) $('#providerPreset').value = preset.provider;
    clearProviderModelList();
    renderApiModelList();
    const result = $('#settingsTestResult');
    if (result) { result.textContent = `${preset.label}. ${preset.note} Hãy nhập API key riêng của bạn rồi bấm “Lưu cấu hình” hoặc “Kiểm tra AI”.`; result.className = 'connection-result'; }
  });
  $('#aiMode')?.addEventListener('change', event => {
    const currentEndpoint = $('#apiEndpoint').value.trim();
    const oldHost = (() => { try { return new URL(currentEndpoint).hostname; } catch { return ''; } })();
    let preset;
    if (event.target.value === 'gemini') preset = { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' };
    else if (event.target.value === 'anthropic') preset = { mode: 'anthropic', endpoint: 'https://api.anthropic.com' };
    else preset = { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' };
    const newHost = new URL(preset.endpoint).hostname;
    if (oldHost && newHost && oldHost !== newHost) $('#apiKey').value = '';
    $('#apiEndpoint').value = preset.endpoint;
    const firstPreset = freePresetsForProvider(preset)[0];
    if (firstPreset) $('#apiModel').value = firstPreset.model;
    else if (preset.mode === 'gemini') $('#apiModel').value = 'gemini-3.8-flash';
    else if (preset.mode === 'anthropic') $('#apiModel').value = 'claude-sonnet-latest';
    else $('#apiModel').value = 'gpt-4o-mini';
    clearProviderModelList();
    renderApiModelList();
  });
  $('#apiEndpoint')?.addEventListener('change', () => { clearProviderModelList(); renderApiModelList(); });
  $('#apiModelList')?.addEventListener('change', event => {
    if (event.target.value && $('#apiModel')) $('#apiModel').value = event.target.value;
  });
  $('#apiModel')?.addEventListener('input', event => {
    const list = $('#apiModelList');
    if (list && ![...list.options].some(option => option.value === event.target.value)) list.value = '';
    else if (list) list.value = event.target.value;
  });
  $('#toggleApiKey')?.addEventListener('click', () => { const input = $('#apiKey'); input.type = input.type === 'password' ? 'text' : 'password'; $('#toggleApiKey').textContent = input.type === 'password' ? 'Hiện' : 'Ẩn'; });
  $('#loadModels')?.addEventListener('click', event => loadProviderModels(event.currentTarget));
  $('#freeModelsOnly')?.addEventListener('change', renderApiModelList);
  $('#saveSettings')?.addEventListener('click', saveSettingsForm);
  $('#testAI')?.addEventListener('click', async () => {
    if (!saveSettingsForm(false)) return;
    const result = $('#settingsTestResult');
    result.textContent = 'Đang kiểm tra kết nối AI…';
    try {
      const data = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: settings.model, messages: [{ role: 'user', content: 'Trả lời đúng một từ: OK' }], system: 'Trả lời thật ngắn.' }) });
      result.textContent = `Kết nối thành công · ${settings.model}: ${String(data.text || '').slice(0, 180)}`;
      result.className = 'connection-result success-result';
    } catch (error) { result.textContent = `Chưa kết nối được: ${friendlyApiError(error.message)}`; result.className = 'connection-result error-result'; }
  });
  $('#resetSettings')?.addEventListener('click', () => {
    settings = normalizeSettings(DEFAULTS); const saved = saveSettings(); if (saved) toast('Đã đặt lại cấu hình AI.', 'success'); renderView();
  });
  renderApiModelList();
}
function renderApiModelList() {
  const list = $('#apiModelList');
  const suggestions = $('#apiModelSuggestions');
  if (!list) return;
  const oldValue = String($('#apiModel')?.value || list.value || '');
  const mode = $('#aiMode')?.value || settings.aiMode;
  const endpoint = $('#apiEndpoint')?.value.trim() || settings.endpoint;
  const context = `${mode}|${endpoint.replace(/\/$/, '')}`;
  const bundled = freePresetsForProvider({ mode, endpoint }).map(item => ({
    id: item.model, name: item.label, description: item.note, free: true, presetKey: item.key
  }));
  const downloaded = loadedModelContext === context ? loadedApiModels : [];
  const byId = new Map();
  for (const item of bundled) byId.set(item.id, item);
  for (const item of downloaded) {
    const previous = byId.get(item.id);
    byId.set(item.id, { ...previous, ...item, free: previous?.free === true || item.free === true ? true : item.free });
  }
  const models = [...byId.values()];
  const freeOnly = Boolean($('#freeModelsOnly')?.checked);
  const shown = freeOnly ? models.filter(item => item.free === true) : models;
  if (suggestions) suggestions.innerHTML = shown.map(item => `<option value="${esc(item.id)}" label="${esc(item.name || item.id)}${item.free === true ? ' · FREE TIER*' : ''}"></option>`).join('');
  list.innerHTML = shown.length
    ? `<option value="">Model tích hợp sẵn / catalog (${shown.length})</option>` + shown.map(item => `<option value="${esc(item.id)}">${esc(item.name || item.id)} · ${esc(item.id)}${item.free === true ? ' · FREE TIER*' : ''}</option>`).join('')
    : `<option value="">${freeOnly ? 'Không có model free được xác nhận trong danh sách này' : 'Chưa có model — nhập ID hoặc chọn nhà cung cấp'}</option>`;
  if (shown.some(item => item.id === oldValue)) list.value = oldValue;
  const quick = $('#freeModelPreset');
  if (quick && !quick.value) {
    const selected = BUILTIN_FREE_MODEL_PRESETS.find(item => item.mode === mode && item.model === oldValue && (() => { try { return new URL(item.endpoint).hostname === new URL(endpoint).hostname; } catch { return false; } })());
    quick.value = selected?.key || '';
  }
  if (freeOnly && !shown.length) {
    const result = $('#settingsTestResult');
    if (result) { result.textContent = 'Không có model Free Tier cho endpoint hiện tại trong catalog đã xác minh. Không tự gắn nhãn miễn phí; hãy chọn Gemini/Groq/OpenRouter trong Model chọn sẵn hoặc kiểm tra bảng giá.'; result.className = 'connection-result'; }
  }
}
async function loadProviderModels(button) {
  const mode = $('#aiMode')?.value || 'openai-compatible';
  const endpoint = $('#apiEndpoint')?.value.trim() || '';
  const apiKey = $('#apiKey')?.value.trim() || '';
  const backendUrl = $('#backendUrl')?.value.trim().replace(/\/$/, '') || '';
  const backendAccessToken = $('#backendAccessToken')?.value.trim() || '';
  const result = $('#settingsTestResult');
  if (!isSafeHttpEndpoint(endpoint)) {
    if (result) { result.textContent = 'Endpoint chưa hợp lệ. Hãy kiểm tra URL rồi tải model lại.'; result.className = 'connection-result error-result'; }
    return;
  }
  if (providerNeedsKey(mode, endpoint) && !apiKey) {
    if (result) { result.textContent = 'Hãy nhập API key riêng của endpoint này trước khi lấy danh sách model. Các preset chỉ có sẵn tên model, không chứa key.'; result.className = 'connection-result error-result'; }
    return;
  }
  if (backendUrl && !isSafeHttpEndpoint(backendUrl)) {
    if (result) { result.textContent = 'Backend URL chưa hợp lệ.'; result.className = 'connection-result error-result'; }
    return;
  }
  const oldSettings = settings;
  if (button) { button.disabled = true; button.textContent = 'Đang tải…'; }
  if (result) { result.textContent = 'Đang lấy model trực tiếp từ nhà cung cấp…'; result.className = 'connection-result'; }
  try {
    settings = { ...oldSettings, backendUrl, backendAccessToken };
    const data = await apiFetch('/api/ai/models', { method: 'POST', body: JSON.stringify({ mode, endpoint, apiKey }) });
    const models = Array.isArray(data?.models) ? data.models.filter(item => item && typeof item.id === 'string' && item.id.trim()) : [];
    if (!models.length) throw new Error('API chưa trả về model khả dụng.');
    loadedApiModels = models;
    loadedModelContext = `${mode}|${endpoint.replace(/\/$/, '')}`;
    renderApiModelList();
    const modelInput = $('#apiModel');
    const current = String(modelInput?.value || '').trim();
    const available = $('#freeModelsOnly')?.checked ? models.filter(item => item.free === true) : models;
    if (modelInput && available.length && !available.some(item => item.id === current)) {
      const textModel = available.find(item => !/(image|audio|tts|embedding|transcri|live|robotics|video|speech)/i.test(item.id));
      modelInput.value = (textModel || available[0]).id;
    }
    const modelList = $('#apiModelList');
    if (modelList && modelInput && [...modelList.options].some(option => option.value === modelInput.value)) modelList.value = modelInput.value;
    if (result) {
      const extra = data.truncated ? ' · catalog còn trang sau chưa tải hết.' : '';
      if ($('#freeModelsOnly')?.checked && !available.length) {
        result.textContent = `Đã lấy ${data.count || models.length} model nhưng không model nào được xác nhận Free Tier. Không thể suy ra miễn phí chỉ từ tên model.`;
        result.className = 'connection-result';
      } else {
        result.textContent = `Đã lấy ${data.count || models.length} model từ nhà cung cấp.${extra} Các preset tích hợp vẫn có thể chọn ngay mà không tải catalog.`;
        result.className = 'connection-result success-result';
      }
    }
  } catch (error) {
    if (result) { result.textContent = `Không tải được model: ${friendlyApiError(String(error.message || error).slice(0, 350))}`; result.className = 'connection-result error-result'; }
  } finally {
    settings = oldSettings;
    if (button) { button.disabled = false; button.textContent = 'Tải model'; }
  }
}

function saveSettingsForm(showToast = true) {
  const endpointInput = $('#apiEndpoint')?.value.trim() || '';
  const backendInput = $('#backendUrl')?.value.trim().replace(/\/$/, '') || '';
  const result = $('#settingsTestResult');
  if (!isSafeHttpEndpoint(endpointInput)) {
    const message = 'Endpoint AI không hợp lệ. Hãy dùng URL bắt đầu bằng http:// hoặc https://, không nhúng thông tin đăng nhập.';
    toast(message);
    if (result) { result.textContent = message; result.className = 'connection-result error-result'; }
    return false;
  }
  if (backendInput && !isSafeHttpEndpoint(backendInput)) {
    const message = 'Backend URL không hợp lệ. Hãy dùng URL HTTP(S) hợp lệ hoặc để trống khi chạy cùng máy.';
    toast(message);
    if (result) { result.textContent = message; result.className = 'connection-result error-result'; }
    return false;
  }
  settings.aiMode = $('#aiMode').value;
  settings.endpoint = endpointInput;
  settings.model = $('#apiModel').value.trim();
  settings.apiKey = $('#apiKey').value.trim();
  settings.backendUrl = backendInput;
  settings.backendAccessToken = $('#backendAccessToken').value.trim();
  const previousEngine = settings.botEngine || 'auto';
  const requestedEngine = $('#botEngineSetting')?.value || 'auto';
  settings.botEngine = ['auto', 'lite-single', 'full-single'].includes(requestedEngine) ? requestedEngine : 'auto';
  settings.botEnginePreferenceSet = true;
  settings.botSkill = Math.max(0, Math.min(20, Number($('#botSkillSetting').value || 20)));
  settings.botStrengthMode = $('#botStrengthModeSetting')?.value === 'elo' ? 'elo' : 'max';
  settings.botElo = Math.max(1320, Math.min(3190, Number($('#botEloSetting').value || 2600)));
  settings.botDepth = Math.max(5, Math.min(30, Number($('#botDepthSetting').value || 18)));
  settings.botMoveTimeMs = Math.max(500, Math.min(5000, Number($('#botMoveTimeSetting').value || 1200)));
  settings.analysisMoveTimeMs = Math.max(1000, Math.min(8000, Number($('#analysisMoveTimeSetting').value || 2600)));
  settings.openingBookEnabled = Boolean($('#openingBookEnabledSetting')?.checked);
  settings.soundEnabled = Boolean($('#soundEnabledSetting')?.checked);
  const saved = saveSettings();
  if (showToast && saved) toast(settings.botEngine !== previousEngine ? 'Đã lưu. Tải lại ứng dụng để áp dụng cấu hình engine mới.' : 'Đã lưu cấu hình trên thiết bị.', 'success');
  if (currentView === 'settings') {
    const status = $('#settingsTestResult');
    if (status) {
      status.textContent = saved
        ? 'Đã lưu cấu hình. Nhấn “Kiểm tra AI” để thử kết nối.'
        : 'Cấu hình đang dùng trong phiên này nhưng không lưu được vào thiết bị.';
      status.className = saved ? 'connection-result' : 'connection-result error-result';
    }
  }
  return true;
}
function wireLichessActions() {
  $('#connectLichess')?.addEventListener('click', connectLichess);
  $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
  $('#forgetLichess')?.addEventListener('click', () => {
    // Revoke the app's local session immediately: abort any stream using the
    // token and invalidate the active game before clearing the stored values.
    stopOnlineStream();
    activeLichessToken = '';
    activeLichessUsername = '';
    activeOnlineGame = null;
    safeSessionRemove(lichessTokenKey);
    safeSessionRemove('tubor.chess.lichessUsername');
    if (mode === 'lichess') {
      mode = 'stockfish';
      gameEpoch += 1;
      botThinking = false;
      cancelScheduledBotMove();
      cancelPendingHint();
      cancelMainEngineSearch();
    }
    if ($('#lichessToken')) $('#lichessToken').value = '';
    const result = $('#lichessAccountResult');
    if (result) result.textContent = 'Đã xóa token và ngắt kết nối Lichess khỏi phiên hiện tại.';
    if (currentView === 'play') renderView();
  });
  $('#challengeLichessAI')?.addEventListener('click', challengeLichessAI);
  $('#challengeLichessUser')?.addEventListener('click', challengeLichessUser);
}
async function connectLichess() {
  const token = getLichessToken();
  if (!token) { toast('Hãy nhập Lichess personal access token.'); return; }
  activeLichessToken = token;
  const persisted = safeSessionSet(lichessTokenKey, token);
  const result = $('#lichessAccountResult'); result.textContent = 'Đang xác thực token…';
  try {
    const account = await apiFetch('/api/lichess/account', { method: 'POST', body: JSON.stringify({ token }) });
    activeLichessUsername = account.username || '';
    safeSessionSet('tubor.chess.lichessUsername', activeLichessUsername);
    result.textContent = `Đã kết nối: ${account.username}${account.title ? ` (${account.title})` : ''}${persisted ? '' : ' · token chỉ được giữ trong phiên hiện tại'}`;
    result.className = 'connection-result success-result';
  } catch (error) { result.textContent = `Kết nối thất bại: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessAI() {
  const token = getLichessToken();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang tạo thử thách AI…';
  try {
    const data = await apiFetch('/api/lichess/challenge-ai', { method: 'POST', body: JSON.stringify({ token, level: Number($('#lichessLevel').value), clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã tạo thử thách. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a> <button id="playLichessChallenge" class="mini-primary">Chơi trong Chess Bot</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Ván vừa tạo: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không tạo được thử thách: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessUser() {
  const token = getLichessToken();
  const username = $('#lichessUsername').value.trim();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  if (!username) { result.textContent = 'Hãy nhập tên người chơi muốn thách đấu.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang gửi lời mời…';
  try {
    const data = await apiFetch('/api/lichess/challenge-user', { method: 'POST', body: JSON.stringify({ token, username, clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', opponent: username, username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã gửi lời mời. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở lời mời ↗</a> <button id="playLichessChallenge" class="mini-primary">Kết nối ván trong Chess Bot</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Lời mời: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không gửi được lời mời: ${error.message}`; result.className = 'connection-result error-result'; }
}

async function sendCoachMessage(content, { forceApi = false } = {}) {
  const cleanContent = String(content || '').trim();
  if (!cleanContent) return;
  if (coachRequestActive) { toast('Đang chờ Chess Bot trả lời tin nhắn trước.'); return; }

  coachRequestActive = true;
  const requestId = ++coachRequestId;
  coachAbortController = new AbortController();
  const inputMessages = chatMessages.filter(m => m.role === 'user' || m.role === 'assistant').slice(-6).map(m => ({ role: m.role, content: m.content }));
  chatMessages.push({ id: makeMessageId(), role: 'user', content: cleanContent });
  chatMessages.push({ id: 'waiting', role: 'assistant', content: 'Đang phân tích thế cờ…' });
  if (currentView === 'coach') renderView();

  try {
    if (settings.coachEngineMode === 'stockfish' && !forceApi) {
      const variants = await analyzeLocallyForCoach();
      if (requestId !== coachRequestId) return;
      chatMessages = chatMessages.filter(m => m.id !== 'waiting');
      const lines = variants.slice(0, 3).map((variant, index) => {
        const san = uciPvToSan(variant.fen, variant.pv).slice(0, 8).join(' ');
        return `${index + 1}. ${formatUciScore(variant)} · độ sâu ${variant.depth} · ${san || 'đang tính'}`;
      });
      const answer = lines.length ? `Phân tích Stockfish nội bộ (không gọi API):\nVị trí FEN: ${game.fen()}\n${lines.join('\n')}\n\nĐiểm số là đánh giá engine, không phải phần trăm thắng. Các biến thể là phương án ứng viên, cần xem toàn bộ ván để quyết định.\n\nLưu ý: Stockfish tính nước cờ, không phải mô hình hội thoại. Chọn AI qua API nếu muốn giải thích bằng ngôn ngữ tự nhiên hoặc hỏi kiến thức chung.` : 'Stockfish chưa trả được biến thể. Hãy thử lại sau.';
      chatMessages.push({ id: makeMessageId(), role: 'assistant', content: answer });
      return;
    }
    const gameContext = `Thế cờ hiện tại (FEN): ${game.fen()}\nPGN gần nhất: ${(game.pgn() || '(ván chưa có nước đi)').slice(-1800)}\nBên tới lượt: ${game.turn() === 'w' ? 'Trắng' : 'Đen'}\nTrạng thái: ${positionStatus()}.\nHãy trả lời bằng tiếng Việt đơn giản, không bịa nước đi. Nếu đưa ra nước đi hãy dùng ký hiệu SAN và nói đó là gợi ý cần xác minh.`;
    const data = await apiFetch('/api/ai/chat', {
      method: 'POST',
      timeoutMs: 35_000,
      signal: coachAbortController.signal,
      body: JSON.stringify({
        mode: settings.aiMode,
        endpoint: settings.endpoint,
        apiKey: settings.apiKey,
        model: settings.model,
        temperature: Math.min(Number(settings.temperature) || 0.3, 0.5),
        maxTokens: 384,
        timeoutMs: 30_000,
        system: `Bạn là huấn luyện viên cờ vua thân thiện cho người mới. Ưu tiên giải thích ngắn gọn, có ví dụ. ${gameContext}`,
        messages: [...inputMessages, { role: 'user', content: cleanContent }]
      })
    });
    if (requestId !== coachRequestId) return;
    chatMessages = chatMessages.filter(m => m.id !== 'waiting');
    chatMessages.push({ id: makeMessageId(), role: 'assistant', content: String(data.text || '').trim() || 'AI chưa trả về nội dung. Hãy thử lại.' });
  } catch (error) {
    if (requestId !== coachRequestId || error?.name === 'AbortError') return;
    chatMessages = chatMessages.filter(m => m.id !== 'waiting');
    chatMessages.push({ id: makeMessageId(), role: 'assistant', content: settings.coachEngineMode === 'stockfish' ? `Stockfish chưa phân tích được: ${error.message}\n\nHãy đợi engine sẵn sàng hoặc đóng phân tích đang chạy rồi thử lại.` : `Mình chưa gọi được API: ${error.message}\n\nBạn kiểm tra endpoint, tên model và API key trong Cài đặt nhé. Nếu chỉ muốn luyện cờ, Stockfish nội bộ vẫn dùng độc lập.` });
  } finally {
    if (requestId === coachRequestId) {
      coachRequestActive = false;
      coachAbortController = null;
      if (currentView === 'coach') {
        renderView();
        const transcript = $('#chatTranscript');
        if (transcript) transcript.scrollTop = transcript.scrollHeight;
      }
    }
  }
}

async function requestHint() {
  if (!gameStarted) { toast('Bắt đầu ván trước khi yêu cầu gợi ý.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi dùng gợi ý.'); return; }
  if (botThinking) { toast('Đợi bot đi xong rồi hãy xin gợi ý.'); return; }
  if (game.isGameOver()) { toast('Ván cờ đã kết thúc.'); return; }
  if (engineWorker && engineReady && !engineFailed) {
    if (engineSearchActive || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive) {
      toast('Stockfish đang xử lý yêu cầu khác; chờ xong rồi thử lại.');
      return;
    }
    const legal = game.moves({ verbose: true });
    if (!legal.length) return;
    cancelMainEngineWatchdog();
    const request = { fen: game.fen(), epoch: gameEpoch, legal, timeout: null };
    request.timeout = setTimeout(() => {
      if (pendingHintRequest !== request) return;
      pendingHintRequest = null;
      engineSearchActive = false;
      const shouldResumeBot = queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && game.turn() !== humanColor;
      retireStockfishWorker('Stockfish không phản hồi gợi ý kịp thời.');
      if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
      toast('Stockfish chưa phản hồi gợi ý kịp thời; đã dừng engine để tránh kết quả cũ. Chạm trạng thái engine để thử lại.');
      if (shouldResumeBot) { queuedMainEngineMove = false; scheduleBotMove(0); }
    }, 30000);
    pendingHintRequest = request;
    engineSearchActive = true;
    engineWorker.postMessage('stop');
    engineWorker.postMessage(`position fen ${request.fen}`);
    engineWorker.postMessage(`go movetime ${Math.max(700, Math.min(5000, Number(settings.botMoveTimeMs) || 1200))}`);
    return;
  }
  const move = chooseFallbackMove();
  if (move) setHintSuggestion(move, 'Dự phòng nhanh');
  toast(move ? `Gợi ý nhanh: ${move.san}. Đây là gợi ý dự phòng, không phải phân tích Stockfish.` : 'Không có nước đi hợp lệ.');
}

async function queryOpeningExplorer(showToast = true) {
  const requestId = ++explorerRequestId;
  const expectedFen = game.fen();
  const box = $('#explorerResult');
  if (box) box.innerHTML = '<div class="explorer-loading">Đang tra Opening Explorer…</div>';
  try {
    const moves = chessUciHistory();
    const data = await apiFetch(`/api/openings/explorer?moves=${encodeURIComponent(moves)}`);
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    lastExplorerData = data;
    const topMoves = Array.isArray(data?.moves) ? data.moves.slice(0, 4) : [];
    if (box) {
      const rows = topMoves.filter(m => m && typeof m === 'object').map(m => {
        const white = Math.max(0, Number(m.white) || 0);
        const draws = Math.max(0, Number(m.draws) || 0);
        const black = Math.max(0, Number(m.black) || 0);
        const total = white + draws + black;
        const pct = total ? Math.round(100 * white / total) : 0;
        const label = typeof m.san === 'string' ? m.san : typeof m.uci === 'string' ? m.uci : '';
        if (!label) return '';
        return `<div class="explorer-move"><b>${esc(label)}</b><span>${total.toLocaleString('vi-VN')} ván</span><small>Trắng thắng ${pct}%</small></div>`;
      }).filter(Boolean);
      box.innerHTML = rows.length ? `<div class="explorer-title">Nước phổ biến ở thế này</div>${rows.join('')}` : '<div class="empty-state small-empty">Chưa có thống kê cho thế cờ này.</div>';
    }
    if (showToast) toast(topMoves.length ? 'Đã tải dữ liệu khai cuộc từ Lichess.' : 'Không có dữ liệu khai cuộc ở thế này.');
  } catch (error) {
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    if (box) box.innerHTML = `<div class="empty-state small-empty">Chưa tra được: ${esc(error.message)}. Kiểm tra backend hoặc internet.</div>`;
    if (showToast) toast(`Không tra được khai cuộc: ${error.message}`);
  }
}
async function startOnlinePlay() {
  const token = getLichessToken();
  if (!activeOnlineGame?.id || !token) { toast('Cần có ván Lichess và token đã kết nối.'); setView('lichess'); return; }
  activeLichessToken = token;
  activeOnlineGame.apiMode = $('#lichessApiMode')?.value || activeOnlineGame.apiMode || 'board';
  activeOnlineGame.username = activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '';
  mode = 'lichess';
  humanColor = activeOnlineGame.color === 'black' ? 'b' : activeOnlineGame.color === 'white' ? 'w' : 'w';
  orientation = humanColor;
  game = new Chess(); gameStartFen = game.fen(); gameStarted = true; selected = null; selectedTargets = []; lastMove = null; botThinking = false;
  setView('play');
  toast('Đang kết nối luồng ván Lichess…');
  listenOnlineGame();
}
async function submitLichessMove(uci) {
  if (!activeOnlineGame?.id) { toast('Chưa có mã ván Lichess.'); return; }
  const token = getLichessToken();
  try {
    await apiFetch('/api/lichess/move', { method: 'POST', body: JSON.stringify({ token, gameId: activeOnlineGame.id, move: uci, apiMode: activeOnlineGame.apiMode || 'board' }) });
  } catch (error) {
    toast(`Lichess từ chối nước ${uci}: ${error.message}`);
    listenOnlineGame();
  }
}
async function listenOnlineGame() {
  stopOnlineStream();
  const token = getLichessToken();
  const streamGameId = String(activeOnlineGame?.id || '');
  if (!streamGameId || !token) return;
  const controller = new AbortController();
  onlineStreamController = controller;
  const isCurrentStream = () => !controller.signal.aborted && activeOnlineGame?.id === streamGameId && onlineStreamController === controller;
  try {
    const response = await fetch(apiUrl('/api/lichess/stream'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}) },
      body: JSON.stringify({ token, gameId: streamGameId, apiMode: activeOnlineGame.apiMode || 'board' }),
      signal: controller.signal
    });
    if (!isCurrentStream()) return;
    if (!response.ok || !response.body) {
      const message = await response.text().catch(() => 'Không mở được luồng ván.');
      throw new Error(message.slice(0, 300));
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = '';
    const handleStreamLine = line => {
      const trimmed = line.trim();
      if (!trimmed || !isCurrentStream()) return;
      try { processLichessEvent(JSON.parse(trimmed)); }
      catch (error) { console.warn('Lichess event parse:', error); }
    };
    while (isCurrentStream()) {
      const { value, done } = await reader.read();
      if (!isCurrentStream()) break;
      if (done) {
        pending += decoder.decode();
        if (pending.trim()) handleStreamLine(pending);
        pending = '';
        break;
      }
      pending += decoder.decode(value, { stream: true });
      const lines = pending.split('\n');
      pending = lines.pop() || '';
      for (const line of lines) {
        if (!isCurrentStream()) break;
        handleStreamLine(line);
      }
    }
  } catch (error) {
    if (isCurrentStream() && error?.name !== 'AbortError') toast(`Luồng Lichess bị ngắt: ${error.message}`);
  } finally {
    if (onlineStreamController === controller) onlineStreamController = null;
  }
}
function processLichessEvent(event) {
  if (!event || typeof event !== 'object') return;
  if (event.type === 'gameFull') {
    activeOnlineGame.initialFen = event.initialFen && event.initialFen !== 'startpos' ? event.initialFen : null;
    const whiteName = event.white?.name || event.white?.id || '';
    const blackName = event.black?.name || event.black?.id || '';
    if (activeOnlineGame.username && whiteName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'w';
    else if (activeOnlineGame.username && blackName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'b';
    else if (event.color === 'black' || event.color === 'white') humanColor = event.color === 'black' ? 'b' : 'w';
    orientation = humanColor;
    syncLichessMoveList(event.state?.moves || '');
    if (currentView === 'play') renderView();
  } else if (event.type === 'gameState') {
    syncLichessMoveList(event.moves || '');
    if (event.status && event.status !== 'started') toast(`Ván Lichess kết thúc: ${event.status}.`, 'success');
    if (currentView === 'play') renderView();
  } else if (event.type === 'chatLine') {
    console.info('[Lichess chat]', event.username, event.text);
  }
}
function syncLichessMoveList(movesText) {
  const replay = activeOnlineGame?.initialFen ? new Chess(activeOnlineGame.initialFen) : new Chess();
  for (const uci of String(movesText || '').split(/\s+/).filter(Boolean)) {
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) continue;
    try { replay.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) }); }
    catch { break; }
  }
  game = replay;
  gameEpoch += 1;
  const history = game.history({ verbose: true });
  const last = history[history.length - 1];
  lastMove = last ? { from: last.from, to: last.to } : null;
  selected = null; selectedTargets = [];
}

async function copyText(value) {
  const text = String(value ?? '');
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      toast('Đã sao chép.', 'success');
      return true;
    }
  } catch { /* Try the legacy selection API below for older WebViews. */ }
  let textarea;
  try {
    textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const ok = Boolean(document.execCommand?.('copy'));
    toast(ok ? 'Đã sao chép.' : 'Không sao chép được trên trình duyệt này.');
    return ok;
  } catch {
    toast('Không sao chép được trên trình duyệt này.');
    return false;
  } finally {
    textarea?.remove();
  }
}
function downloadTextFile(contents, filename, mimeType) {
  let url;
  let link;
  try {
    url = URL.createObjectURL(new Blob([contents], { type: mimeType }));
    link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    return true;
  } catch (error) {
    toast(`Không tạo được tệp tải xuống: ${error.message || error}`);
    return false;
  } finally {
    link?.remove();
    if (url) setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
}
function gamePgnWithResult() {
  const result = getGameResult().token;
  const raw = (game.pgn() || '').trim();
  const whiteName = mode === 'local' ? 'White' : (humanColor === 'w' ? 'Player' : (mode === 'ai' ? settings.model : 'Stockfish'));
  const blackName = mode === 'local' ? 'Black' : (humanColor === 'b' ? 'Player' : (mode === 'ai' ? settings.model : 'Stockfish'));
  const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(whiteName)}"]\n[Black "${pgnEscape(blackName)}"]\n[Result "${result}"]${manualGameResult?.reason ? `\n[Termination "${pgnEscape(manualGameResult.reason)}"]` : ''}`;
  const body = raw ? (/(?:1-0|0-1|1\/2-1\/2|\*)\s*$/.test(raw) ? raw.replace(/(?:1-0|0-1|1\/2-1\/2|\*)\s*$/, result) : `${raw} ${result}`) : result;
  return `${headers}\n\n${body}`;
}
function downloadPgn() {
  downloadTextFile(gamePgnWithResult(), 'chess-bot-game.pgn', 'application/x-chess-pgn;charset=utf-8');
}

function stopOnlineStream() {
  if (onlineStreamController) { onlineStreamController.abort(); onlineStreamController = null; }
}

// Re-measure against the actual WebView viewport on rotation, split-screen, or inset changes.
window.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });
window.addEventListener('orientationchange', scheduleBoardLayoutSync, { passive: true });
window.visualViewport?.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });

// Boot
$$('.tab').forEach(tab => tab.addEventListener('click', () => setView(tab.dataset.view)));
$('#openMenu')?.addEventListener('click', () => { const menu = $('#mainMenu'); const open = menu?.classList.toggle('menu-open') ?? false; $('#openMenu')?.setAttribute('aria-expanded', String(open)); });
$('#openSettings')?.addEventListener('click', () => setView('settings'));
$('#engineStatus')?.addEventListener('click', retryStockfishEngine);
resetClock(settings.clockPreset);
ensureClockTicker();
renderView();
initEngine();

