let audioContext = null;
function getAudioContext() {
  if (typeof window === 'undefined') return null;
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  try { audioContext ||= new Ctor(); return audioContext; } catch { return null; }
}
export function unlockBoardSound() {
  const ctx = getAudioContext();
  if (!ctx) return false;
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return true;
}
export function playBoardSound(move, chess, enabled = true) {
  if (!enabled || !move) return false;
  const ctx = getAudioContext();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    let notes;
    if (chess?.isCheckmate?.()) notes = [660, 523, 392];
    else if (chess?.isCheck?.()) notes = [660, 880];
    else if (move.captured || String(move.flags || '').includes('c') || String(move.flags || '').includes('e')) notes = [480, 620];
    else if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) notes = [520, 740];
    else notes = [460];
    notes.forEach((hz, index) => {
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(hz, now + index * 0.055);
      gain.gain.setValueAtTime(0.0001, now + index * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.055, now + index * 0.055 + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.055 + 0.095);
      oscillator.connect(gain); gain.connect(ctx.destination);
      oscillator.start(now + index * 0.055); oscillator.stop(now + index * 0.055 + 0.11);
    });
    return true;
  } catch { return false; }
}
