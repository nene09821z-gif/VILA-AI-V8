/**
 * A compact SAN opening book built from vetted opening lines. It never invents moves:
 * a candidate is returned only if chess.js exposes it as a legal move in the current position.
 */
export function findOpeningBookMove(chess, openings, options = {}) {
  if (!chess || !Array.isArray(openings) || chess.isGameOver?.()) return null;
  const maxPlies = Math.max(0, Math.min(20, Number(options.maxPlies ?? 14)));
  const history = chess.history();
  if (history.length >= maxPlies) return null;
  const legalMoves = chess.moves({ verbose: true });
  if (!legalMoves.length) return null;
  const legalBySan = new Map(legalMoves.map(move => [move.san, move]));
  const frequency = new Map();
  for (const opening of openings) {
    const line = opening?.san;
    if (!Array.isArray(line) || line.length <= history.length) continue;
    let matches = true;
    for (let i = 0; i < history.length; i += 1) {
      if (history[i] !== line[i]) { matches = false; break; }
    }
    if (!matches) continue;
    const san = line[history.length];
    if (legalBySan.has(san)) frequency.set(san, (frequency.get(san) || 0) + 1);
  }
  const candidates = [...frequency.keys()];
  if (!candidates.length) return null;
  const fen = chess.fen();
  const recent = options.recentChoices instanceof Map ? options.recentChoices.get(fen) : null;
  const varied = candidates.length > 1 && recent ? candidates.filter(san => san !== recent) : candidates;
  const pool = varied.length ? varied : candidates;
  // Popular lines remain more likely, but logarithmic weights prevent one mainline from dominating.
  const weights = pool.map(san => 1 + Math.log2(frequency.get(san) || 1));
  const total = weights.reduce((sum, weight) => sum + weight, 0);
  const rng = typeof options.random === 'function' ? options.random : Math.random;
  let ticket = Math.max(0, Math.min(0.999999999, Number(rng()) || 0)) * total;
  let chosen = pool[pool.length - 1];
  for (let i = 0; i < pool.length; i += 1) {
    ticket -= weights[i];
    if (ticket < 0) { chosen = pool[i]; break; }
  }
  if (options.recentChoices instanceof Map) options.recentChoices.set(fen, chosen);
  return legalBySan.get(chosen) || null;
}
