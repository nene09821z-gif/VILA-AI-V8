/** Recognize a named opening by matching the actual SAN history to curated lines. */
export function recognizeOpening(history = [], openings = [], options = {}) {
  const minPlies = Math.max(1, Math.min(12, Number(options.minPlies ?? 2) || 2));
  if (!Array.isArray(history) || history.length < minPlies || !Array.isArray(openings)) return null;
  const matches = [];
  for (const opening of openings) {
    const line = opening?.san;
    if (!Array.isArray(line) || line.length < 2) continue;
    const common = Math.min(history.length, line.length);
    let same = true;
    for (let i = 0; i < common; i += 1) {
      if (history[i] !== line[i]) { same = false; break; }
    }
    if (!same) continue;
    matches.push({ opening, matchedPlies: common, linePlies: line.length, exactLineFinished: history.length >= line.length });
  }
  if (!matches.length) return null;
  // Prefer a line that matches more of the actual game; when still inside a
  // shared prefix, prefer the best-defined longer branch without inventing a name.
  // Prefer the first curated canonical line on a shared prefix. Sorting by longest
  // branch made the app mislabel an ordinary e4/e5 position as a rare gambit before
  // the player had actually chosen its distinguishing move.
  matches.sort((a, b) => b.matchedPlies - a.matchedPlies || Number(b.exactLineFinished) - Number(a.exactLineFinished));
  return matches[0].opening;
}
