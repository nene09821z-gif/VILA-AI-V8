import test from 'node:test';
import assert from 'node:assert/strict';
import { friendlyProviderFailure, providerKeyRequired } from '../server/provider-errors.js';

test('provider failures explain common key, model, permission, quota and service problems', () => {
  assert.match(friendlyProviderFailure(401, 'bad key', 'Gemini').message, /API key không hợp lệ/i);
  assert.match(friendlyProviderFailure(403, '', 'Groq').message, /quyền truy cập/i);
  assert.match(friendlyProviderFailure(404, '', 'OpenRouter').message, /Model ID/i);
  assert.match(friendlyProviderFailure(429, '', 'Gemini').message, /quota/i);
  assert.equal(friendlyProviderFailure(503, '', 'Groq').status, 502);
});

test('provider error text redacts API keys and URL query tokens', () => {
  const message = friendlyProviderFailure(401, 'token=super-secret https://host.example/path?key=url-secret', 'Test', 'super-secret').message;
  assert.doesNotMatch(message, /super-secret|url-secret/);
  assert.match(message, /redacted/i);
});

test('keys are required for remote providers but not a local Ollama endpoint', () => {
  assert.equal(providerKeyRequired('gemini', 'https://generativelanguage.googleapis.com'), true);
  assert.equal(providerKeyRequired('anthropic', 'https://api.anthropic.com'), true);
  assert.equal(providerKeyRequired('openai-compatible', 'https://api.groq.com/openai/v1'), true);
  assert.equal(providerKeyRequired('openai-compatible', 'http://localhost:11434/v1'), false);
});
