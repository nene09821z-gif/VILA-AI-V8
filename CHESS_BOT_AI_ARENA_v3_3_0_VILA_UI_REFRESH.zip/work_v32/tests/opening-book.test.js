import test from 'node:test';
import assert from 'node:assert/strict';
import { findOpeningBookMove } from '../src/opening-book.js';
function mockChess({ history = [], fen = 'mock-fen', moves = [], gameOver = false } = {}) {
  return { history: () => history, fen: () => fen, moves: () => moves, isGameOver: () => gameOver };
}
const book = [{ name: 'line-a', san: ['e4', 'e5'] }, { name: 'line-b', san: ['e4', 'c5'] }, { name: 'line-c', san: ['d4', 'd5'] }];
test('opening book returns only a legal continuation matching the full history prefix', () => {
  const legal = [{ san: 'e5', from: 'e7', to: 'e5' }, { san: 'c5', from: 'c7', to: 'c5' }];
  const result = findOpeningBookMove(mockChess({ history: ['e4'], moves: legal }), book, { random: () => 0 });
  assert.ok(legal.includes(result)); assert.ok(['e5', 'c5'].includes(result.san));
});
test('opening book returns null for off-book positions and finished games', () => {
  assert.equal(findOpeningBookMove(mockChess({ history: ['Nf3'], moves: [{ san: 'd5' }] }), book), null);
  assert.equal(findOpeningBookMove(mockChess({ history: [], moves: [{ san: 'e4' }], gameOver: true }), book), null);
});
test('opening book respects max plies and avoids immediately repeating previous choice', () => {
  const moves = [{ san: 'e5' }, { san: 'c5' }];
  const recent = new Map([['mock-fen', 'e5']]);
  const result = findOpeningBookMove(mockChess({ history: ['e4'], moves }), book, { recentChoices: recent, random: () => 0 });
  assert.equal(result.san, 'c5');
  assert.equal(findOpeningBookMove(mockChess({ history: ['e4','e5'], moves }), book, { maxPlies: 2 }), null);
});
