import test from 'node:test';
import assert from 'node:assert/strict';
import { OPENINGS } from '../src/openings.js';
import { recognizeOpening } from '../src/opening-recognition.js';

test('opening recognition waits for minimum plies and matches actual SAN history', () => {
  assert.equal(recognizeOpening(['e4', 'e5', 'Nf3'], OPENINGS, { minPlies: 4 }), null);
  assert.equal(recognizeOpening(['e4', 'e5', 'Nf3', 'Nc6'], OPENINGS, { minPlies: 5 }), null);
  assert.equal(recognizeOpening(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'], OPENINGS, { minPlies: 5 })?.name, 'Khai cuộc Ý');
});

test('opening recognition returns null for a divergent start and safely clamps the threshold', () => {
  assert.equal(recognizeOpening(['a3', 'h5', 'Ra2', 'g5'], OPENINGS, { minPlies: 4 }), null);
  assert.equal(recognizeOpening(['e4'], OPENINGS, { minPlies: 0 }), null);
});
