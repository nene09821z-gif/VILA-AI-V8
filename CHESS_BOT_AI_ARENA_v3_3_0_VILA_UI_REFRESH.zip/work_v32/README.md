# Chess Bot AI Arena v3.2.0

Chess Bot là app cờ vua ưu tiên Android/WebView, dùng Stockfish 19 để tính nước, luật cờ qua `chess.js`, AI Coach qua Gemini/các API tương thích, sách khai cuộc có trọng số, đánh giá MultiPV, âm thanh bàn cờ, gợi ý có mũi tên, phân tích toàn ván, đồng hồ, PGN và Lichess.

> **Đây là ZIP mã nguồn để build bằng GitHub Actions, không phải APK đã biên dịch.** Build phụ thuộc cài đặt thành công và xác thực thiết bị là cổng bắt buộc trước khi phát hành.

## Có gì trong v3.2.0

- **Bắt đầu có chủ ý:** app mới mở ở trạng thái sẵn sàng; phải nhấn “Bắt đầu chơi” mới tạo ván đang hoạt động. Thiết lập được chọn về chế độ và màu quân được áp dụng tại thời điểm bắt đầu.
- **Bàn cờ responsive & vuốt quân:** đo theo kích thước thực của vùng chứa/viewport; hỗ trợ touch/pointer drag, đánh dấu nước hợp lệ, xử lý phong cấp, thao tác chạm chọn-đi vẫn được giữ. Có mũi tên gợi ý SVG và thanh đánh giá từ góc nhìn Trắng. Thanh đánh giá là biểu diễn trực quan, không phải phần trăm thắng đã hiệu chuẩn.
- **Stockfish 19 ổn định hơn:** Lite/Full single được chọn theo cấu hình thiết bị, Hash/Threads cấu hình một lần. Khi timeout, worker bị kết thúc thay vì chỉ gửi `stop`, loại bỏ khả năng nhận `bestmove` muộn trong yêu cầu mới. Nút trạng thái engine đầu trang có thể thử khởi tạo lại engine sau lỗi.
- **Sách khai cuộc đa dạng:** 81 đường mẫu có lựa chọn có trọng số theo lịch sử, giữ các đường cũ và thêm hệ khai cuộc mới. Nhận diện chờ thêm số nước để tránh kết luận quá sớm; mọi đường được xác minh trên bàn cờ tạm trước khi thay bàn đang chơi.
- **Âm thanh và gợi ý:** âm thanh tổng hợp cục bộ cho đi quân/ăn quân/chiếu/chiếu hết, bật tắt được; có nút đọc gợi ý tiếng Việt nếu WebView có giọng đọc phù hợp. Vuốt quân hỗ trợ Pointer Events.
- **Kết quả & phân tích toàn ván:** hiển thị kết quả thắng/hòa/hết giờ/đầu hàng, tải PGN với headers/result và chạy phân tích tuần tự từng nửa nước bằng Stockfish; có phân loại sai sót theo thay đổi đánh giá khi có đủ score. Giải thích bằng văn bản gọi AI Coach đã cấu hình.
- **AI Coach kép:** chọn Stockfish cục bộ cho điểm và MultiPV, hoặc model API để giải thích ngôn ngữ tự nhiên. Lỗi key/quota/model/endpoint hiển thị hướng xử lý; lỗi trả về không làm lộ key.
- **Preset Free Tier tích hợp sẵn:** Gemini Free Tier, một số model Groq Free Plan và OpenRouter `openrouter/free` có trong code, không cần tải provider catalog trước. Preset chỉ là danh sách model/endpoint; người dùng phải tự cung cấp API key nếu nhà cung cấp cần key. Không có key “miễn phí dùng chung” nhúng trong app. Free Tier chịu quota và có thể đổi theo tài khoản/nhà cung cấp.
- **Giữ chức năng cũ:** đồng hồ, khai cuộc explorer, Arena đấu model, Lichess, import/PGN và cấu hình provider vẫn có trong dự án.

## Build Android qua GitHub Actions

1. Giải nén toàn bộ ZIP vào thư mục gốc repository GitHub; giữ các file ẩn và `.github/workflows`.
2. Commit và push lên nhánh `main`.
3. Mở **Actions** rồi chạy **Build Chess Bot APK**.
4. Workflow sẽ cài npm dependencies, chạy static/full tests, yêu cầu các asset Stockfish, build Vite, tạo/sync Capacitor Android, xác minh Gradle và build APK debug.
5. Chỉ lấy APK artifact nếu workflow hoàn tất thành công. ZIP nguồn không phải APK.

Hướng dẫn chi tiết: [`BUILD_ANDROID_GUIDE_V3_2.md`](BUILD_ANDROID_GUIDE_V3_2.md).

## Trạng thái kiểm thử trong môi trường tạo ZIP

- `npm run test:static`: **77/77 đạt** sau các thay đổi v3.2.0.
- `node --check` cho các tệp JS/MJS dự án: kiểm tra riêng trước khi đóng gói.
- `npm test`: **77 test đạt, 1 test module không nạp được** vì môi trường này không có `node_modules/chess.js`. Do npm registry lỗi DNS trong phiên làm việc, chưa xác nhận được tính hợp lệ SAN của tất cả 81 đường khai cuộc bằng `chess.js`.
- Chưa xác nhận `npm run build`, Stockfish WASM/UCI thật trong trình duyệt, `assembleDebug`, API key live hoặc test trực tiếp trên OPPO A17k Android 12/DPI 360.

Xem [`TEST_REPORT_V3_2.md`](TEST_REPORT_V3_2.md) và [`AUDIT_REPORT_V3_2.md`](AUDIT_REPORT_V3_2.md) để xem đầy đủ các test đã chạy và giới hạn còn lại.

## Model/API và an toàn

Trang chính thức có thể đổi model/giá bất kỳ lúc nào; hãy kiểm tra trước khi dùng:

- Gemini models/pricing: <https://ai.google.dev/gemini-api/docs/models> · <https://ai.google.dev/gemini-api/docs/pricing>
- Groq models/rate limits: <https://console.groq.com/docs/models> · <https://console.groq.com/docs/rate-limits>
- OpenRouter free router: <https://openrouter.ai/openrouter/free> · <https://openrouter.ai/pricing/>

Không commit API key vào repository công khai. Key được người dùng tự nhập trên thiết bị; không có khóa nhà cung cấp chung tích hợp sẵn. Backend public cần HTTPS và `TUBOR_ACCESS_TOKEN` mạnh. Đọc kỹ chính sách chia sẻ dữ liệu của từng provider.
