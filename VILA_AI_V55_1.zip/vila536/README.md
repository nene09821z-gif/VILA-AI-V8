# VILA AI Studio 55.0.0

Ứng dụng Android (WebView) kết nối nhiều nhà cung cấp AI, kèm AI Gateway (Node.js) tuỳ chọn. Gói này là mã nguồn, không phải APK dựng sẵn.

## Cấu trúc
- `app/` — ứng dụng Android (Java + giao diện web trong `assets/`)
- `server/` — AI Gateway (Express, Firebase Admin, định tuyến nhiều provider, đa đội suy luận, công cụ agent)
- `scripts/` — kiểm tra hồi quy mã nguồn (không cần mạng)
- `docs/` — Firebase, đăng nhập Google, Gateway, Play Store, bản đồ kỹ thuật (`docs/TECHNOLOGY_MAP.md`), quy tắc chủ sở hữu
- `.github/workflows/main.yml` — CI: test, build APK, kiểm tra SHA-1 Google OAuth
- `CHANGELOG.md` — lịch sử thay đổi

## Chạy kiểm tra
```bash
cd server && npm install && cd ..
npm test            # test Gateway + toàn bộ script nguồn
```

## Chạy Gateway
```bash
cp server/.env.example server/.env   # điền khoá provider của bạn
cd server && npm start
```
Triển khai production: xem `docs/GATEWAY_DEPLOYMENT.md` và `compose.yaml` (chỉ bind loopback; cần reverse proxy HTTPS).

## Build APK
Đẩy toàn bộ nội dung thư mục này lên GitHub, chạy workflow **VILA AI - Android Build and Verify** và tải artifact. Xem `docs/BUILD_GITHUB_ACTIONS.txt`.

## Giới hạn đã biết
- APK chỉ được coi là build thành công sau khi GitHub Actions chạy xong; đăng nhập Google cần SHA-1 khớp với Firebase.
- `privacy-policy.html` và `account-deletion.html` là bản nháp, cần điền thông tin thật trước khi lên Play Store (`docs/PLAY_STORE_READINESS.md`).
- Không có cam kết uptime 24/7; xem `docs/TECHNOLOGY_MAP.md`.
