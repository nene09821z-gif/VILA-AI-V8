# Changelog

Một file duy nhất thay cho hơn 50 changelog/báo cáo theo từng phiên bản trước đây.

## 55.0.0 (versionCode 70) — Dọn dẹp và hoàn thiện
- Xoá ~90 file cũ tích tụ: changelog, README, báo cáo QA và hướng dẫn build theo từng phiên bản (V15–V54), `VILA_PRO_V17_QA_AUDIT.json`, ảnh `ic_launcher_preview.png` không được tham chiếu.
- Tài liệu còn dùng được chuyển vào `docs/`: Firebase, đăng nhập Google, Play Store, Gateway, bản đồ kỹ thuật, quy tắc chủ sở hữu, build bằng GitHub Actions.
- Tạo lại `.github/workflows/main.yml`: workflow bị thiếu trong gói zip nên 9 script kiểm tra không chạy được. Workflow gồm job kiểm tra (test Gateway và script nguồn) và job build Android.
- Đồng bộ phiên bản về 55.0.0 trong Android, Gateway, `package.json`, hai file `.env` mẫu, `compose.yaml` và bộ kiểm tra. Trước đó các file ghi lệch nhau (52.0.0, 53.6.0, 54.0.0, 54.0.2).
- Thêm `npm test` ở thư mục gốc để chạy toàn bộ test Gateway và script nguồn cùng lúc (`scripts/run-all.js`).
- Thêm `.gitignore`.
- **Định tuyến thích ứng cho Gateway:** đo độ trễ (EWMA) và tỉ lệ thành công của từng provider theo thời gian thực. Điểm xếp hạng được cộng cho provider nhanh, ổn định và trừ cho provider chập chờn hoặc chậm (giới hạn -30 đến +20, cần ít nhất 3 mẫu). Chỉ số hiển thị trong `circuit.performance` của trạng thái provider. Có test mới `adaptive-routing-v55.test.js`.
- Bộ kiểm tra không còn phụ thuộc vào các file tài liệu theo phiên bản đã xoá.

## 54.x — Công cụ thật, Puter Claude, dọn provider
- 54.0: công cụ agent thật (sandbox JS/Python, tìm web có chặn SSRF và DNS rebinding, kho lưu trữ).
- 54.1: sửa lỗi sau audit. 54.2: tích hợp Claude qua Puter.js, cho phép popup đăng nhập trong WebView.
- 54.4: gỡ provider không mong muốn, bỏ token GitHub khỏi giao diện, giao diện đơn giản (`vila-simple`).

## 53.x — Provider pool và agent
- Pool provider (OpenAI, Mistral, Together, Fireworks), kiểm tra câu trả lời rỗng, fallback, lỗi SSE rõ ràng.
- Function calling cho agent mode, tìm kiếm và tạo ảnh/video.

## 52.x — Đa đội suy luận
- Điều phối nhiều đội (chuyên gia, nghiên cứu, lập trình, phản biện, tổng hợp), gắn provider/model riêng cho từng đội.
- Giới hạn tốc độ có trọng số, health endpoints, tắt máy an toàn, Docker Compose.
- Quét máy chủ AI cục bộ (llama.cpp, Ollama, LM Studio, vLLM, LocalAI) trên loopback.

## V50–V51 — Gateway UI, danh mục model trực tiếp
- Danh mục model tìm kiếm được, phân trang bằng `nextPageToken`, giao diện responsive cho Gateway.
- Khoá API lưu bằng AES-GCM trong Android Keystore; Gateway production từ chối chế độ không xác thực và CORS wildcard.

## 41–49 — Đăng nhập và độ tin cậy
- Firebase Auth gốc (email/mật khẩu, Google qua Credential Manager), keystore debug ổn định, reset mật khẩu.
- Deadline và dọn dẹp cho Gateway, gateway phục hồi proxy cục bộ.

## 15–40 — Nền tảng
- WebView Android, nhiều API, định tuyến thông minh, tìm kiếm, ảnh, file, dashboard, biểu tượng SVG.

Lưu ý: APK chưa được build trong môi trường chỉnh sửa này (không có Android SDK/Gradle). Hãy chạy GitHub Actions để xác nhận.
