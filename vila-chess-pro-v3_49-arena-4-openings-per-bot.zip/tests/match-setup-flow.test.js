import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
// Slim GitHub ZIPs omit duplicated static files under app/src/main/assets; fall back to public/.
const readAndroid = file => {
  const androidPath = path.join(root, file);
  if (fs.existsSync(androidPath)) return fs.readFileSync(androidPath, 'utf8');
  return read(file.replace('app/src/main/assets/', 'public/'));
};

test('a separate match setup is rendered before the chessboard', () => {
  const main = read('src/main.js');
  assert.match(main, /function renderMatchSetupView\(\)/);
  assert.match(main, /function renderPlayView\(\)\s*\{\s*if \(!gameStarted\) return renderMatchSetupView\(\);/);
  const setup = main.slice(main.indexOf('function renderMatchSetupView()'), main.indexOf('function renderPlayView()'));
  for (const id of ['modeSelect', 'gameBotProfile', 'colorSelect', 'skillSelect', 'clockPreset', 'randomBotElo', 'startGameOverlay']) {
    assert.ok(setup.includes(`id="${id}"`), `setup screen missing ${id}`);
  }
  assert.match(setup, /Bàn cờ sẽ xuất hiện khi bạn bắt đầu/);
});

test('new match and replay controls route back through setup instead of creating a game immediately', () => {
  const main = read('src/main.js');
  assert.match(main, /function openMatchSetup\(\)/);
  assert.match(main, /gameStarted = false;\s*setView\('play'\)/);
  assert.match(main, /\$\('#newGame'\)\?\.addEventListener\('click', openMatchSetup\)/);
  assert.match(main, /\$\('#restartGameBtn'\)\?\.addEventListener\('click', openMatchSetup\)/);
  assert.match(main, /\$\('#gameShowSetup'\)\?\.addEventListener\('click', openMatchSetup\)/);
});

test('Android prebuilt web assets contain the same setup-first flow and cache generation', () => {
  const html = read('app/src/main/assets/index.html');
  const js = read('app/src/main/assets/assets/index-CYdsNhSO.js');
  const css = read('app/src/main/assets/assets/index-nreOU-41.css');
  const sw = readAndroid('app/src/main/assets/sw.js');
  assert.match(html, /Atelier Chess v3\.47\.2/);
  assert.match(html, /index-CYdsNhSO\.js\?v=352/);
  assert.match(js, /Thiết lập trận đấu/);
  assert.match(js, /function openNewMatchSetup\(\)/);
  assert.match(css, /body\.match-setup-active/);
  assert.match(sw, /covua-vila-v3\.47\.2/);
});
