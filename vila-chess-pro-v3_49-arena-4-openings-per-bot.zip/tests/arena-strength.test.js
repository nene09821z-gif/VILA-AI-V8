import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { resolveArenaMoveTimeMs, resolveArenaSearchSettings, resolveArenaStyleTolerance } from '../src/arena-strength.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('arena uses one bounded move-time policy for all engine profiles', () => {
  assert.equal(resolveArenaMoveTimeMs(8), 1200);
  assert.equal(resolveArenaMoveTimeMs(12), 1320);
  assert.equal(resolveArenaMoveTimeMs(20), 2200);
  assert.equal(resolveArenaMoveTimeMs(30), 3300);
  assert.equal(resolveArenaMoveTimeMs(999), 3300);
  assert.equal(resolveArenaMoveTimeMs('not-a-number'), 3300);
});

test('arena default is full-strength and shared search settings are normalized', () => {
  assert.deepEqual(resolveArenaSearchSettings(), {
    depth: 30, skill: 20, strengthMode: 'max', elo: 2600, moveTimeMs: 3300, multiPv: 4,
  });
  assert.deepEqual(resolveArenaSearchSettings({ depth: 999, skill: -12, strengthMode: 'elo', elo: 9999 }), {
    depth: 30, skill: 0, strengthMode: 'elo', elo: 3200, moveTimeMs: 3300, multiPv: 4,
  });
});

test('arena styles can only select a near-best line and no longer receive a rookie/mentor strength handicap', () => {
  for (const profile of ['classic', 'rookie', 'mentor', 'berserk', 'chaos', 'ethereal']) {
    assert.equal(resolveArenaStyleTolerance(profile), 18);
  }
  const start = main.indexOf('async function chooseArenaUci');
  const end = main.indexOf('function getArenaOutcome', start);
  const choose = main.slice(start, end);
  assert.doesNotMatch(choose, /profile === 'mentor' \? Math\.min\(5, skill\)/);
  assert.doesNotMatch(choose, /profile === 'rookie' \? Math\.min\(10, skill\)/);
  assert.match(choose, /const moveTimeMs = Number\(options\.moveTimeMs\) \|\| resolveArenaMoveTimeMs\(depth\)/);
  assert.match(choose, /strengthMode: options\.strengthMode \|\| 'max'/);
  assert.match(choose, /multiPv: 4/);
  assert.match(choose, /findOpeningBookMove\(chess, OPENINGS, \{ maxPlies: 20, random: \(\) => 0\.5 \}\)/);
  assert.doesNotMatch(choose, /pickPersonaBookMove\(chess, profile, OPENINGS/);
});

test('arena copy explains equal budgets and keeps full strength selected by default', () => {
  assert.match(main, /Mặc định thi đấu tối đa: mọi bot dùng chung độ sâu, thời gian suy nghĩ và Skill Level/);
  assert.match(main, /option value="max" selected>Tối đa · công bằng/);
  assert.match(main, /resolveArenaSearchSettings\(/);
});
