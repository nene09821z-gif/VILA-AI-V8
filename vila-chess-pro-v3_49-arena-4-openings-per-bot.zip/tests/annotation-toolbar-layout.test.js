import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const baseCss = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const v4Css = fs.readFileSync(new URL('../src/vila-v4.css', import.meta.url), 'utf8');

test('Analysis palette is floating, movable, foldable, hideable, and offers direct multicolor selection', () => {
  const board = main.indexOf('<div class="board-frame">');
  const toolbar = main.indexOf('<div class="board-annotation-toolbar-row" aria-label="Công cụ vẽ phân tích">', board);
  const widget = main.indexOf('id="boardAnnotationWidget"', toolbar);
  assert.ok(board >= 0 && toolbar > board && widget > toolbar);
  const tools = main.slice(toolbar, main.indexOf('<div class="mobile-action-row match-action-bar"', toolbar));
  for (const token of ['annotationWidgetGrip', 'annotationWidgetToggle', 'annotationWidgetHide', 'annotationWidgetReopen', 'data-annotation-tool="arrow"', 'data-annotation-tool="circle"', 'data-annotation-color="green"', 'data-annotation-color="red"', 'data-annotation-color="yellow"', 'data-annotation-color="blue"', 'annotationColorCycle', 'annotationClear']) {
    assert.ok(tools.includes(token), `missing annotation control: ${token}`);
  }
  assert.match(main, /function syncAnnotationWidget\(\)[\s\S]*annotationWidgetHidden/);
  assert.match(main, /function wireAnnotationWidget\(\)[\s\S]*annotationWidgetDrag/);
  assert.match(v4Css, /\.board-annotation-widget\{position:fixed!important/);
  assert.match(v4Css, /\.annotation-widget-grip/);
  assert.match(v4Css, /\.annotation-color-dot\.color-blue/);
  assert.match(v4Css, /\.annotation-widget-reopen\[hidden\]/);
  assert.match(baseCss, /\.manual-arrow-blue/);
});

test('Virtual PC mouse supports compact touchpad movement and hold-drag-release using the existing board pointer path', () => {
  for (const token of ['virtualMouseToggle', 'virtualMousePanel', 'virtualMousePad', 'virtualMouseCursor', 'virtualMouseClick', 'virtualMouseHold', 'virtualMouseReopen']) assert.ok(main.includes(token), `missing virtual mouse control: ${token}`);
  assert.match(main, /const VIRTUAL_MOUSE_SENSITIVITY = 2\.35/);
  assert.match(main, /function virtualMouseSetPosition\([\s\S]*requestAnimationFrame/);
  assert.match(main, /function virtualMouseSetHeld\([\s\S]*pointerdown/);
  assert.match(main, /function virtualMouseDispatchPointer\([\s\S]*VIRTUAL_MOUSE_POINTER_ID/);
  assert.match(main, /function wireVirtualMouse\([\s\S]*pointermove/);
  assert.match(v4Css, /\.virtual-mouse-cursor/);
  assert.match(v4Css, /\.virtual-mouse-pad\{position:relative/);
});

test('Optional hand-tracking cursor uses a worker, pinch-to-drag, and a touchpad fallback', () => {
  const worker = fs.readFileSync(new URL('../src/hand-mouse-worker.js', import.meta.url), 'utf8');
  assert.ok(main.includes('id="virtualMouseCamera"'));
  assert.match(main, /async function startHandMouse\(\)[\s\S]*getUserMedia/);
  assert.match(main, /new Worker\(new URL\('\.\/hand-mouse-worker\.js', import\.meta\.url\)/);
  assert.match(main, /HAND_MOUSE_PINCH_DOWN = 0\.047/);
  assert.match(main, /HAND_MOUSE_PINCH_UP = 0\.075/);
  assert.match(main, /chụm cái \+ trỏ để nhấn\/giữ/);
  assert.match(main, /function stopHandMouse\([\s\S]*button\.disabled = false/);
  assert.match(main, /function setView\(view\)[\s\S]*previousView === 'play' && view !== 'play'[\s\S]*stopHandMouse/);
  assert.match(main, /addEventListener\('visibilitychange',[\s\S]*if \(handMouseStream\) stopHandMouse\(\)/);
  assert.match(worker, /HandLandmarker\.createFromOptions/);
  assert.match(worker, /detectForVideo/);
  assert.match(worker, /postMessage\(\{\s*type: 'landmarks'/);
  assert.doesNotMatch(worker, /fetch\([^)]*landmarks|sendBeacon|WebSocket/);
  assert.match(v4Css, /\.virtual-mouse-camera\{/);
  assert.match(v4Css, /\.virtual-mouse-video\{/);
});
