import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { resolveArenaMoveTimeMs, resolveArenaSearchSettings } from '../src/arena-strength.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');

test('Arena defaults to Stockfish 19 and an optional VILA style opponent', () => {
  const main = read('src/main.js');
  assert.match(main, /arenaSelectedLeague = new Set\(\['stockfish', 'offline-ethereal'\]\)/);
  assert.match(main, /const defaultBlack = players\.some\(p => p\.id === 'offline-ethereal'\) \? 'offline-ethereal'/);
  assert.match(main, /startArenaMatch\(\$\('#arenaWhite'\)\?\.value \|\| 'stockfish', \$\('#arenaBlack'\)\?\.value \|\| 'offline-ethereal'\)/);
  assert.match(main, /id: 'stockfish-10'.*cổ điển/);
});

test('Arena applies the same bounded depth/time/skill policy to every contestant', () => {
  const main = read('src/main.js');
  assert.equal(resolveArenaMoveTimeMs(20), 2200);
  assert.equal(resolveArenaSearchSettings().depth, 30);
  assert.equal(resolveArenaSearchSettings().moveTimeMs, 3300);
  assert.equal(resolveArenaSearchSettings().skill, 20);
  assert.equal(resolveArenaSearchSettings().strengthMode, 'max');
  assert.match(main, /resolveArenaSearchSettings\(/);
  assert.match(main, /resolveArenaMoveTimeMs\(depth\)/);
  assert.match(main, /const moveTimeMs = Number\(options\.moveTimeMs\) \|\| resolveArenaMoveTimeMs\(depth\)/);
  assert.match(main, /skill,\s*depth,\s*strengthMode: options\.strengthMode \|\| 'max'/);
  assert.match(main, /multiPv: 4/);
  assert.match(main, /resolveReviewMoveTimeMs\(settings\)/);
  assert.match(main, /value="150" selected>0,15 giây/);
  assert.match(main, /delayMs: Number\(\$\('#arenaDelay'\)\?\.value \?\? 150\)/);
});

test('legacy Stockfish uses the shared arena time budget, not a short fixed handicap', () => {
  const main = read('src/main.js');
  const legacy = main.slice(main.indexOf('async function requestLegacyArenaUci'), main.indexOf('async function chooseArenaUci'));
  assert.match(legacy, /const moveTimeMs = Number\(options\.moveTimeMs\) \|\| resolveArenaMoveTimeMs\(depth\)/);
  assert.doesNotMatch(legacy, /Math\.min\(220,/);
  assert.match(legacy, /timeoutMs: Math\.max\(8_000, moveTimeMs \* 4\)/);
});

test('Android Gradle build stages the canonical public assets rather than relying on stale bundled JS', () => {
  const gradle = read('app/build.gradle.kts');
  assert.match(gradle, /publicDir = rootProject\.file\("public"\)/);
  assert.match(gradle, /stagePublicAssetsForAndroid/);
  assert.match(gradle, /dependsOn\(stagePublicAssetsForAndroid\)/);
  assert.match(gradle, /engine\/stockfish-10\.js/);
});

test('legacy engine init timeout remains bounded and separate from the strengthened arena budget', () => {
  const main = read('src/main.js');
  assert.match(main, /initTimeoutMs: 8_000, defaultSearchTimeoutMs: 4_500/);
});
