import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sourceRes = path.join(root, 'resources', 'android-icons');
const targetRes = path.join(root, 'android', 'app', 'src', 'main', 'res');
const manifestPath = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const stringsPath = path.join(targetRes, 'values', 'strings.xml');

if (!fs.existsSync(manifestPath) || !fs.existsSync(targetRes)) {
  console.error('[Cờ Vua ViLa] Android project is missing. Run `npx cap add android` before applying branding.');
  process.exit(1);
}

const densities = ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'];
const iconNames = ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png'];
for (const density of densities) {
  const fromDir = path.join(sourceRes, `mipmap-${density}`);
  const toDir = path.join(targetRes, `mipmap-${density}`);
  fs.mkdirSync(toDir, { recursive: true });
  for (const name of iconNames) {
    const from = path.join(fromDir, name);
    if (!fs.existsSync(from)) throw new Error(`Missing checked-in icon asset: ${path.relative(root, from)}`);
    fs.copyFileSync(from, path.join(toDir, name));
  }
}

const adaptiveFrom = path.join(sourceRes, 'mipmap-anydpi-v26');
const adaptiveTo = path.join(targetRes, 'mipmap-anydpi-v26');
fs.mkdirSync(adaptiveTo, { recursive: true });
for (const name of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
  fs.copyFileSync(path.join(adaptiveFrom, name), path.join(adaptiveTo, name));
}
const colorSource = path.join(sourceRes, 'values', 'covua-vila-colors.xml');
const valuesTarget = path.join(targetRes, 'values', 'covua_vila_icon_colors.xml');
fs.copyFileSync(colorSource, valuesTarget);

// Keep the native label consistent, whether Capacitor generated it from config or not.
let strings = fs.existsSync(stringsPath)
  ? fs.readFileSync(stringsPath, 'utf8')
  : '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n';
if (/<string\s+name="app_name"[^>]*>[\s\S]*?<\/string>/.test(strings)) {
  strings = strings.replace(/<string\s+name="app_name"[^>]*>[\s\S]*?<\/string>/, '<string name="app_name">Cờ Vua ViLa</string>');
} else {
  strings = strings.replace('</resources>', '    <string name="app_name">Cờ Vua ViLa</string>\n</resources>');
}
fs.mkdirSync(path.dirname(stringsPath), { recursive: true });
fs.writeFileSync(stringsPath, strings);

let manifest = fs.readFileSync(manifestPath, 'utf8');
const applicationMatch = manifest.match(/<application\b[^>]*>/);
if (!applicationMatch) throw new Error('Could not find the Android <application> tag.');
let applicationTag = applicationMatch[0];
const setAttribute = (tag, name, value) => {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\s${escaped}="[^"]*"`);
  return pattern.test(tag)
    ? tag.replace(pattern, ` ${name}="${value}"`)
    : tag.replace(/\s*\/?>$/, ending => ` ${name}="${value}"${ending}`);
};
applicationTag = setAttribute(applicationTag, 'android:label', '@string/app_name');
applicationTag = setAttribute(applicationTag, 'android:icon', '@mipmap/ic_launcher');
applicationTag = setAttribute(applicationTag, 'android:roundIcon', '@mipmap/ic_launcher_round');
manifest = manifest.replace(applicationMatch[0], applicationTag);
fs.writeFileSync(manifestPath, manifest);

console.log('[Cờ Vua ViLa] Android launcher icons, adaptive icons, and app label applied.');
