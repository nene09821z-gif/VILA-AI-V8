import fs from 'node:fs';
import path from 'node:path';

const androidRoot = path.resolve(process.argv[2] || 'android');
const manifestPath = path.join(androidRoot, 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  console.error(`AndroidManifest.xml not found: ${manifestPath}`);
  process.exit(1);
}
let xml = fs.readFileSync(manifestPath, 'utf8');
const permission = 'android.permission.CAMERA';
if (new RegExp(`<uses-permission\\b[^>]*android:name=["']${permission}["']`).test(xml)) {
  console.log('Camera permission already present.');
  process.exit(0);
}
const manifestOpen = xml.match(/<manifest\b[^>]*>/);
if (!manifestOpen) {
  console.error('Invalid AndroidManifest.xml: missing <manifest> root element.');
  process.exit(1);
}
xml = xml.replace(manifestOpen[0], `${manifestOpen[0]}\n    <uses-permission android:name="${permission}" />`);
fs.writeFileSync(manifestPath, xml);
console.log('Added android.permission.CAMERA for optional hand-tracking mode.');
