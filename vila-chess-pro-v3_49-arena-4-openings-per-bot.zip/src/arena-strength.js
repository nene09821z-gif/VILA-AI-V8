const clamp = (value, min, max, fallback) => {
  const parsed = Number(value);
  const safe = Number.isFinite(parsed) ? parsed : fallback;
  return Math.max(min, Math.min(max, Math.round(safe)));
};

/**
 * Shared per-move budget for every opponent in the AI Arena.
 * The same depth and wall-clock allowance are used for Stockfish 19, Stockfish 10,
 * and VILA style profiles. Different engines may reach different depths in that time;
 * that is an engine-performance difference, not an intentional handicap.
 */
export function resolveArenaMoveTimeMs(depth = 30) {
  const safeDepth = clamp(depth, 8, 30, 30);
  return Math.max(1_200, Math.min(3_600, Math.round(safeDepth * 110)));
}

/** Normalized options shared by every arena player. Full strength is the default. */
export function resolveArenaSearchSettings(options = {}) {
  const depth = clamp(options.depth, 8, 30, 30);
  const skill = clamp(options.skill, 0, 20, 20);
  const strengthMode = options.strengthMode === 'elo' ? 'elo' : 'max';
  const elo = clamp(options.elo, 500, 3_200, 2_600);
  return {
    depth,
    skill,
    strengthMode,
    elo,
    moveTimeMs: resolveArenaMoveTimeMs(depth),
    // All Stockfish-backed contestants receive the same number of candidate lines.
    // Stockfish 10's legacy adapter emits only its principal line but gets the same time.
    multiPv: 4,
  };
}

/** Keep style preference as a tie-breaker among near-equal engine moves, never a handicap. */
export function resolveArenaStyleTolerance(_profile = 'classic') {
  return 18;
}
