/**
 * Cờ Vua ViLa — Firebase & Social Cloud Sync Module
 * Tích hợp đăng nhập Google, Facebook và đồng bộ lịch sử ván đấu an toàn.
 * Hỗ trợ chế độ ngoại tuyến 100%: không bắt buộc đăng nhập để chơi cờ.
 */

const FIREBASE_CONFIG_KEY = 'vila.chess.firebase-config.v1';
const FIREBASE_USER_KEY = 'vila.chess.firebase-user.v1';
const SYNC_META_KEY = 'vila.chess.cloud-sync-meta.v1';

export function getFirebaseConfig() {
  try {
    const raw = localStorage.getItem(FIREBASE_CONFIG_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch {}
  return {
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: ''
  };
}

export function saveFirebaseConfig(cfg) {
  try {
    const normalized = {
      apiKey: String(cfg?.apiKey || '').trim(),
      authDomain: String(cfg?.authDomain || '').trim(),
      projectId: String(cfg?.projectId || '').trim(),
      storageBucket: String(cfg?.storageBucket || '').trim(),
      messagingSenderId: String(cfg?.messagingSenderId || '').trim(),
      appId: String(cfg?.appId || '').trim()
    };
    localStorage.setItem(FIREBASE_CONFIG_KEY, JSON.stringify(normalized));
    return normalized;
  } catch (error) {
    console.error('[Firebase] Error saving config:', error);
    return null;
  }
}

export function isFirebaseConfigured() {
  const cfg = getFirebaseConfig();
  return Boolean(cfg.apiKey && cfg.projectId && !cfg.apiKey.includes('YOUR_') && !cfg.projectId.includes('placeholder'));
}

export function getSyncMeta() {
  try {
    const raw = localStorage.getItem(SYNC_META_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { lastSyncTime: null, syncedCount: 0, status: 'offline' };
}

export function saveSyncMeta(meta) {
  try {
    localStorage.setItem(SYNC_META_KEY, JSON.stringify(meta));
  } catch {}
}

/**
 * Đăng nhập Google / Facebook qua Firebase Auth REST API hoặc OAuth Bridge.
 * Hoạt động bảo mật và nhẹ, không làm chậm khởi động app.
 */
export async function authenticateWithFirebase(provider, credentialData = {}) {
  const config = getFirebaseConfig();
  if (!isFirebaseConfigured()) {
    throw new Error('Chưa cấu hình Firebase API Key và Project ID. Vui lòng mở Cài đặt → Cấu hình Firebase để thiết lập.');
  }

  const endpoint = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${encodeURIComponent(config.apiKey)}`;
  
  // Format request payload according to Firebase IdentityToolkit v1
  const body = {
    requestUri: typeof window !== 'undefined' ? window.location.href : 'http://localhost',
    returnSecureToken: true,
    returnIdpCredential: true,
    ...credentialData
  };

  if (provider === 'google') {
    body.providerId = 'google.com';
  } else if (provider === 'facebook') {
    body.providerId = 'facebook.com';
  } else {
    throw new Error(`Nhà cung cấp ${provider} không được hỗ trợ.`);
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000)
  });

  const data = await response.json();
  if (!response.ok) {
    const msg = data?.error?.message || 'Đăng nhập Firebase thất bại.';
    if (msg.includes('CONFIGURATION_NOT_FOUND')) {
      throw new Error(`Nhà cung cấp ${provider} chưa được bật trong Firebase Console (Authentication → Sign-in method).`);
    }
    if (msg.includes('API_KEY_INVALID')) {
      throw new Error('Firebase API Key không hợp lệ. Vui lòng kiểm tra lại trong Cài đặt.');
    }
    throw new Error(msg);
  }

  const user = {
    uid: data.localId,
    email: data.email || '',
    displayName: data.displayName || (provider === 'google' ? 'Google Player' : 'Facebook Player'),
    photoUrl: data.photoUrl || '',
    provider,
    idToken: data.idToken,
    refreshToken: data.refreshToken
  };

  try {
    localStorage.setItem(FIREBASE_USER_KEY, JSON.stringify(user));
  } catch {}

  return user;
}

/**
 * Đồng bộ lịch sử ván đấu lên máy chủ / đám mây
 */
export async function syncHistoryToCloud(backendUrl, authToken, localGames = []) {
  if (!backendUrl || !authToken) {
    return {
      ok: false,
      message: 'Chưa đăng nhập tài khoản đám mây. Lịch sử vẫn được lưu an toàn trên máy.',
      games: localGames
    };
  }

  try {
    const cleanUrl = String(backendUrl).replace(/\/$/, '');
    const response = await fetch(`${cleanUrl}/api/social/history/sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authToken}`
      },
      body: JSON.stringify({ games: localGames }),
      signal: AbortSignal.timeout(12000)
    });

    if (!response.ok) {
      throw new Error(`Máy chủ trả về HTTP ${response.status}`);
    }

    const data = await response.json();
    const merged = Array.isArray(data.games) ? data.games : localGames;
    
    saveSyncMeta({
      lastSyncTime: new Date().toISOString(),
      syncedCount: merged.length,
      status: 'synced'
    });

    return {
      ok: true,
      syncedCount: merged.length,
      games: merged,
      message: `Đồng bộ thành công ${merged.length} ván đấu với đám mây.`
    };
  } catch (error) {
    console.warn('[CloudSync] Sync error:', error.message);
    saveSyncMeta({
      lastSyncTime: getSyncMeta().lastSyncTime,
      syncedCount: localGames.length,
      status: 'error',
      lastError: error.message
    });
    return {
      ok: false,
      message: `Không thể đồng bộ: ${error.message}. Lịch sử đã lưu trên máy an toàn.`,
      games: localGames
    };
  }
}
