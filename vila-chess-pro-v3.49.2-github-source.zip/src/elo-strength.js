/** Strength mapping for Stockfish UCI. UCI_Elo is supported from about 1320;
 * lower training targets map to native Skill Level 0–7 instead of choosing random or
 * material-only moves. These low presets are not advertised as calibrated Elo ratings. */
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));

export function clampTargetElo(value, fallback = 2600) {
  const n = Number(value);
  const safe = Number.isFinite(n) ? n : fallback;
  return Math.round(clamp(safe, 500, 3200));
}

export function resolveStockfishStrength(value) {
  const targetElo = clampTargetElo(value);
  if (targetElo < 1320) {
    // A progressive, native engine skill preset; no scripted blunders or random legal moves.
    const skillLevel = Math.round(((targetElo - 500) / (1320 - 500)) * 7);
    return { targetElo, limitStrength: false, uciElo: null, skillLevel: clamp(skillLevel, 0, 7), mode: 'skill-level-floor' };
  }
  return { targetElo, limitStrength: true, uciElo: Math.min(3190, targetElo), skillLevel: 20, mode: 'uci-elo' };
}
