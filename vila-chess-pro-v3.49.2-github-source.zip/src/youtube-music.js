// YouTube background music through the official IFrame Player API; no audio is downloaded or re-hosted.
// Online-only by design: a failed stream reports an error and never switches to offline background music.

/** Accepts watch / youtu.be / shorts / embed / live / music.youtube.com links, playlists, or a bare video id. */
export function parseYoutubeUrl(input) {
  const raw = String(input || '').trim();
  if (!raw) return null;
  if (/^[\w-]{11}$/.test(raw)) return { videoId: raw, listId: '' };
  let url;
  try { url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`); } catch { return null; }
  const host = url.hostname.toLowerCase().replace(/^www\.|^m\.|^music\./, '');
  if (host !== 'youtube.com' && host !== 'youtu.be' && host !== 'youtube-nocookie.com') return null;
  const list = url.searchParams.get('list') || '';
  const listId = /^[\w-]{10,60}$/.test(list) ? list : '';
  let videoId = '';
  if (host === 'youtu.be') videoId = url.pathname.split('/')[1] || '';
  else if (url.pathname === '/watch') videoId = url.searchParams.get('v') || '';
  else { const m = url.pathname.match(/^\/(?:embed|shorts|live|v)\/([\w-]{11})/); if (m) videoId = m[1]; }
  videoId = /^[\w-]{11}$/.test(videoId) ? videoId : '';
  if (!videoId && !listId) return null;
  return { videoId, listId };
}

export const YOUTUBE_PRESETS = Object.freeze([
  { id: 'lofi', label: '🌙 Lofi Girl · 24/7', url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk' },
  { id: 'sad', label: '🌧️ Sad & sleepy lofi', url: 'https://www.youtube.com/watch?v=l7TxwBhtTUY' },
  { id: 'chillhop', label: '☁️ Chillhop · chill beats', url: 'https://www.youtube.com/watch?v=5yx6BWlEVcY' },
  { id: 'synth', label: '🎧 Synthwave remix', url: 'https://www.youtube.com/watch?v=4xDzrJKXOOY' }
]);

let apiPromise = null;
let player = null;
let current = null;
let errorHandler = null;
let card = null;

function loadApi() {
  if (typeof window === 'undefined') return Promise.reject(new Error('Không có trình duyệt.'));
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (apiPromise) return apiPromise;
  apiPromise = new Promise((resolve, reject) => {
    const previous = window.onYouTubeIframeAPIReady;
    const timer = setTimeout(() => { apiPromise = null; reject(new Error('Không tải được YouTube (cần internet).')); }, 12000);
    window.onYouTubeIframeAPIReady = () => { clearTimeout(timer); try { previous?.(); } catch {} resolve(window.YT); };
    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    script.async = true;
    script.onerror = () => { clearTimeout(timer); apiPromise = null; reject(new Error('Không tải được YouTube (cần internet).')); };
    document.head.appendChild(script);
  });
  return apiPromise;
}

function ensureCard() {
  if (card && document.body.contains(card)) return card;
  card = document.createElement('div');
  card.id = 'vilaYtCard';
  card.className = 'yt-music-card is-collapsed';
  card.innerHTML = '<div class="yt-music-bar"><span>♪ YouTube</span><button type="button" id="vilaYtToggle" aria-label="Hiện hoặc thu gọn video">▾</button><button type="button" id="vilaYtClose" aria-label="Tắt YouTube">✕</button></div><div id="vilaYtPlayerHost"></div>';
  document.body.appendChild(card);
  card.querySelector('#vilaYtToggle').addEventListener('click', () => {
    const collapsed = card.classList.toggle('is-collapsed');
    card.querySelector('#vilaYtToggle').textContent = collapsed ? '▾' : '▴';
  });
  card.querySelector('#vilaYtClose').addEventListener('click', () => { stopYoutube(); try { window.dispatchEvent(new CustomEvent('vila:youtube-closed')); } catch {} });
  return card;
}

export function onYoutubeError(handler) { errorHandler = typeof handler === 'function' ? handler : null; }
export function isYoutubeActive() { return Boolean(current); }

export async function playYoutube(source, { volume = 40 } = {}) {
  const parsed = typeof source === 'string' ? parseYoutubeUrl(source) : source;
  if (!parsed) throw new Error('Link YouTube không hợp lệ.');
  const YT = await loadApi();
  ensureCard();
  current = parsed;
  const vars = { autoplay: 1, playsinline: 1, controls: 1, rel: 0, modestbranding: 1 };
  if (parsed.listId) { vars.list = parsed.listId; vars.listType = 'playlist'; vars.loop = 1; }
  else vars.playlist = parsed.videoId, vars.loop = 1; // a one-video "playlist" makes loop work
  if (player?.loadVideoById) {
    try {
      if (parsed.listId && !parsed.videoId) player.loadPlaylist({ list: parsed.listId, listType: 'playlist' });
      else if (parsed.listId) player.loadPlaylist({ list: parsed.listId, listType: 'playlist', index: 0 });
      else player.loadVideoById(parsed.videoId);
      player.setVolume?.(volume); player.playVideo?.();
      return true;
    } catch { try { player.destroy(); } catch {} player = null; }
  }
  await new Promise((resolve, reject) => {
    const host = card.querySelector('#vilaYtPlayerHost');
    host.innerHTML = '<div id="vilaYtPlayer"></div>';
    player = new YT.Player('vilaYtPlayer', {
      width: '220', height: '124', ...(parsed.videoId && !parsed.listId ? { videoId: parsed.videoId } : {}), playerVars: vars,
      events: {
        onReady: event => { try { event.target.setVolume(volume); event.target.playVideo(); } catch {} resolve(); },
        onStateChange: event => { if (event.data === 0 && !current?.listId) { try { event.target.seekTo(0); event.target.playVideo(); } catch {} } },
        onError: event => { const code = Number(event?.data) || 0; const message = [101, 150].includes(code) ? 'Video này không cho phép phát nhúng.' : code === 100 ? 'Video không tồn tại hoặc ở chế độ riêng tư.' : 'YouTube không phát được video này.'; try { errorHandler?.(new Error(message)); } catch {} reject(new Error(message)); }
      }
    });
  });
  return true;
}

export function stopYoutube() {
  current = null;
  try { player?.stopVideo?.(); } catch {}
  try { player?.destroy?.(); } catch {}
  player = null;
  if (card) { card.remove(); card = null; }
}
