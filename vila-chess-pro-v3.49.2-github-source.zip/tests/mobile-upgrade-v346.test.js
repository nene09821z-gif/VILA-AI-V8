import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const index = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const sound = fs.readFileSync(new URL('../src/sound.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8') + '\n' + fs.readFileSync(new URL('../src/vila-polish.css', import.meta.url), 'utf8') + '\n' + fs.readFileSync(new URL('../src/mobile-upgrade.css', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('v3.49.2 live match keeps time selection in setup and uses one collapsed tools menu', () => {
  assert.equal(pkg.version, '3.49.2');
  assert.match(main, /import '\.\/mobile-upgrade\.css';/);
  assert.match(main, /<details class=\"board-extra-menu\">/);
  const setup = main.slice(main.indexOf('function renderMatchSetupView()'), main.indexOf('function renderPlayView()'));
  const play = main.slice(main.indexOf('function renderPlayView()'), main.indexOf('function renderOpeningsView()'));
  assert.match(setup, /id=\"clockPreset\"/);
  for (const preset of ['1+0', '3+2', '10+0', '15+10']) assert.ok(setup.includes(`['${preset}'`), `missing setup preset ${preset}`);
  assert.doesNotMatch(play, /id=\"clockPreset\"|mobile-time-presets|clock-setting-inline|class=\"mobile-action-row match-action-bar\"/);
  for (const id of ['undoMove', 'redoMove', 'hintMove', 'flipBoard', 'toggleChessMusic', 'offerDrawBtn', 'resignBtn', 'newGame']) assert.ok(play.includes(`id=\"${id}\"`), `tool action ${id} is missing`);
  assert.doesNotMatch(main, /<div class=\"opening-recognition\"/);
  assert.doesNotMatch(main, /<section class=\"hint-card\"/);
  assert.match(css, /board-extra-menu/);
  assert.match(css, /#hintArrowHead path \{ fill: #2563eb/);
});

test('mobile bottom destinations expose play, matchmaking, puzzles and More', () => {
  assert.match(index, /data-view="play" type="button"><i>♟<\/i><span>Chơi<\/span>/);
  assert.match(index, /data-view="ranked" type="button"><i>⚔<\/i><span>Ghép trận<\/span>/);
  assert.match(index, /data-view="puzzles" type="button"><i>✦<\/i><span>Câu đố<\/span>/);
  assert.match(index, /id="bottomMore"/);
});

test('background music is online-only and provides lofi, sad chill and remix-style choices', () => {
  assert.doesNotMatch(sound, /Gymnopedie_No\._1|CLASSICAL_MUSIC_URL|musicAudio|startSynthMusic\(|const melody =/i);
  for (const id of ['lofi', 'sad', 'chillhop', 'synth']) assert.match(sound, new RegExp(`${id}: \\{`));
  assert.match(sound, /external: true/);
  assert.match(sound, /vila:music-error/);
});
