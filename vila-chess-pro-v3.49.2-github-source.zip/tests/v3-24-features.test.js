import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseYoutubeUrl, YOUTUBE_PRESETS } from '../src/youtube-music.js';
import { BOT_REPERTOIRES, repertoireLines } from '../src/bot-personas.js';
import { PIECE_SHAPES, pieceSvgMarkup } from '../src/pieces.js';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');
const main = read('../src/main.js');
const html = read('../index.html');
const core = read('../src/alternate-engine-core.js');

test('Royal piece set draws all six pieces for both colours and is present in index.html', () => {
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    assert.ok(PIECE_SHAPES[type].body.length > 40);
    for (const color of ['w', 'b']) assert.match(pieceSvgMarkup({ type, color }, 'royal'), new RegExp(`url\\(#vp-grad-${color}\\)`));
  }
  assert.equal(pieceSvgMarkup({ type: 'x', color: 'w' }), '');
  assert.match(html, /id="vp-grad-w"/);
  assert.match(html, /id="vp-grad-b"/);
});

test('YouTube parser accepts real YouTube links only', () => {
  assert.deepEqual(parseYoutubeUrl('https://www.youtube.com/watch?v=jfKfPfyJRdk'), { videoId: 'jfKfPfyJRdk', listId: '' });
  assert.deepEqual(parseYoutubeUrl('https://youtu.be/jfKfPfyJRdk?t=5'), { videoId: 'jfKfPfyJRdk', listId: '' });
  assert.equal(parseYoutubeUrl('https://youtube.com/playlist?list=PLabcdefghij12').listId, 'PLabcdefghij12');
  assert.equal(parseYoutubeUrl('https://evil.example/watch?v=jfKfPfyJRdk'), null);
  assert.equal(parseYoutubeUrl('not a link'), null);
  for (const preset of YOUTUBE_PRESETS) assert.ok(parseYoutubeUrl(preset.url));
});

test('every offline engine has a repertoire and YouTube music is wired into the player', () => {
  for (const id of ['lc0', 'ethereal', 'berserk', 'fortress', 'endgame', 'dynamic', 'blitz', 'gambit', 'hyper', 'strangler', 'trickster', 'rookie', 'classic']) {
    assert.ok(BOT_REPERTOIRES[id], `missing repertoire for ${id}`);
    if (id !== 'classic') assert.ok(core.includes(`id: '${id}'`));
  }
  const sample = [
    { name: "King's Gambit", san: ['e4', 'e5', 'f4'] }, { name: 'Italian Game', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'] },
    { name: "Queen's Gambit", san: ['d4', 'd5', 'c4'] }, { name: 'English', san: ['c4', 'e5'] }, { name: 'Reti', san: ['Nf3', 'd5', 'c4'] }
  ];
  assert.ok(repertoireLines(sample, 'gambit', 'w').every(line => ['e4', 'd4', 'c4'].includes(line.san[0])));
  assert.ok(repertoireLines(sample, 'hyper', 'w').every(line => ['Nf3', 'c4', 'g3', 'b3'].includes(line.san[0])));
  assert.match(main, /setChessMusicYoutube\(parsed/);
  assert.match(main, /id="ytMusicUrl"/);
  assert.match(main, /pickPersonaBookMove\(game, profile, OPENINGS/);
  assert.match(main, /pickPersonaBookMove\(chess, profile, OPENINGS/);
});

test('random Trắng/Đen is the default for bot games and a toggle exists for the arena', () => {
  assert.match(main, /let colorChoice = 'random'/);
  assert.match(main, /let arenaRandomSides = true/);
  assert.match(main, /id="arenaRandomSides"/);
  assert.ok(main.indexOf('value="random"') < main.indexOf('value="w" ${colorChoice'), 'random must be the first option');
});

test('flat 2D piece style uses the supplied detailed artwork for all piece colours', () => {
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    for (const color of ['w', 'b']) {
      const markup = pieceSvgMarkup({ type, color }, 'flat');
      assert.match(markup, /piece-set-flat/);
      assert.match(markup, new RegExp(`src=\"\.\/pieces\/${color}_${type}\.png\"`));
      assert.ok(read(`../public/pieces/${color}_${type}.png`).length > 1000, `missing ${color}_${type} artwork`);
    }
  }
  assert.match(main, /id="pieceStyleSetting"/);
});
