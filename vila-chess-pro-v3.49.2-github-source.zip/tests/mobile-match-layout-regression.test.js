import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/style.css'), 'utf8') + '\n' + fs.readFileSync(path.join(root, 'src/vila-polish.css'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('new-player chooser is visible before the board on narrow screens', () => {
  assert.match(main, /function renderPrestartExperiencePanel\(\)/);
  assert.match(main, /<section class="prestart-experience-card"/);
  assert.match(main, /data-experience-choice="beginner">Mới chơi/);
  assert.match(main, /data-experience-choice="experienced">Đã hiểu luật/);
  assert.match(main, /\$\{renderPrestartExperiencePanel\(\)\}/);
  assert.match(css, /\.prestart-experience-card/);
  assert.match(main, /id="startGameOverlay"/);
});

test('changing views resets scroll and keeps the opponent card from hiding under the header', () => {
  assert.match(main, /const previousView = currentView/);
  assert.match(main, /if \(view !== previousView\) window\.scrollTo\(0, 0\)/);
  assert.match(main, /if \(returningToPlay\) window\.scrollTo\(0, 0\)/);
});

test('layout version and compact single-toggle game tools match the new live-match design', () => {
  assert.equal(pkg.version, '3.49.2');
  assert.match(css, /body\.play-screen-active:not\(\.match-setup-active\) #app \{ padding-bottom:16px!important; \}/);
  assert.match(css, /body\.play-screen-active:not\(\.match-setup-active\) \.board-bottom-actions \{ width:min\(310px,calc\(100vw - 24px\)\); grid-template-columns:repeat\(3,minmax\(0,1fr\)\); gap:6px; \}/);
  assert.match(main, /<details class=\"board-extra-menu\">/);
  assert.doesNotMatch(main.slice(main.indexOf('function renderPlayView()'), main.indexOf('function renderOpeningsView()')), /class=\"mobile-action-row match-action-bar\"/);
});
