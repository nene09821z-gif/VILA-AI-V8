import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const generator = fs.readFileSync(new URL('../src/puzzle-generator.js', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('offline puzzle generator rejects quiet positional moves as puzzle answers', () => {
  assert.match(generator, /A puzzle must present a visible tactical task/);
  assert.match(generator, /!rootMove\.captured && !rootMove\.promotion && !info\.mateInOne/);
  assert.match(generator, /if \(!played \|\| !probe\.isCheck\(\)\) continue/);
});

test('Stockfish fallback only accepts tactical candidates instead of the last random move', () => {
  assert.match(main, /if \(!tactical\) continue;\s*chosen = \{ position, best, tactical \};\s*break;/);
  assert.doesNotMatch(main, /if \(tactical \|\| attempt === 6\) break/);
});

test('puzzle history is supplemented with in-session exclusions', () => {
  assert.match(main, /const puzzleSessionSeen = new Set\(\)/);
  assert.match(main, /\[\.\.\.new Set\(\[\.\.\.loadPuzzleHistory\(\), \.\.\.puzzleSessionSeen\]\)\]/);
  assert.match(main, /puzzleSessionSeen\.add\(offline\.fen\.trim\(\)\.split/);
});


test('puzzle room exposes classic, daily, rush and survival modes with stale-generation guards', () => {
  const activeMain = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  const dailyGenerator = fs.readFileSync(new URL('../src/puzzle-generator.js', import.meta.url), 'utf8');
  const client = fs.readFileSync(new URL('../src/puzzle-worker-client.js', import.meta.url), 'utf8');
  for (const mode of ['classic', 'daily', 'rush', 'survival']) assert.match(activeMain, new RegExp(`data-puzzle-mode=\\"${mode}\\"`));
  assert.match(activeMain, /function finishPuzzleRush\(\)/);
  assert.match(activeMain, /function pausePuzzleRushTimer\(\)/);
  assert.match(activeMain, /function resumePuzzleRushTimer\(\)/);
  assert.match(activeMain, /generationToken !== puzzleGenerationEpoch/);
  assert.match(activeMain, /PUZZLE_DAILY_SOLVED_KEY/);
  assert.match(activeMain, /PUZZLE_RUSH_BEST_KEY/);
  assert.match(dailyGenerator, /function createSeededRandom/);
  assert.match(dailyGenerator, /export function generateDailyMatePuzzle/);
  assert.match(client, /generateDailyPuzzleInWorker/);
});
