import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8') + '\n' + fs.readFileSync(new URL('../src/vila-polish.css', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server/index.js', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('Live match removes the fixed action bar and preserves phone safe-area navigation space', () => {
  assert.match(main, /body\.classList\.toggle\('play-screen-active', currentView === 'play'\)/);
  assert.match(css, /body\.play-screen-active:not\(\.match-setup-active\) \.match-action-bar \{ display:none!important; \}/);
  assert.match(css, /@media\(max-width:820px\)\{body\.play-screen-active:not\(\.match-setup-active\) #app \{ padding-bottom:calc\(72px \+ env\(safe-area-inset-bottom,0px\)\)!important; \}\}/);
  assert.match(css, /env\(safe-area-inset-bottom/);
});

test('Mobile game setup uses a compact disclosure instead of a permanently tall panel', () => {
  assert.match(main, /function renderMatchSetupView\(\)/);
  assert.match(main, /<label class="field-label" for="clockPreset">5 · Thời gian mỗi bên/);
  assert.doesNotMatch(main.slice(main.indexOf('function renderPlayView()'), main.indexOf('function renderOpeningsView()')), /id="clockPreset"|class="mobile-time-presets/);
  assert.match(main, /<details class="panel moves-panel match-moves-details"/);
  assert.match(main, /<details class="board-extra-menu"/);
});

test('Chess input is delegated, drag rendering is frame-coalesced, and tap fallback is explicit', () => {
  assert.match(main, /function wireBoardSquareClicks\(board\)/);
  assert.match(main, /dragMoveFrame = requestAnimationFrame/);
  assert.match(main, /handleSquareClick\(state\.from\)/);
  assert.match(main, /new Map\(\$\$\('\.square\[data-square\]', board\)\.map/);
  assert.match(css, /\.square,\.chessboard\{touch-action:none/);
  const clickStart = main.indexOf('function handleSquareClick(');
  const clickEnd = main.indexOf('\nfunction choosePromotion', clickStart);
  const clickHandler = main.slice(clickStart, clickEnd);
  assert.match(clickHandler, /updateDragSelection\(board, selected, selectedTargets\)/);
});

test('One player move triggers one primary view refresh instead of two consecutive redraws', () => {
  const start = main.indexOf('function onMoveComplete()');
  const end = main.indexOf('\nfunction resignCurrentGame()', start);
  const fn = main.slice(start, end);
  assert.equal((fn.match(/renderView\(\)/g) || []).length, 1);
});

test('Offline arena and analysis no longer depend on language-model provider responses', () => {
  assert.match(main, /chooseArenaUci/);
  assert.match(main, /requestStockfishUci/);
  assert.match(main, /Phân tích 3 biến bằng Stockfish/);
  assert.doesNotMatch(main, /\/api\/ai\/(?:chat|models)|requestAiMove|requestCoach\(/);
  assert.equal(pkg.version, '3.49.2');
});

test('Synthetic touch-click suppression is scoped to one square and a short window', () => {
  assert.match(main, /let suppressSquareClick = null/);
  assert.match(main, /Date\.now\(\) <= suppress\.until && square\.dataset\.square === suppress\.square/);
  assert.match(main, /suppressSquareClick = \{ square: state\.from, until: Date\.now\(\) \+ 160 \}/);
  assert.doesNotMatch(main, /suppressSquareClickUntil = Date\.now\(\) \+ 450/);
});

test('Offline Stockfish MultiPV and puzzle progression replace provider retry logic', () => {
  assert.match(main, /multiPv = 1/);
  assert.match(main, /requestedMultiPv/);
  assert.match(main, /Math\.min\(4, Math\.floor\(saved \/ 5\)\)/);
  assert.match(main, /puzzleStageLabel/);
});

test('Drag ghost uses a compositor-friendly transform without per-frame shadow filters', () => {
  assert.match(css, /\.drag-ghost\{[^}]*will-change:transform[^}]*backface-visibility:hidden/);
  assert.match(css, /\.drag-ghost\{left:0;top:0;will-change:transform;filter:none\}/);
  assert.match(main, /lostpointercapture/);
  assert.match(main, /epoch: gameEpoch, fen: game\.fen\(\), moved: false/);
  assert.match(main, /state\.epoch !== gameEpoch \|\| state\.fen !== game\.fen\(\)/);
});

test('Stockfish warm-up waits before using the tactical fallback and normal go has no redundant stop', () => {
  const start = main.indexOf('function askStockfishMove()');
  const end = main.indexOf('\nfunction requestOfflineRescueMove(', start);
  const fn = main.slice(start, end);
  assert.match(fn, /waitingForStockfishMove = waiting/);
  assert.match(fn, /Stockfish (?:19|đang khởi tạo|khởi tạo)/);
  assert.match(fn, /waitingForStockfishMove = waiting/);
  assert.match(fn, /Math\.max\(500, Math\.min\(5000, Number\(settings\.botMoveTimeMs\) \|\| 2600\)\)/);
  assert.doesNotMatch(fn, /engineWorker\.postMessage\('stop'\)/);
  assert.match(main, /if \(waitingForStockfishMove\) \{[\s\S]{0,500}scheduleBotMove\(0\)/);
});


test('Live match keeps clock selection in setup and puts secondary actions behind one toggle', () => {
  const play = main.slice(main.indexOf('function renderPlayView()'), main.indexOf('function renderOpeningsView()'));
  const setup = main.slice(main.indexOf('function renderMatchSetupView()'), main.indexOf('function renderPlayView()'));
  assert.match(setup, /id="clockPreset"/);
  assert.doesNotMatch(play, /id="clockPreset"|mobile-time-presets|clock-setting-inline/);
  assert.match(play, /<details class="board-extra-menu"/);
  for (const id of ['undoMove','redoMove','hintMove','clearBoardSelection','toggleChessMusic','offerDrawBtn','resignBtn','newGame']) assert.match(play, new RegExp(`id="${id}"`));
  assert.doesNotMatch(play, /class="mobile-action-row match-action-bar"/);
});

test('Drag path is frame-coalesced, avoids all-square clearing, and skips network opening queries per move', () => {
  const start = main.indexOf('function wireBoardPointerDrag(');
  const end = main.indexOf('\nfunction getGameResult()', start);
  const drag = main.slice(start, end);
  assert.match(drag, /requestAnimationFrame\(\(\) =>/);
  assert.match(drag, /current\.legal\.some\(move => move\.to === hover\)/);
  assert.doesNotMatch(drag, /querySelectorAll\(['"]\.square/);
  const completeStart = main.indexOf('function onMoveComplete()');
  const completeEnd = main.indexOf('\nfunction resignCurrentGame()', completeStart);
  assert.doesNotMatch(main.slice(completeStart, completeEnd), /queryOpeningExplorer/);
});
