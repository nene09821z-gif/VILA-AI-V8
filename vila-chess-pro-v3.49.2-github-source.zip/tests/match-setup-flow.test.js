import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
// Slim GitHub ZIPs omit duplicated static files under app/src/main/assets; fall back to public/.
const readAndroid = file => {
  const androidPath = path.join(root, file);
  if (fs.existsSync(androidPath)) return fs.readFileSync(androidPath, 'utf8');
  return read(file.replace('app/src/main/assets/', 'public/'));
};

test('a separate match setup is rendered before the chessboard', () => {
  const main = read('src/main.js');
  assert.match(main, /function renderMatchSetupView\(\)/);
  assert.match(main, /function renderPlayView\(\)\s*\{\s*if \(!gameStarted\) return renderMatchSetupView\(\);/);
  const setup = main.slice(main.indexOf('function renderMatchSetupView()'), main.indexOf('function renderPlayView()'));
  for (const id of ['modeSelect', 'gameBotProfile', 'colorSelect', 'skillSelect', 'clockPreset', 'randomBotElo', 'startGameOverlay']) {
    assert.ok(setup.includes(`id="${id}"`), `setup screen missing ${id}`);
  }
  assert.match(setup, /Bàn cờ sẽ xuất hiện khi bạn bắt đầu/);
});

test('new match and replay controls route back through setup instead of creating a game immediately', () => {
  const main = read('src/main.js');
  assert.match(main, /function openMatchSetup\(\)/);
  assert.match(main, /gameStarted = false;\s*setView\('play'\)/);
  assert.match(main, /\$\('#newGame'\)\?\.addEventListener\('click', openMatchSetup\)/);
  assert.match(main, /\$\('#restartGameBtn'\)\?\.addEventListener\('click', openMatchSetup\)/);
  assert.match(main, /\$\('#gameShowSetup'\)\?\.addEventListener\('click', openMatchSetup\)/);
});

test('Android build stages canonical web assets from public and keeps the separate setup flow', () => {
  const html = read('index.html');
  const gradle = read('app/build.gradle.kts');
  const css = read('src/style.css') + '\n' + read('src/vila-polish.css');
  const main = read('src/main.js');
  assert.match(html, /Atelier Chess v3\.49\.2/);
  assert.match(gradle, /from\(publicDir\)/);
  assert.match(gradle, /stagePublicAssetsForAndroid/);
  assert.match(main, /function renderMatchSetupView\(\)/);
  assert.match(css, /body\.match-setup-active/);
});
