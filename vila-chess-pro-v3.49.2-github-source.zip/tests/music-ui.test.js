import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const index = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const sound = fs.readFileSync(new URL('../src/sound.js', import.meta.url), 'utf8');
const youtube = fs.readFileSync(new URL('../src/youtube-music.js', import.meta.url), 'utf8');

test('Music controls are shared across views and respect browser gesture restrictions', () => {
  assert.match(index, /id="appMusicToggle"/);
  assert.match(main, /id="homeToggleChessMusic"/);
  assert.match(main, /id="toggleChessMusic"/);
  assert.match(main, /document\.addEventListener\('pointerdown', handleMusicAutostartGesture/);
  assert.match(main, /musicAutostartHandled = true;[\s\S]*?setChessMusicPlaying\(true\)/);
  assert.match(main, /id="musicAutostartSetting"/);
  assert.match(main, /localStorage\.setItem\(MUSIC_AUTOSTART_KEY, String\(musicAutostart\)\)/);
  assert.match(main, /youtube\.com\/results\?search_query=/);
  assert.doesNotMatch(sound, /Gymnopedie_No\._1|CLASSICAL_MUSIC_URL|musicAudio/);
  assert.doesNotMatch(sound, /startSynthMusic\(|startSynthMusic\s*=|const melody =/i, 'background music must be online-only');
  assert.match(main, /id="musicTrackSetting"/);
  assert.match(main, /setChessMusicTrack\(event\.target\.value\)/);
  for (const id of ['lofi','sad','chillhop','synth']) assert.match(sound, new RegExp(`${id}: \{`));
  assert.match(main, /saved === null \? true/);
  assert.match(main, /Không tải nhạc ngoại tuyến/);
  assert.match(youtube, /Sad & sleepy lofi/);
});
