import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

test('Pencil toolbar is outside the board, compact and stable in normal flow', () => {
  const board = main.indexOf('<div class="board-frame">');
  const meter = main.indexOf('<div class="evaluation-meter-row"', board);
  const toolbar = main.indexOf('<div class="board-annotation-toolbar-row">', board);
  const widget = main.indexOf('id="boardAnnotationWidget"', board);
  assert.ok(board >= 0 && meter > board && toolbar > board && widget > toolbar);
  assert.doesNotMatch(main.slice(board, toolbar), /boardAnnotationWidget/);
  assert.match(main.slice(toolbar, meter), /id="annotationWidgetToggle"/);
  assert.match(main.slice(toolbar, meter), /data-annotation-tool="arrow"/);
  assert.match(main.slice(toolbar, meter), /data-annotation-tool="circle"/);
  assert.match(main.slice(toolbar, meter), /id="annotationColorCycle"/);
  assert.match(main.slice(toolbar, meter), /id="annotationClear"/);
  assert.doesNotMatch(main, /annotationWidgetGrip|annotationWidgetPosition = readSocialCache/);
  assert.match(css, /\.board-annotation-toolbar-row\{position:relative!important/);
  assert.match(css, /\.board-annotation-widget\{position:relative!important;inset:auto!important/);
  assert.match(css, /#engineStatus::after\{content:none!important/);
  assert.match(css, /\.engine-status-knight/);
});
