# QA report — Cờ Vua ViLa v3.49.2

## Scope reviewed

- Mobile live-match layout: clock controls remain in the separate match-setup view; in-game secondary actions are grouped under one collapsed `Công cụ` menu; move history uses a separate disclosure.
- Piece input: delegated pointer events, drag threshold before legal-target work, pointer movement coalesced with `requestAnimationFrame`, cached board geometry, cloned existing piece artwork, and only the previous/current hover square updated.
- Move path: removed an automatic opening-explorer network request from the per-move path to avoid coupling board responsiveness to a network call.
- Music: synthetic/offline background music is not offered; music presets point to online YouTube streams for lofi, sad/chill lofi, Chillhop and synthwave/remix-style. Music needs internet. Browser/WebView policy can prevent audible autoplay until a user gesture, so auto-start is best-effort rather than guaranteed.

## Tests executed in this review

- Focused layout/input/music/setup tests: **21/21 passed** (`mobile-match-layout-regression`, `mobile-performance`, `match-setup-flow`, `music-ui`, `move-input`).
- `npm run test:static`: **269 passed, 1 failed out of 270 test files/tests**. The only failure is `tests/premove.test.js` failing to import `chess.js` because the dependency installation could not complete; npm registry requests returned `EAI_AGAIN`.
- `node --check` across `src`, `server`, `scripts`, and `tests`: **136/136 JavaScript/MJS files passed**.
- ZIP CRC check: performed when packaging the GitHub-source ZIP; see the delivered archive and its `.sha256` file.

## Not verified / blockers

- A live interactive browser preview could not be completed in this environment. The installed headless Chromium hung even on a simple `data:` HTML page, so this is an environment limitation; no static mockup is being represented as a live gameplay preview.
- `npm run build` was attempted and stopped in `prebuild` because `chess.js` was not installed. `npm ci` could not fetch required packages from `registry.npmjs.org` (`EAI_AGAIN`). A fresh Vite production build therefore was not produced here.
- No real drag test, frame-time measurement, or visual confirmation was made on a physical OPPO A17k. The code changes reduce known DOM/network work in the drag path, but complete elimination of lag is **not verified**.
- No APK was built in this review. Use the included GitHub Actions workflow to install dependencies, run the required test gate, build web assets and build the APK; a failed test/build must be resolved rather than bypassed.
- Online music streams and their embed availability were not tested against the live YouTube service in this offline environment.
