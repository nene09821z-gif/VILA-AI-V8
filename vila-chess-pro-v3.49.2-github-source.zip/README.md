# Cờ Vua ViLa v3.49.2 — gọn giao diện trận, tối ưu đường kéo quân và nhạc nền trực tuyến

## v3.49.2 — giao diện phòng đấu gọn, thao tác kéo quân và nhạc trực tuyến

- Chọn thời gian chỉ xuất hiện ở màn Thiết lập trận đấu; đồng hồ đang chạy vẫn hiển thị trên thẻ người chơi.
- Gộp hoàn tác/làm lại/gợi ý/đảo bàn/nhạc/xin hòa/đầu hàng/ván mới vào menu Công cụ có thể thu gọn.
- Giảm công việc DOM trong đường kéo quân, dùng lại SVG quân đang hiển thị và chỉ dọn ô kéo hiện hành.
- Nhạc nền chuyển sang các luồng trực tuyến lofi/chillhop/sad chill/synthwave; yêu cầu mạng và tương tác người dùng khi WebView chặn autoplay.
- Báo cáo QA và các giới hạn xác minh: [`TEST_REPORT_V3_49_2.md`](TEST_REPORT_V3_49_2.md).

### Đưa ZIP lên GitHub từ điện thoại

1. Tải `vila-chess-v3.49.2-match-ui-drag-music-fix.zip` và tải ZIP này lên thư mục gốc của repository.
2. Nếu repository vẫn dùng workflow từ bản cũ, hãy thay `.github/workflows/build-from-zip.yml` bằng file cùng tên trong bản v3.49.2 **một lần nếu workflow của repository đã quá cũ**. Workflow cũ không tự giải nén ZIP chỉ vì ZIP được tải lên.
3. Mở tab **Actions** → **Cờ Vua ViLa build from ZIP/source** → **Run workflow**. Workflow mới tự giải nén ZIP nguồn mới nhất trong repository, cài dependencies, test và build.
4. Khi build hoàn tất, tải artifact `covua-vila-debug-apk` trong trang chạy workflow. Nếu test hoặc build lỗi, mở Summary để xem nguyên nhân; workflow không giả vờ tạo APK thành công.


## v3.47.2 — Stockfish 10 nhanh hơn và gói ZIP gọn hơn

- Giới hạn Stockfish 10 ở khoảng 0,2–0,6 giây/nước trong Đấu trường; giới hạn tối đa 0,5 giây/nước khi đấu người.
- Rút timeout khởi tạo và watchdog của engine cũ để không bị chờ quá lâu; khi engine cũ treo, ứng dụng có thể chuyển sang đường dự phòng sớm hơn.
- Giữ Stockfish 10 để so sánh; chế độ phân tích vẫn dùng cấu hình riêng.
- Gói AI Studio 6,3 MB chỉ được lưu một lần trong mã nguồn; Gradle tự chép vào tài nguyên Android khi build.
- Nâng phiên bản ứng dụng lên 3.47.2 và làm mới cache Service Worker.
- Báo cáo QA bản hiện tại: `TEST_REPORT_V3_47_2.md`.

## v3.47.1 — bỏ Stockfish 10 khỏi mặc định và giảm thời gian mỗi nước

- Đấu trường mặc định dùng Stockfish 19 Lite cùng ViLa Rookie; Stockfish 10 cũ còn ở lựa chọn thủ công để so sánh.
- Ngân sách Đấu trường được giảm: SF19 dùng 0,7–1,5 giây/nước, SF10 dùng 0,3–1,2 giây/nước, thời gian nghỉ mặc định 0,15 giây.
- Đồng bộ thay đổi vào JS bundle Android hiện có; xem `TEST_REPORT_V3_47_1.md`. Đây chưa phải APK mới được build sạch trên máy thật.

## v3.47.0 — bảng màu xanh dương/cyan, theme bàn cờ và Docker

- Đồng bộ màu giao diện theo logo: navy đậm, xanh dương làm màu chính, cyan làm điểm nhấn và vàng dành cho phần thưởng.
- Sửa CSS bàn cờ dùng biến `--board-*`, tránh ép màu bằng `!important` khiến theme do người dùng chọn không đổi được.
- Đồng bộ CSS được đóng gói trong Android, cache-bust biểu tượng/stylesheet và Service Worker cache lên v3.47.0.
- Thêm `Dockerfile` và `.dockerignore`; bản Docker cài dependency trước khi copy mã nguồn để script `postinstall` không chạy quá sớm.
- QA hiện tại: xem [`TEST_REPORT_V3_46_4.md`](TEST_REPORT_V3_46_4.md). Bản ZIP **không phải APK đã build**; cần cài dependencies và hoàn tất build Android trên môi trường có mạng/Android SDK.
- Kết quả đo được trong môi trường offline: `npm run test:static` 266/266 đạt; kiểm tra cú pháp JavaScript/MJS 132/132 đạt. `npm test` còn 4 test không nạp được `chess.js`/`express`; build web, Docker và APK chưa được xác minh trong phiên này.

## v3.46.1 — rà soát bản phát hành và khôi phục dữ liệu khai cuộc dự phòng

- Đồng bộ metadata bản phát hành và cache-bust favicon; sửa thứ tự lịch sử changelog/README và tiêu đề nguồn câu đố.
- Thay `public/openings-eco.json` rỗng bằng 338 dòng khai cuộc dự phòng đã loại trùng. Dữ liệu này không được gắn nhãn nhầm là kho Lichess CC0 đầy đủ.
- Chặn pipeline phát hành nếu kho khai cuộc trong source hoặc `dist` chưa đạt tối thiểu 3.000 dòng hợp lệ; sửa thông báo khi JSON chỉ có biến trùng.
- Kết quả kiểm thử dữ liệu khai cuộc nằm trong [`TEST_REPORT_V3_46_1.md`](TEST_REPORT_V3_46_1.md).

---

## v3.46.0 — giao diện mobile, đồng hồ nhanh và phòng đấu gọn hơn

- Gom các tác vụ thiết lập, danh sách nước, phân tích và khai cuộc vào menu **Công cụ**; bỏ dải nút chức năng dài trùng lặp trên màn hình chơi.
- Bỏ nhãn nhận diện khai cuộc ngay dưới bàn cờ và thẻ gợi ý màu vàng. Gợi ý vẫn đánh dấu nước đi bằng mũi tên trên bàn cờ và thông báo ngắn.
- Thêm lối chọn nhanh Siêu chớp 30 giây, Bullet 1+0, Blitz 3+2 và Rapid 10+0; các mốc khác vẫn ở mục thiết lập.
- Làm gọn thanh điều hướng nhỏ, giữ nút tài khoản dễ truy cập và thêm thẻ ghép trận người thật trong trang chủ.
- Loại bỏ bản nhạc Gymnopédie cũ khỏi nhạc tích hợp; thay bằng các chủ đề tổng hợp nguyên bản chạy offline. Nhạc bên ngoài chỉ phát khi người dùng chủ động chọn.
- Chưa coi ghép trận online là hoạt động thật chỉ dựa vào giao diện: cần triển khai backend và có đối thủ đang chờ. APK không được coi là đã build thành công nếu chưa chạy pipeline Android.

### QA v3.46.0 (lịch sử)

Xem [`TEST_REPORT_V3_46_0.md`](TEST_REPORT_V3_46_0.md) để đối chiếu kết quả của bản trước. Báo cáo kiểm thử của bản hiện tại là [`TEST_REPORT_V3_46_4.md`](TEST_REPORT_V3_46_4.md); [`TEST_REPORT_V3_46_1.md`](TEST_REPORT_V3_46_1.md) là báo cáo lịch sử.
---

## v3.45.0 — sửa an toàn thao tác và phục hồi engine offline

- Đồng hồ dùng phép tính tick thuần, có kiểm tra thời gian lùi, giá trị không hợp lệ và chặn về 0; trạng thái đã kết thúc không tiếp tục trừ thời gian.
- Hộp chọn phong cấp chụp ô đi, FEN và phiên ván; nếu bàn cờ đổi trong lúc hộp thoại đang mở thì yêu cầu cũ bị hủy, tránh đi nhầm quân/ô.
- Worker tìm nước offline bị treo/quá hạn sẽ bị kết thúc; các yêu cầu đang chờ được dọn và nhận phương án tìm kiếm nông có giới hạn để tránh làm bot kẹt mãi.
- Avatar mã vương miện được thêm vào cache lõi Service Worker; metadata phát hành và hướng dẫn build được đồng bộ v3.45.0.

### QA v3.45.0

- `npm run test:static`: **251/251 đạt**.
- Kiểm tra cú pháp JavaScript/MJS: **128/128 tệp đạt**.
- Kiểm thử tập trung đồng hồ, phong cấp bất đồng bộ và phục hồi Worker: **9/9 đạt**.
- `npm test`: **253/257 đạt**; 4 test không khởi chạy vì môi trường không có `chess.js`/`express` và không truy cập được npm registry. Chưa xác nhận build APK hoặc kiểm tra trực tiếp trên Android.
- Chi tiết: [`TEST_REPORT_V3_45_0.md`](TEST_REPORT_V3_45_0.md).

VILA là ứng dụng cờ vua web đóng gói bằng Capacitor cho Android. ZIP này là **mã nguồn để build**, không phải APK đã biên dịch.


## Nâng cấp v3.40.0

- Chip Stockfish chỉ báo sẵn sàng sau UCI handshake hợp lệ `uciok` → `readyok`; khi đã sẵn sàng, chạm chip để xem thời gian khởi động/profile trong thông báo.
- Lưu ván đang chơi dùng snapshot có checksum; ván hỏng, quá hạn, sai mode, nước đi/đồng hồ sai định dạng bị từ chối trước khi nạp; snapshot v2 cũ vẫn tương thích.
- Giữ các chế độ cờ, phân tích, câu đố, đấu trường, Rubik và mini-game hiện có; thay đổi tập trung vào tính đúng đắn, khả năng khôi phục và kiểm thử hồi quy.
- Test tĩnh: 233/233; cú pháp: 123/123; full suite: 235/239 do bốn tệp test thiếu dependency trong môi trường đóng gói. Build APK và UCI với binary thật còn chờ chạy trên GitHub Actions.


## Tính năng nền tảng từ v3.37.0

### Engine và sức mạnh bot
- Stockfish 19 Full NNUE được đưa vào quy trình build Android cùng bản Lite và ASM-JS dự phòng. Full single-threaded có kích thước khoảng 94 MB và không cần cross-origin isolation; Lite nhẹ hơn đáng kể nhưng yếu hơn. [Tài liệu Stockfish.js và các biến thể engine](https://github.com/nmrugg/stockfish.js/blob/master/README.md).
- Chế độ tự động ưu tiên Full NNUE khi WebView báo bộ nhớ thiết bị từ khoảng 2 GiB và ít nhất 4 lõi; máy yếu hơn chọn Lite. Nếu Full không khởi tạo được, ứng dụng có chuỗi dự phòng Lite rồi ASM-JS.
- Bot không còn bỏ lượt Stockfish để đi ngẫu nhiên/heuristic chỉ nhằm giả lập Elo thấp. Dưới ngưỡng UCI_Elo, VILA dùng Skill Level 0–7 của Stockfish; các mức Elo thấp là preset luyện tập, **không phải rating được benchmark**.
- Mặc định tìm kiếm sâu hơn (depth tối đa 30, tối đa 2,6 giây mỗi nước); cài đặt tùy chỉnh đã lưu của người chơi được giữ lại.

### Đấu trường có hai thế hệ Stockfish
- Đấu trường có Stockfish 19 Full NNUE và Stockfish 10 cổ điển như hai đối thủ độc lập. Stockfish 10 được phân phối từ gói `stockfish.js@10.0.2`, chạy UCI trong Web Worker riêng, có giới hạn thời gian và kiểm tra tính hợp lệ của nước đi. Đây là engine đời cũ dùng để so sánh, không được quảng bá là mạnh hơn Stockfish hiện tại.
- Bản Android release bắt buộc xác nhận đủ script Stockfish 10 và giấy phép GPL đi kèm; thiếu một trong hai thì build dừng trước khi ghi đè thư mục engine.

### Xem lại ván và phân tích
- Xem lại từng nửa nước với nút về đầu/trước/sau/cuối, bàn cờ có tô nước cuối, biểu đồ lợi thế và biên bản ghép theo cặp Trắng/Đen. Chạm một nước để nhảy đến đúng thế cờ.
- Phân tích từng nước lưu điểm trước/sau theo góc nhìn Trắng, mức mất điểm theo bên vừa đi, độ sâu engine, nước tốt nhất tìm thấy ở thế trước và biến chính SAN. Panel hiển thị nhãn và số lượng chất lượng nước đi riêng cho Trắng và Đen.
- Phân tích toàn ván, gợi ý nước, phân tích 3 biến và trợ lý cờ chạy ở mức sức mạnh tối đa của engine, không thừa hưởng giới hạn Elo của bot trong ván.
- Các nhãn “Tốt nhất”, “Xuất sắc”, “Tốt”, “Chưa chính xác”, “Sai lầm”, “Blunder”, “Khai cuộc” và “Bỏ lỡ cơ hội thắng” là **heuristic VILA dựa trên điểm Stockfish**, không tuyên bố dùng cùng công thức phân loại độc quyền của Chess.com. Nước “Thiên tài” không được tự gán chỉ vì có quân bị tấn công.

### Giao diện, bài tập và game giải trí
- App mở vào **sảnh Trang chủ VILA**, không mở thẳng bàn cờ. Từ sảnh mới chọn Chơi, Bot, Câu đố, Bài học, Phân tích, Đấu trường AI, lịch sử hoặc mini-game.
- Giao diện ưu tiên điện thoại: xanh đêm/xanh lá mang thương hiệu VILA, điều hướng đáy, vùng chạm lớn, safe-area Android và bàn cờ responsive. Bố cục lấy cảm hứng từ ứng dụng cờ hiện đại, không sao chép logo hoặc tài sản thương hiệu riêng của Chess.com.
- Giữ thư viện khai cuộc ECO cục bộ, tra cứu tên/ECO/nước đi và các biến. Workflow kiểm tra ngưỡng dữ liệu khai cuộc trước build.
- Câu đố ngày sử dụng Lichess API, xác minh dòng nước bằng `chess.js`, lưu cache ngày và có bài ngoại tuyến khi không có mạng. Luyện tự do, Rush và Sinh tồn tự chuyển bài sau khi giải; bộ đố offline có độ khó tăng dần theo tiến trình.
- Bốn mini-game ngoại tuyến: Rubik 3×3 xoay mặt bằng vuốt hoặc nút U/D/L/R/F/B, xáo trộn/hoàn tác/làm mới; 2048; lật thẻ nhớ; Trượt số 15 với xáo trộn chỉ bằng nước đi hợp lệ.
- Giữ các chức năng sẵn có: nhập/xuất PGN, lịch sử cục bộ, đồng hồ, hoàn tác/làm lại, chú thích mũi tên/ô cờ, khai cuộc, profile bot offline, nhạc nền và các luồng online đã tích hợp.

## Bản vá v3.37.2 — bố cục trận đấu trên Android

- Chuyển lời mời bắt đầu khỏi lớp phủ che mờ bàn cờ thành thẻ gọn nằm giữa thông tin đối thủ và bàn cờ.
- Đưa cửa sổ cuộn về đầu trang khi chuyển màn hình hoặc quay lại chơi từ màn xem lại.
- Bảo đảm vùng đệm cuối trang đủ cho thanh thao tác trận đấu cố định, tránh che nội dung cuối trên WebView di động.
- Tăng phiên bản Service Worker để thiết bị không tiếp tục dùng CSS/JS cũ sau khi cập nhật.

## Bản vá v3.37.1 — Stockfish 10 Đấu trường
- Đồng bộ UCI bằng `isready`/`readyok` trước từng lệnh `position`/`go`; reset `ucinewgame` chỉ một lần cho mỗi ván để không xóa bảng băm ở mọi nửa nước.
- Cô lập callback theo đúng Worker và dỡ callback trước khi huỷ worker timeout/lỗi, ngăn `bestmove` cũ làm hoàn tất lượt mới. Worker lỗi hoặc timeout được huỷ an toàn và tự khởi tạo lại ở lượt kế tiếp; lỗi Stockfish 10 được giữ rõ trên trạng thái Đấu trường khi dùng nước dự phòng.
- Bản phát hành tăng phiên bản Service Worker để thiết bị không giữ mã JavaScript cũ trong cache.

## Online và offline
- Chơi với Stockfish, luyện bài và mini-game chạy cục bộ sau khi các engine cần thiết đã được tải/cache.
- Câu đố ngày và dữ liệu mở rộng cần internet; cache cục bộ được dùng khi có sẵn.
- Xếp hạng/cộng đồng/server yêu cầu backend và tài khoản đã cấu hình. Không đăng nhập hay backend thì những luồng phụ thuộc server không thể hoạt động đầy đủ.
- Engine Full NNUE khoảng 94 MB; workflow build nhúng nó để tăng sức mạnh, vì vậy APK lớn hơn. Trên máy yếu có thể dùng Lite hoặc để chế độ tự động chọn phù hợp.

## Build APK bằng GitHub Actions

1. Giải nén ZIP và đẩy **toàn bộ nội dung bên trong** lên một GitHub repository, giữ nguyên thư mục `.github/workflows/`.
2. Mở tab **Actions** và chạy workflow **Cờ Vua ViLa Android build**. Workflow này cũng chạy khi có push/PR.
3. Runner cài Node.js 22 và Java 21; cài package, kiểm tra cú pháp, chạy `npm test`, tải tài nguyên engine/bộ quân/kho khai cuộc, build web, sync Capacitor và chạy `./gradlew assembleDebug`.
4. Chỉ khi các bước bắt buộc đều thành công, tải artifact **`covua-vila-debug-apk`**. Artifact `test-report` giúp xem lỗi test, còn `covua-vila-android-gradle-source` là gói mã nguồn Gradle do workflow sinh ra.
5. Workflow **Cờ Vua ViLa build from ZIP/source** là lựa chọn chạy thủ công riêng; nó không chạy trùng trên mỗi lần push.

### Lệnh cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

`npm run build` cần các package Node và tải dữ liệu build lần đầu. Đối với build Android cần môi trường Java/Android phù hợp hoặc dùng GitHub Actions.

## Báo cáo kiểm thử

Xem [`TEST_REPORT_V3_46_4.md`](TEST_REPORT_V3_46_4.md) để biết kết quả mới nhất và các giới hạn kiểm thử. GitHub Actions phải hoàn tất cài dependencies, toàn bộ test, build web và build Gradle trước khi có thể coi APK là đã build thành công.

## Nguồn câu đố

Nguồn, license và cách tải kho câu đố theo lô được ghi trong [`PUZZLES_SOURCE.md`](PUZZLES_SOURCE.md). Dữ liệu Lichess được tải theo yêu cầu; không đóng gói cả cơ sở dữ liệu nhiều triệu câu vào APK.

## Nguồn và giấy phép

- Stockfish.js: [repository và README](https://github.com/nmrugg/stockfish.js); engine GPLv3, giấy phép được copy kèm asset khi build.
- Lichess API và dữ liệu công khai: [API](https://github.com/lichess-org/api/blob/master/doc/specs/lichess-api.yaml), [Open Database](https://database.lichess.org/) (câu đố dữ liệu công khai CC0). Bản này dùng API daily/cache, không nhúng toàn bộ kho hàng triệu câu đố.
- Các bộ quân SVG và giấy phép nguồn được liệt kê trong [`public/piece-sets/CREDITS.md`](public/piece-sets/CREDITS.md).
- Ý tưởng giao diện Rubik tương tác có tham khảo [Cubing.js](https://js.cubing.net/cubing/); logic xoay trong dự án này được hiện thực nội bộ, không tải thư viện từ CDN.



## v3.47.0 update (2026-10-20)
- Added online-only correspondence controls: 1 day and 2 days per player. Local games keep their existing clock presets.
- Added a Stockfish-powered beginner training preset targeting the lowest supported skill tier; it is not a separate engine binary or a calibrated Elo guarantee.
- Improved readability of puzzle/review panels and touch reliability of AI Arena controls.
- Engine package remains Stockfish 19 Lite WASM plus Stockfish 10 legacy ASM.js. The manifest does not include a Full Stockfish 19 build.
