import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('android');
const alternatives = [
  ['settings.gradle', 'settings.gradle.kts'],
  ['app/build.gradle', 'app/build.gradle.kts'],
  ['app/src/main/AndroidManifest.xml'],
  ['gradlew'],
  ['gradle/wrapper/gradle-wrapper.jar'],
  ['gradle/wrapper/gradle-wrapper.properties'],
];
const missing = alternatives.filter(group => !group.some(file => fs.existsSync(path.join(root, file))));
if (missing.length) {
  console.error('[Cờ Vua ViLa] Android Gradle project incomplete:');
  for (const group of missing) console.error(` - ${group.join(' or ')}`);
  console.error('Run `npx cap add android` after installing the project dependencies.');
  process.exit(1);
}
const wrapperJar = path.join(root, 'gradle', 'wrapper', 'gradle-wrapper.jar');
const jarBytes = fs.readFileSync(wrapperJar);
if (jarBytes.length < 1024 || jarBytes[0] !== 0x50 || jarBytes[1] !== 0x4b) {
  console.error('[Cờ Vua ViLa] gradle-wrapper.jar is missing or does not look like a valid JAR.');
  process.exit(1);
}
const wrapperScript = fs.readFileSync(path.join(root, 'gradlew'), 'utf8');
if (!wrapperScript.includes('GradleWrapperMain')) {
  console.error('[Cờ Vua ViLa] android/gradlew is not the official-style Gradle wrapper launcher.');
  process.exit(1);
}
const wrapperProps = fs.readFileSync(path.join(root, 'gradle', 'wrapper', 'gradle-wrapper.properties'), 'utf8');
if (!/^distributionUrl=https/i.test(wrapperProps.split(/\r?\n/).find(line => line.startsWith('distributionUrl=')) || '')) {
  console.error('[Cờ Vua ViLa] gradle-wrapper.properties has no distributionUrl.');
  process.exit(1);
}
if (process.platform !== 'win32') {
  const mode = fs.statSync(path.join(root, 'gradlew')).mode;
  if (!(mode & 0o111)) {
    console.error('[Cờ Vua ViLa] android/gradlew is not executable. Restoring execute permission.');
    fs.chmodSync(path.join(root, 'gradlew'), mode | 0o111);
  }
}
console.log('[Cờ Vua ViLa] Android Gradle files verified.');
