const express = require('express');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/openai';
const GEMINI_NATIVE = 'https://generativelanguage.googleapis.com/v1beta/models';
const MAX_OUTPUT_TOKENS = Math.min(Number(process.env.MAX_OUTPUT_TOKENS || 32768), 32768);

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '18mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
});

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const retryable = status => [408, 429, 500, 502, 503, 504].includes(Number(status));

const FALLBACK_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.7-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-pro-preview',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite'
];

function normalizeMessages(messages) {
  return Array.isArray(messages) ? messages.filter(Boolean).slice(-120) : [];
}

function parseRetryAfter(response, data) {
  const header = response.headers.get('retry-after');
  if (header) {
    const seconds = Number(header);
    if (Number.isFinite(seconds)) return Math.min(12000, Math.max(500, seconds * 1000));
    const when = Date.parse(header);
    if (Number.isFinite(when)) return Math.min(12000, Math.max(500, when - Date.now()));
  }
  const msg = String(data?.error?.message || data?.message || '');
  const match = msg.match(/retry(?:Delay| after)?[\\s:=]+([0-9]+(?:\\.[0-9]+)?)s/i);
  return match ? Math.min(12000, Math.max(500, Number(match[1]) * 1000)) : 1800;
}

async function geminiChat(body) {
  if (!GEMINI_KEY) {
    const error = new Error('Server chưa có GEMINI_API_KEY trong biến môi trường.');
    error.status = 500;
    throw error;
  }
  const requested = String(body?.model || '').trim();
  const models = [...new Set([requested, ...FALLBACK_MODELS].filter(Boolean))];
  const messages = normalizeMessages(body?.messages);
  let lastError;

  for (const model of models) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await fetch(`${GEMINI_BASE}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${GEMINI_KEY}`
          },
          body: JSON.stringify({
            model,
            messages,
            max_tokens: Math.min(Number(body?.max_tokens || MAX_OUTPUT_TOKENS), MAX_OUTPUT_TOKENS)
          })
        });
        const text = await response.text();
        let data = {};
        try { data = text ? JSON.parse(text) : {}; } catch {}
        if (response.ok) return { ...data, model };
        const error = new Error(data?.error?.message || `Gemini HTTP ${response.status}`);
        error.status = response.status;
        error.retryAfterMs = parseRetryAfter(response, data);
        lastError = error;
        if (!retryable(response.status) || response.status === 429) break;
        await sleep(Math.min(12000, 700 * (attempt + 1)));
      } catch (error) {
        lastError = error;
        if (attempt === 0) await sleep(700);
      }
    }
  }

  throw lastError || new Error('Không thể kết nối Gemini.');
}

function nativePartsFromContent(content) {
  if (!Array.isArray(content)) return [{ text: String(content || '') }];
  return content.map(part => {
    if (part?.type === 'text') return { text: String(part.text || '') };
    const url = String(part?.image_url?.url || '');
    const match = url.match(/^data:([^;]+);base64,(.+)$/);
    if (match) return { inlineData: { mimeType: match[1], data: match[2] } };
    return { text: '[Ảnh đính kèm không có dữ liệu hợp lệ]' };
  });
}

async function geminiSearch(body) {
  if (!GEMINI_KEY) {
    const error = new Error('Server chưa có GEMINI_API_KEY.');
    error.status = 500;
    throw error;
  }
  const model = String(body?.model || 'gemini-3.8-flash').trim();
  const messages = normalizeMessages(body?.messages);
  const system = messages.find(item => item.role === 'system');
  const contents = messages.filter(item => item.role === 'user' || item.role === 'assistant').map(item => ({
    role: item.role === 'assistant' ? 'model' : 'user',
    parts: nativePartsFromContent(item.content)
  }));
  const payload = {
    contents,
    tools: [{ google_search: {} }],
    generationConfig: { maxOutputTokens: MAX_OUTPUT_TOKENS }
  };
  if (system) payload.systemInstruction = { parts: [{ text: String(system.content || '') }] };

  const response = await fetch(`${GEMINI_NATIVE}/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(GEMINI_KEY)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch {}
  if (!response.ok) {
    const error = new Error(data?.error?.message || `Search HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }
  const aiReply = (data?.candidates?.[0]?.content?.parts || []).map(part => part?.text || '').join('').trim();
  const chunks = data?.groundingMetadata?.groundingChunks || [];
  const sources = chunks.map(chunk => chunk?.web).filter(item => item?.uri)
    .filter((item, index, list) => list.findIndex(x => x.uri === item.uri) === index).slice(0, 8);
  let answer = aiReply;
  if (sources.length) {
    answer += '\n\n### Nguồn Web\n' + sources.map((source, index) => `${index + 1}. [${source.title || source.uri}](${source.uri})`).join('\n');
  }
  return { ok: true, aiReply: answer, model };
}

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'VILA AI Server',
    provider: 'Google Gemini',
    apiKeyConfigured: Boolean(GEMINI_KEY),
    endpoints: { chat: '/api/chat', search: '/api/search', health: '/api/health', config: '/api/config' },
    maxTokens: MAX_OUTPUT_TOKENS,
    time: new Date().toISOString()
  });
});

app.get('/api/config', (_req, res) => {
  res.json({
    ok: true,
    serverMode: true,
    provider: 'Google Gemini',
    apiKeyConfigured: Boolean(GEMINI_KEY),
    endpoints: { chat: '/api/chat', search: '/api/search', health: '/api/health', config: '/api/config' },
    maxTokens: MAX_OUTPUT_TOKENS,
    multimodal: true,
    webSearch: true
  });
});

app.post('/api/chat', async (req, res) => {
  try {
    res.json(await geminiChat(req.body || {}));
  } catch (error) {
    res.status(Number(error.status) || 500).json({ message: error.message, status: Number(error.status) || 500, retryAfterMs: error.retryAfterMs || 0 });
  }
});

app.post('/api/search', async (req, res) => {
  try {
    res.json(await geminiSearch(req.body || {}));
  } catch (error) {
    res.status(Number(error.status) || 500).json({ message: error.message, status: Number(error.status) || 500, retryAfterMs: error.retryAfterMs || 0 });
  }
});

app.get('/', (_req, res) => {
  res.type('html').send('<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>VILA AI Server</title></head><body style="font-family:system-ui;background:#09090b;color:#f4f4f5;padding:32px"><h1>VILA AI Server</h1><p>API proxy is running. Use <code>/api/health</code> to check status.</p></body></html>');
});

app.use((_req, res) => res.status(404).json({ message: 'Not found' }));

app.listen(PORT, HOST, () => console.log(`VILA AI Server running on http://${HOST}:${PORT}`));
