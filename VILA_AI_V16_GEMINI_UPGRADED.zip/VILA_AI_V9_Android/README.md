# VILA AI Studio V16 — Android APK

VILA AI Studio V16 giữ kiến trúc WebView + Gemini của bản V15, nhưng sửa lại các điểm tích hợp quan trọng và tăng khả năng chạy thực tế trên Android.

## Đã nâng cấp

- Giữ nguyên chat, nhớ hội thoại, bộ nhớ dự án, Live Preview, chạy lại code, kiểm tra code, tải code, Firebase account và Google Search.
- Ảnh đính kèm đã được gửi thật vào Gemini theo chuẩn multimodal, có thumbnail trong chat; tối đa 3 ảnh/lượt và tự tối ưu ảnh lớn.
- File TXT/JSON/CSV/HTML/CSS/JS/TS/Python/Java/Kotlin/XML/YAML/PDF/DOCX vẫn đọc trực tiếp trong app.
- Sửa wiring của các nút Đính kèm, Xóa lịch sử, Cài đặt và các luồng sự kiện DOM.
- Tùy chọn VILA Server Proxy: APK có thể gọi `/api/chat`, `/api/search` qua server và giữ Gemini API key ở biến môi trường server.
- Tải file từ WebView có cầu nối native vào thư mục Downloads trên Android 10+.
- Gemini 3.8 Flash là model chính; fallback dùng các model hiện hành và 2.5 legacy khi tài khoản còn quyền truy cập.
- Server Express 5.1 được sửa route catch-all, thêm CORS, multimodal image, Web Search và health/config endpoints.
- Gradle/Android Gradle Plugin được cập nhật để khớp API 35/JDK 17.

## Chạy server

Node.js >= 18 (Node 20/22 đều dùng được). Linux/macOS có thể truyền key qua biến môi trường; script Windows `start-vila-server.bat` hỗ trợ đọc `.env`.

```bash
cd server
npm install
GEMINI_API_KEY=YOUR_KEY npm start
```

Sau đó mở APK → ⚙ → nhập **VILA Server Proxy**. Nếu server chạy trong LAN, ví dụ `http://192.168.1.10:8787`.

## Gọi Gemini trực tiếp

Có thể để trống Server Proxy và nhập Gemini API key trong app. Đây là chế độ tiện lợi, nhưng key sẽ nằm trên thiết bị; với production nên ưu tiên server proxy.

## Build APK local

Dùng Gradle 8.11.1 + JDK 17:

```bash
gradle assembleDebug --no-daemon
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions — tự build và tự giải nén ZIP

Workflow nằm tại `.github/workflows/main.yml`. Nó có 2 chế độ:

1. Repo đã chứa `settings.gradle`: build thẳng.
2. Repo chỉ chứa file `VILA_AI_V16_UPGRADED_PROJECT.zip`: workflow tự giải nén vào workspace rồi build, không cần giải nén tay.

**Lưu ý của GitHub:** một workflow không thể tự chạy nếu chính file workflow chỉ nằm bên trong một ZIP chưa được GitHub nhận diện. Vì vậy, cần có `main.yml` trong `.github/workflows/` ít nhất một lần; sau đó ZIP project có thể được upload vào repo và Action sẽ tự giải nén/build.

## Firebase

Giữ cấu hình trong `app/src/main/assets/firebase-config.js`. Nếu để trống, app vẫn chạy bộ hồ sơ cục bộ; Firebase email/Google chỉ hoạt động sau khi điền cấu hình Web App và bật Authentication.


## Gemini API routing

VILA V16 uses Google Gemini. Direct mode uses the Gemini OpenAI-compatible endpoint:

`https://generativelanguage.googleapis.com/v1beta/openai/chat/completions`

Proxy mode uses the VILA server endpoint:

`POST /api/chat`

Health check:

`GET /api/health`

The app Settings screen now displays the resolved full endpoint so `/api` is never presented as if it were a complete URL.
