'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const html=fs.readFileSync(require('node:path').join(__dirname,'../app/src/main/assets/index.html'),'utf8');
function extractFunction(name){
  const marker=`function ${name}(`; const start=html.indexOf(marker);
  assert.ok(start>=0,`Missing function ${name}`);
  const brace=html.indexOf('{',start); let depth=0,quote='',escape=false,template=false;
  for(let i=brace;i<html.length;i++){
    const c=html[i];
    if(quote){if(escape){escape=false;continue;}if(c==='\\'){escape=true;continue;}if(c===quote)quote='';continue;}
    if(c==='"'||c==="'"){quote=c;continue;}
    if(c==='`'){template=!template;continue;}
    if(template)continue;
    if(c==='{')depth++; else if(c==='}'&&--depth===0)return html.slice(start,i+1);
  }
  throw new Error(`Unbalanced function ${name}`);
}
const fn=extractFunction('saveActiveProviderKey');
function makeContext(provider, existing='', entered='', failReadback=false){
  const store=new Map(); const input={value:entered,placeholder:'',type:'password'};const state={textContent:'',classList:{toggle(){}}};
  const keyStore=new Map([[provider,existing]]);const calls=[];
  const Android={
    saveGeminiApiKey(v){calls.push(['saveGemini',v]);keyStore.set('gemini',v);return true;},
    getGeminiApiKey(){return failReadback?'wrong':keyStore.get('gemini')||'';},
    saveGeminiBaseUrl(v){calls.push(['base',v]);},
    saveProviderApiKey(p,v){calls.push(['saveProvider',p,v]);keyStore.set(p,v);return true;},
    getProviderApiKey(p){return failReadback?'wrong':keyStore.get(p)||'';}
  };
  const context={
    activeProvider:provider,activeApiKey:existing,activeBaseUrl:'',currentModel:'test-model',
    PROVIDERS:{gemini:{name:'Gemini',baseUrl:'https://generativelanguage.googleapis.com/v1beta'},groq:{name:'Groq',baseUrl:'https://api.groq.com/openai/v1'},cerebras:{name:'Cerebras',baseUrl:'https://api.cerebras.ai/v1'},openrouter:{name:'OpenRouter',baseUrl:'https://openrouter.ai/api/v1'},custom:{name:'Custom API',baseUrl:'https://example.test/v1'}},
    document:{getElementById(id){return id==='apiKeyInput'?input:id==='apiBaseUrlInput'?{value:'https://example.test/v1'}:id==='apiKeySavedState'?state:null;}},
    localStorage:{setItem(k,v){store.set(k,String(v));},getItem(k){return store.get(k)||null;},removeItem(k){store.delete(k);}},
    window:{Android},getProviderKey(p){return keyStore.get(p)||'';},modelStorageKey(p){return `vila_${p}_model`;},
    showToast(){},console
  };
  vm.createContext(context);vm.runInContext(fn,context);
  return {context,input,state,calls,keyStore,store};
}
// Saving settings with a blank key field must preserve the existing key and not call native save with an empty string.
{
  const t=makeContext('groq','groq-secret','');
  assert.equal(t.context.saveActiveProviderKey(),true);
  assert.equal(t.keyStore.get('groq'),'groq-secret');
  assert.equal(t.calls.some(c=>c[0]==='saveProvider'),false);
  assert.equal(t.input.value,'');
  assert.match(t.input.placeholder,/đã lưu/);
}
// A newly entered provider key is saved and read back from the Android bridge.
{
  const t=makeContext('groq','','new-groq-secret');
  assert.equal(t.context.saveActiveProviderKey(),true);
  assert.equal(t.keyStore.get('groq'),'new-groq-secret');
  assert.ok(t.calls.some(c=>c[0]==='saveProvider'&&c[1]==='groq'&&c[2]==='new-groq-secret'));
}
// Gemini uses its dedicated Keystore bridge and also verifies read-back.
{
  const t=makeContext('gemini','','new-gemini-secret');
  assert.equal(t.context.saveActiveProviderKey(),true);
  assert.equal(t.keyStore.get('gemini'),'new-gemini-secret');
}
// A failed read-back must be reported, not falsely treated as a successful save.
{
  const t=makeContext('groq','','new-secret',true);
  assert.throws(()=>t.context.saveActiveProviderKey(),/Không xác minh được key đã lưu/);
}

// Browser-only fallback persists the key and does not overwrite it with an empty field.
{
  const t=makeContext('groq','','browser-secret');
  t.context.window.Android=null;
  assert.equal(t.context.saveActiveProviderKey(),true);
  assert.equal(t.store.get('vila_groq_key'),'browser-secret');
}
console.log('PASS: V37 key persistence runtime tests (preserve blank, save provider, save Gemini, browser fallback, fail read-back).');
