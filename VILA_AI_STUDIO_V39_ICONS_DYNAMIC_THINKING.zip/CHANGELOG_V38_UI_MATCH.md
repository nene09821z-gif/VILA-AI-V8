# VILA AI Studio V38 — Khớp giao diện mẫu + cải tiến

File đã sửa: `app/src/main/assets/index.html`

## 1. Khớp giao diện với ảnh mẫu
- Sidebar trái: đổi "CỔNG AI CỦA BẠN" → **"BẢNG XẾP HẠNG TOP"**, các dòng xếp hạng
  giờ hiển thị tên model (Gemini 2.5 Flash, GPT-OSS 120B, Llama 3.3 70B, DeepSeek R1,
  Custom API) kèm mô tả ngắn giống ảnh mẫu, vẫn giữ huy chương vàng/bạc/đồng có sẵn.
- Rail phải: đổi "CỔNG AI HỖ TRỢ" → **"TẤT CẢ MODEL ĐỀU FREE"** với mô tả
  "Tự động chọn model phù hợp nhất cho từng tác vụ của bạn." và nhãn **Free** trên từng dòng.
- Card tính năng: viết lại mô tả ngắn cho khớp văn phong ảnh mẫu, thêm mục
  **"Giao diện hiện đại · Nhanh, mượt, dễ sử dụng"**.
- Model trong dropdown header hiển thị hậu tố **"(Free)"** thay vì icon 🆓, giống ảnh mẫu
  ("Gemini 2.5 Flash (Free)").
- Banner chào mừng "XIN CHÀO CÁC BẠN / TÔI CÓ THỂ GIÚP GÌ CHO BẠN?" + robot đã có sẵn
  từ bản V33/34, giữ nguyên vì đã khớp ảnh mẫu.

## 2. Lưu ý quan trọng — KHÔNG thêm "Claude 3.7 Sonnet (Free)"
Ảnh mẫu ghi Claude 3.7 Sonnet là model miễn phí, nhưng trên thực tế **không có API chính
thức/hợp pháp nào cấp Claude miễn phí ở quy mô này** (Anthropic API tính phí theo token,
OpenRouter cũng không có Claude free). Đưa nhãn "Free" cho Claude vào app sẽ gây hiểu lầm
cho người dùng và khi bấm vào sẽ lỗi vì không có endpoint miễn phí thật. Vì vậy bản này
thay bằng Llama 3.3 70B / DeepSeek R1 — hai model có free tier thật qua Cerebras/OpenRouter.
Nếu bạn có một gateway riêng thực sự phục vụ Claude miễn phí, cho biết endpoint để nối vào.

## 3. Cải tiến chức năng ("mạnh hơn")
- Thêm hàm `quickSelectRailModel(provider)`: bấm 1 lần vào dòng xếp hạng / rail model sẽ
  tự chuyển cổng **và** tự chọn model gợi ý (flagship) nếu cổng đó đã lưu key — không cần
  mở Cài đặt mỗi lần như trước (`openProviderFromRail` cũ luôn mở modal Cài đặt).
  Nếu cổng chưa có key, vẫn mở Cài đặt như cũ để người dùng nhập.
- Thêm model mặc định mới vào danh mục fallback: `llama-3.3-70b` (Cerebras),
  `deepseek/deepseek-r1:free` và `meta-llama/llama-3.3-70b-instruct:free` (OpenRouter) —
  giúp Auto model / Ưu tiên Free có thêm lựa chọn thật khi chưa đồng bộ API.
- Đã chạy `node --check` trên toàn bộ 15 khối `<script>` trong `index.html`: không có lỗi cú pháp.
- Đã kiểm tra cân bằng thẻ `section/aside/div/button` sau khi sửa: khớp số lượng mở/đóng.

## 4. Việc chưa làm được trong môi trường này
- Không build APK thật (không có Android SDK / mạng ngoài trong môi trường này). Dùng
  GitHub Actions có sẵn trong `.github/workflows/main.yml` (xem `README_GITHUB_BUILD_V28.md`)
  để build APK từ ZIP này như các bản trước.

---

# VILA AI Studio V39 — Sửa icon bị mất + nâng cấp khung suy luận động

## 1. Sửa icon trống (Groq / Cerebras / OpenRouter / Custom API)
Nguyên nhân: các icon này dùng `<i class="fa-solid fa-...">` và được một script
(`vila-v36-svg-icon-engine`) chuyển thành SVG **lúc chạy**. Trên máy thật (ảnh chụp
màn hình bạn gửi) bước chuyển đổi này không ra hình — chỉ icon Google "G" hiện vì nó
được viết cứng bằng CSS, không phụ thuộc script đó.
Đã sửa: viết **SVG cứng trực tiếp trong HTML** cho Groq (tia sét cam), Cerebras (chip
xanh ngọc), OpenRouter (route tím), Custom API (plug xám) — áp dụng ở cả 3 nơi:
- Sidebar "BẢNG XẾP HẠNG TOP"
- Rail phải "TẤT CẢ MODEL ĐỀU FREE"
- Màn Cài đặt → "Nhà cung cấp" (trước đây thiếu icon hoàn toàn kể cả Gemini)
Icon này không còn phụ thuộc JS/font ngoài — luôn hiển thị ngay cả khi mạng chậm.

## 2. Khung "Đang suy luận" giờ động theo ngữ cảnh thật (giống Claude)
Trước đây checklist 4 bước là **cố định**, không phản ánh việc có đang tìm web / đọc
file / sửa code hay không. Giờ:
- `buildVilaThinkingSteps()` tạo danh sách bước **theo đúng trạng thái yêu cầu hiện tại**:
  luôn có "Hiểu yêu cầu"; thêm "Đọc N tệp đính kèm" nếu có file trong khay đính kèm;
  thêm "Tìm kiếm web" nếu bật công tắc Tìm kiếm; thêm "Đọc project và lên phương án sửa
  code" nếu đang ở chế độ Code; bước suy luận đổi thành "Suy luận sâu nhiều bước" nếu
  bật Suy nghĩ sâu; luôn kết thúc bằng "Rà soát câu trả lời".
- `updateVilaThinkingPanel()` giờ khớp bước theo `data-phase` thay vì chỉ số cố định,
  nên hoạt động đúng dù danh sách bước dài ngắn khác nhau.
- Thêm **đồng hồ đếm giây** ngay trong khung (giống "Đang suy nghĩ... 15s"), tự cập nhật
  mỗi giây và tự dừng khi khung suy luận biến mất.
