# V46 — Fallback to the classic Google account chooser

## Problem
The device has several Google accounts added (as the user's screenshot showed via Settings/Gmail's
account switcher), but VILA AI's "Tiếp tục với Google" button, using only the new Credential
Manager "Sign in with Google" bottom sheet, failed to surface any of them (`NoCredentialException`).
This happens on some OEM Android builds / Play services versions where Credential Manager's
Identity-Provider integration isn't wired up, even though the accounts exist on the device.

## Fix
`startVilaGoogleLogin()` still tries Credential Manager first. If that fails for *any* reason,
`onError()` now calls `launchClassicGoogleSignIn()`, which uses the older, universally-supported
`GoogleSignInClient` API (`com.google.android.gms.auth.api.signin`). This opens Android's native
"Chọn tài khoản" chooser — the exact screen in the screenshot, listing every Google account on
the device plus "Thêm tài khoản khác" — and returns a Firebase-compatible ID token once the user
picks one.

- `finishGoogleFirebaseSignIn()` factors out the shared Firebase sign-in + account-collision
  logic so both the Credential Manager path and the classic fallback path use it.
- `handleClassicGoogleSignInResult()` handles cancel (12501), developer/config error (12500),
  and "no account available" (status 4, which still offers to open Add Account) with the same
  Vietnamese messages as before.
- `app/build.gradle`: added an explicit `com.google.android.gms:play-services-auth:21.2.0`
  dependency (previously only pulled transitively) so the classic API is guaranteed present.

## Still outstanding
Same as V44/V45 — register the debug keystore's SHA-1 in Firebase Console once; see
CHANGELOG_V44_LOGIN_STABLE_KEYSTORE.md.

## Build metadata / CI regression fix
- Bumped Android version metadata to versionCode 52 / versionName 46.0.0.
- Updated legacy regression tests that were still asserting V43 metadata; they now validate the V46 release and classic Google Sign-In fallback dependency.
