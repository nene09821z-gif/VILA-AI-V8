'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const config = fs.readFileSync(path.join(root, 'app/src/main/assets/firebase-config.js'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const setup = fs.readFileSync(path.join(root, 'FIREBASE_SETUP_V41.txt'), 'utf8');
const googleServices = JSON.parse(fs.readFileSync(path.join(root, 'app/google-services.json'), 'utf8'));

for (const dep of [
  'com.google.firebase:firebase-bom:34.19.0',
  'com.google.firebase:firebase-auth',
  'androidx.credentials:credentials:1.3.0',
  'androidx.credentials:credentials-play-services-auth:1.3.0',
  'com.google.android.libraries.identity.googleid:googleid:1.1.1',
  'com.google.android.gms:play-services-auth:21.2.0'
]) assert.ok(gradle.includes(dep), `Missing Firebase dependency ${dep}`);
assert.ok(gradle.includes('versionCode 52') && gradle.includes('versionName "46.0.0"'), 'V46 version code/name must match the release');
for (const method of [
  'initVilaFirebaseAuth()', 'vilaFirebaseStateJson()', 'firebaseEmailRegister(String email, String password)',
  'firebaseEmailLogin(String email, String password)', 'firebasePasswordReset(String email)',
  'firebaseGoogleLogin()', 'firebaseLogout()', 'GetGoogleIdOption',
  'GoogleIdTokenCredential.createFrom', 'GoogleAuthProvider.getCredential',
  'signInWithCredential(firebaseCredential)', 'sendPasswordResetEmail(cleanEmail)', 'clearCredentialStateAsync',
  'googleLoginDiagnostic(Exception e)', 'Credential Manager failed', 'Unable to launch Google Credential Manager',
  'launchClassicGoogleSignIn()', 'handleClassicGoogleSignInResult(Intent data)', 'GoogleSignInOptions.DEFAULT_SIGN_IN',
  'REQ_CLASSIC_GOOGLE_SIGNIN', 'Force the account chooser every time'
]) assert.ok(java.includes(method), `Missing native Firebase auth feature: ${method}`);
for (const field of ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId', 'androidAppId', 'webClientId']) {
  assert.ok(config.includes('\"' + field + '\":'), `Missing Firebase client config field ${field}`);
}
const configStart = config.indexOf('{', config.indexOf('window.VILA_FIREBASE_CONFIG'));
const configEnd = config.lastIndexOf('}');
assert.doesNotThrow(() => JSON.parse(config.slice(configStart, configEnd + 1)), 'Firebase config object must be parseable by native JSONObject');
const parsedConfig = JSON.parse(config.slice(configStart, configEnd + 1));
const androidClient = (googleServices.client || []).find(item =>
  item.client_info && item.client_info.android_client_info &&
  item.client_info.android_client_info.package_name === 'com.vila.ai'
);
assert.ok(androidClient, 'google-services.json must contain Android package com.vila.ai');
assert.equal(parsedConfig.androidAppId, androidClient.client_info.mobilesdk_app_id, 'firebase-config.js Android app ID must match google-services.json');
const webOAuth = (androidClient.oauth_client || []).find(item => item.client_type === 3 && item.client_id);
if (webOAuth) assert.equal(parsedConfig.webClientId, webOAuth.client_id, 'Firebase config must use the Web OAuth client ID supplied by google-services.json');
assert.equal(parsedConfig.projectId, googleServices.project_info.project_id, 'Firebase project ID mismatch');
for (const method of ['window.onNativeFirebaseAuthResult', 'window.emailRegister', 'window.emailLogin', 'window.googleLogin', 'window.resetAccountPassword', 'window.logoutAccount']) {
  assert.ok(html.includes(method), `Missing UI auth integration ${method}`);
}
assert.ok(html.includes('window.Android.firebaseGoogleLogin()'), 'Android Google login must use the native Credential Manager bridge');
assert.ok(html.includes('await window.googleLogin()'), 'Google gate must await the sign-in flow to catch startup failures');
assert.ok(html.includes('window.vilaGateSetError=function(message)'), 'Google gate must surface startup errors and restore buttons');
assert.ok(java.includes('SHA-1 of the APK') || java.includes('SHA-1'), 'Google login error path must diagnose certificate fingerprint mismatch');
assert.ok(html.includes('window.Android.firebaseEmailLogin(email,pw)'), 'Android email login must call native Firebase Auth when configured');
assert.ok(!/if\(window\.Android\)\s*\{[^}]*signInWithRedirect/s.test(html), 'APK must not use the WebView Google redirect flow');
for (const secret of ['FIREBASE_ANDROID_APP_ID', 'FIREBASE_WEB_CLIENT_ID']) assert.ok(workflow.includes(secret), `Missing workflow mapping for ${secret}`);
assert.ok(workflow.includes('node scripts/test-firebase-v41.js'), 'Firebase smoke test must be run by GitHub Actions');
for (const item of ['com.vila.ai', 'androidAppId', 'webClientId', 'SHA-1', 'FIREBASE_WEB_CLIENT_ID']) assert.ok(setup.includes(item), `Firebase setup documentation missing ${item}`);
assert.ok(html.includes('id="vilaAuthGateForm"'), 'Login UI must submit through a real form');
assert.ok(html.includes('id="vilaAuthGateTitle">Đăng nhập</h1>'), 'Login UI title must be simplified');
assert.ok(html.includes('placeholder="Email"') && html.includes('placeholder="Mật khẩu"'), 'Login fields must use clean placeholders');
assert.ok(!html.includes('Firebase phải được cấu hình và bật Email/Password'), 'Small Firebase instruction paragraph should be removed from the login screen');
assert.ok(html.includes('validGateEmail(email)'), 'Gate must validate a full email address');
assert.ok(html.includes('không cần là 6 chữ số'), 'Registration validation must clarify passwords are not restricted to digits');
assert.ok(html.includes('Đang mở tài khoản Google trên thiết bị…'), 'Google login should open the device account picker');
assert.ok(java.includes('.setFilterByAuthorizedAccounts(false)'), 'Google picker must offer accounts beyond only previously authorized accounts');
assert.ok(java.includes('cleanPassword.length() < 6'), 'Registration should enforce Firebase minimum by character count, not digit-only PIN');
assert.ok(!html.includes('Google không phản hồi. Kiểm tra OAuth Web Client ID'), 'Google picker should not be falsely timed out while user is choosing account');
assert.ok(java.includes('Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()'), 'Native Firebase auth must validate email addresses');
console.log('PASS: V46 Firebase Android Auth, classic Google account chooser fallback, clean login UI, email validation, flexible passwords, and setup docs.');
