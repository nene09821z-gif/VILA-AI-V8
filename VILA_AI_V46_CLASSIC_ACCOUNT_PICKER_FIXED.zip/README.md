# VILA AI Studio V46 — Classic Google Account Picker & AI Gateway

VILA is an Android WebView app that connects to real AI provider APIs. This ZIP contains the source project, not a prebuilt APK.

## V46 — Login screen and classic device Google account picker

- The first-run gate is simplified to a clean **Đăng nhập** screen with Email, Mật khẩu, Đăng nhập, Google, Tạo tài khoản and Quên mật khẩu. The small explanatory paragraphs have been removed; status text appears only when an operation needs to report a result or error.
- On Android, **Tiếp tục với Google** calls native Android Credential Manager using `GetGoogleIdOption` with authorized-account filtering disabled so the account picker can offer Google accounts available on the device. Authentication completes through Firebase Auth; the UI does not report success until Firebase confirms it.
- Email fields require a complete email address. Existing-account login accepts the saved password exactly as entered. New passwords can use letters, numbers and symbols and do **not** need to be six digits; Firebase's default policy still requires at least six characters for new accounts.
- Source regression tests cover the new login form and native Google flow. This source ZIP is not a prebuilt APK; the Android build and real device sign-in must be confirmed by GitHub Actions and on the target phone.


## New in V41

- Firebase email/password registration and sign-in, password-reset email, and sign-out use Firebase Android Authentication when the native Firebase Android config is present.
- Google sign-in on Android uses Credential Manager to select a Google account and exchange its ID token with Firebase Auth. This avoids relying on embedded-WebView Google OAuth redirects.
- The project supports two additional Firebase client settings: `androidAppId` and `webClientId`. Configure them through GitHub Actions secrets or `app/src/main/assets/firebase-config.js`.
- Real sign-in requires a Firebase project with Email/Password and Google providers enabled. Google sign-in additionally requires registering package `com.vila.ai`, adding the signing certificate SHA-1, and supplying the OAuth Web client ID.
- Browser preview retains Firebase Web SDK authentication fallback; an Android APK with incomplete native settings reports that Google sign-in needs setup instead of pretending it succeeded.
- The requested V40 plain local preference storage for AI provider API keys remains unchanged; Firebase user authentication does not encrypt those unrelated API keys.


## V42 — AI Gateway and central routing

- The **AI Gateway** screen adds a Multi-API dashboard, provider/model scan, deep diagnostic (chat probe can consume provider quota), health check, request statistics, optional server routing, and an app-update check endpoint.
- The optional Node.js backend exposes a normalized OpenAI-style `/v1/chat/completions` API, model discovery, per-user rate limits, timeouts, bounded retry/fallback, task-aware provider ranking, and Firebase Admin ID-token verification in production. Supported server-side adapters are Gemini REST and OpenAI-compatible endpoints (OpenRouter, Groq, Cerebras, Custom).
- The backend stores provider secrets only in environment variables/secret manager. The browser/app sends Firebase ID tokens to the backend and does not send server provider keys. Direct per-user provider settings remain available when server routing is disabled.
- The diagnostic engine reports endpoint/model state and handles recoverable upstream failures; it does not edit unknown source code or perform unreviewed destructive repairs. Server usage figures are in-memory operational counters, not a durable invoice/accounting ledger.
- The app version endpoint `/v1/app/version` can report a configured release version and HTTPS release page. Android cannot silently install APK updates; the app can direct users to the release page and the OS installer still requires confirmation. Configure `VILA_APP_RELEASE_URL` on the backend to enable that hand-off.
- Automated source regressions and backend engine tests are run in GitHub Actions. A local source test does not demonstrate that upstream API keys, Firebase provider settings, external network access, or every model are live.

The supplied Android config is retained at `app/google-services.json`; the app runtime uses `app/src/main/assets/firebase-config.js` and the native FirebaseOptions bridge. See `README_V42_AI_GATEWAY.md` and `server/README.md` for deployment and Firebase setup. The provided Firebase Android config is prefilled for project `vila-studio`; the current `google-services.json` includes the OAuth Web client ID and the workflow copies it into the native config automatically. Google sign-in still requires the installed APK signing-certificate SHA-1 to be registered in Firebase Console. Browser preview also needs the separate Firebase Web App `appId`.

## Adaptive models (inherited from V39)

- OpenRouter's public `/models` catalog can be scanned without entering a key so you can see the current text-capable catalog and models whose live metadata identifies them as free. A valid OpenRouter API key is still required to send chat requests.
- Gemini model discovery marks documented free-tier families when the live model endpoint exposes them. Free-tier eligibility is not a promise of unlimited quota; availability, account restrictions, region and rate limits remain controlled by the provider.
- Custom/OpenAI-compatible endpoints remain supported: choose **Custom API**, enter the provider's Base URL and API key, then tap **Tải model mới nhất từ API**. This works only if that endpoint exposes a compatible `/models` listing and chat-completions endpoint. Some providers require a provider-specific API protocol or CORS/network permissions and may not work as an arbitrary OpenAI-compatible endpoint.
- The model catalog is cached on-device so the last successful list remains visible when temporarily offline. A successful refresh replaces that cached catalog.
- Android Internet permission and the foreground progress notification are already enabled. The foreground service is intended to keep an active request visible while the user switches apps; Android battery optimization, OEM task killers, network interruptions, provider outages and service limits mean no app can guarantee uninterrupted 24/7 execution on every device.

## Build

Use GitHub Actions: push the extracted project to a GitHub repository, open **Actions**, choose **VILA AI - Android Build and Verify**, then **Run workflow**. Download the debug APK artifact for installation and testing. Release APK signing requires Android signing secrets; without them, the release APK is unsigned.

See `README_GITHUB_BUILD_V28.md` for the detailed workflow. The workflow runs offline source/runtime checks and Android Gradle builds. A green result demonstrates that the selected build completed in CI, not that every external provider or API key works.

## Provider setup

1. Open **Settings / API**.
2. Choose Gemini, Groq, Cerebras, OpenRouter, or Custom API.
3. Enter the endpoint's API key (except when only scanning OpenRouter's public catalog).
4. For Custom API, enter its Base URL. The endpoint must support the protocol shown by that provider.
5. Tap **Tải model mới nhất từ API**, then choose a model. Use **Kiểm tra kết nối** to verify chat access.

Never paste API keys into public issue reports or share screenshots that reveal a key. API keys stored through the Android bridge use plain local preferences as requested for V40; this is less secure than encrypted storage. Uninstalling the app or clearing app data can remove them.

## Model status accuracy

- OpenRouter `:free` suffix and price metadata are treated as catalog indicators, not a guarantee of uninterrupted availability.
- For Gemini, model availability is read from the official authenticated model list when synced. Model-specific free-tier eligibility and quota are controlled by Google's current project/account policies.
- Groq, Cerebras and custom gateways expose the model IDs available to their API credentials; the app does not assume that an ID listed elsewhere is enabled for your account.
- No model is downloaded into the phone by this feature. It discovers hosted API model IDs; downloading/running local model weights is a separate feature with substantial device-storage and RAM requirements.

## Firebase account setup (V41)

Follow `FIREBASE_SETUP_V41.txt`. GitHub Actions supports these additional secrets for native Google sign-in:

- `FIREBASE_ANDROID_APP_ID`: `mobilesdk_app_id` from the Firebase Android app configuration (package must be `com.vila.ai`).
- `FIREBASE_WEB_CLIENT_ID`: OAuth 2.0 client ID for a Web application, ending in `.apps.googleusercontent.com`.

The existing web configuration secrets remain `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_STORAGE_BUCKET`, `FIREBASE_MESSAGING_SENDER_ID`, and `FIREBASE_APP_ID`. The workflow fills Android-native Firebase fields from `app/google-services.json` by default and lets defined GitHub Secrets override them. Browser preview still needs the separate Firebase Web App `appId`. If native Android values are absent, browser email auth may still work when web config is valid, while Google sign-in in the APK displays setup guidance.

Native Google sign-in also depends on Firebase Console provider settings and the SHA-1 of the certificate that signs the installed APK. The old prebuilt APK supplied in the incoming ZIP has a different signing SHA-1 from the Android OAuth fingerprint in `google-services.json`, so build a fresh APK and make sure its signer SHA-1 is registered in Firebase. CI writes `output/sha1-fingerprint.txt`; prefer a release APK signed with a persistent keystore for repeatable tests. Setup steps are in `FIREBASE_SETUP_V41.txt`.
