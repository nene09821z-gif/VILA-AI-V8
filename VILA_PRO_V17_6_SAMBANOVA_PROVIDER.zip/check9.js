
        /* Providers Configuration Map */
        const PROVIDERS = {
            gemini: {
                name: 'Google Gemini',
                baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
                keyStorage: 'vila_api_key',
                models: [
                    { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash — Smart' },
                    { id: 'gemini-3.7-flash', name: 'Gemini 3.7 Flash — Coding' },
                    { id: 'gemini-3.6-flash', name: 'Gemini 3.6 Flash — Balanced' },
                    { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash — Fast' },
                    { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash-Lite — Light' },
                    { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro — Reasoning' },
                    { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash — Fallback' }
                ]
            },
            groq: {
                name: 'Groq',
                baseUrl: 'https://api.groq.com/openai/v1',
                keyStorage: 'vila_groq_api_key',
                models: [
                    { id: 'openai/gpt-oss-120b', name: 'GPT-OSS 120B — Reasoning' }
                ]
            },
            sambanova: {
                name: 'SambaNova',
                baseUrl: 'https://api.sambanova.ai/v1',
                keyStorage: 'vila_sambanova_api_key',
                models: [
                    { id: 'Meta-Llama-3.3-70B-Instruct', name: 'Llama 3.3 70B — General' },
                    { id: 'DeepSeek-V3.1', name: 'DeepSeek V3.1 — Reasoning' }
                ]
            }
        };

        /* Global State */
        let activeProvider = localStorage.getItem('vila_provider') || 'gemini';
        if (!PROVIDERS[activeProvider]) activeProvider = 'gemini';
        let activeApiKey = localStorage.getItem(PROVIDERS[activeProvider].keyStorage) || '';
        let activeBaseUrl = activeProvider==='gemini' ? (localStorage.getItem('vila_base_url') || PROVIDERS[activeProvider].baseUrl) : (activeProvider==='sambanova' ? (localStorage.getItem('vila_sambanova_base_url') || PROVIDERS[activeProvider].baseUrl) : PROVIDERS[activeProvider].baseUrl);
        let serverUrl = localStorage.getItem('vila_server_url') || '';
        let currentModel = localStorage.getItem(activeProvider==='gemini'?'vila_gemini_model':(activeProvider==='groq'?'vila_groq_model':'vila_sambanova_model')) || localStorage.getItem('vila_selected_model') || PROVIDERS[activeProvider].models[0].id;
        let reasoningLevel = localStorage.getItem('vila_reasoning_level') || 'medium';
        const MAX_OUTPUT_TOKENS = 24576;
        const MEMORY_KEY = 'vila_conversation_memory_v7';
        const CODE_MEMORY_KEY = 'vila_latest_code_v7';
        const PROJECT_MEMORY_KEY = 'vila_project_memory_v7';
        const MEMORY_LIMIT = 400;
        const REQUEST_COOLDOWN_KEY = 'vila_model_cooldowns_v2';
        const MAX_RETRY_WAIT_MS = 12000;
        let modelCooldowns = {};
        try { modelCooldowns = JSON.parse(localStorage.getItem(REQUEST_COOLDOWN_KEY) || '{}') || {}; } catch (_) { modelCooldowns = {}; }
        const PROJECT_MEMORY_LIMIT = 12000;
        let conversationHistory = [];
        let projectMemory = localStorage.getItem(PROJECT_MEMORY_KEY) || "";
        let latestGeneratedCode = localStorage.getItem(CODE_MEMORY_KEY) || "";
        let isProcessing = false;
        let pendingAttachments = [];
        const MAX_FILE_CHARS = 120000;
        const MAX_ARCHIVE_CHARS = 240000;
        const MAX_IMAGE_REQUEST_BYTES = 12 * 1024 * 1024;

        function renderAttachmentTray(){
            const tray=document.getElementById('attachmentTray'); if(!tray) return;
            tray.innerHTML='';
            for(const [i,f] of pendingAttachments.entries()){
                const chip=document.createElement('div');
                chip.className='v11-file-chip';
                const icon=document.createElement('i');
                icon.className=`fa-solid ${f.kind==='image'?'fa-image':'fa-file-lines'} shrink-0`;
                chip.appendChild(icon);
                if(f.kind==='image' && f.dataUrl){
                    const img=document.createElement('img');
                    img.src=f.dataUrl; img.alt=f.name; img.loading='lazy'; img.onerror=()=>{img.replaceWith(icon)}; chip.insertBefore(img, icon);
                }
                const name=document.createElement('span'); name.className='v11-file-name'; name.textContent=f.name; chip.appendChild(name);
                const status=document.createElement('span'); status.className='v11-read-status shrink-0'; status.textContent=f.status==='ready'?'Đã sẵn sàng':f.status==='reading'?'Đang đọc':'Lỗi'; chip.appendChild(status);
                const remove=document.createElement('button'); remove.type='button'; remove.className='shrink-0'; remove.title='Xóa file'; remove.innerHTML='<i class="fa-solid fa-xmark"></i>'; remove.onclick=()=>removeAttachment(i); chip.appendChild(remove);
                tray.appendChild(chip);
            }
        }
        window.removeAttachment=function(i){ pendingAttachments.splice(i,1); renderAttachmentTray(); };
        function cleanFileText(text){ return String(text||'').replace(/\u0000/g,'').replace(/\r/g,'').slice(0,MAX_FILE_CHARS); }
        async function readPdfFile(file){
            const ab=await file.arrayBuffer();
            const pdfjs=window.pdfjsLib;
            if(!pdfjs) throw new Error('PDF reader chưa tải xong');
            const pdf=await pdfjs.getDocument({data:ab}).promise; let out=[];
            for(let p=1;p<=pdf.numPages;p++){ const page=await pdf.getPage(p); const tc=await page.getTextContent(); out.push(tc.items.map(x=>x.str).join(' ')); if(out.join('\n').length>=MAX_FILE_CHARS) break; }
            return cleanFileText(out.join('\n\n'));
        }
        async function readDocxFile(file){
            if(!window.mammoth) throw new Error('DOCX reader chưa tải xong');
            const ab=await file.arrayBuffer(); const r=await mammoth.extractRawText({arrayBuffer:ab}); return cleanFileText(r.value);
        }
        function blobToDataUrl(blob){
            return new Promise((resolve,reject)=>{ const r=new FileReader(); r.onload=()=>resolve(String(r.result||'')); r.onerror=()=>reject(r.error||new Error('Không đọc được dữ liệu ảnh')); r.readAsDataURL(blob); });
        }
        async function optimizeImageFile(file){
            const original=await blobToDataUrl(file);
            if(file.size <= 1500000) return {dataUrl:original,mime:file.type||'image/jpeg'};
            try{
                const img=await new Promise((resolve,reject)=>{ const el=new Image(); el.onload=()=>resolve(el); el.onerror=()=>reject(new Error('Không giải mã được ảnh')); el.src=original; });
                const maxSide=1800; const scale=Math.min(1,maxSide/Math.max(img.naturalWidth||img.width||1,img.naturalHeight||img.height||1));
                const w=Math.max(1,Math.round((img.naturalWidth||img.width)*scale));
                const h=Math.max(1,Math.round((img.naturalHeight||img.height)*scale));
                const canvas=document.createElement('canvas'); canvas.width=w; canvas.height=h;
                const c=canvas.getContext('2d'); c.drawImage(img,0,0,w,h);
                const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.88));
                if(blob && blob.size < file.size) return {dataUrl:await blobToDataUrl(blob),mime:'image/jpeg'};
            }catch(_){ /* keep original if browser image decoder is unavailable */ }
            return {dataUrl:original,mime:file.type||'image/jpeg'};
        }
        function isLikelyTextFile(name){
            const lower=String(name||'').toLowerCase();
            return /\.(txt|md|json|csv|html?|css|js|mjs|cjs|ts|tsx|jsx|py|java|kt|kts|c|cc|cpp|h|hpp|xml|svg|yaml|yml|toml|ini|conf|properties|gradle|kts|sql|sh|bat|ps1|log|env|gitignore|vue|svelte)$/i.test(lower) || !/\.[a-z0-9]{1,8}$/i.test(lower);
        }

        async function readZipFile(file){
            if(!window.JSZip) throw new Error('ZIP reader chưa tải xong');
            const zip=await window.JSZip.loadAsync(await file.arrayBuffer());
            const entries=Object.values(zip.files || {});
            let total=0;
            const parts=[`ARCHIVE: ${file.name}`, `FILES: ${entries.length}`, ''];
            for(const entry of entries){
                if(entry.dir){ parts.push(`[DIR] ${entry.name}`); continue; }
                if(total>=MAX_ARCHIVE_CHARS){ parts.push('\n[ARCHIVE CONTENT LIMIT REACHED]'); break; }
                if(!isLikelyTextFile(entry.name)){ parts.push(`\n[BINARY] ${entry.name}`); continue; }
                try{
                    const text=await entry.async('text');
                    const remaining=MAX_ARCHIVE_CHARS-total;
                    const chunk=String(text||'').slice(0, Math.min(50000, remaining));
                    parts.push(`\n===== ${entry.name} =====\n${cleanFileText(chunk)}`);
                    total+=chunk.length;
                }catch(_){ parts.push(`\n[UNREADABLE] ${entry.name}`); }
            }
            return cleanFileText(parts.join('\n')).slice(0,MAX_ARCHIVE_CHARS);
        }

        async function readAttachment(file){
            const lower=file.name.toLowerCase();
            if(file.type.startsWith('image/')) {
                const optimized=await optimizeImageFile(file);
                return {kind:'image',content:'',dataUrl:optimized.dataUrl,mime:optimized.mime,status:'ready'};
            }
            if(lower.endsWith('.zip')) return {kind:'text',content:await readZipFile(file),status:'ready'};
            if(lower.endsWith('.pdf')) return {kind:'text',content:await readPdfFile(file),status:'ready'};
            if(lower.endsWith('.docx')) return {kind:'text',content:await readDocxFile(file),status:'ready'};
            return {kind:'text',content:cleanFileText(await file.text()),status:'ready'};
        }
        async function handleFiles(files){
            const incoming=Array.from(files||[]);
            const imageCount=pendingAttachments.filter(f=>f.kind==='image').length + incoming.filter(f=>f.type.startsWith('image/')).length;
            if(imageCount>3){ showToast('Tối đa 3 ảnh mỗi lượt để giữ request ổn định.','error'); }
            let acceptedImages=0;
            for(const file of incoming){
                const maxFileBytes=file.name.toLowerCase().endsWith('.zip')?25*1024*1024:8*1024*1024; if(file.size>maxFileBytes){ showToast(`${file.name}: file quá lớn (tối đa ${file.name.toLowerCase().endsWith('.zip')?'25MB':'8MB'}).`,'error'); continue; }
                if(file.type.startsWith('image/') && pendingAttachments.filter(f=>f.kind==='image').length+acceptedImages>=3){ continue; }
                const item={name:file.name,size:file.size,kind:file.type.startsWith('image/')?'image':'text',content:'',dataUrl:'',mime:file.type||'',status:'reading'};
                pendingAttachments.push(item); if(item.kind==='image') acceptedImages++; renderAttachmentTray();
                try{ const r=await readAttachment(file); Object.assign(item,r); showToast(`Đã sẵn sàng ${file.name}`,'success'); }
                catch(e){ item.status='error'; showToast(`Không đọc được ${file.name}: ${e.message||'lỗi file'}`,'error'); }
                renderAttachmentTray();
            }
        }
        function getServerProxyUrl(path){
            if(!serverUrl) return '';
            const localProxy=!!(window.Android && typeof window.Android.setServerUrl==='function');
            if(localProxy) return `${location.origin}${path}`;
            return `${serverUrl}${path}`;
        }
        function isServerMode(){ return activeProvider === 'gemini' && !!serverUrl; }
        function contentToDisplayText(content){
            if(typeof content==='string') return content;
            if(Array.isArray(content)){
                return content.map(part=>part?.type==='text'?String(part.text||''):'[Ảnh đính kèm]').filter(Boolean).join('\n');
            }
            return '';
        }
        function buildRequestMessages(){
            const msgs=conversationHistory.map(m=>({role:m.role,content:m.content}));
            const lastUser=msgs.map(x=>x.role).lastIndexOf('user');
            return msgs.map((m,i)=>{
                if(Array.isArray(m.content) && i!==lastUser){
                    return {role:m.role,content:contentToDisplayText(m.content)+'\n[Ảnh cũ đã lược bỏ khỏi request để giảm dung lượng.]'};
                }
                return m;
            });
        }
        function memorySafeMessage(m){
            if(!Array.isArray(m.content)) return {role:m.role,content:m.content};
            return {role:m.role,content:contentToDisplayText(m.content)};
        }



        /* VILA Pro navigation helpers */
        function openFilePicker(){ document.getElementById('filePicker')?.click(); }
        function focusChat(){ const el=document.getElementById('userPrompt'); if(el){ el.focus(); document.getElementById('chatPanel')?.scrollIntoView({block:'nearest'}); } }
        function newVilaChat(){ window.clearChatHistory(); focusChat(); }
        function quickPrompt(text){ const el=document.getElementById('userPrompt'); if(!el)return; el.value=text + (text==='Viết code'?' cho mình một bản hoàn chỉnh, dễ đọc và có thể chạy được.':text==='Đọc file'?' Hãy đọc file mình gửi và tóm tắt đúng nội dung quan trọng.':text==='Phân tích và giải thích'?' Hãy phân tích rõ nguyên nhân, cách làm và kết luận.':''); el.dispatchEvent(new Event('input',{bubbles:true})); el.focus(); }
        function quickOpenFile(){ openFilePicker(); }
        function openMainMenu(){ document.getElementById('mainMenu')?.classList.add('open'); document.getElementById('mainMenuBackdrop')?.classList.add('open'); }
        function closeMainMenu(){ document.getElementById('mainMenu')?.classList.remove('open'); document.getElementById('mainMenuBackdrop')?.classList.remove('open'); }
        function openMemoryModal(){ const m=document.getElementById('memoryModal'); if(!m)return; const mc=document.getElementById('memoryMessageCount'); const pc=document.getElementById('memoryProjectCount'); const cs=document.getElementById('memoryCodeStatus'); if(mc)mc.textContent=String(conversationHistory.filter(m=>m.role!=='system').length); if(pc)pc.textContent=`${projectMemory.length} ký tự`; if(cs)cs.textContent=latestGeneratedCode?`${latestGeneratedCode.length.toLocaleString('vi-VN')} ký tự code đang lưu`:'Chưa có code'; m.classList.remove('opacity-0','pointer-events-none'); }
        function closeMemoryModal(){ document.getElementById('memoryModal')?.classList.add('opacity-0','pointer-events-none'); }
        function clearVilaMemoryAndClose(){ window.clearChatHistory(); closeMemoryModal(); }

        /* Event Listeners setup on load */
        document.addEventListener('DOMContentLoaded', () => {
            initVilaStartup();
            const toggleLayoutBtn = document.getElementById('toggleLayoutBtn');
            if (toggleLayoutBtn) toggleLayoutBtn.addEventListener('click', () => {
                const preview = document.getElementById('previewPanel');
                showMobilePanel(preview && preview.classList.contains('mobile-visible') ? 'chat' : 'preview');
            });
            if (window.innerWidth < 768) showMobilePanel('chat');
            setupSystemPrompt();
            loadConversationMemory();
            populateModelOptions();
            const reasoningEl=document.getElementById('reasoningLevel');
            if(reasoningEl){reasoningEl.value=reasoningLevel;reasoningEl.addEventListener('change',()=>{reasoningLevel=reasoningEl.value;localStorage.setItem('vila_reasoning_level',reasoningLevel);});}
            updateUIState();

            // Handle Textarea submit and resize
            const userPromptEl = document.getElementById('userPrompt');
            if(userPromptEl) {
                userPromptEl.addEventListener('keydown', handleKeyDown);
                userPromptEl.addEventListener('input', function() { autoResizeTextarea(this); });
            }

            const chatFormEl = document.getElementById('chatForm');
            if(chatFormEl) chatFormEl.addEventListener('submit', handleChatSubmit);

            const filePicker=document.getElementById('filePicker');
            const attachBtn=document.getElementById('attachFileBtn');
            if(attachBtn && filePicker){
                attachBtn.addEventListener('click',()=>filePicker.click());
                filePicker.addEventListener('change',()=>{ handleFiles(filePicker.files); filePicker.value=''; });
            }
            const clearBtn=document.getElementById('clearChatBtn');
            if(clearBtn) clearBtn.addEventListener('click',()=>window.clearChatHistory());

            const serverInput=document.getElementById('serverUrlInput');
            if(serverInput) serverInput.value=serverUrl;
            syncServerProxy();
            document.getElementById('mainMenuBtn')?.addEventListener('click', openMainMenu);
            document.getElementById('mainMenuBackdrop')?.addEventListener('click', closeMainMenu);
            document.addEventListener('keydown', (e)=>{ if(e.key==='Escape'){ closeMainMenu(); closeMemoryModal(); closeSettingsModal(); closeAccountModal(); } });
            document.getElementById('settingsModal')?.addEventListener('click',(e)=>{ if(e.target===e.currentTarget) closeSettingsModal(); });
            document.getElementById('memoryModal')?.addEventListener('click',(e)=>{ if(e.target===e.currentTarget) closeMemoryModal(); });
        });

        /* Canvas Interactive Particle Background Engine */
        const canvas = document.getElementById('bgCanvas');
        let ctx = null;
        if(canvas) {
            ctx = canvas.getContext('2d');
            let particles = [];

            function resizeCanvas() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }
            window.addEventListener('resize', resizeCanvas);
            resizeCanvas();

            class Particle {
                constructor() { this.reset(); }
                reset() {
                    this.x = Math.random() * canvas.width;
                    this.y = Math.random() * canvas.height;
                    this.vx = (Math.random() - 0.5) * 0.3;
                    this.vy = (Math.random() - 0.5) * 0.3;
                    this.radius = Math.random() * 1.5 + 0.5;
                    this.alpha = Math.random() * 0.4 + 0.1;
                    this.color = Math.random() > 0.5 ? '#a855f7' : '#00f2fe';
                }
                update() {
                    this.x += this.vx;
                    this.y += this.vy;
                    if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) this.reset();
                }
                draw() {
                    if(!ctx) return;
                    ctx.save();
                    ctx.globalAlpha = this.alpha;
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                    ctx.fillStyle = this.color;
                    ctx.fill();
                    ctx.restore();
                }
            }

            const particleCount = window.innerWidth < 768 ? 0 : 8;
            for (let i = 0; i < particleCount; i++) particles.push(new Particle());
            let lastFrame = 0;
            function animateParticles(now) {
                if (!ctx || particleCount === 0) return;
                if (now - lastFrame < 50) { requestAnimationFrame(animateParticles); return; }
                lastFrame = now;
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                particles.forEach(p => { p.update(); p.draw(); });
                requestAnimationFrame(animateParticles);
            }
            if (particleCount) requestAnimationFrame(animateParticles);
        }

        /* Audio Generator */
        let audioCtx = null;
        function playFuturisticSound(type) {
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (!audioCtx) audioCtx = new AudioContext();
                if (audioCtx.state === 'suspended') audioCtx.resume();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain); gain.connect(audioCtx.destination);
                const now = audioCtx.currentTime;

                if (type === 'send') {
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(440, now);
                    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
                    gain.gain.setValueAtTime(0.1, now);
                    gain.gain.linearRampToValueAtTime(0.01, now + 0.12);
                    osc.start(now); osc.stop(now + 0.12);
                } else if (type === 'complete') {
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(523.25, now);
                    osc.frequency.setValueAtTime(659.25, now + 0.08);
                    gain.gain.setValueAtTime(0.1, now);
                    gain.gain.linearRampToValueAtTime(0.01, now + 0.25);
                    osc.start(now); osc.stop(now + 0.25);
                }
            } catch (e) {
                console.log("Audio not supported or blocked");
            }
        }

        /* VILA Intelligence / Memory Core */
        function cleanDisplayText(text) {
            if (typeof text !== 'string') return '';
            // Remove invisible/control characters but preserve normal Unicode Vietnamese text.
            let s = text.normalize('NFC').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
            // Repair a few common UTF-8 mojibake sequences without touching code blocks.
            const fixes = [['â€™','’'],['â€œ','“'],['â€','”'],['â€“','–'],['â€”','—'],['â€¦','…'],['Â ',' '],['Â','']];
            const parts = s.split(/(```[\\s\\S]*?```)/g);
            for (let i = 0; i < parts.length; i += 2) {
                for (const [bad, good] of fixes) parts[i] = parts[i].split(bad).join(good);
                parts[i] = parts[i].replace(/[ \t]{3,}/g, '  ').replace(/\n{4,}/g, '\n\n\n');
            }
            return parts.join('');
        }

        function classifyTaskForModel(userText) {
            const t = String(userText || '').toLowerCase();
            if (/\b(code|lập trình|javascript|typescript|html|css|python|java|android|apk|debug|sửa code|fix code|build)\b/.test(t)) return 'coding';
            if (/\b(phân tích|logic|toán|giải thích sâu|kiến trúc|thuật toán|reason|debug)\b/.test(t)) return 'reasoning';
            if (/\b(ảnh|hình|image|vision|screenshot)\b/.test(t)) return 'multimodal';
            return 'general';
        }

        function getSmartModelOrder(userText) {
            const latestUser = [...conversationHistory].reverse().find(m => m && m.role === 'user');
            const task = classifyTaskForModel(userText || contentToDisplayText(latestUser?.content || ''));
            const primary = currentModel || (PROVIDERS[activeProvider]?.models?.[0]?.id || 'gemini-3.8-flash');
            if (activeProvider === 'groq') return ['openai/gpt-oss-120b'];
            const orders = {
                coding: ['gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-3.1-pro-preview','gemini-2.5-flash'],
                reasoning: ['gemini-3.1-pro-preview','gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-2.5-flash'],
                multimodal: ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-2.5-flash'],
                general: ['gemini-3.8-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-3.5-flash-lite','gemini-2.5-flash']
            };
            return [primary, ...(orders[task] || orders.general)].filter((m,i,a)=>a.indexOf(m)===i);
        }

        async function discoverAvailableGeminiModels() {
            if (!activeApiKey) return [];
            try {
                const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(activeApiKey)}&pageSize=1000`);
                if (!r.ok) return [];
                const d = await r.json();
                return (d.models || []).filter(m => Array.isArray(m.supportedGenerationMethods) && m.supportedGenerationMethods.includes('generateContent')).map(m => String(m.baseModelId || m.name || '').replace(/^models\//,''));
            } catch (_) { return []; }
        }

        function getSystemPrompt() {
            return `Bạn là trợ lý AI của VILA. Trong hội thoại, xưng "Bạn" và gọi người dùng là "bạn".
NHẬN DIỆN DỰ ÁN: Cha đẻ dự án là Bảo An. Khi phù hợp, ghi nhớ thông tin này như một phần ngữ cảnh dự án.
MỤC TIÊU: trả lời nhanh, rõ, đúng việc; giữ nguyên kiến trúc và endpoint mà người dùng đã yêu cầu. Có thể nói chuyện vui vẻ, có chút hài hước tự nhiên khi phù hợp, nhưng không màu mè và không lan man.

LẬP TRÌNH:
- Viết code rõ ràng, dễ đọc, có cấu trúc và tên biến/hàm dễ hiểu.
- Khi được yêu cầu code dài hoặc sửa project, ưu tiên bản hoàn chỉnh có thể thay thế trực tiếp; không dùng "...", TODO hay bỏ phần quan trọng.
- Trước khi đưa code, tự rà soát cú pháp, logic, API, null/undefined, đường dẫn file, lỗi mạng và luồng chính.
- Không tự ý đổi framework, model, endpoint, tên API hoặc kiến trúc đang hoạt động nếu người dùng không yêu cầu.
- Nếu có nhiều file, ghi rõ tên file và đưa nội dung đầy đủ của phần cần thay.
- Khi sửa lỗi, nói ngắn gọn nguyên nhân rồi đưa bản sửa.

CHAT & HÌNH ẢNH:
- Khi có ảnh, phân tích trực tiếp nội dung ảnh và chỉ nói điều quan sát được.
- Khi có file, đọc đúng dữ liệu được cung cấp và giữ ngữ cảnh giữa các lượt. Với ZIP, đọc cây file và nội dung các file văn bản/code có trong archive, không tự bỏ qua phần quan trọng.
- Trả lời tự nhiên như một trợ lý thật: ngắn khi câu hỏi đơn giản, sâu khi công việc cần. Không màu mè, không lặp lại, không chèn emoji nếu không cần.

ENDPOINT & GEMINI:
- Giữ nguyên Gemini và URL endpoint hiện tại của ứng dụng. Server proxy ưu tiên /api/chat; không tự thay URL.
- Nếu kết nối lỗi, báo đúng lỗi và cách sửa thực tế; không bịa rằng server đang chạy.
- Groq dùng duy nhất model openai/gpt-oss-120b; endpoint Groq không thay thế Gemini endpoint.

BỘ NHỚ DỰ ÁN:
${projectMemory || "(Chưa có bộ nhớ dự án riêng.)"}`;
        }

        function setupSystemPrompt() {
            conversationHistory = [{ role: 'system', content: getSystemPrompt() }];
        }

        function refreshSystemPrompt() {
            const idx = conversationHistory.findIndex(m => m.role === 'system');
            const prompt = getSystemPrompt();
            if (idx >= 0) conversationHistory[idx].content = prompt;
            else conversationHistory.unshift({ role: 'system', content: prompt });
        }

        function updateProjectMemoryFromTurn(userText, aiText) {
            const combined = `BẠN: ${userText}\nVILA: ${aiText}`;
            const important = combined.length > 9000 ? combined.slice(0, 9000) : combined;
            const stamp = new Date().toLocaleString('vi-VN');
            const entry = `[${stamp}]\n${important}`;
            projectMemory = `${projectMemory ? projectMemory + "\n\n" : ""}${entry}`.slice(-PROJECT_MEMORY_LIMIT);
            try { localStorage.setItem(PROJECT_MEMORY_KEY, projectMemory); } catch (e) {}
            refreshSystemPrompt();
        }

        function saveConversationMemory() {
            try {
                const messages = conversationHistory.filter(m => m.role !== 'system').slice(-MEMORY_LIMIT).map(memorySafeMessage);
                localStorage.setItem(MEMORY_KEY, JSON.stringify({
                    version: 17,
                    savedAt: Date.now(),
                    messages
                }));
                localStorage.setItem(PROJECT_MEMORY_KEY, projectMemory);
            } catch (e) {
                console.warn('Không thể lưu bộ nhớ hội thoại:', e);
            }
        }

        function loadConversationMemory() {
            setupSystemPrompt();
            try {
                projectMemory = localStorage.getItem(PROJECT_MEMORY_KEY) || "";
                refreshSystemPrompt();
                const raw = localStorage.getItem(MEMORY_KEY);
                if (!raw) return renderWelcomeMessage();

                const saved = JSON.parse(raw);
                const messages = Array.isArray(saved?.messages) ? saved.messages : [];
                if (!messages.length) return renderWelcomeMessage();

                conversationHistory.push(...messages);
                renderConversationMessages(messages);
            } catch (e) {
                console.warn('Bộ nhớ hội thoại không hợp lệ, tạo phiên mới:', e);
                localStorage.removeItem(MEMORY_KEY);
            localStorage.removeItem(PROJECT_MEMORY_KEY);
                renderWelcomeMessage();
            }
        }

        function renderWelcomeMessage() {
            const chatBox = document.getElementById('chatMessages');
            if (!chatBox) return;
        }

        function renderConversationMessages(messages) {
            const chatBox = document.getElementById('chatMessages');
            if (!chatBox) return;
            chatBox.innerHTML = '';
            messages.forEach(m => {
                if(m.role==='user') appendUserMessage(contentToDisplayText(m.content),false);
                if(m.role==='assistant') appendAiMessage(contentToDisplayText(m.content),false);
            });
            scrollToBottom();
        }

        function populateModelOptions() {
            const modelSelect = document.getElementById('modelSelect');
            const mobileModelSelect = document.getElementById('mobileModelSelect');
            if(!modelSelect || !mobileModelSelect) return;
            const provider = PROVIDERS[activeProvider] || PROVIDERS.gemini;
            modelSelect.innerHTML = '';
            mobileModelSelect.innerHTML = '';
            provider.models.forEach(m => {
                const a=document.createElement('option'); a.value=m.id; a.textContent=m.name; modelSelect.appendChild(a);
                const b=document.createElement('option'); b.value=m.id; b.textContent=m.name; mobileModelSelect.appendChild(b);
            });
            if(!provider.models.some(m=>m.id===currentModel)) currentModel=provider.models[0].id;
            modelSelect.value=currentModel; mobileModelSelect.value=currentModel;
            const handle=(e)=>{ currentModel=String(e.target.value); modelSelect.value=currentModel; mobileModelSelect.value=currentModel; localStorage.setItem(activeProvider==='gemini'?'vila_gemini_model':(activeProvider==='groq'?'vila_groq_model':'vila_sambanova_model'),currentModel); localStorage.setItem('vila_selected_model',currentModel); };
            modelSelect.onchange=handle; mobileModelSelect.onchange=handle;
        }

        function applyProviderPreset(type) {
            activeProvider = PROVIDERS[type] ? type : 'gemini';
            const p = PROVIDERS[activeProvider];
            activeApiKey = localStorage.getItem(p.keyStorage) || '';
            activeBaseUrl = activeProvider === 'gemini' ? (localStorage.getItem('vila_base_url') || p.baseUrl) : (activeProvider === 'sambanova' ? (localStorage.getItem('vila_sambanova_base_url') || p.baseUrl) : p.baseUrl);
            currentModel = localStorage.getItem(type==='gemini'?'vila_gemini_model':(type==='groq'?'vila_groq_model':'vila_sambanova_model')) || p.models[0].id;
            const keyInput=document.getElementById('apiKeyInput');
            const groqInput=document.getElementById('groqApiKeyInput');
            const sambaInput=document.getElementById('sambaApiKeyInput');
            const baseInput=document.getElementById('apiBaseUrlInput');
            const sambaBaseInput=document.getElementById('sambaApiBaseUrlInput');
            if(keyInput) keyInput.value=localStorage.getItem(PROVIDERS.gemini.keyStorage)||'';
            if(groqInput) groqInput.value=localStorage.getItem(PROVIDERS.groq.keyStorage)||'';
            if(sambaInput) sambaInput.value=localStorage.getItem(PROVIDERS.sambanova.keyStorage)||'';
            if(baseInput) baseInput.value=localStorage.getItem('vila_base_url')||PROVIDERS.gemini.baseUrl;
            if(sambaBaseInput) sambaBaseInput.value=localStorage.getItem('vila_sambanova_base_url')||PROVIDERS.sambanova.baseUrl;
            ['gemini','groq','sambanova'].forEach(name=>{ const ids={gemini:'presetGeminiBtn',groq:'presetGroqBtn',sambanova:'presetSambaBtn'}; const btn=document.getElementById(ids[name]); if(!btn)return; btn.classList.toggle('active',name===activeProvider); });
            localStorage.setItem('vila_provider',activeProvider);
            populateModelOptions(); updateUIState(); updateEndpointPreview();
        }

        function updateUIState() {
            const keyInput=document.getElementById('apiKeyInput');
            const baseInput=document.getElementById('apiBaseUrlInput');
            const serverInput=document.getElementById('serverUrlInput');
            if(keyInput)keyInput.value=activeApiKey;
            if(baseInput)baseInput.value=activeBaseUrl;
            if(serverInput)serverInput.value=serverUrl;
            if(sambaKeyInput)sambaKeyInput.value=localStorage.getItem(PROVIDERS.sambanova.keyStorage)||'';
            if(sambaBaseInput)sambaBaseInput.value=localStorage.getItem('vila_sambanova_base_url')||PROVIDERS.sambanova.baseUrl;

            const statusText = document.getElementById('keyStatusText');
            const badge = document.getElementById('keyStatusBadge');
            if(!statusText || !badge) return;

            const icon = badge.querySelector('i');
            if(serverUrl && activeProvider === 'gemini'){
                statusText.innerText='SERVER PROXY';
                statusText.className='hidden md:inline font-bold text-emerald-300';
                badge.className='flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono cursor-pointer';
                if(icon)icon.className='fa-solid fa-server text-[10px] text-emerald-400';
            } else if (activeProvider === 'gemini' && activeApiKey) {
                statusText.innerText = "GEMINI ACTIVE";
                statusText.className = "hidden md:inline font-bold text-cyan-300";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-cyan-400";
            } else if (activeProvider === 'groq' && activeApiKey) {
                statusText.innerText = "GROQ ACTIVE";
                statusText.className = "hidden md:inline font-bold text-emerald-300";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-emerald-400";
            } else if (activeProvider === 'sambanova' && activeApiKey) {
                statusText.innerText = "SAMBANOVA ACTIVE";
                statusText.className = "hidden md:inline font-bold text-violet-300";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-violet-400";
            } else {
                statusText.innerText = "NO API KEY";
                statusText.className = "hidden md:inline font-bold text-gray-400";
                badge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-gray-400 text-xs font-mono cursor-pointer";
                if(icon) icon.className = "fa-solid fa-key text-[10px] text-gray-500";
            }
        }

        function vilaTrimUrl(value) {
            return String(value || '').trim().replace(/\/+$/, '');
        }

        function updateEndpointPreview() {
            const base = vilaTrimUrl(document.getElementById('apiBaseUrlInput')?.value || activeBaseUrl || PROVIDERS.gemini.baseUrl);
            const server = vilaTrimUrl(document.getElementById('serverUrlInput')?.value || serverUrl);
            const direct = document.getElementById('directEndpointPreview');
            const proxy = document.getElementById('serverEndpointPreview');
            const samba = document.getElementById('sambaEndpointPreview');
            const sambaBase = vilaTrimUrl(document.getElementById('sambaApiBaseUrlInput')?.value || localStorage.getItem('vila_sambanova_base_url') || PROVIDERS.sambanova.baseUrl);
            if (direct) direct.textContent = `${base}/chat/completions`;
            if (proxy) proxy.textContent = server ? `${server}/api/chat` : 'Chưa cấu hình server';
            if (samba) samba.textContent = `${sambaBase}/chat/completions`;
        }

        function setApiConnectionStatus(ok, message) {
            const box = document.getElementById('apiConnectionStatus');
            if (!box) return;
            box.classList.toggle('ok', ok === true);
            box.classList.toggle('bad', ok === false);
            const text = box.querySelector('span:last-child');
            if (text) text.textContent = message;
        }

        /* VILA V3 PRO: Fast Gemini + Auto Fallback + Optional Google Search */
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        function isRetryableGeminiStatus(status) {
            return [408, 429, 500, 502, 503, 504].includes(Number(status));
        }

        function getFallbackModels(primaryModel) {
            const preferred = [
                primaryModel,
                'gemini-3.8-flash',
                'gemini-3.7-flash',
                'gemini-3.6-flash',
                'gemini-3.5-flash',
                'gemini-3.5-flash-lite',
                'gemini-3.1-pro-preview',
                'gemini-2.5-flash',
                'gemini-2.5-flash-lite'
            ];
            const validIds = new Set((PROVIDERS.gemini?.models || []).map(m => m.id));
            return [...new Set(preferred)].filter(id => validIds.has(id));
        }

        function parseRetryAfterMs(response, data) {
            const header = response?.headers?.get?.('Retry-After');
            if (header) {
                const seconds = Number(header);
                if (Number.isFinite(seconds)) return Math.min(MAX_RETRY_WAIT_MS, Math.max(500, seconds * 1000));
                const date = Date.parse(header);
                if (Number.isFinite(date)) return Math.min(MAX_RETRY_WAIT_MS, Math.max(500, date - Date.now()));
            }
            const msg = String(data?.error?.message || data?.message || '');
            const match = msg.match(/retry(?:Delay| after)?[\\s:=]+([0-9]+(?:\\.[0-9]+)?)s/i);
            if (match) return Math.min(MAX_RETRY_WAIT_MS, Math.max(500, Number(match[1]) * 1000));
            return 1800;
        }

        function markModelCooldown(model, ms) {
            modelCooldowns[model] = Date.now() + Math.min(ms, 60000);
            try { localStorage.setItem(REQUEST_COOLDOWN_KEY, JSON.stringify(modelCooldowns)); } catch (_) {}
        }

        function getModelCooldown(model) {
            const until = Number(modelCooldowns[model] || 0);
            if (until <= Date.now()) {
                delete modelCooldowns[model];
                return 0;
            }
            return until - Date.now();
        }

        function classifyGeminiError(status, data) {
            const msg = String(data?.error?.message || data?.message || '').toLowerCase();
            const reason = String(data?.error?.status || '').toLowerCase();
            return {
                quota: status === 429 && (reason.includes('resource_exhausted') || msg.includes('quota') || msg.includes('rate limit') || msg.includes('exceeded')),
                retryable: isRetryableGeminiStatus(status)
            };
        }

        function getResponseTokenBudget(messages){
            const text=contentToDisplayText(messages?.find(m=>m.role==='user')?.content||'').toLowerCase();
            if(/\b(code|lập trình|javascript|typescript|html|css|python|java|android|apk|debug|sửa code|fix code|build)\b/.test(text)) return isVilaFastMode()?8192:12288;
            if(/\b(phân tích|logic|toán|kiến trúc|thuật toán|reason|debug)\b/.test(text)) return isVilaFastMode()?6144:8192;
            if(/\b(ảnh|hình|image|vision|screenshot)\b/.test(text)) return isVilaFastMode()?6144:8192;
            return isVilaFastMode()?4096:8192;
        }

        async function requestOpenAICompatible(url, key, model, messages, extra={}, maxTokens=null) {
            const body={model,messages,max_tokens:Number.isFinite(Number(maxTokens))?Number(maxTokens):getResponseTokenBudget(messages),...extra};
            const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},body:JSON.stringify(body)});
            const raw=await response.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){ }
            if(!response.ok){ const err=new Error(data?.error?.message||data?.message||`API lỗi HTTP ${response.status}`); err.status=response.status; err.data=data; throw err; }
            const message=data?.choices?.[0]?.message||{};
            const aiReply=message.content||'';
            if(!aiReply) throw new Error('API không trả về nội dung.');
            return {aiReply,model,reasoning:message.reasoning||''};
        }

        async function requestGeminiFast(model, messages, maxRetries=1) {
            const fetchUrl=isServerMode()?getServerProxyUrl('/api/chat'):`${activeBaseUrl}/chat/completions`;
            if(!activeApiKey && !isServerMode()) throw new Error('Chưa có Gemini API Key.');
            let lastError=null;
            for(let attempt=0;attempt<=maxRetries;attempt++){
                try{
                    const headers={'Content-Type':'application/json'}; if(!isServerMode()) headers.Authorization=`Bearer ${activeApiKey}`;
                    const response=await fetch(fetchUrl,{method:'POST',headers,body:JSON.stringify({model,messages,max_tokens:getResponseTokenBudget(messages)})});
                    const raw=await response.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){ }
                    if(response.ok){const aiReply=data?.choices?.[0]?.message?.content||''; if(!aiReply)throw new Error('Gemini không trả về nội dung.'); return {aiReply,model};}
                    const detail=data?.error?.message||data?.message||`Gemini API lỗi HTTP ${response.status}`;
                    const err=new Error(detail);
                    err.status=response.status;
                    err.retryAfterMs=parseRetryAfterMs(response,data);
                    err.quota=classifyGeminiError(response.status,data).quota;
                    err.apiDetail=detail;
                    lastError=err;
                    // 404 is handled by the outer model fallback; do not waste a retry on the same route.
                    if(response.status===404) throw err;
                    if(response.status===429)throw err; if(!isRetryableGeminiStatus(response.status)||attempt>=maxRetries)throw err;
                    await sleep(isVilaFastMode()?250:Math.min(MAX_RETRY_WAIT_MS,700+attempt*900));
                }catch(err){lastError=err;if(err?.status===429)throw err;if(err?.status&&!isRetryableGeminiStatus(err.status))throw err;if(attempt>=maxRetries)throw err;await sleep(isVilaFastMode()?250:Math.min(MAX_RETRY_WAIT_MS,700+attempt*900));}
            }
            throw lastError||new Error('Không thể kết nối Gemini.');
        }

        function compactMessagesForGroq(messages, maxChars=10000) {
            // Conservative budget for Groq fallback. The user's org has an 8K TPM ceiling.
            const MAX_CHARS=Math.max(6000,Number(maxChars)||16000);
            const MAX_SYSTEM_CHARS=3500;
            const out=[];
            const system=messages.find(m=>m.role==='system');
            let used=0;
            if(system){
                const text=contentToDisplayText(system.content||'').slice(0,MAX_SYSTEM_CHARS);
                out.push({role:'system',content:text});
                used=text.length;
            }
            const rest=messages.filter(m=>m.role!=='system');
            for(let i=rest.length-1;i>=0 && used<MAX_CHARS;i--){
                const m=rest[i];
                const text=contentToDisplayText(m.content||'');
                const room=MAX_CHARS-used;
                if(room<=0)break;
                const clipped=text.slice(0,room);
                out.unshift({role:m.role,content:clipped});
                used+=clipped.length;
            }
            return out;
        }

        function isGeminiFallbackEligible(err){
            const status=Number(err?.status||0);
            // 404 usually means the selected Gemini model/route is unavailable.
            // Treat it as recoverable so VILA can try another Gemini model or Groq.
            return !status || [404,408,429,500,502,503,504].includes(status);
        }

        function getStoredGroqKey(){
            return String(localStorage.getItem(PROVIDERS.groq.keyStorage)||'').trim();
        }

        async function requestGroqFast(messages, keyOverride='', compactLimit=10000) {
            const groqKey=String(keyOverride||getStoredGroqKey()||activeApiKey).trim();
            if(!groqKey) throw new Error('Chưa có Groq API Key để fallback.');
            const compacted=compactMessagesForGroq(messages,compactLimit);
            const effort=['low','medium','high'].includes(reasoningLevel)?reasoningLevel:'medium';
            try{
                return await requestOpenAICompatible(
                    'https://api.groq.com/openai/v1/chat/completions',
                    groqKey,
                    'openai/gpt-oss-120b',
                    compacted,
                    {reasoning_effort:effort,include_reasoning:false},
                    1000
                );
            }catch(err){
                // One extra compaction pass specifically for HTTP 413.
                if(Number(err?.status)===413 && compactLimit>6000){
                    return requestGroqFast(messages,keyOverride,6000);
                }
                throw err;
            }
        }

        async function requestSambaNovaFast(messages, keyOverride='') {
            const key=String(keyOverride||localStorage.getItem(PROVIDERS.sambanova.keyStorage)||activeApiKey).trim();
            if(!key) throw new Error('Chưa có SambaNova API Key.');
            const base=vilaTrimUrl(localStorage.getItem('vila_sambanova_base_url')||PROVIDERS.sambanova.baseUrl);
            const model=currentModel||PROVIDERS.sambanova.models[0].id;
            return requestOpenAICompatible(`${base}/chat/completions`,key,model,messages,{},getResponseTokenBudget(messages));
        }

        async function requestGeminiWithFallback(messages) {
            if(activeProvider==='groq') return requestGroqFast(messages);
            if(activeProvider==='sambanova') return requestSambaNovaFast(messages);
            const taskText=contentToDisplayText(messages.find(m=>m.role==='user')?.content||'');
            const models=isServerMode()?[currentModel]:getSmartModelOrder(taskText);
            let lastError=null;
            for(const model of models){
                try{
                    return await requestGeminiFast(model,messages,1);
                }catch(err){
                    lastError=err;
                    const status=Number(err?.status||0);
                    if(status===404 || status===408 || status===429 || status>=500) continue;
                    break;
                }
            }

            // Gemini quota/temporary/network failure -> Groq fallback.
            // Permanent 400/401/403 errors are not hidden by fallback.
            if(lastError && !isGeminiFallbackEligible(lastError)) throw lastError;
            const groqKey=getStoredGroqKey();
            if(!groqKey) throw lastError||new Error('Gemini không khả dụng và chưa cấu hình Groq API Key.');
            try{
                setAiStatus('Gemini gặp lỗi — chuyển sang Groq','busy');
                const result=await requestGroqFast(messages,groqKey);
                result.fallback=true;
                result.fallbackFrom='gemini';
                return result;
            }catch(groqErr){
                groqErr.fallbackFrom='gemini';
                groqErr.geminiError=lastError;
                throw groqErr;
            }
        }

        function geminiGenerateContentUrl(model) {
            return `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(activeApiKey)}`;
        }

        async function requestGroqWebSearch(messages){
            if(!activeApiKey) throw new Error('Chưa có Groq API Key.');
            const input=messages.filter(m=>m.role!=='system').map(m=>({role:m.role,content:contentToDisplayText(m.content)}));
            const instructions=String(messages.find(m=>m.role==='system')?.content||'');
            const response=await fetch('https://api.groq.com/openai/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${activeApiKey}`},body:JSON.stringify({model:'openai/gpt-oss-120b',instructions,input,tools:[{type:'browser_search'}]})});
            const raw=await response.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){}
            if(!response.ok){const err=new Error(data?.error?.message||`Groq Search API lỗi HTTP ${response.status}`);err.status=response.status;throw err;}
            const aiReply=data?.output_text||data?.output?.flatMap(x=>x?.content||[]).filter(x=>x?.type==='output_text').map(x=>x.text).join('')||'';
            if(!aiReply)throw new Error('Groq Search không trả về nội dung.');
            return {aiReply,model:'openai/gpt-oss-120b'};
        }

        async function requestGeminiWebSearch(messages) {
            const requestMessages=Array.isArray(messages)&&messages.length ? messages : buildRequestMessages();
            if(isServerMode()){
                const response=await fetch(getServerProxyUrl('/api/search'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:currentModel,messages:requestMessages})});
                const raw=await response.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){ }
                if(!response.ok){ const err=new Error(data?.message||`Web Search API lỗi HTTP ${response.status}`); err.status=response.status; throw err; }
                if(!data?.aiReply) throw new Error('Server Search không trả về nội dung.');
                return {aiReply:data.aiReply,model:data.model||currentModel};
            }
            const systemMessage=requestMessages.find(m=>m.role==='system');
            const contents=requestMessages.filter(m=>m.role==='user'||m.role==='assistant').map(m=>({
                role:m.role==='assistant'?'model':'user',
                parts:Array.isArray(m.content)?m.content.map(part=>{
                    if(part?.type==='text') return {text:String(part.text||'')};
                    const url=part?.image_url?.url||''; const mm=String(url).match(/^data:([^;]+);base64,(.+)$/);
                    return mm?{inlineData:{mimeType:mm[1],data:mm[2]}}:{text:'[Ảnh đính kèm không có dữ liệu hợp lệ]'};
                }):[{text:String(m.content||'')}]
            }));
            const body={contents,tools:[{google_search:{}}],generationConfig:{maxOutputTokens:Math.min(getResponseTokenBudget(requestMessages),16384)}};
            if(systemMessage)body.systemInstruction={parts:[{text:String(systemMessage.content||'')}]};
            const model=currentModel||'gemini-3.8-flash';
            const response=await fetch(geminiGenerateContentUrl(model),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
            const raw=await response.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){ }
            if(!response.ok){const err=new Error(data?.error?.message||`Google Search API lỗi HTTP ${response.status}`);err.status=response.status;throw err;}
            const aiReply=(data?.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim(); if(!aiReply)throw new Error('Gemini Search không trả về nội dung.');
            const chunks=data?.groundingMetadata?.groundingChunks||[];
            const sources=chunks.map(c=>c?.web).filter(w=>w?.uri).filter((w,i,a)=>a.findIndex(x=>x.uri===w.uri)===i).slice(0,8);
            let answer=aiReply; if(sources.length)answer+='\n\n### Nguồn Web\n'+sources.map((src,i)=>`${i+1}. [${src.title||src.uri}](${src.uri})`).join('\n');
            return {aiReply:answer,model};
        }


        function detectCodeFile(rawText) {
            const m = rawText.match(/```([a-zA-Z0-9_-]+)?\s*([\s\S]*?)```/);
            if (!m) return null;
            const lang = (m[1] || '').toLowerCase();
            const extMap = {
                html: 'html', htm: 'html', css: 'css', js: 'js', javascript: 'js',
                json: 'json', py: 'py', python: 'py', txt: 'txt', md: 'md',
                xml: 'xml', svg: 'svg', csv: 'csv'
            };
            const ext = extMap[lang] || 'txt';
            return { code: m[2].trim(), ext, lang: lang || 'txt' };
        }

        window.downloadLatestFile = function() {
            if (!latestGeneratedCode) {
                showToast('Chưa có mã để tạo file.', 'info');
                return;
            }
            downloadTextFile(latestGeneratedCode, `VILA_${Date.now()}.html`, 'text/html');
        };

        function downloadTextFile(content, filename, mime = 'text/plain') {
            if(window.Android && typeof window.Android.saveTextFile==='function'){
                try{window.Android.saveTextFile(String(filename||'VILA.txt'),String(content||''),String(mime||'text/plain'));showToast(`Đã lưu ${filename} vào Downloads.`,'success');return;}catch(e){console.warn('Android save failed',e);}
            }
            const blob = new Blob([content], { type: mime + ';charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            showToast(`Đã tạo file ${filename}`, 'success');
        }

        /* Core Chat Execution */
        function setAiStatus(text, mode='ready'){
            const el=document.getElementById('aiStatus'); if(!el)return;
            el.className=`vila-ai-status ${mode==='busy'?'busy':mode==='search'?'search':''}`;
            const label=el.querySelector('span:last-child'); if(label)label.textContent=text;
        }

        /* VILA Pro Fast UX + command palette */
        function isVilaFastMode(){ return localStorage.getItem('vila_fast_mode')!=='0'; }
        function toggleVilaFastMode(){
            const next=!isVilaFastMode(); localStorage.setItem('vila_fast_mode',next?'1':'0');
            const text=document.getElementById('vilaFastModeText'); if(text) text.textContent=next?'Nhanh':'Chuẩn';
            showToast(next?'Đã bật phản hồi nhanh.':'Đã tắt phản hồi nhanh.','success');
        }
        function syncVilaFastMode(){ const t=document.getElementById('vilaFastModeText'); if(t)t.textContent=isVilaFastMode()?'Nhanh':'Chuẩn'; }
        function openVilaCommand(){
            const p=document.getElementById('vilaCommandPanel'); if(!p)return; p.classList.add('open');
            const i=document.getElementById('vilaCommandInput'); if(i){i.value='';setTimeout(()=>i.focus(),40);filterVilaCommands('');}
        }
        function closeVilaCommand(){ document.getElementById('vilaCommandPanel')?.classList.remove('open'); }
        function filterVilaCommands(q){
            q=String(q||'').toLowerCase().trim();
            document.querySelectorAll('.vila-command-item').forEach(b=>b.style.display=(!q||b.textContent.toLowerCase().includes(q))?'flex':'none');
        }
        function enableVilaWebSearch(){
            const t=document.getElementById('webSearchToggle'); if(t){t.checked=true;t.dispatchEvent(new Event('change',{bubbles:true}));}
            focusChat(); showToast('Đã bật tìm kiếm web cho câu hỏi tiếp theo.','success');
        }
        document.addEventListener('keydown',e=>{
            if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openVilaCommand();}
            if(e.key==='Escape')closeVilaCommand();
        });
        setTimeout(syncVilaFastMode,250);

        function getAutoVoice(){ return localStorage.getItem('vila_auto_voice') !== '0'; }
        function setAutoVoice(enabled){ localStorage.setItem('vila_auto_voice',enabled?'1':'0'); const el=document.getElementById('startupAutoVoice'); if(el)el.checked=enabled; }
        function closeStartup(){ const el=document.getElementById('vilaStartup'); if(el)el.classList.add('hidden'); try{sessionStorage.setItem('vila_startup_seen','1')}catch(_){} }
        function selectStartupProvider(type){
            if(!PROVIDERS[type]) return;
            applyProviderPreset(type);
            document.getElementById('startupGeminiCard')?.classList.toggle('active',type==='gemini');
            document.getElementById('startupGroqCard')?.classList.toggle('active',type==='groq');
            const gm=document.getElementById('startupGeminiModel'); if(gm)gm.textContent=localStorage.getItem('vila_gemini_model')||PROVIDERS.gemini.models[0].id;
        }
        function startVilaFromStartup(){
            const voice=document.getElementById('startupAutoVoice'); if(voice)setAutoVoice(voice.checked);
            closeStartup();
            if(activeProvider==='gemini' && !activeApiKey && !serverUrl) openSettingsModal();
            else if(activeProvider==='groq' && !getStoredGroqKey()) openSettingsModal();
            else focusChat();
        }
        function initVilaStartup(){
            const voice=document.getElementById('startupAutoVoice'); if(voice)voice.checked=getAutoVoice();
            const gm=document.getElementById('startupGeminiModel'); if(gm)gm.textContent=localStorage.getItem('vila_gemini_model')||PROVIDERS.gemini.models[0].id;
            document.getElementById('startupGeminiCard')?.classList.toggle('active',activeProvider==='gemini');
            document.getElementById('startupGroqCard')?.classList.toggle('active',activeProvider==='groq');
            setTimeout(()=>{ try{ if(sessionStorage.getItem('vila_startup_seen')==='1') closeStartup(); }catch(_){} },80);
        }
        async function handleChatSubmit(e) {
            if(e)e.preventDefault(); if(isProcessing)return;
            const inputEl=document.getElementById('userPrompt'); if(!inputEl)return;
            let promptText=inputEl.value.trim();
            const usableFiles=pendingAttachments.filter(f=>f.status==='ready');
            if(!promptText&&!usableFiles.length)return;
            const textFiles=usableFiles.filter(f=>f.kind==='text');
            const imageFiles=usableFiles.filter(f=>f.kind==='image'&&f.dataUrl);
            const textContext=textFiles.map(f=>`\n\n[FILE: ${f.name}]\n${f.content||'[File trống]'}\n[/FILE]`).join('');
            if(textContext)promptText=(promptText||'Hãy đọc và phân tích các file tôi đính kèm.')+textContext;
            if(imageFiles.length)promptText=(promptText||'Hãy phân tích ảnh tôi đính kèm.')+imageFiles.map(f=>`\n\n[ẢNH: ${f.name}]`).join('');
            const encodedImageBytes=imageFiles.reduce((sum,f)=>{const comma=String(f.dataUrl||'').indexOf(',');return sum+(comma>0?Math.floor((f.dataUrl.length-comma-1)*0.75):0);},0);
            if(encodedImageBytes>MAX_IMAGE_REQUEST_BYTES){showToast('Tổng dung lượng ảnh sau tối ưu vượt 12MB.','error');return;}
            if(!isServerMode()&&!activeApiKey){showToast(`Vui lòng nhập ${activeProvider==='groq'?'Groq':'Gemini'} API Key hoặc cấu hình VILA Server.`,'error');openSettingsModal();return;}
            playFuturisticSound('send');
            const displayPrompt=inputEl.value.trim()||'Hãy đọc và phân tích file/ảnh đính kèm.';
            appendUserMessage(displayPrompt,true,usableFiles);
            inputEl.value='';pendingAttachments=[];renderAttachmentTray();inputEl.style.height='auto';const counter=document.getElementById('charCounter');if(counter)counter.innerText='0 ký tự';
            isProcessing=true;const loadingMsgId=appendTypingIndicator();
            let userContent=promptText;if(imageFiles.length)userContent=[{type:'text',text:promptText},...imageFiles.map(f=>({type:'image_url',image_url:{url:f.dataUrl}}))];
            conversationHistory.push({role:'user',content:userContent});saveConversationMemory();
            const useWebSearch=!!document.getElementById('webSearchToggle')?.checked;
            const savedProvider=activeProvider,savedKey=activeApiKey,savedBase=activeBaseUrl;
            try{
                let result;
                if(savedProvider==='groq'&&imageFiles.length){
                    const geminiKey=localStorage.getItem('vila_api_key')||'';
                    if(!geminiKey)throw new Error('GPT-OSS 120B xử lý văn bản; để đọc ảnh, hãy thêm Gemini API Key.');
                    setAiStatus(useWebSearch?'Đang tìm kiếm + đọc ảnh':'Đang đọc ảnh bằng Gemini','busy');
                    activeProvider='gemini';activeApiKey=geminiKey;activeBaseUrl=localStorage.getItem('vila_base_url')||PROVIDERS.gemini.baseUrl;currentModel='gemini-3.8-flash';
                    result=useWebSearch?await requestGeminiWebSearch(buildRequestMessages()):await requestGeminiWithFallback(buildRequestMessages());
                }else if(useWebSearch){
                    setAiStatus('Đang tìm kiếm web','search');
                    result=savedProvider==='groq'?await requestGroqWebSearch(buildRequestMessages()):await requestGeminiWebSearch(buildRequestMessages());
                }else{
                    setAiStatus(savedProvider==='groq'?'Groq • GPT-OSS 120B':'Gemini • Smart','busy');
                    result=savedProvider==='groq'
                        ? await requestGroqFast(buildRequestMessages(),savedKey)
                        : await requestGeminiWithFallback(buildRequestMessages());
                }
                const aiReply=cleanDisplayText(result.aiReply);
                if(result?.fallback) setAiStatus('Groq fallback • GPT-OSS 120B','busy');
                conversationHistory.push({role:'assistant',content:aiReply});updateProjectMemoryFromTurn(promptText,aiReply);saveConversationMemory();
                removeMessage(loadingMsgId);appendAiMessage(aiReply);playFuturisticSound('complete');extractAndExecuteCode(aiReply); if(getAutoVoice()) setTimeout(()=>window.speakVilaText(aiReply),120);
                setAiStatus(useWebSearch?'Đã tìm kiếm':'Đã sẵn sàng','search');
            }catch(err){
                removeMessage(loadingMsgId);
                const status=err?.status?` (HTTP ${err.status})`:'';
                const friendly=err?.status===404
                    ?'Gemini không tìm thấy model/endpoint hiện tại. VILA đã thử model dự phòng; hãy kiểm tra API Key hoặc bật Groq để tự chuyển engine.'
                    :(err?.status===413?'Request quá lớn; VILA đã rút gọn context cho Groq nhưng vẫn vượt giới hạn.':(err?.status===429?'API đang giới hạn quota/rate limit.':(err?.message||'Không thể kết nối AI.')));
                appendErrorMessage(`Lỗi API${status}: ${friendly}`);setAiStatus('Có lỗi — kiểm tra Cài đặt','');
            }finally{
                activeProvider=savedProvider;activeApiKey=savedKey;activeBaseUrl=savedBase;populateModelOptions();updateUIState();isProcessing=false;
            }
        }


        function showMobilePanel(which) {
            const previewPanel = document.getElementById('previewPanel');
            const chatPanel = document.getElementById('chatPanel');
            const btn = document.getElementById('toggleLayoutBtn');
            if (!previewPanel || !chatPanel || window.innerWidth >= 768) return;
            const showPreview = which === 'preview';
            previewPanel.classList.toggle('mobile-visible', showPreview);
            previewPanel.classList.toggle('mobile-hidden', !showPreview);
            chatPanel.classList.toggle('mobile-hidden', showPreview);
            chatPanel.classList.toggle('mobile-visible', !showPreview);
            if (btn) {
                btn.innerHTML = showPreview ? '<i class="fa-solid fa-comments"></i>' : '<i class="fa-solid fa-code"></i>';
                btn.title = showPreview ? 'Quay lại trò chuyện' : 'Mở màn hình code';
            }
        }

        function extractAndExecuteCode(rawText) {
            let cleanText = rawText.replace(/<think>[\s\S]*?<\/think>/g, '');
            const fenced = cleanText.match(/```(?:html|htm)?\s*([\s\S]*?)```/i);
            const bare = cleanText.match(/(?:<!doctype html|<html[\s>])([\s\S]*)/i);
            const code = (fenced && fenced[1]) ? fenced[1].trim() : (bare ? (bare[0] || '').trim() : '');

            if (code && /(?:<!doctype html|<html[\s>])/i.test(code)) {
                latestGeneratedCode = code;
                localStorage.setItem(CODE_MEMORY_KEY, latestGeneratedCode);
                runGeneratedCode();
                setTimeout(()=>autoCreateZipForGeneratedCode(),80);

                if (window.innerWidth < 768) {
                    showMobilePanel('preview');
                }
            }
        }

        function runGeneratedCode() {
            if (!latestGeneratedCode) return;
            const iframe = document.getElementById('liveFrame');
            const placeholder = document.getElementById('previewPlaceholder');
            if(!iframe || !placeholder) return;
            
            placeholder.style.display = 'none';

            const doc = iframe.contentWindow?.document;
            if(doc) {
                doc.open();
                doc.write(latestGeneratedCode);
                doc.close();
                showToast('Đã chạy mã thành công!', 'success');
            }
        }

        function inferGeneratedFileMeta(code) {
            const m = String(code || '').match(/^(?:\s*<\!doctype html|\s*<html[\s>])/i);
            if (m) return { ext:'html', mime:'text/html', name:'VILA_App' };
            if (/^\s*[{[]/.test(code) && /["']?[A-Za-z0-9_-]+["']?\s*:/.test(code)) return { ext:'json', mime:'application/json', name:'VILA_Data' };
            if (/^\s*(?:body|html|\.|#|@media|:root)\b[^{]*\{/.test(code)) return { ext:'css', mime:'text/css', name:'VILA_Style' };
            return { ext:'txt', mime:'text/plain', name:'VILA_Code' };
        }

        function downloadCodeAsFile() {
            if (!latestGeneratedCode) {
                showToast('Chưa có mã để tải về!', 'info');
                return;
            }
            const meta = inferGeneratedFileMeta(latestGeneratedCode);
            downloadTextFile(latestGeneratedCode, `${meta.name}_${Date.now()}.${meta.ext}`, meta.mime);
        }

        function reviewCurrentCode() {
            if (!latestGeneratedCode) {
                showToast('Chưa có code để kiểm tra.', 'info');
                return;
            }
            const input = document.getElementById('userPrompt');
            if (!input) return;
            input.value = `Kiểm tra toàn bộ code hiện tại trong Live Preview. Tìm lỗi cú pháp, lỗi logic, lỗi responsive, lỗi API, lỗi bảo mật và lỗi chạy thực tế. Nếu có lỗi, sửa trực tiếp và trả lại bản hoàn chỉnh. Nếu không có lỗi rõ ràng, nêu ngắn gọn các điểm đã kiểm tra.\n\n[CODE HIỆN TẠI]\n${latestGeneratedCode}\n[/CODE HIỆN TẠI]`;
            input.dispatchEvent(new Event('input', {bubbles:true}));
            input.focus();
            showToast('Đã chuẩn bị yêu cầu kiểm tra code.', 'success');
        }

        /* VILA Pro Developer Workspace */
        function prepareCodingAgent(){
            const input=document.getElementById('userPrompt');
            if(!input)return;
            const code=latestGeneratedCode ? `\n\nCODE HIỆN TẠI:\n${latestGeneratedCode.slice(0,12000)}\n\n` : '';
            input.value=`Bạn đang ở CHẾ ĐỘ LẬP TRÌNH VILA PRO. Hãy xử lý như một senior software engineer: phân tích yêu cầu, lập kế hoạch ngắn, viết code hoàn chỉnh, kiểm tra cú pháp/logic/API/null/path/network, ưu tiên mã chạy được. Nếu sửa project, trả về bản hoàn chỉnh thay vì chỉ đưa vài dòng.${code}`;
            input.dispatchEvent(new Event('input',{bubbles:true}));
            input.focus();
            showToast('Đã bật Chế độ lập trình.', 'success');
        }

        function buildProjectReadme(){
            return `# VILA Pro Generated Project\n\nGenerated by VILA Pro on ${new Date().toISOString()}\n\n## Included\n- Generated application code\n- VILA project metadata\n- README\n\n## Notes\nMở index.html để chạy bản web nếu project được VILA tạo dưới dạng HTML/CSS/JS.\n`;
        }

        async function blobToBase64(blob){ return await new Promise((resolve,reject)=>{ const reader=new FileReader(); reader.onload=()=>resolve(String(reader.result||'').split(',')[1]||''); reader.onerror=reject; reader.readAsDataURL(blob); }); }
        async function exportProjectZip(options={}){
            const auto=!!options.auto;
            if(typeof JSZip==='undefined'){if(!auto)showToast('Thư viện ZIP chưa sẵn sàng.','error');return false;}
            if(!latestGeneratedCode){if(!auto)showToast('Chưa có code để đóng gói. Hãy yêu cầu VILA viết project trước.','info');return false;}
            try{
                const zip=new JSZip(),meta=inferGeneratedFileMeta(latestGeneratedCode),root=zip.folder('VILA-Pro-Project');
                root.file(meta.ext==='html'?'index.html':`generated.${meta.ext}`,latestGeneratedCode);
                root.file('README.md',buildProjectReadme());
                root.file('vila-project.json',JSON.stringify({name:'VILA Pro Generated Project',version:'17.5.0',provider:activeProvider,model:currentModel,generatedAt:new Date().toISOString(),creator:'Bảo An',source:'VILA Pro'},null,2));
                const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6}}),filename=`VILA-Pro-Project-${Date.now()}.zip`;
                if(window.Android&&typeof window.Android.saveBase64File==='function'){window.Android.saveBase64File(filename,await blobToBase64(blob),'application/zip');showToast(auto?'Đã tạo ZIP trực tiếp trong Downloads.':'Đã lưu project ZIP vào Downloads.','success');return true;}
                const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),2000);showToast('Đã xuất project ZIP thành công.','success');return true;
            }catch(e){if(!auto)showToast(`Không thể xuất ZIP: ${e.message||'lỗi không xác định'}`,'error');return false;}
        }
        async function autoCreateZipForGeneratedCode(){ if(!latestGeneratedCode||localStorage.getItem('vila_auto_zip')==='0')return; await exportProjectZip({auto:true}); }

        /* Render Helpers */
        function appendUserMessage(text, doScroll = true, files = []) {
            const chatBox=document.getElementById('chatMessages'); if(!chatBox)return;
            const div=document.createElement('div'); div.className='flex gap-4 items-start justify-end group';
            const fileHtml=(files||[]).filter(f=>f.status==='ready').map(f=>f.kind==='image'&&f.dataUrl
                ? `<div class="mt-2 flex flex-wrap gap-2"><div class="rounded-xl overflow-hidden border border-white/10 bg-black/20"><img src="${f.dataUrl}" alt="${escapeHtml(f.name)}" class="max-w-[220px] max-h-48 object-cover"></div></div>`
                : `<div class="mt-2 inline-flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-black/20 border border-white/10 text-[11px] text-cyan-100"><i class="fa-solid fa-file-lines"></i>${escapeHtml(f.name)}</div>`).join('');
            div.innerHTML=`<div class="max-w-[85%] space-y-1"><div class="flex items-center justify-end gap-2"><span class="text-[10px] text-gray-500 font-mono">${getCurrentTime()}</span><span class="font-bold text-xs text-cyan-300">BẠN</span></div><div class="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white rounded-2xl rounded-tr-none p-4 text-sm leading-relaxed shadow-lg shadow-purple-900/30">${escapeHtml(contentToDisplayText(text)).replace(/\n/g,'<br>')}${fileHtml}</div></div><div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-400 to-indigo-600 p-[1px] shrink-0 shadow-md"><div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-white"><i class="fa-solid fa-user text-xs"></i></div></div>`;
            chatBox.appendChild(div); if(doScroll)scrollToBottom();
        }


        function appendAiMessage(rawText, doScroll = true) {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return;
            const div = document.createElement('div');
            div.className = "flex gap-4 items-start group";

            rawText = cleanDisplayText(rawText);
            let reasoningContent = "";
            let mainContent = rawText;

            const thinkMatch = rawText.match(/<think>([\s\S]*?)<\/think>/i);
            if (thinkMatch) {
                reasoningContent = thinkMatch[1].trim();
                mainContent = rawText.replace(/<think>[\s\S]*?<\/think>/i, '').trim();
            }

            const speechId = 'speech_' + Math.random().toString(36).slice(2,10);
            vilaSpeechStore[speechId] = mainContent;
            let formattedHtml = formatMarkdownText(mainContent);
            let reasoningHtml = "";

            if (reasoningContent) {
                reasoningHtml = `
                    <details class="mb-3 rounded-xl bg-black/40 border border-purple-500/20 text-xs text-gray-400 overflow-hidden">
                        <summary class="p-2.5 font-mono cursor-pointer hover:bg-white/5 font-semibold text-purple-300 flex items-center gap-2">
                            <i class="fa-solid fa-brain text-neon-violet"></i> Thấu Quan Trí Tuệ (Reasoning Process)
                        </summary>
                        <div class="p-3 border-t border-purple-500/10 font-mono text-[11px] leading-relaxed whitespace-pre-wrap text-gray-400">
                            ${escapeHtml(reasoningContent)}
                        </div>
                    </details>
                `;
            }

            div.innerHTML = `
                <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1px] shrink-0 shadow-md shadow-purple-500/20">
                    <div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-cyan-300">
                        VILA
                    </div>
                </div>
                <div class="flex-1 space-y-2 overflow-hidden">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-sm text-gradient">VILA Pro</span>
                        <span class="text-[10px] text-gray-500 font-mono">${getCurrentTime()}</span>
                        <button type="button" class="vila-ai-tool ml-1" title="Đọc câu trả lời" onclick="speakVilaStored('${speechId}')"><i class="fa-solid fa-volume-high"></i></button>
                        <button type="button" class="vila-ai-tool" title="Dừng giọng nói" onclick="stopVilaSpeech()"><i class="fa-solid fa-stop"></i></button>
                        <button type="button" class="vila-zip-ready" title="Tạo và lưu ZIP" onclick="exportProjectZip()"><i class="fa-solid fa-file-zipper"></i> ZIP</button>
                    </div>
                    <div class="glass-card rounded-2xl rounded-tl-none p-4 text-sm text-gray-200 leading-relaxed border border-purple-500/20 shadow-xl overflow-x-auto">
                        ${reasoningHtml}
                        ${formattedHtml}
                    </div>
                </div>
            `;
            chatBox.appendChild(div);
            if (doScroll) scrollToBottom();
        }

        function appendTypingIndicator() {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return '';
            const id = 'typing_' + Date.now();
            const div = document.createElement('div');
            div.id = id;
            div.className = "flex gap-4 items-start animate-pulse";
            div.innerHTML = `
                <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1px] shrink-0">
                    <div class="w-full h-full bg-dark-surface rounded-[11px] flex items-center justify-center text-xs font-bold text-cyan-300">
                        VILA
                    </div>
                </div>
                <div class="glass-card rounded-2xl rounded-tl-none p-4 text-xs font-mono text-cyan-300 border border-purple-500/20 flex items-center gap-3">
                    <i class="fa-solid fa-circle-notch fa-spin text-neon-violet"></i>
                    <span>Bạn đang xử lý...</span>
                </div>
            `;
            chatBox.appendChild(div);
            scrollToBottom();
            return id;
        }

        function appendErrorMessage(msg) {
            const chatBox = document.getElementById('chatMessages');
            if(!chatBox) return;
            const div = document.createElement('div');
            div.className = "flex gap-4 items-start";
            div.innerHTML = `
                <div class="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 shrink-0 flex items-center justify-center text-rose-400">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div class="bg-rose-950/40 border border-rose-500/30 text-rose-300 rounded-2xl p-4 text-xs font-mono leading-relaxed">
                    ${escapeHtml(msg)}
                </div>
            `;
            chatBox.appendChild(div);
            scrollToBottom();
        }

        function removeMessage(id) {
            const el = document.getElementById(id);
            if (el) el.remove();
        }

        function formatMarkdownText(text) {
            return text.replace(/```(html|css|js|javascript|json|python|py|txt|md|xml|svg|csv)?([\s\S]*?)```/gi, (match, lang, code) => {
                const codeId = 'code_' + Math.random().toString(36).substring(2, 10);
                const safeCode = escapeHtml(code.trim());
                const normalized = (lang || 'txt').toLowerCase();
                const ext = ({
                    javascript:'js', python:'py'
                })[normalized] || normalized;

                return `
                    <div class="my-3 rounded-xl bg-dark-base border border-white/10 overflow-hidden font-mono text-xs shadow-xl">
                        <div class="bg-dark-surface/90 px-3 py-2 border-b border-white/10 flex items-center justify-between text-gray-400 text-[11px]">
                            <span class="font-bold text-cyan-400 uppercase">${escapeHtml(ext || 'CODE')}</span>
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="copyCodeToClipboard('${codeId}')" class="hover:text-white flex items-center gap-1 transition-all" title="Sao chép">
                                    <i class="fa-regular fa-copy"></i> Sao chép
                                </button>
                                <button type="button" onclick="downloadCodeBlock('${codeId}','${escapeHtml(ext || 'txt')}')" class="hover:text-cyan-300 flex items-center gap-1 transition-all" title="Tải thành file">
                                    <i class="fa-solid fa-download"></i> File
                                </button>
                            </div>
                        </div>
                        <pre class="p-4 overflow-x-auto text-cyan-200 leading-relaxed"><code id="${codeId}">${safeCode}</code></pre>
                    </div>
                `;
            }).replace(/\n/g, '<br>');
        }

        window.downloadCodeBlock = function(elementId, ext) {
            const el = document.getElementById(elementId);
            if (!el) return;
            const cleanExt = String(ext || 'txt').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'txt';
            const mime = cleanExt === 'html' ? 'text/html' :
                         cleanExt === 'css' ? 'text/css' :
                         cleanExt === 'js' ? 'text/javascript' :
                         cleanExt === 'json' ? 'application/json' : 'text/plain';
            downloadTextFile(el.innerText, `VILA_${Date.now()}.${cleanExt}`, mime);
        };

        window.copyCodeToClipboard = function(elementId) {
            const codeEl = document.getElementById(elementId);
            if (!codeEl) return;
            
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(codeEl.innerText).then(() => {
                    showToast('Đã sao chép mã thành công!', 'success');
                }).catch(err => {
                    fallbackCopy(codeEl.innerText);
                });
            } else {
                fallbackCopy(codeEl.innerText);
            }
        }

        function fallbackCopy(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                showToast('Đã sao chép mã thành công!', 'success');
            } catch (err) {
                showToast('Không thể sao chép!', 'error');
            }
            document.body.removeChild(textarea);
        }

        function autoResizeTextarea(el) {
            el.style.height = 'auto';
            el.style.height = (el.scrollHeight) + 'px';
            const counter = document.getElementById('charCounter');
            if(counter) counter.innerText = `${el.value.length} ký tự`;
        }

        function handleKeyDown(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleChatSubmit();
            }
        }

        function scrollToBottom() {
            const chatBox = document.getElementById('chatMessages');
            if(chatBox) chatBox.scrollTop = chatBox.scrollHeight;
        }

        function getCurrentTime() {
            const d = new Date();
            return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        function escapeHtml(str) {
            return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }

        /* Viewport Switching */
        window.setViewport = function(type) {
            const container = document.getElementById('viewportContainer');
            if(!container) return;
            const btns = document.querySelectorAll('.vp-btn');
            btns.forEach(b => { b.classList.remove('bg-white/10', 'text-white'); b.classList.add('text-gray-400'); });
            const activeBtn = document.getElementById(`vp-${type}`);
            if (activeBtn) { activeBtn.classList.add('bg-white/10', 'text-white'); activeBtn.classList.remove('text-gray-400'); }

            if (type === 'mobile') {
                container.style.width = '375px'; container.style.height = '667px';
            } else if (type === 'tablet') {
                container.style.width = '768px'; container.style.height = '100%';
            } else {
                container.style.width = '100%'; container.style.height = '100%';
            }
        }

        window.toggleFullscreenPreview = function() {
            const previewPanel = document.getElementById('previewPanel');
            if(!previewPanel) return;
            if (!document.fullscreenElement) {
                previewPanel.requestFullscreen().catch(() => showToast('Không thể bật toàn màn hình', 'error'));
            } else {
                document.exitFullscreen();
            }
        }

        let appImmersive=false;
        window.toggleAppFullscreen = function() {
            if(window.Android && typeof window.Android.setImmersiveMode==='function'){
                try{appImmersive=!appImmersive;window.Android.setImmersiveMode(appImmersive);showToast(appImmersive?'Đã bật chế độ toàn màn hình.':'Đã thoát chế độ toàn màn hình.','info');return;}catch(_){ }
            }
            if(!document.fullscreenElement){document.documentElement.requestFullscreen().catch(()=>showToast('Không hỗ trợ toàn màn hình','error'));}
            else if(document.exitFullscreen)document.exitFullscreen();
        }

        window.openPreviewNewTab = function() {
            if (!latestGeneratedCode) return showToast('Chưa có mã để mở tab mới!', 'info');
            const win = window.open();
            if(win) win.document.write(latestGeneratedCode);
        }

        function renderWelcomeState(){
            const chatBox=document.getElementById('chatMessages');
            if(!chatBox) return;
            chatBox.innerHTML=`
              <div class="vila-quick-actions" aria-label="Gợi ý nhanh">
                <button type="button" class="vila-quick-btn" onclick="quickPrompt('Viết code')"><i class="fa-solid fa-code"></i><span>Viết code</span></button>
                <button type="button" class="vila-quick-btn" onclick="quickPrompt('Đọc file')"><i class="fa-solid fa-file-lines"></i><span>Đọc file</span></button>
                <button type="button" class="vila-quick-btn" onclick="quickOpenFile()"><i class="fa-solid fa-folder-open"></i><span>Chọn file</span></button>
                <button type="button" class="vila-quick-btn" onclick="quickPrompt('Phân tích và giải thích')"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Phân tích</span></button>
              </div>
              <div class="flex gap-3 items-start group">
                <div class="w-9 h-9 rounded-xl overflow-hidden shrink-0 bg-[#19191c] border border-[#33343a]">
                  <img src="/vila_avatar.png" alt="VILA Pro" class="w-full h-full object-cover" style="object-position:20% 50%">
                </div>
                <div class="flex-1 space-y-2">
                  <div class="flex items-center gap-2"><span class="font-semibold text-sm text-white">VILA Pro</span><span class="text-[10px] text-gray-500">AI Assistant</span></div>
                  <div class="rounded-2xl rounded-tl-none bg-[#171719] border border-[#2a2a2e] p-4 text-sm text-gray-200 leading-relaxed">
                    <p class="mb-2"><strong>Chào bạn.</strong> Mình là VILA Pro.</p>
                    <p class="text-gray-400">Mình có thể trò chuyện, viết code, đọc ảnh, PDF, DOCX và ZIP. Khi làm code, mình ưu tiên bản rõ ràng, đầy đủ và dùng được.</p>
                  </div>
                </div>
              </div>`;
            scrollToBottom();
        }

        window.clearChatHistory = function() {
            localStorage.removeItem(MEMORY_KEY);
            localStorage.removeItem(PROJECT_MEMORY_KEY);
            localStorage.removeItem(CODE_MEMORY_KEY);
            latestGeneratedCode = '';
            projectMemory = '';
            pendingAttachments = [];
            renderAttachmentTray();
            setupSystemPrompt();
            renderWelcomeState();
            try {
                vilaDB().then(db=>{ const tx=db.transaction('memory','readwrite'); tx.objectStore('memory').delete('main'); }).catch(()=>{});
            } catch(_) {}
            showToast('Đã tạo cuộc trò chuyện mới.', 'info');
        }

        async function testServerConnection(){
            const input=document.getElementById('serverUrlInput'); const u=String(input?.value||serverUrl||'').trim().replace(/\/$/,'');
            if(!u)return showToast('Chưa nhập VILA Server URL.','error');
            try{const r=await fetch(`${u}/api/health`,{cache:'no-store'});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d?.message||`HTTP ${r.status}`);setApiConnectionStatus(true, `Server OK • /api/chat • Gemini key ${d.apiKeyConfigured?'đã cấu hình':'chưa cấu hình'}`);updateEndpointPreview();showToast(`Server OK • API key ${d.apiKeyConfigured?'đã cấu hình':'chưa cấu hình'}`,'success');}
            catch(e){setApiConnectionStatus(false, 'Server không phản hồi');showToast(`Server không phản hồi: ${e.message||'lỗi mạng'}`,'error');}
        }
        function syncServerProxy(){
            try{
                if(window.Android&&typeof window.Android.getServerUrl==='function'){
                    const remote=String(window.Android.getServerUrl()||'').trim();
                    if(remote && remote!==serverUrl){serverUrl=remote;localStorage.setItem('vila_server_url',serverUrl);}
                    if(serverUrl&&typeof window.Android.setServerUrl==='function')window.Android.setServerUrl(serverUrl);
                }
            }catch(_){ }
            updateUIState();
        }

        /* Settings Modal & API Key Operations */
        window.openSettingsModal = function() {
            applyProviderPreset(activeProvider);
            const modal = document.getElementById('settingsModal');
            const modalContent = document.getElementById('modalContent');
            if(!modal || !modalContent) return;
            modal.classList.remove('opacity-0', 'pointer-events-none');
            modalContent.classList.remove('scale-95');
            modalContent.classList.add('scale-100');
            updateEndpointPreview();
            const ghInput = document.getElementById('githubTokenInput');
            const ghStatus = document.getElementById('githubTokenStatus');
            const ghHas = !!(window.Android && typeof window.Android.hasGithubToken === 'function' && window.Android.hasGithubToken());
            if (ghInput) { ghInput.value=''; ghInput.placeholder = ghHas ? '••••••••••••••••  (đã lưu)' : 'github_pat_...'; }
            if (ghStatus) ghStatus.innerHTML = ghHas ? '<i class="fa-solid fa-shield-halved text-emerald-400"></i> GitHub Token đã lưu an toàn' : '<i class="fa-solid fa-shield-halved"></i> Lưu bằng Android Keystore';
            setApiConnectionStatus(null, serverUrl ? 'Đang ưu tiên VILA Server Proxy' : (activeApiKey ? 'Đã có Gemini API Key trên thiết bị' : 'Chưa cấu hình Gemini API Key'));
        }

        window.closeSettingsModal = function() {
            const modal = document.getElementById('settingsModal');
            const modalContent = document.getElementById('modalContent');
            if(!modal || !modalContent) return;
            modal.classList.add('opacity-0', 'pointer-events-none');
            modalContent.classList.remove('scale-100');
            modalContent.classList.add('scale-95');
        }

        window.toggleKeyVisibility = function() {
            const input = document.getElementById('apiKeyInput');
            const icon = document.getElementById('eyeIcon');
            if(!input || !icon) return;
            if (input.type === 'password') {
                input.type = 'text'; icon.className = 'fa-solid fa-eye-slash';
            } else {
                input.type = 'password'; icon.className = 'fa-solid fa-eye';
            }
        }

        window.toggleGroqKeyVisibility=function(){const input=document.getElementById('groqApiKeyInput'),icon=document.getElementById('groqEyeIcon');if(!input)return;if(input.type==='password'){input.type='text';if(icon)icon.className='fa-solid fa-eye-slash';}else{input.type='password';if(icon)icon.className='fa-solid fa-eye';}};

        window.testApiKey = async function() {
            const inputKey = document.getElementById('apiKeyInput');
            const inputBaseUrl = document.getElementById('apiBaseUrlInput');
            if(!inputKey || !inputBaseUrl) return;

            const testKey = inputKey.value.trim();
            const testBaseUrl = inputBaseUrl.value.trim() || PROVIDERS.gemini.baseUrl;

            if (activeProvider==='sambanova') return testSambaApiKey();
            if (!testKey) return showToast(activeProvider==='groq'?'Chưa nhập Groq API Key!':'Chưa nhập Gemini API Key!', 'error');
            showToast(`Đang kiểm tra ${activeProvider==='groq'?'Groq':'Gemini'} Key...`, 'info');

            try {
                const testModel = activeProvider==='groq'?'openai/gpt-oss-120b':(currentModel || 'gemini-3.8-flash');
                const testUrl = activeProvider==='groq'?'https://api.groq.com/openai/v1/chat/completions':`${testBaseUrl}/chat/completions`;
                const body={model:testModel,messages:[{role:'user',content:'Trả lời OK.'}],max_tokens:8};
                if(activeProvider==='groq'){body.reasoning_effort='low';body.include_reasoning=false;}
                const res = await fetch(testUrl,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${testKey}`},body:JSON.stringify(body)});

                const data = await res.json();
                if (res.ok) {
                    setApiConnectionStatus(true, `${activeProvider==='groq'?'Groq':'Gemini'} OK • ${testModel}`); showToast(`${activeProvider==='groq'?'Groq':'Gemini'} API Key hợp lệ.`, 'success');
                } else {
                    showToast(`Lỗi: ${data?.error?.message || `HTTP ${res.status}`}`, 'error');
                }
            } catch (e) {
                setApiConnectionStatus(false, `Không kết nối được ${activeProvider==='groq'?'Groq':'Gemini'}`); showToast(`Lỗi mạng/CORS: ${e.message || 'Không thể kết nối API'}`, 'error');
            }
        }

        window.toggleSambaKeyVisibility=function(){const input=document.getElementById('sambaApiKeyInput'),icon=document.getElementById('sambaEyeIcon');if(!input)return;if(input.type==='password'){input.type='text';if(icon)icon.className='fa-solid fa-eye-slash';}else{input.type='password';if(icon)icon.className='fa-solid fa-eye';}};

        window.testSambaApiKey = async function(){
            const key=document.getElementById('sambaApiKeyInput')?.value.trim()||'';
            const base=(document.getElementById('sambaApiBaseUrlInput')?.value.trim()||PROVIDERS.sambanova.baseUrl).replace(/\/$/,'');
            const model=localStorage.getItem('vila_sambanova_model')||PROVIDERS.sambanova.models[0].id;
            if(!key) return showToast('Chưa nhập SambaNova API Key!', 'error');
            showToast('Đang kiểm tra SambaNova Key...', 'info');
            try{
                const res=await fetch(`${base}/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:'user',content:'Trả lời OK.'}],max_tokens:8})});
                const raw=await res.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){}
                if(res.ok){setApiConnectionStatus(true,`SambaNova OK • ${model}`);showToast('SambaNova API Key hợp lệ.','success');}
                else showToast(`SambaNova lỗi: ${data?.error?.message||`HTTP ${res.status}`}`,'error');
            }catch(e){setApiConnectionStatus(false,'Không kết nối được SambaNova');showToast(`Lỗi mạng/CORS: ${e.message||'Không thể kết nối SambaNova'}`,'error');}
        };

        window.toggleGithubTokenVisibility = function(){
            const input=document.getElementById('githubTokenInput'), icon=document.getElementById('githubEyeIcon');
            if(!input) return;
            if(input.type==='password'){input.type='text';if(icon)icon.className='fa-solid fa-eye-slash';}
            else{input.type='password';if(icon)icon.className='fa-solid fa-eye';}
        };

        window.testGithubTokenConnection = function(){
            const input=document.getElementById('githubTokenInput');
            const value=input?.value.trim()||'';
            if(value && window.Android && typeof window.Android.saveGithubToken==='function') window.Android.saveGithubToken(value);
            if(!window.Android || typeof window.Android.testGithubToken!=='function') return showToast('GitHub bridge chưa sẵn sàng.', 'error');
            showToast('Đang kiểm tra GitHub Token...', 'info');
            window.Android.testGithubToken();
        };

        window.clearGithubToken = function(){
            if(window.Android && typeof window.Android.clearGithubToken==='function') window.Android.clearGithubToken();
            const input=document.getElementById('githubTokenInput'); if(input){input.value='';input.placeholder='github_pat_...';}
            const status=document.getElementById('githubTokenStatus'); if(status) status.innerHTML='<i class="fa-solid fa-shield-halved"></i> Chưa lưu GitHub Token';
            showToast('Đã xóa GitHub Token khỏi thiết bị.', 'success');
        };

        window.onGithubTokenTest = function(code, message){
            const ok = Number(code)>=200 && Number(code)<300;
            const status=document.getElementById('githubTokenStatus');
            if(ok){
                if(status) status.innerHTML='<i class="fa-solid fa-circle-check text-emerald-400"></i> '+escapeHtml(message);
                showToast(message || 'GitHub Token hợp lệ.', 'success');
            } else {
                if(status) status.innerHTML='<i class="fa-solid fa-triangle-exclamation text-amber-400"></i> '+escapeHtml(message || ('HTTP '+code));
                showToast('GitHub: '+(message || ('HTTP '+code)), 'error');
            }
        };

        window.saveSettings = function() {
            const geminiKey=document.getElementById('apiKeyInput')?.value.trim()||'';
            const groqKey=document.getElementById('groqApiKeyInput')?.value.trim()||'';
            const sambaKey=document.getElementById('sambaApiKeyInput')?.value.trim()||'';
            const sambaBase=(document.getElementById('sambaApiBaseUrlInput')?.value.trim()||PROVIDERS.sambanova.baseUrl).replace(/\/$/,'');
            const baseUrlVal=(document.getElementById('apiBaseUrlInput')?.value.trim()||PROVIDERS.gemini.baseUrl).replace(/\/$/,'');
            const serverVal=(document.getElementById('serverUrlInput')?.value.trim()||'').replace(/\/$/,'');
            const githubToken=document.getElementById('githubTokenInput')?.value.trim()||'';
            if(githubToken && window.Android && typeof window.Android.saveGithubToken==='function') window.Android.saveGithubToken(githubToken);
            activeProvider=PROVIDERS[activeProvider]?activeProvider:'gemini';
            activeApiKey=activeProvider==='groq'?groqKey:geminiKey;
            activeBaseUrl=activeProvider==='sambanova'?sambaBase:baseUrlVal; serverUrl=serverVal;
            localStorage.setItem('vila_provider',activeProvider);
            if(geminiKey)localStorage.setItem('vila_api_key',geminiKey);else localStorage.removeItem('vila_api_key');
            if(groqKey)localStorage.setItem('vila_groq_api_key',groqKey);else localStorage.removeItem('vila_groq_api_key');
            if(sambaKey)localStorage.setItem('vila_sambanova_api_key',sambaKey);else localStorage.removeItem('vila_sambanova_api_key');
            localStorage.setItem('vila_sambanova_base_url',sambaBase);
            localStorage.setItem('vila_base_url',baseUrlVal);
            if(serverUrl)localStorage.setItem('vila_server_url',serverUrl);else localStorage.removeItem('vila_server_url');
            localStorage.setItem('vila_reasoning_level',reasoningLevel);
            try{if(window.Android&&typeof window.Android.setServerUrl==='function')window.Android.setServerUrl(serverUrl);}catch(_){}
            populateModelOptions();updateUIState();updateEndpointPreview();closeSettingsModal();
            const githubConfigured=!!(window.Android&&typeof window.Android.hasGithubToken==='function'&&window.Android.hasGithubToken());
            showToast(`Đã lưu ${activeProvider==='groq'?'Groq GPT-OSS 120B':activeProvider==='sambanova'?'SambaNova':'Gemini'}${serverUrl&&activeProvider==='gemini'?' + Server Proxy':''}${githubConfigured?' + GitHub':''}.`,'success');
        }



        /* Toast System */
        function showToast(message, type = 'info') {
            const container = document.getElementById('toastContainer');
            if(!container) return;
            const toast = document.createElement('div');
            
            let bgStyle = 'glass-card border-purple-500/30 text-purple-200';
            let icon = 'fa-circle-info text-neon-violet';

            if (type === 'success') {
                bgStyle = 'glass-card border-emerald-500/40 text-emerald-200';
                icon = 'fa-circle-check text-emerald-400';
            } else if (type === 'error') {
                bgStyle = 'glass-card border-rose-500/40 text-rose-200';
                icon = 'fa-triangle-exclamation text-rose-400';
            }

            toast.className = `flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold shadow-2xl backdrop-blur-xl border transition-all duration-300 transform translate-y-4 opacity-0 ${bgStyle}`;
            toast.innerHTML = `<i class="fa-solid ${icon} text-sm"></i><span>${escapeHtml(message)}</span>`;

            container.appendChild(toast);
            setTimeout(() => toast.classList.remove('translate-y-4', 'opacity-0'), 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-4');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }
    
        ['apiBaseUrlInput','serverUrlInput'].forEach(id => {
          document.getElementById(id)?.addEventListener('input', updateEndpointPreview);
        });

        /* Voice + image generation tools */
        let vilaVoiceActive = false;
        let vilaLastGeneratedImage = null;

        function setVoiceState(text, active=false){
          const el=document.getElementById('voiceState'); if(el) el.textContent=text;
          const btn=document.getElementById('voiceBtn'); if(btn) btn.classList.toggle('active',!!active);
        }

        window.onVilaVoiceResult=function(state,text){
          const input=document.getElementById('userPrompt');
          if(state==='ready'){ vilaVoiceActive=true; setVoiceState('Chuẩn bị',true); return; }
          if(state==='listening'){ vilaVoiceActive=true; setVoiceState('Đang nghe',true); return; }
          if(state==='processing'){ setVoiceState('Đang xử lý',true); return; }
          if((state==='partial'||state==='result')&&input){
            input.value=String(text||''); input.dispatchEvent(new Event('input',{bubbles:true}));
          }
          if(state==='result'||state==='error'){ vilaVoiceActive=false; setVoiceState(state==='error'?'Lỗi mic':'Sẵn sàng',false); }
        };

        window.toggleVilaVoice=function(){
          if(vilaVoiceActive){
            try{ if(window.Android&&typeof window.Android.stopVoiceInput==='function') window.Android.stopVoiceInput(); }catch(_){ }
            vilaVoiceActive=false; setVoiceState('Sẵn sàng',false); return;
          }
          try{
            if(window.Android&&typeof window.Android.startVoiceInput==='function'){
              setVoiceState('Đang mở mic',true); window.Android.startVoiceInput(); return;
            }
          }catch(_){ }
          const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
          if(!SR) return showToast('Thiết bị chưa hỗ trợ nhập giọng nói.','error');
          const r=new SR(); r.lang='vi-VN'; r.interimResults=true; r.continuous=false;
          vilaVoiceActive=true; setVoiceState('Đang nghe',true);
          r.onresult=e=>{ const text=Array.from(e.results).map(x=>x[0]?.transcript||'').join(''); const input=document.getElementById('userPrompt'); if(input){input.value=text;input.dispatchEvent(new Event('input',{bubbles:true}));} };
          r.onerror=()=>{vilaVoiceActive=false;setVoiceState('Lỗi mic',false);};
          r.onend=()=>{vilaVoiceActive=false;setVoiceState('Sẵn sàng',false);};
          try{r.start();}catch(_){vilaVoiceActive=false;setVoiceState('Sẵn sàng',false);}
        };

        const vilaSpeechStore=window.vilaSpeechStore=window.vilaSpeechStore||{};
        window.speakVilaStored=function(id){ const text=vilaSpeechStore[id]||''; window.speakVilaText(text); };
        let vilaAudio=null;
        function base64ToBytes(b64){ const bin=atob(String(b64||'')); const out=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i); return out; }
        function pcmToWav(bytes,sampleRate=24000,channels=1,bits=16){
          const header=new ArrayBuffer(44); const v=new DataView(header); const blockAlign=channels*bits/8; const byteRate=sampleRate*blockAlign;
          const put=(o,t)=>{for(let i=0;i<t.length;i++)v.setUint8(o+i,t.charCodeAt(i));};
          put(0,'RIFF');v.setUint32(4,36+bytes.length,true);put(8,'WAVE');put(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,channels,true);v.setUint32(24,sampleRate,true);v.setUint32(28,byteRate,true);v.setUint16(32,blockAlign,true);v.setUint16(34,bits,true);put(36,'data');v.setUint32(40,bytes.length,true);
          return new Uint8Array([...new Uint8Array(header),...bytes]);
        }
        async function speakVilaWithGemini(text){
          const key=localStorage.getItem('vila_api_key')||''; if(!key)return false;
          const body={model:'gemini-3.1-flash-tts-preview',input:`[friendly] ${text}`,response_format:{type:'audio'},generation_config:{speech_config:[{voice:'Kore'}]}};
          const r=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify(body)});
          const raw=await r.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){ }
          if(!r.ok)throw new Error(data?.error?.message||`TTS API lỗi HTTP ${r.status}`);
          const b64=data?.output_audio?.data||''; if(!b64)throw new Error('TTS không trả về audio.');
          const bytes=base64ToBytes(b64); let wav=bytes;
          if(!(bytes[0]===82&&bytes[1]===73&&bytes[2]===70&&bytes[3]===70)) wav=pcmToWav(bytes);
          if(vilaAudio){try{vilaAudio.pause();}catch(_){}}
          vilaAudio=new Audio(URL.createObjectURL(new Blob([wav],{type:'audio/wav'}))); vilaAudio.onended=()=>{try{URL.revokeObjectURL(vilaAudio.src);}catch(_){}}; await vilaAudio.play(); return true;
        }
        window.speakVilaText=async function(rawText){
          const text=String(rawText||'').replace(/```[\s\S]*?```/g,'Đoạn mã đã được tạo.').replace(/[#*_`>\[\]]/g,' ').replace(/\s+/g,' ').trim();
          if(!text)return;
          setAiStatus('Đang đọc','busy');
          if(activeProvider==='gemini'){
            try{ if(await speakVilaWithGemini(text)){setAiStatus('Đã sẵn sàng','');return;} }catch(e){console.warn('Gemini TTS:',e); }
          }
          try{ if(window.Android&&typeof window.Android.speakText==='function'){window.Android.speakText(text);setAiStatus('Đã sẵn sàng','');return;} }catch(_){ }
          if('speechSynthesis' in window){ try{window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='vi-VN';u.rate=.94;u.pitch=1.02;window.speechSynthesis.speak(u);}catch(_){} }
          setAiStatus('Đã sẵn sàng','');
        };

        window.stopVilaSpeech=function(){
          try{if(vilaAudio){vilaAudio.pause();vilaAudio.currentTime=0;}}catch(_){ }
          try{if(window.Android&&typeof window.Android.stopSpeaking==='function')window.Android.stopSpeaking();}catch(_){ }
          try{if('speechSynthesis' in window)window.speechSynthesis.cancel();}catch(_){ }
          setAiStatus('Đã sẵn sàng','');
        };

        function extractInteractionImage(data){
          if(data?.output_image?.data) return {data:String(data.output_image.data),mime:String(data.output_image.mime_type||'image/png')};
          const seen=new Set();
          function walk(v){
            if(!v||typeof v!=='object'||seen.has(v))return null; seen.add(v);
            if(v.data && typeof v.data==='string' && /^(image\/)?(png|jpeg|jpg|webp)$/i.test(String(v.mime_type||'').replace('image/',''))){return {data:v.data,mime:String(v.mime_type||'image/png')};}
            if(v.data && typeof v.data==='string' && v.data.length>1000 && /^[A-Za-z0-9+/=\r\n]+$/.test(v.data)){return {data:v.data,mime:String(v.mime_type||'image/png')};}
            for(const k of Object.keys(v)){const hit=walk(v[k]);if(hit)return hit;}
            return null;
          }
          return walk(data);
        }

        async function generateImageWithGemini(prompt){
          const key=localStorage.getItem('vila_api_key')||'';
          if(!key) throw new Error('Cần Gemini API Key để tạo ảnh.');
          const input=String(prompt||'').trim();
          if(!input) throw new Error('Hãy nhập mô tả ảnh trước.');
          const body={model:'gemini-3.1-flash-image',input:[{type:'text',text:input}],response_format:{type:'image',mime_type:'image/png',aspect_ratio:'1:1',image_size:'1K'}};
          if(document.getElementById('webSearchToggle')?.checked) body.tools=[{type:'google_search'}];
          const r=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify(body)});
          const raw=await r.text(); let data={}; try{data=raw?JSON.parse(raw):{};}catch(_){ }
          if(!r.ok) throw new Error(data?.error?.message||`Image API lỗi HTTP ${r.status}`);
          const image=extractInteractionImage(data);
          if(!image) throw new Error('API không trả về dữ liệu ảnh.');
          return image;
        }

        function appendGeneratedImage(image,prompt){
          const chatBox=document.getElementById('chatMessages'); if(!chatBox)return;
          const id='vila_img_'+Date.now();
          vilaLastGeneratedImage=image;
          const mime=image.mime||'image/png';
          const src=`data:${mime};base64,${image.data}`;
          const div=document.createElement('div'); div.className='flex gap-4 items-start group';
          div.innerHTML=`<div class="w-9 h-9 rounded-xl bg-[#202024] border border-[#34343a] shrink-0 flex items-center justify-center text-xs font-bold text-white">V</div><div class="flex-1 space-y-2 overflow-hidden"><div class="flex items-center gap-2"><span class="font-bold text-sm text-white">VILA Pro</span><span class="text-[10px] text-gray-500">${getCurrentTime()}</span></div><div class="vila-image-result"><img id="${id}" src="${src}" alt="Ảnh VILA tạo"><div class="vila-image-actions"><button type="button" onclick="saveLastGeneratedImage()"><i class="fa-solid fa-download"></i> Lưu ảnh</button><button type="button" onclick="speakVilaText('Mình đã tạo ảnh theo yêu cầu của bạn.')"><i class="fa-solid fa-volume-high"></i> Đọc</button></div></div><div class="text-[11px] text-gray-500">${escapeHtml(prompt)}</div></div>`;
          chatBox.appendChild(div); scrollToBottom();
        }

        window.saveLastGeneratedImage=function(){
          if(!vilaLastGeneratedImage)return showToast('Chưa có ảnh để lưu.','info');
          const ext=(vilaLastGeneratedImage.mime||'image/png').split('/')[1]||'png';
          if(window.Android&&typeof window.Android.saveBase64File==='function'){try{window.Android.saveBase64File(`VILA_${Date.now()}.${ext}`,vilaLastGeneratedImage.data,vilaLastGeneratedImage.mime);return;}catch(_){}}
          const a=document.createElement('a');a.href=`data:${vilaLastGeneratedImage.mime};base64,${vilaLastGeneratedImage.data}`;a.download=`VILA_${Date.now()}.${ext}`;document.body.appendChild(a);a.click();a.remove();
        };

        window.generateImageFromPrompt=async function(){
          const input=document.getElementById('userPrompt'); const prompt=String(input?.value||'').trim();
          if(!prompt)return showToast('Nhập mô tả ảnh vào ô chat trước.','info');
          setAiStatus('Đang tạo ảnh','busy');
          try{ const image=await generateImageWithGemini(prompt); appendUserMessage(prompt,true); appendGeneratedImage(image,prompt); if(input){input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));} setAiStatus('Đã tạo ảnh',''); showToast('Tạo ảnh thành công.','success'); }
          catch(e){showToast(e?.message||'Không thể tạo ảnh.','error');setAiStatus('Lỗi tạo ảnh','');}
        };

        document.getElementById('voiceBtn')?.addEventListener('click',()=>window.toggleVilaVoice());
        document.getElementById('generateImageBtn')?.addEventListener('click',()=>window.generateImageFromPrompt());

        // VILA Account: Firebase cloud auth when configured, local profile fallback otherwise.
        let vilaAuth = null;
        function firebaseReady(){ return !!(window.firebase && window.VILA_FIREBASE_CONFIG && window.VILA_FIREBASE_CONFIG.apiKey); }
        function initVilaAuth(){
          try{
            if(firebaseReady()){
              if(!firebase.apps.length) firebase.initializeApp(window.VILA_FIREBASE_CONFIG);
              vilaAuth=firebase.auth();
              vilaAuth.onAuthStateChanged(u=>updateAccountUI(u));
              vilaAuth.getRedirectResult().catch(e=>{ if(e?.code && e.code!=='auth/popup-closed-by-user') console.warn('Firebase redirect:',e); });
            } else updateAccountUI(null);
          }catch(e){ console.warn('Firebase auth unavailable',e); updateAccountUI(null); }
        }
        function updateAccountUI(user){
          const el=document.getElementById('accountStatus'); if(!el) return;
          const local=JSON.parse(localStorage.getItem('vila_local_account')||'null');
          if(user) el.innerHTML=`Đã đăng nhập: <b>${escapeHtml(user.email||user.displayName||'Google')}</b>`;
          else if(local) el.innerHTML=`Tài khoản thiết bị: <b>${escapeHtml(local.email||local.name||'VILA User')}</b>`;
          else el.textContent='Chưa đăng nhập';
        }
        window.openAccountModal=()=>{ const m=document.getElementById('accountModal'); if(m){m.classList.remove('opacity-0','pointer-events-none'); updateAccountUI(vilaAuth?.currentUser||null);} };
        window.closeAccountModal=()=>{ const m=document.getElementById('accountModal'); if(m){m.classList.add('opacity-0','pointer-events-none');} };
        window.emailRegister=async()=>{
          const email=document.getElementById('accountEmail')?.value.trim(); const pw=document.getElementById('accountPassword')?.value;
          if(!email||!pw) return showToast('Nhập email và mật khẩu.','error');
          if(vilaAuth){ try{await vilaAuth.createUserWithEmailAndPassword(email,pw); showToast('Tạo tài khoản thành công.','success'); return;}catch(e){return showToast(e.message||'Không tạo được tài khoản.','error');} }
          localStorage.setItem('vila_local_account',JSON.stringify({email,createdAt:Date.now()})); updateAccountUI(null); showToast('Đã tạo hồ sơ trên thiết bị.','success');
        };
        window.emailLogin=async()=>{
          const email=document.getElementById('accountEmail')?.value.trim(); const pw=document.getElementById('accountPassword')?.value;
          if(!email||!pw) return showToast('Nhập email và mật khẩu.','error');
          if(vilaAuth){ try{await vilaAuth.signInWithEmailAndPassword(email,pw); showToast('Đăng nhập thành công.','success'); return;}catch(e){return showToast(e.message||'Đăng nhập thất bại.','error');} }
          const local=JSON.parse(localStorage.getItem('vila_local_account')||'null');
          if(local?.email===email){ updateAccountUI(null); showToast('Đã đăng nhập hồ sơ thiết bị.','success'); } else showToast('Chưa có hồ sơ này trên thiết bị.','error');
        };
        window.googleLogin=async()=>{
          if(!vilaAuth) return showToast('Google Login cần cấu hình Firebase cho ứng dụng.','info');
          try{ const provider=new firebase.auth.GoogleAuthProvider(); provider.setCustomParameters({prompt:'select_account'}); await vilaAuth.signInWithRedirect(provider); }catch(e){ showToast(e.message||'Google Login thất bại.','error'); }
        };
        window.resetAccountPassword=async()=>{
          const email=document.getElementById('accountEmail')?.value.trim();
          if(!email) return showToast('Nhập email trước để nhận liên kết đặt lại mật khẩu.','info');
          if(!vilaAuth) return showToast('Đặt lại mật khẩu cloud cần cấu hình Firebase.','info');
          try{await vilaAuth.sendPasswordResetEmail(email);showToast('Đã gửi email đặt lại mật khẩu.','success');}catch(e){showToast(e.message||'Không gửi được email đặt lại mật khẩu.','error');}
        };
        window.logoutAccount=async()=>{
          try{ if(vilaAuth) await vilaAuth.signOut(); }catch(e){}
          localStorage.removeItem('vila_local_account'); updateAccountUI(null); showToast('Đã đăng xuất.','info');
        };
        initVilaAuth();

        // Long-term project memory: IndexedDB backup in addition to localStorage.
        const VILA_DB='vila_long_memory_v1';
        function vilaDB(){ return new Promise((resolve,reject)=>{ const r=indexedDB.open(VILA_DB,1); r.onupgradeneeded=()=>{ if(!r.result.objectStoreNames.contains('memory')) r.result.createObjectStore('memory'); }; r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error); }); }
        async function saveLongTermMemory(){ try{ const db=await vilaDB(); const tx=db.transaction('memory','readwrite'); tx.objectStore('memory').put({messages:conversationHistory.filter(m=>m.role!=='system').slice(-2000).map(memorySafeMessage),projectMemory,latestGeneratedCode,savedAt:Date.now()},'main'); }catch(e){ console.warn('IndexedDB memory error',e); } }
        async function restoreLongTermMemory(){ try{ const db=await vilaDB(); const tx=db.transaction('memory','readonly'); const req=tx.objectStore('memory').get('main'); req.onsuccess=()=>{ const d=req.result; if(!d) return; if(!localStorage.getItem(MEMORY_KEY)&&Array.isArray(d.messages)&&d.messages.length){ conversationHistory=d.messages; refreshSystemPrompt(); renderConversationMessages(d.messages); } if(!projectMemory&&d.projectMemory){projectMemory=d.projectMemory; localStorage.setItem(PROJECT_MEMORY_KEY,projectMemory); refreshSystemPrompt();} if(!latestGeneratedCode&&d.latestGeneratedCode) latestGeneratedCode=d.latestGeneratedCode; }; }catch(e){} }
        const _saveConversationMemory=saveConversationMemory;
        saveConversationMemory=function(){ _saveConversationMemory(); saveLongTermMemory(); };
        restoreLongTermMemory();
