'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pinnedFetch } = require('../src/tools/web');
const { ProviderCircuitBreaker } = require('../src/reliability');
const store = require('../src/tools/store');
const { createAgentLoop } = require('../src/agent-loop');
const serverSrc = fs.readFileSync(path.join(__dirname, '../src/server.js'), 'utf8');

test('pinnedFetch connects through a real hostname on Node >= 20 (lookup {all:true} contract)', async () => {
  const srv = http.createServer((q, r) => r.end('pong')).listen(0, '127.0.0.1');
  await new Promise(r => srv.once('listening', r));
  try {
    const res = await pinnedFetch(`http://localhost:${srv.address().port}/`, {}, { allowPrivate: true });
    assert.equal(res.status, 200);
    assert.equal(await res.text(), 'pong');
  } finally { srv.close(); }
});

test('circuit breaker: release() frees a half-open probe slot without recording a result', () => {
  let t = 1000; const cb = new ProviderCircuitBreaker({ failureThreshold: 1, cooldownMs: 1000, now: () => t });
  cb.failure('p', { retryable: true, status: 500 });
  t += 2000;
  assert.equal(cb.acquire('p').probe, true);
  assert.equal(cb.acquire('p').allowed, false, 'second caller is blocked while the probe is out');
  cb.release('p');
  assert.equal(cb.acquire('p').allowed, true, 'provider is usable again after release');
});

test('memory/doc search is accent-insensitive and memoryList returns every item', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vila-t-')); const env = { VILA_DATA_DIR: dir };
  try {
    for (let i = 0; i < 15; i++) store.memorySave('u1', { text: i === 0 ? 'Tôi thích tìm kiếm đường đi ở Đà Nẵng' : `ghi chú số ${i}` }, env);
    assert.equal(store.memorySearch('u1', { query: 'tim kiem Da Nang' }, env).results[0].text.includes('Đà Nẵng'), true);
    assert.equal(store.memoryList('u1', env).results.length, 15);
    store.docAdd('u1', { name: 'a.txt', text: 'Hướng dẫn cài đặt phần mềm' }, env);
    assert.equal(store.docSearch('u1', { query: 'cai dat phan mem' }, env).results.length, 1);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('agent loop: malformed tool args consume budget and raw tool_calls never escape', async () => {
  const bad = { choices: [{ message: { content: null, tool_calls: [{ id: '1', function: { name: 'vila_calculate', arguments: '{not json' } }] } }] };
  let upstreamCalls = 0;
  const loop = createAgentLoop({
    upstreamFor: async () => { upstreamCalls++; return { ok: true, text: async () => JSON.stringify(bad) }; },
    releaseResponse() {}, toOpenAIShape: x => x, runAgentTool: async () => ({ json: '{}', trace: {} }), maxCalls: () => 2
  });
  const r = await loop({ type: 'openai' }, 'm', bad, { messages: [{ role: 'user', content: 'hi' }] }, { uid: 'u' });
  assert.ok(upstreamCalls <= 3, `bounded round trips (got ${upstreamCalls})`);
  assert.equal(r.data.choices[0].message.tool_calls, undefined);
});

test('server source: CORS allows DELETE, Gemini key is not placed in the URL, agent mode never streams', () => {
  assert.match(serverSrc, /methods: \['GET', 'POST', 'DELETE', 'OPTIONS'\]/);
  assert.doesNotMatch(serverSrc, /[?&]key=\$\{encodeURIComponent\(provider\.key\)\}/);
  assert.doesNotMatch(serverSrc, /searchParams\.set\('key'/);
  assert.match(serverSrc, /x-goog-api-key/);
  assert.match(serverSrc, /body\.stream === true && body\.agentMode !== true/);
});
