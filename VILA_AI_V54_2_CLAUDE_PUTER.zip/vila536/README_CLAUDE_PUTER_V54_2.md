# Enable Claude in VILA through Puter.js

1. Build and install VILA as usual.
2. Open **Cài đặt → Nhà cung cấp** and choose **Claude via Puter.js**.
3. Choose one of the Claude model entries.
4. Send a short test message. If Puter asks you to sign in or approve access, complete that flow and retry.
5. No Anthropic API key or Base URL is entered in VILA for this provider.

If the SDK fails to load, check Internet access, WebView support for external scripts/pop-ups, and whether a network filter blocks `js.puter.com`. If a selected model is unavailable to the Puter account, select another listed model.
