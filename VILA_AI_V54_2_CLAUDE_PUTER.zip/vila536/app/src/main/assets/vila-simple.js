/* VILA simple UI + Agent knowledge (documents & memory). Loaded last. */
(function () {
  'use strict';
  var KEY = 'vila_ui_simple';
  var root = document.documentElement;
  function safeGet() { try { return localStorage.getItem(KEY); } catch (_) { return null; } }
  function safeSet(v) { try { localStorage.setItem(KEY, v); } catch (_) {} }
  function isSimple() { return true; }                          // simple is the only UI now
  function apply() { root.classList.toggle('vila-simple', isSimple()); var l = document.getElementById('vilaSimpleToggleText'); if (l) l.textContent = isSimple() ? 'Đơn giản' : 'Đầy đủ'; }
  apply();
  window.vilaToggleSimpleUI = function () { /* kept for old callers: the simple UI cannot be switched off */ apply(); };
  try { localStorage.removeItem(KEY); } catch (_) {}

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function gw() { return window.vilaAuthedGatewayFetch; }
  var tab = 'docs';

  function ensureDialog() {
    var d = document.getElementById('vilaKnowledge'); if (d) return d;
    d = document.createElement('div'); d.id = 'vilaKnowledge'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true'); d.setAttribute('aria-label', 'Tài liệu và bộ nhớ của Agent');
    d.innerHTML = '<div class="vk-card"><div class="vk-head"><span>Kiến thức của Agent</span><button type="button" class="vk-btn" data-vk="close" aria-label="Đóng">✕</button></div>' +
      '<div class="vk-tabs"><button type="button" class="vk-tab on" data-vk="tab-docs">Tài liệu</button><button type="button" class="vk-tab" data-vk="tab-mem">Bộ nhớ</button></div>' +
      '<div class="vk-body" id="vkBody"></div></div>' +
      '<input type="file" id="vkFile" hidden multiple accept=".txt,.md,.csv,.json,.log,.html,.xml,.pdf,.docx,text/*">';
    document.body.appendChild(d);
    d.addEventListener('click', function (e) {
      if (e.target === d) return close();
      var t = e.target.closest('[data-vk]'); if (!t) return; var a = t.getAttribute('data-vk');
      if (a === 'close') close();
      else if (a === 'tab-docs' || a === 'tab-mem') { tab = a === 'tab-docs' ? 'docs' : 'mem'; render(); }
      else if (a === 'upload') document.getElementById('vkFile').click();
      else if (a === 'del-doc') del('/v1/docs/' + encodeURIComponent(t.getAttribute('data-id')));
      else if (a === 'del-mem') del('/v1/memory/' + encodeURIComponent(t.getAttribute('data-id')));
      else if (a === 'del-all-mem') { if (confirm('Xóa toàn bộ bộ nhớ của Agent?')) del('/v1/memory/all'); }
    });
    document.getElementById('vkFile').addEventListener('change', function (e) { upload(Array.prototype.slice.call(e.target.files || [])); e.target.value = ''; });
    return d;
  }
  function body() { return document.getElementById('vkBody'); }
  function status(msg) { var b = body(); if (b) b.innerHTML = '<div class="vk-status">' + esc(msg) + '</div>'; }
  function close() { var d = document.getElementById('vilaKnowledge'); if (d) d.classList.remove('open'); }

  async function render() {
    var d = ensureDialog();
    d.querySelectorAll('.vk-tab').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-vk') === 'tab-' + tab); });
    if (!gw()) return status('Chưa kết nối AI Gateway. Hãy đăng nhập và đặt URL Gateway trong mục AI Gateway.');
    status('Đang tải…');
    try {
      if (tab === 'docs') {
        var r = await gw()('/v1/docs', { method: 'GET', timeout: 20000 });
        var docs = (r.data && r.data.docs) || [];
        body().innerHTML = '<button type="button" class="vk-btn vk-primary" data-vk="upload">+ Tải tài liệu lên</button>' +
          '<div class="vk-status">Agent sẽ tìm trong các tài liệu này khi bạn bật chế độ Agent. Hỗ trợ txt, md, csv, json, pdf, docx.</div>' +
          (docs.length ? docs.map(function (x) { return '<div class="vk-row"><span>' + esc(x.name) + '<small>' + x.chunks + ' đoạn</small></span><button type="button" class="vk-btn" data-vk="del-doc" data-id="' + esc(x.id) + '" aria-label="Xóa ' + esc(x.name) + '">Xóa</button></div>'; }).join('') : '<div class="vk-empty">Chưa có tài liệu nào.</div>');
      } else {
        var m = await gw()('/v1/memory', { method: 'GET', timeout: 20000 });
        var items = (m.data && m.data.results) || [];
        body().innerHTML = '<div class="vk-status">Những điều Agent đã ghi nhớ về bạn. Bạn có thể xóa bất cứ lúc nào.</div>' +
          (items.length ? items.map(function (x) { return '<div class="vk-row"><span>' + esc(x.text) + '</span><button type="button" class="vk-btn" data-vk="del-mem" data-id="' + esc(x.id) + '" aria-label="Xóa mục nhớ">Xóa</button></div>'; }).join('') + '<button type="button" class="vk-btn" data-vk="del-all-mem">Xóa tất cả</button>' : '<div class="vk-empty">Chưa có gì được ghi nhớ.</div>');
      }
    } catch (e) { status('Không tải được: ' + (e && e.message ? e.message : e)); }
  }
  async function del(path) { try { await gw()(path, { method: 'DELETE', timeout: 20000 }); } catch (e) { status('Không xóa được: ' + (e && e.message ? e.message : e)); return; } render(); }

  async function extract(file) {
    var n = file.name.toLowerCase();
    if (n.endsWith('.pdf') && typeof readPdfFile === 'function') return readPdfFile(file);
    if (n.endsWith('.docx') && typeof readDocxFile === 'function') return readDocxFile(file);
    return file.text();
  }
  async function upload(files) {
    if (!files.length) return;
    var ok = 0, errs = [];
    for (var i = 0; i < files.length; i++) {
      status('Đang xử lý ' + files[i].name + ' (' + (i + 1) + '/' + files.length + ')…');
      try {
        var text = String(await extract(files[i]) || '').trim();
        if (!text) throw new Error('không có chữ để đọc');
        await gw()('/v1/docs', { method: 'POST', body: JSON.stringify({ name: files[i].name, text: text.slice(0, 390000) }), timeout: 60000 });
        ok++;
      } catch (e) { errs.push(files[i].name + ': ' + (e && e.message ? e.message : e)); }
    }
    await render();
    if (errs.length) { var b = body(); if (b) b.insertAdjacentHTML('afterbegin', '<div class="vk-status">Lỗi: ' + esc(errs.join(' · ')) + '</div>'); }
  }

  window.openVilaKnowledge = function () { var d = ensureDialog(); d.classList.add('open'); render(); };
  window.closeVilaKnowledge = close;

  function addMenuItems() {
    var nav = document.querySelector('#mainMenu .ds-side-nav'); if (!nav || nav.querySelector('[data-vila-knowledge]')) return;
    var k = document.createElement('button'); k.type = 'button'; k.className = 'vila-menu-btn'; k.setAttribute('data-vila-knowledge', '1');
    k.innerHTML = '<i class="fa-solid fa-book" aria-hidden="true"></i><span>Tài liệu &amp; bộ nhớ Agent</span>';
    k.addEventListener('click', function () { window.openVilaKnowledge(); if (typeof closeMainMenu === 'function') closeMainMenu(); });
    nav.appendChild(k);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', addMenuItems); else addMenuItems();
})();
