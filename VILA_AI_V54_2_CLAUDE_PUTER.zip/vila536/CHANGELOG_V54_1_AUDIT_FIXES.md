# VILA AI V54.1 — Audit fixes

## Bugs fixed
1. **`vila_web_fetch` could not reach any real hostname** (Node ≥ 20): `pinnedFetch` answered the `lookup` callback with the 3-argument form while Node's autoSelectFamily asks for `{all:true}` → `ERR_INVALID_IP_ADDRESS`. Both conventions are now supported. Old tests injected a fake fetch, so they never saw it.
2. **Circuit breaker could lock a provider out until restart**: a half-open probe that got `429 + Retry-After ≤ 2s` kept its probe slot forever. Added `ProviderCircuitBreaker.release()` and call it before the retry.
3. **Client disconnect counted as provider failure**: closing the app before the first token tripped the provider breaker. Disconnects now release the probe and are not recorded as failures.
4. **CORS preflight rejected `DELETE`** (`/v1/docs/:id`, `/v1/memory/:id`) for browser clients.
5. **Agent mode + `stream:true`** produced an empty stream and a false provider failure → Agent mode is always non-streaming. Agent requests are also no longer planned/billed as multi-team requests (3–5 rate-limit units).
6. **Agent loop**: malformed tool arguments did not consume the tool budget; unresolved `tool_calls` could leak to the client. Both fixed.
7. **Docker**: non-root `node` user could not create `.vila-data` → memory/documents failed in production. Added `VILA_DATA_DIR=/data` volume; compose image tag corrected.
8. Fatal errors (`uncaughtException`) exited with code 0, so `restart: on-failure` would not restart → exit code 1.

## Hardening / upgrades
- Gemini API key moved from URL query string to `x-goog-api-key` header.
- Android WebView: `setAllowFileAccess(false)`, `setAllowContentAccess(false)`.
- Memory/document search is accent-insensitive (`tim kiem` finds `tìm kiếm`, `da nang` finds `Đà Nẵng`).
- `GET /v1/memory` without `q` returns all items (UI previously showed only 10 of up to 200).
- New tests: `server/test/audit-v54-1.test.js` (69 server tests total; all 17 scripts pass).

## Not changed (needs your decision)
- `usesCleartextTraffic="true"` is needed for the local 127.0.0.1 page and LAN/local LLM endpoints; restrict via a network-security-config if you do not use LAN models.
- `vila_run_code` is defence-in-depth only; keep `VILA_ENABLE_CODE_EXEC` off unless the container is isolated. The slim Docker image has no `python3`.
- Version strings were left at 54.0.x because several regression scripts pin them.

## UI: simple is now the only interface
- Removed the "Chế độ giao diện" switch; `html.vila-simple` is always on (no more neon/full UI).
- Flat single-palette styling for login, start screen, side menu, chat, thinking indicator, code blocks and all dialogs; animated welcome splash removed.
- Messages: your text in a soft grey pill, VILA's answer as plain text (no avatar / name / clock); one quiet "thinking" line.
- Fixed code blocks: the template's raw newlines were turned into `<br>` and spread the header apart.
- Composer/keyboard area: removed the dark gradient band and frame; page, dock and Android window/bars all use the same #212121.
