# VILA AI V54.2 — Claude via Puter.js

- Added a `Claude via Puter.js` provider to the existing provider picker.
- Added Claude model choices (Sonnet 4.5, Opus 4.1, Haiku 4.5) as selectable defaults; the account/provider must actually expose the selected model.
- Uses the Puter.js browser SDK (`https://js.puter.com/v2/`) and `puter.ai.chat()`. No Anthropic API key is embedded or required by this integration.
- Existing VILA providers, gateway, local AI, and chat flows remain available.

## Important

- Puter.js may open a Puter sign-in/permission flow. This patch intentionally does not bypass authentication, quotas, or access controls.
- Access to specific Claude models, availability, limits, and any costs/credits are determined by Puter and can change. Model IDs in the selector are best-effort choices, not a guarantee that every account can access every model.
- This is a client-side SDK integration, so prompts are sent to Puter. Review Puter's current privacy and terms before sending sensitive information.
- The app needs Internet access to load Puter.js. Web search is disabled for this provider; other VILA providers retain their existing web-search paths.
- Image attachments are currently converted to descriptive placeholders by this adapter rather than uploaded as native image inputs. VILA's existing file/workspace text context remains available.
