import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const androidRoot = path.resolve(process.argv[2] || 'android');
const appRoot = path.join(androidRoot, 'app');
const sourceBinary = path.join(root, 'app', 'src', 'main', 'jniLibs', 'arm64-v8a', 'libstockfish.so');
const sourceLicense = path.join(root, 'app', 'src', 'main', 'assets', 'STOCKFISH-COPYING.txt');
const templatePath = path.join(root, 'scripts', 'templates', 'NativeStockfishBridge.java.template');

function fail(message) {
  console.error(`[Cờ Vua ViLa] Native Stockfish setup failed: ${message}`);
  process.exit(1);
}

if (!fs.existsSync(path.join(appRoot, 'src', 'main', 'AndroidManifest.xml'))) {
  fail(`Android app manifest not found in ${appRoot}. Run npx cap sync android first.`);
}
if (!fs.existsSync(sourceBinary) || !fs.statSync(sourceBinary).isFile()) fail('Native Stockfish ARM64 binary is missing; run scripts/fetch-native-stockfish-android.sh.');
const binaryStat = fs.statSync(sourceBinary);
if (binaryStat.size < 10_000_000) fail(`Native Stockfish binary has unexpected size (${binaryStat.size} bytes).`);
const header = Buffer.alloc(20);
const fd = fs.openSync(sourceBinary, 'r');
try { fs.readSync(fd, header, 0, header.length, 0); } finally { fs.closeSync(fd); }
if (header[0] !== 0x7f || header[1] !== 0x45 || header[2] !== 0x4c || header[3] !== 0x46 || header.readUInt16LE(18) !== 183) {
  fail('Downloaded engine is not a little-endian ELF AArch64 executable.');
}
if (!fs.existsSync(sourceLicense) || fs.statSync(sourceLicense).size < 1000) fail('Stockfish GPL license file is missing.');
if (!fs.existsSync(templatePath)) fail('NativeStockfishBridge Java template is missing.');

function findFiles(directory, accept, result = []) {
  if (!fs.existsSync(directory)) return result;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const current = path.join(directory, entry.name);
    if (entry.isDirectory()) findFiles(current, accept, result);
    else if (entry.isFile() && accept(current)) result.push(current);
  }
  return result;
}

const activityCandidates = findFiles(path.join(appRoot, 'src', 'main', 'java'), file => /^MainActivity\.(java|kt)$/.test(path.basename(file)));
if (activityCandidates.length !== 1) fail(`Expected exactly one generated MainActivity.java/kt, found ${activityCandidates.length}.`);
const activityPath = activityCandidates[0];
const activitySource = fs.readFileSync(activityPath, 'utf8');
const packageMatch = activitySource.match(/^\s*package\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*;?/m);
if (!packageMatch) fail(`Cannot determine MainActivity package from ${path.relative(root, activityPath)}.`);
const packageName = packageMatch[1];
// MainActivity lives in the package directory in the generated Capacitor scaffold.
const bridgePath = path.join(path.dirname(activityPath), 'NativeStockfishBridge.java');
const bridgeSource = fs.readFileSync(templatePath, 'utf8').replace('__PACKAGE__', packageName);
fs.writeFileSync(bridgePath, bridgeSource);

const nativeLibDir = path.join(appRoot, 'src', 'main', 'jniLibs', 'arm64-v8a');
fs.mkdirSync(nativeLibDir, { recursive: true });
fs.copyFileSync(sourceBinary, path.join(nativeLibDir, 'libstockfish.so'));
fs.chmodSync(path.join(nativeLibDir, 'libstockfish.so'), 0o755);
const assetsDir = path.join(appRoot, 'src', 'main', 'assets');
fs.mkdirSync(assetsDir, { recursive: true });
fs.copyFileSync(sourceLicense, path.join(assetsDir, 'STOCKFISH-COPYING.txt'));

function patchJavaActivity(source) {
  if (source.includes('new NativeStockfishBridge(')) return source;
  let output = source;
  if (!/import\s+android\.os\.Bundle\s*;/.test(output)) {
    output = output.replace(/^(\s*package\s+[^;]+;)/m, '$1\n\nimport android.os.Bundle;');
  }
  const classMatch = output.match(/class\s+MainActivity\s+extends\s+BridgeActivity\s*\{/m);
  if (!classMatch) fail('Generated Java MainActivity is not a standard Capacitor BridgeActivity; refusing to patch it blindly.');
  const registration = `\n    // VILA_NATIVE_STOCKFISH_BRIDGE: expose the native UCI process to the existing engine worker.\n    private void registerVilaNativeStockfishBridge() {\n        if (bridge == null || bridge.getWebView() == null) return;\n        bridge.getWebView().addJavascriptInterface(new NativeStockfishBridge(this, bridge.getWebView()), "AndroidBridge");\n    }\n`;
  if (/void\s+onCreate\s*\(/m.test(output)) {
    if (!/super\.onCreate\(savedInstanceState\)\s*;/.test(output)) fail('MainActivity already has onCreate(), but its super.onCreate(savedInstanceState) call was not found.');
    output = output.replace(/super\.onCreate\(savedInstanceState\)\s*;/, match => `${match}\n        registerVilaNativeStockfishBridge();`);
    return output.replace(/}\s*$/, `${registration}}\n`);
  }
  const openBrace = classMatch.index + classMatch[0].length;
  const closeBrace = output.lastIndexOf('}');
  if (closeBrace < openBrace) fail('Could not locate the end of MainActivity class.');
  const method = `\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n        super.onCreate(savedInstanceState);\n        registerVilaNativeStockfishBridge();\n    }\n`;
  return output.slice(0, openBrace) + method + registration + output.slice(closeBrace);
}

function patchKotlinActivity(source) {
  if (source.includes('NativeStockfishBridge(')) return source;
  let output = source;
  if (!/import\s+android\.os\.Bundle\b/.test(output)) output = output.replace(/^(\s*package\s+[^\n]+)/m, '$1\n\nimport android.os.Bundle');
  const classMatch = output.match(/class\s+MainActivity\s*:\s*BridgeActivity\s*\{/m);
  if (!classMatch) fail('Generated Kotlin MainActivity is not a standard Capacitor BridgeActivity; refusing to patch it blindly.');
  const registration = `\n    // VILA_NATIVE_STOCKFISH_BRIDGE\n    private fun registerVilaNativeStockfishBridge() {\n        val stockfishWebView = bridge?.webView\n        if (stockfishWebView != null) stockfishWebView.addJavascriptInterface(NativeStockfishBridge(this, stockfishWebView), "AndroidBridge")\n    }\n`;
  if (/override\s+fun\s+onCreate\s*\(/m.test(output)) {
    if (!/super\.onCreate\(savedInstanceState\)/.test(output)) fail('MainActivity already has onCreate(), but its super.onCreate(savedInstanceState) call was not found.');
    output = output.replace(/super\.onCreate\(savedInstanceState\)/, match => `${match}\n        registerVilaNativeStockfishBridge()`);
    return output.replace(/}\s*$/, `${registration}}\n`);
  }
  const openBrace = classMatch.index + classMatch[0].length;
  const closeBrace = output.lastIndexOf('}');
  const method = `\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        registerVilaNativeStockfishBridge()\n    }\n`;
  return output.slice(0, openBrace) + method + registration + output.slice(closeBrace);
}

const patchedActivity = activityPath.endsWith('.kt') ? patchKotlinActivity(activitySource) : patchJavaActivity(activitySource);
fs.writeFileSync(activityPath, patchedActivity);

const gradleCandidates = ['build.gradle', 'build.gradle.kts'].map(name => path.join(appRoot, name)).filter(file => fs.existsSync(file));
if (gradleCandidates.length !== 1) fail(`Expected one app/build.gradle or app/build.gradle.kts, found ${gradleCandidates.length}.`);
const gradlePath = gradleCandidates[0];
let gradleSource = fs.readFileSync(gradlePath, 'utf8');
if (!gradleSource.includes('libstockfish.so') || !gradleSource.includes('useLegacyPackaging')) {
  const groovy = gradlePath.endsWith('.gradle');
  const packagingInner = groovy
    ? `    // VILA_NATIVE_STOCKFISH_PACKAGING: allow the ARM64 executable to be launched from nativeLibraryDir.\n    packagingOptions {\n        jniLibs {\n            useLegacyPackaging true\n            keepDebugSymbols += ['**/libstockfish.so']\n        }\n    }\n`
    : `    // VILA_NATIVE_STOCKFISH_PACKAGING: allow the ARM64 executable to be launched from nativeLibraryDir.\n    packaging {\n        jniLibs {\n            useLegacyPackaging = true\n            keepDebugSymbols += setOf("**/libstockfish.so")\n        }\n    }\n`;
  // Prefer injecting inside the existing android { } block to avoid duplicate top-level android blocks.
  const androidMatch = gradleSource.match(/\bandroid\s*\{/);
  if (androidMatch) {
    const insertAt = androidMatch.index + androidMatch[0].length;
    gradleSource = gradleSource.slice(0, insertAt) + '\n' + packagingInner + gradleSource.slice(insertAt);
  } else {
    const packagingBlock = groovy
      ? `\n\nandroid {\n${packagingInner}}\n`
      : `\n\nandroid {\n${packagingInner}}\n`;
    gradleSource += packagingBlock;
  }
  fs.writeFileSync(gradlePath, gradleSource);
}

const manifestPath = path.join(appRoot, 'src', 'main', 'AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');
if (!/android\.permission\.VIBRATE/.test(manifest)) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, '$1\n    <uses-permission android:name="android.permission.VIBRATE" />');
  fs.writeFileSync(manifestPath, manifest);
}

if (!fs.readFileSync(activityPath, 'utf8').includes('NativeStockfishBridge')) fail('MainActivity did not register NativeStockfishBridge.');
console.log(`[Cờ Vua ViLa] Installed native Stockfish UCI bridge into ${path.relative(root, androidRoot)}.`);
console.log(`[Cờ Vua ViLa] ARM64 engine: ${binaryStat.size.toLocaleString()} bytes; native bridge: ${path.relative(root, bridgePath)}.`);
