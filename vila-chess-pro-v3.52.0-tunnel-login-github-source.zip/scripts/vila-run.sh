#!/data/data/com.termux/files/usr/bin/bash
# Chạy máy chủ VILA + Cloudflare Tunnel lâu dài trong Termux.
#   bash scripts/vila-run.sh                 chạy (nên chạy trong tmux)
#   bash scripts/vila-run.sh --install-boot  tạo ~/.termux/boot/vila.sh (cần app Termux:Boot)
#   bash scripts/vila-run.sh --status        kiểm tra server và in link tunnel hiện tại
#
# Tunnel cố định: export CF_TUNNEL_NAME=ten-tunnel (Named Tunnel đã tạo bằng cloudflared).
# Không đặt CF_TUNNEL_NAME thì dùng Quick Tunnel — link trycloudflare.com ĐỔI mỗi lần cloudflared khởi động lại.
set -u
cd "$(dirname "$0")/.." || exit 1
ROOT="$(pwd)"
PORT="${PORT:-8787}"
mkdir -p data logs

tunnel_url() { grep -ao 'https://[a-z0-9-]*\.trycloudflare\.com' logs/tunnel.log 2>/dev/null | tail -n 1; }

case "${1:-}" in
  --install-boot)
    mkdir -p "$HOME/.termux/boot"
    {
      echo '#!/data/data/com.termux/files/usr/bin/bash'
      echo 'termux-wake-lock'
      printf 'cd %q && exec bash scripts/vila-run.sh\n' "$ROOT"
    } > "$HOME/.termux/boot/vila.sh"
    chmod +x "$HOME/.termux/boot/vila.sh"
    echo "Đã tạo $HOME/.termux/boot/vila.sh. Cài app Termux:Boot (F-Droid) và mở nó một lần để kích hoạt."
    exit 0
    ;;
  --status)
    if curl -fsS -m 5 "http://127.0.0.1:${PORT}/api/social/health"; then echo; else echo "Server KHÔNG phản hồi trên cổng ${PORT}."; fi
    echo "Tunnel: $(tunnel_url || true)"
    exit 0
    ;;
esac

if [ ! -f .env ]; then
  echo 'Thiếu tệp .env. Chạy: cp .env.example .env rồi đặt SOCIAL_TOKEN_SECRET, TUBOR_ACCESS_TOKEN (>= 32 byte).'
  exit 1
fi
command -v node >/dev/null 2>&1 || { echo 'Chưa có Node.js. Chạy: pkg install nodejs-lts'; exit 1; }
command -v cloudflared >/dev/null 2>&1 || { echo 'Chưa có cloudflared. Chạy: pkg install cloudflared'; exit 1; }
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock

# Chạy một lệnh mãi mãi; thoát thì tự chạy lại. Nếu lệnh chết quá nhanh (< 30 giây) thì giãn thời gian chờ
# 3 → 6 → 12 … tối đa 60 giây để không quay vòng liên tục khi cấu hình sai.
supervise() {
  local name=$1 log=$2; shift 2
  local delay=3 started code
  while true; do
    if [ -f "$log" ] && [ "$(stat -c %s "$log" 2>/dev/null || echo 0)" -gt 5242880 ]; then : > "$log"; fi
    started=$SECONDS
    echo "[$(date '+%F %T')] $name: bắt đầu" >> "$log"
    "$@" >> "$log" 2>&1
    code=$?
    echo "[$(date '+%F %T')] $name: thoát (mã $code)" >> "$log"
    if [ $((SECONDS - started)) -ge 30 ]; then delay=3; else delay=$((delay * 2 > 60 ? 60 : delay * 2)); fi
    sleep "$delay"
  done
}

if [ -n "${CF_TUNNEL_NAME:-}" ]; then
  tunnel_cmd=(cloudflared tunnel run "$CF_TUNNEL_NAME")
else
  tunnel_cmd=(cloudflared tunnel --url "http://127.0.0.1:${PORT}")
fi

supervise server logs/server.log bash scripts/start-termux.sh &
SERVER_SUPERVISOR=$!
supervise tunnel logs/tunnel.log "${tunnel_cmd[@]}" &
TUNNEL_SUPERVISOR=$!
# Dừng sạch: gom cả vòng giám sát lẫn mọi tiến trình con cháu (node, cloudflared) rồi tắt cùng lúc.
descendants() { local c; for c in $(pgrep -P "$1" 2>/dev/null); do echo "$c"; descendants "$c"; done; }
stop_all() {
  local pids
  pids="$SERVER_SUPERVISOR $TUNNEL_SUPERVISOR $(descendants "$SERVER_SUPERVISOR") $(descendants "$TUNNEL_SUPERVISOR")"
  # shellcheck disable=SC2086
  kill $pids 2>/dev/null
  exit 0
}
trap stop_all INT TERM HUP

echo "VILA đang chạy nền (cổng ${PORT}). Log: logs/server.log, logs/tunnel.log"
echo "Kiểm tra: bash scripts/vila-run.sh --status"
if [ -z "${CF_TUNNEL_NAME:-}" ]; then echo "Quick Tunnel: link mới sẽ xuất hiện trong logs/tunnel.log sau vài giây."; fi
wait
