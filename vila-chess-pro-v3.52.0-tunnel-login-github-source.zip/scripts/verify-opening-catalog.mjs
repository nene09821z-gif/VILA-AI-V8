/** Release guard: refuse to package an app without a complete, validated opening catalog. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const requiredCount = 3000;

async function readCatalog(file) {
  let payload;
  try {
    payload = JSON.parse(await fs.readFile(file, 'utf8'));
  } catch (error) {
    throw new Error(`${path.relative(root, file)} cannot be read as JSON: ${error.message}`);
  }
  const openings = Array.isArray(payload) ? payload : payload?.openings;
  if (!Array.isArray(openings)) throw new Error(`${path.relative(root, file)} has no openings array.`);
  const valid = openings.filter(item => item && typeof item === 'object'
    && /^[A-E]\d{2}$/.test(String(item.eco || ''))
    && typeof item.name === 'string' && item.name.trim().length > 0
    && Array.isArray(item.san) && item.san.length > 0 && item.san.length <= 60
    && item.san.every(move => typeof move === 'string' && move.trim().length > 0));
  const uniqueLines = new Set(valid.map(item => item.san.join(' ')));
  if (valid.length < requiredCount) {
    throw new Error(`${path.relative(root, file)} contains ${valid.length} valid lines; ${requiredCount} are required.`);
  }
  if (uniqueLines.size < requiredCount) {
    throw new Error(`${path.relative(root, file)} contains only ${uniqueLines.size} unique move lines; ${requiredCount} are required.`);
  }
  return { total: openings.length, valid: valid.length, unique: uniqueLines.size };
}

try {
  const publicFile = path.join(root, 'public', 'openings-eco.json');
  const distFile = path.join(root, 'dist', 'openings-eco.json');
  const source = await readCatalog(publicFile);
  const output = await readCatalog(distFile);
  console.log(`[opening-catalog-check] Source: ${source.valid} valid entries, ${source.unique} unique legal move lines.`);
  console.log(`[opening-catalog-check] Built app: ${output.valid} valid entries, ${output.unique} unique legal move lines.`);
  console.log('[opening-catalog-check] PASS: release contains at least 3,000 opening lines.');
} catch (error) {
  console.error(`[opening-catalog-check] FAIL: ${error.message}`);
  process.exitCode = 1;
}
