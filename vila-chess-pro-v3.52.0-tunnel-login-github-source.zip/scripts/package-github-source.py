#!/usr/bin/env python3
"""Create a GitHub-web-upload-friendly ZIP without duplicating public assets in Android.

`public/` is the canonical source for static WebView assets. The Gradle preBuild task copies
those assets back into app/src/main/assets when building the native Android module.
"""
from __future__ import annotations

import hashlib
import os
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else ROOT.parent / "vila-chess-pro-source.zip"
PUBLIC = ROOT / "public"
ANDROID_ASSETS = ROOT / "app" / "src" / "main" / "assets"

EXCLUDED_DIRS = {".git", "node_modules", "dist", "build", ".gradle", ".idea", "__pycache__", ".pytest_cache"}
EXCLUDED_NAMES = {".env", ".DS_Store", "debug.keystore", "local.properties"}
EXCLUDED_SUFFIXES = {".apk", ".aab", ".pyc"}
MAX_SOURCE_ZIP_BYTES = 25_000_000


def is_android_asset(path: Path) -> bool:
    try:
        return path.is_relative_to(ANDROID_ASSETS)
    except AttributeError:  # Python 3.8 fallback
        return str(path).startswith(str(ANDROID_ASSETS) + os.sep)


def should_skip(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True
    if path.name in EXCLUDED_NAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if path.resolve() == OUTPUT:
        return True
    # This CI-generated executable is intentionally fetched during build and must never
    # bloat the upload-friendly source ZIP to ~100 MiB.
    if rel.as_posix() == "app/src/main/jniLibs/arm64-v8a/libstockfish.so":
        return True
    # If an Android WebView asset is byte-identical to its public counterpart, store it once.
    # app/build.gradle.kts restores the same relative path before Android build tasks run.
    if is_android_asset(path):
        rel_asset = path.relative_to(ANDROID_ASSETS)
        public_copy = PUBLIC / rel_asset
        if public_copy.is_file() and path.stat().st_size == public_copy.stat().st_size:
            if hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256(public_copy.read_bytes()).digest():
                return True
    return False


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        OUTPUT.unlink()
    included = 0
    omitted_duplicate_assets = 0
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file():
                continue
            if should_skip(path):
                if is_android_asset(path):
                    rel_asset = path.relative_to(ANDROID_ASSETS)
                    public_copy = PUBLIC / rel_asset
                    if public_copy.is_file() and path.stat().st_size == public_copy.stat().st_size:
                        if hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256(public_copy.read_bytes()).digest():
                            omitted_duplicate_assets += 1
                continue
            archive.write(path, path.relative_to(ROOT).as_posix())
            included += 1

    required = {
        "package.json",
        "package-lock.json",
        "src/main.js",
        "public/engine/stockfish-10.js",
        "public/engine/stockfish-19-lite-single.wasm",
        "app/build.gradle.kts",
        "scripts/package-github-source.py",
        "scripts/install-native-stockfish-android.mjs",
        "scripts/templates/NativeStockfishBridge.java.template",
        "scripts/fetch-native-stockfish-android.sh",
    }
    with zipfile.ZipFile(OUTPUT, "r") as archive:
        names = set(archive.namelist())
        missing = sorted(required - names)
        if missing:
            raise SystemExit("ZIP verification failed, missing: " + ", ".join(missing))
        if not any(name.startswith("public/assets/aistudio/") and name.lower().endswith(".zip") for name in names):
            raise SystemExit("ZIP verification failed: canonical AI Studio backup ZIP is missing.")
        for duplicated in ["app/src/main/assets/engine/stockfish-10.js"]:
            if duplicated in names:
                raise SystemExit(f"ZIP verification failed: duplicate asset still included: {duplicated}")
        if any(name.startswith("app/src/main/assets/assets/aistudio/") and name.lower().endswith(".zip") for name in names):
            raise SystemExit("ZIP verification failed: duplicated AI Studio ZIP is still included in Android assets.")
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP CRC check failed: {bad}")

    output_size = OUTPUT.stat().st_size
    if output_size > MAX_SOURCE_ZIP_BYTES:
        OUTPUT.unlink(missing_ok=True)
        raise SystemExit(
            f"Source ZIP is {output_size / (1024 * 1024):.2f} MiB; "
            f"upload limit is 25 MB. Large native Stockfish is expected to download at build time."
        )

    digest = hashlib.sha256(OUTPUT.read_bytes()).hexdigest()
    checksum_path = Path(str(OUTPUT) + ".sha256")
    checksum_path.write_text(f"{digest}  {OUTPUT.name}\n", encoding="ascii")
    print(f"ZIP: {OUTPUT}")
    print(f"Size: {OUTPUT.stat().st_size:,} bytes")
    print(f"Files included: {included}; duplicate Android assets omitted: {omitted_duplicate_assets}")
    print(f"SHA-256: {digest}")
    print(f"Checksum: {checksum_path}")


if __name__ == "__main__":
    main()
