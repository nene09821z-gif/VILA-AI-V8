import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('android');
const alternatives = [
  ['settings.gradle', 'settings.gradle.kts'],
  ['app/build.gradle', 'app/build.gradle.kts'],
  ['app/src/main/AndroidManifest.xml'],
  ['gradlew'],
  ['gradle/wrapper/gradle-wrapper.jar'],
  ['gradle/wrapper/gradle-wrapper.properties'],
];
const missing = alternatives.filter(group => !group.some(file => fs.existsSync(path.join(root, file))));
if (missing.length) {
  console.error('[Cờ Vua ViLa] Android Gradle project incomplete:');
  for (const group of missing) console.error(` - ${group.join(' or ')}`);
  console.error('Run `npx cap add android` after installing the project dependencies.');
  process.exit(1);
}
const androidManifest = fs.readFileSync(path.join(root, 'app', 'src', 'main', 'AndroidManifest.xml'), 'utf8');
if (!androidManifest.includes('android.permission.CAMERA')) {
  console.error('[Cờ Vua ViLa] AndroidManifest.xml is missing CAMERA permission for optional hand tracking.');
  console.error('Run `node scripts/ensure-camera-permission.mjs android` before verifying the project.');
  process.exit(1);
}
const wrapperJar = path.join(root, 'gradle', 'wrapper', 'gradle-wrapper.jar');
const jarBytes = fs.readFileSync(wrapperJar);
if (jarBytes.length < 1024 || jarBytes[0] !== 0x50 || jarBytes[1] !== 0x4b) {
  console.error('[Cờ Vua ViLa] gradle-wrapper.jar is missing or does not look like a valid JAR.');
  process.exit(1);
}
const wrapperScript = fs.readFileSync(path.join(root, 'gradlew'), 'utf8');
if (!wrapperScript.includes('GradleWrapperMain')) {
  console.error('[Cờ Vua ViLa] android/gradlew is not the official-style Gradle wrapper launcher.');
  process.exit(1);
}
const wrapperProps = fs.readFileSync(path.join(root, 'gradle', 'wrapper', 'gradle-wrapper.properties'), 'utf8');
if (!/^distributionUrl=https/i.test(wrapperProps.split(/\r?\n/).find(line => line.startsWith('distributionUrl=')) || '')) {
  console.error('[Cờ Vua ViLa] gradle-wrapper.properties has no distributionUrl.');
  process.exit(1);
}
if (process.platform !== 'win32') {
  const mode = fs.statSync(path.join(root, 'gradlew')).mode;
  if (!(mode & 0o111)) {
    console.error('[Cờ Vua ViLa] android/gradlew is not executable. Restoring execute permission.');
    fs.chmodSync(path.join(root, 'gradlew'), mode | 0o111);
  }
}
// The workflows must install Stockfish into the actual Capacitor Android module,
// not only into the standalone/reference app at repository root.
const nativeBinary = path.join(root, 'app', 'src', 'main', 'jniLibs', 'arm64-v8a', 'libstockfish.so');
const nativeLicense = path.join(root, 'app', 'src', 'main', 'assets', 'STOCKFISH-COPYING.txt');
const nativeBridge = path.join(root, 'app', 'src', 'main', 'java');
const appGradlePath = ['app/build.gradle', 'app/build.gradle.kts'].map(file => path.join(root, file)).find(file => fs.existsSync(file));
if (!appGradlePath || !fs.readFileSync(appGradlePath, 'utf8').includes('useLegacyPackaging')) {
  console.error('[Cờ Vua ViLa] Android Gradle packaging is not configured to extract the native executable.');
  process.exit(1);
}
if (!fs.existsSync(nativeBinary) || !fs.statSync(nativeBinary).isFile() || fs.statSync(nativeBinary).size < 10_000_000) {
  console.error('[Cờ Vua ViLa] Generated Capacitor app is missing the native Stockfish ARM64 executable.');
  console.error('Run `node scripts/install-native-stockfish-android.mjs android` after `npx cap sync android`.');
  process.exit(1);
}
if (!fs.existsSync(nativeLicense) || fs.statSync(nativeLicense).size < 1000) {
  console.error('[Cờ Vua ViLa] Generated Android app is missing the Stockfish GPL license.');
  process.exit(1);
}
function containsNativeBridge(directory) {
  if (!fs.existsSync(directory)) return false;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const current = path.join(directory, entry.name);
    if (entry.isDirectory() && containsNativeBridge(current)) return true;
    if (entry.isFile() && /^MainActivity\.(java|kt)$/.test(entry.name)) {
      const activity = fs.readFileSync(current, 'utf8');
      if (activity.includes('NativeStockfishBridge') && activity.includes('AndroidBridge')) return true;
    }
  }
  return false;
}
if (!containsNativeBridge(nativeBridge)) {
  console.error('[Cờ Vua ViLa] MainActivity is not wired to NativeStockfishBridge in the generated Capacitor project.');
  process.exit(1);
}
const bridgeFiles = [];
function collectBridgeFiles(directory) {
  if (!fs.existsSync(directory)) return;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const current = path.join(directory, entry.name);
    if (entry.isDirectory()) collectBridgeFiles(current);
    else if (entry.isFile() && entry.name === 'NativeStockfishBridge.java') bridgeFiles.push(current);
  }
}
collectBridgeFiles(nativeBridge);
if (bridgeFiles.length !== 1 || !fs.readFileSync(bridgeFiles[0], 'utf8').includes('startNativeStockfish')) {
  console.error('[Cờ Vua ViLa] NativeStockfishBridge.java is missing or incomplete in the generated Android project.');
  process.exit(1);
}
console.log('[Cờ Vua ViLa] Android Gradle files and native Stockfish integration verified.');
