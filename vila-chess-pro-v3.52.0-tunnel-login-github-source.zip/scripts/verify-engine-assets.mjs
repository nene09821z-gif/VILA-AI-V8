import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const engineDir = path.join(root, 'public', 'engine');
const args = new Set(process.argv.slice(2));
const release = args.has('--release');
const skipSmoke = args.has('--skip-smoke');
const includeFull = process.env.INCLUDE_STOCKFISH_FULL === '1';

function requireFile(name, minBytes = 1) {
  const file = path.join(engineDir, name);
  if (!fs.existsSync(file)) throw new Error(`Missing engine asset: public/engine/${name}`);
  const stat = fs.statSync(file);
  if (!stat.isFile() || stat.size < minBytes) throw new Error(`Engine asset is too small or not a file: ${name} (${stat.size} bytes)`);
  return file;
}
function waitForLine(proc, queue, predicate, timeoutMs, stderrRef) {
  const found = queue.findIndex(predicate);
  if (found >= 0) return Promise.resolve(queue.splice(found, 1)[0]);
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      cleanup();
      reject(new Error(`Timed out waiting for Stockfish output after ${timeoutMs} ms. Recent output: ${queue.slice(-10).join(' | ')}. stderr: ${stderrRef.value.slice(-500)}`));
    }, timeoutMs);
    const waiter = { predicate, resolve: line => { cleanup(); resolve(line); } };
    const onExit = (code, signal) => {
      cleanup();
      reject(new Error(`Stockfish exited before responding (code=${code}, signal=${signal}). stderr: ${stderrRef.value.slice(-800)}`));
    };
    function cleanup() {
      clearTimeout(timer);
      const i = proc.__vilaWaiters.indexOf(waiter);
      if (i >= 0) proc.__vilaWaiters.splice(i, 1);
      proc.off('exit', onExit);
    }
    proc.__vilaWaiters.push(waiter);
    proc.once('exit', onExit);
  });
}

async function smokeTestLite(engineFile, wasmFile) {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'vila-stockfish-smoke-'));
  const basename = path.basename(engineFile, '.js');
  const runnable = path.join(temp, `${basename}.cjs`);
  fs.copyFileSync(engineFile, runnable);
  fs.copyFileSync(wasmFile, path.join(temp, `${basename}.wasm`));

  const proc = spawn(process.execPath, [runnable], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  const queue = [];
  const stderrRef = { value: '' };
  let stdoutBuffer = '';
  proc.__vilaWaiters = [];
  proc.stdout.setEncoding('utf8');
  proc.stderr.setEncoding('utf8');
  proc.stdout.on('data', chunk => {
    stdoutBuffer += chunk;
    let newline;
    while ((newline = stdoutBuffer.indexOf('\n')) >= 0) {
      const line = stdoutBuffer.slice(0, newline).trim();
      stdoutBuffer = stdoutBuffer.slice(newline + 1);
      if (!line) continue;
      const waiterIndex = proc.__vilaWaiters.findIndex(waiter => waiter.predicate(line));
      if (waiterIndex >= 0) proc.__vilaWaiters.splice(waiterIndex, 1)[0].resolve(line);
      else queue.push(line);
    }
  });
  proc.stderr.on('data', chunk => { stderrRef.value = (stderrRef.value + chunk).slice(-4000); });
  const send = command => {
    if (proc.stdin.destroyed || proc.exitCode !== null) throw new Error(`Cannot send UCI command to Stockfish: ${command}`);
    proc.stdin.write(`${command}\n`);
  };
  try {
    send('uci');
    const uciLine = await waitForLine(proc, queue, line => line === 'uciok', 15000, stderrRef);
    send('isready');
    await waitForLine(proc, queue, line => line === 'readyok', 15000, stderrRef);
    send('position startpos');
    send('go depth 4');
    const bestMoveLine = await waitForLine(proc, queue, line => line.startsWith('bestmove '), 20000, stderrRef);
    const match = bestMoveLine.match(/^bestmove\s+([a-h][1-8][a-h][1-8][qrbn]?)(?:\s|$)/i);
    if (!match) throw new Error(`Stockfish returned an invalid bestmove line: ${bestMoveLine}`);
    const allowedStartMoves = new Set([
      'a2a3','a2a4','b2b3','b2b4','c2c3','c2c4','d2d3','d2d4','e2e3','e2e4','f2f3','f2f4','g2g3','g2g4','h2h3','h2h4',
      'b1a3','b1c3','g1f3','g1h3'
    ]);
    if (!allowedStartMoves.has(match[1].toLowerCase())) throw new Error(`Stockfish returned an illegal start-position move: ${match[1]}`);
    try { send('quit'); } catch {}
    await Promise.race([
      new Promise(resolve => proc.once('exit', resolve)),
      new Promise(resolve => setTimeout(() => { try { proc.kill('SIGTERM'); } catch {} resolve(); }, 2500))
    ]);
    const engineName = queue.find(line => /^id name\s+/i.test(line))?.replace(/^id name\s*/i, '') || 'Stockfish Lite';
    return { engine: engineName, bestmove: match[1].toLowerCase() };
  } catch (error) {
    try { proc.kill('SIGKILL'); } catch {}
    throw error;
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
}

async function main() {
  const manifestPath = requireFile('engine-manifest.json', 50);
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (!manifest.lite || !manifest.asmFallback || !manifest.assets?.liteJs || !manifest.assets?.liteWasm || !manifest.assets?.asmJs) {
    throw new Error('engine-manifest.json does not declare the required Lite + WASM + ASM-JS fallback chain.');
  }
  const liteJs = requireFile(manifest.assets.liteJs, 10000);
  const liteWasm = requireFile(manifest.assets.liteWasm, 100000);
  const asmJs = requireFile(manifest.assets.asmJs, 100000);
  const wasmHeader = fs.readFileSync(liteWasm).subarray(0, 4);
  if (wasmHeader.toString('hex') !== '0061736d') throw new Error('Stockfish Lite WASM has an invalid WebAssembly header.');
  if (release) {
    requireFile(manifest.assets.sf10Js || 'stockfish-10.js', 100000);
    requireFile('STOCKFISH-10-LICENSE.txt', 100);
    if (!manifest.sf10 || manifest.sf10Version !== '10.0.2') throw new Error('Stockfish 10 is not declared correctly in the engine manifest.');
  }
  if (includeFull) {
    const fullJs = requireFile('stockfish-19-single.js', 10000);
    const fullWasm = requireFile('stockfish-19-single.wasm', 1000000);
    if (!manifest.full || manifest.assets.fullJs !== path.basename(fullJs) || manifest.assets.fullWasm !== path.basename(fullWasm)) {
      throw new Error('Full NNUE assets exist but engine-manifest.json does not declare them consistently.');
    }
    if (fs.readFileSync(fullWasm).subarray(0, 4).toString('hex') !== '0061736d') throw new Error('Full NNUE WASM has an invalid WebAssembly header.');
  }
  // Worker builds are UMD and run as classic browser workers. Test their actual UCI engine
  // in Node via a temporary .cjs copy so package.json's type=module does not alter the engine.
  if (!skipSmoke) {
    const result = await smokeTestLite(liteJs, liteWasm);
    console.log(`[VILA engine QA] Stockfish 19 Lite runtime OK; ${result.engine}; depth-4 bestmove ${result.bestmove}.`);
  }
  console.log(`[VILA engine QA] Lite JS/WASM and ASM-JS assets valid (${fs.statSync(liteJs).size} B JS, ${fs.statSync(liteWasm).size} B WASM, ${fs.statSync(asmJs).size} B ASM).`);
  if (includeFull) console.log('[VILA engine QA] Full NNUE JS/WASM files and manifest validated.');
  if (release) console.log('[VILA engine QA] Release requirement for Stockfish 10 and its GPL notice passed.');
}

main().catch(error => {
  console.error(`[VILA engine QA] FAILED: ${error.message}`);
  process.exitCode = 1;
});
