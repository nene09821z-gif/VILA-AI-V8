/** Build-time importer for the public-domain Lichess ECO opening catalog. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Chess } from 'chess.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputPath = path.join(root, 'public', 'openings-eco.json');
const categories = ['a', 'b', 'c', 'd', 'e'];
const requiredCount = 3000;
const requireFullCatalog = process.env.REQUIRE_OPENING_CATALOG === '1';
const sourceRoot = 'https://raw.githubusercontent.com/lichess-org/chess-openings/master';

function familyFor(name, firstMove) {
  const value = String(name || '').toLowerCase();
  if (/defen[cs]e|countergambit|counterattack|counter attack/.test(value)) return 'Phòng thủ';
  if (/gambit|attack|trap/.test(value)) return 'Tấn công';
  if (String(firstMove || '').startsWith('e')) return 'Mở e4';
  if (String(firstMove || '').startsWith('d')) return 'Mở d4';
  return 'Mở c4';
}

function formatLine(san) {
  const result = [];
  for (let i = 0; i < san.length; i += 2) {
    const moveNumber = Math.floor(i / 2) + 1;
    result.push(`${moveNumber}. ${san[i]}${san[i + 1] ? ` ${san[i + 1]}` : ''}`);
  }
  return result.join(' ');
}

function parseLine(eco, name, pgn) {
  const chess = new Chess();
  const san = [];
  const tokens = String(pgn || '')
    .replace(/\{[^}]*\}|\([^)]*\)/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
  try {
    for (let token of tokens) {
      token = token.replace(/^\d+\.(?:\.\.)?/, '');
      if (!token || /^\d+\.{1,3}$/.test(token) || /^(?:1-0|0-1|1\/2-1\/2|\*)$/.test(token) || /^(?:e\.p\.|ep)$/i.test(token)) continue;
      token = token.replace(/[!?]+$/g, '');
      const move = chess.move(token);
      if (!move) return null;
      san.push(move.san);
    }
  } catch {
    return null;
  }
  if (!san.length || san.length > 60) return null;
  return {
    name: String(name || '').trim(),
    family: familyFor(name, san[0]),
    eco: String(eco || '').trim(),
    line: formatLine(san),
    san,
    note: `Biến ${String(eco || 'ECO')} trong bộ dữ liệu khai cuộc mở Lichess.`,
    source: 'Lichess chess-openings · CC0-1.0'
  };
}

async function main() {
  const files = await Promise.all(categories.map(async category => {
    const url = `${sourceRoot}/${category}.tsv`;
    const response = await fetch(url, { signal: AbortSignal.timeout(25000) });
    if (!response.ok) throw new Error(`HTTP ${response.status} while retrieving ${category}.tsv`);
    return { category, text: await response.text() };
  }));

  const openings = [];
  const lineKeys = new Set();
  let rejected = 0;
  for (const file of files) {
    for (const row of file.text.split(/\r?\n/).slice(1)) {
      if (!row.trim()) continue;
      const [eco, name, pgn] = row.split('\t');
      if (!eco || !name || !pgn) { rejected += 1; continue; }
      const opening = parseLine(eco, name, pgn);
      if (!opening) { rejected += 1; continue; }
      const key = opening.san.join(' ');
      if (lineKeys.has(key)) continue;
      lineKeys.add(key);
      openings.push(opening);
    }
  }

  if (openings.length < requiredCount) throw new Error(`Only ${openings.length} valid legal lines parsed; at least ${requiredCount} are required. The existing catalog will be preserved.`);
  const payload = {
    source: 'lichess-org/chess-openings',
    license: 'CC0-1.0',
    generatedAt: new Date().toISOString(),
    count: openings.length,
    openings
  };
  await fs.mkdir(path.dirname(outputPath), { recursive: true });
  await fs.writeFile(outputPath, `${JSON.stringify(payload)}\n`, 'utf8');
  console.log(`[opening-catalog] Bundled ${openings.length} unique legal ECO lines; skipped/rejected ${rejected}.`);
}

main().catch(async error => {
  console.error(`[opening-catalog] Could not prepare a complete Lichess catalog: ${error.message}`);
  let existingCount = 0;
  try {
    const existing = JSON.parse(await fs.readFile(outputPath, 'utf8'));
    existingCount = Array.isArray(existing) ? existing.length : Array.isArray(existing?.openings) ? existing.openings.length : 0;
  } catch {
    // Do not replace or fabricate catalog data when the source cannot be reached.
  }
  if (existingCount >= requiredCount) {
    console.warn(`[opening-catalog] Preserving existing catalog with ${existingCount} entries; it was not overwritten.`);
    return;
  }
  console.error(`[opening-catalog] The current file contains ${existingCount} entries; this is below the required ${requiredCount}. Existing files are preserved.`);
  if (requireFullCatalog) {
    console.error('[opening-catalog] REQUIRE_OPENING_CATALOG=1: failing the release build instead of shipping an incomplete opening book.');
    process.exitCode = 1;
    return;
  }
  if (existingCount === 0) {
    console.warn('[opening-catalog] Dev-only build may continue with curated offline openings, but this output is not release-ready.');
  } else {
    console.warn(`[opening-catalog] Retained existing ${existingCount}-entry file without overwriting it.`);
  }
});
