import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** Ensure the generated Capacitor Android manifest declares CAMERA for optional hand tracking. */
export function ensureCameraPermission(androidRoot = 'android') {
  const resolvedRoot = path.resolve(androidRoot);
  const manifestPath = path.join(resolvedRoot, 'app', 'src', 'main', 'AndroidManifest.xml');
  if (!fs.existsSync(manifestPath)) {
    throw new Error(`AndroidManifest.xml not found: ${manifestPath}`);
  }

  let xml = fs.readFileSync(manifestPath, 'utf8');
  const permission = 'android.permission.CAMERA';
  const escapedPermission = permission.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const permissionPattern = new RegExp(`<uses-permission\\b[^>]*android:name=["']${escapedPermission}["']`);
  if (permissionPattern.test(xml)) {
    console.log('Camera permission already present.');
    return false;
  }

  const manifestOpen = xml.match(/<manifest\b[^>]*>/);
  if (!manifestOpen) {
    throw new Error('Invalid AndroidManifest.xml: missing <manifest> root element.');
  }
  xml = xml.replace(manifestOpen[0], `${manifestOpen[0]}\n    <uses-permission android:name="${permission}" />`);
  fs.writeFileSync(manifestPath, xml);
  console.log('Added android.permission.CAMERA for optional hand-tracking mode.');
  return true;
}

// Keep this file both importable by the branding step and usable as a standalone CLI.
const invokedPath = process.argv[1] ? path.resolve(process.argv[1]) : '';
if (invokedPath === fileURLToPath(import.meta.url)) {
  try {
    ensureCameraPermission(process.argv[2] || 'android');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  }
}
