# Báo cáo kiểm thử — AI Arena toàn lực và công bằng

Ngày: 2026-10-21  
Dự án đầu vào: `vila-chess-pro-v3_49-arena-elo500.zip`

## Thay đổi

- Mặc định đấu trường dùng chế độ sức mạnh tối đa, độ sâu 30 và Skill Level 20; giới hạn thời gian mặc định khoảng 3,3 giây cho mỗi nước ở độ sâu 30. Các đối thủ nhận cùng cấu hình độ sâu/thời gian, thay vì hạ riêng sức mạnh của profile Rookie/Mentor.
- Tất cả đối thủ dùng chung sách khai cuộc của đấu trường. Lựa chọn tiếp diễn ổn định theo vị trí, giúp các ván đổi màu không thay nhánh chỉ vì lịch sử chọn khai cuộc toàn cục.
- Cả Stockfish 19 và Stockfish 10 nhận giới hạn độ sâu lẫn thời gian qua lệnh UCI. Profile VILA chỉ được chọn giữa các biến thể Stockfish có điểm nằm trong 18 centipawn so với biến thể tốt nhất.
- Khi engine lỗi, tìm kiếm offline cứu hộ vẫn bị giới hạn thời gian; các nước dự phòng được ghi nhận để người dùng nhận biết.
- Chế độ giới hạn Elo vẫn tồn tại như mô phỏng tùy chọn; nó không phải Elo đã benchmark.

## Kết quả xác minh

- `node --check src/main.js`: đạt.
- `node --check src/arena-strength.js`: đạt.
- `node --check src/legacy-uci-engine.js`: đạt.
- Nhóm kiểm thử chọn lọc sau các thay đổi: **47/47 đạt** (`arena-strength`, tốc độ/engine arena, lịch giải, legacy UCI, project smoke, kiểm tra tính năng v3.23/v3.24).
- Toàn bộ `node --test`: **300/306 mục đạt**. Sáu mục còn lại không khởi chạy do dependency không có trong thư mục `node_modules`: `chess.js` làm lỗi load bốn file test chess/premove/engine và hai file tính năng (trong đó `v3-25-features.test.js`, `v3-48-features.test.js`); `express` làm lỗi `social.test.js`. Đây là lỗi thiếu dependency của môi trường hiện tại, không phải kết quả khẳng định các test đó đã đạt.
- `npm run build`: chưa thành công; bước `prebuild` dừng vì không tìm thấy `node_modules/chess.js/index.js`. Quá trình cài dependency ở môi trường này bị treo/time-out trước đó.

## Giới hạn và tính trung thực

Chưa build APK được và chưa chạy trận engine thật trên OPPO A17k. Cùng thời gian/độ sâu làm giảm lợi thế do cấu hình, nhưng không khiến các phiên bản engine khác nhau có sức mạnh nền giống hệt nhau. Các bot phong cách VILA vẫn là profile chọn nước từ Stockfish, không phải các engine neural độc lập và không có Elo benchmark được xác minh. Để kiểm chứng phát hành, hãy cho GitHub Actions cài dependencies rồi chạy lại toàn bộ test, build web và `assembleDebug`.
