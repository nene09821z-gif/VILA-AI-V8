import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSystemChecks, REQUIRED_OPENING_COUNT } from '../src/system-health.js';

test('system checks report observed ready state and the exact opening count', () => {
  const checks = buildSystemChecks({ engineReady: true, workerSupported: true, storageAvailable: true, openingCount: 3210, backendConfigured: true, backendStatus: 'online' });
  assert.equal(checks.find(x => x.id === 'engine').status, 'ok');
  assert.match(checks.find(x => x.id === 'openings').detail, /3,210/);
  assert.equal(checks.find(x => x.id === 'backend').status, 'ok');
});

test('system checks never report an empty opening book as ready', () => {
  const checks = buildSystemChecks({ engineFailed: true, openingCount: 81, backendConfigured: false });
  assert.equal(checks.find(x => x.id === 'openings').status, 'error');
  assert.match(checks.find(x => x.id === 'openings').detail, new RegExp(String(REQUIRED_OPENING_COUNT).replace(/\B(?=(\d{3})+(?!\d))/g, '[,.]?')));
  assert.equal(checks.find(x => x.id === 'backend').status, 'warning');
});
