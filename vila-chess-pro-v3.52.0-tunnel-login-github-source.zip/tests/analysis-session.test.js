import test from 'node:test';
import assert from 'node:assert/strict';
import { isCurrentAnalysisSession, mergeAnalysisVariation } from '../src/analysis-session.js';

test('analysis session accepts only its original active FEN and game epoch', () => {
  const session = { active: true, sessionFen: 'startpos-fen', currentFen: 'startpos-fen', sessionEpoch: 7, currentEpoch: 7 };
  assert.equal(isCurrentAnalysisSession(session), true);
  assert.equal(isCurrentAnalysisSession({ ...session, currentFen: 'next-position' }), false);
  assert.equal(isCurrentAnalysisSession({ ...session, currentEpoch: 8 }), false);
  assert.equal(isCurrentAnalysisSession({ ...session, active: false }), false);
  assert.equal(isCurrentAnalysisSession({ ...session, sessionEpoch: -1 }), false);
});

test('MultiPV merge keeps the deepest score per lane and does not mutate old state', () => {
  const first = [{ multipv: 1, depth: 10, score: 25, pv: ['e2e4'], fen: 'fen-a' }];
  const shallow = mergeAnalysisVariation(first, { multipv: 1, depth: 8, score: -80, pv: ['d2d4'] }, 'fen-a');
  assert.equal(shallow[0].score, 25);
  const deeper = mergeAnalysisVariation(shallow, { multipv: 1, depth: 12, score: 31, pv: ['g1f3'] }, 'fen-a');
  const third = mergeAnalysisVariation(deeper, { multipv: 3, depth: 11, score: -12, pv: ['c2c4'] }, 'fen-a');
  assert.deepEqual(third.map(v => [v.multipv, v.depth]), [[1, 12], [3, 11]]);
  assert.equal(first[0].depth, 10);
  assert.equal(deeper.length, 1);
});

test('invalid variation data is ignored safely', () => {
  assert.deepEqual(mergeAnalysisVariation(null, { multipv: 1, depth: 1 }, 'fen'), []);
  const base = [{ multipv: 1, depth: 5 }];
  assert.deepEqual(mergeAnalysisVariation(base, { multipv: 0, depth: 6 }, 'fen'), base);
});
