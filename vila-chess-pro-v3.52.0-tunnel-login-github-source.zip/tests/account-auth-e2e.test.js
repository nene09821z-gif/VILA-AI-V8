import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHmac } from 'node:crypto';
import express from 'express';
import { createSocialRouter } from '../server/social.js';

async function startServer(dataDir) {
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  app.use('/api/social', await createSocialRouter({ dataDir }));
  const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = `http://127.0.0.1:${server.address().port}/api/social`;
  const call = async (route, { method = 'GET', body, token, headers = {} } = {}) => {
    const response = await fetch(base + route, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
      body: body ? JSON.stringify(body) : undefined
    });
    const data = await response.json().catch(() => ({}));
    return { status: response.status, data };
  };
  return { server, call, close: () => new Promise(resolve => server.close(resolve)) };
}

test('username + password accounts: register, login, persistent session, server-side storage', async () => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'vila-auth-'));
  let srv = await startServer(dataDir);
  try {
    assert.equal((await srv.call('/health')).data.status, 'online');

    // Registration needs only a username and a password (no email).
    const reg = await srv.call('/auth/register', { method: 'POST', body: { username: 'Kien_Bro', password: 'matkhau123' } });
    assert.equal(reg.status, 201);
    assert.ok(reg.data.token && reg.data.user);
    assert.equal(reg.data.user.username, 'kien_bro');
    assert.equal(reg.data.user.displayName, 'kien_bro');
    assert.equal(reg.data.user.passwordHash, undefined, 'public profile must never expose password material');
    assert.equal(reg.data.user.salt, undefined);

    // Validation.
    assert.equal((await srv.call('/auth/register', { method: 'POST', body: { username: 'ab', password: 'matkhau123' } })).status, 400);
    assert.equal((await srv.call('/auth/register', { method: 'POST', body: { username: 'bad name!', password: 'matkhau123' } })).status, 400);
    assert.equal((await srv.call('/auth/register', { method: 'POST', body: { username: 'shortpw', password: '1234567' } })).status, 400);
    assert.equal((await srv.call('/auth/register', { method: 'POST', body: { username: 'KIEN_BRO', password: 'matkhau123' } })).status, 409, 'usernames are case-insensitive unique');

    // Concurrent sign-ups for one username create exactly one account.
    const race = await Promise.all(Array.from({ length: 5 }, () => srv.call('/auth/register', { method: 'POST', body: { username: 'racer', password: 'matkhau123' } })));
    assert.equal(race.filter(r => r.status === 201).length, 1);

    // Login.
    assert.equal((await srv.call('/auth/login', { method: 'POST', body: { username: 'kien_bro', password: 'sai-mat-khau' } })).status, 401);
    assert.equal((await srv.call('/auth/login', { method: 'POST', body: { username: 'nobody', password: 'matkhau123' } })).status, 401);
    const login = await srv.call('/auth/login', { method: 'POST', body: { username: 'KIEN_BRO', password: 'matkhau123' } });
    assert.equal(login.status, 200);
    assert.equal(login.data.user.id, reg.data.user.id);

    // Session checks.
    assert.equal((await srv.call('/auth/me')).status, 401);
    assert.equal((await srv.call('/auth/me', { token: login.data.token + 'x' })).status, 401);
    const me = await srv.call('/auth/me', { token: login.data.token });
    assert.equal(me.status, 200);
    assert.equal(me.data.user.username, 'kien_bro');
    assert.equal(me.data.token, undefined, 'fresh tokens are not re-issued on every call');

    // Per-account server-side data (history) survives and is private to the account.
    const sync = await srv.call('/history/sync', { method: 'POST', token: login.data.token, body: { games: [{ id: 'g1', signature: 'sig-1', date: '2026-10-22', pgn: '1. e4 e5' }] } });
    assert.equal(sync.status, 200);
    assert.equal(sync.data.syncedCount, 1);

    // The store lives on the server's disk, the password is hashed, and the file is private.
    const raw = await fs.readFile(path.join(dataDir, 'social-store.json'), 'utf8');
    assert.ok(raw.includes('kien_bro'));
    assert.ok(!raw.includes('matkhau123'), 'plain-text password must never be written to disk');
    if (process.platform !== 'win32') assert.equal((await fs.stat(path.join(dataDir, 'social-store.json'))).mode & 0o077, 0);

    // Server restart: account, password and previously issued token remain valid.
    await srv.close();
    srv = await startServer(dataDir);
    assert.equal((await srv.call('/auth/me', { token: login.data.token })).status, 200, 'session token survives a server restart');
    const again = await srv.call('/auth/login', { method: 'POST', body: { username: 'kien_bro', password: 'matkhau123' } });
    assert.equal(again.status, 200);
    assert.equal((await srv.call('/history', { token: again.data.token })).data.games.length, 1);

    // Sliding session: a token older than a week is exchanged for a fresh one.
    const db = JSON.parse(await fs.readFile(path.join(dataDir, 'social-store.json'), 'utf8'));
    const iat = Math.floor(Date.now() / 1000) - 10 * 24 * 3600;
    const payload = Buffer.from(JSON.stringify({ sub: reg.data.user.id, ver: 0, iat, exp: iat + 30 * 24 * 3600 })).toString('base64url');
    const aged = `${payload}.${createHmac('sha256', db.tokenSecret).update(payload).digest('base64url')}`;
    const refreshed = await srv.call('/auth/me', { token: aged });
    assert.equal(refreshed.status, 200);
    assert.ok(refreshed.data.token, 'server issues a refreshed token');
    assert.equal((await srv.call('/auth/me', { token: refreshed.data.token })).status, 200);
    // An expired token is rejected.
    const eiat = Math.floor(Date.now() / 1000) - 40 * 24 * 3600;
    const epayload = Buffer.from(JSON.stringify({ sub: reg.data.user.id, ver: 0, iat: eiat, exp: eiat + 30 * 24 * 3600 })).toString('base64url');
    const expired = `${epayload}.${createHmac('sha256', db.tokenSecret).update(epayload).digest('base64url')}`;
    assert.equal((await srv.call('/auth/me', { token: expired })).status, 401);

    // Logout revokes every issued token.
    assert.equal((await srv.call('/auth/logout', { method: 'POST', token: again.data.token, body: {} })).status, 200);
    assert.equal((await srv.call('/auth/me', { token: again.data.token })).status, 401);
    assert.equal((await srv.call('/auth/login', { method: 'POST', body: { username: 'kien_bro', password: 'matkhau123' } })).status, 200, 'can sign in again after logout');
  } finally {
    await srv.close();
    await fs.rm(dataDir, { recursive: true, force: true });
  }
});
