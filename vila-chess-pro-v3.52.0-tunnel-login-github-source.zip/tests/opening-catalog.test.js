import test from 'node:test';
import assert from 'node:assert/strict';
import { mergeOpeningEntries } from '../src/opening-catalog.js';

const seed = [
  { name: 'Khai cuộc Ý', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'] }
];

test('opening catalog merges unique valid SAN lines without mutating the curated seed', () => {
  const base = structuredClone(seed);
  const imported = [
    { name: 'Khai cuộc Ý', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'] },
    { name: 'Khai cuộc Ý', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5'] },
    { name: 'Broken row', eco: 'C00', san: ['NOT-SAN'] },
    { name: 'Queen opening', eco: 'D00', san: ['d4', 'd5', 'c4', 'e6'] }
  ];
  const result = mergeOpeningEntries(base, imported, 100);
  assert.equal(result.length, 2);
  assert.equal(result[0].eco, 'C50');
  assert.equal(result[0].san.at(-1), 'Bb5');
  assert.equal(result[0].name, 'Khai cuộc Ý · C50');
  assert.equal(result[1].family, 'Mở d4');
  assert.deepEqual(base, seed);
});

test('opening catalog enforces its cap and ignores malformed inputs', () => {
  assert.deepEqual(mergeOpeningEntries(null, []), []);
  const finalMoves = ['Nc3', 'Nd3', 'Nf3', 'Ng3', 'Nb3', 'Nh3', 'Ne3', 'Na3'];
  const imported = Array.from({ length: 10 }, (_, index) => ({
    name: `Line ${index}`, eco: 'B00', san: ['e4', 'a6', finalMoves[index % finalMoves.length]]
  }));
  const result = mergeOpeningEntries([], imported, 3);
  assert.equal(result.length, 3);
  assert.equal(mergeOpeningEntries([], [{ name: 'No moves', san: [] }]).length, 0);
});
