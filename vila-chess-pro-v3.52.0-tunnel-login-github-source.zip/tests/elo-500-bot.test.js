import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { resolveBotStrength, rescueProfileForStrength, isStockfishBotMode } from '../src/elo-strength.js';
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('beginner mode is always Elo 500, even with stale or full-strength saved settings', () => {
  for (const settings of [{}, { botStrengthMode: 'max', botElo: 3200 }, { botStrengthMode: 'elo', botElo: 2600 }]) {
    const s = resolveBotStrength('stockfish-beginner', settings);
    assert.equal(s.targetElo, 500);
    assert.equal(s.skillLevel, 0);
    assert.equal(s.mode, 'skill-level-floor');
  }
  assert.equal(resolveBotStrength('stockfish', { botStrengthMode: 'max' }), null);
  assert.equal(resolveBotStrength('stockfish', { botStrengthMode: 'elo', botElo: 1500 }).uciElo, 1500);
});

test('a weak target is never rescued by a strong offline engine', () => {
  assert.equal(rescueProfileForStrength(resolveBotStrength('stockfish-beginner', {}), 'berserk'), 'rookie');
  assert.equal(rescueProfileForStrength(resolveBotStrength('stockfish', { botStrengthMode: 'elo', botElo: 1000 }), 'berserk'), 'mentor');
  assert.equal(rescueProfileForStrength(null, 'berserk'), 'berserk');
});

test('regression: scheduleBotMove, watchdog and rescue all handle the Elo-500 mode', () => {
  assert.equal(isStockfishBotMode('stockfish-beginner'), true);
  const schedule = main.slice(main.indexOf('function scheduleBotMove'), main.indexOf('function cancelPendingHint'));
  assert.match(schedule, /isStockfishBotMode\(expectedMode\)\) askStockfishMove\(\)/);
  assert.doesNotMatch(schedule, /expectedMode === 'stockfish'\)/);
  const ask = main.slice(main.indexOf('function askStockfishMove'), main.indexOf('function chooseFallbackMove()'));
  assert.doesNotMatch(ask, /mode !== 'stockfish'/);
  assert.doesNotMatch(ask, /mode === 'stockfish' &&/);
  assert.match(ask, /resolveBotStrength\(mode, settings\)/);
});
