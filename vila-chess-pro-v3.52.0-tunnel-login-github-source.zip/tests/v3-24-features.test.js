import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseYoutubeUrl, YOUTUBE_PRESETS } from '../src/youtube-music.js';
import { BOT_REPERTOIRES, getPersonaOpeningNames, repertoireLines } from '../src/bot-personas.js';
import { OPENINGS } from '../src/openings.js';
import { PIECE_SHAPES, pieceSvgMarkup } from '../src/pieces.js';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');
const main = read('../src/main.js');
const html = read('../index.html');
const core = read('../src/alternate-engine-core.js');

test('Royal piece set draws all six pieces for both colours and is present in index.html', () => {
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    assert.ok(PIECE_SHAPES[type].body.length > 40);
    for (const color of ['w', 'b']) assert.match(pieceSvgMarkup({ type, color }, 'royal'), new RegExp(`url\\(#vp-grad-${color}\\)`));
  }
  assert.equal(pieceSvgMarkup({ type: 'x', color: 'w' }), '');
  assert.match(html, /id="vp-grad-w"/);
  assert.match(html, /id="vp-grad-b"/);
});

test('YouTube parser accepts real YouTube links only', () => {
  assert.deepEqual(parseYoutubeUrl('https://www.youtube.com/watch?v=jfKfPfyJRdk'), { videoId: 'jfKfPfyJRdk', listId: '' });
  assert.deepEqual(parseYoutubeUrl('https://youtu.be/jfKfPfyJRdk?t=5'), { videoId: 'jfKfPfyJRdk', listId: '' });
  assert.equal(parseYoutubeUrl('https://youtube.com/playlist?list=PLabcdefghij12').listId, 'PLabcdefghij12');
  assert.equal(parseYoutubeUrl('https://evil.example/watch?v=jfKfPfyJRdk'), null);
  assert.equal(parseYoutubeUrl('not a link'), null);
  for (const preset of YOUTUBE_PRESETS) assert.ok(parseYoutubeUrl(preset.url));
});

test('every bot has exactly four stored opening lines and the arena uses each bot own repertoire', () => {
  const availableNames = new Set(OPENINGS.map(opening => opening.name));
  const signatures = new Set();
  for (const [id, repertoire] of Object.entries(BOT_REPERTOIRES)) {
    assert.equal(repertoire.openingNames.length, 4, `${id} should store exactly four opening choices`);
    assert.equal(new Set(repertoire.openingNames).size, 4, `${id} should not repeat an opening`);
    for (const name of repertoire.openingNames) assert.ok(availableNames.has(name), `${id}: missing catalogue line ${name}`);
    const actual = repertoireLines(OPENINGS, id, 'w');
    assert.equal(actual.length, 4, `${id} must resolve all four lines from the catalogue`);
    assert.equal(new Set(actual.map(opening => opening.san.join(' '))).size, 4, `${id} should store four distinct move sequences`);
    assert.deepEqual(new Set(actual.map(opening => opening.name)), new Set(repertoire.openingNames));
    assert.deepEqual(new Set(getPersonaOpeningNames(id)), new Set(repertoire.openingNames));
    signatures.add([...repertoire.openingNames].sort().join('|'));
  }
  assert.equal(signatures.size, Object.keys(BOT_REPERTOIRES).length, 'each bot should have a different four-opening reserve');
  for (const id of ['lc0', 'ethereal', 'berserk', 'fortress', 'endgame', 'dynamic', 'blitz', 'gambit', 'hyper', 'strangler', 'trickster', 'rookie', 'mentor', 'hunter', 'sentinel', 'strategist', 'longgame', 'chaos']) {
    assert.ok(core.includes(`id: '${id}'`), `missing engine profile ${id}`);
  }
  assert.match(main, /setChessMusicYoutube\(parsed/);
  assert.match(main, /id="ytMusicUrl"/);
  assert.match(main, /pickPersonaBookMove\(game, profile, OPENINGS/);
  assert.match(main, /pickPersonaBookMove\(chess, profile, OPENINGS, \{ recentChoices: arenaOpeningChoices \}\)/);
  assert.match(main, /4 khai cuộc dự trữ/);
  assert.match(main, /id="arenaPairedOpenings"\/>/);
  assert.doesNotMatch(main, /findOpeningBookMove\(chess, OPENINGS, \{ maxPlies: 20, random: \(\) => 0\.5 \}\)/);
});

test('random Trắng/Đen is the default for bot games and a toggle exists for the arena', () => {
  assert.match(main, /let colorChoice = 'random'/);
  assert.match(main, /let arenaRandomSides = true/);
  assert.match(main, /id="arenaRandomSides"/);
  assert.ok(main.indexOf('value="random"') < main.indexOf('value="w" ${colorChoice'), 'random must be the first option');
});

test('flat 2D piece style uses the supplied detailed artwork for all piece colours', () => {
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    for (const color of ['w', 'b']) {
      const markup = pieceSvgMarkup({ type, color }, 'flat');
      assert.match(markup, /piece-set-flat/);
      assert.match(markup, new RegExp(`src=\"\.\/pieces\/${color}_${type}\.png\"`));
      assert.ok(read(`../public/pieces/${color}_${type}.png`).length > 1000, `missing ${color}_${type} artwork`);
    }
  }
  assert.match(main, /id="pieceStyleSetting"/);
});
