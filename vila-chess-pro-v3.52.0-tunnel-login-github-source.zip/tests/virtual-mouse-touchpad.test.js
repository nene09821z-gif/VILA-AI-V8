import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('virtual mouse pad supports tap-to-click, double-tap-drag and velocity gain', () => {
  assert.match(main, /function virtualMousePointerGain\(/);
  assert.match(main, /VIRTUAL_MOUSE_ACCEL_MAX/);
  assert.match(main, /VIRTUAL_MOUSE_TAP_MS/);
  assert.match(main, /VIRTUAL_MOUSE_DOUBLE_TAP_MS/);
  assert.match(main, /virtualMousePadHeld/);
  assert.match(main, /window\.addEventListener\('resize',[\s\S]*virtualMouseSetPosition/);
});

test('virtual mouse gain: slow = base sensitivity, fast = boosted but capped', () => {
  const src = main.match(/function virtualMousePointerGain[\s\S]*?\n}\n/)[0];
  const fn = new Function('VIRTUAL_MOUSE_SENSITIVITY', 'VIRTUAL_MOUSE_ACCEL_MAX', `${src}; return virtualMousePointerGain;`)(2.35, 2.4);
  assert.equal(fn(1, 16), 2.35);
  const fast = fn(200, 16);
  assert.ok(fast > 2.35 && fast <= 2.35 * 2.4 + 1e-9);
});
