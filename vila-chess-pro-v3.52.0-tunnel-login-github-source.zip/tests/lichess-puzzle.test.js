import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeLichessPuzzlePayload, uciToMove, puzzlePlyCandidates,
  prepareLichessDailyPuzzle, validateCachedPuzzleLine, lichessDifficultyForProgress, lichessPuzzleUrlForDifficulty, lichessDailyPuzzleUrl,
} from '../src/lichess-puzzle.js';

const payload = () => ({
  puzzle: { id: 'abc123', rating: 1460, plays: 980, initialPly: 2, solution: { moves: ['g1f3', 'g8f6', 'f3e5'] }, themes: ['fork', 'advantage'] },
  game: { id: 'game1234', pgn: '[Event "Test"]\n\n1. e4 e5 2. Nf3 Nc6 *' },
});

class FakeChess {
  constructor(fen = 'test-ply-0') {
    this.ply = Number(String(fen).match(/test-ply-(\d+)/)?.[1] || 0);
    this.sanHistory = [];
  }
  loadPgn() { this.sanHistory = ['e4', 'e5', 'Nf3', 'Nc6']; this.ply = 4; }
  history() { return [...this.sanHistory]; }
  getHeaders() { return {}; }
  fen() { return `test-ply-${this.ply}`; }
  move(value) {
    if (typeof value === 'string') { this.ply += 1; return { san: value }; }
    const from = value?.from; const to = value?.to;
    if (!from || !to) return null;
    this.ply += 1;
    return { san: `${from}${to}`, from, to };
  }
}

test('normalizes Lichess puzzle data and keeps source metadata', () => {
  const normalized = normalizeLichessPuzzlePayload(payload());
  assert.equal(normalized.id, 'abc123');
  assert.equal(normalized.rating, 1460);
  assert.deepEqual(normalized.moves, ['g1f3', 'g8f6', 'f3e5']);
  assert.deepEqual(normalized.themes, ['fork', 'advantage']);
  assert.equal(normalized.url, 'https://lichess.org/training/abc123');
});

test('rejects malformed remote puzzle data rather than using unvalidated moves', () => {
  assert.throws(() => normalizeLichessPuzzlePayload({ ...payload(), puzzle: { ...payload().puzzle, solution: { moves: ['javascript:alert(1)'] } } }));
  assert.throws(() => normalizeLichessPuzzlePayload({ puzzle: {}, game: {} }));
});

test('converts UCI coordinates and handles promotions', () => {
  assert.deepEqual(uciToMove('e7e8q'), { from: 'e7', to: 'e8', promotion: 'q' });
  assert.deepEqual(uciToMove('g1f3'), { from: 'g1', to: 'f3' });
  assert.throws(() => uciToMove('e2e9'));
});

test('chooses preferred puzzle ply first while keeping nearby PGN recovery options bounded', () => {
  assert.deepEqual(puzzlePlyCandidates(4, 9), [4, 3, 5, 2, 6]);
  assert.deepEqual(puzzlePlyCandidates(0, 2), [0, 1, 2]);
  assert.deepEqual(puzzlePlyCandidates(100, 3), []);
});

test('prepares puzzle FEN and verifies the entire solution line with the supplied rules engine', () => {
  const prepared = prepareLichessDailyPuzzle(payload(), FakeChess);
  assert.equal(prepared.fen, 'test-ply-2');
  assert.equal(prepared.firstMove, 'g1f3');
  assert.deepEqual(prepared.sanLine, ['g1f3', 'g8f6', 'f3e5']);
  assert.equal(prepared.source, 'lichess');
  assert.equal(validateCachedPuzzleLine(prepared, FakeChess), true);
  assert.equal(validateCachedPuzzleLine({ fen: 'test-ply-2', moves: ['bad'] }, FakeChess), false);
});


test('Lichess puzzle API uses official daily and progressive difficulty endpoints', () => {
  assert.equal(lichessDailyPuzzleUrl(), 'https://lichess.org/api/puzzle/daily');
  assert.equal(lichessPuzzleUrlForDifficulty('easiest'), 'https://lichess.org/api/puzzle/next?difficulty=easiest');
  assert.equal(lichessPuzzleUrlForDifficulty('untrusted/value'), 'https://lichess.org/api/puzzle/next?difficulty=normal');
  assert.deepEqual([0, 4, 5, 10, 15, 20, 80].map(lichessDifficultyForProgress), ['easiest','easiest','easier','normal','harder','hardest','hardest']);
});
