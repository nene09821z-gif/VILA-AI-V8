import test from 'node:test';
import assert from 'node:assert/strict';
import { CLOCK_PRESETS, RANKED_CLOCK_PRESETS, classifyTimeControl, parseClockPreset, formatClockTime, consumeClockTick } from '../src/clock.js';

test('clock presets cover ultra bullet, bullet, blitz, and rapid without untimed ranked games', () => {
  for (const value of ['untimed', '0.25+0', '0.5+0', '1+0', '2+0', '2+1', '3+0', '3+2', '5+0', '6+0', '10+0', '15+10', '20+0', '25+5', '30+0']) {
    assert.ok(CLOCK_PRESETS.some(item => item.value === value), `missing clock preset ${value}`);
  }
  assert.ok(!RANKED_CLOCK_PRESETS.some(item => item.value === 'untimed'));
  assert.ok(RANKED_CLOCK_PRESETS.some(item => item.value === '1d' && item.category === 'daily'));
  assert.ok(RANKED_CLOCK_PRESETS.some(item => item.value === '2d' && item.category === 'daily'));
  assert.equal(classifyTimeControl('1d'), 'daily');
  assert.equal(parseClockPreset('2d').baseMs, 172800000);
  assert.equal(parseClockPreset('3+2').baseMs, 180_000);
  assert.equal(parseClockPreset('3+2').incrementMs, 2_000);
  assert.equal(parseClockPreset('0.25+0').baseMs, 15_000);
  assert.equal(classifyTimeControl('2+1'), 'bullet');
  assert.equal(classifyTimeControl('3+2'), 'blitz');
  assert.equal(classifyTimeControl('10+5'), 'rapid');
  assert.equal(parseClockPreset('not-a-clock').preset, '10+0');
});

test('clock formatting stays readable from untimed to sub-ten-second states', () => {
  assert.equal(formatClockTime(999_999, false), '∞');
  assert.equal(formatClockTime(600_000), '10:00');
  assert.equal(formatClockTime(9_999), '9.9');
  assert.equal(formatClockTime(0), '0.0');
  assert.equal(formatClockTime(86400000), '1d 00:00');
  assert.equal(formatClockTime(-1), '0.0');
});


test('clock tick math is monotonic, clamps zero and cannot leak NaN into the live clock', () => {
  const state = { enabled: true, running: true, lastTickAt: 1000, remaining: { w: 2500, b: 7000 } };
  assert.deepEqual(consumeClockTick(state, 'w', 1750), { valid: true, elapsedMs: 750, remainingMs: 1750, flagged: false });
  assert.equal(consumeClockTick(state, 'w', 500).remainingMs, 2500, 'clock rollback must not add or remove time');
  assert.deepEqual(consumeClockTick({ ...state, remaining: { w: 100, b: 7000 } }, 'w', 1100), { valid: true, elapsedMs: 100, remainingMs: 0, flagged: true });
  assert.equal(consumeClockTick({ ...state, remaining: { w: Number.NaN, b: 7000 } }, 'w', 1010).remainingMs, 0);
  assert.deepEqual(consumeClockTick({ ...state, running: false }, 'w', 2000), { valid: false, elapsedMs: 0, remainingMs: null, flagged: false });
  assert.equal(consumeClockTick(state, 'x', 2000).valid, false);
});
