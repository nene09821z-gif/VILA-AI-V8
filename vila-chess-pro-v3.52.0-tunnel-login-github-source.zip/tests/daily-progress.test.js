import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  DAILY_MISSIONS, COSMETICS, createDailyState, normalizeDailyState,
  recordMissionEvent, claimMissionReward, purchaseCosmetic, equipCosmetic, getMissionSummary
} from '../src/daily-progress.js';

const date = (day) => new Date(2026, 4, day, 12, 0, 0);

test('daily check-in and streak roll forward on consecutive days and reset after a missed day', () => {
  const first = createDailyState(date(10));
  assert.equal(first.streak, 1);
  assert.equal(first.missionProgress.checkin, 1);
  const next = normalizeDailyState(first, date(11));
  assert.equal(next.streak, 2);
  assert.equal(next.day, '2026-05-11');
  assert.deepEqual(next.claimed, []);
  const missed = normalizeDailyState(next, date(14));
  assert.equal(missed.streak, 1);
  assert.equal(missed.day, '2026-05-14');
});

test('daily mission rewards require completion and can only be claimed once', () => {
  let state = createDailyState(date(10));
  let result = claimMissionReward(state, 'finish_game', date(10));
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'not_completed');
  state = recordMissionEvent(state, 'complete_game', date(10));
  assert.equal(state.missionProgress.finish_game, 1);
  result = claimMissionReward(state, 'finish_game', date(10));
  assert.equal(result.ok, true);
  assert.equal(result.reward, 35);
  assert.equal(result.state.coins, 35);
  const repeated = claimMissionReward(result.state, 'finish_game', date(10));
  assert.equal(repeated.ok, false);
  assert.equal(repeated.reason, 'already_claimed');
  assert.equal(repeated.state.coins, 35);
});

test('mission progress is capped at its goal and only known events change missions', () => {
  let state = createDailyState(date(10));
  state = recordMissionEvent(state, 'visit_coach', date(10));
  state = recordMissionEvent(state, 'visit_coach', date(10));
  assert.equal(state.missionProgress.coach_visit, 1);
  const before = state.missionProgress.opening_visit;
  state = recordMissionEvent(state, 'unknown-event', date(10));
  assert.equal(state.missionProgress.opening_visit, before);
  assert.ok(DAILY_MISSIONS.length >= 16);
});

test('cosmetic store prevents overspending and only permits owned cosmetics to be equipped', () => {
  let state = createDailyState(date(10));
  let result = purchaseCosmetic(state, 'ocean', date(10));
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'not_enough_coins');
  state.coins = 200;
  result = purchaseCosmetic(state, 'ocean', date(10));
  assert.equal(result.ok, true);
  assert.equal(result.state.coins, 100);
  assert.ok(result.state.ownedCosmetics.includes('ocean'));
  const equipped = equipCosmetic(result.state, 'ocean', date(10));
  assert.equal(equipped.ok, true);
  assert.equal(equipped.state.activeCosmetic, 'ocean');
  assert.equal(equipCosmetic(equipped.state, 'walnut', date(10)).reason, 'not_owned');
  assert.ok(COSMETICS.length >= 8);
});

test('progress summary reports coins, streak, and daily completion accurately', () => {
  let state = createDailyState(date(10));
  state = recordMissionEvent(state, 'visit_openings', date(10));
  const result = claimMissionReward(state, 'opening_visit', date(10));
  const summary = getMissionSummary(result.state, date(10));
  assert.equal(summary.coins, 20);
  assert.equal(summary.streak, 1);
  assert.equal(summary.completed, 2); // check-in + opening
  assert.equal(summary.total, DAILY_MISSIONS.length);
  assert.equal(summary.claimed, 1);
});


test('v3.12 UI routes are connected and clearly distinguish virtual rewards from money', () => {
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
  const readme = fs.readFileSync(path.join(root, 'MONETIZATION.md'), 'utf8');
  assert.match(html, /data-view="missions"/);
  assert.match(html, /data-view="shop"/);
  assert.match(main, /currentView === 'missions'.*renderMissionsView/s);
  assert.match(main, /currentView === 'shop'.*renderShopView/s);
  assert.match(main, /recordDailyEvent\('complete_game'\)/);
  assert.match(main, /data-claim-mission/);
  assert.match(main, /data-buy-cosmetic/);
  assert.match(readme, /No real-money payment or live advertising is enabled/);
});


test('v3.12 includes multiple simultaneous goals for the same event and puzzle progression', () => {
  let state = createDailyState(date(10));
  state = recordMissionEvent(state, 'complete_game', date(10));
  assert.equal(state.missionProgress.finish_game, 1);
  assert.equal(state.missionProgress.play_three, 1);
  // This mission tracks distinct claimed rewards, not completed games.
  assert.equal(state.missionProgress.streak_bonus, 0);
  const openingClaim = claimMissionReward(
    recordMissionEvent(state, 'visit_openings', date(10)),
    'opening_visit',
    date(10)
  );
  assert.equal(openingClaim.ok, true);
  assert.equal(openingClaim.state.missionProgress.streak_bonus, 1);
  state = recordMissionEvent(state, 'solve_puzzle', date(10));
  state = recordMissionEvent(state, 'solve_puzzle', date(10));
  state = recordMissionEvent(state, 'solve_puzzle', date(10));
  assert.equal(state.missionProgress.solve_puzzles, 3);
  assert.equal(claimMissionReward(state, 'solve_puzzles', date(10)).ok, true);
});


test('streak mission counts distinct claimed rewards, caps at five, and cannot self-complete', () => {
  const today = date(10);
  let state = createDailyState(today);
  state = recordMissionEvent(state, 'visit_openings', today);
  const first = claimMissionReward(state, 'opening_visit', today);
  assert.equal(first.ok, true);
  assert.equal(first.state.missionProgress.streak_bonus, 1);
  const duplicate = claimMissionReward(first.state, 'opening_visit', today);
  assert.equal(duplicate.ok, false);
  assert.equal(duplicate.state.missionProgress.streak_bonus, 1);
  state = first.state;
  for (const id of ['coach_visit', 'finish_game', 'win_game', 'draw_game']) {
    const mission = DAILY_MISSIONS.find(item => item.id === id);
    state = recordMissionEvent(state, mission.event, today);
    const result = claimMissionReward(state, id, today);
    assert.equal(result.ok, true, `expected ${id} to be claimable`);
    state = result.state;
  }
  assert.equal(state.missionProgress.streak_bonus, 5);
  const streakClaim = claimMissionReward(state, 'streak_bonus', today);
  assert.equal(streakClaim.ok, true);
  assert.equal(streakClaim.state.missionProgress.streak_bonus, 5);
});
