import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');

test('main.js wires chess.com UX module', () => {
  const main = read('src/main.js');
  assert.match(main, /from '\.\/chesscom-ux\.js'/);
  assert.match(main, /chesscom-polish\.css/);
  assert.match(main, /buildReviewDashboard/);
  assert.match(main, /botThinkDelayMs/);
  assert.match(main, /BOT_ELO_PRESETS/);
  assert.match(main, /puzzleStreakLabel/);
  assert.match(main, /LESSON_CATALOG/);
  assert.match(main, /clubHomeMarkup/);
  assert.match(main, /boardThemeSwatches|theme-swatch|BOARD_THEME_CATALOG/);
  assert.match(main, /renderOpeningExplorerPanel|openingExplorerContinuations/);
  assert.match(main, /currentView === 'lessons'|currentView === 'club'/);
});

test('index.html exposes club navigation', () => {
  const html = read('index.html');
  assert.match(html, /data-view="club"/);
  assert.match(html, /data-view="openings"/);
  assert.match(html, /data-view="friends"/);
});

test('polish stylesheet ships motion and action-bar rules', () => {
  const css = read('src/chesscom-polish.css');
  assert.match(css, /match-action-bar/);
  assert.match(css, /review-dashboard/);
  assert.match(css, /opening-explorer/);
  assert.match(css, /in-check/);
  assert.match(css, /lesson-grid/);
  assert.match(css, /bot-elo-chip/);
});

test('home one-tap and play opening explorer are wired', () => {
  const main = read('src/main.js');
  assert.match(main, /data-home-elo/);
  assert.match(main, /home-one-tap/);
  assert.match(main, /openingExplorerPanel/);
  assert.match(main, /renderOpeningExplorerPanel/);
  assert.match(main, /data-home-action="daily-puzzle"/);
});


test('commercial skin stylesheet is loaded last', () => {
  const main = read('src/main.js');
  assert.match(main, /vila-commercial\.css/);
  const css = read('src/vila-commercial.css');
  assert.match(css, /--vila-accent/);
  assert.match(css, /home-one-tap/);
  assert.match(css, /primary-btn/);
});
