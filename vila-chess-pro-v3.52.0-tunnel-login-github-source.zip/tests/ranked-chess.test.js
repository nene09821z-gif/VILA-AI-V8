import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRankedEloChange, chooseRandomOpponent, eloExpectedScore, hasRankedPresenceExpired, matchmakingWindow, settleRankedClock } from '../server/ranked-chess.js';

test('Elo expectation stays bounded and respects rating difference', () => {
  assert.equal(eloExpectedScore(1200, 1200), 0.5);
  assert.ok(eloExpectedScore(1600, 1200) > 0.9);
  assert.ok(eloExpectedScore(800, 1200) < 0.1);
});

test('ranked Elo uses bounded K factor and keeps rating within platform limits', () => {
  assert.deepEqual(calculateRankedEloChange(1200, 1200, 1, 24, 0), { before: 1200, after: 1212, delta: 12 });
  assert.equal(calculateRankedEloChange(100, 4000, 0, 24, 0).after, 100);
  assert.equal(calculateRankedEloChange(3999, 3999, 1, 24).after, 4000);
  assert.equal(calculateRankedEloChange(1200, 1200, 1, 24).delta, 12);
  assert.equal(calculateRankedEloChange(1200, 1200, 1, 24).delta, calculateRankedEloChange(1200, 1200, 1, 24).delta, 'same result must always yield same Elo');
});

test('matchmaking range expands gradually and picks only compatible other users', () => {
  assert.equal(matchmakingWindow(0), 100);
  assert.equal(matchmakingWindow(20), 200);
  assert.equal(matchmakingWindow(300), 500);
  const queue = [{ userId: 'self', elo: 1200, joinedAt: 0 }, { userId: 'far', elo: 1900, joinedAt: 10 }, { userId: 'near', elo: 1280, joinedAt: 10 }];
  assert.equal(chooseRandomOpponent(queue, 'self', 1200, 1000, () => 0)?.userId, 'near');
  assert.equal(chooseRandomOpponent([{ userId: 'far', elo: 1900, joinedAt: 10 }], 'self', 1200, 1000), null);
});

test('ranked presence timeout has a grace period and handles missing timestamps safely', () => {
  const now = 10_000_000;
  assert.equal(hasRankedPresenceExpired(now - 89_000, now, 90_000), false);
  assert.equal(hasRankedPresenceExpired(now - 91_000, now, 90_000), true);
  assert.equal(hasRankedPresenceExpired(undefined, now, 90_000), false);
});


test('ranked clock decrements only the active side and ends at zero', () => {
  const match = { clockEnabled: true, clockRemainingMs: { w: 10_000, b: 6_000 }, clockUpdatedAt: 1_000 };
  assert.equal(settleRankedClock(match, 2_500, 'w'), null);
  assert.equal(match.clockRemainingMs.w, 8_500);
  assert.equal(match.clockRemainingMs.b, 6_000);
  assert.equal(match.clockUpdatedAt, 2_500);
  assert.equal(settleRankedClock(match, 11_000, 'w'), 'w');
  assert.equal(match.clockRemainingMs.w, 0);
});

test('ranked clock safely ignores casual or malformed matches', () => {
  assert.equal(settleRankedClock({ clockEnabled: false, clockRemainingMs: { w: 1000, b: 1000 } }, 10_000, 'w'), null);
  assert.equal(settleRankedClock(null, 10_000, 'w'), null);
  assert.equal(settleRankedClock({ clockEnabled: true, clockRemainingMs: { w: 1000, b: 1000 } }, 10_000, 'x'), null);
});

test('server Elo is deterministic and symmetric for equal ratings', () => {
  const win = calculateRankedEloChange(1200, 1200, 1, 24);
  const loss = calculateRankedEloChange(1200, 1200, 0, 24);
  assert.equal(win.delta, 12);
  assert.equal(loss.delta, -12);
  assert.equal(win.delta + loss.delta, 0);
});

test('server Elo rejects invalid outcomes rather than clamping them into real results', () => {
  for (const score of [NaN, Infinity, -1, 0.25, 2, 'invalid']) {
    assert.throws(() => calculateRankedEloChange(1200, 1200, score), TypeError);
  }
  assert.deepEqual(calculateRankedEloChange(1200, 1200, 0.5), { before: 1200, after: 1200, delta: 0 });
});
