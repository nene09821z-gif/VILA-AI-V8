import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DEFAULTS, DEFAULT_BACKEND_URL, normalizeSettings } from '../src/settings-schema.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server/index.js', import.meta.url), 'utf8');
const social = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');

test('app connects to the Cloudflare Tunnel account server by default, and users can still override it', () => {
  assert.equal(DEFAULT_BACKEND_URL, 'https://cosmetics-paris-believe-harvey.trycloudflare.com');
  assert.equal(DEFAULTS.backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({}).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'https://my.example.com/' }).backendUrl, 'https://my.example.com');
});

test('sign-up and sign-in forms use only a username and password', () => {
  const gateRegister = main.match(/<form data-auth-submit="register">[\s\S]*?<\/form>/)[0];
  assert.match(gateRegister, /name="username"/);
  assert.match(gateRegister, /name="password"[^>]*minlength="8"/);
  assert.doesNotMatch(gateRegister, /type="email"|name="email"/);
  const gateLogin = main.match(/<form data-auth-submit="login">[\s\S]*?<\/form>/)[0];
  assert.match(gateLogin, /name="identity"/);
  assert.doesNotMatch(gateLogin, /minlength=/, 'legacy accounts with longer passwords and any length must still sign in');
  assert.match(main, /socialApi\('\/auth\/register', \{ method: 'POST', body: JSON\.stringify\(\{ username: String\(values\.get\('username'\)/);
  assert.match(social, /MIN_PASSWORD_LENGTH = 8/);
});

test('only a definite 401 (or banned/missing account) ends the stored session; offline or validation errors do not', () => {
  assert.match(main, /failure\.status = response\.status/);
  assert.match(main, /function isSessionRejected\(error\)/);
  assert.doesNotMatch(main, /không hợp lệ\|HTTP 401\|HTTP 403/, 'message-text matching used to sign users out on unrelated validation errors');
  assert.match(main, /Only a definite rejection from the server ends the session/);
});

test('server keeps sessions long-lived, refreshes them, and sees real client IPs behind the tunnel', () => {
  assert.match(social, /TOKEN_TTL_SECONDS = 30 \* 24 \* 60 \* 60/);
  assert.match(social, /router\.post\('\/auth\/logout'/);
  assert.match(server, /app\.set\('trust proxy', 'loopback'\)/);
  assert.match(server, /https:\/\/localhost/, 'Capacitor Android WebView origin stays in the CORS allow-list');
});
