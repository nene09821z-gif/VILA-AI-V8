import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createEngineHealthState, observeEngineLine, failEngineHealth,
  engineStartupDurationMs, describeEngineHealth, splitUciOutput
} from '../src/engine-health.js';

test('engine is not ready until uciok is followed by readyok', () => {
  let state = createEngineHealthState('lite-single', 100, 2);
  state = observeEngineLine(state, 'info string starting', 110);
  assert.equal(state.status, 'loading');
  state = observeEngineLine(state, 'readyok', 120);
  assert.equal(state.status, 'loading', 'a stray readyok must not fake the UCI handshake');
  assert.equal(state.readyOk, false);
  state = observeEngineLine(state, 'uciok', 130);
  assert.equal(state.uciOk, true);
  assert.equal(state.status, 'loading');
  state = observeEngineLine(state, 'readyok', 150);
  assert.equal(state.status, 'ready');
  assert.equal(engineStartupDurationMs(state), 50);
  assert.match(describeEngineHealth(state), /uciok \+ readyok/);
});

test('unknown engine output cannot mark readiness and failed startup remains explicit', () => {
  let state = createEngineHealthState('sf10', 100);
  state = observeEngineLine(state, 'bestmove e2e4', 140);
  assert.equal(state.status, 'loading');
  state = failEngineHealth(state, 'Worker timed out', 8000);
  assert.equal(state.status, 'failed');
  assert.match(describeEngineHealth(state), /Worker timed out/);
  assert.equal(observeEngineLine(state, 'uciok', 9000), state, 'late lines from failed startup cannot revive it');
});

test('runtime failure downgrades readiness and a late line cannot revive the failed worker', () => {
  let state = createEngineHealthState('full-single', 1);
  state = observeEngineLine(state, 'uciok', 2);
  state = observeEngineLine(state, 'readyok', 3);
  state = failEngineHealth(state, 'worker exited unexpectedly', 4);
  assert.equal(state.status, 'failed');
  assert.equal(observeEngineLine(state, 'uciok', 5), state);
});


test('split UCI output handles legacy Stockfish multiline worker events', () => {
  assert.deepEqual(splitUciOutput('id name Stockfish 10\r\nuciok\nreadyok\n'), ['id name Stockfish 10', 'uciok', 'readyok']);
  let state = createEngineHealthState('sf10', 10);
  for (const line of splitUciOutput('id name Stockfish 10\nuciok\nreadyok')) state = observeEngineLine(state, line, 12);
  assert.equal(state.status, 'ready');
});


test('legacy engine profile supports UCI handshake where old Worker emits several lines at once', () => {
  let state = createEngineHealthState('sf10', 100);
  for (const line of splitUciOutput('id name Stockfish 10\noption name Skill Level type spin default 20 min 0 max 20\nuciok\n')) {
    state = observeEngineLine(state, line, 110);
  }
  assert.equal(state.uciOk, true);
  assert.equal(state.status, 'loading');
  for (const line of splitUciOutput('readyok\n')) state = observeEngineLine(state, line, 120);
  assert.equal(state.status, 'ready');
});
