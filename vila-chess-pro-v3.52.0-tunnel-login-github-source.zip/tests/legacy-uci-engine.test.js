import test from 'node:test';
import assert from 'node:assert/strict';
import { LegacyUciEngine } from '../src/legacy-uci-engine.js';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const AFTER_E4 = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1';
const AFTER_D5 = 'rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2';
const AFTER_EXD5 = 'rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b KQkq - 0 2';
const AFTER_QXD5 = 'r1b1kbnr/ppp1pppp/8/3q4/8/8/PPPP1PPP/RNBQKBNR w KQkq - 0 3';

class FakeUciWorker {
  constructor({ moves = [], autoBestmove = true, combinedOutput = false } = {}) {
    this.onmessage = null;
    this.onerror = null;
    this.terminated = false;
    this.lines = [];
    this.moves = [...moves];
    this.autoBestmove = autoBestmove;
    this.combinedOutput = combinedOutput;
  }
  emit(data) { this.onmessage?.({ data }); }
  postMessage(line) {
    this.lines.push(line);
    if (line === 'uci') queueMicrotask(() => this.emit('uciok'));
    else if (line === 'isready') queueMicrotask(() => this.emit('readyok'));
    else if (line.startsWith('go movetime ') && this.autoBestmove) {
      const move = this.moves.shift() || 'e2e4';
      queueMicrotask(() => {
        if (this.combinedOutput) this.emit(`info depth 12 score cp 34 nodes 12000 pv ${move}\nbestmove ${move} ponder e7e5`);
        else {
          this.emit(`info depth 12 score cp 34 nodes 12000 pv ${move} e7e5`);
          this.emit(`bestmove ${move} ponder e7e5`);
        }
      });
    } else if (line === 'stop' && this.autoBestmove) queueMicrotask(() => this.emit('bestmove e2e4'));
  }
  terminate() { this.terminated = true; }
}

test('legacy UCI worker handshakes, configures mobile-safe options and returns a parsed best move', async () => {
  const worker = new FakeUciWorker();
  const engine = new LegacyUciEngine(() => worker, { initTimeoutMs: 500, defaultSearchTimeoutMs: 1500 });
  const result = await engine.bestMove(START, { skill: 17, moveTimeMs: 150 });
  assert.deepEqual(result, { uci: 'e2e4', depth: 12, score: 34, pv: 'e2e4' });
  assert.ok(worker.lines.includes('setoption name Threads value 1'));
  assert.ok(worker.lines.includes('setoption name Hash value 2'));
  assert.ok(worker.lines.includes('setoption name Skill Level value 17'));
  assert.ok(worker.lines.includes(`position fen ${START}`));
  assert.equal(worker.lines.filter(line => line === 'ucinewgame').length, 1);
  engine.dispose();
  assert.equal(worker.terminated, true);
});

test('malformed FEN is rejected before a worker is created', async () => {
  let factoryCalls = 0;
  const engine = new LegacyUciEngine(() => { factoryCalls++; return new FakeUciWorker(); }, { initTimeoutMs: 500 });
  await assert.rejects(() => engine.bestMove('not a FEN'), /FEN/);
  assert.equal(factoryCalls, 0);
  engine.dispose();
});

test('a timeout retires its worker and the next search can initialize a replacement worker', async () => {
  let firstWorker;
  let factoryCalls = 0;
  const engine = new LegacyUciEngine(() => {
    factoryCalls++;
    const worker = new FakeUciWorker();
    if (factoryCalls === 1) firstWorker = worker;
    return worker;
  }, { initTimeoutMs: 500, defaultSearchTimeoutMs: 200 });
  await engine.ensureReady();
  const staleHandler = firstWorker.onmessage;
  firstWorker.autoBestmove = false;
  await assert.rejects(() => engine.bestMove(START, { moveTimeMs: 150, timeoutMs: 180 }), /vượt thời gian/);
  assert.equal(firstWorker.terminated, true);
  assert.equal(firstWorker.onmessage, null, 'retired worker callbacks must be detached');

  const replacement = new FakeUciWorker({ autoBestmove: false });
  engine.workerFactory = () => { factoryCalls++; return replacement; };
  const nextSearch = engine.bestMove(AFTER_E4, { moveTimeMs: 150, timeoutMs: 2000 });
  await new Promise(resolve => setTimeout(resolve, 0));
  // Even manually invoking a queued callback from the old Worker cannot
  // finish the replacement Worker’s pending search.
  staleHandler?.({ data: 'bestmove a2a3' });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.equal(replacement.lines.some(line => line.startsWith('go movetime ')), true);
  replacement.emit('info depth 7 score cp 12 pv d7d5');
  replacement.emit('bestmove d7d5');
  const recovered = await nextSearch;
  assert.equal(recovered.uci, 'd7d5');
  assert.equal(factoryCalls, 2);
  engine.dispose();
});

test('legacy UCI engine completes repeated turns, capture positions and resets new-game state only once per match', async () => {
  const worker = new FakeUciWorker({ moves: ['e2e4', 'd7d5', 'e4d5', 'd8d5', 'b1c3', 'd5e5'] });
  const engine = new LegacyUciEngine(() => worker, { initTimeoutMs: 500, defaultSearchTimeoutMs: 1500 });
  const positions = [START, AFTER_E4, AFTER_D5, AFTER_EXD5, AFTER_QXD5, AFTER_QXD5];
  const expected = ['e2e4', 'd7d5', 'e4d5', 'd8d5', 'b1c3', 'd5e5'];
  for (let i = 0; i < positions.length; i++) {
    const result = await engine.bestMove(positions[i], { moveTimeMs: 150 });
    assert.equal(result.uci, expected[i], `search ${i + 1} should resolve rather than stall`);
  }
  assert.equal(worker.lines.filter(line => line === 'ucinewgame').length, 1, 'do not clear the hash table on every ply');
  assert.equal(worker.lines.filter(line => line.startsWith('go movetime 150 depth ')).length, positions.length);

  const goIndices = worker.lines.map((line, index) => line.startsWith('go movetime ') ? index : -1).filter(index => index >= 0);
  for (const goIndex of goIndices) {
    assert.match(worker.lines[goIndex - 1], /^position fen /, 'position must immediately precede go');
    assert.equal(worker.lines[goIndex - 2], 'isready', 'ready barrier must be sent before each position/go pair');
  }
  engine.newGame();
  await engine.bestMove(START, { moveTimeMs: 150 });
  assert.equal(worker.lines.filter(line => line === 'ucinewgame').length, 2, 'a new arena game gets one reset');
  engine.dispose();
});

test('combined UCI info and bestmove lines are both parsed', async () => {
  const worker = new FakeUciWorker({ combinedOutput: true });
  const engine = new LegacyUciEngine(() => worker, { initTimeoutMs: 500, defaultSearchTimeoutMs: 1500 });
  const result = await engine.bestMove(START, { moveTimeMs: 150 });
  assert.equal(result.uci, 'e2e4');
  assert.equal(result.depth, 12);
  assert.equal(result.score, 34);
  engine.dispose();
});

test('synchronous worker-construction errors do not poison future initialization attempts', async () => {
  let factoryCalls = 0;
  const engine = new LegacyUciEngine(() => {
    factoryCalls++;
    if (factoryCalls === 1) throw new Error('Worker asset cannot be created');
    return new FakeUciWorker();
  }, { initTimeoutMs: 500, defaultSearchTimeoutMs: 1500 });
  await assert.rejects(engine.ensureReady(), /Worker asset cannot be created/);
  const result = await engine.bestMove(START, { moveTimeMs: 150 });
  assert.equal(result.uci, 'e2e4');
  assert.equal(factoryCalls, 2);
  engine.dispose();
});


test('Stockfish 10 worker accepts wrapped and multiline output payloads', async () => {
  const worker = new FakeUciWorker();
  const engine = new LegacyUciEngine(() => worker);
  const ready = engine.ensureReady();
  worker.emit({ data: 'id name Stockfish 10\nuciok' });
  assert.ok(worker.lines.includes('isready'));
  worker.emit({ data: 'readyok' });
  await ready;
  assert.equal(engine.state, 'ready');
  engine.dispose();
});
