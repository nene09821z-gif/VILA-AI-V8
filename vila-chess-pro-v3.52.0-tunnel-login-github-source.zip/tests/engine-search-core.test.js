import test from 'node:test';
import assert from 'node:assert/strict';
import { searchBestMove } from '../src/engines/search-core.js';
import { evaluateLeelaStyle } from '../src/engines/leela-style.js';
import { evaluateTactical } from '../src/engines/tactical.js';
import { evaluateAggressive } from '../src/engines/aggressive.js';

// Small deterministic turn-tree validates the generic search kernel without
// requiring the npm dependency to be installed in this offline environment.
class FakeChess {
  constructor(nodes, start = 'root') { this.nodes = nodes; this.node = nodes[start]; this.stack = []; }
  fen() { return `${this.node.id} ${this.node.turn} - - 0 1`; }
  turn() { return this.node.turn; }
  board() { return []; }
  isDraw() { return false; }
  isCheck() { return Boolean(this.node.check); }
  moves() { return this.node.edges.map(edge => ({ ...edge, color: this.node.turn })); }
  move(move) {
    const edge = this.node.edges.find(item => item.from === move.from && item.to === move.to && (item.promotion || '') === (move.promotion || ''));
    if (!edge) throw new Error('illegal fake move');
    this.stack.push(this.node);
    this.node = this.nodes[edge.target];
    return edge;
  }
  undo() { this.node = this.stack.pop(); }
}

const quiet = (from, to, target) => ({ from, to, target, piece: 'p' });
const makeNodes = () => ({
  root: { id: 'root', turn: 'w', edges: [quiet('a2', 'a3', 'lineA'), quiet('b2', 'b3', 'lineB')] },
  lineA: { id: 'lineA', turn: 'b', edges: [quiet('a7', 'a6', 'goodForWhite'), quiet('b7', 'b6', 'alsoGood')] },
  lineB: { id: 'lineB', turn: 'b', edges: [quiet('c7', 'c6', 'badForWhite'), quiet('d7', 'd6', 'worseForWhite')] },
  goodForWhite: { id: 'goodForWhite', turn: 'w', edges: [quiet('h2', 'h3', 'dummy1')] },
  alsoGood: { id: 'alsoGood', turn: 'w', edges: [quiet('h2', 'h4', 'dummy2')] },
  badForWhite: { id: 'badForWhite', turn: 'w', edges: [quiet('g2', 'g3', 'dummy3')] },
  worseForWhite: { id: 'worseForWhite', turn: 'w', edges: [quiet('g2', 'g4', 'dummy4')] },
  // Place evaluation values at the true depth-3 horizon. The quiet edges keep
  // the synthetic horizon alive for quiescence without allowing extra captures.
  dummy1: { id: 'dummy1', turn: 'b', score: 5, edges: [quiet('h8', 'h7', 'leaf1')] },
  dummy2: { id: 'dummy2', turn: 'b', score: 2, edges: [quiet('h8', 'h6', 'leaf2')] },
  dummy3: { id: 'dummy3', turn: 'b', score: 0, edges: [quiet('g8', 'g7', 'leaf3')] },
  dummy4: { id: 'dummy4', turn: 'b', score: -3, edges: [quiet('g8', 'g6', 'leaf4')] },
  leaf1: { id: 'leaf1', turn: 'w', score: 0, edges: [] },
  leaf2: { id: 'leaf2', turn: 'w', score: 0, edges: [] },
  leaf3: { id: 'leaf3', turn: 'w', score: 0, edges: [] },
  leaf4: { id: 'leaf4', turn: 'w', score: 0, edges: [] }
});

test('iterative alpha-beta selects the move with the best minimax result', () => {
  const chess = new FakeChess(makeNodes());
  const result = searchBestMove(chess, { style: 'balanced', defaultDepth: 3, maxNodes: 5000, maxTimeMs: 1000, lateMoveReduction: true }, game => game.node.score || 0, { depth: 3, maxNodes: 5000, maxTimeMs: 1000, random: () => 0.999 });
  assert.equal(result.uci, 'a2a3');
  assert.equal(result.depth, 3);
  assert.ok(result.nodes > 0);
  assert.equal(chess.fen(), 'root w - - 0 1', 'search must undo every temporary move');
});


test('positional, tactical, and aggressive evaluators are separate and return finite scores', () => {
  const board = Array.from({ length: 8 }, () => Array(8).fill(null));
  const put = (row, col, type, color) => { board[row][col] = { type, color }; };
  put(7, 4, 'k', 'w'); put(0, 4, 'k', 'b');
  put(4, 4, 'q', 'w'); put(2, 5, 'r', 'b');
  put(3, 3, 'n', 'w'); put(2, 4, 'p', 'b');
  put(6, 2, 'b', 'w'); put(6, 5, 'b', 'w');
  put(5, 1, 'p', 'w'); put(1, 6, 'p', 'b');
  const position = { board: () => board };
  const scores = [evaluateLeelaStyle(position), evaluateTactical(position), evaluateAggressive(position)];
  assert.ok(scores.every(Number.isFinite));
  assert.ok(new Set(scores).size > 1, 'distinct engines should not be the same evaluator');
});
