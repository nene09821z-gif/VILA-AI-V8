import test from 'node:test';
import assert from 'node:assert/strict';
import {
  sealLocalGameRecoverySnapshot, validateLocalGameRecoverySnapshot
} from '../src/game-recovery.js';

function snapshot(overrides = {}) {
  return {
    savedAt: 10_000, gameId: 'game-1', mode: 'stockfish', fen: 'fen-now',
    moves: [{ from: 'e2', to: 'e4' }], startFen: 'fen-start', orientation: 'w',
    humanColor: 'w', gameStarted: true, clockHistory: [],
    clockState: { enabled: true, remaining: { w: 300_000, b: 300_000 }, incrementMs: 2000 },
    result: null, ...overrides
  };
}

test('recovery envelope is checksummed and accepts an intact current snapshot', () => {
  const sealed = sealLocalGameRecoverySnapshot(snapshot());
  assert.equal(sealed.version, 3);
  assert.match(sealed.checksum, /^[a-f0-9]{8}$/);
  assert.deepEqual(validateLocalGameRecoverySnapshot(sealed, 10_500), { ok: true, legacy: false });
});

test('recovery refuses corrupted payloads before replaying a move', () => {
  const sealed = sealLocalGameRecoverySnapshot(snapshot());
  sealed.moves[0].to = 'e5';
  assert.equal(validateLocalGameRecoverySnapshot(sealed, 10_500).reason, 'checksum-mismatch');
});

test('recovery validates time bounds, allowed modes, move shape and clock bounds', () => {
  const now = 10_000;
  assert.equal(validateLocalGameRecoverySnapshot(sealLocalGameRecoverySnapshot(snapshot({ savedAt: now + 120_000 })), now).reason, 'timestamp-in-future');
  assert.equal(validateLocalGameRecoverySnapshot(sealLocalGameRecoverySnapshot(snapshot({ mode: 'lichess' })), now).reason, 'unsupported-mode');
  assert.equal(validateLocalGameRecoverySnapshot(sealLocalGameRecoverySnapshot(snapshot({ moves: [{ from: 'e2', to: 'e9' }] })), now).reason, 'invalid-move');
  assert.equal(validateLocalGameRecoverySnapshot(sealLocalGameRecoverySnapshot(snapshot({ clockState: { remaining: { w: -1, b: 100 } } })), now).reason, 'invalid-clock-time');
});

test('expired and completed snapshots are rejected; valid legacy version-2 snapshots remain migratable', () => {
  const now = 10_000_000_000;
  assert.equal(validateLocalGameRecoverySnapshot(sealLocalGameRecoverySnapshot(snapshot({ savedAt: now - 8 * 24 * 60 * 60 * 1000 })), now).reason, 'snapshot-expired');
  assert.equal(validateLocalGameRecoverySnapshot(sealLocalGameRecoverySnapshot(snapshot({ result: '1-0' })), now).reason, 'game-not-active');
  const legacy = snapshot({ savedAt: now, version: 2 });
  assert.deepEqual(validateLocalGameRecoverySnapshot(legacy, now), { ok: true, legacy: true });
});
