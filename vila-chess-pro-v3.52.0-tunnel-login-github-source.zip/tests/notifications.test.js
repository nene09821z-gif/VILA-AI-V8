import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addNotification, clearReadNotifications, markAllNotificationsRead,
  markNotificationRead, normalizeNotifications, unreadNotificationCount
} from '../src/notifications.js';

test('notification inbox normalizes invalid data and counts unread items', () => {
  const items = normalizeNotifications([{ id: 'a', title: 'Hello', message: 'World' }, null, { id: 'a', title: 'dup', message: 'dup' }, { id: 'bad' }]);
  assert.equal(items.length, 1);
  assert.equal(unreadNotificationCount(items), 1);
  assert.equal(markNotificationRead(items, 'a')[0].read, true);
});

test('notifications deduplicate by source key and can be cleared after reading', () => {
  const first = addNotification([], { id: 'n1', title: 'Lời mời', message: '@alice muốn kết bạn', sourceKey: 'friend:req-1' }, new Date('2026-01-01T00:00:00Z'));
  assert.equal(first.added, true);
  const duplicate = addNotification(first.items, { title: 'Lặp lại', message: 'Không tạo lần hai', sourceKey: 'friend:req-1' });
  assert.equal(duplicate.added, false);
  assert.equal(duplicate.items.length, 1);
  assert.equal(unreadNotificationCount(markAllNotificationsRead(first.items)), 0);
  assert.equal(clearReadNotifications(markAllNotificationsRead(first.items)).length, 0);
});

test('notification history stays capped at 100 and sanitizes control characters', () => {
  let items = [];
  for (let i = 0; i < 105; i++) items = addNotification(items, { id: `n${i}`, title: `Title ${i}`, message: `line\n${i}` }).items;
  assert.equal(items.length, 100);
  assert.equal(items[0].id, 'n5');
  assert.equal(items[99].message.includes('\n'), false);
});
