import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateBoardFrameMaxWidth, calculateChessSquareSize } from '../src/board-layout.js';

test('board fits available content width on 360 CSS-pixel Android screens', () => {
  assert.equal(calculateBoardFrameMaxWidth({ containerWidth: 344, viewportWidth: 360, viewportHeight: 800 }), 344);
  assert.equal(calculateChessSquareSize(336), 42);
});

test('short landscape viewport caps board to actual height budget', () => {
  assert.equal(calculateBoardFrameMaxWidth({ containerWidth: 410, viewportWidth: 800, viewportHeight: 360 }), 206);
  assert.equal(calculateBoardFrameMaxWidth({ containerWidth: 190, viewportWidth: 800, viewportHeight: 360 }), 190);
  assert.equal(calculateBoardFrameMaxWidth({ containerWidth: 340, viewportWidth: 800, viewportHeight: 200 }), 46);
});

test('desktop sizing uses available column width and does not apply phone DPI scaling', () => {
  assert.equal(calculateBoardFrameMaxWidth({ containerWidth: 620, viewportWidth: 1440, viewportHeight: 900 }), 620);
  assert.equal(calculateChessSquareSize(640), 80);
});

test('invalid measurements fail safely rather than producing NaN CSS', () => {
  assert.equal(calculateBoardFrameMaxWidth({ containerWidth: NaN, viewportWidth: 0, viewportHeight: 0 }), 0);
  assert.equal(calculateChessSquareSize(NaN), 0);
});
