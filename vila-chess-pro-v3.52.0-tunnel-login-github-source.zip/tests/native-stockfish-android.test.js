import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('Android uses packaged native ARM64 Stockfish through the UCI bridge with a browser fallback', () => {
  const kotlin = read('app/src/main/java/com/example/MainActivity.kt');
  const main = read('src/main.js');
  const gradle = read('app/build.gradle.kts');
  assert.match(kotlin, /fun nativeStockfishAvailable\(\): Boolean/);
  assert.match(kotlin, /fun startNativeStockfish\(\): Boolean/);
  assert.match(kotlin, /fun sendStockfishCommand\(command: String\): Boolean/);
  assert.match(kotlin, /fun stopNativeStockfish\(\)/);
  assert.match(kotlin, /libstockfish\.so/);
  assert.match(kotlin, /vila-native-stockfish-message/);
  assert.match(main, /function createNativeStockfishWorker\(\)/);
  assert.match(main, /bridge\.sendStockfishCommand\(String\(message\)\)/);
  assert.match(main, /nativePreference = \['auto', 'full-single'\]\.includes\(settings\.botEngine \|\| 'auto'\)/);
  assert.match(main, /createNativeStockfishWorker\(\).*new Worker\(enginePath\)/);
  assert.match(gradle, /useLegacyPackaging = true/);
  assert.match(gradle, /keepDebugSymbols \+= setOf\("\*\*\/libstockfish\.so"\)/);
  assert.match(gradle, /native Stockfish ARM64 is missing/i);
});

test('GitHub workflows fetch and verify native Stockfish at build time, not inside the source ZIP', () => {
  const fetcher = read('scripts/fetch-native-stockfish-android.sh');
  const packer = read('scripts/package-github-source.py');
  for (const name of ['build-android.yml', 'build-from-zip.yml']) {
    assert.match(read(`.github/workflows/${name}`), /fetch-native-stockfish-android\.sh/);
  }
  assert.match(fetcher, /official-stockfish\/Stockfish\/releases\/latest\/download\/stockfish-android-arm64-universal\.tar\.gz/);
  assert.match(fetcher, /readelf -h/);
  assert.match(fetcher, /STOCKFISH-COPYING\.txt/);
  assert.match(packer, /app\/src\/main\/jniLibs\/arm64-v8a\/libstockfish\.so/);
  assert.match(fetcher, /Machine:/);
  assert.match(fetcher, /AArch64/);
  const installer = read('scripts/install-native-stockfish-android.mjs');
  const verifier = read('scripts/verify-android-project.mjs');
  assert.match(installer, /NativeStockfishBridge/);
  assert.match(installer, /jniLibs/);
  assert.match(installer, /chmodSync\(path\.join\(nativeLibDir, 'libstockfish\.so'\), 0o755\)/);
  assert.match(verifier, /Generated Capacitor app is missing the native Stockfish ARM64 executable/);
  assert.match(verifier, /Android Gradle packaging is not configured to extract the native executable/);
  for (const name of ['build-android.yml', 'build-from-zip.yml']) {
    const workflow = read(`.github/workflows/${name}`);
    assert.match(workflow, /npx cap sync android\s+node scripts\/install-native-stockfish-android\.mjs android/);
  }
});
