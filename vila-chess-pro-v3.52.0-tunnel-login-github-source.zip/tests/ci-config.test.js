import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const exists = file => fs.existsSync(new URL(`../${file}`, import.meta.url));
const pkg = JSON.parse(read('package.json'));

test('workflows do not request npm caching without a lockfile (setup-node aborts otherwise)', () => {
  const hasLock = exists('package-lock.json') || exists('npm-shrinkwrap.json');
  assert.match(read('.github/workflows/build-android.yml'), /pull_request:/);
  assert.match(read('.github/workflows/build-from-zip.yml'), /workflow_dispatch:/);
  assert.doesNotMatch(read('.github/workflows/build-from-zip.yml'), /branches: \[main, master\]/);
  for (const file of ['.github/workflows/build-android.yml', '.github/workflows/build-from-zip.yml']) {
    if (!hasLock) assert.doesNotMatch(read(file), /cache:\s*npm/, `${file} uses cache: npm but the repository has no lockfile`);
  }
});

test('manual ZIP workflow expands the latest GitHub-friendly source ZIP before npm install', () => {
  const workflow = read('.github/workflows/build-from-zip.yml');
  assert.match(workflow, /vila-chess-pro-\*-github-source\.zip/);
  assert.match(workflow, /zf\.testzip\(\)/);
  assert.match(workflow, /Source archive did not contain package\.json/);
  assert.ok(workflow.indexOf('Expand the uploaded GitHub-friendly source ZIP') < workflow.indexOf('Install Node dependencies'));
});

test('the two Android workflows use different concurrency groups', () => {
  const group = file => read(file).match(/group:\s*(.+)/)?.[1].trim();
  assert.notEqual(group('.github/workflows/build-android.yml'), group('.github/workflows/build-from-zip.yml'));
});

test('Dockerfile installs without running postinstall before scripts/ is copied', () => {
  const docker = read('Dockerfile');
  assert.match(docker, /npm install --ignore-scripts/);
  assert.ok(docker.indexOf('npm install') < docker.indexOf('COPY . .'));
  assert.match(pkg.scripts.build, /copy-engine\.mjs --required/, 'the build step must still bundle Stockfish');
});

test('Capacitor core is a declared dependency (needed by cap add / cap sync)', () => {
  assert.ok(pkg.devDependencies['@capacitor/core'] || pkg.dependencies['@capacitor/core']);
});

test('transposition-table key ignores the halfmove clock and move number', () => {
  assert.match(read('src/engines/search-core.js'), /chess\.fen\(\)\.split\(' '\)\.slice\(0, 4\)/);
});

test('the push/PR workflow and manual full build both test and report failures', () => {
  assert.match(read('.github/workflows/build-android.yml'), /pull_request:/);
  assert.match(read('.github/workflows/build-from-zip.yml'), /workflow_dispatch:/);
  assert.doesNotMatch(read('.github/workflows/build-from-zip.yml'), /branches: \[main, master\]/);
  for (const file of ['.github/workflows/build-android.yml', '.github/workflows/build-from-zip.yml']) {
    const text = read(file);
    assert.match(text, /run:\s*npm test/, `${file} must run npm test`);
    assert.match(text, /id:\s*tests/);
    assert.match(text, /always\(\) && steps\.tests\.outcome == 'failure'/, `${file} must report failed tests even after the test step fails`);
    assert.doesNotMatch(text, /continue-on-error:\s*true/, `${file} must not ignore test failures before packaging`);
    assert.match(text, /APK build halted/, `${file} must label the failed build honestly`);
  }
});

test('Docker context excludes local secrets and bulky build products but keeps the example env file', () => {
  const ignore = read('.dockerignore');
  assert.match(ignore, /^node_modules$/m);
  assert.match(ignore, /^dist$/m);
  assert.match(ignore, /^\.env$/m);
  assert.match(ignore, /^\.env\.\*$/m);
  assert.match(ignore, /^!\.env\.example$/m);
  assert.match(read('Dockerfile'), /FROM node:22-alpine/);
  assert.match(read('Dockerfile'), /EXPOSE 8787/);
});
