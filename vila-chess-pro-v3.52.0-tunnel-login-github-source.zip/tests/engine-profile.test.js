import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveEngineProfile, describeEngineProfile, nextEngineFallback, engineAssetFile } from '../src/engine-profile.js';

test('auto engine stays Lite on unknown, low-memory or low-core devices', () => {
  assert.equal(resolveEngineProfile('auto', {}), 'lite-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 1, hardwareConcurrency: 8 }), 'lite-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 2 }), 'lite-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 8, fullEngineAvailable: false }), 'lite-single');
});

test('auto engine selects stronger Full NNUE on suitable hardware when included', () => {
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 2, hardwareConcurrency: 4 }), 'full-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 4, hardwareConcurrency: 4 }), 'full-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 6, hardwareConcurrency: 6 }), 'full-single');
  assert.equal(resolveEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 8 }), 'full-single');
});

test('manual Lite/Full selection is honored and engine filenames are deterministic', () => {
  assert.equal(resolveEngineProfile('full-single', { deviceMemory: 2 }), 'full-single');
  assert.equal(resolveEngineProfile('lite-single', { deviceMemory: 12 }), 'lite-single');
  assert.equal(engineAssetFile('full-single'), 'stockfish-19-single.js');
  assert.equal(engineAssetFile('lite-single'), 'stockfish-19-lite-single.js');
  assert.equal(engineAssetFile('asm'), 'stockfish-19-asm.js');
});

test('initialization fallback is Full → Lite → ASM-JS and then stops', () => {
  assert.equal(nextEngineFallback('full-single'), 'lite-single');
  assert.equal(nextEngineFallback('lite-single'), 'asm');
  assert.equal(nextEngineFallback('asm'), null);
  assert.equal(nextEngineFallback('unknown'), null);
});

test('profile description reflects the selected auto engine', () => {
  assert.equal(describeEngineProfile('auto', { deviceMemory: 8, hardwareConcurrency: 8 }), 'Full NNUE (tự động)');
  assert.equal(describeEngineProfile('auto', {}), 'Lite (tự động)');
});
