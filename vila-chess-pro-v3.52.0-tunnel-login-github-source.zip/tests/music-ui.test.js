import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const index = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const sound = fs.readFileSync(new URL('../src/sound.js', import.meta.url), 'utf8');
const lib = fs.readFileSync(new URL('../src/music-library.js', import.meta.url), 'utf8');
const yt = fs.readFileSync(new URL('../src/youtube-music.js', import.meta.url), 'utf8');

test('Music is online-only: curated TikTok remix / sad-song library, no offline synth', () => {
  assert.match(index, /id="appMusicToggle"/);
  assert.match(main, /id="toggleChessMusic"/);
  assert.match(main, /data-music-track=/);
  assert.match(main, /musicLibraryMarkup\(\{ compact: true \}\)/);
  assert.doesNotMatch(sound, /Gymnopedie_No\._1|CLASSICAL_MUSIC_URL|musicAudio|startSynthMusic|MUSIC_TRACKS|createOscillator\(\);[\s\S]*musicTimer/);
  assert.ok((lib.match(/videoId:|listId:/g) || []).length >= 10);
  assert.match(lib, /TikTok/);
  assert.match(lib, /Slowed|slowed/);
});

test('Music starts on app open, skips blocked videos and exposes player controls', () => {
  assert.match(main, /MUSIC_AUTOSTART_KEY\) !== 'false'/);
  assert.match(main, /window\.AndroidBridge \|\| navigator\.userActivation\?\.hasBeenActive/);
  assert.match(main, /document\.addEventListener\('click', handleMusicAutostartGesture/);
  assert.match(sound, /stepChessMusicTrack\(1, \{ keepSkips: true \}\)/);
  for (const id of ['vilaYtPrev', 'vilaYtPause', 'vilaYtNext', 'vilaYtClose']) assert.ok(yt.includes(id), id);
  assert.match(yt, /vars\.origin/);
});
