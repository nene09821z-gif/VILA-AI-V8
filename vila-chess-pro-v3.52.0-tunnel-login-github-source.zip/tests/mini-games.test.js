import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createSolvedRubikCube, applyRubikMove, getRubikFaceStickers, isRubikSolved,
  invertRubikMove, scrambleRubikMoves, create2048Board, move2048, has2048Moves,
  createScrambledSlidingPuzzle, moveSlidingPuzzleTile, isSlidingPuzzleSolved,
} from '../src/mini-games.js';

function seededRandom(seed = 123456) {
  let state = seed >>> 0;
  return () => { state = (state * 1664525 + 1013904223) >>> 0; return state / 0x100000000; };
}

test('Rubik solved cube has 54 visible stickers and six uniform faces', () => {
  const cube = createSolvedRubikCube();
  assert.equal(cube.length, 54);
  assert.equal(isRubikSolved(cube), true);
  for (const face of ['U', 'D', 'F', 'B', 'R', 'L']) {
    const facelets = getRubikFaceStickers(cube, face);
    assert.equal(facelets.length, 9);
    assert.equal(new Set(facelets).size, 1);
  }
});

test('all Rubik face turns invert and four quarter-turns restore solved state', () => {
  for (const face of ['U', 'D', 'F', 'B', 'R', 'L']) {
    const cube = createSolvedRubikCube();
    assert.equal(isRubikSolved(applyRubikMove(applyRubikMove(cube, face), invertRubikMove(face))), true, face);
    let fourTurns = cube;
    for (let i = 0; i < 4; i++) fourTurns = applyRubikMove(fourTurns, face);
    assert.equal(isRubikSolved(fourTurns), true, face);
    assert.equal(isRubikSolved(applyRubikMove(applyRubikMove(cube, `${face}2`), `${face}2`)), true, `${face}2`);
  }
});

test('Rubik scramble generation is bounded, legal, and reproducible', () => {
  const a = scrambleRubikMoves(25, seededRandom(17));
  const b = scrambleRubikMoves(25, seededRandom(17));
  assert.equal(a.length, 25);
  assert.deepEqual(a, b);
  assert.ok(a.every(move => /^[UDFBRL]['2]?$/.test(move)));
  const axis = face => 'UD'.includes(face) ? 'y' : 'FB'.includes(face) ? 'z' : 'x';
  assert.ok(a.every((move, index) => index === 0 || axis(move[0]) !== axis(a[index - 1][0])));
  let cube = createSolvedRubikCube();
  for (const move of a) cube = applyRubikMove(cube, move);
  assert.equal(isRubikSolved(cube), false);
});

test('2048 merges equal tiles once and reports score', () => {
  const board = [2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  const result = move2048(board, 'left', () => 0.99);
  assert.deepEqual(result.board.slice(0, 4), [4, 4, 0, 0]);
  assert.equal(result.score, 8);
  assert.equal(result.changed, true);
});

test('2048 movement supports vertical direction and avoids spawning on unchanged moves', () => {
  const board = [2, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0];
  const result = move2048(board, 'up', () => 0.999);
  assert.deepEqual([result.board[0], result.board[4], result.board[8], result.board[12]], [4, 4, 0, 0]);
  assert.equal(result.score, 4);
  const fixed = Array(16).fill(0); fixed[0] = 2;
  const unchanged = move2048(fixed, 'left', () => 0);
  assert.equal(unchanged.changed, false);
  assert.equal(unchanged.board.reduce((sum, n) => sum + n, 0), 2);
});

test('2048 game-over detection distinguishes full immobile and movable boards', () => {
  assert.equal(has2048Moves([2, 4, 2, 4, 4, 2, 4, 2, 2, 4, 2, 4, 4, 2, 4, 2]), false);
  assert.equal(has2048Moves([2, 2, 4, 8, ...Array(12).fill(16)]), true);
  assert.equal(create2048Board(seededRandom()).filter(Boolean).length, 2);
});


function slidingInversionCount(board) {
  const values = board.filter(Boolean);
  let inversions = 0;
  for (let i = 0; i < values.length; i++) for (let j = i + 1; j < values.length; j++) if (values[i] > values[j]) inversions++;
  return inversions;
}

test('15-puzzle scramble uses legal moves and preserves solvability parity', () => {
  let seed = 123456;
  const seededRandom = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  for (const count of [1, 2, 25, 100, 250]) {
    const board = createScrambledSlidingPuzzle(count, seededRandom);
    assert.equal(board.length, 16);
    assert.equal(new Set(board).size, 16);
    assert.deepEqual([...board].sort((a, b) => a - b), Array.from({ length: 16 }, (_, index) => index));
    const blankRowFromBottom = 4 - Math.floor(board.indexOf(0) / 4);
    assert.equal((slidingInversionCount(board) + blankRowFromBottom) % 2, 1, 'board remains solvable');
    assert.equal(isSlidingPuzzleSolved(board), false);
  }
});

test('15-puzzle permits adjacent tile moves, rejects distant taps, and detects completion', () => {
  const solved = Array.from({ length: 16 }, (_, index) => index === 15 ? 0 : index + 1);
  assert.equal(isSlidingPuzzleSolved(solved), true);
  const legal = moveSlidingPuzzleTile(solved, 14);
  assert.equal(legal.changed, true);
  assert.equal(legal.solved, false);
  assert.equal(legal.board[15], 15);
  assert.equal(legal.board[14], 0);
  const reversed = moveSlidingPuzzleTile(legal.board, 15);
  assert.equal(reversed.changed, true);
  assert.equal(reversed.solved, true);
  const illegal = moveSlidingPuzzleTile(solved, 0);
  assert.equal(illegal.changed, false);
  assert.deepEqual(illegal.board, solved);
});
