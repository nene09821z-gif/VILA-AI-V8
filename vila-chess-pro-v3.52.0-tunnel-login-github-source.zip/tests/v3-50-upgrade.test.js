import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('v3.52.0 version, cache generation and Android fresh-build gate are aligned', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('app/build.gradle.kts');
  const html = read('index.html');
  const androidFallback = read('app/src/main/assets/index.html');
  const sw = read('public/sw.js');
  assert.equal(pkg.version, '3.52.0');
  assert.equal(lock.packages[''].version, pkg.version);
  assert.match(gradle, /versionCode = 8\s+versionName = "3\.52\.0"/);
  assert.match(html, /Atelier Chess v3\.52\.0/);
  assert.match(androidFallback, /Cờ Vua/);
  assert.match(androidFallback, /giao diện web chưa được build/i);
  assert.match(gradle, /stageBuiltWebAssetsForAndroid/);
  assert.match(sw, /covua-vila-v3\.52\.0/);
  assert.match(html, /favicon\.ico\?v=353/);
  assert.match(sw, /favicon\.ico\?v=353/);
});

test('a tap from a stale board cannot select on a newly restored or restarted position', () => {
  const main = read('src/main.js');
  const start = main.indexOf('const finish = async event => {', main.indexOf('function wireBoardPointerDrag'));
  const end = main.indexOf("board.addEventListener('contextmenu'", start);
  const finish = main.slice(start, end);
  const guard = finish.indexOf('isMoveContextCurrent(state, { epoch: gameEpoch, fen: game.fen() })');
  assert.ok(guard >= 0);
  assert.ok(guard < finish.indexOf('handleSquareClick(state.from)'));
  assert.ok(guard < finish.indexOf('const choices = to ? state.legal.filter'));
});

test('analysis tools stay docked in the mouse/menu panels and drawing remains opt-in', () => {
  const main = read('src/main.js');
  const css = read('src/vila-v4.css');
  assert.match(main, /function toggleAnnotationToolsDock\(location = 'mouse'\)/);
  assert.match(main, /target\.append\(widget\)/);
  assert.match(main, /if \(requested === 'move'\) annotationTool = null/);
  assert.match(css, /html body \.board-annotation-widget\.annotation-tool-docked\s*\{[^}]*position: relative !important/s);
  assert.match(css, /\.annotation-tools-dock\[hidden\]/);
  assert.match(css, /\.virtual-mouse-panel\.has-annotation-tools/);
});

test('mini-game logic and the local avatar remain offline-capable', () => {
  const puzzle = read('src/mini-games.js');
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  const avatar = read('public/vila-chess-avatar.svg');
  for (const token of ['move2048', 'createScrambledSlidingPuzzle', 'moveSlidingPuzzleTile', 'applyRubikMove']) assert.ok(puzzle.includes(token));
  assert.match(main, /vila-chess-avatar\.svg\?v=3500/);
  assert.match(sw, /vila-chess-avatar\.svg\?v=3500/);
  assert.match(avatar, /<title[^>]*>VILA Chess<\/title>/);
});
