import fs from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { isMoveContextCurrent } from '../src/move-input.js';

test('promotion prompt may only submit into the same active game epoch and position', () => {
  const request = { from: 'a7', to: 'a8', epoch: 12, fen: 'fen-before-promotion' };
  assert.equal(isMoveContextCurrent(request, { epoch: 12, fen: 'fen-before-promotion' }), true);
  assert.equal(isMoveContextCurrent(request, { epoch: 13, fen: 'fen-before-promotion' }), false, 'starting another game invalidates the old prompt even if the position matches');
  assert.equal(isMoveContextCurrent(request, { epoch: 12, fen: 'fen-after-move' }), false, 'a changed position invalidates the old prompt');
});

test('move-context validation fails closed for malformed or incomplete state', () => {
  assert.equal(isMoveContextCurrent(null, { epoch: 1, fen: 'fen' }), false);
  assert.equal(isMoveContextCurrent({ epoch: '1', fen: 'fen' }, { epoch: 1, fen: 'fen' }), false);
  assert.equal(isMoveContextCurrent({ epoch: 1, fen: null }, { epoch: 1, fen: null }), false);
  assert.equal(isMoveContextCurrent({ epoch: 1, fen: 'fen' }, null), false);
});


test('board promotion callback uses captured from/to and rejects a stale async context', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /const request = \{ from: selected, to: square, epoch: gameEpoch, fen: game\.fen\(\) \}/);
  assert.match(main, /isMoveContextCurrent\(request, \{ epoch: gameEpoch, fen: game\.fen\(\) \}\)/);
  assert.match(main, /playMove\(request\.from, request\.to, type\)/);
  assert.doesNotMatch(main, /choosePromotion\(game\.turn\(\)\)\.then\(type => type && playMove\(selected, square, type\)\)/);
});


test('board pointer release rejects stale contexts before either tap selection or dragged move', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  const start = main.indexOf('const finish = async event => {', main.indexOf('function wireBoardPointerDrag'));
  const end = main.indexOf("board.addEventListener('contextmenu'", start);
  assert.ok(start >= 0 && end > start, 'board pointer finish handler must exist');
  const finish = main.slice(start, end);
  const staleGuard = finish.indexOf('isMoveContextCurrent(state, { epoch: gameEpoch, fen: game.fen() })');
  const tapHandler = finish.indexOf('handleSquareClick(state.from)');
  const dragHandler = finish.indexOf('const choices = to ? state.legal.filter');
  assert.ok(staleGuard >= 0 && staleGuard < tapHandler && staleGuard < dragHandler,
    'stale releases must be discarded before tap selection or applying a dragged move');
  assert.match(finish.slice(staleGuard, tapHandler), /suppressSquareClick = null/);
});
