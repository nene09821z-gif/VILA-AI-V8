import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');

test('offline alternative engines are in-app and do not call a backend for chess moves', () => {
  const main = read('src/main.js');
  const engine = read('src/alternate-engine.js');
  assert.match(main, /function askEngineHubMove\(\)/);
  assert.match(main, /const budget = resolveOfflineSearchBudget\(profile, settings\)/);
  assert.match(main, /chooseAlternateMoveAsync\(fen, \{ \.\.\.budget, seen: repetitionContext\(game\) \}\)/);
  assert.doesNotMatch(main.slice(main.indexOf('function askEngineHubMove'), main.indexOf('function askStockfishMove')), /apiFetch\('\/api\/engines\/analyze'/);
  assert.match(main, /AI đa phong cách — offline, không cần backend/);
  assert.match(main, /không phải binary gốc của Lc0\/Ethereal\/Berserk|không phải các engine thương hiệu bên ngoài/);
  const coreEngine = read('src/alternate-engine-core.js');
  assert.match(coreEngine, /export const ALTERNATE_ENGINE_PROFILES/);
  assert.match(coreEngine, /searchBestMove\(chess, profile, evaluators\[key\], options\)/);
  for (const path of ['src/engines/leela-style.js', 'src/engines/tactical.js', 'src/engines/aggressive.js']) {
    assert.ok(fs.existsSync(path.replace(/^/, root + '/')));
  }
  assert.match(main, /module worker so the board stays responsive/);
  assert.ok(fs.existsSync(path.join(root, 'src/alternate-engine-worker.js')));
  const core = read('src/engines/search-core.js');
  for (const feature of ['quiescence', 'negamax', 'historyHeuristic', 'table', 'completedDepth']) assert.ok(core.includes(feature), `search core should include ${feature}`);
});


test('six additional local training profiles are available and use bounded search budgets', () => {
  const core = read('src/alternate-engine-core.js');
  const personas = read('src/bot-personas.js');
  for (const id of ['mentor', 'hunter', 'sentinel', 'strategist', 'longgame', 'chaos']) {
    assert.match(core, new RegExp(`${id}: Object\.freeze`), `missing search profile ${id}`);
    assert.match(core, new RegExp(`id: '${id}', label:`), `missing selectable profile ${id}`);
    assert.match(personas, new RegExp(`${id}\\s*:`), `missing opening repertoire ${id}`);
  }
  assert.match(read('src/main.js'), /id="gameBotProfile"/);
});

test('offline engine retires a timed-out worker and settles queued requests', () => {
  const engine = read('src/alternate-engine.js');
  assert.match(engine, /function retireOfflineWorker\(worker\)/);
  assert.match(engine, /worker\?\.terminate\(\)/);
  assert.match(engine, /if \(offlineWorker === worker\) offlineWorker = null/);
  assert.match(engine, /for \(const \[id, pending\] of offlineRequests\)/);
  assert.match(engine, /resolveOfflineFallback\(pending\)/);
  assert.match(engine, /if \(!offlineRequests\.has\(id\)\) return;[\s\S]*?retireOfflineWorker\(worker\)/);
});
