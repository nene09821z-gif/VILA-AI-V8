import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { OPENINGS } from '../src/openings.js';

test('starting position has 20 legal moves', () => {
  const game = new Chess();
  assert.equal(game.moves().length, 20);
});

test('rejects illegal move', () => {
  const game = new Chess();
  assert.throws(() => game.move('e5'));
});

test('supports kingside castling', () => {
  const game = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
  game.move('O-O');
  assert.equal(game.get('g1')?.type, 'k');
  assert.equal(game.get('f1')?.type, 'r');
});

test('supports en passant capture', () => {
  const game = new Chess();
  for (const san of ['e4', 'a6', 'e5', 'd5', 'exd6']) game.move(san);
  assert.equal(game.get('d6')?.type, 'p');
  // chess.js 1.4.0 returns undefined for an empty square (not null).
  assert.equal(game.get('d5'), undefined);
});

test('supports pawn promotion', () => {
  const game = new Chess('7k/P7/8/8/8/8/8/7K w - - 0 1');
  game.move({ from: 'a7', to: 'a8', promotion: 'q' });
  assert.equal(game.get('a8')?.type, 'q');
});

test('detects checkmate', () => {
  const game = new Chess();
  for (const san of ['f3', 'e5', 'g4', 'Qh4#']) game.move(san);
  assert.equal(game.isCheckmate(), true);
});


test('detects stalemate without check', () => {
  const game = new Chess('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1');
  assert.equal(game.isStalemate(), true);
  assert.equal(game.isCheck(), false);
  assert.equal(game.isDraw(), true);
});

test('exported PGN contains the legal move history', () => {
  const game = new Chess();
  game.move('e4');
  game.move('e5');
  assert.match(game.pgn(), /1\. e4 e5/);
});


test('all 81 curated opening lines are legal and internally consistent', () => {
  assert.ok(OPENINGS.length >= 80, `The opening library should contain at least 80 curated lines (found ${OPENINGS.length}).`);
  const seen = new Set();
  for (const opening of OPENINGS) {
    assert.ok(opening.name && opening.eco && opening.family && opening.note, `Missing opening metadata: ${opening.name || '(unnamed)'}`);
    assert.ok(Array.isArray(opening.san) && opening.san.length > 0, `Missing SAN sequence: ${opening.name}`);
    assert.ok(!seen.has(opening.name), `Duplicate opening name: ${opening.name}`);
    seen.add(opening.name);
    const game = new Chess();
    for (let ply = 0; ply < opening.san.length; ply++) {
      try { game.move(opening.san[ply]); }
      catch (error) { throw new Error(`${opening.name}, half-move ${ply + 1} (${opening.san[ply]}): ${error.message}`); }
    }
    assert.equal(game.history().length, opening.san.length, `Move count mismatch: ${opening.name}`);
    assert.match(opening.line, /^1\./, `Opening display line should start with move 1: ${opening.name}`);
  }
});
