import test from 'node:test';
import assert from 'node:assert/strict';
import { OPENINGS } from '../src/openings.js';
import { recognizeOpening } from '../src/opening-recognition.js';

test('opening recognition waits for minimum plies and matches actual SAN history', () => {
  assert.equal(recognizeOpening(['e4', 'e5', 'Nf3'], OPENINGS, { minPlies: 4 }), null);
  assert.equal(recognizeOpening(['e4', 'e5', 'Nf3', 'Nc6'], OPENINGS, { minPlies: 5 }), null);
  assert.equal(recognizeOpening(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'], OPENINGS, { minPlies: 5 })?.name, 'Khai cuộc Ý');
});

test('opening recognition returns null for a divergent start and safely clamps the threshold', () => {
  assert.equal(recognizeOpening(['a3', 'h5', 'Ra2', 'g5'], OPENINGS, { minPlies: 4 }), null);
  assert.equal(recognizeOpening(['e4'], OPENINGS, { minPlies: 0 }), null);
});


test('opening recognition refreshes its prefix trie when more ECO lines are appended', () => {
  const catalog = [{ name: 'Seed line', san: ['e4', 'e5'] }];
  assert.equal(recognizeOpening(['a3', 'a6', 'h3'], catalog, { minPlies: 3 }), null);
  catalog.push({ name: 'New catalog line', san: ['a3', 'a6', 'h3'] });
  assert.equal(recognizeOpening(['a3', 'a6', 'h3'], catalog, { minPlies: 3 })?.name, 'New catalog line');
});
