import test from 'node:test';
import assert from 'node:assert/strict';
import { chooseTicTacToeMove, ticTacToeOutcome } from '../src/tic-tac-toe.js';

test('tic tac toe recognizes wins, draw, and unfinished states', () => {
  assert.equal(ticTacToeOutcome(['X','X','X','O','','O','','','']), 'X');
  assert.equal(ticTacToeOutcome(['X','O','X','X','O','O','O','X','X']), 'draw');
  assert.equal(ticTacToeOutcome(['X','','','','O','','','','']), null);
});

test('bot takes an immediate winning move', () => {
  const board = ['O','O','','X','X','','','',''];
  assert.equal(chooseTicTacToeMove(board), 2);
  assert.equal(board[2], '', 'move selection does not mutate caller state');
});

test('bot blocks an immediate human win', () => {
  assert.equal(chooseTicTacToeMove(['X','X','','O','','','','','']), 2);
});

test('bot never picks an occupied square and returns -1 for finished boards', () => {
  const move = chooseTicTacToeMove(['X','','','','O','','','','X']);
  assert.ok(move >= 0 && move < 9);
  assert.equal(['X','','','','O','','','','X'][move], '');
  assert.equal(chooseTicTacToeMove(['X','X','X','O','O','','','','']), -1);
});
