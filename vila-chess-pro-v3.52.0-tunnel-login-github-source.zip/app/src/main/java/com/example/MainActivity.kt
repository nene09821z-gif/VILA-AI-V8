package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
          color = Color(0xFF0F172A)
        ) {
          ChessAppScreen()
        }
      }
    }
  }
}

class AndroidChessBridge(private val context: Context, private val webView: WebView) {
  private val stockfishLock = Any()
  @Volatile private var stockfishProcess: Process? = null
  @Volatile private var stockfishWriter: BufferedWriter? = null

  /** Native Stockfish is packaged as an ARM64 executable under jniLibs and extracted by Android. */
  @JavascriptInterface
  fun nativeStockfishAvailable(): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false // The official Android universal binary requires Android 10+.
    if (Build.SUPPORTED_ABIS.none { it == "arm64-v8a" }) return false
    return File(context.applicationInfo.nativeLibraryDir, "libstockfish.so").isFile
  }

  @JavascriptInterface
  fun startNativeStockfish(): Boolean {
    if (!nativeStockfishAvailable()) return false
    synchronized(stockfishLock) {
      val current = stockfishProcess
      if (current != null && current.isAlive) return true
      val executable = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
      return try {
        val process = ProcessBuilder(executable.absolutePath)
          .directory(context.filesDir)
          .redirectErrorStream(true)
          .start()
        stockfishProcess = process
        stockfishWriter = BufferedWriter(OutputStreamWriter(process.outputStream, Charsets.UTF_8))
        Thread({
          try {
            BufferedReader(InputStreamReader(process.inputStream, Charsets.UTF_8)).useLines { lines ->
              lines.forEach { line ->
                if (stockfishProcess === process) dispatchStockfishLine(line)
              }
            }
          } catch (error: Exception) {
            if (stockfishProcess === process) {
              Log.w("VILA-Stockfish", "Failed to read native engine output", error)
              dispatchStockfishLine("info string native engine output read error")
            }
          } finally {
            synchronized(stockfishLock) {
              if (stockfishProcess === process) {
                stockfishProcess = null
                stockfishWriter = null
              }
            }
          }
        }, "VILA-Stockfish-UCI").apply {
          isDaemon = true
          start()
        }
        true
      } catch (error: Exception) {
        stockfishProcess = null
        stockfishWriter = null
        Log.e("VILA-Stockfish", "Could not start native Stockfish; JS/WASM fallback will be used", error)
        false
      }
    }
  }

  @JavascriptInterface
  fun sendStockfishCommand(command: String): Boolean {
    if (command.length > 8192 || command.contains('\n') || command.contains('\r')) return false
    synchronized(stockfishLock) {
      val process = stockfishProcess ?: return false
      if (!process.isAlive) return false
      return try {
        val writer = stockfishWriter ?: return false
        writer.write(command)
        writer.newLine()
        writer.flush()
        true
      } catch (error: Exception) {
        Log.w("VILA-Stockfish", "Could not send UCI command", error)
        false
      }
    }
  }

  @JavascriptInterface
  fun stopNativeStockfish() {
    val process: Process?
    synchronized(stockfishLock) {
      process = stockfishProcess
      try {
        stockfishWriter?.write("quit")
        stockfishWriter?.newLine()
        stockfishWriter?.flush()
      } catch (_: Exception) {}
      stockfishWriter = null
      stockfishProcess = null
    }
    try { process?.destroy() } catch (_: Exception) {}
  }

  private fun dispatchStockfishLine(line: String) {
    val safeLine = line.take(8192)
    val quoted = JSONObject.quote(safeLine)
    webView.post {
      webView.evaluateJavascript(
        "window.dispatchEvent(new CustomEvent('vila-native-stockfish-message',{detail:{line:$quoted}}));",
        null
      )
    }
  }

  @JavascriptInterface
  fun vibrate(durationMs: Long) {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        val vibrator = vibratorManager?.defaultVibrator
        vibrator?.vibrate(VibrationEffect.createOneShot(durationMs.coerceIn(10L, 500L), VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          vibrator?.vibrate(VibrationEffect.createOneShot(durationMs.coerceIn(10L, 500L), VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
          @Suppress("DEPRECATION")
          vibrator?.vibrate(durationMs.coerceIn(10L, 500L))
        }
      }
    } catch (_: Exception) {}
  }

  @JavascriptInterface
  fun getPlatform(): String {
    return "android-native"
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ChessAppScreen() {
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }

  BackHandler(enabled = true) {
    val wv = webViewInstance
    if (wv != null) {
      wv.evaluateJavascript(
        "(function() { if (typeof window.handleAppBack === 'function') { return window.handleAppBack(); } return false; })()"
      ) { result ->
        if (result == "false" || result == null) {
          if (wv.canGoBack()) {
            wv.goBack()
          }
        }
      }
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .systemBarsPadding()
      .background(Color(0xFF0F172A))
  ) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { ctx ->
        val assetLoader = WebViewAssetLoader.Builder()
          .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
          .build()

        WebView(ctx).apply {
          layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
          setBackgroundColor(android.graphics.Color.parseColor("#0F172A"))

          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
          }

          addJavascriptInterface(AndroidChessBridge(ctx, this), "AndroidBridge")

          webChromeClient = WebChromeClient()

          webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
              view: WebView?,
              request: WebResourceRequest?
            ): WebResourceResponse? {
              val url = request?.url ?: return null
              val response = assetLoader.shouldInterceptRequest(url)
              if (response != null) {
                val path = url.path.orEmpty()
                if (path.endsWith(".wasm")) {
                  response.mimeType = "application/wasm"
                } else if (path.endsWith(".js") || path.endsWith(".mjs")) {
                  response.mimeType = "application/javascript"
                } else if (path.endsWith(".json")) {
                  response.mimeType = "application/json"
                }
              }
              return response
            }
          }

          loadUrl("https://appassets.androidplatform.net/assets/index.html")
          webViewInstance = this
        }
      },
      update = { wv ->
        webViewInstance = wv
      }
    )
  }

  DisposableEffect(Unit) {
    onDispose {
      webViewInstance?.destroy()
      webViewInstance = null
    }
  }
}
