# Báo cáo kiểm thử VILA Chess v3.50.0

Ngày kiểm tra: 22/10/2026  
Phạm vi: mã nguồn ZIP, các bài test Node.js, tài nguyên engine offline và cấu hình GitHub Actions. **Không phải báo cáo kiểm thử APK trên thiết bị.**

## Thay đổi trong bản này

- Đồng bộ phiên bản phát hành `3.50.0` ở `package.json`, `package-lock.json`, trang web, API server, Service Worker và HTML dự phòng Android; tăng Android `versionCode` từ 5 lên 6.
- Đồng bộ cache generation của favicon/brand assets thành `v=353` và đồng bộ Service Worker Android dự phòng với `public/sw.js`.
- Sửa luồng thả chuột/ngón tay trên bàn cờ: nếu epoch ván hoặc FEN đã đổi trong khi con trỏ vẫn đang giữ, bỏ sự kiện cũ trước khi chọn ô hoặc gửi nước đi. Điều này ngăn một lần chạm từ ván cũ tác động lên ván vừa được tạo/khôi phục.
- Giữ bộ công cụ phân tích trong menu chuột ảo hoặc menu trận; test xác minh widget được dock, không nổi đè lên bàn cờ. Các công cụ gồm di chuyển, mũi tên, bút chì, đường chữ L quân Mã, khoanh ô và màu nét.
- Thêm `scripts/verify-engine-assets.mjs`: kiểm tra manifest, độ lớn file, header WebAssembly, fallback ASM-JS, Stockfish 10 và giấy phép; khi build release có biến `INCLUDE_STOCKFISH_FULL=1`, script yêu cầu cả hai tệp Full NNUE và metadata khai báo khớp.
- Thêm smoke test chạy Stockfish 19 Lite JS + WASM thật bằng UCI dưới Node.js: xác nhận `uciok`, `readyok`, tìm kiếm đến độ sâu 4 và một `bestmove` hợp lệ từ vị trí đầu.
- Giữ các mini-game và avatar VILA SVG trong đường dẫn offline; bổ sung test hồi quy cho chúng.

## Kết quả thực tế trong môi trường hiện tại

| Kiểm tra | Kết quả | Ghi chú |
|---|---:|---|
| Toàn bộ `node --test` | **319/325 đạt** | 6 tệp test không khởi chạy do không có dependency `chess.js`/`express` trong `node_modules`. Không có assertion thất bại sau khi đồng bộ metadata. |
| Bộ test mục tiêu kéo quân, công cụ vẽ, review, mini-game, branding, phiên bản và engine | **52/52 đạt** | Đã chạy riêng trong Node.js 22.16.0. |
| Cú pháp JavaScript/MJS | **152/152 tệp kiểm tra được** | Chạy `node --check` cho mọi tệp trong `src`, `server`, `scripts`, `tests`. |
| Stockfish 19 Lite offline runtime | **Đạt** | Engine thật trả `uciok`, `readyok`, `bestmove e2e3` từ `position startpos` với `go depth 4` ở lần chạy smoke test. Nước đi có thể khác giữa các môi trường; test xác minh tính hợp lệ thay vì cố định nước đi. |
| Engine manifest, Lite/ASM-JS, Stockfish 10 + giấy phép | **Đạt** | `node scripts/verify-engine-assets.mjs --release --skip-smoke` thành công. |
| Đồng bộ phiên bản Android và cache | **Đạt** | Test xác minh versionName `3.50.0`, versionCode `6`, cache `v3.50.0` và icon query `v=353`. |
| Build Vite / Capacitor / APK | **Chưa xác minh** | `npm ci` không hoàn tất vì DNS tới npm registry lỗi `EAI_AGAIN`; `vite` chưa được cài. Không có APK mới được tạo trong môi trường này. |
| Stockfish 19 Full NNUE | **Chưa xác minh cục bộ** | Full JS/WASM không nằm trong ZIP nguồn hiện tại. Hai workflow GitHub được cấu hình `INCLUDE_STOCKFISH_FULL=1`, yêu cầu file Full NNUE + manifest sau bước cài dependency và dừng build nếu thiếu. Cần xem log/artifact GitHub Actions để xác nhận tải thành công. |
| Android thật / OPPO A17k | **Chưa kiểm tra** | Không có thiết bị Android/WebView để đo độ trễ cảm ứng hoặc kiểm thử cài đặt ở đây. |

## Các bài test còn bị chặn bởi dependency

Các tệp này chưa thể vào phần kiểm thử logic do import không tìm thấy module:

- `tests/alternate-engine.test.js` — `chess.js`
- `tests/chess.test.js` — `chess.js`
- `tests/premove.test.js` — `chess.js`
- `tests/social.test.js` — `express`
- `tests/v3-25-features.test.js` — `chess.js`
- `tests/v3-48-features.test.js` — `chess.js`

Lỗi cài phụ thuộc xuất phát từ truy cập npm registry trong môi trường kiểm thử, không được xem là bằng chứng các tính năng tương ứng đang đúng hoặc sai. GitHub Actions cần chạy lại toàn bộ suite sau khi tải dependencies thành công.

## Chạy lại trên GitHub

1. Tải ZIP source và giải nén vào thư mục gốc repository.
2. Mở **Actions → Cờ Vua ViLa Android build** hoặc **Cờ Vua ViLa build from ZIP/source** và chạy workflow.
3. Xác nhận các bước cài dependencies, `npm test`, xác minh engine, Vite, Capacitor sync và `assembleDebug` đều xanh.
4. Chỉ gọi là build APK thành công sau khi artifact `covua-vila-debug-apk` xuất hiện và được tải/kiểm tra. Sau đó thử cài trên OPPO A17k để xác nhận kéo quân, menu chuột và tool vẽ không xung đột.
