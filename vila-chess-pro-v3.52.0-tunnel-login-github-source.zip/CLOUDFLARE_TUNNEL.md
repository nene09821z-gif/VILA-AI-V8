# Tài khoản VILA qua Cloudflare Tunnel

App mặc định kết nối tới `https://cosmetics-paris-believe-harvey.trycloudflare.com` (xem `DEFAULT_BACKEND_URL` trong `src/settings-schema.js`). Người dùng vẫn có thể đổi URL ở màn hình đăng nhập → “Thiết lập máy chủ…” hoặc Cài đặt → Máy chủ cộng đồng.

## Tài khoản

- Đăng ký chỉ cần **tên tài khoản** (3–24 ký tự: chữ, số, `.` `_` `-`, không phân biệt hoa/thường) và **mật khẩu** (≥ 8 ký tự).
- Tài khoản lưu trên **server** trong `data/social-store.json` (mật khẩu băm scrypt, file quyền `600`). Đăng nhập lại được trên máy khác.
- Phiên đăng nhập: token ký HMAC sống 30 ngày, tự gia hạn khi app mở sau hơn 7 ngày. App lưu token trên điện thoại, mất mạng không bị đăng xuất; chỉ khi server trả 401 (hết hạn/bị thu hồi) mới yêu cầu đăng nhập lại. “Đăng xuất” thu hồi mọi token của tài khoản.
- Quên mật khẩu bằng email chỉ dùng được với tài khoản có email và khi cấu hình `RESEND_API_KEY`; mặc định đã ẩn khỏi giao diện.

## Chạy server + tunnel

```sh
cp .env.example .env        # đặt SOCIAL_TOKEN_SECRET, TUBOR_ACCESS_TOKEN (>= 32 byte), ADMIN_* nếu cần
npm install --omit=dev
bash scripts/start-termux.sh   # hoặc: NODE_ENV=production node --env-file=.env server/index.js
cloudflared tunnel --url http://127.0.0.1:8787
```

Chạy lâu dài, tự restart và tự chạy khi mở máy: dùng `bash scripts/vila-run.sh` (xem mục “Chạy lâu dài” trong `TERMUX_SERVER.md`).

Kiểm tra: `curl https://<tunnel>/api/social/health` phải trả `{"ok":true,"service":"Cờ Vua ViLa social",...}`.

## Quan trọng: link `trycloudflare.com` là tạm thời

Quick Tunnel đổi địa chỉ **mỗi lần chạy lại `cloudflared`**. Khi link đổi, app đã cài sẽ báo “Không kết nối được máy chủ VILA”. Cách xử lý:

- Tạm thời: nhập link mới ở màn hình đăng nhập → “Thiết lập máy chủ…” (không mất tài khoản, vì dữ liệu nằm trên server).
- Lâu dài: dùng Named Tunnel với tên miền cố định (`cloudflared tunnel create`/`route dns`), rồi chạy `CF_TUNNEL_NAME=<tên tunnel> bash scripts/vila-run.sh`, sửa `DEFAULT_BACKEND_URL` một lần và build lại app.
