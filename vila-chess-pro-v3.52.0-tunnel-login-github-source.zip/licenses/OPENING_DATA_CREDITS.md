# Opening database attribution

The expanded ECO opening-name dataset is sourced from `lichess-org/chess-openings`:
https://github.com/lichess-org/chess-openings

The dataset README states that the collection of opening facts is in the public domain and, insofar as copyright may subsist in the curation, is released under the CC0 1.0 Universal Public Domain Dedication. The build script fetches this data from the repository and validates each sequence with `chess.js` before bundling it. If refresh fails, the app keeps its curated built-in opening sample.
