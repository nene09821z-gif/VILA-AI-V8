# ViLa Chess Pro v3.47.1 — Arena response-time patch

## Changes
- AI Arena defaults to Stockfish 19 Lite + ViLa Rookie instead of pairing the newer engine with legacy Stockfish 10.
- Legacy Stockfish 10 remains selectable manually for comparison and is visibly marked as older/slower.
- Arena Stockfish 10 search time is now bounded to 300–1,200 ms per move (previously up to 3,600 ms); standard human-vs-bot play caps active SF10 move time at 1,000 ms.
- Arena Stockfish 19 Lite search time is bounded to 700–1,500 ms per move (previously up to 2,600 ms).
- Default delay between arena moves is reduced from 350 ms to 150 ms.
- The prebuilt Android JavaScript bundle is patched to match these defaults and caps.
- Existing full-strength post-game analysis/review settings are not changed by these arena caps.
- Release and service-worker versions are updated to v3.47.1.

## Engine package notes
The project already includes Stockfish.js 19.0.1 Lite single-thread WASM and a Stockfish 19 ASM-JS fallback, alongside legacy Stockfish 10.0.2. This patch does not download another engine binary. The project manifest says the Full NNUE build is not bundled, so this patch does not claim Full NNUE is available.

## Tests
- Syntax checks: passed for source JS, bundled Android JS, service workers, server files, and the new focused test.
- Focused engine/Arena regression tests: 20/20 passed.
- Static suite (`npm run test:static`): 269/269 passed.
- Full `npm test`: 274/278 passed. Four test files could not initialize because dependencies are absent from the offline workspace: `alternate-engine.test.js` and `chess.test.js` and `v3-25-features.test.js` require `chess.js`; `social.test.js` requires `express`. These four did not reach their assertions.
- ZIP archive integrity: checked with `unzip -t`.

## Not verified
Vite/Gradle build and on-device engine timing have not been verified because the workspace has no installed `node_modules` and network access is unavailable. The ZIP is a source project update, not a newly built APK. Actual move latency varies by device and position complexity.
