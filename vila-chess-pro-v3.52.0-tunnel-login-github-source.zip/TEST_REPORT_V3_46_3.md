# Test report — Cờ Vua ViLa v3.46.3

## Scope

This patch synchronizes the interface to the blue/cyan crown-knight brand palette, refreshes PWA/Service Worker cache keys, restores selected board-theme behavior, adds Docker build files, and updates the already-bundled Android web assets. Existing features and the embedded Google AI Studio ZIP are preserved.

## Changes checked

- Updated the three source stylesheets to use navy/blue/cyan with gold for reward accents.
- Replaced hard-coded `!important` board-square fills with `--board-light`, `--board-dark`, `--board-selected`, and `--board-last-*` variables.
- Synchronized `app/src/main/assets/assets/index-nreOU-41.css`, the Android HTML asset URLs, PWA manifest and Android Service Worker copy.
- Updated package/app version to `3.46.3`; bumped asset cache query strings from `v=348` to `v=349` and Service Worker cache ID to `covua-vila-v3.46.3`.
- Added `Dockerfile` and `.dockerignore` and added regression checks for Docker configuration and bundled Android palette/theme settings.
- Preserved historical test reports and the nested Google AI Studio ZIP under `app/src/main/assets/assets/aistudio/`.

## Checks actually run

| Check | Result |
|---|---:|
| `npm run test:static` | **266/266 passed** |
| Current-release targeted regressions | **43/43 passed** |
| `node --check` over `.js`/`.mjs` files in `src`, `server`, `scripts` and `tests` | **132/132 passed** |
| JSON parse for package, lockfile, metadata, Capacitor and both PWA manifests | **Passed** |
| CSS brace-balance and Android board-theme variable checks | **Passed** |
| Full `npm test` | **268 passed / 272 total**; 4 files cannot load required packages |

The four full-suite files blocked before their assertions are `tests/alternate-engine.test.js`, `tests/chess.test.js`, `tests/social.test.js`, and `tests/v3-25-features.test.js`. The errors are `ERR_MODULE_NOT_FOUND`: `chess.js` is absent for three files and `express` is absent for one. No conclusion about those four test suites' assertions can be drawn until dependencies are installed.

## Build status and limits

- `node_modules` is absent and this environment has no usable dependency-install cache/network, so the Vite production build was not run.
- Docker CLI/daemon is unavailable here, so the image was not built. The Dockerfile contract is covered by tests, but the actual container still needs a network-enabled build environment.
- No APK was built or tested on a physical Android device. A GitHub Actions/Gradle build is still required before treating this ZIP as an APK-ready release.
- A fresh Chromium screenshot did not complete in this environment, so this report does not claim a new screenshot-based visual review.

The Android CSS asset was updated directly and cache-busted because Vite could not be run locally. Once dependencies are available, run `npm ci`, `npm test`, `npm run build`, and the Android workflow; re-check the visual screens and compare the generated Android assets with the source build.
