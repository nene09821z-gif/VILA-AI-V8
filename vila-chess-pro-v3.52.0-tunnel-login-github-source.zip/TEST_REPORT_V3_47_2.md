# ViLa Chess Pro v3.47.2 — báo cáo kiểm tra

## Thay đổi

- Stockfish 10 trong Đấu trường: thời gian tìm nước được hạ xuống khoảng 0,18–0,60 giây mỗi nước (độ sâu 20 thường nhắm khoảng 0,40 giây), thay cho mức có thể lên đến 1,2 giây.
- Stockfish 10 khi người chơi đấu bot: ngân sách tìm nước tối đa khoảng 0,5 giây mỗi nước; watchdog riêng giảm còn khoảng 3,5–7 giây để tránh mắc kẹt quá lâu.
- Timeout khởi tạo engine cũ giảm từ 30 giây xuống 8 giây; timeout tìm nước mặc định còn 4,5–5 giây. Engine Worker vẫn được tái sử dụng trong các nước/ván để tránh khởi động lại mỗi lượt.
- Stockfish 10 vẫn giữ nguyên để chọn thủ công. Không đổi thời lượng/phân tích chuyên sâu của Stockfish mới và luồng xem lại ván.
- Nâng phiên bản web/Android lên 3.47.2 và thay cache Service Worker `v3.47.2`, asset key `v=352`.
- Thêm script `scripts/package-github-source.py`, tạo ZIP gọn bằng cách chỉ lưu một bản nguồn của các tài nguyên tĩnh. ZIP không lặp lại 145 tài nguyên trùng giữa `public/` và `app/src/main/assets/`; Gradle tự sao chép tài nguyên từ `public/` trước khi build native Android. Gói AI Studio vẫn được giữ một bản đầy đủ.

## Kết quả

- Test nhóm engine, luồng trận, UI/metadata và gói nguồn: 51/51 đạt.
- Bộ kiểm thử tĩnh `npm run test:static`: 272/272 đạt.
- Toàn bộ `npm test`: 277/281 đạt; 4 test không khởi chạy do môi trường không có package `chess.js` và `express` (3 bài phụ thuộc `chess.js`, 1 bài phụ thuộc `express`).
- Kiểm tra cú pháp JavaScript cho `src/main.js`, `src/legacy-uci-engine.js`, backend và JS bundle Android: đạt.
- Script đóng gói kiểm tra file bắt buộc và CRC của ZIP trước khi báo thành công.
- ZIP GitHub gọn được tạo ở 16.1 MB (15.4 MiB), thấp hơn giới hạn tải lên qua giao diện GitHub khoảng 25 MB.

## Giới hạn chưa xác nhận

- Môi trường không có `node_modules` và không thể cài dependency qua mạng, nên chưa chạy được Vite build/Gradle APK build hoàn chỉnh.
- Không có benchmark trực tiếp trên điện thoại OPPO/Android thật. Các thời gian trên là giới hạn cấu hình tìm kiếm gửi cho engine; thời gian thực tế còn phụ thuộc CPU/WebView và thời gian khởi tạo.
- Stockfish 10 là bản asm.js cũ, một luồng; không thể biến nó thành engine mới hoặc tăng số luồng chỉ bằng cài đặt. Khi cần sức mạnh tối đa nên chọn Stockfish 19 cho phân tích; Stockfish 10 nay ưu tiên phản hồi nhanh.
