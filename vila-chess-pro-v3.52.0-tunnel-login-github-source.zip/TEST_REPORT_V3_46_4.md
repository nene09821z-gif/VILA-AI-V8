# Test report — Cờ Vua ViLa v3.46.4

## What changed

- Added a dedicated **Thiết lập trận đấu** screen. Opening Chơi cờ before a game starts shows setup options only; the board is rendered only after **Bắt đầu trận**.
- Setup lets the player choose game mode, bot profile, side/color, bot strength/Elo limit, clock, and quick time controls.
- New game, replay, and the in-game setup action route through the setup screen. Starting a new setup asks before discarding a live game with moves, then stops clocks and cancels pending bot/analysis work.
- Added responsive mobile styles and applied the setup-first flow to both the source web app and the prebundled Android WebView assets.
- Incremented app/cache versions to v3.46.4 / asset query v=350.

## Verification performed

- Match-setup flow tests: **3/3 passed**.
- Targeted UI, navigation, version/cache, branding and release-audit selection: **38/38 passed**.
- Full `npm test`: **271 passed / 4 unable to start (275 total)**.
- JavaScript syntax check passed for `src/main.js` and the bundled Android JS file.
- ZIP integrity verified after packaging.

## Tests unable to start

These fail during module loading because this offline environment has no installed `node_modules` and no network access to install dependencies. They do not reach the assertions:

- `tests/alternate-engine.test.js` — missing `chess.js`
- `tests/chess.test.js` — missing `chess.js`
- `tests/social.test.js` — missing `express`
- `tests/v3-25-features.test.js` — missing `chess.js`

## Not verified

- A real Vite production build was not run because build dependencies are not installed.
- The prebuilt Android JS/CSS assets were updated directly to avoid leaving Android users on the old UI, but they were not regenerated via Vite in this environment.
- No APK/Gradle build or on-device Android test was performed. Do not treat this ZIP as an already-built APK.
- Chromium preview could not be run in this environment because the sandbox blocked browser navigation to the local project.

## Recommended final release check

On a networked build environment, install the pinned dependencies, run `npm test`, run `npm run build`, sync/build Android, and verify on a phone: setup opens without a board, pressing **Bắt đầu trận** creates the board, the new-game/setup actions return to setup, and the selected bot/color/clock are applied.
