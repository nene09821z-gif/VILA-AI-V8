# Test report — Cờ Vua ViLa v3.46.2

## Scope

This patch applies the supplied cyan/blue crown-knight logo as the brand mark and application icon. The full `VILA` wordmark is retained for brand display in Settings. The generated memorial image is preserved as the Settings keepsake; it is not used as the launcher icon.

## Changes checked

- Replaced the live header/home brand mark with `public/covua-vila-brand-icon.png` derived from the supplied high-resolution logo.
- Updated favicon PNG/ICO, Apple touch icon, PWA manifest icons, and all Android launcher densities (`mdpi` through `xxxhdpi`). The launcher/PWA variants include safe padding around the crown and horse.
- Kept the full user logo in `public/covua-vila-logo.png`, compressed web display form `public/covua-vila-logo.webp`, and archived full source in `resources/branding/covua-vila-logo-original.png`.
- Added the original memorial PNG at `resources/branding/vila-memory-monument-original.png`; the app uses the compressed `public/vila-memory-monument.webp` inside Settings for better mobile loading.
- Updated Service Worker cache version and pre-cached the new brand icon, manifest and memorial image for offline use.
- Added `tests/branding-update.test.js` for brand paths, image dimensions, Android mipmaps, manifest and the Settings keepsake.

## Checks actually run

| Check | Result |
|---|---:|
| `npm run test:static` | **264/264 passed** |
| `node --check` over `src`, `server`, `scripts`, and `tests` JS/MJS | **131/131 passed** |
| Full `npm test` | **266 passed / 270 total** |
| Image decode, icon PNG dimensions, Android XML and PWA manifest JSON validation | **Passed** |

The four full-suite test files that could not load were `tests/alternate-engine.test.js`, `tests/chess.test.js`, `tests/social.test.js`, and `tests/v3-25-features.test.js`. The runtime errors are missing installed packages (`chess.js` in three files and `express` in one); they did not reach their test assertions.

## Build status / known limitation

`npm run build` was attempted and stopped in the `prebuild` stage because `chess.js` is not installed in this environment. No `node_modules` directory was provided in the source ZIP. Therefore the production bundle and Android APK have **not** been verified in this session. Build the project in an environment where dependencies can be installed, then let the Android GitHub Actions workflow run its required tests and Gradle build before treating an APK as release-ready.
