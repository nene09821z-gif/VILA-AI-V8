# Máy chủ cộng đồng VILA Chess trên Termux

> Máy chủ Termux phải chạy liên tục và có một URL HTTPS công khai mới phục vụ được người chơi từ Internet. Chạy `127.0.0.1` hoặc chỉ mở cổng trong Wi-Fi không giúp người chơi bên ngoài kết nối. Android/nhà mạng có thể chặn kết nối vào; dùng tunnel/hosting có HTTPS nếu không thể mở cổng an toàn.

## 1. Cài đặt

```sh
pkg update && pkg upgrade
pkg install nodejs-lts git
# Giải nén project rồi cd vào thư mục chứa package.json
npm install --omit=dev
cp .env.example .env
```

Sửa `.env`: đặt `SOCIAL_TOKEN_SECRET` và `TUBOR_ACCESS_TOKEN` thành các chuỗi ngẫu nhiên riêng biệt dài ít nhất 32 byte (không giữ giá trị mẫu); cấu hình `ADMIN_USERNAME`, `ADMIN_PASSWORD` (ít nhất 14 ký tự), `ADMIN_EMAIL`. Nếu truy cập app từ trình duyệt web qua một domain riêng, thêm origin của domain đó vào danh sách `CORS_ORIGIN`; app Android Capacitor đã có origin `capacitor://localhost`. Sau đó mở app, bấm “Thiết lập máy chủ Termux…” ở màn hình đăng nhập, nhập URL và kiểm tra kết nối. `http://127.0.0.1:8787` chỉ dành cho app và máy chủ chạy trên cùng điện thoại; để ghép trận với người ở xa, phải mở server ra Internet qua một tunnel/hostname HTTPS và nhập URL HTTPS đó. Không gửi mật khẩu qua HTTP công cộng.

Để gửi mã khôi phục 6 số thật qua email, đặt `RESEND_API_KEY` và `RESET_EMAIL_FROM` bằng một địa chỉ thuộc domain đã xác minh ở Resend; nếu chưa cấu hình thì app sẽ báo rõ rằng email chưa sẵn sàng. Mã có thời hạn 10 phút và bị giới hạn số lần nhập.

## 2. Chạy

```sh
bash scripts/start-termux.sh
```

Server lắng nghe cổng 8787. Trong cùng thiết bị có thể kiểm tra `http://127.0.0.1:8787/api/social/health`. Để app Android kết nối từ mạng bên ngoài, cần URL HTTPS của server/tunnel và nhập URL đó trong Cài đặt → Máy chủ cộng đồng. Không nhúng secret vào APK hoặc GitHub.

## Lưu ý vận hành

- Dữ liệu tài khoản lưu trong `data/social-store.json`; sao lưu file này và bảo vệ quyền truy cập.
- Một tiến trình Node duy nhất được hỗ trợ cho kho JSON hiện tại; không chạy nhiều bản sao cùng lúc.
- Dùng HTTPS, giữ Termux không bị Android ngủ nền, có sao lưu và giới hạn truy cập quản trị. Không có cơ chế nào bảo đảm “không bao giờ bị ban”; chế độ rank trong app chỉ cung cấp bàn cờ, luật đi, đồng hồ và thông tin khai cuộc, không đưa gợi ý engine.
- Nếu dùng tunnel, đừng để lộ cổng quản trị hoặc secret. Định kỳ cập nhật Node.js và các gói phụ thuộc.

## 3. Chạy lâu dài (khuyến nghị)

Dùng `scripts/vila-run.sh`: một lệnh chạy cả server lẫn Cloudflare Tunnel, tự chạy lại khi thoát (server cố ý tự thoát khi gặp lỗi nghiêm trọng để được khởi động lại; nếu chết quá nhanh thì giãn thời gian chờ 3 → 60 giây), giữ wakelock, ghi log vào `logs/` (tự xoá khi file > 5 MB).

```sh
pkg install tmux cloudflared
cp .env.example .env            # đặt SOCIAL_TOKEN_SECRET, TUBOR_ACCESS_TOKEN (>= 32 byte)
tmux new -s vila "bash scripts/vila-run.sh"    # thoát bằng Ctrl+B rồi D; vào lại: tmux attach -t vila
bash scripts/vila-run.sh --status              # kiểm tra server + in link tunnel
bash scripts/vila-run.sh --install-boot        # tự chạy khi mở máy (cần app Termux:Boot từ F-Droid)
```

Để Android không tắt Termux:

1. Cài Termux từ F-Droid/GitHub (không dùng bản Google Play).
2. Cài đặt → Ứng dụng → Termux → Pin → **Không giới hạn**. Giữ điện thoại cắm sạc, bật “Giữ Wi-Fi khi ngủ”.
3. Android 12 trở lên có thể giết tiến trình con của Termux: bật “Tắt hạn chế tiến trình con” trong Tùy chọn nhà phát triển (Android 14), hoặc chạy từ máy tính `adb shell "settings put global settings_enable_monitor_phantom_procs false"`.

Link Cloudflare: Quick Tunnel đổi link mỗi lần `cloudflared` khởi động lại. Để link không đổi, tạo Named Tunnel (xem `CLOUDFLARE_TUNNEL.md`) rồi chạy `CF_TUNNEL_NAME=ten-tunnel bash scripts/vila-run.sh`.
