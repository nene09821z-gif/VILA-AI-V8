/**
 * VILA AI Arena — tournament logic (pure functions; no DOM, no chess.js, fully unit-testable).
 *
 * Formats
 *   match      first two selected players, N games, colours alternate
 *   roundrobin everyone plays everyone, N games per pairing, colours alternate
 *   gauntlet   first selected player ("champion") plays every other player, N games per pairing
 *   knockout   single elimination; each tie is a 2-game mini-match, then sudden-death games
 *
 * Fairness: with `pairedOpenings`, games 2k and 2k+1 of a pairing use the SAME opening with colours
 * swapped (the standard engine-testing practice), so one lucky opening cannot decide a pairing.
 *
 * Elo numbers produced here are RELATIVE (centred on the field's average). They are not benchmarked ratings.
 */

export const ARENA_FORMATS = Object.freeze([
  { id: 'match', label: 'Trận đấu 1-1', hint: 'Hai bot đầu tiên đấu nhiều ván, đổi màu xen kẽ' },
  { id: 'roundrobin', label: 'Vòng tròn', hint: 'Mọi bot gặp nhau, đổi màu xen kẽ' },
  { id: 'gauntlet', label: 'Thách đấu (1 vs tất cả)', hint: 'Bot đầu tiên đấu với từng bot còn lại' },
  { id: 'knockout', label: 'Loại trực tiếp', hint: 'Cặp đấu 2 ván; hòa thì đấu thêm ván quyết định' }
]);
export const ARENA_MIN_PLAYERS = 2;
export const ARENA_MAX_PLAYERS = 8;
export const ARENA_GAMES_PER_PAIR_OPTIONS = Object.freeze([2, 4, 6, 8, 10]);

export function isValidArenaFormat(id) { return ARENA_FORMATS.some(format => format.id === id); }

/** Small deterministic PRNG so a tournament's openings are reproducible from its seed. */
export function seededRandom(seed) {
  let state = (Number(seed) >>> 0) || 0x9e3779b9;
  return function next() {
    state = (state + 0x6D2B79F5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Pick `count` distinct opening lines (SAN arrays) of an even number of plies.
 * `openings` are catalogue entries `{ name, san: [...] }`. Falls back to [] (start position) when empty.
 */
export function pickArenaOpenings(openings, count, { seed = 1, plies = 6, minPlies = 4 } = {}) {
  const pool = (Array.isArray(openings) ? openings : []).filter(item => Array.isArray(item?.san) && item.san.length >= minPlies);
  if (!pool.length || count <= 0) return Array.from({ length: Math.max(0, count) }, () => ({ name: 'Thế cờ ban đầu', san: [] }));
  const rng = seededRandom(seed);
  const chosen = [];
  const seen = new Set();
  let guard = 0;
  while (chosen.length < count && guard < count * 40) {
    guard += 1;
    const item = pool[Math.floor(rng() * pool.length)];
    let length = Math.min(item.san.length, plies);
    if (length % 2 === 1) length -= 1; // end on a full move so both sides are to move fairly
    if (length < 2) continue;
    const san = item.san.slice(0, length);
    const key = san.join(' ');
    if (seen.has(key) && seen.size < pool.length) continue;
    seen.add(key);
    chosen.push({ name: String(item.name || 'Khai cuộc'), san });
  }
  while (chosen.length < count) chosen.push(chosen[chosen.length % Math.max(1, chosen.length)] || { name: 'Thế cờ ban đầu', san: [] });
  return chosen;
}

function gamesFor(a, b, gamesPerPair, round, openingsForPair) {
  const games = [];
  for (let index = 0; index < gamesPerPair; index += 1) {
    const flipped = index % 2 === 1;
    const opening = openingsForPair ? openingsForPair[Math.floor(index / 2) % openingsForPair.length] : null;
    games.push({ whiteId: flipped ? b : a, blackId: flipped ? a : b, round, opening });
  }
  return games;
}

/**
 * Full schedule for match / roundrobin / gauntlet.
 * Returns [{ whiteId, blackId, round, opening }]. Knockout is scheduled round by round (see knockoutRound).
 */
export function buildArenaSchedule(format, playerIds, { gamesPerPair = 2, openings = null, pairedOpenings = true } = {}) {
  const ids = [...new Set(playerIds)];
  const pairs = [];
  if (format === 'match') {
    if (ids.length >= 2) pairs.push([ids[0], ids[1]]);
  } else if (format === 'gauntlet') {
    for (let i = 1; i < ids.length; i += 1) pairs.push([ids[0], ids[i]]);
  } else {
    for (let i = 0; i < ids.length; i += 1) for (let j = i + 1; j < ids.length; j += 1) pairs.push([ids[i], ids[j]]);
  }
  const perPair = Math.max(1, Math.floor(Number(gamesPerPair) || 2));
  const schedule = [];
  pairs.forEach(([a, b], pairIndex) => {
    const needed = Math.ceil(perPair / 2);
    const openingsForPair = pairedOpenings && Array.isArray(openings) && openings.length
      ? Array.from({ length: needed }, (_, k) => openings[(pairIndex * needed + k) % openings.length])
      : null;
    schedule.push(...gamesFor(a, b, perPair, pairIndex + 1, openingsForPair));
  });
  // Interleave so a stopped tournament has played every pairing a little rather than finishing early pairs first.
  if (format === 'roundrobin' && perPair > 2) {
    const byPair = new Map();
    for (const game of schedule) { if (!byPair.has(game.round)) byPair.set(game.round, []); byPair.get(game.round).push(game); }
    const queues = [...byPair.values()];
    const out = [];
    for (let k = 0; k < perPair; k += 1) for (const queue of queues) if (queue[k]) out.push(queue[k]);
    return out;
  }
  return schedule;
}

/** Number of games a non-knockout format will play. */
export function countArenaGames(format, playerCount, gamesPerPair) {
  const perPair = Math.max(1, Math.floor(Number(gamesPerPair) || 2));
  if (format === 'match') return playerCount >= 2 ? perPair : 0;
  if (format === 'gauntlet') return Math.max(0, playerCount - 1) * perPair;
  if (format === 'knockout') return Math.max(0, playerCount - 1) * 2; // minimum; tie-breaks add games
  return (playerCount * (playerCount - 1) / 2) * perPair;
}

/** Pair a knockout round in seed order (1 v last, 2 v next-to-last…). An odd player out gets a bye. */
export function knockoutRound(playerIds) {
  const ids = [...playerIds];
  const bye = ids.length % 2 === 1 ? ids.shift() : null; // best remaining seed gets the bye
  const pairs = [];
  while (ids.length >= 2) pairs.push([ids.shift(), ids.pop()]);
  return { pairs, bye };
}

/** Winner of a knockout tie from score of a (higher seed) vs b; null while level. */
export function knockoutTieWinner(scoreA, scoreB, idA, idB) {
  if (scoreA > scoreB) return idA;
  if (scoreB > scoreA) return idB;
  return null;
}

/* ---------- standings ---------- */

export function createArenaStandings(players) {
  const rows = new Map();
  for (const player of players) {
    rows.set(player.id, { id: player.id, name: player.name, games: 0, points: 0, wins: 0, draws: 0, losses: 0, whiteGames: 0, blackGames: 0, fallbackMoves: 0, versus: {} });
  }
  return rows;
}

/** Record a finished game. `result` is '1-0' | '0-1' | '1/2-1/2'. Returns false for unfinished results. */
export function recordArenaResult(standings, whiteId, blackId, result) {
  const white = standings.get(whiteId), black = standings.get(blackId);
  if (!white || !black) return false;
  let ws, bs;
  if (result === '1-0') { ws = 1; bs = 0; }
  else if (result === '0-1') { ws = 0; bs = 1; }
  else if (result === '1/2-1/2') { ws = 0.5; bs = 0.5; }
  else return false;
  for (const [row, score, opponent, isWhite] of [[white, ws, black, true], [black, bs, white, false]]) {
    row.games += 1; row.points += score;
    if (score === 1) row.wins += 1; else if (score === 0) row.losses += 1; else row.draws += 1;
    if (isWhite) row.whiteGames += 1; else row.blackGames += 1;
    const v = row.versus[opponent.id] || (row.versus[opponent.id] = { points: 0, games: 0 });
    v.points += score; v.games += 1;
  }
  return true;
}

/** Relative Elo from a score fraction (Laplace-smoothed so 100 % / 0 % stay finite). */
export function eloFromScore(points, games) {
  const n = Math.max(0, Number(games) || 0);
  if (!n) return 0;
  const s = (Number(points) + 0.5) / (n + 1);
  const elo = 400 * Math.log10(s / (1 - s));
  return Math.max(-800, Math.min(800, elo));
}

/** Sorted rows with score %, relative Elo (field-centred) and rank. */
export function rankArenaStandings(standings) {
  const rows = [...standings.values()].map(row => ({
    ...row,
    scorePct: row.games ? (row.points / row.games) * 100 : 0,
    relElo: eloFromScore(row.points, row.games)
  }));
  const played = rows.filter(row => row.games > 0);
  const mean = played.length ? played.reduce((sum, row) => sum + row.relElo, 0) / played.length : 0;
  for (const row of rows) row.relElo = row.games ? Math.round(row.relElo - mean) : 0;
  rows.sort((a, b) => b.points - a.points || b.wins - a.wins || a.losses - b.losses || b.relElo - a.relElo || a.name.localeCompare(b.name));
  rows.forEach((row, index) => { row.rank = index + 1; });
  return rows;
}

/** Cross-table: matrix[rowId][colId] = '1.5/2' style cell text ('' on the diagonal / unplayed). */
export function arenaCrosstable(rankedRows) {
  return rankedRows.map(row => ({
    id: row.id, name: row.name,
    cells: rankedRows.map(col => {
      if (col.id === row.id) return { id: col.id, text: '·', tone: 'self' };
      const v = row.versus[col.id];
      if (!v || !v.games) return { id: col.id, text: '', tone: 'none' };
      const tone = v.points > v.games / 2 ? 'win' : v.points < v.games / 2 ? 'loss' : 'draw';
      return { id: col.id, text: `${formatPoints(v.points)}/${v.games}`, tone };
    })
  }));
}

export function formatPoints(points) {
  const n = Number(points) || 0;
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}

/* ---------- adjudication ---------- */

const MATERIAL = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 0 };

/** Material balance in centipawns from White's view; `board` is chess.js `board()` output. */
export function materialBalance(board) {
  let total = 0;
  for (const row of board || []) for (const piece of row || []) {
    if (!piece) continue;
    total += (MATERIAL[piece.type] || 0) * (piece.color === 'w' ? 1 : -1);
  }
  return total;
}

/**
 * Decide a game that hit the ply cap. A clear material edge (default 5 pawns) counts as a win,
 * otherwise the game is drawn. Returns { result, reason }.
 */
export function adjudicateAtPlyLimit(board, plyLimit, { enabled = true, threshold = 500 } = {}) {
  const balance = materialBalance(board);
  if (enabled && balance >= threshold) return { result: '1-0', reason: `Xử thắng Trắng theo vật chất (+${(balance / 100).toFixed(1)}) tại ${plyLimit} nửa nước` };
  if (enabled && balance <= -threshold) return { result: '0-1', reason: `Xử thắng Đen theo vật chất (+${(Math.abs(balance) / 100).toFixed(1)}) tại ${plyLimit} nửa nước` };
  return { result: '1/2-1/2', reason: `Chạm giới hạn ${plyLimit} nửa nước — tính hòa` };
}

/** "mm:ss" for the tournament clock. */
export function formatArenaDuration(ms) {
  const total = Math.max(0, Math.round((Number(ms) || 0) / 1000));
  const m = Math.floor(total / 60), s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

/** Rough ETA from games finished so far. */
export function estimateArenaRemaining(elapsedMs, done, total) {
  if (!done || done >= total) return 0;
  return Math.round((elapsedMs / done) * (total - done));
}
