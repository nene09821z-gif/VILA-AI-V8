/**
 * VILA local game-history sync. Authentication is exclusively managed by the VILA account API.
 * This module intentionally contains no Firebase, Google, GitHub, or third-party login code.
 */
const SYNC_META_KEY = 'vila.chess.cloud-sync-meta.v1';

export function getSyncMeta() {
  try {
    const raw = localStorage.getItem(SYNC_META_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { lastSyncTime: null, syncedCount: 0, status: 'offline' };
}

function saveSyncMeta(meta) {
  try { localStorage.setItem(SYNC_META_KEY, JSON.stringify(meta)); } catch {}
}

export async function syncHistoryToCloud(backendUrl, authToken, localGames = []) {
  if (!backendUrl || !authToken) {
    return { ok: false, message: 'Chưa cấu hình máy chủ VILA hoặc chưa đăng nhập. Lịch sử vẫn được lưu trên máy.', games: localGames };
  }
  try {
    const cleanUrl = String(backendUrl).replace(/\/$/, '');
    const response = await fetch(`${cleanUrl}/api/social/history/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authToken}` },
      body: JSON.stringify({ games: localGames }),
      signal: AbortSignal.timeout(12000)
    });
    if (!response.ok) throw new Error(`Máy chủ trả về HTTP ${response.status}`);
    const data = await response.json();
    const merged = Array.isArray(data.games) ? data.games : localGames;
    saveSyncMeta({ lastSyncTime: new Date().toISOString(), syncedCount: merged.length, status: 'synced' });
    return { ok: true, syncedCount: merged.length, games: merged, message: `Đồng bộ thành công ${merged.length} ván đấu với máy chủ VILA.` };
  } catch (error) {
    saveSyncMeta({ lastSyncTime: getSyncMeta().lastSyncTime, syncedCount: localGames.length, status: 'error', lastError: error.message });
    return { ok: false, message: `Không thể đồng bộ: ${error.message}. Lịch sử vẫn lưu trên máy.`, games: localGames };
  }
}
