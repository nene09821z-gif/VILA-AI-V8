import { centerValue, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, positionalScore, countAttackers } from './evaluation-utils.js';

// Space and initiative profile: controls the center, develops quickly and keeps pieces coordinated. VILA engine.
export const DYNAMIC = Object.freeze({ id: 'dynamic', name: 'VILA Dynamic', defaultDepth: 6, maxNodes: 54000, maxTimeMs: 1100, multipv: 1, style: 'dynamic', lateMoveReduction: true, randomTop: 2 });

export function evaluateDynamic(chess) {
  const board = chess.board();
  let score = materialScore(board) + positionalScore(board, 0.7) + pawnStructureScore(board) * 0.8 + kingSafetyScore(board);
  score += pieceActivityScore(board, { knight: 7, bishop: 6, rook: 1.5, queen: 1, pawnAdvance: 3.4 });
  for (const [row, col] of [[3, 3], [3, 4], [4, 3], [4, 4], [2, 2], [2, 5], [5, 2], [5, 5]]) {
    const weight = centerValue(row, col) >= 6 ? 3.2 : 1.6;
    score += (countAttackers(board, row, col, 'w') - countAttackers(board, row, col, 'b')) * weight;
  }
  // Reward getting minor pieces off the back rank early.
  for (let col = 0; col < 8; col += 1) {
    const w = board[7][col]; const b = board[0][col];
    if (w && (w.type === 'n' || w.type === 'b') && w.color === 'w') score -= 9;
    if (b && (b.type === 'n' || b.type === 'b') && b.color === 'b') score += 9;
  }
  return score;
}
