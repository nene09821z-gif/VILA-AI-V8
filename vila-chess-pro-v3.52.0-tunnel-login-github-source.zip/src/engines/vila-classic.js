import { materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, positionalScore } from './evaluation-utils.js';

export function evaluateVilaClassic(chess) {
  const board = chess.board();
  return materialScore(board) + positionalScore(board, 1) + pawnStructureScore(board) + kingSafetyScore(board) +
    pieceActivityScore(board, { knight: 6, bishop: 5, rook: 1, queen: 0.5, pawnAdvance: 2.8 });
}
