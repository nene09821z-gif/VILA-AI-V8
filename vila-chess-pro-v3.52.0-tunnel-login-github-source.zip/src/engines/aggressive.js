import { centerValue, kingPosition, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, positionalScore, isAttacked } from './evaluation-utils.js';

// Initiative and attacking-space profile. This is a VILA engine, not Berserk.
export const AGGRESSIVE = Object.freeze({ id: 'berserk', name: 'Aggressive', defaultDepth: 6, maxNodes: 51000, maxTimeMs: 1100, multipv: 1, style: 'aggressive', lateMoveReduction: true, randomTop: 2 });

export function evaluateAggressive(chess) {
  const board = chess.board();
  let score = materialScore(board) + positionalScore(board, 0.5) + pawnStructureScore(board) * 0.5 + kingSafetyScore(board) * 0.8;
  score += pieceActivityScore(board, { knight: 6, bishop: 5, rook: 2, queen: 2, pawnAdvance: 4.2 });
  const kings = { w: kingPosition(board, 'w'), b: kingPosition(board, 'b') };
  for (const color of ['w', 'b']) {
    const king = kings[color]; if (!king) continue;
    const enemy = color === 'w' ? 'b' : 'w';
    let attackersNearKing = 0;
    let nearbyPower = 0;
    for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
      const p = board[row][col]; if (!p || p.color !== enemy || p.type === 'p' || p.type === 'k') continue;
      const distance = Math.abs(king.row - row) + Math.abs(king.col - col);
      if (distance <= 3) {
        attackersNearKing += 1;
        nearbyPower += distance <= 2 ? 2 : 1;
      }
    }
    score += (color === 'w' ? -1 : 1) * Math.min(nearbyPower * 4, 28);
    const kingCentrality = centerValue(king.row, king.col);
    // Encourage keeping an enemy king under pressure, while not blindly exposing our own.
    if (kingCentrality > 2.5 && attackersNearKing > 0) score += (color === 'w' ? -1 : 1) * 5;
  }
  // Reward attacking undefended enemy pieces and penalize our own attacked heavy pieces.
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p || p.type === 'p' || p.type === 'k') continue;
    const enemy = p.color === 'w' ? 'b' : 'w';
    if (isAttacked(board, row, col, enemy)) score += (p.color === 'w' ? -1 : 1) * 7;
  }
  return score;
}
