export const DEFAULT_VISUAL_SETTINGS = Object.freeze({
  showLegalMoves: true,
  highlightLastMove: true,
  smoothAnimations: true,
  autoQueen: false,
  announceMoves: true
});

export function normalizeVisualSettings(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  return {
    showLegalMoves: source.showLegalMoves !== false,
    highlightLastMove: source.highlightLastMove !== false,
    smoothAnimations: source.smoothAnimations !== false,
    autoQueen: source.autoQueen === true,
    announceMoves: source.announceMoves !== false
  };
}
