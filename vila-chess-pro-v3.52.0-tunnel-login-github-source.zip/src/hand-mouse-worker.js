/* Optional camera hand tracking, isolated from the UI thread. Camera frames are processed locally. */
const VISION_VERSION = '0.10.14';
const VISION_MODULE = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VISION_VERSION}/vision_bundle.mjs`;
const VISION_WASM = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VISION_VERSION}/wasm`;
const HAND_MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
let handLandmarker = null;
let busy = false;

self.onmessage = async event => {
  const data = event.data || {};
  if (data.type === 'init') {
    try {
      const { FilesetResolver, HandLandmarker } = await import(VISION_MODULE);
      const vision = await FilesetResolver.forVisionTasks(VISION_WASM);
      try {
        handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: { modelAssetPath: HAND_MODEL, delegate: 'GPU' },
          runningMode: 'VIDEO', numHands: 1,
          minHandDetectionConfidence: 0.55,
          minHandPresenceConfidence: 0.5,
          minTrackingConfidence: 0.55
        });
      } catch (gpuError) {
        handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: { modelAssetPath: HAND_MODEL, delegate: 'CPU' },
          runningMode: 'VIDEO', numHands: 1,
          minHandDetectionConfidence: 0.55,
          minHandPresenceConfidence: 0.5,
          minTrackingConfidence: 0.55
        });
      }
      self.postMessage({ type: 'ready' });
    } catch (error) {
      self.postMessage({ type: 'fatal', error: String(error?.message || error || 'Không tải được mô hình nhận diện tay.') });
    }
    return;
  }
  if (data.type !== 'frame' || !handLandmarker || busy || !data.bitmap) {
    data.bitmap?.close?.();
    return;
  }
  busy = true;
  const bitmap = data.bitmap;
  try {
    const result = handLandmarker.detectForVideo(bitmap, Number(data.timestamp) || performance.now());
    const points = result?.landmarks?.[0];
    if (points?.[8] && points?.[4]) {
      const tip = points[8];
      const thumb = points[4];
      self.postMessage({
        type: 'landmarks',
        point: { x: tip.x, y: tip.y },
        pinchDistance: Math.hypot(tip.x - thumb.x, tip.y - thumb.y),
        confidence: Number(result?.handednesses?.[0]?.[0]?.score || 0)
      });
    } else {
      self.postMessage({ type: 'no-hand' });
    }
  } catch (error) {
    self.postMessage({ type: 'frame-error', error: String(error?.message || error || 'Lỗi nhận diện khung hình.') });
  } finally {
    bitmap.close?.();
    busy = false;
  }
};
