/**
 * Isolated UCI session for the legacy Stockfish 10 JavaScript engine.
 * The worker is never shared with Stockfish 19, the player's game, or review.
 * A new-game marker is sent once per arena game (not before every ply), and
 * every search waits for `readyok` before its position/go commands are sent.
 */
export class LegacyUciEngine {
  constructor(workerFactory, { initTimeoutMs = 30_000, defaultSearchTimeoutMs = 5_000 } = {}) {
    if (typeof workerFactory !== 'function') throw new TypeError('workerFactory must be a function');
    this.workerFactory = workerFactory;
    this.initTimeoutMs = initTimeoutMs;
    this.defaultSearchTimeoutMs = defaultSearchTimeoutMs;
    this.worker = null;
    this.state = 'idle';
    this.initPromise = null;
    this.resolveInit = null;
    this.rejectInit = null;
    this.initTimer = null;
    this.search = null;
    this.newGamePending = true;
    this.disposed = false;
  }

  ensureReady() {
    if (this.disposed) return Promise.reject(new Error('Stockfish 10 session was disposed.'));
    if (this.state === 'ready') return Promise.resolve();
    if (this.initPromise) return this.initPromise;

    this.state = 'starting';
    // Assign the promise before creating the Worker so synchronous constructor
    // errors cannot leave a permanently cached, already-rejected initPromise.
    this.initPromise = new Promise((resolve, reject) => {
      this.resolveInit = resolve;
      this.rejectInit = reject;
    });
    const initPromise = this.initPromise;

    try {
      const worker = this.workerFactory();
      this.worker = worker;
      worker.onmessage = event => {
        // A timed-out/retired worker must never resolve a search belonging to a
        // replacement worker, even if an event had already been queued.
        if (this.worker !== worker || this.disposed) return;
        const payload = event?.data;
        const message = typeof payload === 'string' ? payload
          : (payload && typeof payload.data === 'string') ? payload.data
            : String(payload ?? '');
        this.#onMessage(message);
      };
      worker.onerror = event => {
        if (this.worker !== worker || this.disposed) return;
        this.#fail(new Error(event?.message || 'Stockfish 10 worker failed.'), worker);
      };
      this.initTimer = setTimeout(() => {
        if (this.worker === worker && this.state === 'starting') {
          this.#fail(new Error('Stockfish 10 khởi tạo quá thời gian.'), worker);
        }
      }, this.initTimeoutMs);
      worker.postMessage('uci');
    } catch (error) {
      this.#fail(error instanceof Error ? error : new Error(String(error)));
    }
    return initPromise;
  }

  #post(line) {
    if (!this.worker) throw new Error('Stockfish 10 worker chưa khởi tạo.');
    this.worker.postMessage(line);
  }

  #onMessage(message) {
    // Some wrappers emit multiple UCI lines in one message. Process each line
    // independently so a bundled `info` + `bestmove` cannot be missed.
    for (const rawLine of String(message).split(/\r?\n/)) {
      const line = rawLine.trim();
      if (line) this.#onLine(line);
    }
  }

  #onLine(line) {
    if (this.state === 'starting' && /^uciok\b/.test(line)) {
      try {
        this.#post('setoption name Threads value 1');
        this.#post('setoption name Hash value 2');
        this.#post('setoption name MultiPV value 1');
        this.#post('isready');
      } catch (error) {
        this.#fail(error instanceof Error ? error : new Error(String(error)), this.worker);
      }
      return;
    }

    if (line === 'readyok') {
      if (this.state === 'starting') {
        clearTimeout(this.initTimer);
        this.initTimer = null;
        this.state = 'ready';
        const resolve = this.resolveInit;
        this.resolveInit = null;
        this.rejectInit = null;
        resolve?.();
        return;
      }

      const pending = this.search;
      if (pending?.awaitingReady) {
        pending.awaitingReady = false;
        try {
          this.#post(`position fen ${pending.fen}`);
          this.#post(`go movetime ${pending.moveTimeMs} depth ${pending.depthLimit}`);
        } catch (error) {
          this.#fail(error instanceof Error ? error : new Error(String(error)), this.worker);
        }
      }
      return;
    }

    const pending = this.search;
    if (!pending || pending.awaitingReady) return;

    const info = line.match(/^info\b.*?\bdepth\s+(\d+)\b.*?\bscore\s+(cp|mate)\s+(-?\d+).*?\bpv\s+([a-h][1-8][a-h][1-8][qrbn]?)/i);
    if (info) {
      const depth = Number(info[1]);
      if (depth >= pending.depth) {
        pending.depth = depth;
        pending.score = info[2] === 'mate'
          ? Math.sign(Number(info[3]) || 1) * (30_000 - Math.min(999, Math.abs(Number(info[3]))))
          : Number(info[3]);
        pending.pv = info[4].toLowerCase();
      }
    }

    const best = line.match(/^bestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000|\(none\))/i);
    if (!best) return;
    this.search = null;
    clearTimeout(pending.timer);
    const uci = best[1].toLowerCase();
    if (pending.cancelled) pending.resolve(null);
    else if (uci === '0000' || uci === '(none)') pending.reject(new Error('Stockfish 10 không trả về nước đi.'));
    else pending.resolve({ uci, depth: pending.depth, score: pending.score, pv: pending.pv });
  }

  #retireWorker(nextState = 'idle') {
    const worker = this.worker;
    this.worker = null;
    this.state = nextState;
    this.initPromise = null;
    this.resolveInit = null;
    this.rejectInit = null;
    clearTimeout(this.initTimer);
    this.initTimer = null;
    this.newGamePending = true;
    if (worker) {
      try { worker.onmessage = null; } catch {}
      try { worker.onerror = null; } catch {}
      try { worker.terminate?.(); } catch {}
    }
  }

  #fail(error, sourceWorker = undefined) {
    if (this.disposed) return;
    if (sourceWorker && sourceWorker !== this.worker) return;
    const rejectInit = this.rejectInit;
    this.resolveInit = null;
    this.rejectInit = null;
    clearTimeout(this.initTimer);
    this.initTimer = null;
    const pending = this.search;
    this.search = null;
    if (pending) {
      clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.#retireWorker('failed');
    rejectInit?.(error);
  }

  /** Mark the next search as the start of a fresh arena game. Safe before startup. */
  newGame() {
    if (this.disposed) throw new Error('Stockfish 10 session was disposed.');
    if (this.search) throw new Error('Không thể đặt lại ván Stockfish 10 khi engine đang tìm nước.');
    this.newGamePending = true;
  }

  async bestMove(fen, { skill = 20, moveTimeMs = 900, depth = 20, timeoutMs = this.defaultSearchTimeoutMs } = {}) {
    const safeFen = typeof fen === 'string' ? fen.trim() : '';
    if (safeFen.split(/\s+/).length !== 6) throw new Error('FEN không hợp lệ cho Stockfish 10.');

    await this.ensureReady();
    if (this.search) throw new Error('Stockfish 10 đang tính một nước khác.');

    const safeSkill = Math.max(0, Math.min(20, Math.round(Number.isFinite(Number(skill)) ? Number(skill) : 20)));
    const safeTime = Math.max(150, Math.min(5_000, Math.round(Number(moveTimeMs) || 900)));
    const safeDepth = Math.max(1, Math.min(30, Math.round(Number.isFinite(Number(depth)) ? Number(depth) : 20)));
    const safeTimeout = Math.max(safeTime + 1_500, Math.min(20_000, Math.round(Number(timeoutMs) || this.defaultSearchTimeoutMs)));
    const needsNewGame = this.newGamePending;
    this.newGamePending = false;

    return new Promise((resolve, reject) => {
      const pending = {
        resolve, reject, depth: 0, depthLimit: safeDepth, score: null, pv: null, timer: null,
        cancelled: false, awaitingReady: true, fen: safeFen, moveTimeMs: safeTime
      };
      pending.timer = setTimeout(() => {
        if (this.search !== pending) return;
        this.search = null;
        // Retire rather than reuse a worker that failed to finish: a delayed
        // bestmove from it must not be mistaken for the next search's result.
        pending.reject(new Error('Stockfish 10 vượt thời gian suy nghĩ.'));
        this.#retireWorker('idle');
      }, safeTimeout);
      this.search = pending;
      try {
        this.#post(`setoption name Skill Level value ${safeSkill}`);
        this.#post('setoption name MultiPV value 1');
        if (needsNewGame) this.#post('ucinewgame');
        // UCI readiness is a barrier: do not send position/go until readyok.
        this.#post('isready');
      } catch (error) {
        this.#fail(error instanceof Error ? error : new Error(String(error)), this.worker);
      }
    });
  }

  stop() {
    if (!this.search || !this.worker) return false;
    this.search.cancelled = true;
    try { this.#post('stop'); return true; } catch { return false; }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    clearTimeout(this.initTimer);
    this.initTimer = null;
    const pending = this.search;
    this.search = null;
    if (pending) {
      clearTimeout(pending.timer);
      pending.reject(new Error('Stockfish 10 session disposed.'));
    }
    const rejectInit = this.rejectInit;
    this.resolveInit = null;
    this.rejectInit = null;
    this.#retireWorker('disposed');
    rejectInit?.(new Error('Stockfish 10 session disposed.'));
  }
}
