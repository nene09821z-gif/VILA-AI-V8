/** Validated, migration-safe settings for an offline-first chess app. */
/** Default VILA account server (Cloudflare Tunnel). Users can override it in Settings. */
export const DEFAULT_BACKEND_URL = 'https://cosmetics-paris-believe-harvey.trycloudflare.com';

export const DEFAULTS = Object.freeze({
  backendUrl: DEFAULT_BACKEND_URL,
  backendAccessToken: '',
  botSkill: 20,
  botStrengthMode: 'max',
  botElo: 2600,
  botDepth: 30,
  botMoveTimeMs: 2600,
  botSearchSettingsPreferenceSet: false,
  analysisMoveTimeMs: 2600,
  reviewQuality: 'max',
  clockPreset: '10+0',
  botEngine: 'auto',
  botEnginePreferenceSet: false,
  openingBookEnabled: true,
  soundEnabled: true,
  alternativeEngine: 'ethereal',
  alternativeEnginePreferenceSet: false,
});

const ENGINE_MODES = new Set(['auto', 'lite-single', 'full-single', 'sf10']);
const OFFLINE_STYLES = new Set(['lc0', 'ethereal', 'berserk', 'fortress', 'endgame', 'dynamic', 'blitz', 'gambit', 'hyper', 'strangler', 'trickster', 'rookie', 'classic', 'mentor', 'hunter', 'sentinel', 'strategist', 'longgame', 'chaos']);

function cleanText(value, fallback = '', max = 4000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : fallback;
}
function clampNumber(value, fallback, min, max) {
  if (value === null || value === '' || typeof value === 'boolean') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
function cleanHttpUrl(value, fallback = '') {
  const candidate = cleanText(value, fallback, 2000);
  if (!candidate) return fallback;
  try {
    const parsed = new URL(candidate);
    if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname) return fallback;
    if (parsed.username || parsed.password || parsed.search || parsed.hash) return fallback;
    return parsed.toString().replace(/\/+$/, '');
  } catch {
    return fallback;
  }
}

/**
 * The whitelist below is deliberate: older builds stored provider API keys,
 * model IDs, endpoints and chat profiles in localStorage. Returning only this
 * shape migrates those legacy records away instead of persisting secrets again.
 */
export function normalizeSettings(storedValue) {
  const stored = storedValue && typeof storedValue === 'object' && !Array.isArray(storedValue)
    ? storedValue
    : {};
  const out = { ...DEFAULTS };

  out.backendUrl = cleanHttpUrl(stored.backendUrl, DEFAULT_BACKEND_URL);
  out.backendAccessToken = cleanText(stored.backendAccessToken, '', 4000);
  out.botSkill = Math.round(clampNumber(stored.botSkill, DEFAULTS.botSkill, 0, 20));
  out.botElo = Math.round(clampNumber(stored.botElo, DEFAULTS.botElo, 500, 3200));
  // Upgrade the previous release's implicit defaults for existing installs, while preserving
  // any non-default values that indicate the player tuned strength before this migration.
  const legacyImplicitSearchDefaults = stored.botSearchSettingsPreferenceSet !== true
    && ((Number(stored.botDepth) === 18 && Number(stored.botMoveTimeMs) === 1200)
      || (Number(stored.botDepth) === 22 && Number(stored.botMoveTimeMs) === 1600));
  out.botDepth = legacyImplicitSearchDefaults ? DEFAULTS.botDepth : Math.round(clampNumber(stored.botDepth, DEFAULTS.botDepth, 5, 30));
  out.botMoveTimeMs = legacyImplicitSearchDefaults ? DEFAULTS.botMoveTimeMs : Math.round(clampNumber(stored.botMoveTimeMs, DEFAULTS.botMoveTimeMs, 500, 5000));
  out.botSearchSettingsPreferenceSet = stored.botSearchSettingsPreferenceSet === true;
  out.reviewQuality = ['standard', 'deep', 'max'].includes(stored.reviewQuality) ? stored.reviewQuality : DEFAULTS.reviewQuality;
  out.analysisMoveTimeMs = Math.round(clampNumber(stored.analysisMoveTimeMs, DEFAULTS.analysisMoveTimeMs, 1000, 8000));
  const validClockPresets = new Set(['untimed', '0.25+0', '0.5+0', '1+0', '2+0', '2+1', '3+0', '3+1', '3+2', '5+0', '5+3', '5+5', '6+0', '10+0', '10+5', '15+0', '15+10', '20+0', '25+5', '30+0']);
  out.clockPreset = validClockPresets.has(stored.clockPreset) ? stored.clockPreset : DEFAULTS.clockPreset;
  out.botStrengthMode = stored.botStrengthMode === 'elo' ? 'elo' : 'max';
  out.botEngine = ENGINE_MODES.has(stored.botEngine) ? stored.botEngine : DEFAULTS.botEngine;
  out.botEnginePreferenceSet = stored.botEnginePreferenceSet === true;
  out.alternativeEngine = OFFLINE_STYLES.has(stored.alternativeEngine) ? stored.alternativeEngine : DEFAULTS.alternativeEngine;
  out.alternativeEnginePreferenceSet = stored.alternativeEnginePreferenceSet === true;
  // Older releases used a Leela-style heuristic as the default; it is not the actual LCZero engine.
  // Migrate that implicit default to the more tactical fallback while preserving explicit choices.
  if (!out.alternativeEnginePreferenceSet && out.alternativeEngine === 'lc0') out.alternativeEngine = 'ethereal';
  out.openingBookEnabled = stored.openingBookEnabled !== false;
  out.soundEnabled = stored.soundEnabled !== false;

  // Migrate old implicit Lite defaults unless the player explicitly chose it.
  if (!out.botEnginePreferenceSet && out.botEngine === 'lite-single') out.botEngine = 'auto';
  return out;
}
