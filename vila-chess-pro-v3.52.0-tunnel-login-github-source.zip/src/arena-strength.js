const clamp = (value, min, max, fallback) => {
  const parsed = Number(value);
  const safe = Number.isFinite(parsed) ? parsed : fallback;
  return Math.max(min, Math.min(max, Math.round(safe)));
};

/**
 * Shared per-move budget for every opponent in the AI Arena.
 * Full-power defaults give every bot the same high depth ceiling and a generous
 * wall-clock allowance so Stockfish 19 / 10 and VILA style profiles all run near
 * maximum strength. Different engines may still finish different depths inside
 * that time; that is engine performance, not an intentional handicap.
 */
export function resolveArenaMoveTimeMs(depth = 32) {
  const safeDepth = clamp(depth, 8, 40, 32);
  // ~250 ms per depth unit, floor 2 s, ceiling 15 s for true full-power runs
  return Math.max(2_000, Math.min(15_000, Math.round(safeDepth * 250)));
}

/** Normalized options shared by every arena player. Full strength is the default. */
export function resolveArenaSearchSettings(options = {}) {
  const depth = clamp(options.depth, 8, 40, 32);
  const skill = clamp(options.skill, 0, 20, 20);
  const strengthMode = options.strengthMode === 'elo' ? 'elo' : 'max';
  const elo = clamp(options.elo, 500, 3_200, 2_800);
  const fullPower = strengthMode === 'max' && skill >= 20 && depth >= 28;
  return {
    depth,
    skill,
    strengthMode,
    elo,
    moveTimeMs: resolveArenaMoveTimeMs(depth),
    // Prefer pure principal variation at full power (less MultiPV overhead).
    // Keep a few lines only when the user deliberately lowers strength.
    multiPv: fullPower ? 1 : 4,
  };
}

/** Keep style preference as a tie-breaker among near-equal engine moves, never a handicap. */
export function resolveArenaStyleTolerance(_profile = 'classic') {
  return 18;
}
