const UCI_MOVE_PATTERN = /^[a-h][1-8][a-h][1-8][qrbn]?$/;

function readCandidateMove(fen, uci, ChessClass) {
  if (!UCI_MOVE_PATTERN.test(String(uci || '')) || typeof ChessClass !== 'function') return null;
  try {
    const board = new ChessClass(fen);
    const legal = board.moves({ verbose: true }).find(move => `${move.from}${move.to}${move.promotion || ''}` === uci);
    if (!legal) return null;
    const next = new ChessClass(fen);
    const played = next.move({ from: legal.from, to: legal.to, ...(legal.promotion ? { promotion: legal.promotion } : {}) });
    if (!played) return null;
    const mate = Boolean(next.isCheckmate?.());
    const check = Boolean(next.isCheck?.());
    const tactical = Boolean(legal.captured || legal.promotion || check || mate);
    return { uci, san: played.san, tactical, mate, check, captured: Boolean(legal.captured), promotion: Boolean(legal.promotion) };
  } catch {
    return null;
  }
}

/**
 * Accept a Stockfish-generated puzzle only when the proposed answer is legal,
 * visibly tactical, and clearly ahead of a distinct MultiPV alternative.
 * Scores are expected to be Stockfish root scores from the side-to-move view.
 */
export function selectVerifiedTacticalCandidate(fen, variations, ChessClass, {
  minimumGapCp = 180,
  minimumScoreCp = 80,
  minimumDepth = 6,
  maximumDepthDisparity = 2,
} = {}) {
  if (!Array.isArray(variations) || variations.length < 2 || typeof ChessClass !== 'function') return null;
  const candidates = variations
    .filter(item => item && UCI_MOVE_PATTERN.test(String(item.uci || '')) && Number.isFinite(Number(item.score)))
    .map(item => ({ ...item, uci: String(item.uci).toLowerCase(), score: Number(item.score), depth: Number(item.depth) || 0, multipv: Number(item.multipv) || 0 }))
    .sort((a, b) => (a.multipv || 99) - (b.multipv || 99));
  const best = candidates[0];
  const second = candidates.find(item => item.uci !== best?.uci);
  if (!best || !second || best.depth < minimumDepth || second.depth < minimumDepth) return null;
  if (Math.abs(best.depth - second.depth) > maximumDepthDisparity) return null;
  const gapCp = best.score - second.score;
  if (gapCp < minimumGapCp || best.score < minimumScoreCp) return null;
  const move = readCandidateMove(fen, best.uci, ChessClass);
  if (!move?.tactical) return null;
  return { ...move, uci: best.uci, scoreCp: best.score, gapCp, depth: best.depth };
}

/** A Lichess mate-in-one theme may have more than one correct mating move. */
export function isMateInOneTheme(themes) {
  if (!Array.isArray(themes)) return false;
  return themes.some(theme => String(theme || '').toLowerCase().replace(/[\s_-]/g, '') === 'matein1');
}


const THEME_LABELS = Object.freeze({
  advantage: 'Lợi thế', advancedpawn: 'Tốt thông nâng cao', anastasiamate: 'Chiếu hết Anastasia', arabianmate: 'Chiếu hết Ả Rập',
  attraction: 'Dụ quân', backrankmate: 'Chiếu hết hàng cuối', capturingdefender: 'Loại bỏ quân phòng thủ', clearance: 'Giải phóng đường',
  defensivemove: 'Nước phòng thủ', deflection: 'Đánh lạc hướng', doublebishopmate: 'Chiếu hết bằng hai tượng', doublecheck: 'Chiếu kép',
  discoveredattack: 'Tấn công mở', discoveredcheck: 'Chiếu mở', endgame: 'Tàn cuộc', enpassant: 'Bắt tốt qua đường', equality: 'Cân bằng',
  exposedking: 'Vua lộ', fork: 'Đòn chĩa đôi', hangingpiece: 'Quân treo', intermezzo: 'Nước trung gian', interference: 'Cản quân',
  kingsideattack: 'Tấn công cánh Vua', long: 'Biến dài', middlegame: 'Trung cuộc', opening: 'Khai cuộc', pin: 'Ghim quân', promotion: 'Phong cấp',
  queensideattack: 'Tấn công cánh Hậu', quietmove: 'Nước im lặng', sacrifice: 'Thí quân', skewer: 'Đòn xiên', short: 'Biến ngắn',
  smotheredmate: 'Chiếu hết ngạt', trappedpiece: 'Quân mắc bẫy', underpromotion: 'Phong cấp không Hậu', xrayattack: 'Tấn công X-quang',
  zugzwang: 'Zugzwang — buộc phải đi nước bất lợi', mate: 'Chiếu hết',
});

/** Return a readable Vietnamese label for common Lichess puzzle theme tags. */
export function localizePuzzleTheme(theme) {
  const raw = String(theme || '').trim();
  if (!raw) return '';
  const mate = raw.match(/^mateIn(\d+)$/i);
  if (mate) return `Chiếu hết trong ${mate[1]}`;
  const key = raw.toLowerCase().replace(/[\s_-]/g, '');
  return THEME_LABELS[key] || raw.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, char => char.toUpperCase());
}

export function localizePuzzleThemes(themes) {
  if (!Array.isArray(themes)) return [];
  return [...new Set(themes.slice(0, 8).map(localizePuzzleTheme).filter(Boolean))];
}
