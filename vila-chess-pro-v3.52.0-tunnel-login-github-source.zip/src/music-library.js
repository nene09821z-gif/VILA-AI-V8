// Online background music (streamed through the official YouTube IFrame player — nothing is
// downloaded or re-hosted by the app). Each entry is a YouTube video or playlist; when one cannot be
// embedded the player automatically skips to the next entry.
export const MUSIC_LIBRARY = Object.freeze([
  { id: 'tt-buon-nonstop', name: 'Nonstop DJ Buồn TikTok', mood: 'Nhạc buồn · remix', videoId: 'LuAwaemUXsA' },
  { id: 'tt-remix-top30-a', name: 'Top 30 Remix gây bão TikTok 2026', mood: 'Remix TikTok', videoId: 'qIkQuwzuHk0' },
  { id: 'tt-remix-thuong-nhau', name: 'Remix siêu bá khí · Thương Nhau Đến Thế', mood: 'Remix TikTok', videoId: 'jFcN7ibsLTk' },
  { id: 'tt-remix-loi-lam', name: 'Remix hot trend · Lỗi Lầm Em Mang Đi, Ái Nữ', mood: 'Remix TikTok', videoId: 'SFy8EsCSnog' },
  { id: 'tt-remix-chap-niem', name: 'Remix · Chấp Niệm Trong Em, Lỡ Một Lời Thương', mood: 'Nhạc buồn · remix', videoId: 'LQCxuES4Hco' },
  { id: 'tt-remix-xin-dung', name: 'Remix lộn xộn · Xin Đừng Rời Xa Anh', mood: 'Nhạc buồn · remix', videoId: 'NM1cikzWYUQ' },
  { id: 'tt-remix-co-minh-va-ta', name: 'Remix · Có Mình Và Ta, Nhường Lại Nỗi Đau', mood: 'Remix TikTok', videoId: 'qoyP3hbGhqM' },
  { id: 'tt-lon-xon-top30', name: 'Nhạc lộn xộn TikTok gây nghiện', mood: 'Remix TikTok', videoId: 'e8NPNnJFUjI' },
  { id: 'tt-lon-xon-trieu-view', name: 'Nhạc remix lộn xộn triệu view', mood: 'Remix TikTok', videoId: 'M4hTYv38U9g' },
  { id: 'sad-slowed-pl', name: 'Sad Slowed & Reverb (playlist)', mood: 'Buồn · slowed', listId: 'PL3WZeZEnfvvBpI0suvOPoDixi4G9iGKj8' },
  { id: 'slowed-tiktok-pl', name: 'TikTok Slowed Songs (playlist)', mood: 'Slowed · TikTok', listId: 'PLBTanuC8SLeZaIXwjc-vDZ-CmRak-KITf' },
  { id: 'sad-slowed-love', name: 'Best Slowed Songs · Sad Love Songs', mood: 'Buồn · slowed', videoId: '7xVKoy60YRI' },
  { id: 'sad-tiktok-slowed', name: 'Sadvibes TikTok Slowed & Reverb', mood: 'Buồn · slowed', videoId: 'dWzmtbqk9jI' },
  { id: 'sad-night', name: 'Sad Love Songs · late night', mood: 'Buồn · đêm khuya', videoId: 'xp-vIAVoAE8' },
  { id: 'slowed-sad-mix', name: 'Slowed Sad Songs (slowed + reverb)', mood: 'Buồn · slowed', videoId: 'NbPHVIGQMJY' },
  { id: 'tiktok-slowed-mix', name: 'TikTok songs · slowed + reverb', mood: 'Slowed · TikTok', videoId: 'YlTVYFu2IB4' }
]);
export const DEFAULT_MUSIC_ID = MUSIC_LIBRARY[0].id;
export function musicEntryById(id) { return MUSIC_LIBRARY.find(item => item.id === id) || null; }
export function musicEntrySource(entry) { return entry ? { videoId: entry.videoId || '', listId: entry.listId || '' } : null; }
