/** A compact SAN-opening trie; only legal continuations matching the full history are returned. */
const trieCache = new WeakMap();

function buildTrie(openings) {
  const root = { children: new Map(), lineCount: 0 };
  for (const opening of openings) {
    const line = opening?.san;
    if (!Array.isArray(line) || !line.length) continue;
    let node = root;
    for (const san of line) {
      const key = String(san);
      if (!node.children.has(key)) node.children.set(key, { children: new Map(), lineCount: 0 });
      node = node.children.get(key);
      node.lineCount += 1;
    }
  }
  return root;
}

function getTrie(openings) {
  const cached = trieCache.get(openings);
  if (cached?.length === openings.length) return cached.root;
  const root = buildTrie(openings);
  trieCache.set(openings, { length: openings.length, root });
  return root;
}

export function findOpeningBookMove(chess, openings, options = {}) {
  if (!chess || !Array.isArray(openings) || chess.isGameOver?.()) return null;
  const maxPlies = Math.max(0, Math.min(20, Number(options.maxPlies ?? 14)));
  const history = chess.history();
  if (history.length >= maxPlies) return null;
  const legalMoves = chess.moves({ verbose: true });
  if (!legalMoves.length) return null;
  const legalBySan = new Map(legalMoves.map(move => [move.san, move]));

  let node = getTrie(openings);
  for (const san of history) {
    node = node.children.get(san);
    if (!node) return null;
  }

  const frequency = new Map();
  for (const [san, nextNode] of node.children) {
    if (legalBySan.has(san)) frequency.set(san, nextNode.lineCount);
  }
  const candidates = [...frequency.keys()];
  if (!candidates.length) return null;

  const fen = chess.fen();
  const recent = options.recentChoices instanceof Map ? options.recentChoices.get(fen) : null;
  const varied = candidates.length > 1 && recent ? candidates.filter(san => san !== recent) : candidates;
  const pool = varied.length ? varied : candidates;
  const weights = pool.map(san => 1 + Math.log2(frequency.get(san) || 1));
  const total = weights.reduce((sum, weight) => sum + weight, 0);
  const rng = typeof options.random === 'function' ? options.random : Math.random;
  const randomValue = Number(rng());
  let ticket = Math.max(0, Math.min(0.999999999, Number.isFinite(randomValue) ? randomValue : 0)) * total;
  let chosen = pool[pool.length - 1];
  for (let i = 0; i < pool.length; i += 1) {
    ticket -= weights[i];
    if (ticket < 0) { chosen = pool[i]; break; }
  }
  if (options.recentChoices instanceof Map) options.recentChoices.set(fen, chosen);
  return legalBySan.get(chosen) || null;
}
