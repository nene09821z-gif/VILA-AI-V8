/** Pure guards for keeping asynchronous engine analysis bound to one board position. */
export function isCurrentAnalysisSession({ active, sessionFen, currentFen, sessionEpoch, currentEpoch }) {
  return Boolean(active && typeof sessionFen === 'string' && sessionFen.length > 0 &&
    sessionFen === currentFen && Number.isInteger(sessionEpoch) && sessionEpoch === currentEpoch);
}

/** Keep the deepest record for each MultiPV lane without mutating the caller's array. */
export function mergeAnalysisVariation(variations, parsed, fen) {
  if (!Array.isArray(variations) || !parsed || !Number.isInteger(parsed.multipv) || parsed.multipv < 1) {
    return Array.isArray(variations) ? variations : [];
  }
  const next = variations.slice();
  const record = { ...parsed, fen };
  const index = next.findIndex(item => item.multipv === record.multipv);
  if (index < 0) next.push(record);
  else if (record.depth >= (Number(next[index].depth) || 0)) next[index] = record;
  return next.sort((a, b) => a.multipv - b.multipv);
}
