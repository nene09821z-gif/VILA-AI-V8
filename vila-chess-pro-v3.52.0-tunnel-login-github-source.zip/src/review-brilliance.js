/** Sacrifice detection for the "Thiên tài" (brilliant) review label. Pure; chess.js is injected. */
const VALUE = Object.freeze({ p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 });

function balance(chess, color) {
  let mine = 0;
  let theirs = 0;
  for (const row of chess.board()) {
    for (const piece of row) {
      if (!piece) continue;
      if (piece.color === color) mine += VALUE[piece.type] || 0; else theirs += VALUE[piece.type] || 0;
    }
  }
  return mine - theirs;
}

function applyUci(chess, uci) {
  const text = String(uci || '');
  if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(text)) return null;
  try { return chess.move({ from: text.slice(0, 2), to: text.slice(2, 4), ...(text[4] ? { promotion: text[4] } : {}) }); } catch { return null; }
}

/**
 * True when `playedUci` gives up at least `threshold` points of material that the engine's own
 * continuation (`pvAfterUci`, starting with the opponent's reply) does not win back within 4 plies.
 */
export function detectSacrifice({ fenBefore, playedUci, pvAfterUci = [], mover, ChessConstructor, threshold = 2 }) {
  if (typeof ChessConstructor !== 'function' || !['w', 'b'].includes(mover)) return false;
  try {
    const chess = new ChessConstructor(fenBefore);
    const start = balance(chess, mover);
    if (!applyUci(chess, playedUci)) return false;
    let lowest = Infinity;
    const line = (Array.isArray(pvAfterUci) ? pvAfterUci : []).slice(0, 4);
    let played = 0;
    for (const uci of line) {
      if (!applyUci(chess, uci)) break;
      played += 1;
      if (played % 2 === 0) lowest = Math.min(lowest, balance(chess, mover));
    }
    if (!Number.isFinite(lowest)) return false; // not enough line to see whether material comes back
    const final = balance(chess, mover);
    // Judge the position after the mover's reply (even ply): a trade that is repaid is not a sacrifice.
    const settled = played % 2 === 0 ? final : lowest;
    return start - settled >= threshold;
  } catch {
    return false;
  }
}
