/** Recognize the longest named opening prefix without rescanning every ECO line. */
const trieCache = new WeakMap();

function buildTrie(openings) {
  const root = { children: new Map(), endings: [], firstDescendant: null };
  for (const opening of openings) {
    const line = opening?.san;
    if (!Array.isArray(line) || line.length < 2) continue;
    let node = root;
    for (const san of line) {
      const key = String(san);
      if (!node.children.has(key)) node.children.set(key, { children: new Map(), endings: [], firstDescendant: opening });
      node = node.children.get(key);
    }
    node.endings.push(opening);
  }
  return root;
}

function getTrie(openings) {
  const cached = trieCache.get(openings);
  if (cached?.length === openings.length) return cached.root;
  const root = buildTrie(openings);
  trieCache.set(openings, { length: openings.length, root });
  return root;
}

export function recognizeOpening(history = [], openings = [], options = {}) {
  const minPlies = Math.max(1, Math.min(12, Number(options.minPlies ?? 2) || 2));
  if (!Array.isArray(history) || history.length < minPlies || !Array.isArray(openings)) return null;
  let node = getTrie(openings);
  let bestEnding = null;
  for (let index = 0; index < history.length; index += 1) {
    node = node.children.get(history[index]);
    if (!node) return bestEnding;
    if (node.endings.length) bestEnding = node.endings[0];
  }
  // If the played history exactly names an entry, prefer that over a longer branch.
  if (node.endings.length) return node.endings[0];
  return node.firstDescendant || bestEnding;
}
