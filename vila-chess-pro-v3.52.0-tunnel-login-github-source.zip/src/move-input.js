/** True only while an asynchronous move prompt still belongs to the active position. */
export function isMoveContextCurrent(request, current) {
  if (!request || !current || typeof request !== 'object' || typeof current !== 'object') return false;
  if (!Number.isInteger(request.epoch) || !Number.isInteger(current.epoch)) return false;
  if (typeof request.fen !== 'string' || typeof current.fen !== 'string') return false;
  return request.epoch === current.epoch && request.fen === current.fen;
}
