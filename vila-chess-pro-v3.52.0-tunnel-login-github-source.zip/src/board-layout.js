/**
 * Compute a safe board frame width in CSS pixels for mobile WebViews.
 * CSS pixels are used intentionally: Android physical DPI must not be applied
 * a second time, otherwise the board becomes too small on high-density phones.
 */
export function calculateBoardFrameMaxWidth({ containerWidth, viewportWidth, viewportHeight } = {}) {
  const width = Number(containerWidth);
  const viewportW = Number(viewportWidth);
  const viewportH = Number(viewportHeight);
  const available = Number.isFinite(width) && width > 0
    ? width
    : (Number.isFinite(viewportW) && viewportW > 0 ? viewportW : 0);
  if (available <= 0) return 0;

  // In short landscape viewports, reserve room for the app header, tabs, and
  // clock/controls. Respect the real height budget instead of imposing a
  // minimum that could overflow very short Android WebViews.
  if (Number.isFinite(viewportW) && Number.isFinite(viewportH) && viewportW > viewportH && viewportH <= 520) {
    const heightBudget = Math.max(1, Math.floor(viewportH - 154));
    return Math.max(1, Math.floor(Math.min(available, heightBudget)));
  }
  return Math.max(1, Math.floor(available));
}

export function calculateChessSquareSize(boardWidth) {
  const width = Number(boardWidth);
  return Number.isFinite(width) && width > 0 ? width / 8 : 0;
}
