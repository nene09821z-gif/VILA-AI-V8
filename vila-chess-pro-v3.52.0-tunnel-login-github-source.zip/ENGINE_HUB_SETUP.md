# Hồ sơ engine và bot của Cờ Vua ViLa

Cờ Vua ViLa tích hợp Stockfish khi engine asset khởi chạy được, cùng các profile offline VILA điều chỉnh hàm đánh giá, ngân sách tìm kiếm, độ ngẫu nhiên và repertoire khai cuộc. Các profile mới gồm Mentor, Hunter, Sentinel, Strategist, Endgame Pro và Chaos.

Các profile là cấu hình của engine cục bộ, không phải sáu engine độc lập hoặc mô hình neural đã train riêng. Không dùng nhãn Elo như kết quả thực nghiệm: cần benchmark nhiều ván, đổi màu và khai cuộc cân bằng để ước lượng sức mạnh.

Trong phòng đấu, chọn **Thiết lập trận → Chọn đối thủ/phong cách bot**. Một số profile cần engine worker sẵn sàng; nếu gặp fallback, kiểm tra chip trạng thái engine và log build.
