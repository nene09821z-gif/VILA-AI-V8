# Kiểm thử Cờ Vua ViLa v3.46.0

## Thay đổi được rà soát

- Giao diện phòng đấu ưu tiên mobile; gom bốn thao tác thiết lập, danh sách nước, phân tích và khai cuộc vào menu `Công cụ`.
- Bổ sung lựa chọn nhanh `0.5+0` (30 giây / Siêu chớp), `1+0` (Bullet), `3+2` (Blitz) và `10+0` (Rapid). Các điều khiển vẫn cập nhật cùng lựa chọn `clockPreset` hiện có.
- Xóa markup nhãn nhận diện khai cuộc dưới bàn cờ và thẻ gợi ý màu vàng. Nước gợi ý vẫn cập nhật mũi tên trên bàn cờ và thông báo trạng thái ngắn.
- Thanh điều hướng điện thoại ưu tiên Trang chủ, Chơi, Ghép trận, Câu đố và Thêm. Lối tắt tài khoản được hiện lại ở kích thước mobile, dẫn tới luồng tài khoản/cộng đồng sẵn có.
- Gỡ nguồn nhạc Gymnopédie cũ khỏi mã chạy. Nhạc nền tích hợp dùng Web Audio tổng hợp tại chỗ; phát YouTube vẫn là lựa chọn bên ngoài do người dùng chủ động chọn.
- Thêm CSS mobile mới và 3 trường hợp kiểm thử hồi quy cho thay đổi giao diện/nhạc.

## Kết quả

| Kiểm tra | Kết quả |
|---|---:|
| `npm run test:static` | **254/254 đạt** |
| `node --check` trên các tệp JavaScript/MJS | **131/131 đạt** |
| Kiểm thử tập trung `music-ui` và `mobile-upgrade-v346` | **4/4 đạt** |
| `npm test` đầy đủ | **256/260 đạt; 4 không khởi chạy** |

Bốn tệp bị chặn khi chạy toàn bộ suite là `tests/alternate-engine.test.js`, `tests/chess.test.js`, `tests/social.test.js` và `tests/v3-25-features.test.js`. Runtime báo `ERR_MODULE_NOT_FOUND`: chưa cài dependency `chess.js` (ba tệp) và `express` (một tệp). ZIP mã nguồn không chứa `node_modules`; cần cài dependency trên môi trường build rồi chạy lại `npm test`.

## Chưa xác minh

- Chưa chạy production build Vite hoặc build APK bằng Gradle ở môi trường hiện tại; vì vậy không ghi nhận APK đã tạo thành công.
- Chưa thao tác trực tiếp trên OPPO/WebView thật để đo độ mượt kéo quân. Mã đã giữ nguyên cơ chế drag/pointer hiện có và bổ sung `touch-action`, nhưng cần kiểm tra thiết bị thực tế.
- Ghép trận người thật và hồ sơ máy chủ cần triển khai backend, cấu hình URL HTTPS/OAuth theo lựa chọn đăng nhập, và cần đối thủ khác đang chờ. Giao diện/luồng hiện hữu không thể tự tạo người chơi trực tuyến.
- Các chủ đề nhạc tích hợp được tổng hợp offline; đường dẫn YouTube tùy chọn phụ thuộc kết nối mạng và quyền phát nhúng của video.

## Cách kiểm tra lại

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
```

Chỉ coi bản Android là sẵn sàng sau khi pipeline GitHub Actions hoàn tất các bước build web, đồng bộ Capacitor, `assembleDebug` và kiểm thử APK trên thiết bị.
