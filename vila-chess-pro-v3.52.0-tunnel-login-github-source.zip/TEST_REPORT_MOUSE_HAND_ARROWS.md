# Báo cáo kiểm thử — Chuột ảo, nhận diện tay và mũi tên phân tích

## Phạm vi đã kiểm tra

- Thanh vẽ phân tích nổi: vị trí độc lập, di chuyển, thu gọn, ẩn/hiện, chọn trực tiếp bốn màu, mũi tên/khoanh ô/xóa dấu vẽ.
- Chuột ảo: mở/tắt bảng, con trỏ bằng `transform`/`requestAnimationFrame`, giữ-thả được nối vào luồng Pointer Events của bàn cờ hiện tại.
- Nhận diện bàn tay tùy chọn: MediaPipe Hand Landmarker chạy trong Web Worker, nhận diện đầu ngón trỏ, cử chỉ chụm để nhấn/giữ và tách để thả; bàn di cảm ứng vẫn dùng được nếu camera không hỗ trợ hoặc không tải được mô hình.
- Script thêm quyền `android.permission.CAMERA` cho dự án Capacitor được sinh ra; chạy idempotent và được gọi từ cả hai workflow GitHub Actions, sau đó được xác minh trước build.

## Kết quả

- Kiểm thử mục tiêu: **24/24 đạt** với lệnh:

```bash
node --test tests/annotation-toolbar-layout.test.js tests/mobile-match-layout-regression.test.js tests/mobile-performance.test.js tests/release-audit.test.js tests/camera-permission-script.test.js
```

- Kiểm tra cú pháp JavaScript/MJS toàn bộ thư mục `src`, `scripts`, `tests`: **137/137 tệp đạt** bằng `node --check`.
- `package.json` hợp lệ; test xác nhận workflow Android gọi script thêm quyền camera.

## Chưa xác minh

- Không xác nhận build Vite/Gradle hoặc APK hoàn chỉnh trong phiên này: dependencies chưa được cài đầy đủ trong môi trường hiện tại.
- Chưa đo độ trễ/khả năng nhận diện trên OPPO A17k hoặc thiết bị Android thực tế; phần nhận diện tay cần internet để tải thư viện, WASM và mô hình từ CDN/Google Storage. Nếu không dùng được, người chơi vẫn có thể điều khiển bằng vùng trượt cảm ứng.
- Camera chỉ bật khi người chơi chủ động bấm nút; mã ứng dụng chuyển khung hình sang Worker cục bộ và không gửi ảnh/video camera lên API backend của VILA. MediaPipe có thể gửi số liệu sử dụng/hiệu năng theo tài liệu nhà cung cấp; thư viện/WASM/mô hình được tải từ CDN/Google Storage.
