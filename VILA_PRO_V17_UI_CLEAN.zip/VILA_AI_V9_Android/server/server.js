/**
 * VILA AI Server — proxy Gemini + Groq (tránh CORS trên app)
 * Env:
 *   PORT=8787
 *   GEMINI_API_KEY=...
 *   GROQ_API_KEY=...
 *   CORS_ORIGIN=*
 */
const express = require('express');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const GROQ_KEY = process.env.GROQ_API_KEY || '';
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/openai';
const GEMINI_NATIVE = 'https://generativelanguage.googleapis.com/v1beta/models';
const GROQ_BASE = 'https://api.groq.com/openai/v1';
const MAX_OUTPUT_TOKENS = Math.min(Number(process.env.MAX_OUTPUT_TOKENS || 16384), 32768);

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '18mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Provider');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
});

const sleep = ms => new Promise(r => setTimeout(r, ms));
const retryable = status => [408, 429, 500, 502, 503, 504].includes(Number(status));

const GEMINI_FALLBACKS = [
  'gemini-3.5-flash-lite',
  'gemini-3.5-flash',
  'gemini-3.6-flash',
  'gemini-3.7-flash',
  'gemini-3.8-flash',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite'
];

function normalizeMessages(messages) {
  return Array.isArray(messages) ? messages.filter(Boolean).slice(-120) : [];
}

function parseRetryAfter(response, data) {
  const header = response.headers.get('retry-after');
  if (header) {
    const seconds = Number(header);
    if (Number.isFinite(seconds)) return Math.min(12000, Math.max(500, seconds * 1000));
    const when = Date.parse(header);
    if (Number.isFinite(when)) return Math.min(12000, Math.max(500, when - Date.now()));
  }
  const msg = String(data?.error?.message || data?.message || '');
  const match = msg.match(/retry(?:Delay| after)?[\s:=]+([0-9]+(?:\.[0-9]+)?)s/i);
  return match ? Math.min(12000, Math.max(500, Number(match[1]) * 1000)) : 1800;
}

async function geminiChat(body) {
  if (!GEMINI_KEY) {
    const error = new Error('Server chưa có GEMINI_API_KEY.');
    error.status = 500;
    throw error;
  }
  const requested = String(body?.model || '').trim();
  const messages = normalizeMessages(body?.messages);
  const models = [requested, ...GEMINI_FALLBACKS].filter(Boolean)
    .filter((m, i, a) => a.indexOf(m) === i);

  let lastErr;
  for (const model of models) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await fetch(`${GEMINI_BASE}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${GEMINI_KEY}`
          },
          body: JSON.stringify({
            model,
            messages,
            max_tokens: Math.min(Number(body?.max_tokens) || MAX_OUTPUT_TOKENS, MAX_OUTPUT_TOKENS),
            temperature: body?.temperature ?? 0.7
          })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          const err = new Error(data?.error?.message || data?.message || `Gemini HTTP ${response.status}`);
          err.status = response.status;
          err.retryAfterMs = parseRetryAfter(response, data);
          if (retryable(response.status) && attempt < 2) {
            await sleep(err.retryAfterMs || 1200);
            continue;
          }
          lastErr = err;
          break;
        }
        const aiReply = data?.choices?.[0]?.message?.content || '';
        if (!aiReply) {
          lastErr = new Error('Gemini không trả nội dung.');
          lastErr.status = 502;
          break;
        }
        return { ok: true, aiReply, model, provider: 'gemini' };
      } catch (e) {
        lastErr = e;
        if (attempt < 2) await sleep(1000);
      }
    }
  }
  throw lastErr || new Error('Gemini thất bại.');
}

async function groqChat(body) {
  if (!GROQ_KEY) {
    const error = new Error('Server chưa có GROQ_API_KEY.');
    error.status = 500;
    throw error;
  }
  const model = String(body?.model || 'openai/gpt-oss-120b').trim();
  const messages = normalizeMessages(body?.messages);
  const response = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${GROQ_KEY}`
    },
    body: JSON.stringify({
      model,
      messages,
      max_tokens: Math.min(Number(body?.max_tokens) || 8192, 16384),
      temperature: body?.temperature ?? 0.6
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data?.error?.message || data?.message || `Groq HTTP ${response.status}`);
    err.status = response.status;
    throw err;
  }
  const aiReply = data?.choices?.[0]?.message?.content || '';
  if (!aiReply) {
    const err = new Error('Groq không trả nội dung.');
    err.status = 502;
    throw err;
  }
  return { ok: true, aiReply, model, provider: 'groq' };
}

async function geminiSearch(body) {
  if (!GEMINI_KEY) {
    const error = new Error('Server chưa có GEMINI_API_KEY.');
    error.status = 500;
    throw error;
  }
  const model = String(body?.model || 'gemini-2.5-flash').replace(/^models\//, '');
  const messages = normalizeMessages(body?.messages);
  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }]
  }));
  const response = await fetch(
    `${GEMINI_NATIVE}/${model}:generateContent?key=${encodeURIComponent(GEMINI_KEY)}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents,
        tools: [{ google_search: {} }]
      })
    }
  );
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(data?.error?.message || `Search HTTP ${response.status}`);
    err.status = response.status;
    throw err;
  }
  const aiReply = (data?.candidates?.[0]?.content?.parts || []).map(p => p?.text || '').join('').trim();
  const chunks = data?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sources = chunks.map(c => c?.web).filter(i => i?.uri)
    .filter((item, index, list) => list.findIndex(x => x.uri === item.uri) === index)
    .slice(0, 8);
  let answer = aiReply;
  if (sources.length) {
    answer += '\n\n### Nguồn Web\n' + sources.map((s, i) => `${i + 1}. [${s.title || s.uri}](${s.uri})`).join('\n');
  }
  return { ok: true, aiReply: answer, model, provider: 'gemini' };
}

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'VILA AI Server',
    providers: {
      gemini: Boolean(GEMINI_KEY),
      groq: Boolean(GROQ_KEY)
    },
    endpoints: {
      chat: '/api/chat',
      search: '/api/search',
      health: '/api/health',
      config: '/api/config'
    },
    maxTokens: MAX_OUTPUT_TOKENS,
    time: new Date().toISOString()
  });
});

app.get('/api/config', (_req, res) => {
  res.json({
    ok: true,
    serverMode: true,
    providers: {
      gemini: Boolean(GEMINI_KEY),
      groq: Boolean(GROQ_KEY)
    },
    endpoints: {
      chat: '/api/chat',
      search: '/api/search',
      health: '/api/health',
      config: '/api/config'
    },
    maxTokens: MAX_OUTPUT_TOKENS,
    multimodal: true,
    webSearch: true
  });
});

app.post('/api/chat', async (req, res) => {
  try {
    const body = req.body || {};
    const provider = String(body.provider || req.headers['x-provider'] || 'gemini').toLowerCase();
    if (provider === 'groq') {
      res.json(await groqChat(body));
    } else {
      res.json(await geminiChat(body));
    }
  } catch (error) {
    res.status(Number(error.status) || 500).json({
      message: error.message,
      status: Number(error.status) || 500,
      retryAfterMs: error.retryAfterMs || 0
    });
  }
});

app.post('/api/search', async (req, res) => {
  try {
    res.json(await geminiSearch(req.body || {}));
  } catch (error) {
    res.status(Number(error.status) || 500).json({
      message: error.message,
      status: Number(error.status) || 500,
      retryAfterMs: error.retryAfterMs || 0
    });
  }
});

app.get('/', (_req, res) => {
  res.type('html').send(`<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>VILA AI Server</title>
<style>
body{font-family:system-ui;background:#0a0a0a;color:#f5f5f5;padding:32px;line-height:1.5}
code,pre{background:#1a1a1a;padding:2px 6px;border-radius:6px}
a{color:#8ab4f8}
.card{border:1px solid #2a2a2a;border-radius:12px;padding:16px;margin:12px 0;background:#111}
.btn{display:inline-block;margin-top:8px;padding:8px 14px;border-radius:999px;background:#fff;color:#0a0a0a;text-decoration:none;font-weight:600;font-size:13px}
</style></head>
<body>
<h1>VILA AI Server</h1>
<p>Proxy Gemini + Groq — tránh lỗi CORS trên app Android.</p>
<div class="card">
  <div>Health: <a href="/api/health">/api/health</a></div>
  <div>Chat: <code>POST /api/chat</code> body <code>{ provider, model, messages }</code></div>
  <div>Search: <code>POST /api/search</code></div>
</div>
<p>Đặt key trong file <code>.env</code>: <code>GEMINI_API_KEY</code>, <code>GROQ_API_KEY</code></p>
</body></html>`);
});

app.use((_req, res) => res.status(404).json({ message: 'Not found' }));

app.listen(PORT, HOST, () => {
  console.log(`VILA AI Server http://${HOST}:${PORT}`);
  console.log(`  Gemini key: ${GEMINI_KEY ? 'OK' : 'MISSING'}`);
  console.log(`  Groq key:   ${GROQ_KEY ? 'OK' : 'MISSING'}`);
});
