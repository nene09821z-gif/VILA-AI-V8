VILA AI Server — Gemini + Groq proxy
====================================

1) Cài Node.js 18+
2) cd server
3) copy .env.example -> .env và điền GEMINI_API_KEY / GROQ_API_KEY
4) npm install
5) npm start   hoặc  ./start-vila-server.sh  hoặc  start-vila-server.bat

App Android:
- Mở Cài đặt → dán URL server (vd http://192.168.1.10:8787)
- Khi có Server Proxy, app gọi /api/chat thay vì gọi API trực tiếp (hết CORS)

Endpoints:
  GET  /api/health
  GET  /api/config
  POST /api/chat    { provider: "gemini"|"groq", model, messages }
  POST /api/search  (Gemini web search)
