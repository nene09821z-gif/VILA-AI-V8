/* VILA endpoints — Gemini tách riêng (chỉnh ở đây, không cần động vào index.html).
 * Groq giữ nguyên endpoint cũ. Không còn VILA Server. */
window.VILA_ENDPOINTS = Object.freeze({
  gemini: Object.freeze({
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai', // chat/completions (OpenAI-compatible)
    nativeBase: 'https://generativelanguage.googleapis.com/v1beta',     // models, interactions, Veo
    videoModel: 'veo-3.1-generate-preview'                              // đổi nếu Google ra bản Veo mới
  }),
  groq: Object.freeze({ baseUrl: 'https://api.groq.com/openai/v1' })
});
