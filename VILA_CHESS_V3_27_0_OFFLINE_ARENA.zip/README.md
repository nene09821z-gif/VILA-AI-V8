# VILA Chess v3.27.0 — offline-first chess arena

VILA Chess is a mobile-first chess app source package for GitHub Actions builds. It uses `chess.js` for legal moves and the bundled Stockfish 19 package for real UCI search. The ZIP contains source code, not a prebuilt or device-verified APK.

## What changed in v3.27.0

- Removed language-model provider settings, provider profiles, built-in chat-model presets, the `/api/ai/chat` and `/api/ai/models` routes, and the backend code used only by those routes. When the app loads older saved settings, it rewrites the settings object through a strict whitelist so legacy provider keys, model IDs, and chat endpoints are not copied forward.
- Replaced the former AI chat/coach screen with a local analysis workspace: Stockfish multi-variation analysis, full-game review, opening study, and puzzles.
- Added a compact charcoal/lime interface and changed the mobile bottom navigation to put Home, Play, Arena, and Puzzles directly on the bottom bar. Opening library, review, history, and settings remain available from the More/menu view.
- Added actual UCI MultiPV candidate collection for the offline arena. Style profiles choose among Stockfish-searched candidates and use individual opening repertoires. If Stockfish cannot start, the style arena may use the existing local JavaScript search fallback.
- Added visible three-stage puzzle progression: Easy for 0–9 solves, Medium for 10–19, and Hard from 20 solves onward. Puzzles are generated locally and validated against the chess rules; this is not a claim that the app embeds or reproduces Chess.com’s curated puzzle database.
- Kept original SVG piece artwork, PGN export, analysis graph, move classifications, clocks, premove/drag handling, opening library, local ratings, and optional community/Lichess features.
- Kept the community-server address/access token in a clearly separate optional section because it serves accounts, friends and online Lichess/community routes—not language-model chess bots. The offline board and local bots do not require that server.

## Important strength and engine notes

- Stockfish is a real chess engine; strength on a phone depends on the packaged build, available CPU, time per move, depth and engine settings.
- The VILA personalities are **profiles**, not the original LCZero/Leela, Ethereal, Berserk or other branded engine binaries. They have different opening repertoires and selection biases over real Stockfish MultiPV lines; the app does not claim their individual Elo has been independently measured.
- The Elo control is an approximate Stockfish UCI strength setting, not an independently benchmarked rating. No bot is labelled “verified 2700 Elo” in this release because no tournament benchmark has been run.
- Review labels such as “excellent”, “mistake” or “brilliant” are engine/heuristic-based hints, not official Chess.com labels. Puzzle positions are generated offline rather than copied from Chess.com.

## Build from the ZIP

1. Upload or extract the ZIP into a GitHub repository with the workflow files retained.
2. Use Node.js 22, matching the included GitHub Actions workflow.
3. Run `npm install` to install dependencies and copy Stockfish assets through the package postinstall script.
4. Run `npm test` and `npm run build` locally if dependencies are available. The build validates required Stockfish assets before running Vite.
5. For Android, run the repository’s GitHub Actions workflow `Build VILA Chess APK`. It installs dependencies, runs tests, builds the web app, syncs Capacitor, verifies the Android source and packages a debug APK artifact.

Useful scripts:

- `npm run dev:web` — Vite frontend.
- `npm run dev:api` — optional community/Lichess backend.
- `npm run test:static` — focused static and unit tests.
- `npm run build` — copy/validate Stockfish assets and build the Vite bundle.
- `npm run android:sync` — build web assets and sync them to an existing Capacitor Android project.

## Offline vs optional online features

Offline features include legal moves, Stockfish play, locally generated style bots, opening-book replies, puzzles, analysis, review, clocks, annotations and local game history. Optional community accounts, friends, OAuth and Lichess integration require a real backend deployment and the corresponding server configuration. GitHub Pages alone cannot run the Node backend. No shared provider API key is packaged, and language-model provider/chat routes are not part of this version.

## Verification status

The included test report records exactly which source/syntax/static tests ran in the packaging environment. It distinguishes those checks from full dependency installation, Vite/Capacitor/Gradle builds, live backend integration and physical Android testing. A ZIP must still pass GitHub Actions before release; that workflow is the build gate for the produced APK.
