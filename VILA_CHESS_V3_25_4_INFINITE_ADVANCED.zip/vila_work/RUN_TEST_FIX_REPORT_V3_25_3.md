# VILA Chess V3.25.3 — Test Repair Report

## Failure shown in CI
`tests/v3-25-features.test.js`: `offline puzzle generator yields a legal single-solution puzzle` failed because `generateOfflinePuzzle()` returned `null` after its three 15-second attempts. The generator discarded candidates whenever a full root scan exceeded its node/time budget, then continued generating positions until the full budget expired.

## Changes
1. Bound the expensive search phase to a short portion of the requested budget and reduced the per-scan limits.
2. Added `createFallbackMatePuzzle()`: random legal K+Q-v-K candidates are checked for exactly one checkmating move; a symmetry-variant composed mate-in-one position is the final safety net.
3. The fallback reports a solution only after enumerating legal moves and confirming that exactly one delivers checkmate.
4. Added a regression test checking both the legality of the winning move and uniqueness of the mate-in-one solution.
5. Updated puzzle UI copy and the zero-ply status label to avoid claiming a composed fallback came from a randomized game history.

## Checks actually performed
- `node --check` across all JavaScript/MJS files in `src`, `server`, `scripts`, and `tests` — passed.
- `npm run test:static` — **202 passed, 0 failed**.
- The dependency-backed `tests/v3-25-features.test.js` was not executable here because `npm install --no-audit --no-fund` timed out before dependencies were available. No claim is made that the full suite or APK build has passed. Re-run the repository's GitHub Actions workflow to complete dependency-backed verification.
