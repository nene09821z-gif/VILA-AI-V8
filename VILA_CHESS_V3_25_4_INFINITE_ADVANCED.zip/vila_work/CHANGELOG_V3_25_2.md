# v3.25.2
- Stockfish 10 (npm `stockfish@10.0.2`, pure asm.js, classical eval) added as an optional engine: Settings -> "Engine Stockfish" -> "Stockfish 10 · cải tiến tìm lỗi". Used by the shared worker for hints, analysis and "Phân tích toàn ván" (mistake/blunder finding).
  - Declared as `optionalDependencies` alias `stockfish-10`; `scripts/copy-engine.mjs` bundles it as `public/engine/stockfish-10.js` and records `sf10` in `engine-manifest.json`. Missing package = warning only (set `REQUIRE_STOCKFISH_10=1` to make it mandatory).
  - Init fallback chain: Stockfish 10 -> Lite -> ASM-JS. Hash capped at 16 MB for this build; UCI_Elo/UCI_LimitStrength are not supported by SF10 and are ignored by the engine.
- Offline: new `public/sw.js` service worker (registered only in production web builds, not in Capacitor) caches the app shell, pieces, openings and all engine files; API/cross-origin calls are never intercepted. Online/offline toasts added.
- Comment fix in `search-core.js` (null-move pruning is enabled and guarded).
- Tests: `tests/sf10-offline.test.js` (7 tests). Full `npm test` still requires `npm install` (chess.js, express) - 4 files cannot load in an offline sandbox.
- Fix: offline puzzle generator never produced a puzzle on CI (its depth-3 scan hit a 40k-node cap, so every candidate was discarded). Now uses a cheap depth-2 pre-filter and larger node/time budgets; the test retries up to 3 times because the generator is randomized.
