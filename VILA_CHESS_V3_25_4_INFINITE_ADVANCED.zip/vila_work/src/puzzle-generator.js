// Infinite offline puzzle generator (v3.25). No network, no Stockfish: it plays a random
// opening line + a few engine-guided moves, then asks VILA's own search to score every legal
// move. A position becomes a puzzle only when ONE move is clearly best (mate, or a large
// material/tactical gain) and the runner-up is much worse.
import { Chess } from 'chess.js';
import { searchBestMove, scoreRootMoves } from './engines/search-core.js';
import { evaluateVilaClassic } from './engines/vila-classic.js';
import { OPENINGS } from './openings.js';

const MATE = 30000;
const FILLER = Object.freeze({ id: 'puzzle-filler', name: 'filler', defaultDepth: 2, maxNodes: 4000, maxTimeMs: 40, style: 'balanced', lateMoveReduction: false, randomTop: 1 });
const yieldToUi = () => new Promise(resolve => setTimeout(resolve, 0));
const pick = (list, rng) => list[Math.min(list.length - 1, Math.floor(rng() * list.length))];
const fenKey = fen => String(fen || '').trim().split(/\s+/).slice(0, 4).join(' ');

function buildStartPosition(rng, openings) {
  const chess = new Chess();
  const usable = openings.filter(o => Array.isArray(o.san) && o.san.length >= 4);
  if (usable.length && rng() < 0.85) {
    const line = pick(usable, rng).san;
    const cut = Math.max(4, Math.min(line.length, 4 + Math.floor(rng() * (line.length - 3))));
    for (const san of line.slice(0, cut)) { try { chess.move(san); } catch { break; } }
  }
  // Mix in guided + loose moves so the middlegame is varied and often tactical.
  const extra = 4 + Math.floor(rng() * 14);
  for (let i = 0; i < extra && !chess.isGameOver(); i += 1) {
    const legal = chess.moves({ verbose: true });
    if (!legal.length) break;
    let move;
    if (rng() < 0.45) {
      const found = searchBestMove(chess, FILLER, evaluateVilaClassic, { depth: 2, maxTimeMs: 40, varietyCp: 70, random: rng });
      move = found ? legal.find(m => `${m.from}${m.to}${m.promotion || ''}` === found.uci) : null;
    }
    if (!move) {
      const loud = legal.filter(m => m.captured || m.san.includes('+'));
      move = rng() < 0.3 && loud.length ? pick(loud, rng) : pick(legal, rng);
    }
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  }
  return chess;
}

function classify(chess, best, gap) {
  const move = chess.moves({ verbose: true }).find(m => `${m.from}${m.to}${m.promotion || ''}` === best.uci);
  if (!move) return null;
  const clone = new Chess(chess.fen());
  clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
  let theme = 'Chiến thuật';
  if (clone.isCheckmate()) theme = 'Chiếu hết trong 1';
  else if (best.score >= MATE - 200) theme = 'Chiếu hết cưỡng bức';
  else if (move.promotion) theme = 'Phong cấp';
  else if (move.captured && clone.isCheck()) theme = 'Ăn quân kèm chiếu';
  else if (move.captured) theme = 'Thắng quân';
  else if (clone.isCheck()) theme = 'Chiếu mở đường';
  else theme = 'Nước im lặng (quiet move)';
  const level = gap >= 700 ? 'Dễ' : gap >= 350 ? 'Vừa' : 'Khó';
  return { theme, level, san: move.san, mateInOne: clone.isCheckmate() };
}

function randomUnit(rng) {
  const value = Number(rng());
  if (!Number.isFinite(value)) return Math.random();
  return Math.max(0, Math.min(0.999999999, value));
}

function minimalFen(whiteKing, whiteQueen, blackKing, turn = 'w') {
  const board = Array.from({ length: 8 }, () => Array(8).fill(''));
  board[whiteKing.y][whiteKing.x] = 'K';
  board[whiteQueen.y][whiteQueen.x] = 'Q';
  board[blackKing.y][blackKing.x] = 'k';
  const ranks = [];
  for (let y = 7; y >= 0; y -= 1) {
    let row = '';
    let empty = 0;
    for (let x = 0; x < 8; x += 1) {
      const piece = board[y][x];
      if (!piece) empty += 1;
      else {
        if (empty) row += String(empty);
        row += piece;
        empty = 0;
      }
    }
    if (empty) row += String(empty);
    ranks.push(row);
  }
  return `${ranks.join('/')} ${turn} - - 0 1`;
}

function validateMateInOneFen(fen) {
  let chess;
  try {
    chess = new Chess(fen);
    // KQ-v-K fallback positions must be legal and not already finished.
    if (chess.isGameOver() || chess.isCheck()) return null;
    const blackToMove = new Chess(fen.replace(' w ', ' b '));
    // The non-moving king may not already be in check in a legal position.
    if (blackToMove.isCheck()) return null;
  } catch {
    return null;
  }

  const mates = [];
  for (const move of chess.moves({ verbose: true })) {
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const isMate = chess.isCheckmate();
    chess.undo();
    if (isMate) mates.push(move);
    if (mates.length > 1) return null;
  }
  if (mates.length !== 1) return null;
  const move = mates[0];
  return {
    fen,
    best: `${move.from}${move.to}${move.promotion || ''}`,
    san: move.san,
    plies: 0,
    mateOnly: true,
    theme: 'Chiếu hết trong 1',
    level: 'Dễ'
  };
}

/**
 * Fast, completely offline safety net. It searches legal K+Q-v-K positions and only
 * accepts a position with exactly one checkmating move. If random sampling misses,
 * symmetry variants of a known legal mate-in-one motif keep puzzle generation reliable.
 */
export function createFallbackMatePuzzle({ rng = Math.random, attempts = 160, excludeFens = [] } = {}) {
  const excluded = new Set(excludeFens.map(fenKey).filter(Boolean));
  const count = Math.max(1, Math.min(5000, Math.floor(Number(attempts) || 160)));
  for (let attempt = 0; attempt < count; attempt += 1) {
    const squares = [
      Math.floor(randomUnit(rng) * 64),
      Math.floor(randomUnit(rng) * 64),
      Math.floor(randomUnit(rng) * 64)
    ];
    if (new Set(squares).size !== 3) continue;
    const [wk, wq, bk] = squares.map(square => ({ x: square % 8, y: Math.floor(square / 8) }));
    // Kings may never occupy adjacent squares.
    if (Math.max(Math.abs(wk.x - bk.x), Math.abs(wk.y - bk.y)) <= 1) continue;
    const puzzle = validateMateInOneFen(minimalFen(wk, wq, bk));
    if (puzzle && !excluded.has(fenKey(puzzle.fen))) return puzzle;
  }

  // Guaranteed composed fallback, varied by board symmetries (no pawns/castling rights).
  const transforms = [
    p => ({ x: p.x, y: p.y }),
    p => ({ x: 7 - p.x, y: p.y }),
    p => ({ x: p.x, y: 7 - p.y }),
    p => ({ x: 7 - p.x, y: 7 - p.y }),
    p => ({ x: p.y, y: p.x }),
    p => ({ x: p.y, y: 7 - p.x }),
    p => ({ x: 7 - p.y, y: p.x }),
    p => ({ x: 7 - p.y, y: 7 - p.x })
  ];
  const base = [{ x: 5, y: 5 }, { x: 6, y: 5 }, { x: 7, y: 7 }]; // Kf6, Qg6, Kh8
  const first = Math.floor(randomUnit(rng) * transforms.length);
  for (let i = 0; i < transforms.length; i += 1) {
    const transform = transforms[(first + i) % transforms.length];
    const [wk, wq, bk] = base.map(transform);
    const puzzle = validateMateInOneFen(minimalFen(wk, wq, bk));
    if (puzzle && !excluded.has(fenKey(puzzle.fen))) return puzzle;
  }
  return null;
}

/**
 * Produce one validated puzzle. Resolves with { fen, best, san, theme, level, plies, mateOnly }.
 * Search for a stronger tactical position briefly, then use a verified mate-in-one puzzle
 * rather than spending the full budget returning null on constrained devices/CI.
 */
export async function generateOfflinePuzzle({ rng = Math.random, budgetMs = 6000, openings = OPENINGS, excludeFens = [], difficulty = 0 } = {}) {
  const tier = Math.max(0, Math.min(3, Math.floor(Number(difficulty) || 0)));
  const excluded = new Set(excludeFens.map(fenKey).filter(Boolean));
  const normalizedBudget = Math.max(100, Math.min(30000, Number(budgetMs) || 6000));
  // Reserve most of the caller's budget for fallback/UI recovery instead of unbounded retries.
  const searchDeadline = Date.now() + Math.min(1500, Math.max(250, normalizedBudget * 0.2));
  while (Date.now() < searchDeadline) {
    await yieldToUi();
    let chess;
    try { chess = buildStartPosition(rng, openings); } catch { continue; }
    if (chess.isGameOver() || chess.moves().length < 3) continue;
    // Cheap depth-2 pre-filter: most random positions have no clear best move, so reject them
    // before paying for the deeper scans. (The old 40k-node cap on a depth-3 scan of ~35 root
    // moves was exhausted almost every time, so scoreRootMoves returned null and no puzzle was ever kept.)
    const quick = scoreRootMoves(chess, evaluateVilaClassic, { depth: 2, maxNodes: 50000 + tier * 10000, maxTimeMs: 300 + tier * 60 });
    if (!quick || quick.length < 3 || quick[0].score < 150 + tier * 35 || quick[0].score - quick[1].score < 100 + tier * 35) continue;
    const scored = scoreRootMoves(chess, evaluateVilaClassic, { depth: 3 + (tier >= 2 ? 1 : 0), maxNodes: 80000 + tier * 12000, maxTimeMs: 600 + tier * 80 });
    if (!scored || scored.length < 3) continue;
    const [best, second] = scored;
    const gap = best.score - second.score;
    const mating = best.score >= MATE - 200;
    const winning = best.score >= 220 && best.score < MATE - 200;
    if (!(mating || winning) || gap < 160 + tier * 35) continue;
    const info = classify(chess, best, gap);
    if (!info) continue;
    // Skip "free capture of a hanging queen" trivia when a quiet theme was possible: keep variety
    // by occasionally rejecting plain captures so quiet/mating ideas appear more often.
    if (info.theme === 'Thắng quân' && rng() < 0.4) continue;
    // Deeper verification of the single best move reduces horizon-effect false puzzles.
    const verify = scoreRootMoves(chess, evaluateVilaClassic, { depth: 4 + (tier >= 3 ? 1 : 0), maxNodes: 100000 + tier * 15000, maxTimeMs: 850 + tier * 100 });
    if (!verify || verify[0].uci !== best.uci || verify[0].score - (verify[1]?.score ?? -MATE) < 140 + tier * 30) continue;
    const candidate = { fen: chess.fen(), best: best.uci, plies: chess.history().length, mateOnly: info.mateInOne, ...info };
    if (excluded.has(fenKey(candidate.fen))) continue;
    if (!isPuzzleAnswerLegal(candidate)) continue;
    return candidate;
  }
  return createFallbackMatePuzzle({ rng, attempts: 1200, excludeFens: [...excluded] });
}

/** Verify the advertised UCI answer is legal from the exact puzzle position. */
export function isPuzzleAnswerLegal(puzzle) {
  if (!puzzle || typeof puzzle.fen !== 'string' || typeof puzzle.best !== 'string') return false;
  try {
    const chess = new Chess(puzzle.fen);
    const uci = puzzle.best;
    const move = chess.moves({ verbose: true }).find(item => `${item.from}${item.to}${item.promotion || ''}` === uci);
    if (!move) return false;
    if (puzzle.mateOnly) {
      chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
      if (!chess.isCheckmate()) return false;
      chess.undo();
      let mates = 0;
      for (const candidate of chess.moves({ verbose: true })) {
        chess.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) });
        if (chess.isCheckmate()) mates += 1;
        chess.undo();
        if (mates > 1) return false;
      }
      return mates === 1;
    }
    return true;
  } catch { return false; }
}
