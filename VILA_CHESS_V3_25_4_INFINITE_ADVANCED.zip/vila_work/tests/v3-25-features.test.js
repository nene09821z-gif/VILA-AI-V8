import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import { OPENINGS } from '../src/openings.js';
import { adaptPayloadForProviderError } from '../server/ai-request.js';
import { createFallbackMatePuzzle, generateOfflinePuzzle, isPuzzleAnswerLegal } from '../src/puzzle-generator.js';
import { chooseAlternateMove } from '../src/alternate-engine-core.js';

test('opening library is larger and every line is legal', () => {
  assert.ok(OPENINGS.length >= 300, `found ${OPENINGS.length}`);
  for (const o of OPENINGS) { const c = new Chess(); for (const san of o.san) c.move(san); }
});
test('pieces are shrunk and board effects exist in CSS', () => {
  const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
  for (const token of ['--piece-fill:80%', '.square.in-check', '.square.fx-capture', '.square.fx-castle']) assert.ok(css.includes(token), token);
});
test('provider payload adapts to max_completion_tokens', () => {
  const next = adaptPayloadForProviderError({ max_tokens: 9, temperature: .3 }, "Unsupported parameter: 'max_tokens'. Use 'max_completion_tokens'");
  assert.equal(next.max_completion_tokens, 9); assert.equal('max_tokens' in next, false);
});
test('offline engine returns a legal move', () => {
  const uci = chooseAlternateMove(new Chess().fen(), { profile: 'classic', depth: 3, maxTimeMs: 400 });
  assert.ok(new Chess().moves({ verbose: true }).some(m => m.from + m.to === uci.slice(0, 4)));
});
test('offline puzzle generator yields a legal single-solution puzzle', async () => {
  // The generator is randomized and time-boxed (and returns null when a budget is spent, which the app
  // handles by falling back to Stockfish), so allow a few independent attempts before declaring failure.
  let p = null;
  for (let attempt = 0; attempt < 3 && !p; attempt += 1) p = await generateOfflinePuzzle({ budgetMs: 15000 });
  assert.ok(p, 'puzzle expected');
  const c = new Chess(p.fen);
  assert.ok(c.moves({ verbose: true }).some(m => m.from + m.to + (m.promotion || '') === p.best));
});

test('offline puzzle fallback has exactly one legal mate-in-one solution', () => {
  let seed = 0.371;
  const rng = () => { seed = (seed + 0.61803398875) % 1; return seed; };
  const puzzle = createFallbackMatePuzzle({ rng, attempts: 160 });
  assert.ok(puzzle, 'verified fallback puzzle expected');
  const chess = new Chess(puzzle.fen);
  const matingMoves = [];
  for (const move of chess.moves({ verbose: true })) {
    chess.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    if (chess.isCheckmate()) matingMoves.push(`${move.from}${move.to}${move.promotion || ''}`);
    chess.undo();
  }
  assert.equal(matingMoves.length, 1, 'exactly one move must deliver checkmate');
  assert.equal(matingMoves[0], puzzle.best);
});

