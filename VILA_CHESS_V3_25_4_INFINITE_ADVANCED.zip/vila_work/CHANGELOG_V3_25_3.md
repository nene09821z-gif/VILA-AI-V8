# VILA Chess V3.25.3

## Fixed
- Fixed the CI failure in `offline puzzle generator yields a legal single-solution puzzle`.
- Added an offline fallback that validates legal K+Q-v-K positions and accepts only positions with exactly one mate-in-one move.
- Added symmetric composed mate-in-one positions as a final fallback if random sampling does not find a candidate.
- Bounded the costly VILA search phase and reduced root-scan time/node budgets so low-powered phones and CI do not spend the entire request repeatedly discarding timed-out candidates.
- Added a regression test that verifies the fallback has exactly one legal mate-in-one solution.
- Updated puzzle-screen copy so the fallback and Stockfish's analysis role are described accurately.

## Verification note
- JavaScript syntax checks are included in the accompanying repair report.
- The full Node test suite requires npm dependencies (`chess.js`, `express`, and others). In this repair environment, `npm install` timed out, so the full suite could not be truthfully marked as passed. GitHub Actions should rerun `npm test` after dependencies install.
