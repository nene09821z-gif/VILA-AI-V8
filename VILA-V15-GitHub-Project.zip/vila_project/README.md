# VILA V15

GitHub-ready Android Gradle project for VILA AI Studio V15.

## Build on GitHub

1. Upload the contents of this project to your repository.
2. Open **Actions**.
3. Select **VILA V15 - Build APK**.
4. Press **Run workflow**.
5. Download `VILA-V15-debug-apk` from Artifacts.

The web application is stored in `app/src/main/assets/`.
