import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const main = read('src/main.js');
const css = read('src/style.css');
const pkg = JSON.parse(read('package.json'));

 test('production and build dependencies remain pinned to explicit versions', () => {
  assert.deepEqual(pkg.dependencies, { 'chess.js': '1.4.0', express: '5.1.0', stockfish: '19.0.1', 'stockfish-10': 'npm:stockfish.js@10.0.2' });
  assert.deepEqual(pkg.devDependencies, { '@capacitor/android': '7.4.3', '@capacitor/cli': '7.4.3', '@capacitor/core': '7.4.3', concurrently: '9.2.1', vite: '7.1.7' });
  assert.equal(pkg.optionalDependencies?.['stockfish-10'], undefined);
});

test('play-room navigation and game actions remain wired', () => {
  assert.equal(pkg.version, '3.46.3');
  for (const view of ['play', 'arena', 'puzzles', 'history', 'coach', 'openings', 'settings']) {
    assert.match(main, new RegExp(`data-play-rail-view="${view}"`));
  }
  for (const id of ['undoMove', 'redoMove', 'hintMove', 'clearBoardSelection', 'newGame']) {
    assert.match(main, new RegExp(`id="${id}"`));
  }
  assert.match(css, /\.play-tool-rail/);
  assert.match(css, /\.player-card-opponent/);
  assert.match(css, /\.match-action-bar\s*\{[^}]*grid-template-columns:\s*repeat\(5/);
});

test('board selection mutates only previously/now highlighted squares, not all 64 cells', () => {
  const start = main.indexOf('function updateDragSelection(');
  const end = main.indexOf('\nfunction wireBoardSquareClicks', start);
  const fn = main.slice(start, end);
  assert.match(fn, /new Set\(\[\.\.\.boardHighlightedSquares, \.\.\.nextHighlightedSquares\]\)/);
  assert.doesNotMatch(fn, /for\s*\(const \[squareName, cell\] of boardSquareMap\)/);
});

test('legal move generation is deferred until an actual drag crosses the movement threshold', () => {
  const start = main.indexOf('function wireBoardPointerDrag(');
  const end = main.indexOf('\nfunction getGameResult', start);
  const fn = main.slice(start, end);
  const down = fn.slice(fn.indexOf("board.addEventListener('pointerdown'"), fn.indexOf("board.addEventListener('pointermove'"));
  const move = fn.slice(fn.indexOf("board.addEventListener('pointermove'"), fn.indexOf('const finish = async event'));
  assert.doesNotMatch(down, /game\.moves\(\{ square: from, verbose: true \}\)/);
  assert.match(move, /Math\.hypot\(event\.clientX - state\.x, event\.clientY - state\.y\) < 4/);
  assert.match(move, /state\.legal = state\.isPremove \? getPremoveLegalMoves/);
  assert.match(fn, /squareAtBoardPoint\(event\.clientX, event\.clientY, state\.boardRect\)/);
  assert.doesNotMatch(fn, /document\.elementFromPoint\(event\.clientX, event\.clientY\)/);
});
