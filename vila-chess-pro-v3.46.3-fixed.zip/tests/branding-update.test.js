import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

function pngSize(file) {
  const bytes = fs.readFileSync(path.join(root, file));
  assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${file} must be a PNG`);
  assert.ok(bytes.length > 100, `${file} should not be an empty placeholder`);
  return { width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) };
}

test('v3.46.3 user-supplied logo is used as app and web brand icon', () => {
  const html = read('index.html');
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '3.46.3');
  assert.match(html, /covua-vila-brand-icon\.png\?v=349/);
  assert.match(html, /favicon\.ico\?v=349/);
  assert.match(html, /manifest\.webmanifest\?v=349/);
  assert.match(main, /covua-vila-logo\.webp/);
  assert.match(sw, /covua-vila-brand-icon\.png\?v=349/);
  assert.match(sw, /v3\.46\.3/);
  assert.ok(fs.existsSync(path.join(root, 'public/covua-vila-logo.webp')));
  assert.ok(fs.existsSync(path.join(root, 'resources/branding/covua-vila-logo-original.png')));
  assert.ok(pngSize('public/covua-vila-brand-icon.png').width >= 1024);
  assert.ok(fs.statSync(path.join(root, 'public/covua-vila-brand-icon.png')).size > 100000, 'source logo mark must stay sharp at high resolution');
  assert.deepEqual(pngSize('public/pwa-icon-512.png'), { width: 512, height: 512 });
  assert.deepEqual(pngSize('public/pwa-icon-192.png'), { width: 192, height: 192 });
});

test('memorial image is preserved in Settings and cached for offline viewing', () => {
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  assert.match(main, /memory-keepsake/);
  assert.match(main, /src="\.\/vila-memory-monument\.webp"/);
  assert.match(main, /alt="Tượng đài kỷ niệm hành trình xây dựng Cờ Vua ViLa"/);
  assert.match(sw, /\.\/vila-memory-monument\.webp/);
  assert.ok(fs.statSync(path.join(root, 'public/vila-memory-monument.webp')).size < 700000, 'memorial should be compressed for mobile');
});

test('all Android launcher density icons were regenerated and stay valid square PNGs', () => {
  const expected = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
  for (const [density, size] of Object.entries(expected)) {
    for (const name of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) {
      const file = `resources/android-icons/mipmap-${density}/${name}`;
      assert.deepEqual(pngSize(file), { width: size, height: size }, `${file} should match Android density`);
    }
  }
  const manifest = JSON.parse(read('public/manifest.webmanifest'));
  assert.equal(manifest.name, 'Cờ Vua ViLa');
  assert.ok(manifest.icons.some(icon => icon.src === './pwa-icon-512.png'));
});
