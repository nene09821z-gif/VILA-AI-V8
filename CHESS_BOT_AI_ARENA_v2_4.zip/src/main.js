import { Chess } from 'chess.js';
import { resolveEngineProfile } from './engine-profile.js';
import './style.css';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const STORAGE_KEY = 'tubor.chess.settings.v1';
const lichessTokenKey = 'tubor.chess.lichessToken.session';
const DEFAULTS = {
  aiMode: 'gemini',
  endpoint: 'https://generativelanguage.googleapis.com',
  model: 'gemini-3.8-flash',
  apiKey: '',
  aiProfiles: [],
  backendUrl: '',
  backendAccessToken: '',
  temperature: 0.3,
  botSkill: 20,
  botStrengthMode: 'max',
  botElo: 2600,
  botDepth: 18,
  botEngine: 'auto',
  botEnginePreferenceSet: false,
  assistantName: 'Chess Bot AI'
};
let settings = loadSettings();
let currentView = 'play';
let game = new Chess();
let mode = 'stockfish'; // stockfish, ai, local
let humanColor = 'w';
let orientation = 'w';
let selected = null;
let selectedTargets = [];
let botThinking = false;
let currentOpening = null;
let lastMove = null;
let engineWorker = null;
let engineReady = false;
let engineFailed = false;
let engineQueue = [];
let engineSearchActive = false;
let pendingEngineRequest = null;
let mainEngineTimer = null;
let gameEpoch = 0;
let mainEngineSearchEpoch = -1;
let mainEngineSearchFen = '';
let queuedMainEngineMove = false;
let arenaGame = new Chess();
let arenaRunning = false;
let arenaStopRequested = false;
let arenaAbortController = null;
let arenaLastMove = null;
let arenaPgnHeaders = {};
let arenaLastPgnResult = '*';
let arenaPgnArchive = [];
let arenaLastResult = '';
let arenaCurrentPlayers = { w: null, b: null };
let arenaGameCounter = 0;
let arenaLastNote = '';
let arenaTournamentSummary = '';
let arenaSelectedLeague = new Set(['stockfish', 'current']);
let arenaFallbackMoves = new Map();
let activeOnlineGame = null;
let activeLichessUsername = sessionStorage.getItem('tubor.chess.lichessUsername') || '';
let onlineStreamController = null;
let lastExplorerData = null;
let chatMessages = [];
let toastTimer = null;

function loadSettings() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    const merged = { ...DEFAULTS, ...stored };
    // Migrate the previous version's default Lite choice to adaptive mode.
    // Preserve Lite only when a user explicitly saved an engine preference.
    if (!stored.botEnginePreferenceSet && stored.botEngine === 'lite-single') merged.botEngine = 'auto';
    return merged;
  } catch { return { ...DEFAULTS }; }
}
function saveSettings() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}
function apiUrl(path) {
  const base = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  return `${base}${path}`;
}
async function apiFetch(path, options = {}) {
  const response = await fetch(apiUrl(path), { ...options, headers: { ...(options.headers || {}), ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}), ...(options.body && typeof options.body === 'string' ? { 'Content-Type': 'application/json' } : {}) } });
  const type = response.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
  if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
  return data;
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function toast(message, type = '') {
  const element = $('#toast');
  if (!element) return;
  element.textContent = message;
  element.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.className = 'toast'; }, 3300);
}
function setView(view) {
  currentView = view;
  $$('.tab').forEach(tab => tab.classList.toggle('active', tab.dataset.view === view));
  renderView();
}
function pieceGlyph(piece) {
  const map = { wk: '♔', wq: '♕', wr: '♖', wb: '♗', wn: '♘', wp: '♙', bk: '♚', bq: '♛', br: '♜', bb: '♝', bn: '♞', bp: '♟' };
  return map[`${piece.color}${piece.type}`] || '';
}
function squareColor(square) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 1 ? 'dark' : 'light';
}
function renderBoard() {
  const board = $('#board');
  if (!board) return;
  const rows = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const legalTargetSet = new Set(selectedTargets.map(move => move.to));
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = game.get(sq);
    const isLastFrom = lastMove && (lastMove.from === sq || lastMove.to === sq);
    const checkKing = game.isCheck() && piece?.type === 'k' && piece.color === game.turn();
    const isSelected = selected === sq;
    const targetMoves = selectedTargets.filter(move => move.to === sq);
    const capture = targetMoves.length && piece;
    const classes = ['square', squareColor(sq), isSelected ? 'selected' : '', legalTargetSet.has(sq) ? (capture ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-move' : '', checkKing ? 'in-check' : ''].filter(Boolean).join(' ');
    const glyph = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}" aria-label="${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}">${pieceGlyph(piece)}</span>` : '';
    const coord = orientation === 'w' ? (colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : '') + (rowIndex === 7 && colIndex === 7 ? `<span class="coord file-coord">${file}</span>` : '') : (colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : '') + (rowIndex === 7 && colIndex === 7 ? `<span class="coord file-coord">${file}</span>` : '');
    html += `<button type="button" class="${classes}" data-square="${sq}" aria-label="Ô ${sq}">${glyph}${targetMoves.length && !capture ? '<span class="move-dot"></span>' : ''}${coord}</button>`;
  }));
  board.innerHTML = html;
  $$('.square', board).forEach(square => square.addEventListener('click', () => handleSquareClick(square.dataset.square)));
  $('#boardStatus')?.replaceChildren(document.createTextNode(positionStatus()));
  const moveList = $('#moveList');
  if (moveList) renderMoveList(moveList);
  const fenBox = $('#fenText');
  if (fenBox) fenBox.textContent = game.fen();
  const pgnBox = $('#pgnText');
  if (pgnBox) pgnBox.textContent = game.pgn();
  const evalBox = $('#evalNumber');
  if (evalBox && !engineSearchActive) evalBox.textContent = '—';
  $('#turnChip')?.replaceChildren(document.createTextNode(game.turn() === 'w' ? 'Lượt Trắng' : 'Lượt Đen'));
  $('#resignBtn')?.toggleAttribute('disabled', game.isGameOver());
}
function positionStatus(chess = game) {
  if (chess.isCheckmate()) return `Chiếu hết — ${chess.turn() === 'w' ? 'Đen' : 'Trắng'} thắng`;
  if (chess.isStalemate()) return 'Hòa do hết nước đi';
  if (chess.isThreefoldRepetition()) return 'Hòa do lặp lại thế cờ';
  if (chess.isInsufficientMaterial()) return 'Hòa do không đủ quân chiếu hết';
  if (chess.isDraw()) return 'Ván cờ hòa';
  return `${chess.turn() === 'w' ? 'Trắng' : 'Đen'} đang đi${chess.isCheck() ? ' — đang bị chiếu!' : ''}`;
}
function renderMoveList(element) {
  const history = game.history();
  if (!history.length) { element.innerHTML = '<div class="empty-state">Nước đi của bạn sẽ xuất hiện ở đây.</div>'; return; }
  let rows = '';
  for (let i = 0; i < history.length; i += 2) {
    rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2) + 1}.</span><span class="move-san">${esc(history[i])}</span><span class="move-san">${esc(history[i + 1] || '…')}</span></div>`;
  }
  element.innerHTML = rows;
  element.scrollTop = element.scrollHeight;
}
function handleSquareClick(square) {
  if (arenaRunning) { toast('Đấu trường AI đang dùng Stockfish; hãy dừng trận trước khi chơi bàn chính.'); return; }
  if (game.isGameOver() || botThinking) return;
  if (mode !== 'local' && game.turn() !== humanColor) { toast(mode === 'lichess' ? 'Đang chờ đối thủ đi.' : 'Đang đến lượt bot.'); return; }
  const piece = game.get(square);
  if (selected && selectedTargets.some(m => m.to === square)) {
    const choices = selectedTargets.filter(m => m.to === square);
    const promotion = choices.find(m => m.promotion)?.promotion;
    if (promotion) choosePromotion(game.turn()).then(type => type && playMove(selected, square, type));
    else playMove(selected, square);
    return;
  }
  if (piece && (mode === 'local' || piece.color === game.turn())) {
    selected = square;
    selectedTargets = game.moves({ square, verbose: true });
  } else {
    selected = null;
    selectedTargets = [];
  }
  renderBoard();
}
function choosePromotion(color) {
  return new Promise(resolve => {
    const root = $('#modalRoot');
    root.innerHTML = `<div class="modal-backdrop"><div class="modal-card"><h3>Phong cấp tốt</h3><p>Chọn quân muốn phong cấp.</p><div class="promotion-options">${['q','r','b','n'].map(type => `<button data-promotion="${type}" class="promotion-choice ${color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph({ color, type })}<small>${({ q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã' })[type]}</small></button>`).join('')}</div><button id="cancelPromotion" class="secondary-btn full-width">Hủy</button></div></div>`;
    $$('[data-promotion]', root).forEach(button => button.addEventListener('click', () => { root.innerHTML = ''; resolve(button.dataset.promotion); }));
    $('#cancelPromotion', root).addEventListener('click', () => { root.innerHTML = ''; resolve(null); });
  });
}
function playMove(from, to, promotion) {
  try {
    const move = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!move) return;
    gameEpoch += 1;
    lastMove = { from: move.from, to: move.to };
    selected = null; selectedTargets = []; currentOpening = null;
    if (mode === 'lichess') submitLichessMove(`${move.from}${move.to}${move.promotion || ''}`);
    onMoveComplete();
  } catch (error) { toast(`Nước đi không hợp lệ: ${error.message}`); }
}
function onMoveComplete() {
  renderView();
  if (game.isGameOver()) {
    botThinking = false;
    const outcome = game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.';
    toast(outcome, 'success');
    return;
  }
  if (['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true;
    renderView();
    setTimeout(() => {
      if (mode === 'stockfish') askStockfishMove();
      else if (mode === 'ai') askAiMove();
    }, 220);
  }
  if (currentView === 'play') queryOpeningExplorer(false);
}
function freshGame({ startFen = null } = {}) {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi tạo ván khác.'); return; }
  gameEpoch += 1;
  queuedMainEngineMove = false;
  if (engineSearchActive && !pendingEngineRequest) { try { engineWorker?.postMessage('stop'); } catch {} }
  if (mode === 'lichess') mode = 'stockfish';
  stopOnlineStream();
  game = startFen ? new Chess(startFen) : new Chess();
  selected = null; selectedTargets = []; lastMove = null; botThinking = false; currentOpening = null;
  renderView();
  if (['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true;
    setTimeout(() => mode === 'stockfish' ? askStockfishMove() : askAiMove(), 250);
  }
}
function undoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi hoàn tác.'); return; }
  if (mode === 'lichess') { toast('Không thể tự hoàn tác ván Lichess; hãy dùng chức năng takeback trên Lichess.'); return; }
  if (!game.history().length || botThinking) return;
  game.undo();
  if (mode !== 'local' && game.history().length && game.turn() !== humanColor) game.undo();
  gameEpoch += 1;
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; currentOpening = null;
  renderView();
}

function initEngine() {
  try {
    const selectedEngine = resolveEngineProfile(settings.botEngine, { deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency });
    const engineFile = selectedEngine === 'full-single' ? 'stockfish-19-single.js' : 'stockfish-19-lite-single.js';
    const enginePath = new URL(`${import.meta.env.BASE_URL}engine/${engineFile}`, window.location.href).href;
    engineWorker = new Worker(enginePath);
    engineWorker.onmessage = event => {
      const line = typeof event.data === 'string' ? event.data : String(event.data?.data || event.data || '');
      if (line.includes('uciok')) {
        engineReady = true;
        $('#engineStatus').innerHTML = `<i></i> Stockfish ${selectedEngine === 'full-single' ? 'Full' : 'Lite'} sẵn sàng`; 
        $('#engineStatus').classList.add('ready');
        engineWorker.postMessage('isready');
      }
      if (line.includes('readyok')) runEngineQueue();
      const scoreMatch = line.match(/\bscore (cp|mate) (-?\d+)/);
      if (scoreMatch && $('#evalNumber') && engineSearchActive) {
        const score = scoreMatch[1] === 'mate' ? `M${scoreMatch[2]}` : `${(Number(scoreMatch[2]) / 100).toFixed(1)}`;
        $('#evalNumber').textContent = score;
      }
      const bestMatch = line.match(/\bbestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000)/i);
      if (bestMatch) {
        if (mainEngineTimer) { clearTimeout(mainEngineTimer); mainEngineTimer = null; }
        engineSearchActive = false;
        const uci = bestMatch[1].toLowerCase();
        if (pendingEngineRequest) {
          const pending = pendingEngineRequest;
          pendingEngineRequest = null;
          clearTimeout(pending.timeout);
          if (uci === '0000') pending.reject(new Error('Stockfish không trả về nước đi trong thế cờ này.'));
          else pending.resolve(uci);
          return;
        }
        const searchedEpoch = mainEngineSearchEpoch;
        const searchedFen = mainEngineSearchFen;
        mainEngineSearchEpoch = -1;
        mainEngineSearchFen = '';
        // Discard stale results when the player starts a new game or changes mode during a search.
        if (searchedEpoch !== gameEpoch || !searchedFen || searchedFen !== game.fen()) {
          if (queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && game.turn() !== humanColor) {
            queuedMainEngineMove = false;
            setTimeout(() => askStockfishMove(), 0);
          }
          return;
        }
        if (botThinking && mode === 'stockfish' && !game.isGameOver()) {
          botThinking = false;
          applyUciMove(uci);
        }
      }
    };
    engineWorker.onerror = () => failEngine('Không tải được tệp Stockfish. Hãy chạy npm install rồi npm run build.');
    engineWorker.postMessage('uci');
  } catch (error) { failEngine('Stockfish chưa được tải. Bot dự phòng vẫn có thể đi nước hợp lệ.'); }
}
function failEngine(message) {
  engineFailed = true; engineReady = false;
  if (mainEngineTimer) { clearTimeout(mainEngineTimer); mainEngineTimer = null; }
  if (pendingEngineRequest) { const pending = pendingEngineRequest; pendingEngineRequest = null; clearTimeout(pending.timeout); pending.reject(new Error(message)); }
  const status = $('#engineStatus');
  if (status) { status.innerHTML = '<i></i> Bot dự phòng'; status.classList.remove('ready'); }
  console.warn('[Chess Bot] Stockfish unavailable:', message);
  // Do not leave a human waiting forever if the engine fails during their turn.
  if (botThinking && mode === 'stockfish' && !game.isGameOver()) {
    botThinking = false;
    const move = chooseFallbackMove();
    if (move) {
      try { const made = game.move(move); gameEpoch += 1; lastMove = { from: made.from, to: made.to }; }
      catch { /* Keep the position unchanged if the game has already changed. */ }
    }
    renderView();
    toast('Stockfish bị lỗi; đã chuyển sang bot dự phòng với nước đi hợp lệ.');
  }
}
function runEngineQueue() {
  if (!engineWorker || !engineReady || !engineQueue.length) return;
  const next = engineQueue.shift();
  if (next) next();
}
function askStockfishMove() {
  if (game.isGameOver()) { botThinking = false; renderView(); return; }
  if (pendingEngineRequest) { toast('Stockfish đang xử lý một ván khác.'); return; }
  if (engineSearchActive) { queuedMainEngineMove = true; return; }
  if (!engineWorker || !engineReady || engineFailed) {
    const move = chooseFallbackMove();
    botThinking = false;
    if (move) {
      try {
        const applied = game.move(move);
        gameEpoch += 1;
        lastMove = { from: applied.from, to: applied.to };
        toast('Stockfish chưa sẵn sàng — đang dùng bot dự phòng.', '');
      } catch { /* Ignore stale position */ }
    }
    renderView();
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = gameEpoch;
  mainEngineSearchFen = game.fen();
  const skill = Math.max(0, Math.min(20, Number(settings.botSkill ?? 8)));
  const depth = Math.max(5, Math.min(30, Number(settings.botDepth || 18)));
  $('#boardStatus') && ($('#boardStatus').textContent = 'Stockfish đang suy nghĩ…');
  $('#evalNumber') && ($('#evalNumber').textContent = '…');
  engineWorker.postMessage('stop');
  if (settings.botStrengthMode === 'elo') {
    engineWorker.postMessage('setoption name UCI_LimitStrength value true');
    engineWorker.postMessage(`setoption name UCI_Elo value ${Math.max(1320, Math.min(3190, Number(settings.botElo) || 2600))}`);
  } else {
    engineWorker.postMessage('setoption name UCI_LimitStrength value false');
    engineWorker.postMessage(`setoption name Skill Level value ${skill}`);
  }
  engineWorker.postMessage('setoption name Threads value 1');
  engineWorker.postMessage('setoption name Hash value 32');
  engineWorker.postMessage('ucinewgame');
  engineWorker.postMessage(`position fen ${game.fen()}`);
  engineWorker.postMessage(`go depth ${depth}`);
  if (mainEngineTimer) clearTimeout(mainEngineTimer);
  const watchdogMs = Math.max(60000, Math.min(180000, depth * 5000));
  mainEngineTimer = setTimeout(() => {
    mainEngineTimer = null;
    if (!botThinking || mode !== 'stockfish' || pendingEngineRequest || !engineSearchActive) return;
    try { engineWorker?.postMessage('stop'); } catch {}
    engineFailed = true; engineReady = false; engineSearchActive = false; botThinking = false;
    const status = $('#engineStatus');
    if (status) { status.innerHTML = '<i></i> Bot dự phòng'; status.classList.remove('ready'); }
    const fallback = chooseFallbackMove();
    if (fallback) {
      try { const made = game.move(fallback); gameEpoch += 1; lastMove = { from: made.from, to: made.to }; }
      catch { /* Ignore if the game position changed while timing out. */ }
    }
    renderView();
    toast('Stockfish suy nghĩ quá lâu; đã dùng bot dự phòng để ván cờ tiếp tục.');
  }, watchdogMs);
}
function chooseFallbackMove() { return chooseFallbackMoveFor(game); }
function chooseFallbackMoveFor(chess) {
  const moves = chess.moves({ verbose: true });
  if (!moves.length) return null;
  // A small material/capture/center heuristic keeps the legal-move fallback useful, but it is not Stockfish strength.
  const values = { p: 1, n: 3.1, b: 3.3, r: 5, q: 9, k: 0 };
  const scored = moves.map(move => {
    let score = Math.random() * 1.6;
    if (move.captured) score += 2 + values[move.captured] * 0.9 - values[move.piece] * 0.1;
    if (move.san.includes('+')) score += 1.1;
    if (move.san.includes('#')) score += 500;
    if (move.promotion) score += 8;
    const file = move.to.charCodeAt(0) - 97, rank = Number(move.to[1]) - 1;
    score += (3.5 - Math.abs(3.5 - file)) * 0.07 + (3.5 - Math.abs(3.5 - rank)) * 0.07;
    return { move, score };
  }).sort((a,b) => b.score - a.score);
  return scored[Math.floor(Math.random() * Math.min(4, scored.length))]?.move || scored[0].move;
}
function applyUciMove(uci) {
  try {
    const from = uci.slice(0, 2), to = uci.slice(2, 4), promotion = uci[4];
    const made = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!made) throw new Error('Stockfish returned an invalid move.');
    gameEpoch += 1;
    lastMove = { from: made.from, to: made.to };
    renderView();
    if (game.isGameOver()) toast(game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.', 'success');
    else if (currentView === 'play') queryOpeningExplorer(false);
  } catch (error) { botThinking = false; toast(`Lỗi nước đi engine: ${error.message}`); renderView(); }
}
function chessUciHistory() { return game.history({ verbose: true }).map(m => `${m.from}${m.to}${m.promotion || ''}`).join(','); }

async function askAiMove() {
  const requestEpoch = gameEpoch;
  const requestedFen = game.fen();
  const legal = game.moves({ verbose: true });
  if (!legal.length) { botThinking = false; renderView(); return; }
  const prompt = `Bạn là engine cờ vua. Chỉ chọn đúng MỘT nước trong danh sách nước hợp lệ sau, ở định dạng UCI 4 hoặc 5 ký tự (ví dụ e7e8q). Không giải thích, không Markdown. FEN: ${requestedFen}\nNước hợp lệ: ${legal.map(m => `${m.from}${m.to}${m.promotion || ''}`).join(' ')}\nHãy trả lời chỉ bằng UCI.`;
  try {
    const response = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: settings.model, temperature: 0, system: 'Tuân thủ định dạng yêu cầu. Chỉ xuất mã UCI của một nước hợp lệ.', messages: [{ role: 'user', content: prompt }] }) });
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    const uci = response.text.match(/[a-h][1-8][a-h][1-8][qrbn]?/i)?.[0];
    const allowed = legal.some(m => `${m.from}${m.to}${m.promotion || ''}` === uci);
    if (!allowed) throw new Error('AI trả về nước không hợp lệ.');
    botThinking = false; applyUciMove(uci);
  } catch (error) {
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    botThinking = false;
    toast(`AI chưa dùng được: ${error.message}. Tạm chuyển sang nước hợp lệ dự phòng.`);
    const move = chooseFallbackMove();
    if (move) { const made = game.move(move); gameEpoch += 1; lastMove = { from: made.from, to: made.to }; }
    renderView();
  }
}

// Arena: each configured model plays by proposing one UCI move from the legal-move list.
// chess.js validates every move, while Stockfish remains the tactical engine.
function arenaCandidates() {
  const candidates = [
    { id: 'stockfish', name: 'Stockfish 19 Lite · nội bộ', type: 'stockfish' },
    { id: 'current', name: `AI hiện tại · ${settings.model || 'chưa đặt model'}`, type: 'llm', aiMode: settings.aiMode, endpoint: settings.endpoint, model: settings.model, apiKey: settings.apiKey }
  ];
  for (const profile of (Array.isArray(settings.aiProfiles) ? settings.aiProfiles : []).slice(0, 20)) {
    candidates.push({ ...profile, type: 'llm' });
  }
  return candidates;
}
function arenaPlayer(id) {
  return arenaCandidates().find(player => player.id === id) || null;
}
function renderArenaOptions(selectedId) {
  return arenaCandidates().map(player => `<option value="${esc(player.id)}" ${player.id === selectedId ? 'selected' : ''}>${esc(player.name)}${player.type === 'stockfish' ? ' · engine' : ' · API'}</option>`).join('');
}
function renderArenaProfiles() {
  const profiles = (Array.isArray(settings.aiProfiles) ? settings.aiProfiles : []).slice(0, 20);
  if (!profiles.length) return '<div class="empty-state small-empty">Chưa thêm AI riêng. Hãy thêm endpoint/model bên dưới, hoặc chọn AI hiện tại trong cài đặt.</div>';
  return profiles.map(profile => `<div class="arena-profile-row"><div class="arena-profile-avatar">✦</div><div class="arena-profile-info"><b>${esc(profile.name)}</b><small>${esc(profile.model)} · ${esc(profile.aiMode === 'gemini' ? 'Gemini' : profile.aiMode === 'anthropic' ? 'Anthropic' : 'OpenAI-compatible')}</small><small class="arena-endpoint">${esc(profile.endpoint)}</small></div><button class="mini-primary arena-test-profile" type="button" data-test-profile="${esc(profile.id)}">Kiểm tra</button><button class="tiny-btn arena-delete-profile" type="button" data-delete-profile="${esc(profile.id)}" aria-label="Xóa ${esc(profile.name)}">×</button></div>`).join('');
}
function renderArenaView() {
  const players = arenaCandidates();
  const validLeague = new Set(players.map(p => p.id));
  for (const id of [...arenaSelectedLeague]) if (!validLeague.has(id)) arenaSelectedLeague.delete(id);
  if (!arenaSelectedLeague.size) { arenaSelectedLeague.add('stockfish'); arenaSelectedLeague.add('current'); }
  const leagueChecks = players.map(player => `<label class="arena-check"><input type="checkbox" class="arena-participant-check" value="${esc(player.id)}" ${arenaSelectedLeague.has(player.id) ? 'checked' : ''}/><span><b>${esc(player.name)}</b><small>${player.type === 'stockfish' ? 'Engine cục bộ · không tốn API' : `${esc(player.aiMode === 'gemini' ? 'Gemini' : player.aiMode === 'anthropic' ? 'Anthropic' : 'API tương thích OpenAI')} · gọi API theo từng lượt`}</small></span></label>`).join('');
  return `<section class="content-page arena-page">
    <div class="page-intro"><div class="eyebrow">CHESS BOT ARENA</div><h1>Đấu trường giao lưu AI</h1><p>Cho Stockfish và nhiều mô hình AI đấu với nhau tự động. Mỗi AI nhận FEN cùng danh sách nước hợp lệ; ứng dụng xác thực nước bằng luật cờ trước khi đi. Bạn có thể ghép bất kỳ hai AI đã cấu hình, hoặc chạy một giải vòng tròn giữa các AI đã chọn.</p></div>
    <div class="arena-warning"><span>ⓘ</span><p><b>Minh bạch:</b> Stockfish là engine cờ chuyên dụng; các LLM chỉ chọn nước qua API và có thể yếu hơn, chậm hoặc trả lỗi. Chess Bot sẽ kiểm tra nước đi và dùng nước dự phòng hợp lệ nếu API hỏng. Mỗi lượt LLM có thể tiêu thụ hạn mức API.</p></div>
    <div class="arena-layout">
      <div class="arena-left">
        <section class="panel arena-board-panel"><div class="arena-live-heading"><div><small class="eyebrow">VÁN ĐANG DIỄN RA</small><h2 id="arenaMatchTitle">${esc(arenaCurrentPlayers.w?.name || 'Stockfish')} vs ${esc(arenaCurrentPlayers.b?.name || 'AI hiện tại')}</h2></div><span id="arenaLiveBadge" class="arena-live-badge ${arenaRunning ? 'is-live' : ''}">${arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'}</span></div>
          <div class="arena-board-frame"><div id="arenaBoard" class="arena-board" aria-label="Bàn cờ đấu trường AI"></div></div>
          <div class="arena-status-row"><span id="arenaStatus">${esc(arenaLastResult || positionStatus(arenaGame))}</span><b id="arenaPlyCount">${arenaGame.history().length} nửa nước đi</b></div><div id="arenaFallbackNote" class="arena-fallback-note">${esc(arenaLastNote || 'Nước đi của từng AI sẽ hiển thị tại đây.')}</div>
          <div class="arena-controls"><button id="arenaRunMatch" class="primary-btn" ${arenaRunning ? 'disabled' : ''}>▶ Đấu trận này</button><button id="arenaRunLeague" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>⚔ Giải giao lưu</button><button id="arenaStop" class="danger-btn" ${arenaRunning ? '' : 'disabled'}>■ Dừng</button></div>
          <div class="arena-controls secondary-arena-controls"><button id="arenaSwapRematch" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>⇄ Đổi màu & đấu lại</button><button id="arenaReset" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>↺ Ván mới</button><button id="arenaDownloadPGN" class="secondary-btn" ${(arenaGame.history().length || arenaPgnArchive.length) ? '' : 'disabled'}>↓ Tải PGN</button></div>
          <div id="arenaLeagueSummary" class="arena-league-summary">${esc(arenaTournamentSummary || 'Chọn các đối thủ bên phải để bắt đầu giải giao lưu.')}</div>
        </section>
        <section class="panel arena-moves-panel"><div class="panel-heading"><div><small class="eyebrow">BIÊN BẢN</small><h2>Nước đi đã xác thực</h2></div><span class="small-counter" id="arenaMoveCounter">0</span></div><div id="arenaMoveList" class="move-list arena-move-list"></div></section>
      </div>
      <div class="arena-right">
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">GHÉP CẶP</small><h2>Chọn hai đối thủ</h2></div><span class="context-icon">⚔</span></div>
          <label class="field-label" for="arenaWhite">Quân Trắng</label><select id="arenaWhite" class="field">${renderArenaOptions('stockfish')}</select>
          <label class="field-label" for="arenaBlack">Quân Đen</label><select id="arenaBlack" class="field">${renderArenaOptions('current')}</select>
          <div class="two-fields"><div><label class="field-label" for="arenaDepth">Độ sâu Stockfish</label><select id="arenaDepth" class="field">${[12,16,18,20,22,24,26,28,30].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}</option>`).join('')}</select></div><div><label class="field-label" for="arenaDelay">Khoảng nghỉ</label><select id="arenaDelay" class="field"><option value="0">Nhanh nhất</option><option value="350" selected>0,35 giây</option><option value="800">0,8 giây</option><option value="1500">1,5 giây</option></select></div></div>
          <div class="two-fields"><div><label class="field-label" for="arenaPlyLimit">Giới hạn nửa nước</label><select id="arenaPlyLimit" class="field"><option value="80">80</option><option value="120" selected>120</option><option value="180">180</option><option value="240">240</option></select></div><div><label class="field-label" for="arenaSkill">Skill Stockfish</label><select id="arenaSkill" class="field">${[10,14,18,20].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}/20</option>`).join('')}</select></div></div>
          <div class="two-fields"><div><label class="field-label" for="arenaEngineMode">Giới hạn sức mạnh</label><select id="arenaEngineMode" class="field"><option value="max" selected>Tối đa</option><option value="elo">Giới hạn Elo</option></select></div><div><label class="field-label" for="arenaEngineElo">Elo mục tiêu</label><select id="arenaEngineElo" class="field">${[1320,1500,1800,2200,2600,3000,3190].map(n=>`<option value="${n}" ${n===2600?'selected':''}>${n}</option>`).join('')}</select></div></div><div class="field-hint">Skill 20 + độ sâu cao sẽ mạnh hơn nhưng chậm hơn trên điện thoại. Chọn Tối đa để Stockfish chơi hết sức; Elo chỉ là mức giới hạn ước lượng, không phải xếp hạng được chứng nhận.</div>
        </section>
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">GIẢI VÒNG TRÒN</small><h2>Chọn những AI tham gia</h2></div><span class="small-counter">${players.length}</span></div><div class="arena-participant-list">${leagueChecks}</div><div class="field-hint">Mỗi cặp chơi hai ván và đổi màu để công bằng hơn. Tối đa 6 AI (tối đa 30 ván cho một giải); mỗi nước LLM có thể tiêu thụ API. Nếu API lỗi, nước dự phòng sẽ được đánh dấu trong kết quả.</div></section>
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">THÊM NHÀ CUNG CẤP</small><h2>Thêm AI giao lưu</h2></div><span class="context-icon">＋</span></div>
          <label class="field-label" for="arenaProfileName">Tên hiển thị</label><input id="arenaProfileName" class="field" maxlength="40" placeholder="Ví dụ: DeepSeek Chess"/>
          <label class="field-label" for="arenaProviderPreset">Nhà cung cấp nhanh</label><select id="arenaProviderPreset" class="field"><option value="custom">Endpoint tùy chỉnh</option><option value="openrouter">OpenRouter · nhiều model</option><option value="openai">OpenAI API</option><option value="anthropic">Anthropic API</option><option value="gemini">Google Gemini API</option><option value="groq">Groq</option><option value="deepseek">DeepSeek</option><option value="mistral">Mistral AI</option><option value="cerebras">Cerebras</option><option value="xai">xAI</option><option value="ollama">Ollama local</option><option value="together">Together AI</option><option value="fireworks">Fireworks AI</option></select>
          <label class="field-label" for="arenaProfileMode">Kiểu API</label><select id="arenaProfileMode" class="field"><option value="openai-compatible">OpenAI-compatible</option><option value="gemini">Google Gemini</option><option value="anthropic">Anthropic Messages API</option></select>
          <label class="field-label" for="arenaProfileEndpoint">Endpoint / Base URL</label><input id="arenaProfileEndpoint" class="field" placeholder="https://api.openai.com/v1"/>
          <label class="field-label" for="arenaProfileModel">Model ID</label><input id="arenaProfileModel" class="field" placeholder="ID chính xác từ nhà cung cấp"/>
          <label class="field-label" for="arenaProfileKey">API key</label><input id="arenaProfileKey" type="password" autocomplete="off" class="field" placeholder="Key của AI này"/>
          <div class="field-hint">Hồ sơ được lưu trên thiết bị trong localStorage để dễ dùng; đừng dùng trên máy dùng chung. Bảo vệ tốt hơn bằng backend riêng, xác thực và quota.</div>
          <button id="arenaAddProfile" class="primary-btn full-width">＋ Lưu AI vào đấu trường</button><div id="arenaProfileNotice" class="connection-result"></div>
          <div class="arena-profile-list">${renderArenaProfiles()}</div>
        </section>
      </div>
    </div>
  </section>`;
}
function renderArenaPosition() {
  const board = $('#arenaBoard');
  if (!board) return;
  const rows = [8,7,6,5,4,3,2,1], files = ['a','b','c','d','e','f','g','h'];
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = arenaGame.get(sq);
    const last = arenaLastMove && (arenaLastMove.from === sq || arenaLastMove.to === sq);
    html += `<div class="arena-square ${squareColor(sq)} ${last ? 'arena-last-move' : ''}" aria-label="${sq}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${rowIndex === 7 && colIndex === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</div>`;
  }));
  board.innerHTML = html;
  const status = $('#arenaStatus');
  if (status) status.textContent = arenaRunning ? `${arenaCurrentPlayers[arenaGame.turn()]?.name || 'AI'} đang suy nghĩ…` : (arenaLastResult || positionStatus(arenaGame));
  const title = $('#arenaMatchTitle');
  if (title) title.textContent = `${arenaCurrentPlayers.w?.name || 'Stockfish'} vs ${arenaCurrentPlayers.b?.name || 'AI hiện tại'}`;
  const badge = $('#arenaLiveBadge');
  if (badge) { badge.textContent = arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'; badge.classList.toggle('is-live', arenaRunning); }
  const ply = $('#arenaPlyCount'); if (ply) ply.textContent = `${arenaGame.history().length} nửa nước đi`;
  const counter = $('#arenaMoveCounter'); if (counter) counter.textContent = String(arenaGame.history().length);
  const note = $('#arenaFallbackNote'); if (note) note.textContent = arenaLastNote || 'Các nước của AI sẽ hiện tại đây.';
  const moveList = $('#arenaMoveList');
  if (moveList) {
    const history = arenaGame.history();
    if (!history.length) moveList.innerHTML = '<div class="empty-state">Chưa có nước đi. Bắt đầu một trận để hai AI chơi tự động.</div>';
    else {
      let rows = '';
      for (let i = 0; i < history.length; i += 2) rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2)+1}.</span><span class="move-san">${esc(history[i])}</span><span class="move-san">${esc(history[i+1] || '…')}</span></div>`;
      moveList.innerHTML = rows; moveList.scrollTop = moveList.scrollHeight;
    }
  }
  ['arenaRunMatch','arenaRunLeague','arenaSwapRematch','arenaReset','arenaDownloadPGN'].forEach(id => { const button = $(`#${id}`); if (button) button.disabled = arenaRunning || (id === 'arenaDownloadPGN' && !arenaGame.history().length && !arenaPgnArchive.length); });
  const stop = $('#arenaStop'); if (stop) stop.disabled = !arenaRunning;
}
function wireArenaActions() {
  $('#arenaRunMatch')?.addEventListener('click', () => startArenaMatch($('#arenaWhite').value, $('#arenaBlack').value));
  $('#arenaRunLeague')?.addEventListener('click', runArenaLeague);
  $('#arenaStop')?.addEventListener('click', stopArenaMatch);
  $('#arenaReset')?.addEventListener('click', () => { if (arenaRunning) return; arenaGame = new Chess(); arenaLastMove = null; arenaLastResult = ''; arenaLastNote = ''; arenaLastPgnResult = '*'; arenaPgnArchive = []; renderArenaPosition(); });
  $('#arenaSwapRematch')?.addEventListener('click', () => { if (arenaRunning) return; const w = $('#arenaWhite').value; $('#arenaWhite').value = $('#arenaBlack').value; $('#arenaBlack').value = w; startArenaMatch($('#arenaWhite').value, $('#arenaBlack').value); });
  $('#arenaDownloadPGN')?.addEventListener('click', downloadArenaPgn);
  $$('.arena-participant-check').forEach(input => input.addEventListener('change', () => { if (input.checked) arenaSelectedLeague.add(input.value); else arenaSelectedLeague.delete(input.value); }));
  $$('[data-test-profile]').forEach(button => button.addEventListener('click', () => testArenaProfile(button.dataset.testProfile, button)));
  $$('[data-delete-profile]').forEach(button => button.addEventListener('click', () => {
    if (arenaRunning) return;
    const id = button.dataset.deleteProfile;
    settings.aiProfiles = (settings.aiProfiles || []).filter(profile => profile.id !== id);
    arenaSelectedLeague.delete(id); saveSettings(); renderView(); toast('Đã xóa hồ sơ AI khỏi đấu trường.');
  }));
  const presets = {
    custom: null,
    openai: { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' },
    openrouter: { mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1' },
    anthropic: { mode: 'anthropic', endpoint: 'https://api.anthropic.com' },
    gemini: { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' },
    groq: { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' },
    deepseek: { mode: 'openai-compatible', endpoint: 'https://api.deepseek.com/v1' },
    mistral: { mode: 'openai-compatible', endpoint: 'https://api.mistral.ai/v1' },
    cerebras: { mode: 'openai-compatible', endpoint: 'https://api.cerebras.ai/v1' },
    xai: { mode: 'openai-compatible', endpoint: 'https://api.x.ai/v1' },
    ollama: { mode: 'openai-compatible', endpoint: 'http://localhost:11434/v1' },
    together: { mode: 'openai-compatible', endpoint: 'https://api.together.xyz/v1' },
    fireworks: { mode: 'openai-compatible', endpoint: 'https://api.fireworks.ai/inference/v1' }
  };
  $('#arenaProviderPreset')?.addEventListener('change', event => {
    const preset = presets[event.target.value]; if (!preset) return;
    $('#arenaProfileMode').value = preset.mode; $('#arenaProfileEndpoint').value = preset.endpoint;
    const labels = { openai:'OpenAI', openrouter:'OpenRouter', anthropic:'Anthropic', gemini:'Gemini', groq:'Groq', deepseek:'DeepSeek', mistral:'Mistral', cerebras:'Cerebras', xai:'xAI', ollama:'Ollama', together:'Together AI', fireworks:'Fireworks AI' };
    if (!$('#arenaProfileName').value.trim()) $('#arenaProfileName').value = labels[event.target.value] || '';
  });
  $('#arenaProfileMode')?.addEventListener('change', event => {
    if (event.target.value === 'gemini') $('#arenaProfileEndpoint').value = 'https://generativelanguage.googleapis.com';
    else if (event.target.value === 'anthropic') $('#arenaProfileEndpoint').value = 'https://api.anthropic.com';
    else if (!$('#arenaProfileEndpoint').value.trim() || ['https://generativelanguage.googleapis.com','https://api.anthropic.com'].includes($('#arenaProfileEndpoint').value.trim())) $('#arenaProfileEndpoint').value = 'https://api.openai.com/v1';
  });
  $('#arenaAddProfile')?.addEventListener('click', saveArenaProfile);
}
async function testArenaProfile(id, button) {
  const player = arenaPlayer(id);
  if (!player) return;
  const original = button?.textContent || 'Kiểm tra';
  if (button) { button.disabled = true; button.textContent = 'Đang thử…'; }
  try {
    const response = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: player.aiMode, endpoint: player.endpoint, apiKey: player.apiKey || '', model: player.model, temperature: 0, system: 'Trả lời thật ngắn.', messages: [{ role: 'user', content: 'Reply exactly: CHESS_BOT_OK' }] }) });
    toast(`${player.name}: kết nối được (${String(response.text || '').trim().slice(0, 40)})`, 'success');
  } catch (error) { toast(`${player.name}: ${String(error.message || error).slice(0, 140)}`); }
  finally { if (button) { button.disabled = false; button.textContent = original; } }
}
function saveArenaProfile() {
  if (arenaRunning) { toast('Không thể thay đổi hồ sơ trong lúc đang đấu.'); return; }
  const name = $('#arenaProfileName')?.value.trim();
  const aiMode = $('#arenaProfileMode')?.value || 'openai-compatible';
  const endpoint = $('#arenaProfileEndpoint')?.value.trim();
  const model = $('#arenaProfileModel')?.value.trim();
  const apiKey = $('#arenaProfileKey')?.value.trim() || '';
  const notice = $('#arenaProfileNotice');
  if (!name || !endpoint || !model) { if (notice) notice.textContent = 'Hãy nhập tên, endpoint và model ID.'; return; }
  if (aiMode !== 'openai-compatible' && !apiKey) { if (notice) notice.textContent = 'Nhà cung cấp này cần API key.'; return; }
  if (!/^https?:\/\//i.test(endpoint)) { if (notice) notice.textContent = 'Endpoint phải bắt đầu bằng http:// hoặc https://.'; return; }
  const profiles = Array.isArray(settings.aiProfiles) ? settings.aiProfiles : [];
  if (profiles.length >= 20) { if (notice) notice.textContent = 'Đã đạt giới hạn 20 hồ sơ AI riêng. Hãy xóa hồ sơ không dùng trước.'; return; }
  const id = `profile-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
  settings.aiProfiles = [...profiles, { id, name, aiMode, endpoint: endpoint.replace(/\/$/, ''), model, apiKey }];
  saveSettings(); arenaSelectedLeague.add(id); renderView(); toast(`Đã thêm ${name} vào đấu trường.`, 'success');
}
function arenaDelay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function requestStockfishUci(fen, { skill = 20, depth = 18, strengthMode = 'max', elo = 3190, timeoutMs = null } = {}) {
  const effectiveTimeoutMs = Number(timeoutMs) || Math.max(60000, Math.min(180000, Number(depth || 18) * 5000));
  if (!engineWorker || engineFailed) throw new Error('Stockfish chưa sẵn sàng; kiểm tra gói engine sau npm install.');
  const readyStarted = Date.now();
  while (!engineReady && !engineFailed && Date.now() - readyStarted < 20000) await arenaDelay(100);
  if (!engineReady || engineFailed) throw new Error('Chờ Stockfish quá lâu hoặc engine lỗi.');
  if (pendingEngineRequest || engineSearchActive) throw new Error('Stockfish đang xử lý một yêu cầu khác. Hãy thử lại sau.');
  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (pendingEngineRequest?.resolve === resolve) {
        pendingEngineRequest = null; engineSearchActive = false;
        try { engineWorker.postMessage('stop'); } catch {}
        engineFailed = true; engineReady = false;
        const status = $('#engineStatus');
        if (status) { status.innerHTML = '<i></i> Bot dự phòng'; status.classList.remove('ready'); }
        reject(new Error('Stockfish quá thời gian suy nghĩ; đã chuyển sang chế độ dự phòng để tránh nhầm nước đi.'));
      }
    }, effectiveTimeoutMs);
    pendingEngineRequest = { resolve, reject, timeout };
    engineSearchActive = true;
    engineWorker.postMessage('stop');
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strengthMode === 'elo' ? 'true' : 'false'}`);
    if (strengthMode === 'elo') engineWorker.postMessage(`setoption name UCI_Elo value ${Math.max(1320, Math.min(3190, Number(elo) || 2600))}`);
    engineWorker.postMessage(`setoption name Skill Level value ${Math.max(0, Math.min(20, Number(skill) || 20))}`);
    engineWorker.postMessage('setoption name Threads value 1');
    engineWorker.postMessage('setoption name Hash value 32');
    engineWorker.postMessage('ucinewgame');
    engineWorker.postMessage(`position fen ${fen}`);
    engineWorker.postMessage(`go depth ${Math.max(5, Math.min(30, Number(depth) || 18))}`);
  });
}
function uciForMove(move) { return `${move.from}${move.to}${move.promotion || ''}`; }
async function requestModelUci(player, chess) {
  if (!player.endpoint || !player.model) throw new Error(`${player.name}: cần endpoint và model ID.`);
  if (player.aiMode !== 'openai-compatible' && !player.apiKey) throw new Error(`${player.name}: chưa có API key.`);
  const legal = chess.moves({ verbose: true });
  if (!legal.length) throw new Error('Không còn nước đi hợp lệ.');
  const legalUci = legal.map(uciForMove);
  const history = chess.history({ verbose: true }).slice(-16).map(uciForMove).join(' ');
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    if (arenaStopRequested) throw new DOMException('Đã dừng trận đấu.', 'AbortError');
    const retryHint = attempt ? '\nLần trước trả về sai định dạng. Lần này chỉ được chọn chính xác một chuỗi từ danh sách legal UCI.' : '';
    const prompt = `Bạn đang trực tiếp chơi cờ vua với vai ${chess.turn() === 'w' ? 'Trắng' : 'Đen'}. Chọn nước mạnh nhất bạn có thể tìm được.\nFEN: ${chess.fen()}\nCác nước trước đó (UCI): ${history || '(ván mới)'}\nDANH SÁCH NƯỚC HỢP LỆ UCI: ${legalUci.join(' ')}\nChỉ trả lời MỘT UCI chính xác từ danh sách, không giải thích.${retryHint}`;
    try {
      const response = await apiFetch('/api/ai/chat', {
        method: 'POST',
        signal: arenaAbortController?.signal,
        body: JSON.stringify({ mode: player.aiMode || 'openai-compatible', endpoint: player.endpoint, apiKey: player.apiKey || '', model: player.model, temperature: 0.05, system: 'Bạn là bộ chọn nước cờ. Quy tắc cờ vua tuyệt đối bắt buộc. Không bao giờ viết nước ngoài danh sách. Chỉ xuất mã UCI, không Markdown.', messages: [{ role: 'user', content: prompt }] })
      });
      const raw = String(response.text || '').replace(/```/g, '').trim().toLowerCase();
      const candidates = raw.match(/[a-h][1-8][a-h][1-8][qrbn]?/g) || [];
      const exact = candidates.find(uci => legalUci.includes(uci));
      if (exact) return exact;
      lastError = new Error(`${player.name} không trả về nước UCI hợp lệ.`);
    } catch (error) {
      if (error?.name === 'AbortError' || arenaStopRequested) throw error;
      lastError = error;
      if (attempt === 0) await arenaDelay(250);
    }
  }
  throw lastError || new Error(`${player.name} không chọn được nước hợp lệ.`);
}
async function chooseArenaUci(player, chess, depth, skill, options = {}) {
  if (player.type === 'stockfish') return requestStockfishUci(chess.fen(), { skill, depth, strengthMode: options.strengthMode || 'max', elo: options.elo || 2600 });
  try { return await requestModelUci(player, chess); }
  catch (error) {
    if (error?.name === 'AbortError' || arenaStopRequested) throw error;
    arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
    arenaLastNote = `${player.name} gặp lỗi API (${String(error.message || error).slice(0, 110)}); Chess Bot đang dùng nước dự phòng hợp lệ.`;
    renderArenaPosition();
    if (engineReady && !engineFailed && !pendingEngineRequest && !engineSearchActive) {
      try { return await requestStockfishUci(chess.fen(), { skill: 20, depth: Math.max(18, depth) }); } catch {}
    }
    const fallback = chooseFallbackMoveFor(chess);
    if (!fallback) throw new Error('Không tìm thấy nước dự phòng.');
    return uciForMove(fallback);
  }
}
function getArenaOutcome(chess, plyLimit) {
  if (chess.isCheckmate()) return { winner: chess.turn() === 'w' ? 'b' : 'w', result: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'Chiếu hết' };
  if (chess.isDraw()) return { winner: null, result: '1/2-1/2', reason: chess.isStalemate() ? 'Hòa pat' : 'Ván hòa theo luật cờ' };
  if (chess.history().length >= plyLimit) return { winner: null, result: '1/2-1/2', reason: `Chạm giới hạn ${plyLimit} nửa nước — tạm tính hòa` };
  return null;
}
async function playArenaCore(white, black, options = {}) {
  const depth = options.depth || 20, skill = options.skill ?? 20, delayMs = options.delayMs ?? 350, plyLimit = options.plyLimit || 120;
  arenaGame = new Chess(); arenaLastMove = null; arenaLastNote = ''; arenaLastResult = '';
  arenaCurrentPlayers = { w: white, b: black };
  renderArenaPosition();
  while (arenaRunning && !arenaStopRequested && !arenaGame.isGameOver() && arenaGame.history().length < plyLimit) {
    const player = arenaCurrentPlayers[arenaGame.turn()];
    arenaLastNote = `${player.name} đang tính nước đi…`; renderArenaPosition();
    let uci;
    try { uci = await chooseArenaUci(player, arenaGame, depth, skill, options); }
    catch (error) {
      if (arenaStopRequested || error?.name === 'AbortError') break;
      if (player.type === 'stockfish') arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
      arenaLastNote = `Lỗi ${player.name}: ${String(error.message || error).slice(0, 150)}`;
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      uci = uciForMove(fallback);
    }
    if (arenaStopRequested || !arenaRunning) break;
    const legal = arenaGame.moves({ verbose: true }).map(uciForMove);
    if (!legal.includes(uci)) {
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      arenaLastNote = `${player.name} trả nước không hợp lệ; đã thay bằng một nước hợp lệ.`;
      uci = uciForMove(fallback);
    }
    try {
      const made = arenaGame.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!made) throw new Error('Nước đi bị luật cờ từ chối.');
      arenaLastMove = { from: made.from, to: made.to };
    } catch (error) {
      arenaLastNote = `Bỏ qua nước không hợp lệ: ${error.message}`;
      continue;
    }
    renderArenaPosition();
    await arenaDelay(delayMs);
  }
  if (arenaGame.isGameOver() || arenaGame.history().length >= plyLimit) {
    const outcome = getArenaOutcome(arenaGame, plyLimit) || { result: '*', reason: positionStatus(arenaGame) };
    arenaLastPgnResult = outcome.result || '*';
    archiveArenaGame(white, black, arenaLastPgnResult, outcome.reason);
    arenaLastResult = `${outcome.reason} · ${outcome.result} · ${white.name} vs ${black.name}`;
    return { ...outcome, white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn() };
  }
  arenaLastPgnResult = '*';
  if (arenaGame.history().length) archiveArenaGame(white, black, '*', 'Đã dừng');
  arenaLastResult = `Đã dừng ván tại ${arenaGame.history().length} nửa nước.`;
  return { winner: null, result: '*', reason: 'Đã dừng', white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn(), stopped: true };
}
async function startArenaMatch(whiteId, blackId) {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish ở bàn Chơi cờ kết thúc rồi mới khởi động đấu trường.'); return; }
  const white = arenaPlayer(whiteId), black = arenaPlayer(blackId);
  if (!white || !black) { toast('Không tìm thấy một trong hai AI.'); return; }
  if (white.type === 'llm' && (!white.endpoint || !white.model || (white.aiMode !== 'openai-compatible' && !white.apiKey))) { toast(`Hãy cấu hình endpoint/model/API key cho ${white.name}.`); return; }
  if (black.type === 'llm' && (!black.endpoint || !black.model || (black.aiMode !== 'openai-compatible' && !black.apiKey))) { toast(`Hãy cấu hình endpoint/model/API key cho ${black.name}.`); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController(); arenaGameCounter++; arenaFallbackMoves = new Map(); arenaPgnArchive = []; arenaLastPgnResult = '*';
  renderArenaPosition();
  try {
    const result = await playArenaCore(white, black, readArenaOptions());
    if (!result.stopped) {
      const fallbackCount = arenaFallbackMoves.get(white.id) || 0;
      const otherFallback = arenaFallbackMoves.get(black.id) || 0;
      const fallbackTag = fallbackCount + otherFallback ? ` · ${fallbackCount + otherFallback} nước dùng dự phòng khi AI lỗi` : '';
      arenaTournamentSummary = `${result.white} ${result.result} ${result.black} · ${result.reason} · ${result.plies} nửa nước${fallbackTag}`;
    }
    else arenaTournamentSummary = result.reason;
    arenaLastResult = result.reason + (result.result && result.result !== '*' ? ` · ${result.result}` : '');
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Trận lỗi: ${String(error.message || error).slice(0, 180)}`; arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function readArenaOptions() {
  return { depth: Number($('#arenaDepth')?.value || 20), skill: Number($('#arenaSkill')?.value || 20), strengthMode: $('#arenaEngineMode')?.value === 'elo' ? 'elo' : 'max', elo: Number($('#arenaEngineElo')?.value || 2600), delayMs: Number($('#arenaDelay')?.value ?? 350), plyLimit: Number($('#arenaPlyLimit')?.value || 120) };
}
function stopArenaMatch() {
  if (!arenaRunning) return;
  arenaStopRequested = true;
  arenaAbortController?.abort();
  if (pendingEngineRequest && engineWorker) { try { engineWorker.postMessage('stop'); } catch {} }
  if ($('#arenaStatus')) $('#arenaStatus').textContent = 'Đang dừng sau khi yêu cầu hiện tại kết thúc…';
}
async function runArenaLeague() {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish hiện tại kết thúc.'); return; }
  const selected = [...arenaSelectedLeague].map(arenaPlayer).filter(Boolean);
  if (selected.length < 2) { toast('Hãy chọn ít nhất hai AI tham gia giải.'); return; }
  if (selected.length > 6) { toast('Để kiểm soát chi phí API, mỗi giải giới hạn tối đa 6 AI. Bỏ chọn bớt model rồi thử lại.'); return; }
  const unconfigured = selected.find(p => p.type === 'llm' && (!p.endpoint || !p.model || (p.aiMode !== 'openai-compatible' && !p.apiKey)));
  if (unconfigured) { toast(`Hãy hoàn thiện cấu hình ${unconfigured.name} trước khi chạy giải.`); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController();
  arenaPgnArchive = []; arenaLastPgnResult = '*';
  const options = readArenaOptions();
  const scores = new Map(selected.map(player => [player.id, { id: player.id, name: player.name, points: 0, wins: 0, draws: 0, losses: 0, games: 0 }]));
  const pairings = [];
  for (let i=0;i<selected.length;i++) for (let j=i+1;j<selected.length;j++) {
    pairings.push({ a:selected[i], b:selected[j], reverse:false });
    pairings.push({ a:selected[i], b:selected[j], reverse:true });
  }
  arenaFallbackMoves = new Map();
  let complete = 0;
  arenaTournamentSummary = `Đang chạy giải: 0/${pairings.length} ván · mỗi cặp đổi màu hai lượt.`;
  renderArenaPosition();
  try {
    for (let i=0;i<pairings.length;i++) {
      if (arenaStopRequested) break;
      const { a, b, reverse } = pairings[i];
      const white = reverse ? b : a, black = reverse ? a : b;
      const result = await playArenaCore(white, black, options);
      if (result.stopped) break;
      if (result.result === '1-0') { scores.get(white.id).points += 1; scores.get(white.id).wins++; scores.get(black.id).losses++; }
      else if (result.result === '0-1') { scores.get(black.id).points += 1; scores.get(black.id).wins++; scores.get(white.id).losses++; }
      else if (result.result === '1/2-1/2') { scores.get(white.id).points += .5; scores.get(black.id).points += .5; scores.get(white.id).draws++; scores.get(black.id).draws++; }
      scores.get(white.id).games++; scores.get(black.id).games++;
      complete++;
      arenaTournamentSummary = `Giải đang chạy: ${complete}/${pairings.length} ván đã xong.`;
      if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = `${arenaTournamentSummary} ${result.white} ${result.result} ${result.black}`;
      renderArenaPosition();
      await arenaDelay(200);
    }
    const table = [...scores.values()].sort((a,b)=>b.points-a.points).map((x,i)=>`${i+1}. ${x.name}: ${x.points.toFixed(1)} điểm · ${x.wins} thắng / ${x.draws} hòa / ${x.losses} thua${arenaFallbackMoves.get(x.id) ? ` · ${arenaFallbackMoves.get(x.id)} nước dự phòng` : ''}`).join('\n');
    arenaTournamentSummary = `${arenaStopRequested ? 'Giải đã dừng' : 'KẾT QUẢ GIẢI VÒNG TRÒN'} (${complete}/${pairings.length} ván)\n${table}`;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    arenaLastResult = arenaStopRequested ? 'Giải đã dừng theo yêu cầu.' : `Giải hoàn tất · ${complete} ván.`;
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Giải gặp lỗi: ${String(error.message || error).slice(0, 180)}`;
    arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function pgnEscape(value) { return String(value || '').replace(/[\\"]+/g, '').slice(0, 120); }
function archiveArenaGame(white, black, result, reason) {
  const outcome = result || '*';
  const moves = (arenaGame.pgn() || '').trim();
  const gamePgn = moves && /(?:1-0|0-1|1\/2-1\/2|\*)$/.test(moves) ? moves : `${moves}${moves ? ' ' : ''}${outcome}`;
  const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(white?.name || 'White')}"]\n[Black "${pgnEscape(black?.name || 'Black')}"]\n[Result "${outcome}"]\n[Annotator "${pgnEscape(reason || 'AI Arena')}"]`;
  arenaPgnArchive.push(`${headers}\n\n${gamePgn}`);
}
function downloadArenaPgn() {
  const pgn = arenaPgnArchive.length ? arenaPgnArchive.join('\n\n') : (() => {
    const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(arenaCurrentPlayers.w?.name || 'White')}"]\n[Black "${pgnEscape(arenaCurrentPlayers.b?.name || 'Black')}"]\n[Result "${arenaLastPgnResult}"]\n[Annotator "${pgnEscape(arenaLastResult || 'AI Arena')}"]`;
    return `${headers}\n\n${arenaGame.pgn() || '*'}`;
  })();
  const url = URL.createObjectURL(new Blob([pgn], { type: 'application/x-chess-pgn;charset=utf-8' }));
  const link = document.createElement('a'); link.href=url; link.download='chess-bot-ai-arena.pgn'; link.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
}

const OPENINGS = [
  { name: 'Khai cuộc Ý', family: 'Mở e4', eco: 'C50', line: '1.e4 e5 2.Nf3 Nc6 3.Bc4 Bc5 4.c3 Nf6 5.d4', san: ['e4','e5','Nf3','Nc6','Bc4','Bc5','c3','Nf6','d4'], note: 'Phát triển quân nhanh, nhắm vào f7 và trung tâm.' },
  { name: 'Ruy Lopez', family: 'Mở e4', eco: 'C60', line: '1.e4 e5 2.Nf3 Nc6 3.Bb5 a6 4.Ba4 Nf6 5.O-O Be7', san: ['e4','e5','Nf3','Nc6','Bb5','a6','Ba4','Nf6','O-O','Be7'], note: 'Gây áp lực lên mã c6, kiểm soát trung tâm dài hạn.' },
  { name: 'Phòng thủ Sicilian', family: 'Phòng thủ', eco: 'B20', line: '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 a6', san: ['e4','c5','Nf3','d6','d4','cxd4','Nxd4','Nf6','Nc3','a6'], note: 'Phản công cánh hậu; có rất nhiều nhánh như Najdorf và Dragon.' },
  { name: 'Phòng thủ Pháp', family: 'Phòng thủ', eco: 'C00', line: '1.e4 e6 2.d4 d5 3.Nc3 Bb4 4.e5 c5 5.a3 Bxc3+', san: ['e4','e6','d4','d5','Nc3','Bb4','e5','c5','a3','Bxc3+'], note: 'Đánh vào chuỗi tốt trung tâm của Trắng.' },
  { name: 'Caro–Kann', family: 'Phòng thủ', eco: 'B10', line: '1.e4 c6 2.d4 d5 3.Nc3 dxe4 4.Nxe4 Bf5', san: ['e4','c6','d4','d5','Nc3','dxe4','Nxe4','Bf5'], note: 'Cấu trúc chắc chắn và phát triển tượng c8 thuận lợi.' },
  { name: 'Khai cuộc Scotch', family: 'Mở e4', eco: 'C45', line: '1.e4 e5 2.Nf3 Nc6 3.d4 exd4 4.Nxd4', san: ['e4','e5','Nf3','Nc6','d4','exd4','Nxd4'], note: 'Đổi tốt trung tâm sớm, mở không gian hoạt động cho quân.' },
  { name: 'Khai cuộc Vienna', family: 'Mở e4', eco: 'C25', line: '1.e4 e5 2.Nc3 Nf6 3.f4 d5', san: ['e4','e5','Nc3','Nf6','f4','d5'], note: 'Linh hoạt, có thể chuyển sang các thế trận tấn công.' },
  { name: 'Gambit Evans', family: 'Tấn công', eco: 'C51', line: '1.e4 e5 2.Nf3 Nc6 3.Bc4 Bc5 4.b4 Bxb4 5.c3 Ba5 6.d4', san: ['e4','e5','Nf3','Nc6','Bc4','Bc5','b4','Bxb4','c3','Ba5','d4'], note: 'Hy sinh tốt để giành nhịp phát triển và mở trung tâm.' },
  { name: 'Gambit Vua', family: 'Tấn công', eco: 'C30', line: '1.e4 e5 2.f4 exf4 3.Nf3 g5 4.h4', san: ['e4','e5','f4','exf4','Nf3','g5','h4'], note: 'Lối chơi sắc bén; cần phát triển nhanh, tránh tấn công thiếu quân.' },
  { name: 'Phòng thủ Scandinavian', family: 'Phòng thủ', eco: 'B01', line: '1.e4 d5 2.exd5 Qxd5 3.Nc3 Qa5', san: ['e4','d5','exd5','Qxd5','Nc3','Qa5'], note: 'Tấn công trực tiếp tốt e4; Hậu có thể bị đuổi nếu thiếu cẩn thận.' },
  { name: 'Phòng thủ Petrov', family: 'Phòng thủ', eco: 'C42', line: '1.e4 e5 2.Nf3 Nf6 3.Nxe5 d6 4.Nf3 Nxe4 5.d4 d5', san: ['e4','e5','Nf3','Nf6','Nxe5','d6','Nf3','Nxe4','d4','d5'], note: 'Đối xứng và vững chắc, hướng đến thế cờ cân bằng.' },
  { name: 'Gambit Hậu', family: 'Mở d4', eco: 'D06', line: '1.d4 d5 2.c4 e6 3.Nc3 Nf6 4.Bg5 Be7 5.e3 O-O', san: ['d4','d5','c4','e6','Nc3','Nf6','Bg5','Be7','e3','O-O'], note: 'Trắng tranh giành trung tâm; đây thường là gambit chiến lược.' },
  { name: 'Phòng thủ Slav', family: 'Phòng thủ', eco: 'D10', line: '1.d4 d5 2.c4 c6 3.Nf3 Nf6 4.Nc3 dxc4 5.a4', san: ['d4','d5','c4','c6','Nf3','Nf6','Nc3','dxc4','a4'], note: 'Giữ chắc trung tâm và tìm thời điểm giữ hoặc trả tốt c4.' },
  { name: 'London System', family: 'Mở d4', eco: 'D00', line: '1.d4 d5 2.Bf4 Nf6 3.e3 e6 4.Nf3 c5 5.c3', san: ['d4','d5','Bf4','Nf6','e3','e6','Nf3','c5','c3'], note: 'Hệ thống dễ học, phát triển tượng f4 sớm.' },
  { name: 'King’s Indian', family: 'Phòng thủ', eco: 'E60', line: '1.d4 Nf6 2.c4 g6 3.Nc3 Bg7 4.e4 d6 5.Nf3 O-O', san: ['d4','Nf6','c4','g6','Nc3','Bg7','e4','d6','Nf3','O-O'], note: 'Đen nhường không gian trung tâm để phản công.' },
  { name: 'Nimzo-Indian', family: 'Phòng thủ', eco: 'E20', line: '1.d4 Nf6 2.c4 e6 3.Nc3 Bb4', san: ['d4','Nf6','c4','e6','Nc3','Bb4'], note: 'Ghim mã c3, tranh quyền kiểm soát trung tâm và cấu trúc tốt.' },
  { name: 'Phòng thủ Grünfeld', family: 'Phòng thủ', eco: 'D70', line: '1.d4 Nf6 2.c4 g6 3.Nc3 d5 4.cxd5 Nxd5', san: ['d4','Nf6','c4','g6','Nc3','d5','cxd5','Nxd5'], note: 'Cho Trắng trung tâm lớn rồi tấn công nó từ xa.' },
  { name: 'Phòng thủ Hà Lan', family: 'Phòng thủ', eco: 'A80', line: '1.d4 f5 2.g3 Nf6 3.Bg2 e6 4.Nf3 Be7 5.O-O O-O', san: ['d4','f5','g3','Nf6','Bg2','e6','Nf3','Be7','O-O','O-O'], note: 'Đen chiếm không gian cánh vua; cần để ý ô e6 và vua.' },
  { name: 'Khai cuộc Anh', family: 'Mở c4', eco: 'A10', line: '1.c4 e5 2.Nc3 Nf6 3.g3 d5 4.cxd5 Nxd5', san: ['c4','e5','Nc3','Nf6','g3','d5','cxd5','Nxd5'], note: 'Kiểm soát trung tâm từ cánh, thường chuyển thế linh hoạt.' },
  { name: 'Phòng thủ Pirc', family: 'Phòng thủ', eco: 'B07', line: '1.e4 d6 2.d4 Nf6 3.Nc3 g6 4.Nf3 Bg7', san: ['e4','d6','d4','Nf6','Nc3','g6','Nf3','Bg7'], note: 'Cho Trắng không gian và phản công bằng các quân nhẹ.' },
  { name: 'Alekhine Defense', family: 'Phòng thủ', eco: 'B02', line: '1.e4 Nf6 2.e5 Nd5 3.d4 d6 4.c4 Nb6', san: ['e4','Nf6','e5','Nd5','d4','d6','c4','Nb6'], note: 'Khiêu khích tốt Trắng tiến lên rồi đánh vào trung tâm.' },
  { name: 'Four Knights', family: 'Mở e4', eco: 'C47', line: '1.e4 e5 2.Nf3 Nc6 3.Nc3 Nf6 4.Bb5 Bb4', san: ['e4','e5','Nf3','Nc6','Nc3','Nf6','Bb5','Bb4'], note: 'Phát triển cân bằng, hữu ích để luyện nguyên tắc khai cuộc.' },
  { name: 'Dragon Sicilian', family: 'Phòng thủ', eco: 'B70', line: '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 g6', san: ['e4','c5','Nf3','d6','d4','cxd4','Nxd4','Nf6','Nc3','g6'], note: 'Tượng g7 hoạt động mạnh; ván thường sắc bén ở hai cánh.' },
  { name: 'Najdorf Sicilian', family: 'Phòng thủ', eco: 'B90', line: '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 a6 6.Be3', san: ['e4','c5','Nf3','d6','d4','cxd4','Nxd4','Nf6','Nc3','a6','Be3'], note: 'Một trong các nhánh Sicilian phổ biến nhất; có nhiều kế hoạch khác nhau.' },
  { name: 'Benoni hiện đại', family: 'Phòng thủ', eco: 'A60', line: '1.d4 Nf6 2.c4 c5 3.d5 e6 4.Nc3 exd5 5.cxd5 d6', san: ['d4','Nf6','c4','c5','d5','e6','Nc3','exd5','cxd5','d6'], note: 'Đen nhận cấu trúc không gian khác biệt để lấy hoạt động quân.' }
];

function renderView() {
  const root = $('#mainView');
  if (!root) return;
  if (currentView === 'play') root.innerHTML = renderPlayView();
  else if (currentView === 'openings') root.innerHTML = renderOpeningsView();
  else if (currentView === 'coach') root.innerHTML = renderCoachView();
  else if (currentView === 'arena') root.innerHTML = renderArenaView();
  else if (currentView === 'lichess') root.innerHTML = renderLichessView();
  else root.innerHTML = renderSettingsView();
  wireCommonActions();
  if (currentView === 'play') {
    renderBoard();
    wirePlayActions();
  }
  if (currentView === 'openings') wireOpeningActions();
  if (currentView === 'coach') wireCoachActions();
  if (currentView === 'arena') { renderArenaPosition(); wireArenaActions(); }
  if (currentView === 'lichess') wireLichessActions();
  if (currentView === 'settings') wireSettingsActions();
}
function renderPlayView() {
  const modeLabel = mode === 'stockfish' ? 'Stockfish' : mode === 'ai' ? 'AI qua API' : mode === 'lichess' ? 'Lichess trực tuyến' : 'Hai người chơi';
  return `<section class="play-layout">
    <div class="board-column">
      <div class="opponent-line"><div class="avatar">${mode === 'local' ? '♙' : mode === 'ai' ? '✦' : mode === 'lichess' ? '↗' : '♞'}</div><div class="opponent-meta"><b>${mode === 'local' ? 'Người chơi Đen / Trắng' : mode === 'ai' ? 'Chess Bot AI' : mode === 'lichess' ? `Lichess · ${esc(activeOnlineGame?.opponent || 'đối thủ trực tuyến')}` : 'Stockfish'}</b><small>${modeLabel} · ${mode === 'stockfish' ? `Skill ${settings.botSkill}/20` : mode === 'ai' ? esc(settings.model) : mode === 'lichess' ? `Ván ${esc(activeOnlineGame?.id || '')}` : 'Cùng thiết bị'}</small></div><span id="turnChip" class="turn-chip">Lượt Trắng</span></div>
      <div class="board-frame"><div id="board" class="chessboard" role="grid" aria-label="Bàn cờ vua"></div></div>
      <div class="board-bottom"><span id="boardStatus">Trắng đang đi</span><button id="flipBoard" class="text-btn">⇅ Đảo bàn</button></div>
      <div class="mobile-action-row"><button class="primary-btn" id="newGame">＋ Ván mới</button><button class="secondary-btn" id="undoMove">↶ Hoàn tác</button><button class="secondary-btn" id="hintMove">✦ Gợi ý</button></div>
    </div>
    <aside class="side-column">
      <section class="panel game-setup"><div class="panel-heading"><div><small class="eyebrow">VÁN CỜ</small><h2>Thiết lập trận</h2></div><span class="live-dot"></span></div>
        <label class="field-label" for="modeSelect">Chế độ chơi</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish — chơi với máy</option><option value="ai" ${mode === 'ai' ? 'selected' : ''}>AI qua API — thử nghiệm</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người trên cùng máy</option></select>
        <div class="two-fields"><div><label class="field-label" for="colorSelect">Bạn cầm quân</label><select id="colorSelect" class="field"><option value="w" ${humanColor === 'w' ? 'selected' : ''}>Trắng</option><option value="b" ${humanColor === 'b' ? 'selected' : ''}>Đen</option></select></div><div><label class="field-label" for="skillSelect">Sức mạnh bot</label><select id="skillSelect" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất · không giới hạn Elo</option><option value="1320" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 1320 ? 'selected' : ''}>Elo giới hạn 1320</option><option value="1500" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 1500 ? 'selected' : ''}>Elo giới hạn 1500</option><option value="1800" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 1800 ? 'selected' : ''}>Elo giới hạn 1800</option><option value="2200" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 2200 ? 'selected' : ''}>Elo giới hạn 2200</option><option value="2600" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 2600 ? 'selected' : ''}>Elo giới hạn 2600</option><option value="3000" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 3000 ? 'selected' : ''}>Elo giới hạn 3000</option><option value="3190" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === 3190 ? 'selected' : ''}>Elo giới hạn 3190</option></select></div></div>
        <button id="newGameSetup" class="primary-btn full-width">Bắt đầu ván mới <span>→</span></button>
        <div class="stats-row"><div><small>Đánh giá</small><b id="evalNumber">—</b></div><div><small>Số nước</small><b>${game.history().length}</b></div><div><small>Trạng thái</small><b class="status-text">${game.isGameOver() ? 'Kết thúc' : 'Đang chơi'}</b></div></div>
      </section>
      <section class="panel moves-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ</small><h2>Nước đi</h2></div><div class="panel-icons"><button class="tiny-btn" id="copyPGN" title="Sao chép PGN">⧉</button><button class="tiny-btn" id="downloadPGN" title="Tải PGN">↓</button></div></div><div id="moveList" class="move-list"></div></section>
      <section class="panel quick-tools"><h3>Phân tích nhanh</h3><div class="tool-grid"><button id="explainPosition" class="tool-btn"><span>✦</span><b>Giải thích</b><small>Hỏi AI về thế cờ</small></button><button id="queryExplorer" class="tool-btn"><span>⌘</span><b>Khai cuộc</b><small>Dữ liệu Lichess</small></button></div><div id="explorerResult" class="explorer-result"></div></section>
    </aside>
  </section>`;
}
function renderOpeningsView() {
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">HỌC CỜ CÓ HỆ THỐNG</div><h1>Thư viện khai cuộc</h1><p>Hơn 20 hệ thống phổ biến, có biến mẫu để phát lại trên bàn cờ. Dữ liệu khai cuộc trực tuyến có thể tra thêm qua Lichess Opening Explorer.</p></div>
    <div class="opening-toolbar"><input id="openingSearch" class="field search-field" placeholder="Tìm tên khai cuộc, mã ECO…"/><select id="openingFilter" class="field"><option value="all">Tất cả hệ thống</option><option value="Mở e4">Khai cuộc 1.e4</option><option value="Mở d4">Khai cuộc 1.d4</option><option value="Phòng thủ">Phòng thủ</option><option value="Tấn công">Tấn công</option><option value="Mở c4">Khai cuộc 1.c4</option></select></div>
    <div id="openingGrid" class="opening-grid">${renderOpeningCards()}</div>
    <div class="note-banner"><span>✦</span><div><b>Cách dùng biến</b><p>Chọn “Xem biến” để nạp chuỗi nước đi hợp lệ lên bàn cờ. Đây là các đường mẫu để học, không phải toàn bộ biến có thể có của từng khai cuộc.</p></div></div>
  </section>`;
}
function renderOpeningCards(filter = '', family = 'all') {
  return OPENINGS.filter(o => (family === 'all' || o.family === family) && `${o.name} ${o.eco} ${o.note}`.toLowerCase().includes(filter.toLowerCase())).map((o, i) => `<article class="opening-card"><div class="opening-card-top"><span class="eco-tag">${o.eco}</span><span class="family-tag">${esc(o.family)}</span></div><h3>${esc(o.name)}</h3><p>${esc(o.note)}</p><div class="opening-line">${esc(o.line)}</div><div class="opening-card-bottom"><span>${o.san.length} nửa nước đi</span><button class="mini-primary" data-load-opening="${OPENINGS.indexOf(o)}">Xem biến ↗</button></div></article>`).join('') || '<div class="empty-state">Không tìm thấy khai cuộc phù hợp.</div>';
}
function renderCoachView() {
  return `<section class="content-page coach-page"><div class="page-intro"><div class="eyebrow">TRỢ LÝ CỜ VUA</div><h1>AI phân tích & huấn luyện</h1><p>Hỏi về vị trí hiện tại, ý tưởng chiến thuật, khai cuộc hoặc gửi một đoạn PGN. AI cần endpoint/model hoạt động; Stockfish vẫn phân tích nước đi độc lập.</p></div>
    <div class="coach-layout"><section class="panel coach-context"><div class="panel-heading"><div><small class="eyebrow">THẾ CỜ HIỆN TẠI</small><h2>Thông tin bàn cờ</h2></div><span class="context-icon">♞</span></div><div class="context-stat"><span>FEN</span><code>${esc(game.fen())}</code><button id="copyFen" class="tiny-btn">⧉</button></div><div class="context-stat"><span>PGN</span><code class="truncate-code">${esc(game.pgn() || 'Chưa có nước đi')}</code><button id="copyPgnCoach" class="tiny-btn">⧉</button></div><div class="coach-suggestions"><button data-prompt="Giải thích kế hoạch tốt nhất cho bên đang tới lượt trong thế cờ hiện tại.">Ý tưởng tốt nhất?</button><button data-prompt="Hãy chỉ ra các quân bị treo và các đòn chiến thuật trong thế cờ hiện tại.">Quân bị treo?</button><button data-prompt="Phân tích khai cuộc hiện tại, nêu nguyên tắc phát triển quân cho người mới học.">Phân tích khai cuộc</button><button data-prompt="Đưa ra kế hoạch phòng thủ an toàn cho bên đang tới lượt.">Kế hoạch phòng thủ</button></div></section>
      <section class="panel chat-panel"><div class="chat-header"><div class="avatar ai-avatar">✦</div><div><b>Chess Bot Coach</b><small>Đang dùng ${esc(settings.model)} · ${settings.aiMode === 'gemini' ? 'Gemini' : settings.aiMode === 'anthropic' ? 'Anthropic' : 'OpenAI-compatible'}</small></div><button id="clearChat" class="tiny-btn" title="Cuộc trò chuyện mới">＋</button></div><div id="chatTranscript" class="chat-transcript">${chatMessages.length ? renderChatMessages() : '<div class="welcome-chat"><div class="welcome-spark">✦</div><h3>Cùng phân tích ván cờ</h3><p>Mình sẽ giải thích bằng tiếng Việt, từng bước dễ hiểu.</p><div class="starter-prompts"><button data-prompt="Tôi mới chơi cờ. Hãy chỉ tôi 3 nguyên tắc quan trọng nhất ở khai cuộc.">Tôi mới học cờ ♟</button><button data-prompt="Dựa trên FEN hiện tại, giải thích các nước ứng viên dễ hiểu.">Giải thích vị trí này ✦</button></div></div>'}</div><form id="coachForm" class="chat-composer"><textarea id="coachInput" rows="2" placeholder="Hỏi về nước đi, chiến thuật, khai cuộc…"></textarea><button id="sendCoach" class="send-btn" type="submit" aria-label="Gửi tin nhắn">↑</button></form><div class="chat-footnote">AI có thể sai; hãy kiểm tra nước đi bằng luật cờ và Stockfish.</div></section></div>
  </section>`;
}
function renderChatMessages() {
  return chatMessages.map(m => `<div class="chat-message ${m.role === 'user' ? 'user-message' : 'assistant-message'}"><div class="message-role">${m.role === 'user' ? 'Bạn' : 'Chess Bot AI'}</div><div class="message-content">${esc(m.content).replace(/\n/g, '<br>')}</div><button class="copy-message" data-copy-message="${m.id}">Sao chép</button></div>`).join('');
}
function renderLichessView() {
  const token = sessionStorage.getItem(lichessTokenKey) || '';
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">CHƠI TRỰC TUYẾN</div><h1>Kết nối Lichess</h1><p>Kết nối tài khoản bằng Personal Access Token. Token chỉ giữ trong phiên trình duyệt và được gửi tới backend đã cấu hình; không đưa token lên GitHub. Bot API cần tài khoản đã được nâng cấp thành Bot và đúng scope.</p></div>
    <div class="lichess-layout"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Kết nối Lichess.org</h2></div><div class="lichess-logo">♞</div></div><label class="field-label" for="lichessToken">Personal Access Token</label><input id="lichessToken" type="password" autocomplete="off" class="field" placeholder="Dán token có quyền phù hợp" value="${esc(token)}"/><div class="field-hint">Dùng quyền cần thiết cho cách chơi bạn muốn: đọc tài khoản và chơi ván cờ. Không dán token vào nơi công khai.</div><label class="field-label" for="lichessApiMode">Kiểu API chơi ván</label><select id="lichessApiMode" class="field"><option value="board">Tài khoản thông thường (Board API)</option><option value="bot">Tài khoản Lichess Bot (Bot API)</option></select><div class="field-hint">Chọn Bot API chỉ khi tài khoản đã được nâng cấp thành bot; tài khoản thường dùng Board API.</div><div class="button-row"><button id="connectLichess" class="primary-btn">Kiểm tra kết nối</button><button id="forgetLichess" class="secondary-btn">Xóa token</button></div><div id="lichessAccountResult" class="connection-result">${token ? 'Token đang lưu tạm trong phiên này; hãy kiểm tra kết nối.' : 'Chưa kết nối tài khoản.'}</div><div class="form-divider"></div><h3>Thử đấu AI của Lichess</h3><div class="two-fields"><div><label class="field-label" for="lichessLevel">Độ khó AI (1–8)</label><select id="lichessLevel" class="field">${[1,2,3,4,5,6,7,8].map(n=>`<option value="${n}" ${n===3?'selected':''}>Cấp ${n}</option>`).join('')}</select></div><div><label class="field-label" for="lichessClock">Thời gian (giây)</label><select id="lichessClock" class="field"><option value="60">1 phút</option><option value="180">3 phút</option><option value="300" selected>5 phút</option><option value="600">10 phút</option><option value="0">Không giới hạn</option></select></div></div><button id="challengeLichessAI" class="primary-btn full-width">Tạo ván với AI Lichess ↗</button><div class="form-divider"></div><h3>Thách đấu người chơi</h3><label class="field-label" for="lichessUsername">Tên người chơi Lichess</label><input id="lichessUsername" class="field" placeholder="Ví dụ: username"/><button id="challengeLichessUser" class="secondary-btn full-width">Gửi lời mời đấu ↗</button><div id="lichessChallengeResult" class="connection-result"></div></section>
    <section class="panel lichess-info"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI THỰC TẾ</small><h2>Trạng thái & hướng dẫn</h2></div><span class="online-indicator"></span></div><div class="info-row"><span class="info-icon">✓</span><div><b>Dữ liệu khai cuộc</b><p>Tra thống kê nước đi trong tab Khai cuộc qua Lichess Opening Explorer; không cần token cho truy vấn công khai.</p></div></div><div class="info-row"><span class="info-icon">↗</span><div><b>Ván trực tuyến</b><p>Sau khi gửi thử thách, mở trang ván trên Lichess để chấp nhận/chơi. Đồng bộ nước đi trong ứng dụng cần token, đúng API scope và backend có thể truy cập Lichess.</p></div></div><div class="info-row"><span class="info-icon">!</span><div><b>Bot Lichess không giống AI Stockfish nội bộ</b><p>API Bot chỉ hoạt động với tài khoản bot đủ điều kiện. Không dùng tài khoản thường để tự động hóa qua Bot API.</p></div></div><a class="external-link" href="https://lichess.org/account/oauth/token" target="_blank" rel="noopener noreferrer">Mở trang quản lý token ↗</a><a class="external-link" href="https://lichess-org.github.io/api/" target="_blank" rel="noopener noreferrer">Tài liệu API chính thức ↗</a><div id="lichessActiveGame" class="active-game-card">${activeOnlineGame ? `Ván vừa tạo: <b>${esc(activeOnlineGame.id || '')}</b><br><a href="${esc(activeOnlineGame.url || 'https://lichess.org') }" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a><br><button id="playLichessHere" class="mini-primary">Kết nối ván trong Chess Bot</button>` : 'Chưa tạo ván nào trong phiên này.'}</div></section></div>
  </section>`;
}
function renderSettingsView() {
  return `<section class="content-page settings-page"><div class="page-intro"><div class="eyebrow">CẤU HÌNH ỨNG DỤNG</div><h1>AI, engine & máy chủ</h1><p>Không có một endpoint chung cho mọi AI. Hãy chọn API tương thích OpenAI, Google Gemini hoặc Anthropic và nhập endpoint/model theo nhà cung cấp. API key được lưu trên thiết bị này; không đưa vào kho mã nguồn. OpenRouter có thể cung cấp quyền truy cập nhiều model qua một API, tùy tài khoản.</p></div>
    <div class="settings-layout"><section class="panel settings-panel"><div class="panel-heading"><div><small class="eyebrow">AI PROVIDER</small><h2>Kết nối mô hình ngôn ngữ</h2></div><span class="context-icon">✦</span></div><label class="field-label" for="providerPreset">Chọn nhanh nhà cung cấp</label><select id="providerPreset" class="field"><option value="custom">Custom endpoint</option><option value="openai">OpenAI API</option><option value="openrouter">OpenRouter · nhiều model</option><option value="anthropic">Anthropic API</option><option value="groq">Groq</option><option value="deepseek">DeepSeek</option><option value="together">Together AI</option><option value="mistral">Mistral AI</option><option value="fireworks">Fireworks AI</option><option value="cerebras">Cerebras</option><option value="xai">xAI</option><option value="ollama">Ollama local</option><option value="gemini">Google Gemini API</option></select><div class="field-hint">Chọn nhanh URL nền. Tên model và quyền truy cập vẫn phải đúng theo tài khoản/nhà cung cấp.</div><label class="field-label" for="aiMode">Kiểu API</label><select id="aiMode" class="field"><option value="openai-compatible" ${settings.aiMode === 'openai-compatible' ? 'selected' : ''}>OpenAI-compatible (OpenAI, OpenRouter, Groq, DeepSeek, Together, Cerebras, xAI, Ollama…)</option><option value="gemini" ${settings.aiMode === 'gemini' ? 'selected' : ''}>Google Gemini API</option><option value="anthropic" ${settings.aiMode === 'anthropic' ? 'selected' : ''}>Anthropic Messages API</option></select><label class="field-label" for="apiEndpoint">Endpoint / Base URL</label><input id="apiEndpoint" class="field" value="${esc(settings.endpoint)}" placeholder="https://api.openai.com/v1"/><div class="field-hint">Ví dụ Ollama: http://localhost:11434/v1. API cần được nhà cung cấp cho phép gọi từ máy chủ đã cài đặt.</div><label class="field-label" for="apiModel">Tên model chính xác</label><input id="apiModel" class="field" value="${esc(settings.model)}" placeholder="Tên model do nhà cung cấp cung cấp"/><label class="field-label" for="apiKey">API key</label><div class="secret-input"><input id="apiKey" type="password" class="field" autocomplete="off" value="${esc(settings.apiKey)}" placeholder="Dán API key tại đây"/><button id="toggleApiKey" type="button" class="tiny-btn">Hiện</button></div><div class="field-hint">Không chia sẻ ảnh chụp màn hình có API key. Nếu từng lộ key, hãy thu hồi và tạo key mới.</div><div class="form-divider"></div><label class="field-label" for="botEngineSetting">Engine Stockfish</label><select id="botEngineSetting" class="field"><option value="auto" ${!['lite-single','full-single'].includes(settings.botEngine) ? 'selected' : ''}>Tự động theo thiết bị · khuyến nghị</option><option value="lite-single" ${settings.botEngine === 'lite-single' ? 'selected' : ''}>Lite Single · nhẹ, phù hợp điện thoại</option><option value="full-single" ${settings.botEngine === 'full-single' ? 'selected' : ''}>Full Single · mạnh hơn, tải khoảng 94 MB</option></select><div class="field-hint">Tự động chọn Full khi trình duyệt báo ít nhất 6 GB RAM và 6 luồng CPU; nếu thiếu thông tin hoặc thiết bị yếu, dùng Lite để giảm nguy cơ chậm/nóng. Cả hai chạy một luồng. Đổi engine cần tải lại ứng dụng.</div><div class="two-fields"><div><label class="field-label" for="botSkillSetting">Stockfish Skill (0–20)</label><input id="botSkillSetting" type="number" class="field" min="0" max="20" value="${Number(settings.botSkill)}"/></div><div><label class="field-label" for="botDepthSetting">Độ sâu (5–30)</label><input id="botDepthSetting" type="number" class="field" min="5" max="30" value="${Number(settings.botDepth)}"/></div></div><div class="two-fields"><div><label class="field-label" for="botStrengthModeSetting">Chế độ sức mạnh</label><select id="botStrengthModeSetting" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Tối đa (không giới hạn Elo)</option><option value="elo" ${settings.botStrengthMode === 'elo' ? 'selected' : ''}>Giới hạn Elo</option></select></div><div><label class="field-label" for="botEloSetting">Elo giới hạn (1320–3190)</label><input id="botEloSetting" type="number" class="field" min="1320" max="3190" step="10" value="${Number(settings.botElo || 2600)}"/></div></div><label class="field-label" for="backendUrl">API backend URL (để trống khi chạy cùng máy)</label><input id="backendUrl" class="field" value="${esc(settings.backendUrl)}" placeholder="https://api-cua-ban.example"/><label class="field-label" for="backendAccessToken">Mã truy cập backend (nếu máy chủ yêu cầu)</label><input id="backendAccessToken" type="password" autocomplete="off" class="field" value="${esc(settings.backendAccessToken)}" placeholder="Không bắt buộc khi backend chạy cục bộ"/><div class="field-hint">Khi đóng gói APK, AI/Lichess cần backend được triển khai có HTTPS. Chơi cờ và engine được đóng gói có thể chạy cục bộ.</div><div class="button-row"><button id="saveSettings" class="primary-btn">Lưu cấu hình</button><button id="testAI" class="secondary-btn">Kiểm tra AI</button></div><div id="settingsTestResult" class="connection-result"></div></section>
    <aside class="panel settings-about"><div class="panel-heading"><div><small class="eyebrow">CHESS BOT ENGINE</small><h2>Thông tin hệ thống</h2></div></div><div class="brand-showcase"><img src="./chess-bot-logo.webp" alt="Logo Chess Bot" loading="lazy" decoding="async" /></div><div class="info-row"><span class="info-icon">♞</span><div><b>Stockfish 19 · tự chọn Lite/Full</b><p>Engine UCI chạy trong Web Worker. Chế độ tự động dùng Full khi navigator báo ít nhất 6 GB RAM và 6 luồng CPU; nếu không, chọn Lite. Có thể chọn thủ công trong cài đặt. Độ sâu đến 30 có thể tốn thời gian và pin; engine cần các tệp JS/WASM được copy khi cài dependencies.</p></div></div><div class="info-row"><span class="info-icon">♟</span><div><b>Luật cờ tiêu chuẩn</b><p>Được kiểm tra bởi chess.js: nước hợp lệ, nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hòa và lặp thế cờ.</p></div></div><div class="info-row"><span class="info-icon">⌘</span><div><b>Kho khai cuộc</b><p>${OPENINGS.length} đường khai cuộc mẫu kèm mã ECO tham khảo và tích hợp Opening Explorer.</p></div></div><div class="info-row"><span class="info-icon">🔐</span><div><b>Bảo vệ khóa</b><p>Khóa không được đóng cứng vào mã. Trình duyệt lưu cài đặt cục bộ; khi triển khai công khai cần cấu hình xác thực, giới hạn truy cập và HTTPS cho backend.</p></div></div><div class="license-note"><b>Giấy phép thư viện</b><p>chess.js theo BSD-2-Clause. Stockfish theo GPL-3.0; xem giấy phép và thông báo bản quyền đi kèm bản phân phối Stockfish trước khi phát hành.</p></div><button id="resetSettings" class="danger-btn full-width">Đặt lại cài đặt AI</button></aside></div>
  </section>`;
}

function wireCommonActions() {
  // Global navigation listeners are attached once during boot; the views below are re-rendered.
}
function wirePlayActions() {
  const modeSelect = $('#modeSelect');
  modeSelect?.addEventListener('change', () => {
    const chosen = modeSelect.value;
    if (chosen === 'lichess' && !activeOnlineGame?.id) {
      toast('Kết nối Lichess và tạo ván trước.'); mode = 'stockfish'; modeSelect.value = mode;
    } else {
      mode = chosen;
      if (mode === 'lichess') {
        gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
        if (engineSearchActive && !pendingEngineRequest) { try { engineWorker?.postMessage('stop'); } catch {} }
        startOnlinePlay(); return;
      }
    }
    gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
    if (engineSearchActive && !pendingEngineRequest) { try { engineWorker?.postMessage('stop'); } catch {} }
    if (mode === 'ai' && (!settings.model || !settings.endpoint)) toast('Hãy cấu hình model và endpoint trong Cài đặt.');
    renderView();
    if (['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor && !(mode === 'ai' && (!settings.model || !settings.endpoint))) {
      botThinking = true; renderView();
      setTimeout(() => { if (mode === 'stockfish') askStockfishMove(); else if (mode === 'ai') askAiMove(); }, 220);
    }
  });
  $('#colorSelect')?.addEventListener('change', event => { humanColor = event.target.value; orientation = humanColor; renderBoard(); });
  $('#skillSelect')?.addEventListener('change', event => {
    const value = event.target.value;
    if (value === 'max') { settings.botStrengthMode = 'max'; settings.botSkill = 20; }
    else { settings.botStrengthMode = 'elo'; settings.botElo = Math.max(1320, Math.min(3190, Number(value) || 2600)); settings.botSkill = 20; }
    saveSettings(); toast(settings.botStrengthMode === 'max' ? 'Stockfish đang ở sức mạnh tối đa.' : `Đã giới hạn Stockfish ở khoảng Elo ${settings.botElo}.`);
  });
  $('#newGame')?.addEventListener('click', () => freshGame());
  $('#newGameSetup')?.addEventListener('click', () => {
    mode = $('#modeSelect').value;
    humanColor = $('#colorSelect').value;
    orientation = humanColor;
    freshGame();
  });
  $('#undoMove')?.addEventListener('click', undoMove);
  $('#flipBoard')?.addEventListener('click', () => { orientation = orientation === 'w' ? 'b' : 'w'; renderBoard(); });
  $('#hintMove')?.addEventListener('click', requestHint);
  $('#copyPGN')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
  $('#downloadPGN')?.addEventListener('click', downloadPgn);
  $('#explainPosition')?.addEventListener('click', () => { setView('coach'); setTimeout(() => { $('#coachInput') && ($('#coachInput').value = 'Phân tích thế cờ hiện tại của tôi: điểm mạnh, điểm yếu và kế hoạch đơn giản nhất.'); $('#coachInput')?.focus(); }, 0); });
  $('#queryExplorer')?.addEventListener('click', () => queryOpeningExplorer(true));
}
function wireOpeningActions() {
  const update = () => { $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch').value, $('#openingFilter').value); wireOpeningButtons(); };
  $('#openingSearch')?.addEventListener('input', update);
  $('#openingFilter')?.addEventListener('change', update);
  wireOpeningButtons();
}
function wireOpeningButtons() {
  $$('[data-load-opening]').forEach(button => button.addEventListener('click', () => loadOpening(Number(button.dataset.loadOpening))));
}
function loadOpening(index) {
  const opening = OPENINGS[index];
  if (!opening) return;
  gameEpoch += 1;
  queuedMainEngineMove = false;
  if (engineSearchActive && !pendingEngineRequest) { try { engineWorker?.postMessage('stop'); } catch {} }
  game = new Chess();
  for (const san of opening.san) {
    try { game.move(san); } catch (error) { console.warn('Opening line issue:', opening.name, san, error); break; }
  }
  currentOpening = opening.name;
  mode = 'local';
  selected = null; selectedTargets = []; lastMove = null; humanColor = 'w'; orientation = 'w'; botThinking = false;
  setView('play');
  toast(`Đã nạp biến mẫu: ${opening.name}. Bạn có thể tiếp tục nước đi từ thế cờ này.`, 'success');
}
function wireCoachActions() {
  $('#coachForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const input = $('#coachInput');
    const content = input.value.trim();
    if (!content) return;
    input.value = '';
    await sendCoachMessage(content);
  });
  $('#clearChat')?.addEventListener('click', () => { chatMessages = []; renderView(); });
  $$('[data-prompt]').forEach(button => button.addEventListener('click', () => { const input = $('#coachInput'); input.value = button.dataset.prompt; input.focus(); }));
  $$('[data-copy-message]').forEach(button => button.addEventListener('click', () => { const m = chatMessages.find(x => x.id === button.dataset.copyMessage); if (m) copyText(m.content); }));
  $('#copyFen')?.addEventListener('click', () => copyText(game.fen()));
  $('#copyPgnCoach')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
}
function wireSettingsActions() {
  const presetForEndpoint = {
    'https://api.openai.com/v1': 'openai',
    'https://api.anthropic.com': 'anthropic',
    'https://api.cerebras.ai/v1': 'cerebras',
    'https://api.x.ai/v1': 'xai',
    'https://openrouter.ai/api/v1': 'openrouter',
    'https://api.groq.com/openai/v1': 'groq',
    'https://api.deepseek.com/v1': 'deepseek',
    'https://api.together.xyz/v1': 'together',
    'https://api.mistral.ai/v1': 'mistral',
    'https://api.fireworks.ai/inference/v1': 'fireworks',
    'http://localhost:11434/v1': 'ollama',
    'https://generativelanguage.googleapis.com': 'gemini'
  };
  const currentPreset = settings.aiMode === 'gemini' ? 'gemini' : (presetForEndpoint[settings.endpoint.replace(/\/$/, '')] || 'custom');
  if ($('#providerPreset')) $('#providerPreset').value = currentPreset;
  $('#providerPreset')?.addEventListener('change', event => {
    const presets = {
      custom: null,
      openai: { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' },
      anthropic: { mode: 'anthropic', endpoint: 'https://api.anthropic.com' },
      cerebras: { mode: 'openai-compatible', endpoint: 'https://api.cerebras.ai/v1' },
      xai: { mode: 'openai-compatible', endpoint: 'https://api.x.ai/v1' },
      openrouter: { mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1' },
      groq: { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' },
      deepseek: { mode: 'openai-compatible', endpoint: 'https://api.deepseek.com/v1' },
      together: { mode: 'openai-compatible', endpoint: 'https://api.together.xyz/v1' },
      mistral: { mode: 'openai-compatible', endpoint: 'https://api.mistral.ai/v1' },
      fireworks: { mode: 'openai-compatible', endpoint: 'https://api.fireworks.ai/inference/v1' },
      ollama: { mode: 'openai-compatible', endpoint: 'http://localhost:11434/v1' },
      gemini: { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' }
    };
    const preset = presets[event.target.value];
    if (!preset) return;
    $('#aiMode').value = preset.mode;
    $('#apiEndpoint').value = preset.endpoint;
    if (preset.mode === 'gemini' && ['gpt-4o-mini', ''].includes($('#apiModel').value)) $('#apiModel').value = 'gemini-3.8-flash';
    if (preset.mode !== 'gemini' && $('#apiModel').value === 'gemini-3.8-flash') $('#apiModel').value = '';
  });
  $('#aiMode')?.addEventListener('change', event => {
    if (event.target.value === 'gemini') {
      $('#apiEndpoint').value = 'https://generativelanguage.googleapis.com';
      if (!$('#apiModel').value || $('#apiModel').value === 'gpt-4o-mini') $('#apiModel').value = 'gemini-3.8-flash';
    } else if (event.target.value === 'anthropic') {
      $('#apiEndpoint').value = 'https://api.anthropic.com';
      if (!$('#apiModel').value) $('#apiModel').value = 'claude-sonnet-latest';
    } else {
      $('#apiEndpoint').value = 'https://api.openai.com/v1';
      if (!$('#apiModel').value || $('#apiModel').value === 'gemini-3.8-flash') $('#apiModel').value = 'gpt-4o-mini';
    }
  });
  $('#toggleApiKey')?.addEventListener('click', () => { const input = $('#apiKey'); input.type = input.type === 'password' ? 'text' : 'password'; $('#toggleApiKey').textContent = input.type === 'password' ? 'Hiện' : 'Ẩn'; });
  $('#saveSettings')?.addEventListener('click', saveSettingsForm);
  $('#testAI')?.addEventListener('click', async () => {
    saveSettingsForm(false);
    const result = $('#settingsTestResult');
    result.textContent = 'Đang kiểm tra kết nối AI…';
    try {
      const data = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: settings.model, messages: [{ role: 'user', content: 'Trả lời đúng một từ: OK' }], system: 'Trả lời thật ngắn.' }) });
      result.textContent = `Kết nối thành công · ${settings.model}: ${data.text.slice(0, 180)}`;
      result.className = 'connection-result success-result';
    } catch (error) { result.textContent = `Chưa kết nối được: ${error.message}`; result.className = 'connection-result error-result'; }
  });
  $('#resetSettings')?.addEventListener('click', () => {
    settings = { ...DEFAULTS }; saveSettings(); toast('Đã đặt lại cấu hình AI.'); renderView();
  });
}
function saveSettingsForm(showToast = true) {
  settings.aiMode = $('#aiMode').value;
  settings.endpoint = $('#apiEndpoint').value.trim();
  settings.model = $('#apiModel').value.trim();
  settings.apiKey = $('#apiKey').value.trim();
  settings.backendUrl = $('#backendUrl').value.trim().replace(/\/$/, '');
  settings.backendAccessToken = $('#backendAccessToken').value.trim();
  const previousEngine = settings.botEngine || 'auto';
  const requestedEngine = $('#botEngineSetting')?.value || 'auto';
  settings.botEngine = ['auto', 'lite-single', 'full-single'].includes(requestedEngine) ? requestedEngine : 'auto';
  settings.botEnginePreferenceSet = true;
  settings.botSkill = Math.max(0, Math.min(20, Number($('#botSkillSetting').value || 20)));
  settings.botStrengthMode = $('#botStrengthModeSetting')?.value === 'elo' ? 'elo' : 'max';
  settings.botElo = Math.max(1320, Math.min(3190, Number($('#botEloSetting').value || 2600)));
  settings.botDepth = Math.max(5, Math.min(30, Number($('#botDepthSetting').value || 18)));
  saveSettings();
  if (showToast) toast(settings.botEngine !== previousEngine ? 'Đã lưu. Tải lại ứng dụng để áp dụng cấu hình engine mới.' : 'Đã lưu cấu hình trên thiết bị.', 'success');
  if (currentView === 'settings') {
    const result = $('#settingsTestResult');
    if (result) { result.textContent = 'Đã lưu cấu hình. Nhấn “Kiểm tra AI” để thử kết nối.'; result.className = 'connection-result'; }
  }
}
function wireLichessActions() {
  $('#connectLichess')?.addEventListener('click', connectLichess);
  $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
  $('#forgetLichess')?.addEventListener('click', () => { sessionStorage.removeItem(lichessTokenKey); $('#lichessToken').value = ''; $('#lichessAccountResult').textContent = 'Đã xóa token khỏi phiên hiện tại.'; });
  $('#challengeLichessAI')?.addEventListener('click', challengeLichessAI);
  $('#challengeLichessUser')?.addEventListener('click', challengeLichessUser);
}
async function connectLichess() {
  const token = $('#lichessToken').value.trim();
  if (!token) { toast('Hãy nhập Lichess personal access token.'); return; }
  sessionStorage.setItem(lichessTokenKey, token);
  const result = $('#lichessAccountResult'); result.textContent = 'Đang xác thực token…';
  try {
    const account = await apiFetch('/api/lichess/account', { method: 'POST', body: JSON.stringify({ token }) });
    activeLichessUsername = account.username || '';
    sessionStorage.setItem('tubor.chess.lichessUsername', activeLichessUsername);
    result.textContent = `Đã kết nối: ${account.username}${account.title ? ` (${account.title})` : ''}`;
    result.className = 'connection-result success-result';
  } catch (error) { result.textContent = `Kết nối thất bại: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessAI() {
  const token = $('#lichessToken').value.trim() || sessionStorage.getItem(lichessTokenKey) || '';
  const result = $('#lichessChallengeResult'); result.textContent = 'Đang tạo thử thách AI…';
  try {
    const data = await apiFetch('/api/lichess/challenge-ai', { method: 'POST', body: JSON.stringify({ token, level: Number($('#lichessLevel').value), clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', username: activeLichessUsername || sessionStorage.getItem('tubor.chess.lichessUsername') || '' };
    result.innerHTML = `Đã tạo thử thách. <a href="${esc(data.url || `https://lichess.org/${data.id}`)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a> <button id="playLichessHere" class="mini-primary">Chơi trong Chess Bot</button>`;
    $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Ván vừa tạo: <b>${esc(data.id || '')}</b><br><a href="${esc(data.url || `https://lichess.org/${data.id}`)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không tạo được thử thách: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessUser() {
  const token = $('#lichessToken').value.trim() || sessionStorage.getItem(lichessTokenKey) || '';
  const username = $('#lichessUsername').value.trim();
  const result = $('#lichessChallengeResult'); result.textContent = 'Đang gửi lời mời…';
  try {
    const data = await apiFetch('/api/lichess/challenge-user', { method: 'POST', body: JSON.stringify({ token, username, clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', opponent: username, username: activeLichessUsername || sessionStorage.getItem('tubor.chess.lichessUsername') || '' };
    result.innerHTML = `Đã gửi lời mời. <a href="${esc(data.url || `https://lichess.org/${data.id}`)}" target="_blank" rel="noopener noreferrer">Mở lời mời ↗</a> <button id="playLichessHere" class="mini-primary">Kết nối ván trong Chess Bot</button>`;
    $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Lời mời: <b>${esc(data.id || '')}</b><br><a href="${esc(data.url || `https://lichess.org/${data.id}`)}" target="_blank" rel="noopener noreferrer">Mở Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không gửi được lời mời: ${error.message}`; result.className = 'connection-result error-result'; }
}

async function sendCoachMessage(content) {
  const inputMessages = chatMessages.filter(m => m.role === 'user' || m.role === 'assistant').slice(-10).map(m => ({ role: m.role, content: m.content }));
  const userMessage = { id: crypto.randomUUID(), role: 'user', content };
  chatMessages.push(userMessage);
  renderView();
  const waiting = { id: 'waiting', role: 'assistant', content: 'Đang phân tích thế cờ…' };
  chatMessages.push(waiting);
  renderView();
  try {
    const gameContext = `Thế cờ hiện tại (FEN): ${game.fen()}\nPGN hiện tại: ${game.pgn() || '(ván chưa có nước đi)'}\nBên tới lượt: ${game.turn() === 'w' ? 'Trắng' : 'Đen'}\nTrạng thái: ${positionStatus()}.\nHãy trả lời bằng tiếng Việt đơn giản, không bịa nước đi. Nếu đưa ra nước đi hãy dùng ký hiệu SAN và nói đó là gợi ý cần xác minh.`;
    const data = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: settings.model, temperature: settings.temperature, system: `Bạn là huấn luyện viên cờ vua thân thiện cho người mới. Ưu tiên giải thích ngắn gọn, có ví dụ. ${gameContext}`, messages: [...inputMessages, { role: 'user', content }] }) });
    chatMessages = chatMessages.filter(m => m.id !== 'waiting');
    chatMessages.push({ id: crypto.randomUUID(), role: 'assistant', content: data.text });
  } catch (error) {
    chatMessages = chatMessages.filter(m => m.id !== 'waiting');
    chatMessages.push({ id: crypto.randomUUID(), role: 'assistant', content: `Mình chưa gọi được API: ${error.message}\n\nBạn kiểm tra endpoint, tên model và API key trong Cài đặt nhé. Nếu chỉ muốn luyện cờ, Stockfish nội bộ vẫn dùng độc lập.` });
  }
  renderView();
  const transcript = $('#chatTranscript'); if (transcript) transcript.scrollTop = transcript.scrollHeight;
}
async function requestHint() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi dùng gợi ý.'); return; }
  if (botThinking) { toast('Đợi bot đi xong rồi hãy xin gợi ý.'); return; }
  if (game.isGameOver()) { toast('Ván cờ đã kết thúc.'); return; }
  if (engineWorker && engineReady && mode === 'stockfish') {
    const legal = game.moves({ verbose: true });
    if (!legal.length) return;
    // Give the engine a depth-limited search of the present position. It only displays a candidate, it does not play it.
    const wasThinking = botThinking;
    engineSearchActive = false;
    let received = false;
    const oldHandler = engineWorker.onmessage;
    engineWorker.onmessage = event => {
      const line = typeof event.data === 'string' ? event.data : String(event.data || '');
      const match = line.match(/\bbestmove\s+([a-h][1-8][a-h][1-8][qrbn]?)/i);
      if (match && !received) {
        received = true;
        engineWorker.onmessage = oldHandler;
        const uci = match[1];
        const mv = legal.find(m => `${m.from}${m.to}${m.promotion || ''}` === uci);
        toast(mv ? `Gợi ý Stockfish: ${mv.san} (${uci})` : `Gợi ý Stockfish: ${uci}`, 'success');
        $('#boardStatus') && ($('#boardStatus').textContent = positionStatus());
      } else if (oldHandler) oldHandler(event);
    };
    engineWorker.postMessage('stop');
    engineWorker.postMessage(`position fen ${game.fen()}`);
    engineWorker.postMessage(`go depth ${Math.max(8, Math.min(18, Number(settings.botDepth || 12)))}`);
    botThinking = wasThinking;
  } else {
    const move = chooseFallbackMove();
    toast(move ? `Gợi ý nhanh: ${move.san}. Đây là gợi ý heuristic, không phải phân tích Stockfish.` : 'Không có nước đi hợp lệ.');
  }
}
async function queryOpeningExplorer(showToast = true) {
  const box = $('#explorerResult');
  if (box) box.innerHTML = '<div class="explorer-loading">Đang tra Opening Explorer…</div>';
  try {
    const moves = chessUciHistory();
    const data = await apiFetch(`/api/openings/explorer?moves=${encodeURIComponent(moves)}`);
    lastExplorerData = data;
    const topMoves = (data.moves || []).slice(0, 4);
    if (box) {
      box.innerHTML = topMoves.length ? `<div class="explorer-title">Nước phổ biến ở thế này</div>${topMoves.map(m => {
        const total = (m.white || 0) + (m.draws || 0) + (m.black || 0);
        const pct = total ? Math.round(100 * (m.white || 0) / total) : 0;
        return `<div class="explorer-move"><b>${esc(m.san || m.uci)}</b><span>${Number(total).toLocaleString('vi-VN')} ván</span><small>Trắng thắng ${pct}%</small></div>`;
      }).join('')}` : '<div class="empty-state small-empty">Chưa có thống kê cho thế cờ này.</div>';
    }
    if (showToast) toast(topMoves.length ? 'Đã tải dữ liệu khai cuộc từ Lichess.' : 'Không có dữ liệu khai cuộc ở thế này.');
  } catch (error) {
    if (box) box.innerHTML = `<div class="empty-state small-empty">Chưa tra được: ${esc(error.message)}. Kiểm tra backend hoặc internet.</div>`;
    if (showToast) toast(`Không tra được khai cuộc: ${error.message}`);
  }
}
async function startOnlinePlay() {
  const token = $('#lichessToken')?.value.trim() || sessionStorage.getItem(lichessTokenKey) || '';
  if (!activeOnlineGame?.id || !token) { toast('Cần có ván Lichess và token đã kết nối.'); setView('lichess'); return; }
  activeOnlineGame.apiMode = $('#lichessApiMode')?.value || activeOnlineGame.apiMode || 'board';
  activeOnlineGame.username = activeLichessUsername || sessionStorage.getItem('tubor.chess.lichessUsername') || '';
  mode = 'lichess';
  humanColor = activeOnlineGame.color === 'black' ? 'b' : activeOnlineGame.color === 'white' ? 'w' : 'w';
  orientation = humanColor;
  game = new Chess(); selected = null; selectedTargets = []; lastMove = null; botThinking = false;
  setView('play');
  toast('Đang kết nối luồng ván Lichess…');
  listenOnlineGame();
}
async function submitLichessMove(uci) {
  if (!activeOnlineGame?.id) { toast('Chưa có mã ván Lichess.'); return; }
  const token = sessionStorage.getItem(lichessTokenKey) || '';
  try {
    await apiFetch('/api/lichess/move', { method: 'POST', body: JSON.stringify({ token, gameId: activeOnlineGame.id, move: uci, apiMode: activeOnlineGame.apiMode || 'board' }) });
  } catch (error) {
    toast(`Lichess từ chối nước ${uci}: ${error.message}`);
    listenOnlineGame();
  }
}
async function listenOnlineGame() {
  stopOnlineStream();
  const token = sessionStorage.getItem(lichessTokenKey) || '';
  if (!activeOnlineGame?.id || !token) return;
  onlineStreamController = new AbortController();
  try {
    const response = await fetch(apiUrl('/api/lichess/stream'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}) },
      body: JSON.stringify({ token, gameId: activeOnlineGame.id, apiMode: activeOnlineGame.apiMode || 'board' }),
      signal: onlineStreamController.signal
    });
    if (!response.ok || !response.body) {
      const message = await response.text().catch(() => 'Không mở được luồng ván.');
      throw new Error(message.slice(0, 300));
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      pending += decoder.decode(value, { stream: true });
      const lines = pending.split('\n'); pending = lines.pop() || '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try { processLichessEvent(JSON.parse(trimmed)); } catch (error) { console.warn('Lichess event parse:', error); }
      }
    }
  } catch (error) {
    if (error.name !== 'AbortError') toast(`Luồng Lichess bị ngắt: ${error.message}`);
  }
}
function processLichessEvent(event) {
  if (!event || typeof event !== 'object') return;
  if (event.type === 'gameFull') {
    activeOnlineGame.initialFen = event.initialFen && event.initialFen !== 'startpos' ? event.initialFen : null;
    const whiteName = event.white?.name || event.white?.id || '';
    const blackName = event.black?.name || event.black?.id || '';
    if (activeOnlineGame.username && whiteName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'w';
    else if (activeOnlineGame.username && blackName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'b';
    else if (event.color === 'black' || event.color === 'white') humanColor = event.color === 'black' ? 'b' : 'w';
    orientation = humanColor;
    syncLichessMoveList(event.state?.moves || '');
    if (currentView === 'play') renderView();
  } else if (event.type === 'gameState') {
    syncLichessMoveList(event.moves || '');
    if (event.status && event.status !== 'started') toast(`Ván Lichess kết thúc: ${event.status}.`, 'success');
    if (currentView === 'play') renderView();
  } else if (event.type === 'chatLine') {
    console.info('[Lichess chat]', event.username, event.text);
  }
}
function syncLichessMoveList(movesText) {
  const replay = activeOnlineGame?.initialFen ? new Chess(activeOnlineGame.initialFen) : new Chess();
  for (const uci of String(movesText || '').split(/\s+/).filter(Boolean)) {
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) continue;
    try { replay.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) }); }
    catch { break; }
  }
  game = replay;
  gameEpoch += 1;
  const history = game.history({ verbose: true });
  const last = history[history.length - 1];
  lastMove = last ? { from: last.from, to: last.to } : null;
  selected = null; selectedTargets = [];
}

async function copyText(value) {
  try { await navigator.clipboard.writeText(String(value)); toast('Đã sao chép.', 'success'); }
  catch { const textarea = document.createElement('textarea'); textarea.value = String(value); document.body.appendChild(textarea); textarea.select(); const ok = document.execCommand('copy'); textarea.remove(); toast(ok ? 'Đã sao chép.' : 'Không sao chép được trên trình duyệt này.'); }
}
function downloadPgn() {
  const blob = new Blob([game.pgn() || '[Event "Chess Bot"]\n\n*'], { type: 'application/x-chess-pgn;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'chess-bot-game.pgn'; a.click(); URL.revokeObjectURL(url);
}
function stopOnlineStream() {
  if (onlineStreamController) { onlineStreamController.abort(); onlineStreamController = null; }
}

// Boot
$$('.tab').forEach(tab => tab.addEventListener('click', () => setView(tab.dataset.view)));
$('#openSettings')?.addEventListener('click', () => setView('settings'));
renderView();
initEngine();

