import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';

test('starting position has 20 legal moves', () => {
  const game = new Chess();
  assert.equal(game.moves().length, 20);
});

test('rejects illegal move', () => {
  const game = new Chess();
  assert.throws(() => game.move('e5'));
});

test('supports kingside castling', () => {
  const game = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
  game.move('O-O');
  assert.equal(game.get('g1')?.type, 'k');
  assert.equal(game.get('f1')?.type, 'r');
});

test('supports en passant capture', () => {
  const game = new Chess();
  for (const san of ['e4', 'a6', 'e5', 'd5', 'exd6']) game.move(san);
  assert.equal(game.get('d6')?.type, 'p');
  assert.equal(game.get('d5'), null);
});

test('supports pawn promotion', () => {
  const game = new Chess('7k/P7/8/8/8/8/8/7K w - - 0 1');
  game.move({ from: 'a7', to: 'a8', promotion: 'q' });
  assert.equal(game.get('a8')?.type, 'q');
});

test('detects checkmate', () => {
  const game = new Chess();
  for (const san of ['f3', 'e5', 'g4', 'Qh4#']) game.move(san);
  assert.equal(game.isCheckmate(), true);
});


test('detects stalemate without check', () => {
  const game = new Chess('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1');
  assert.equal(game.isStalemate(), true);
  assert.equal(game.isCheck(), false);
  assert.equal(game.isDraw(), true);
});

test('exported PGN contains the legal move history', () => {
  const game = new Chess();
  game.move('e4');
  game.move('e5');
  assert.match(game.pgn(), /1\. e4 e5/);
});
