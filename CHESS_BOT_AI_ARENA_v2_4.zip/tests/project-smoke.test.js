import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('Auto engine selection module and UI option exist', () => {
  const helper = read('src/engine-profile.js');
  const main = read('src/main.js');
  assert.match(helper, /deviceMemory/);
  assert.match(helper, /hardwareConcurrency/);
  assert.match(main, /value=\"auto\"/);
  assert.match(main, /resolveEngineProfile/);
});

test('Stockfish Lite and Full single-thread assets are required for production build', () => {
  const script = read('scripts/copy-engine.mjs');
  for (const name of [
    'stockfish-19-lite-single.js',
    'stockfish-19-lite-single.wasm',
    'stockfish-19-single.js',
    'stockfish-19-single.wasm'
  ]) assert.ok(script.includes(name), `Missing engine asset declaration: ${name}`);
  assert.match(script, /REQUIRE_STOCKFISH/);
});

test('Android workflow fails instead of silently shipping without Stockfish', () => {
  const workflow = read('.github/workflows/build-android.yml');
  assert.match(workflow, /REQUIRE_STOCKFISH:\s*'1'/);
  assert.match(workflow, /npm test/);
  assert.match(workflow, /assembleDebug/);
});

test('UI includes core Play, Arena, Openings, Coach, Lichess and Settings views', () => {
  const html = read('index.html');
  for (const view of ['play', 'arena', 'openings', 'coach', 'lichess', 'settings']) {
    assert.ok(html.includes(`data-view="${view}"`), `Missing ${view} navigation`);
  }
});

test('Backend protects public binds with access token', () => {
  const server = read('server/index.js');
  assert.match(server, /TUBOR_ACCESS_TOKEN/);
  assert.match(server, /HOST/);
});


test('Chess Bot branding assets and Android resource pipeline are present', () => {
  const html = read('index.html');
  const config = JSON.parse(read('capacitor.config.json'));
  const packageJson = JSON.parse(read('package.json'));
  const brandingScript = read('scripts/apply-android-branding.mjs');
  const androidWorkflow = read('.github/workflows/build-android.yml');
  const zipWorkflow = read('.github/workflows/build-from-zip.yml');
  const style = read('src/style.css');
  assert.equal(config.appName, 'Chess Bot');
  assert.equal(packageJson.name, 'chess-bot-ai');
  assert.match(packageJson.scripts['android:init'], /apply-android-branding\.mjs/);
  assert.match(style, /--accent:#4bbfff/);
  assert.match(html, /chess-bot-icon\.webp/);
  assert.match(html, /Chess Bot — AI Chess Arena/);
  for (const asset of [
    'public/chess-bot-logo.webp', 'public/chess-bot-icon.png', 'public/chess-bot-icon.webp', 'public/favicon.ico',
    'resources/android-icons/mipmap-mdpi/ic_launcher.png',
    'resources/android-icons/mipmap-xxxhdpi/ic_launcher.png',
    'resources/android-icons/mipmap-anydpi-v26/ic_launcher.xml'
  ]) assert.ok(fs.existsSync(path.join(root, asset)), `Missing branding asset: ${asset}`);
  assert.match(brandingScript, /ic_launcher_foreground/);
  assert.match(androidWorkflow, /apply-android-branding\.mjs/);
  assert.match(zipWorkflow, /apply-android-branding\.mjs/);
});
