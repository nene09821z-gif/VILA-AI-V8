import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { timingSafeEqual } from 'node:crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));

const CORS_ORIGINS = (process.env.CORS_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173,capacitor://localhost,https://localhost,http://localhost').split(',').map(x => x.trim()).filter(Boolean);
const ACCESS_SECRET = process.env.TUBOR_ACCESS_TOKEN || '';
app.use('/api', (req, res, next) => {
  const origin = req.headers.origin;
  if (origin && CORS_ORIGINS.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  if (ACCESS_SECRET && req.path !== '/health') {
    const supplied = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const a = Buffer.from(supplied);
    const b = Buffer.from(ACCESS_SECRET);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return res.status(401).json({ error: 'Backend yêu cầu mã truy cập hợp lệ.' });
  }
  next();
});

const PORT = Number(process.env.PORT || 8787);
// Bind only to loopback by default. Public deployments require an access token.
const HOST = process.env.HOST || '127.0.0.1';
const isLoopbackHost = ['127.0.0.1', 'localhost', '::1'].includes(HOST.toLowerCase());
if (!isLoopbackHost && !ACCESS_SECRET) {
  console.error('[TUBOR] Refusing to expose the AI/Lichess proxy without TUBOR_ACCESS_TOKEN. Configure a long random token first.');
  process.exit(1);
}

const aiRateBuckets = new Map();
const AI_RATE_LIMIT_PER_MINUTE = Math.max(10, Math.min(600, Number(process.env.AI_RATE_LIMIT_PER_MINUTE || 120)));
function limitAiCalls(req, res, next) {
  const now = Date.now();
  const key = req.ip || req.socket?.remoteAddress || 'unknown';
  let bucket = aiRateBuckets.get(key);
  if (!bucket || now - bucket.startedAt >= 60_000) bucket = { startedAt: now, count: 0 };
  bucket.count++;
  aiRateBuckets.set(key, bucket);
  if (aiRateBuckets.size > 2000) {
    for (const [ip, item] of aiRateBuckets) if (now - item.startedAt >= 60_000) aiRateBuckets.delete(ip);
  }
  if (bucket.count > AI_RATE_LIMIT_PER_MINUTE) {
    res.setHeader('Retry-After', String(Math.max(1, Math.ceil((60_000 - (now - bucket.startedAt)) / 1000))));
    return res.status(429).json({ error: `Đã vượt giới hạn ${AI_RATE_LIMIT_PER_MINUTE} yêu cầu AI/phút. Hãy đợi rồi thử lại.` });
  }
  next();
}

function sendUpstreamError(res, status, message) {
  return res.status(status).json({ error: message || 'Dịch vụ bên ngoài trả về lỗi.' });
}
function cleanString(value, max = 8000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function normalizeBaseUrl(raw) {
  const value = cleanString(raw, 2000);
  if (!value) throw new Error('Bạn cần nhập endpoint API.');
  let url;
  try { url = new URL(value); } catch { throw new Error('Endpoint không đúng định dạng URL.'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Endpoint chỉ được dùng HTTP hoặc HTTPS.');
  return url.toString().replace(/\/$/, '');
}
function openAiChatUrl(endpoint) {
  const base = normalizeBaseUrl(endpoint);
  if (/\/chat\/completions$/i.test(base)) return base;
  return `${base}/chat/completions`;
}
function anthropicMessagesUrl(endpoint) {
  const base = normalizeBaseUrl(endpoint || 'https://api.anthropic.com');
  if (/\/v1\/messages$/i.test(base)) return base;
  if (/\/v1$/i.test(base)) return `${base}/messages`;
  return `${base}/v1/messages`;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Chess Bot', version: '1.4.0' }));

app.post('/api/ai/chat', limitAiCalls, async (req, res) => {
  const mode = cleanString(req.body?.mode || 'openai-compatible', 40).toLowerCase();
  const endpoint = cleanString(req.body?.endpoint, 2000);
  const apiKey = cleanString(req.body?.apiKey, 4000);
  const model = cleanString(req.body?.model, 200);
  const messages = Array.isArray(req.body?.messages) ? req.body.messages.slice(-24) : [];
  const system = cleanString(req.body?.system, 8000);
  if (!model) return sendUpstreamError(res, 400, 'Hãy nhập tên model AI trong Cài đặt.');
  if (!messages.length) return sendUpstreamError(res, 400, 'Chưa có nội dung để gửi AI.');
  if (messages.some(m => !m || !['user', 'assistant', 'system'].includes(m.role) || typeof m.content !== 'string')) {
    return sendUpstreamError(res, 400, 'Định dạng hội thoại không hợp lệ.');
  }
  try {
    let url;
    let headers = { 'Content-Type': 'application/json' };
    let payload;
    if (mode === 'gemini') {
      const base = endpoint ? normalizeBaseUrl(endpoint) : 'https://generativelanguage.googleapis.com';
      if (!apiKey && !/[?&]key=[^&]+/.test(base)) return sendUpstreamError(res, 400, 'Gemini cần API key.');
      url = /:generateContent(?:\?|$)/.test(base)
        ? base
        : `${base.replace(/\/$/, '')}/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const contents = messages.filter(m => m.role !== 'system').map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      }));
      payload = { contents, generationConfig: { temperature: Number.isFinite(Number(req.body?.temperature)) ? Math.min(1.5, Math.max(0, Number(req.body.temperature))) : 0.7 } };
      if (system) payload.systemInstruction = { parts: [{ text: system }] };
    } else if (mode === 'anthropic') {
      if (!apiKey) return sendUpstreamError(res, 400, 'Anthropic cần API key.');
      url = anthropicMessagesUrl(endpoint || 'https://api.anthropic.com');
      headers['x-api-key'] = apiKey;
      headers['anthropic-version'] = '2023-06-01';
      payload = {
        model,
        max_tokens: Math.max(128, Math.min(8192, Number(req.body?.maxTokens || 1200))),
        messages: messages.filter(m => m.role !== 'system').map(m => ({ role: m.role, content: m.content })),
        temperature: Number.isFinite(Number(req.body?.temperature)) ? Math.min(1.5, Math.max(0, Number(req.body.temperature))) : 0.7
      };
      if (system) payload.system = system;
    } else {
      url = openAiChatUrl(endpoint || 'https://api.openai.com/v1');
      if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
      payload = {
        model,
        messages: [...(system ? [{ role: 'system', content: system }] : []), ...messages],
        temperature: Number.isFinite(Number(req.body?.temperature)) ? Math.min(1.5, Math.max(0, Number(req.body.temperature))) : 0.7,
        stream: false
      };
    }
    const upstream = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload), signal: AbortSignal.timeout(90000) });
    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { message: raw.slice(0, 1000) }; }
    if (!upstream.ok) {
      const detail = data?.error?.message || data?.message || `HTTP ${upstream.status}`;
      return sendUpstreamError(res, 502, `AI API lỗi (${upstream.status}): ${String(detail).slice(0, 500)}`);
    }
    const text = mode === 'gemini'
      ? (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n').trim()
      : mode === 'anthropic'
        ? (data?.content || []).filter(part => part?.type === 'text').map(part => part.text || '').join('\n').trim()
        : (data?.choices?.[0]?.message?.content ?? data?.choices?.[0]?.text ?? '');
    if (!text) return sendUpstreamError(res, 502, 'API đã phản hồi nhưng không có nội dung văn bản. Hãy kiểm tra model/endpoint.');
    res.json({ text, model: data?.model || model, usage: data?.usage || null });
  } catch (error) {
    res.status(502).json({ error: `Không gọi được AI API: ${String(error?.message || error).slice(0, 400)}` });
  }
});

async function lichessRequest(pathname, token, options = {}) {
  const cleanToken = cleanString(token, 4000);
  if (!cleanToken) throw new Error('Hãy nhập Lichess personal access token. Token không được gửi vào mã nguồn công khai.');
  return fetch(`https://lichess.org${pathname}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${cleanToken}`,
      Accept: options.accept || 'application/json',
      ...(options.method === 'POST' ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}),
      ...(options.headers || {})
    },
    signal: options.signal || AbortSignal.timeout(30000)
  });
}

app.post('/api/lichess/account', async (req, res) => {
  try {
    const upstream = await lichessRequest('/api/account', req.body?.token);
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.id, username: data.username, title: data.title || '', perfs: data.perfs || {} });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/challenge-ai', async (req, res) => {
  try {
    const level = Math.max(1, Math.min(8, Number(req.body?.level || 3)));
    const limit = Math.max(0, Math.min(10800, Number(req.body?.clockLimit || 300)));
    const increment = Math.max(0, Math.min(180, Number(req.body?.clockIncrement || 0)));
    const form = new URLSearchParams({ level: String(level), 'clock.limit': String(limit), 'clock.increment': String(increment), color: ['white', 'black', 'random'].includes(req.body?.color) ? req.body.color : 'random' });
    const upstream = await lichessRequest('/api/challenge/ai', req.body?.token, { method: 'POST', body: form.toString() });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.id, url: data.url, color: data.color, status: data.status, raw: data });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/challenge-user', async (req, res) => {
  try {
    const username = cleanString(req.body?.username, 80).replace(/^@/, '');
    if (!/^[a-zA-Z0-9_-]{2,30}$/.test(username)) return res.status(400).json({ error: 'Tên người chơi Lichess không hợp lệ.' });
    const limit = Math.max(0, Math.min(10800, Number(req.body?.clockLimit || 300)));
    const increment = Math.max(0, Math.min(180, Number(req.body?.clockIncrement || 0)));
    const form = new URLSearchParams({ rated: 'false', 'clock.limit': String(limit), 'clock.increment': String(increment), color: ['white', 'black', 'random'].includes(req.body?.color) ? req.body.color : 'random', variant: 'standard' });
    const upstream = await lichessRequest(`/api/challenge/${encodeURIComponent(username)}`, req.body?.token, { method: 'POST', body: form.toString() });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.challenge?.id || data.id, url: data.challenge?.url || data.url, status: data.challenge?.status || data.status, raw: data });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/move', async (req, res) => {
  try {
    const gameId = cleanString(req.body?.gameId, 100);
    const move = cleanString(req.body?.move, 10);
    if (!/^[a-zA-Z0-9]{8}$/.test(gameId)) return res.status(400).json({ error: 'Mã ván Lichess không hợp lệ.' });
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(move)) return res.status(400).json({ error: 'Nước đi phải ở định dạng UCI, ví dụ e2e4.' });
    const apiMode = req.body?.apiMode === 'bot' ? 'bot' : 'board';
    const route = apiMode === 'bot' ? `/api/bot/game/${gameId}/move/${move}` : `/api/board/game/${gameId}/move/${move}`;
    const upstream = await lichessRequest(route, req.body?.token, { method: 'POST', body: '' });
    const text = await upstream.text();
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, text || `Lichess HTTP ${upstream.status}`);
    res.json({ ok: true, response: text });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/stream', async (req, res) => {
  try {
    const gameId = cleanString(req.body?.gameId, 100);
    if (!/^[a-zA-Z0-9]{8}$/.test(gameId)) return res.status(400).json({ error: 'Mã ván Lichess không hợp lệ.' });
    const apiMode = req.body?.apiMode === 'bot' ? 'bot' : 'board';
    const route = apiMode === 'bot' ? `/api/bot/game/stream/${gameId}` : `/api/board/game/stream/${gameId}`;
    const upstream = await lichessRequest(route, req.body?.token, { method: 'GET', accept: 'application/x-ndjson' });
    if (!upstream.ok || !upstream.body) {
      const message = await upstream.text().catch(() => 'Lichess không mở được luồng ván cờ.');
      return sendUpstreamError(res, upstream.status || 502, message.slice(0, 500));
    }
    res.status(200);
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    Readable.fromWeb(upstream.body).pipe(res);
    res.on('close', () => { try { upstream.body.cancel(); } catch {} });
  } catch (error) { if (!res.headersSent) res.status(400).json({ error: String(error.message || error) }); }
});

app.get('/api/openings/explorer', async (req, res) => {
  try {
    const moves = cleanString(req.query.moves, 1000).split(',').filter(Boolean).slice(0, 40);
    if (moves.some(m => !/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(m))) return res.status(400).json({ error: 'Danh sách nước UCI không hợp lệ.' });
    const url = new URL('https://explorer.lichess.ovh/lichess');
    url.searchParams.set('variant', 'standard');
    url.searchParams.set('speeds[]', 'blitz');
    url.searchParams.set('ratings[]', '1600');
    url.searchParams.set('moves', moves.join(','));
    const upstream = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Opening Explorer HTTP ${upstream.status}`);
    res.json(data);
  } catch (error) { res.status(502).json({ error: `Không lấy được dữ liệu khai cuộc: ${String(error.message || error)}` }); }
});

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(root, 'dist')));
  app.get('/{*splat}', (_req, res) => res.sendFile(path.join(root, 'dist', 'index.html')));
}

app.listen(PORT, HOST, () => {
  console.log(`[Chess Bot] API server listening on http://${HOST}:${PORT}`);
  if (process.env.NODE_ENV === 'production') console.log('[Chess Bot] Production mode: serving dist/');
});
