# Chess Bot AI Arena v2.4 — Báo cáo kiểm thử

Ngày: 2026-10-16

## Đã chạy thành công
- `node --check src/main.js`: passed.
- `node --check src/engine-profile.js`: passed.
- `node --check server/index.js`: passed.
- `node --check scripts/copy-engine.mjs`: passed.
- `node --check tests/engine-profile.test.js`: passed.
- `node --check tests/chess.test.js`: passed.
- `node --check tests/project-smoke.test.js`: passed.
- `node --check scripts/start.mjs`: passed.
- `node --test tests/project-smoke.test.js tests/engine-profile.test.js`: 11/11 passed.
- Script `scripts/apply-android-branding.mjs` passed against a temporary Android project fixture; all generated XML files parsed successfully, and launcher icons plus app label were verified.
- Đã thêm 5 test cho lựa chọn engine tự động, ngưỡng thiết bị, override thủ công và mô tả profile.

## Chưa xác nhận trong môi trường này
- Đã thử `npm test`: 11 test đạt, nhưng test luật cờ `tests/chess.test.js` không khởi chạy do thiếu package `chess.js` (`ERR_MODULE_NOT_FOUND`).
- `npm install --no-audit --no-fund` không tải được dependencies do lỗi DNS `EAI_AGAIN` khi truy cập `registry.npmjs.org`.
- Vite production build và APK Android chưa được xác nhận; cần dependencies npm và Android SDK/Gradle hoặc GitHub Actions.
- Chưa chạy Stockfish WASM thực tế trên điện thoại và chưa kiểm tra kết nối API/Lichess với token thật.

## Thay đổi bản 1.4.0 Chess Bot
- Engine mặc định chuyển sang `auto`.
- Thêm `src/engine-profile.js`: Full nếu browser báo >= 6 GB RAM và >= 6 luồng CPU; Lite nếu thiếu thông tin hoặc thiết bị thấp hơn; có thể chọn Lite/Full thủ công.
- UI cài đặt mô tả ngưỡng tự động và rủi ro bộ nhớ/nhiệt.
- Trạng thái engine hiện Lite hoặc Full khi khởi động xong.
- Thêm test độc lập cho lựa chọn engine và cập nhật tài liệu.
- APK offline bao gồm cả Lite + Full nên dung lượng gói sẽ lớn hơn; đây là đánh đổi để không cần tải engine khi ngoại tuyến.


## Logo và biểu tượng ứng dụng
- Thêm `public/chess-bot-logo.webp` và icon `public/chess-bot-icon.webp` cho giao diện; thêm PNG/ICO cho trình duyệt và lưu bản nguồn độ phân giải cao trong `resources/branding/`. Đồng bộ màu giao diện sang xanh navy, xanh điện và vàng kim.
- Thêm launcher icon Android ở các mức mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi và adaptive icon XML.
- Thêm `scripts/apply-android-branding.mjs`; cả hai workflow build gọi script sau `cap sync` để đặt icon và nhãn app **Chess Bot**.
- Giữ `appId` và key cấu hình legacy `TUBOR_ACCESS_TOKEN` để tránh gây lỗi tương thích với setup hiện có.
