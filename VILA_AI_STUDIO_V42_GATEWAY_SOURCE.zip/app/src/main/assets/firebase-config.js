/* Firebase client config generated from the supplied google-services.json.
 * The Android client ID is configured. Add the Firebase Web App appId and OAuth Web Client ID
 * before relying on browser preview / Google sign-in; those values are not present in google-services.json.
 * Do not place Firebase Admin service-account credentials in this file.
 */
window.VILA_FIREBASE_CONFIG = {
  "apiKey": "AIzaSyDhG7wFiN1JEpTAV1Hvbj4HpOmpmlUcMy0",
  "authDomain": "vila-studio.firebaseapp.com",
  "projectId": "vila-studio",
  "storageBucket": "vila-studio.firebasestorage.app",
  "messagingSenderId": "106926396056",
  "appId": "",
  "androidAppId": "1:106926396056:android:f2b6f557426c68468236ed",
  "webClientId": ""
};
