'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const config = fs.readFileSync(path.join(root, 'app/src/main/assets/firebase-config.js'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const setup = fs.readFileSync(path.join(root, 'FIREBASE_SETUP_V41.txt'), 'utf8');

for (const dep of [
  'com.google.firebase:firebase-bom:34.19.0',
  'com.google.firebase:firebase-auth',
  'androidx.credentials:credentials:1.3.0',
  'androidx.credentials:credentials-play-services-auth:1.3.0',
  'com.google.android.libraries.identity.googleid:googleid:1.1.1'
]) assert.ok(gradle.includes(dep), `Missing Firebase dependency ${dep}`);
assert.ok(gradle.includes('versionCode 48') && gradle.includes('versionName "42.0.0"'), 'V42 version must be bumped');
for (const method of [
  'initVilaFirebaseAuth()', 'vilaFirebaseStateJson()', 'firebaseEmailRegister(String email, String password)',
  'firebaseEmailLogin(String email, String password)', 'firebasePasswordReset(String email)',
  'firebaseGoogleLogin()', 'firebaseLogout()', 'GetGoogleIdOption',
  'GoogleIdTokenCredential.createFrom', 'GoogleAuthProvider.getCredential',
  'signInWithCredential(firebaseCredential)', 'sendPasswordResetEmail(cleanEmail)', 'clearCredentialStateAsync'
]) assert.ok(java.includes(method), `Missing native Firebase auth feature: ${method}`);
for (const field of ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId', 'androidAppId', 'webClientId']) {
  assert.ok(config.includes('\"' + field + '\":'), `Missing Firebase client config field ${field}`);
}
const configStart = config.indexOf('{', config.indexOf('window.VILA_FIREBASE_CONFIG'));
const configEnd = config.lastIndexOf('}');
assert.doesNotThrow(() => JSON.parse(config.slice(configStart, configEnd + 1)), 'Firebase config object must be parseable by native JSONObject');
for (const method of ['window.onNativeFirebaseAuthResult', 'window.emailRegister', 'window.emailLogin', 'window.googleLogin', 'window.resetAccountPassword', 'window.logoutAccount']) {
  assert.ok(html.includes(method), `Missing UI auth integration ${method}`);
}
assert.ok(html.includes('window.Android.firebaseGoogleLogin()'), 'Android Google login must use the native Credential Manager bridge');
assert.ok(html.includes('window.Android.firebaseEmailLogin(email,pw)'), 'Android email login must call native Firebase Auth when configured');
assert.ok(!/if\(window\.Android\)\s*\{[^}]*signInWithRedirect/s.test(html), 'APK must not use the WebView Google redirect flow');
for (const secret of ['FIREBASE_ANDROID_APP_ID', 'FIREBASE_WEB_CLIENT_ID']) assert.ok(workflow.includes(secret), `Missing workflow mapping for ${secret}`);
assert.ok(workflow.includes('node scripts/test-firebase-v41.js'), 'Firebase smoke test must be run by GitHub Actions');
for (const item of ['com.vila.ai', 'androidAppId', 'webClientId', 'SHA-1', 'FIREBASE_WEB_CLIENT_ID']) assert.ok(setup.includes(item), `Firebase setup documentation missing ${item}`);
console.log('PASS: Firebase Android Auth wiring, native Google Credential Manager path, email/password methods, V42 build configuration, and setup docs.');
