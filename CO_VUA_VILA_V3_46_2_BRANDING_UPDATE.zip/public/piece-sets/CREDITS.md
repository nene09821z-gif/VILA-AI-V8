# Cờ Vua VILA — piece-set notices

These nine SVG sets are optional open artwork fetched from the upstream Lichess public piece directory during a release build. The resulting SVGs are bundled locally and cached for offline play. Keep these author and license notices when redistributing.

| Set | Author | License | Source |
|---|---|---|---|
| fantasy | Maurizio Monge | MIT | https://github.com/lichess-org/lila/tree/master/public/piece/fantasy |
| spatial | Maurizio Monge | MIT | https://github.com/lichess-org/lila/tree/master/public/piece/spatial |
| celtic | Maurizio Monge | MIT | https://github.com/lichess-org/lila/tree/master/public/piece/celtic |
| chessnut | Alexis Luengas | Apache 2.0 | https://github.com/lichess-org/lila/tree/master/public/piece/chessnut |
| rhosgfx | RhosGFX | CC0 1.0 | https://github.com/lichess-org/lila/tree/master/public/piece/rhosgfx |
| kiwen-suwi | neverRare | CC BY 4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/kiwen-suwi |
| firi | James Faure | CC BY 4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/firi |
| totoy | Kosal Sen | CC BY 4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/totoy |
| shapes | flugsio | CC BY-SA 4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/shapes |

The license mapping is documented by Lichess at https://github.com/lichess-org/lila/blob/master/COPYING.md. Attribution licenses are included and credited by `scripts/fetch-piece-sets.mjs`. The `shapes` set remains under CC BY-SA 4.0. Cờ Vua VILA is not affiliated with or endorsed by Lichess. These are third-party piece artworks; the project does not copy Chess.com piece assets.
