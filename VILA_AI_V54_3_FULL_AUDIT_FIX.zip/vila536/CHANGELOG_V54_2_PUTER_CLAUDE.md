# VILA AI V54.2 — Claude via Puter.js and reliability audit

- Added Claude via Puter.js while preserving existing providers and Gateway routing.
- Claude model choices prefer the live model catalog exposed by `puter.ai.listModels('claude')`; a fallback catalog remains available offline.
- Passes `AbortSignal` to Puter streaming chat, surfaces SDK stream error chunks, and releases the controller after completion.
- Corrected the Android accessibility description to reference `@string/deepseek_accessibility_description`.
- GitHub Actions now chooses the highest versioned `VILA_AI*.zip` and flattens a nested `vila536/` project folder before Gradle validation.
- Fixed the localhost networking test so an IPv6 resolution of `localhost` reaches the test server.

## Notes

Puter authentication, per-account model access, network access, and quotas still require a real device/account test. Image attachments are sent as text placeholders by the current Puter adapter, not as native vision content.
