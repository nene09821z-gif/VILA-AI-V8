#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const serverTest = fs.readFileSync('server/test/audit-v54-1.test.js', 'utf8');
const activity = fs.readFileSync('app/src/main/java/com/vila/ai/MainActivity.java', 'utf8');
assert.match(html, /puter\.ai\.listModels\('claude'\)/, 'Claude model catalog should be discovered live from Puter');
assert.match(html, /id:'claude-sonnet-5'/, 'fallback catalog should point to a currently documented Claude model');
assert.match(html, /stream:true,signal:controller\.signal/, 'Puter chat must receive AbortSignal for real cancellation');
assert.match(html, /part\?\.type==='error'/, 'stream error chunks must not be mistaken for successful empty output');
assert.match(html, /releaseVilaChatAbortController\(controller\)/, 'Puter request controllers should be released');
assert.match(workflow, /sort -V \| tail -n 1/, 'workflow should choose the newest versioned ZIP');
assert.match(workflow, /Flattening nested Android project/, 'workflow should handle source ZIPs with a nested project directory');
assert.match(serverTest, /\.listen\(0, '::'\)/, 'localhost test listener should accept IPv6 resolution');
assert.match(activity, /setSupportMultipleWindows\(true\)/, 'Android WebView should support Puter authentication popups');
assert.match(activity, /onCreateWindow\(WebView parent/, 'authentication popup window should be handled in the app');
console.log('PASS: V54.2 Puter live model discovery, abort/error handling, controller cleanup, source ZIP selection/flattening and localhost test regression checks.');
