# VILA Pro V17

VILA Pro V17 giữ kiến trúc V16 và nâng cấp trải nghiệm chat theo hướng sạch, rõ, gần phong cách ChatGPT.

- Gemini API và URL endpoint hiện tại được giữ nguyên.
- VILA Server vẫn dùng `/api/chat`, `/api/search`, `/api/health`, `/api/config`.
- Chat nhanh, tự chọn model theo tác vụ và có fallback.
- Gửi ảnh, đọc PDF/DOCX và đọc ZIP dự án (cây file + nội dung code/văn bản).
- Memory/history vẫn lưu cục bộ.
- Giao diện giảm màu/hiệu ứng, tập trung vào nội dung.
- GitHub Actions build `app-debug.apk`.

## Endpoint

Gemini direct:
`https://generativelanguage.googleapis.com/v1beta/openai/chat/completions`

VILA Server:
`YOUR_SERVER/api/chat`

## Build

GitHub Actions → **VILA Pro V17 - Build APK** → Artifact `VILA-Pro-V17-debug`.
