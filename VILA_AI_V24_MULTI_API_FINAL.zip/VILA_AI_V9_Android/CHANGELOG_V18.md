# V18.0.0
- Tách endpoint Gemini sang endpoints.js; xoá VILA Server (UI, JS, bridge Java, thư mục server/).
- Rút gọn model; thêm chế độ Đen, panel suy nghĩ, /video (Veo), prompt tiếng Việt có dấu giọng vui.
- Chưa build/chạy thử trên máy thật.
