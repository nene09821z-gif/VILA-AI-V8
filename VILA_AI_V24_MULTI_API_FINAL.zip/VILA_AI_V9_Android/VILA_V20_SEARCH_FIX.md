# V20 Search Fix
- Google Search now validates the Gemini API key before calling the API.
- Search tries the selected model first, then falls back to Gemini 3.8 Flash, 3.7 Flash, and 3.5 Flash if the selected route/model rejects Google Search.
- Added a 35-second timeout so the UI does not hang indefinitely.
- Existing MainActivity.java was not modified by this patch.
