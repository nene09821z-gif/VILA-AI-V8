/* VILA Firebase configuration
 * Replace the empty strings with your Firebase Web App config.
 * Enable Authentication > Email/Password and Google in Firebase Console.
 * This file contains client configuration, not a server secret.
 */
window.VILA_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
