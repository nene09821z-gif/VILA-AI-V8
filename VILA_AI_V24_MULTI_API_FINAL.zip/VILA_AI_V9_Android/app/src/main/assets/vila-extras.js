/* VILA V18 extras: chế độ đen, panel suy nghĩ, tạo video Veo. */
(function () {
  'use strict';
  // ---------- Theme: Tối / Đen (AMOLED) ----------
  const css = document.createElement('style');
  css.textContent = `
  html[data-theme="black"]{--vila-bg:#000;--vila-panel:#000;--vila-card:#0a0a0a;--vila-border:#1c1c1c}
  html[data-theme="black"] body,html[data-theme="black"] [class*="bg-dark-"],html[data-theme="black"] .glass-panel{background:#000!important}
  .vila-think{margin:2px 0;color:#a1a1aa;font-size:12.5px}
  .vila-think summary{display:flex;align-items:center;gap:8px;cursor:pointer;list-style:none;user-select:none}
  .vila-think summary::-webkit-details-marker{display:none}
  .vila-think-dot{width:8px;height:8px;border-radius:50%;background:#a78bfa;animation:vilaPulse 1.1s ease-in-out infinite}
  .vila-think.done .vila-think-dot{animation:none;background:#52525b}
  .vila-think-label{background:linear-gradient(90deg,#71717a,#e4e4e7,#71717a);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:vilaShimmer 1.8s linear infinite}
  .vila-think.done .vila-think-label{animation:none;background:none;color:#a1a1aa}
  .vila-think-steps{margin:6px 0 0 4px;padding-left:14px;border-left:1px solid #3f3f46;list-style:none}
  .vila-think-steps li{padding:2px 0;opacity:.85}
  .vila-think-body{margin:6px 0 0;padding-left:14px;border-left:1px solid #3f3f46;white-space:pre-wrap;max-height:240px;overflow:auto}
  @keyframes vilaPulse{50%{opacity:.25;transform:scale(.7)}}
  @keyframes vilaShimmer{to{background-position:-200% 0}}`;
  document.head.appendChild(css);
  function applyTheme(t) { document.documentElement.setAttribute('data-theme', t); try { localStorage.setItem('vila_theme', t); } catch (_) {} }
  window.vilaSetTheme = applyTheme;
  applyTheme((function () { try { return localStorage.getItem('vila_theme') || 'dark'; } catch (_) { return 'dark'; } })());

  // ---------- Trạng thái suy nghĩ ----------
  const STEPS = ['Đọc kỹ câu hỏi', 'Lục lại trí nhớ cuộc trò chuyện', 'Cân nhắc vài hướng trả lời', 'Chọn hướng ổn nhất', 'Soạn câu trả lời có dấu đàng hoàng'];
  window.appendTypingIndicator = function () {
    const box = document.getElementById('chatMessages'); if (!box) return '';
    const id = 'typing_' + Date.now(), t0 = Date.now(); window.__vilaThinkStart = t0;
    const d = document.createElement('div'); d.id = id; d.className = 'flex gap-4 items-start';
    d.innerHTML = '<div class="vila-avatar shrink-0">V</div><details class="vila-think" open><summary><span class="vila-think-dot"></span><span class="vila-think-label">Đang suy nghĩ…</span><span class="vila-think-time">0s</span></summary><ol class="vila-think-steps"></ol></details>';
    box.appendChild(d); if (window.scrollToBottom) window.scrollToBottom();
    const ol = d.querySelector('ol'), tm = d.querySelector('.vila-think-time'); let i = 0;
    const add = function () { const li = document.createElement('li'); li.textContent = STEPS[i]; ol.appendChild(li); };
    add();
    const timer = setInterval(function () {
      if (!document.getElementById(id)) return clearInterval(timer);
      const s = Math.round((Date.now() - t0) / 1000); tm.textContent = s + 's';
      if (s > 0 && s % 2 === 0 && i < STEPS.length - 1) { i++; add(); }
    }, 1000);
    return id;
  };
  window.vilaShowThought = function (result) {
    const box = document.getElementById('chatMessages'); if (!box || !box.lastElementChild) return;
    const secs = Math.max(1, Math.round((Date.now() - (window.__vilaThinkStart || Date.now())) / 1000));
    const reasoning = String(result && result.reasoning || '').trim();
    const el = document.createElement('div'); el.className = 'vila-think done'; el.style.marginLeft = '48px';
    const head = '<span class="vila-think-dot"></span><span class="vila-think-label">🧠 Đã suy nghĩ ' + secs + ' giây</span>';
    if (reasoning) {
      el.innerHTML = '<details open><summary>' + head + '</summary><div class="vila-think-body"></div></details>';
      el.querySelector('.vila-think-body').textContent = reasoning;
    } else {
      // Gemini không trả reasoning content ở mức effort hiện tại -> chỉ hiện trạng thái đã suy nghĩ.
      el.innerHTML = '<div style="display:flex;align-items:center;gap:8px">' + head + '</div>';
    }
    box.insertBefore(el, box.lastElementChild);
  };

  // ---------- Tạo video bằng Veo (văn bản → video, ảnh → video) ----------
  window.vilaMakeVideo = async function (prompt, imageDataUrl) {
    const E = window.VILA_ENDPOINTS.gemini, key = (window.Android && typeof window.Android.getGeminiApiKey === 'function' ? (window.Android.getGeminiApiKey() || '') : '') || localStorage.getItem('vila_api_key') || '';
    if (!key) throw new Error('Cần Gemini API Key để tạo video (Veo).');
    const inst = { prompt: prompt };
    const m = imageDataUrl && /^data:([^;]+);base64,(.+)$/.exec(imageDataUrl);
    if (m) inst.image = { bytesBase64Encoded: m[2], mimeType: m[1] };
    const H = { 'Content-Type': 'application/json', 'x-goog-api-key': key };
    const j = async function (r) { const d = await r.json().catch(function () { return {}; }); if (!r.ok) throw new Error((d.error && d.error.message) || ('HTTP ' + r.status)); return d; };
    let d = await j(await fetch(E.nativeBase + '/models/' + E.videoModel + ':predictLongRunning', { method: 'POST', headers: H, body: JSON.stringify({ instances: [inst], parameters: { aspectRatio: '16:9' } }) }));
    const name = d.name; if (!name) throw new Error('Veo không trả về mã tác vụ.');
    for (let n = 0; n < 60 && !d.done; n++) { await new Promise(function (s) { setTimeout(s, 10000); }); d = await j(await fetch(E.nativeBase + '/' + name, { headers: H })); }
    if (!d.done) throw new Error('Quá thời gian chờ video (10 phút).');
    if (d.error) throw new Error(d.error.message || 'Veo báo lỗi.');
    const s = d.response && d.response.generateVideoResponse && d.response.generateVideoResponse.generatedSamples;
    const uri = s && s[0] && s[0].video && s[0].video.uri;
    if (!uri) throw new Error('Veo không trả về video (có thể bị bộ lọc an toàn chặn).');
    const v = await fetch(uri, { headers: { 'x-goog-api-key': key } }); if (!v.ok) throw new Error('Tải video lỗi HTTP ' + v.status);
    return URL.createObjectURL(await v.blob());
  };
  window.vilaAppendVideo = function (url) {
    const box = document.getElementById('chatMessages'); if (!box) return;
    const d = document.createElement('div'); d.className = 'flex gap-4 items-start';
    d.innerHTML = '<div class="vila-avatar shrink-0">V</div><div><p style="margin-bottom:8px">Video xong rồi nè, nóng hổi vừa ra lò 🎬</p><video controls playsinline style="max-width:100%;border-radius:12px"></video><p style="margin-top:6px"><a download="vila-video.mp4" style="color:#a78bfa;text-decoration:underline">Tải video</a></p></div>';
    d.querySelector('video').src = url; d.querySelector('a').href = url;
    box.appendChild(d); if (window.scrollToBottom) window.scrollToBottom();
  };
})();

/* V19: menu "+", camera/ảnh/video/ZIP, nút Suy nghĩ, nhãn giao diện */
(function () {
  'use strict';
  const $ = function (id) { return document.getElementById(id); };
  const ready = function (fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); };
  const toast = function (m, t) { if (window.showToast) window.showToast(m, t || 'info'); };
  const closeMenu = function () { if (window.closeInputTools) window.closeInputTools(); };

  function videoToFrames(file, n) {
    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(file), v = document.createElement('video');
      v.muted = true; v.playsInline = true; v.preload = 'auto';
      const out = [], base = file.name.replace(/\.[^.]+$/, '');
      const fail = function (msg) { URL.revokeObjectURL(url); reject(new Error(msg)); };
      v.onerror = function () { fail(file.name + ': không đọc được video này.'); };
      v.onloadedmetadata = function () {
        const dur = v.duration || 1, W = Math.min(768, v.videoWidth || 768), H = Math.round(W * (v.videoHeight || 432) / (v.videoWidth || 768));
        const c = document.createElement('canvas'); c.width = W; c.height = H; let i = 0;
        v.onseeked = function () {
          c.getContext('2d').drawImage(v, 0, 0, W, H);
          c.toBlob(function (b) {
            if (!b) return fail('Không lấy được khung hình.');
            out.push(new File([b], base + '-khung' + (i + 1) + '.jpg', { type: 'image/jpeg' })); i++;
            if (i >= n) { URL.revokeObjectURL(url); resolve(out); } else v.currentTime = dur * (i + 0.5) / n;
          }, 'image/jpeg', 0.8);
        };
        v.currentTime = dur * 0.5 / n;
      };
      v.src = url;
    });
  }

  ready(function () {
    const tb = $('themeToggleBtn'), tt = $('themeText');
    const label = function () { if (tt) tt.textContent = document.documentElement.getAttribute('data-theme') === 'black' ? 'Đen' : 'Tối'; };
    if (tb) tb.addEventListener('click', function () { window.vilaSetTheme(document.documentElement.getAttribute('data-theme') === 'black' ? 'dark' : 'black'); });
    new MutationObserver(label).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] }); label();

    const deep = $('deepThinkToggle'), lvl = $('reasoningLevel');
    if (deep && lvl) {
      deep.checked = lvl.value === 'high';
      deep.addEventListener('change', function () { lvl.value = deep.checked ? 'high' : 'medium'; lvl.dispatchEvent(new Event('change')); });
    }

    const cam = $('cameraInput'), med = $('mediaInput');
    if ($('cameraBtn')) $('cameraBtn').addEventListener('click', function () { closeMenu(); cam.click(); });
    if ($('mediaBtn')) $('mediaBtn').addEventListener('click', function () { closeMenu(); med.click(); });
    if ($('makeVideoBtn')) $('makeVideoBtn').addEventListener('click', function () {
      closeMenu(); const t = $('userPrompt'); if (!t) return;
      if (!/^\/video\s/i.test(t.value)) t.value = '/video ' + t.value;
      t.focus(); t.dispatchEvent(new Event('input')); toast('Mô tả video rồi bấm gửi. Đính kèm 1 ảnh để biến ảnh thành video.');
    });
    if ($('generateImageBtn')) $('generateImageBtn').addEventListener('click', closeMenu);
    if ($('attachFileBtn')) $('attachFileBtn').addEventListener('click', closeMenu);
    if (cam) cam.addEventListener('change', function (ev) { const f = Array.from(ev.target.files || []); ev.target.value = ''; if (f.length) window.handleFiles(f); });
    if (med) med.addEventListener('change', async function (ev) {
      const files = Array.from(ev.target.files || []); ev.target.value = ''; const out = [];
      for (const f of files) {
        if (f.type.indexOf('video/') === 0) {
          if (f.size > 200 * 1024 * 1024) { toast(f.name + ': video quá lớn (tối đa 200MB).', 'error'); continue; }
          try { toast('Đang lấy khung hình từ video…'); out.push.apply(out, await videoToFrames(f, 3)); } catch (err) { toast(err.message, 'error'); }
        } else out.push(f);
      }
      if (out.length) window.handleFiles(out);
    });
  });
})();
