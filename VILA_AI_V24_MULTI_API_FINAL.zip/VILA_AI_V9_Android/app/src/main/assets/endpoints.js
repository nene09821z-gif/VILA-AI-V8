/* VILA multi-provider API endpoints. No AI model runs on the phone. */
window.VILA_ENDPOINTS = Object.freeze({
  gemini: Object.freeze({
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    nativeBase: 'https://generativelanguage.googleapis.com/v1beta',
    defaultModel: 'gemini-3.8-flash'
  }),
  groq: Object.freeze({
    baseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile'
  }),
  cerebras: Object.freeze({
    baseUrl: 'https://api.cerebras.ai/v1',
    defaultModel: 'llama-3.3-70b'
  }),
  openrouter: Object.freeze({
    baseUrl: 'https://openrouter.ai/api/v1',
    defaultModel: 'openrouter/free'
  })
});
