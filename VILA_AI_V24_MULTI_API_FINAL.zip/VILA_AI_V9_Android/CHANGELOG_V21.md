# VILA V21.0.0

## Code / Project Workspace
- Gemini 3.8 Flash ưu tiên cho tác vụ lập trình với suy luận cao.
- Tăng output budget để giảm cắt code.
- ZIP được mở thành workspace có thể chỉnh sửa.
- AI trả về file thay đổi theo định dạng có đường dẫn; app áp dụng thay đổi và giữ file không đổi.
- Xuất ZIP bao gồm toàn bộ workspace, kể cả binary file đã giữ lại.
- Thêm kiểm tra nhanh JS/JSON trước khi xuất.

## Key
- Gemini API key tiếp tục dùng Android Keystore-backed AES-GCM.
