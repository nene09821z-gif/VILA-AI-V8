# VILA Pro V17.8.0 – sửa lỗi & nâng cấp bảo mật

## Sửa lỗi
- Trang đôi khi không tải được: cổng nội bộ 127.0.0.1:18787 giờ được mở trước khi nạp trang (trước đây mở ở luồng khác nên có thể chưa kịp), thêm reuse-address.
- Link ngoài trong câu trả lời AI không còn mở bên trong app (nơi có cầu nối `Android.*`). Link mở bằng trình duyệt; chỉ đăng nhập Google/Firebase được ở lại trong app.
- Bộ chọn file không còn kẹt khi lần chọn trước chưa trả kết quả.
- Proxy nội bộ: đường dẫn có `?query` không còn trả 404.
- Thêm lại workflow GitHub Actions (bản compact bị thiếu file này).

## Bảo mật
- Xem trước code chạy trong sandbox cô lập (bỏ `allow-same-origin`): code do AI sinh ra không đọc được API key trong localStorage của VILA. localStorage/sessionStorage trong xem trước được thay bằng bộ nhớ tạm.
- Proxy nội bộ: kiểm tra Host, giới hạn body 64 MB, bỏ CORS `*`.
- Tắt `allowBackup`.

## Lưu ý
- Cầu nối `Android.*` vẫn được nạp vào mọi frame, kể cả iframe xem trước. Muốn khóa hẳn cần dùng `WebViewCompat.addWebMessageListener` (thêm thư viện androidx.webkit).
- Danh sách model Gemini/Groq giữ nguyên, chưa đối chiếu với danh sách model hiện hành.
- Chưa build và chưa chạy thử trên máy thật.

## V17.9 — thêm Claude làm nhà cung cấp
- Thêm Anthropic Claude làm lựa chọn thứ ba bên cạnh Gemini và Groq: thẻ chọn ở màn hình khởi động, nút chọn + ô nhập API key riêng trong Cài đặt, bảng model, dòng endpoint.
- Model: claude-sonnet-5 (mặc định), claude-opus-5-5, claude-sonnet-5-5, claude-haiku-5-5, claude-fable-5-1.
- Gọi thẳng `https://api.anthropic.com/v1/messages` từ trình duyệt bằng header `anthropic-dangerous-direct-browser-access: true` — API key Claude nằm trên máy người dùng y như Gemini/Groq hiện tại, không qua VILA Server.
- Claude đọc được ảnh gửi kèm trực tiếp (không cần chuyển qua Gemini như Groq).
- Tìm kiếm web với Claude dùng công cụ `web_search_20250305` do Anthropic lo phần chạy, kèm danh sách nguồn ở cuối câu trả lời.
- **Lưu ý:** key Claude gõ trong Cài đặt vẫn lưu ở localStorage trên thiết bị — ai mở DevTools trên máy đó đọc được, giống hệt cách Gemini/Groq đang làm. Muốn an toàn hơn thì cần route qua VILA Server (chưa làm trong bản này).

## V17.9.1 — cải tiến giao diện
- Làm sạch UI theo hướng ChatGPT/Claude: bớt gradient tím, nền trung tính.
- Bubble tin nhắn người dùng gọn (nền tối solid, bo góc mềm).
- Tin nhắn AI bỏ khung glass; avatar thống nhất; typing indicator dạng chấm.
- Header gọn hơn, version badge V17.9; welcome message cập nhật Gemini/Groq/Claude.
- Ô nhập, quick actions, startup provider cards tinh chỉnh spacing/focus.
- Sửa typo "enpoiko" → "endpoint".

## V17.9.2 — kiểm tra & cải tiến UI
- Thêm logo vào header, aria-label cho nút chính.
- Ô nhập + nút gửi bỏ gradient tím, style composer thống nhất.
-  đồng bộ với welcome tĩnh (quick actions đầy đủ, copy Claude).
- Menu công cụ API ghi Gemini / Groq / Claude.
- Badge API key hỗ trợ phím Enter/Space; title cập nhật đủ 3 provider.
- Endpoints/API giữ nguyên.

## V17.9.3 — sửa lỗi API
- `toClaudeMessages`: gộp role liên tiếp, bắt đầu bằng user, chuẩn hóa media_type ảnh (jpg→jpeg).
- `formatApiError`: thông báo lỗi 401/403/404/413/429/400/5xx và lỗi mạng rõ theo provider (Gemini/Groq/Claude).
- Kiểm tra API key trước gửi tin lấy đúng key Claude/Groq từ storage.
- Groq: tăng max_tokens linh hoạt (2048–4096) thay vì cố định 1000.
- Bọc fetch Claude/OpenAI khi mất mạng; giữ nguyên endpoints.
