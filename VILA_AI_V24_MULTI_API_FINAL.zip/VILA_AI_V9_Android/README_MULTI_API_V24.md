# VILA Multi-API V24

V23 UI is retained. The API layer adds:
- Google Gemini native REST generateContent
- Groq OpenAI-compatible chat completions
- Cerebras OpenAI-compatible chat completions
- OpenRouter OpenAI-compatible chat completions (default free router: openrouter/free)
- Custom OpenAI-compatible API

No AI model runs locally; the APK only uses WebView fetch over Internet.
Keys are stored locally for non-Gemini providers. Gemini keeps the existing Android Keystore bridge.

Build:
1. Open the folder in Android Studio.
2. Sync Gradle.
3. Build > Build APK(s).
4. APK is under app/build/outputs/apk/debug/app-debug.apk.

Command line:
./gradlew :app:assembleDebug
