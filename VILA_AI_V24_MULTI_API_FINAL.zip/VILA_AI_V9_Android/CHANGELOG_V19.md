# V19.0.0
- UI kiểu DeepSeek; gom camera/ảnh/video/file vào nút +; bỏ nút trùng (menu, lệnh nhanh, hàng tiện ích).
- Xoá Claude; xin quyền camera/ảnh/video; chụp ảnh qua MediaStore.
- Chưa build/chạy thử trên máy thật.
