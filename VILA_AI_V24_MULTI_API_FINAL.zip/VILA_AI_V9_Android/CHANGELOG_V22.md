# VILA V22.0.0 — Direct File Chat

- File kết quả được hiển thị trực tiếp trong chat dưới dạng thẻ file, có tên, dung lượng và nút Tải xuống.
- Android lưu file qua MediaStore/Downloads khi người dùng bấm Tải xuống.
- Xuất project ZIP không tự tải ngay; ZIP được đính kèm trong chat như một file AI trả về.
- Khi AI sửa workspace, VILA tự kiểm tra JS/JSON và thực hiện một lượt sửa cú pháp tự động nếu phát hiện lỗi.
- Tăng giới hạn file text lên 2 MB/file và snapshot workspace lên 5.5 triệu ký tự; archive đọc text tối đa 6 triệu ký tự.
- Workspace đầy đủ được lưu IndexedDB, giữ cả binary file; localStorage chỉ giữ chỉ mục nhẹ.
- Gemini API key cho Veo/video ưu tiên lấy từ Android Keystore.
- Không cam kết tuyệt đối 0 lỗi build: Android/Gradle vẫn cần build thật trên môi trường Android để xác nhận compilation.
