# VILA V20.0.0 — Upgrade Notes

## Gemini-only AI
- Removed active Groq integration from the app UI and request path.
- Gemini uses the official Google Gemini API endpoint and OpenAI-compatible endpoint configuration.
- Supported primary text models in the UI: Gemini 3.8 Flash, Gemini 3.5 Flash-Lite, Gemini 3.1 Pro Preview.
- Reasoning level is mapped to low / medium / high through Gemini `reasoning_effort`.

## API key and endpoint settings
- Gemini API key is stored through the Android bridge using Android Keystore-backed AES/GCM encryption.
- Gemini endpoint is editable in Settings and persisted in native app preferences.
- Existing legacy `vila_api_key` localStorage values are migrated to secure native storage on startup when possible.

## AI search and files
- Auto web-search is enabled by default for freshness/search/download/file/link related requests and can be toggled from the search control.
- Gemini Google Search grounding is used for web research and source links are shown in the answer.
- Direct file links returned by search results can be handed to Android DownloadManager for download into Downloads when the URL is a supported file type.

## ZIP export
- Project ZIP export remains an explicit user action from the ZIP control/menu or generated-code ZIP button.
- Silent automatic ZIP creation was removed so the app does not unexpectedly create extra ZIP files.
- Exported metadata is versioned as 20.0.0.

## MainActivity.java preservation
- The original `MainActivity.java` content was preserved exactly in order.
- Only additive insertions were made for Gemini secure settings and direct file-download bridging.

## Build
- `app/build.gradle`: versionName 20.0.0, compileSdk/targetSdk 35, Java 17.
- GitHub Actions workflow sets up JDK 17, Android SDK 35/build-tools, and Gradle 8.9; it can extract a project ZIP before building when a ZIP is present in the repository.
