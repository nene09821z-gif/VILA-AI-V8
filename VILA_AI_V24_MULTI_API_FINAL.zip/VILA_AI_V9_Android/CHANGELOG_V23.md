# VILA AI V23.0.0

## 1–10 upgrade
- Optional Agent Server with server-side Gemini key and SSE streaming.
- Real build/test loop for Android projects when a trusted server has JDK/Android SDK/Gradle. Up to 3 repair rounds.
- Workspace snapshots in IndexedDB and rollback API.
- Local workspace diff view.
- Relevant-file context/indexing to reduce unnecessary prompt size.
- Direct chat file attachments remain supported; successful APK builds are attached to chat.
- HTTP build-job foundation keeps the Android UI responsive while the server builds.
- Scoped Android Downloads/MediaStore path retained for Android 10+.
- ZIP path-traversal validation on the server.
- Server token authentication and explicit `ALLOW_UNTRUSTED_BUILDS=true` gate for running uploaded code.
- Direct Gemini mode remains available as fallback when no Agent Server is configured.

## Security
The Build Agent executes project build scripts on the configured server. Run it only on a machine you control, preferably isolated/ephemeral. Never expose it publicly without HTTPS, authentication, network controls and a sandbox/container.
