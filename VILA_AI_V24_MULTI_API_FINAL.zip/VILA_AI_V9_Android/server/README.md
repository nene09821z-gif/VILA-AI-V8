# VILA Agent Server

Optional secure backend for VILA. It keeps the Gemini key on the server, streams Gemini responses, accepts a project ZIP for a real Gradle build, and returns compiler/build logs plus APK artifacts.

## Requirements
- Node.js 18+
- Linux server/PC
- `unzip`, `zip`, `git`
- Android SDK + JDK 17 + Gradle 8.9 (or project `gradlew`) for Android builds

## Start
Set `GEMINI_API_KEY` in the environment, optionally set `VILA_SERVER_TOKEN`, then:

```bash
node server.js
```

Point VILA's Agent Server URL at `http://YOUR_SERVER:8787`. For production use HTTPS and a reverse proxy.

The server never sends its Gemini API key to the APK.
