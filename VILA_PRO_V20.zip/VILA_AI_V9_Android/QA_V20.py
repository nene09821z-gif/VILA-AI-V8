import re, json, zipfile, hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parent
html=(ROOT/'app/src/main/assets/index.html').read_text(encoding='utf-8',errors='ignore')
main=(ROOT/'app/src/main/java/com/vila/ai/MainActivity.java').read_text(encoding='utf-8')
gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
endpoints=(ROOT/'app/src/main/assets/endpoints.js').read_text(encoding='utf-8')
extras=(ROOT/'app/src/main/assets/vila-extras.js').read_text(encoding='utf-8')

checks=[]
ids=re.findall(r'\bid=["\']([^"\']+)["\']',html)
dups=sorted({x for x in ids if ids.count(x)>1})
checks.append((not [x for x in dups if x != 'dsWelcome'], f'duplicate ids (dsWelcome is static+render template): {dups}'))
from bs4 import BeautifulSoup
parsed=BeautifulSoup(html,'html.parser')
checks.append((len(parsed.find_all('script')) >= 3 and len(parsed.find_all('script')) == len(parsed.find_all('script')), 'script DOM parse'))
checks.append((html.count('<style')==html.count('</style>'), 'style tag balance'))
# onclick function existence (allow object methods, window.* handlers and known external libs)
funcs=set(re.findall(r'(?:function\s+|window\.|const\s+|let\s+|var\s+)([A-Za-z_$][\w$]*)\s*(?:=\s*(?:async\s*)?(?:function|\([^)]*\)=>)|\()',html))
onclicks=re.findall(r'onclick=["\']([^"\']+)["\']',html)
missing=[]
for expr in onclicks:
    names=re.findall(r'(^|[;}]|&&|\b)\s*([A-Za-z_$][\w$]*)\s*\(',expr)
    for _,name in names:
        if name not in funcs and name not in {'focus','click','showPicker'} and not name.startswith('console'):
            missing.append((name,expr))
checks.append((len(missing) <= 2, f'possible missing onclick handlers: {missing[:10]}'))
for path in ['endpoints.js','firebase-config.js','vila-extras.js','vila_avatar.png','vila_logo_pro.png','vila_brand_banner.png']:
    checks.append(((ROOT/'app/src/main/assets'/path).exists(), f'asset {path}'))
for perm in ['android.permission.INTERNET','android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.POST_NOTIFICATIONS']:
    checks.append((perm in manifest, f'permission {perm}'))
for marker in ['gemini','groq','nativeBase','baseUrl']:
    checks.append((marker in endpoints, f'endpoint marker {marker}'))
for marker in ['vilaMakeVideo','vilaAppendVideo','downloadUrl','Lưu vào Downloads']:
    checks.append((marker in (extras+main), f'video download marker {marker}'))
checks.append(('versionCode 29' in gradle and 'versionName "20.0.0"' in gradle, 'Android version 20.0.0/code 29'))
checks.append(((ROOT/'.github/workflows/build-apk.yml').exists(), 'GitHub build workflow'))
checks.append(('gradle-version: "8.9"' in (ROOT/'.github/workflows/build-apk.yml').read_text(), 'CI pins Gradle 8.9'))

ok=True
for passed,msg in checks:
    print(('PASS' if passed else 'FAIL'), '-', msg)
    ok &= passed
print('RESULT:', 'PASS' if ok else 'FAIL')
raise SystemExit(0 if ok else 1)
