# VILA Pro V20
- Giao diện kiểu DeepSeek: header gọn (menu · model · chat mới), ô nhập có nút Suy nghĩ / Tìm kiếm / mic / + / gửi.
- Nút `+`: Chụp ảnh · Ảnh & video · File & ZIP · Tạo ảnh AI · Tạo video AI. Video được lấy 3 khung hình để AI xem.
- Chỉ còn Gemini + Groq (endpoint Gemini ở `assets/endpoints.js`). Đã xoá Claude và VILA Server.
- Quyền Android: camera, ảnh, video (Android 13+: READ_MEDIA_*), xin một lần lúc mở app.
- Đăng nhập email/Google: điền `assets/firebase-config.js` (xem FIREBASE_SETUP_V15.txt).


## V20 nâng cấp
- Giữ nguyên chức năng V19, không xoá Gemini/Groq, file/ZIP, ảnh/camera/video, web search, TTS, bộ nhớ, GitHub/Firebase.
- TTS Gemini dùng model 3.8 mới và có fallback.
- Video Veo có nút lưu thẳng vào Downloads bằng Android DownloadManager.
- WebView an toàn hơn và cleanup callback khi Activity đóng.
- Build version: 20.0.0 (29).
