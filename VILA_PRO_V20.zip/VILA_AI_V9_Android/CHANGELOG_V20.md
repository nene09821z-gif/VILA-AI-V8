# VILA Pro V20.0.0

- Giữ nguyên toàn bộ tính năng V19: Gemini, Groq, chat, file/ZIP/PDF/DOCX, ảnh, camera, video, web search, TTS, bộ nhớ, GitHub, Firebase.
- Cập nhật Gemini TTS sang `gemini-3.8-flash-tts` / `gemini-3.8-flash-lite-tts`, giữ fallback preview cũ để không làm mất khả năng đọc.
- Thêm nút `Lưu vào Downloads` cho video Veo; Android dùng DownloadManager + header API để tránh lỗi tải `blob:` trong WebView.
- Xin quyền micro cùng nhóm quyền khởi động, nhưng vẫn giữ kiểm tra quyền ngay khi bấm mic.
- WebView chặn mixed-content chủ động; bật remote debugging chỉ ở debug build.
- Dọn callback file khi Activity bị huỷ để tránh treo bộ chọn file.
- Tăng version Android: `20.0.0` / versionCode `29`.
- Cải thiện trạng thái API trong Cài đặt để hiển thị đúng Gemini/Groq.

## Kiểm thử
- JavaScript: `node --check` cho asset JS và inline script.
- Static audit: ID/handler, script balance, manifest permissions, version, endpoint.
- Build CI tiếp tục dùng Gradle 8.9 qua `gradle/actions/setup-gradle`; project vẫn chưa có binary `gradle-wrapper.jar` nên chưa thể chạy `./gradlew` offline trong gói này.
