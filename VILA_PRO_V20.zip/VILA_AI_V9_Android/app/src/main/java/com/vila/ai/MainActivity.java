package com.vila.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.app.DownloadManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.content.ContentValues;
import android.os.Environment;
import android.widget.*;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import android.speech.tts.UtteranceProgressListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.KeyStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    Uri camUri;
    LocalProxy proxy;
    android.content.SharedPreferences prefs;
    SpeechRecognizer speechRecognizer;
    TextToSpeech textToSpeech;
    static final int PORT = 18787;
    static final int REQ_NOTIFICATIONS = 1001;
    static final int REQ_PERMISSION_BOOT = 1004;
    static final int REQ_CAMERA_CAPTURE = 1003;
    static final String GITHUB_KEY_ALIAS = "VILA_GITHUB_PAT";
    static final String GITHUB_TOKEN_PREF = "github_token_enc";
    static final String GITHUB_IV_PREF = "github_token_iv";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vila", MODE_PRIVATE);
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                int lang = textToSpeech.setLanguage(new Locale("vi", "VN"));
                textToSpeech.setSpeechRate(0.94f);
                textToSpeech.setPitch(1.02f);
                textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { evaluateVoice("tts_start", ""); }
                    @Override public void onDone(String utteranceId) { evaluateVoice("tts_done", ""); }
                    @Override public void onError(String utteranceId) { evaluateVoice("tts_error", ""); }
                });
            }
        });
        proxy = new LocalProxy(this, PORT);
        proxy.bind();
        proxy.start();
        web = new WebView(this);
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setBackgroundColor(Color.rgb(3,7,18));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setOffscreenPreRaster(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            // Only the local app (and Google/Firebase sign-in) may load inside the WebView that owns the JS bridge.
            private boolean openExternal(String url) {
                if (url == null) return false;
                Uri u = Uri.parse(url);
                String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
                String path = u.getPath() == null ? "" : u.getPath();
                boolean local = sc.equals("http") && (host.equals("127.0.0.1") || host.equals("localhost")) && u.getPort() == PORT;
                boolean auth = sc.equals("https") && (host.equals("accounts.google.com") || (host.endsWith(".firebaseapp.com") && path.startsWith("/__/auth/")));
                if (local || auth || sc.equals("blob") || sc.equals("data") || sc.equals("about") || sc.equals("javascript")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return openExternal(url); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return openExternal(r.getUrl().toString()); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (params.isCaptureEnabled()) {
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.CAMERA"}, 1003);
                        Toast.makeText(MainActivity.this, "Hãy cấp quyền Camera rồi bấm Chụp ảnh lại", Toast.LENGTH_LONG).show();
                        callback.onReceiveValue(null); return true;
                    }
                    try {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "VILA_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        cam.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        if (fileCallback != null) { try { fileCallback.onReceiveValue(null); } catch (Exception ignored) {} fileCallback = null; }
                        fileCallback = callback; startActivityForResult(cam, 2002); return true;
                    } catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return true; }
                }
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                if (fileCallback != null) { try { fileCallback.onReceiveValue(null); } catch (Exception ignored) {} fileCallback = null; }
                try { startActivityForResult(intent, 2001); fileCallback = callback; return true; }
                catch (Exception e) { callback.onReceiveValue(null); return false; }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                req.setDescription("VILA AI đang tải file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
                dm.enqueue(req);
                Toast.makeText(this, "Đang tải file vào thư mục Downloads", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Không thể tải file", Toast.LENGTH_SHORT).show(); }
        });
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(web);
        web.loadUrl("http://127.0.0.1:" + PORT + "/");
        if (Build.VERSION.SDK_INT >= 23) {
            String[] want = Build.VERSION.SDK_INT >= 33
                ? new String[]{"android.permission.POST_NOTIFICATIONS", "android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO"}
                : (Build.VERSION.SDK_INT <= 28
                    ? new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}
                    : new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.READ_EXTERNAL_STORAGE"});
            ArrayList<String> need = new ArrayList<>();
            for (String p : want) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
            if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1004);
        }
    }


    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2002 && fileCallback != null) {
            Uri[] shot = null;
            if (resultCode == RESULT_OK && camUri != null) shot = new Uri[]{camUri};
            else if (camUri != null) { try { getContentResolver().delete(camUri, null, null); } catch (Exception ignored) {} }
            fileCallback.onReceiveValue(shot); fileCallback = null; camUri = null;
            return;
        }
        if (requestCode == 2001 && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
    public class AndroidBridge {

        @android.webkit.JavascriptInterface public void saveTextFile(String filename, String content, String mimeType) {
            try {
                String safeName = (filename == null ? "VILA_File.txt" : filename).replaceAll("[\\/:*?\"<>|]", "_");
                if (safeName.length() > 120) safeName = safeName.substring(0, 120);
                byte[] bytes = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);
                String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "text/plain" : mimeType.trim();
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mime);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Không tạo được file Downloads");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new IOException("Không mở được file"); out.write(bytes); }
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Không tạo được thư mục Downloads");
                    File file = new File(dir, safeName);
                    try (OutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Không thể lưu file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @android.webkit.JavascriptInterface public void startVoiceInput() {
            runOnUiThread(() -> MainActivity.this.startVoiceRecognition());
        }

        @android.webkit.JavascriptInterface public void stopVoiceInput() {
            runOnUiThread(() -> {
                if (speechRecognizer != null) {
                    try { speechRecognizer.stopListening(); } catch (Exception ignored) {}
                }
            });
        }

        @android.webkit.JavascriptInterface public void speakText(String text) {
            runOnUiThread(() -> speakSmoothText(text));
        }

        private void speakSmoothText(String text) {
            if (textToSpeech == null) return;
            String value = text == null ? "" : text.trim();
            if (value.isEmpty()) return;
            try {
                value = value.replaceAll("```[\\s\\S]*?```", "");
                value = value.replaceAll("[#*_`>]+", " ");
                value = value.replaceAll("\\s{2,}", " ").trim();
                if (value.isEmpty()) return;
                textToSpeech.setLanguage(new Locale("vi", "VN"));
                textToSpeech.setSpeechRate(0.94f);
                textToSpeech.setPitch(1.02f);
                textToSpeech.stop();
                final int maxChars = 3200;
                ArrayList<String> chunks = new ArrayList<>();
                String remaining = value;
                while (remaining.length() > maxChars) {
                    int cut = remaining.lastIndexOf('.', maxChars);
                    if (cut < 1200) cut = remaining.lastIndexOf('!', maxChars);
                    if (cut < 1200) cut = remaining.lastIndexOf('?', maxChars);
                    if (cut < 1200) cut = remaining.lastIndexOf(' ', maxChars);
                    if (cut <= 0) cut = maxChars;
                    chunks.add(remaining.substring(0, cut + (cut < remaining.length() && ".!?".indexOf(remaining.charAt(cut)) >= 0 ? 1 : 0)).trim());
                    remaining = remaining.substring(Math.min(remaining.length(), cut + 1)).trim();
                }
                if (!remaining.isEmpty()) chunks.add(remaining);
                for (int i = 0; i < chunks.size(); i++) {
                    String id = "VILA_REPLY_" + System.nanoTime() + "_" + i;
                    textToSpeech.speak(chunks.get(i), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, id);
                }
            } catch (Exception ignored) {}
        }

        @android.webkit.JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> {
                if (textToSpeech != null) {
                    try { textToSpeech.stop(); } catch (Exception ignored) {}
                }
            });
        }

        @android.webkit.JavascriptInterface public void saveGithubToken(String token) {
            try {
                String value = token == null ? "" : token.trim();
                if (value.isEmpty()) { clearGithubToken(); return; }
                byte[] iv = new byte[12];
                new java.security.SecureRandom().nextBytes(iv);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, getGithubSecretKey(), new GCMParameterSpec(128, iv));
                byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
                prefs.edit()
                    .putString(GITHUB_TOKEN_PREF, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                    .putString(GITHUB_IV_PREF, Base64.encodeToString(iv, Base64.NO_WRAP))
                    .apply();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Không thể lưu GitHub Token an toàn", Toast.LENGTH_LONG).show();
            }
        }

        @android.webkit.JavascriptInterface public void clearGithubToken() {
            prefs.edit().remove(GITHUB_TOKEN_PREF).remove(GITHUB_IV_PREF).apply();
        }

        @android.webkit.JavascriptInterface public boolean hasGithubToken() {
            return !getGithubToken().isEmpty();
        }

        @android.webkit.JavascriptInterface public void testGithubToken() {
            new Thread(() -> {
                int code = -1; String login = ""; String message = "";
                try {
                    String token = getGithubToken();
                    if (token.isEmpty()) throw new IOException("Chưa có GitHub Token");
                    URL url = new URL("https://api.github.com/user");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(10000); c.setReadTimeout(15000);
                    c.setRequestProperty("Accept", "application/vnd.github+json");
                    c.setRequestProperty("Authorization", "Bearer " + token);
                    c.setRequestProperty("X-GitHub-Api-Version", "2026-03-10");
                    code = c.getResponseCode();
                    InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    String json = new String(readAllStream(is), StandardCharsets.UTF_8);
                    if (code >= 200 && code < 300) {
                        try { login = new JSONObject(json).optString("login", "GitHub"); } catch (Exception ignored) {}
                        message = "GitHub OK • " + login;
                    } else {
                        try { message = new JSONObject(json).optString("message", "HTTP " + code); } catch (Exception ignored) { message = "HTTP " + code; }
                    }
                    c.disconnect();
                } catch (Exception e) { message = e.getMessage() == null ? "Lỗi kết nối GitHub" : e.getMessage(); }
                final int resultCode = code; final String resultMessage = message;
                runOnUiThread(() -> {
                    String js = "window.onGithubTokenTest && window.onGithubTokenTest(" + resultCode + "," + JSONObject.quote(resultMessage) + ");";
                    if (web != null) web.evaluateJavascript(js, null);
                });
            }).start();
        }

        private SecretKey getGithubSecretKey() throws Exception {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(GITHUB_KEY_ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(GITHUB_KEY_ALIAS, null)).getSecretKey();
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(GITHUB_KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build());
            return kg.generateKey();
        }

        private String getGithubToken() {
            try {
                String enc = prefs.getString(GITHUB_TOKEN_PREF, "");
                String ivText = prefs.getString(GITHUB_IV_PREF, "");
                if (enc.isEmpty() || ivText.isEmpty()) return "";
                byte[] iv = Base64.decode(ivText, Base64.DEFAULT);
                byte[] encrypted = Base64.decode(enc, Base64.DEFAULT);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, getGithubSecretKey(), new GCMParameterSpec(128, iv));
                return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
            } catch (Exception e) { return ""; }
        }

        private byte[] readAllStream(InputStream i) throws IOException {
            if (i == null) return new byte[0];
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] x = new byte[8192]; int k;
            while ((k = i.read(x)) > 0) b.write(x, 0, k);
            try { i.close(); } catch (Exception ignored) {}
            return b.toByteArray();
        }

        @android.webkit.JavascriptInterface public void saveBase64File(String filename, String base64, String mimeType) {
            try {
                String safeName = (filename == null ? "VILA_Image.png" : filename).replaceAll("[\\/:*?\"<>|]", "_");
                if (safeName.length() > 120) safeName = safeName.substring(0, 120);
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType.trim();
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mime);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Không tạo được file Downloads");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IOException("Không mở được file");
                        out.write(bytes);
                    }
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Không tạo được thư mục Downloads");
                    try (OutputStream out = new FileOutputStream(new File(dir, safeName))) { out.write(bytes); }
                }
                final String savedName = safeName;
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Đã lưu " + savedName + " vào Downloads", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Không thể lưu file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @android.webkit.JavascriptInterface public void downloadUrl(String url, String filename, String mimeType, String headerName, String headerValue) {
            try {
                if (url == null || url.trim().isEmpty()) throw new IOException("URL tải file trống");
                String safeName = (filename == null || filename.trim().isEmpty() ? URLUtil.guessFileName(url, null, mimeType) : filename)
                        .replaceAll("[\\/:*?\"<>|]", "_");
                if (safeName.length() > 140) safeName = safeName.substring(0, 140);
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                if (mimeType != null && !mimeType.trim().isEmpty()) req.setMimeType(mimeType.trim());
                if (headerName != null && !headerName.trim().isEmpty() && headerValue != null && !headerValue.isEmpty()) {
                    req.addRequestHeader(headerName.trim(), headerValue);
                }
                req.setTitle(safeName);
                req.setDescription("VILA AI đang lưu file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName);
                dm.enqueue(req);
                final String outName = safeName;
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Đang tải " + outName + " vào Downloads", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Không thể tải file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @android.webkit.JavascriptInterface public void setImmersiveMode(boolean enabled) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowInsetsController controller = getWindow().getInsetsController();
                    if (controller != null) {
                        if (enabled) {
                            controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                            controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        } else {
                            controller.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                        }
                        return;
                    }
                }
                int flags = enabled ? (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE) : View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                getWindow().getDecorView().setSystemUiVisibility(flags);
            });
        }
    }

    private void startVoiceRecognition() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.RECORD_AUDIO") != getPackageManager().PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 1003);
            Toast.makeText(this, "Cho phép micro rồi bấm mic lại", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Thiết bị chưa có dịch vụ nhận dạng giọng nói", Toast.LENGTH_LONG).show();
            return;
        }
        if (speechRecognizer != null) { try { speechRecognizer.destroy(); } catch (Exception ignored) {} }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { evaluateVoice("ready", ""); }
            @Override public void onBeginningOfSpeech() { evaluateVoice("listening", ""); }
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { evaluateVoice("processing", ""); }
            @Override public void onError(int error) { evaluateVoice("error", ""); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                evaluateVoice("result", text);
            }
            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> matches = partialResults == null ? null : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) evaluateVoice("partial", matches.get(0));
            }
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try { speechRecognizer.startListening(intent); } catch (Exception e) { Toast.makeText(this, "Không thể khởi động micro", Toast.LENGTH_SHORT).show(); }
    }

    private void evaluateVoice(String state, String text) {
        if (web == null) return;
        String js = "window.onVilaVoiceResult && window.onVilaVoiceResult(" + JSONObject.quote(state) + "," + JSONObject.quote(text == null ? "" : text) + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(fileCallback!=null){try{fileCallback.onReceiveValue(null);}catch(Exception ignored){} fileCallback=null;} if(speechRecognizer!=null){try{speechRecognizer.destroy();}catch(Exception ignored){}} if(textToSpeech!=null){try{textToSpeech.stop();textToSpeech.shutdown();}catch(Exception ignored){}} if(proxy!=null) proxy.stopServer(); super.onDestroy(); }

    static class LocalProxy extends Thread {
        final MainActivity ctx; final int port; volatile boolean running=true; ServerSocket ss;
        LocalProxy(MainActivity c,int p){ctx=c;port=p;}
        void bind(){if(ss!=null&&ss.isBound())return; try{ss=new ServerSocket(); ss.setReuseAddress(true); ss.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),port));}catch(Exception e){try{if(ss!=null)ss.close();}catch(Exception ignored){} ss=null;}}
        public void run(){if(ss==null)bind(); if(ss==null)return; while(running){try{Socket s=ss.accept(); new Thread(()->handle(s)).start();}catch(Exception ignored){}}}
        void handle(Socket s){try{s.setSoTimeout(15000); BufferedInputStream in=new BufferedInputStream(s.getInputStream()); OutputStream out=s.getOutputStream(); String request=readLine(in); if(request==null){s.close();return;} String[] p=request.split(" "); String method=p[0], path=p[1]; Map<String,String> headers=new HashMap<>(); String line; while((line=readLine(in))!=null&&!line.isEmpty()){int i=line.indexOf(':');if(i>0)headers.put(line.substring(0,i).toLowerCase(),line.substring(i+1).trim());}
            String hostH=headers.getOrDefault("host","").toLowerCase(Locale.ROOT); if(!(hostH.equals("127.0.0.1:"+port)||hostH.equals("localhost:"+port))){write(out,403,"text/plain; charset=utf-8","Forbidden".getBytes(StandardCharsets.UTF_8));s.close();return;}
            int len=0; try{len=Integer.parseInt(headers.getOrDefault("content-length","0"));}catch(Exception ignored){} if(len<0||len>64*1024*1024){write(out,413,"text/plain; charset=utf-8","Too large".getBytes(StandardCharsets.UTF_8));s.close();return;} byte[] body=new byte[len]; int off=0; while(off<len){int n=in.read(body,off,len-off);if(n<0)break;off+=n;}
            if(path.startsWith("/api/")){write(out,404,"text/plain; charset=utf-8","Not found".getBytes(StandardCharsets.UTF_8));}
            else {
                String cleanPath = path.indexOf('?')>=0 ? path.substring(0,path.indexOf('?')) : path;
                String assetPath = cleanPath.equals("/") ? "index.html" : cleanPath.substring(1);
                if(assetPath.contains("..") || assetPath.contains("\\")){
                    write(out,400,"text/plain; charset=utf-8","Bad path".getBytes(StandardCharsets.UTF_8));
                } else {
                    try {
                        byte[] data=asset(assetPath);
                        write(out,200,mimeType(assetPath),data);
                    } catch(Exception missing) {
                        write(out,404,"text/plain; charset=utf-8","Not found".getBytes(StandardCharsets.UTF_8));
                    }
                }
            }
            s.close();}catch(Exception ignored){try{s.close();}catch(Exception x){}}}
        String readLine(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();int c,prev=-1;while((c=in.read())!=-1){if(prev=='\r'&&c=='\n'){b.write('\r');break;}b.write(c);prev=c;if(b.size()>8192)break;}String x=b.toString("ISO-8859-1");return x.replace("\r","").replace("\n","");}
        byte[] asset(String n)throws IOException{InputStream i=ctx.getAssets().open(n);try{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}finally{try{i.close();}catch(Exception ignored){}}}
        String mimeType(String n){String x=n.toLowerCase(Locale.ROOT);if(x.endsWith(".html"))return "text/html; charset=utf-8";if(x.endsWith(".js"))return "application/javascript; charset=utf-8";if(x.endsWith(".css"))return "text/css; charset=utf-8";if(x.endsWith(".json"))return "application/json; charset=utf-8";if(x.endsWith(".png"))return "image/png";if(x.endsWith(".jpg")||x.endsWith(".jpeg"))return "image/jpeg";if(x.endsWith(".webp"))return "image/webp";if(x.endsWith(".svg"))return "image/svg+xml";if(x.endsWith(".ico"))return "image/x-icon";if(x.endsWith(".woff2"))return "font/woff2";if(x.endsWith(".woff"))return "font/woff";if(x.endsWith(".ttf"))return "font/ttf";return "application/octet-stream";}
        byte[] readAll(InputStream i)throws IOException{if(i==null)return new byte[0];ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}
        void write(OutputStream o,int code,String ct,byte[] data)throws IOException{String h="HTTP/1.1 "+code+" "+(code==200?"OK":code==503?"Service Unavailable":"Error")+"\r\nContent-Type: "+ct+"\r\nContent-Length: "+data.length+"\r\nConnection: close\r\n\r\n";o.write(h.getBytes(StandardCharsets.ISO_8859_1));o.write(data);o.flush();}
        void stopServer(){running=false;try{if(ss!=null)ss.close();}catch(Exception ignored){}}
    }
}
