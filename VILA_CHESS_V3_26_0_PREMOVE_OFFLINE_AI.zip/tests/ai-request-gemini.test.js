import test from 'node:test';
import assert from 'node:assert/strict';
import { buildChatPayload, adaptPayloadForProviderError } from '../server/ai-request.js';

test('Gemini 3.8 payload avoids unsupported legacy sampling fields and limits reasoning overhead', () => {
  const payload = buildChatPayload({
    mode: 'gemini', model: 'gemini-3.8-flash', temperature: 0.2, maxTokens: 32,
    messages: [{ role: 'user', content: 'Trả lời đúng một từ: OK' }]
  });
  assert.equal(payload.generationConfig.maxOutputTokens, 32);
  assert.deepEqual(payload.generationConfig.thinkingConfig, { thinkingLevel: 'low' });
  assert.equal('temperature' in payload.generationConfig, false);
  assert.equal('candidateCount' in payload.generationConfig, false);
  assert.equal(payload.contents[0].role, 'user');
});

test('Gemini 2.5 payload retains its supported legacy generation options', () => {
  const payload = buildChatPayload({
    mode: 'gemini', model: 'gemini-2.5-flash', temperature: 0.15, maxTokens: 96,
    messages: [{ role: 'user', content: 'hi' }]
  });
  assert.equal(payload.generationConfig.temperature, 0.15);
  assert.equal(payload.generationConfig.candidateCount, 1);
  assert.equal(payload.generationConfig.maxOutputTokens, 96);
});

test('OpenAI-compatible providers retry incompatible token/temperature parameters', () => {
  const original = { model: 'openai/gpt-oss-20b', max_tokens: 80, temperature: 0.3, messages: [] };
  const adapted = adaptPayloadForProviderError(original, 'max_tokens is not configurable; use max_completion_tokens and temperature is not configurable for this model');
  assert.equal(adapted.max_completion_tokens, 80);
  assert.equal('max_tokens' in adapted, false);
  assert.equal('temperature' in adapted, false);
  assert.equal(original.max_tokens, 80, 'original request must not be mutated');
});
