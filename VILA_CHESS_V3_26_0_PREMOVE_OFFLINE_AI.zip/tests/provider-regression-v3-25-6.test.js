import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server/index.js'), 'utf8');

test('Test AI action sends the configured model instead of an undefined modelOverride', () => {
  assert.match(main, /const data = await apiFetch\('\/api\/ai\/chat',[\s\S]{0,600}model: settings\.model/);
  assert.match(main, /const health = await apiFetch\('\/api\/health'/);
});

test('External OpenAI-compatible arena profiles require their own API key', () => {
  assert.match(main, /providerNeedsKey\(aiMode, endpoint\) && !apiKey/);
  assert.match(main, /providerNeedsKey\(player\.aiMode \|\| 'openai-compatible', player\.endpoint\) && !player\.apiKey/);
  assert.match(main, /providerNeedsKey\(white\.aiMode \|\| 'openai-compatible', white\.endpoint\) && !white\.apiKey/);
  assert.match(main, /providerNeedsKey\(black\.aiMode \|\| 'openai-compatible', black\.endpoint\) && !black\.apiKey/);
});

test('Gemini and OpenRouter credentials use headers rather than query strings', () => {
  assert.match(server, /headers\['x-goog-api-key'\] = apiKey/);
  assert.match(server, /headers\.Authorization = `Bearer \$\{apiKey\}`/);
  assert.match(server, /X-Title.*VILA Chess/);
});

test('captured material indicators are wired to the main play board and updated after moves', () => {
  assert.match(main, /summarizeCapturedMaterial\(game\.history\(\{ verbose: true \}\)\)/);
  assert.match(main, /updateCapturedMaterialDisplays\(\)/);
  assert.match(main, /captured-material-row/);
});
