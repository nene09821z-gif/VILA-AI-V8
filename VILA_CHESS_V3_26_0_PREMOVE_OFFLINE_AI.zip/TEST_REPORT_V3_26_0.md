# VILA Chess 3.26.0 — Test Report

## Tests run

- `npm run test:static`: **218 passed, 0 failed**.
- Additional engine/opening/rating tests: **9 passed, 0 failed**.
- Focused earlier regression selection: **91 passed, 0 failed**.
- `node --check` across JavaScript/ES module files under `src`, `tests`, `scripts` and `server`: passed.

Coverage added/checked includes premove FEN preview, actual-position premove revalidation, queen-default promotion, click/drag wiring, timer charging the actual side during bot thinking, clearing premoves at timeout, captured-piece artwork, new piece styles and the bounded offline fallback branch.

## Build limitation

`npm run build` was attempted but stopped in the `prebuild` step with `ERR_MODULE_NOT_FOUND: Cannot find package 'chess.js'` from `scripts/prepare-openings.mjs`. The extracted ZIP did not contain installed dependencies. An install attempt was blocked by DNS/network failure (`EAI_AGAIN` reaching `registry.npmjs.org`), so this environment could not build the Vite distribution or an Android APK.

## Not claimed as tested

- No live browser play-through, physical Android-device test, API-provider test or Stockfish-vs-human game was run.
- The 25 newly added opening SAN lines have not all been mechanically replay-validated here because `chess.js` was unavailable. Static catalog tests passed, but that is not equivalent to validating every SAN sequence.

## Suggested CI validation

Run `npm ci` (or `npm install` if no lockfile is supplied), then `npm run test:static` and `npm run build` in GitHub Actions. Add a SAN replay test for every curated opening row before considering the opening expansion fully verified.
