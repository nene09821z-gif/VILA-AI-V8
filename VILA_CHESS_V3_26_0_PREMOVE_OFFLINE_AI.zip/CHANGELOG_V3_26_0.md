# VILA Chess 3.26.0 — Premove, Piece Art & Offline Rescue

## Changes

- Added click/tap and drag-to-queue premoves during bot thinking. Queued moves are highlighted, can be cancelled by tapping the source square, and are revalidated against the real position after the bot move. Invalidated premoves are cancelled; promotions default to queen.
- Preserved the existing active-side chess clock while the bot searches. Timeout stops the game, clears queued premoves, cancels pending engine work and shows the timeout result. Added regression coverage for the clock/premove relationship.
- Replaced Unicode glyphs in captured-material rows with the actual selected local piece artwork for the captured colour, for both White and Black.
- Expanded piece appearance options to four styles: Flat PNG, Royal SVG, Neon SVG and Wood SVG. The shared renderer applies to the main board, other board views, captured-piece rows and drag pieces.
- Added a bounded VILA offline-engine rescue search when Stockfish cannot initialize or times out. The rescue validates the returned UCI move and keeps the basic legal-move fallback as a last resort.
- Increased search-core limits modestly for deeper offline analysis and added 25 named opening variations.
- Bumped project/API health version to 3.26.0 and added focused premove/artwork tests.

## Notes

- The additional opening lines are in the source catalog, but full SAN replay validation still needs the `chess.js` dependency; that dependency could not be installed in this environment. Do not treat all 25 lines as mechanically replay-verified by this run.
- The bounded offline rescue is a fallback for Stockfish failure, not a claim that the VILA JavaScript engine is stronger than a successfully running current Stockfish build.
