# VILA Chess V3.25.6 — Provider + Captured Material Fix

## Changes

- Added Chess.com-inspired captured-piece strips beneath each player's clock. Captured pieces are grouped by side, sorted by material value, and the positive material differential is shown as `+N`.
- The material tracker uses legal move history (including en passant records) and ignores malformed history records safely.
- Normalized Gemini Base URLs including a root URL, `/v1beta`, `/v1beta/models`, and a saved `:generateContent` URL. Gemini keys are transmitted using `x-goog-api-key`, not as query tokens.
- Updated Gemini 3.x/4.x payloads to use `thinkingConfig.thinkingLevel: "low"` without legacy `temperature` or `candidateCount`; older Gemini models keep their supported generation fields.
- Kept OpenRouter and Groq on the OpenAI-compatible protocol, with tested canonical `chat/completions` and `models` URLs, Bearer API key authentication, and OpenRouter `X-Title` metadata.
- Fixed the Settings “Test AI” action to use the saved model field instead of an undefined variable, and require separate API keys for external Arena profiles.
- Added provider auto-detection when the endpoint is changed. Improved errors for missing backend, HTML/static hosting instead of an API server, CORS, and bad endpoints.
- Updated older test assertions that hard-coded version `3.25.0` so they check `3.25.6` rather than failing after a release version bump.

## Verification

- `npm run test:static`: 211 tests passed, 0 failed.
- `node --check` for all project JavaScript and MJS files: passed.
- Targeted provider/material test set: 75 tests passed, 0 failed before the final two explicit OpenRouter/Groq URL assertions were added; those assertions are included in the passing 211-test static run.
- A production Vite/Android build and live calls to Gemini/OpenRouter/Groq have not been claimed: dependencies were not installed in this environment and live tests require the user's own valid API keys, quotas, and deployed Node.js backend.

## Required deployment configuration

- Gemini: Base URL `https://generativelanguage.googleapis.com/v1beta`, API mode `Gemini`, model ID available to the user's Google AI project, and a valid Gemini API key.
- OpenRouter: Base URL `https://openrouter.ai/api/v1`, API mode `OpenAI-compatible`, valid OpenRouter key, and a model ID that account can access (for example `openrouter/free` where available).
- Groq: Base URL `https://api.groq.com/openai/v1`, API mode `OpenAI-compatible`, valid Groq key, and a current supported model ID.
- When the UI is hosted on GitHub Pages or in an APK without a local Node server, deploy the project's Node.js backend to HTTPS and enter its URL under Settings → API backend URL. Configure `CORS_ORIGIN` to include the exact frontend origin when the frontend and backend domains differ. API keys are not included in the ZIP.
