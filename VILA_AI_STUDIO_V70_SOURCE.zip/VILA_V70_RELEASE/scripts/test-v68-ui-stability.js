'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const postcss = require('postcss');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const extras = fs.readFileSync(path.join(root, 'app/src/main/assets/vila-extras.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');

// Static HTML must not contain duplicate IDs that break click handlers or ARIA links.
const markupOnly = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '');
const idCounts = new Map();
for (const match of markupOnly.matchAll(/\bid=["']([^"']+)["']/gi)) idCounts.set(match[1], (idCounts.get(match[1]) || 0) + 1);
const duplicateIds = [...idCounts].filter(([, count]) => count > 1).map(([id]) => id);
assert.deepEqual(duplicateIds, [], `static HTML IDs must be unique, duplicates: ${duplicateIds.join(', ')}`);
const allLiteralIds = new Set([...html.matchAll(/\bid=["']([^"']+)["']/gi)].map(m => m[1]));
const getElementTargets = new Set([...html.matchAll(/getElementById\(['"]([^'"]+)['"]\)/g)].map(m => m[1]));
const absentTargets = [...getElementTargets].filter(id => !allLiteralIds.has(id));
assert.deepEqual(absentTargets, [], `literal getElementById targets must exist in markup or generated templates: ${absentTargets.join(', ')}`);

// Audit static inline button callbacks so source edits cannot leave dead function names behind.
const declaredFunctions = new Set([...html.matchAll(/\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g)].map(m => m[1]));
for (const m of html.matchAll(/\bwindow\.([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>)/g)) declaredFunctions.add(m[1]);
for (const m of html.matchAll(/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)/g)) declaredFunctions.add(m[1]);
const nativeCallNames = new Set(['if','function','alert','confirm','prompt','setTimeout','setInterval','requestAnimationFrame','fetch','window','document','console','JSON','String','Number','Boolean','Math','Array','Object','URL','Blob','navigator','history','location','event','stopPropagation','preventDefault']);
const inlineCalls = new Set();
for (const m of markupOnly.matchAll(/\bonclick\s*=\s*(["'])(.*?)\1/gi)) {
  for (const call of m[2].matchAll(/(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(/g)) {
    if (!nativeCallNames.has(call[1])) inlineCalls.add(call[1]);
  }
}
const unresolvedInlineCalls = [...inlineCalls].filter(name => !declaredFunctions.has(name));
assert.deepEqual(unresolvedInlineCalls, [], `static inline button handlers must resolve to functions: ${unresolvedInlineCalls.join(', ')}`);




// All application component styles must be available before <body> is rendered,
// so old skins cannot flash and then be replaced by the new palette.
const bodyMarkupIndex = html.indexOf('<body class=');
assert.ok(bodyMarkupIndex > 0, 'body markup exists');
for (const id of ['vila-v33-neon-dashboard','vila-v36-dashboard','vila-model-picker-foundation','vila-power-voice-css','vila-v68-cohesive-ui','vila-v68-final-polish']) {
  assert.ok(html.indexOf(`id="${id}"`) < bodyMarkupIndex, `${id} is loaded in head before body paint`);
}
assert.doesNotMatch(html, /<canvas id="bgCanvas"|Canvas Interactive Particle Background Engine|const particleCount = window\.innerWidth/,
  'old animated neon particle system and canvas are removed');
assert.match(html, /vila-provider-status-badge/);
const stateFn = html.match(/function updateUIState\(\)\s*\{([\s\S]*?)\n        \}/);
assert.ok(stateFn, 'provider status update function exists');
assert.doesNotMatch(stateFn[1], /text-cyan|text-violet|text-emerald|#22d3ee|#34d399|bg-cyan|bg-violet/,
  'provider badge runtime updates use the neutral V68 status classes');

assert.equal(pkg.version, '70.0.0');
assert.match(gradle, /versionCode 83/);
assert.match(gradle, /versionName "70\.0\.0"/);

// Saved theme is applied before any remote CSS/JS can paint the legacy palette.
const bootstrap = html.match(/<script id="vila-v68-theme-bootstrap">([\s\S]*?)<\/script>/);
assert.ok(bootstrap, 'early theme bootstrap exists');
assert.ok(html.indexOf('id="vila-v68-theme-bootstrap"') < html.indexOf('cdn.tailwindcss.com'), 'theme bootstrap runs before remote CSS/JS');
function simulateBootstrap(saved, lightLegacy) {
  const attrs = {}; const classes = new Set(['dark']); const storage = new Map();
  if (saved != null) storage.set('vila_theme', saved);
  if (lightLegacy != null) storage.set('vila_theme_light', lightLegacy);
  const rootElement = {
    style: {},
    setAttribute(k, v) { attrs[k] = v; },
    classList: { toggle(k, yes) { if (yes) classes.add(k); else classes.delete(k); } }
  };
  vm.runInNewContext(bootstrap[1], {
    document: { documentElement: rootElement },
    localStorage: { getItem(k) { return storage.has(k) ? storage.get(k) : null; } }
  });
  return { attrs, classes, scheme: rootElement.style.colorScheme };
}
assert.deepEqual(simulateBootstrap('light', null), { attrs: { 'data-theme': 'light' }, classes: new Set(['vila-theme-light']), scheme: 'light' });
assert.deepEqual(simulateBootstrap('dark', null), { attrs: { 'data-theme': 'dark' }, classes: new Set(['dark']), scheme: 'dark' });
assert.equal(simulateBootstrap(null, '1').attrs['data-theme'], 'light', 'legacy light preference migrates once at startup');

// Remove the animated legacy splash and its visual effects, which caused theme flash.
assert.doesNotMatch(html, /id="vilaWelcomeSplash"/);
assert.doesNotMatch(html, /id="vila-v33-hero-inject"|id="vilaV33Hero"|class="vila-v33-hero"|class="vila-v34-robot"|\.vila-v33-hero|\.vila-v34-robot|\.vila-hero-brand/, 'legacy blue robot hero and its obsolete CSS are removed rather than recolored');
assert.match(html, /<div class="ds-welcome"><h2>Mình có thể giúp gì cho bạn\?<\/h2>/, 'single source welcome content remains in static markup');
assert.match(html, /html body \.vila-explore-dialog\{background:var\(--v66-panel\)!important/, 'Explore surfaces use the same neutral design tokens');
assert.match(html, /html body #inputToolsMenu\.ds-plus\{background:var\(--v66-panel\)!important/, 'plus-menu panel is neutral before and after legacy styles');
assert.match(html, /html body #mainMenuBtn\{background:var\(--v66-panel\)!important/, 'main menu trigger is neutral from first paint');
assert.doesNotMatch(html, /@keyframes\s+vilaWelcome(?:Rise|Glow|Sweep|Orbit)|@keyframes\s+vilaTitleShine/);
assert.doesNotMatch(html, /id="vila-v31-welcome-leaderboard"/);
assert.match(html, /id="vila-v68-critical-palette"/);
assert.match(html, /html body \.animate-pulse,html body \.animate-ping,html body \.animate-bounce[\s\S]*?animation:none!important/, 'reduce only flashing pulse animations rather than disabling all motion');
assert.doesNotMatch(html, /html \*,html \*::before,html \*::after\{animation:none!important;transition:none!important/, 'do not globally disable all transitions and UI motion');
assert.doesNotMatch(html, /html \*\{box-shadow:none!important/, 'preserve intentional subtle component depth instead of flattening all surfaces');
assert.match(html, /id="vila-v68-final-polish"/, 'final component overrides unify legacy button colors and mobile model picker');
assert.doesNotMatch(html, /id="vilaInfoRail"|id="vilaToolReasoning"|id="vilaToolSearch"|id="vilaToolCode"|id="vilaToolImage"|id="vilaToolVideo"|id="vilaToolAttach"/, 'hidden duplicate provider rail and header toolbar are removed from the DOM');
assert.match(html, /closeVilaExplore\(\);openCodingLab\(\)/, 'Explore programming tile calls the real coding action');
assert.match(html, /closeVilaExplore\(\);enableVilaWebSearch\(\);focusChat\(\)/, 'Explore web-search tile enables real search mode');
assert.match(html, /closeVilaExplore\(\);document\.getElementById\('generateImageBtn'\)\?\.click\(\)/, 'Explore image tile calls the actual composer image action');
assert.match(html, /closeVilaExplore\(\);document\.getElementById\('makeVideoBtn'\)\?\.click\(\)/, 'Explore video tile calls the actual composer video action');
assert.doesNotMatch(html, /getElementById\('vilaTool(?:Code|Search|Image|Video|Attach)'\)/, 'Explore has no stale references to removed header buttons');
assert.match(html, /html body header\.ds-header \.ds-model-copy\{display:flex!important/);
assert.match(html, /html body #chatForm #sendBtn\{background:var\(--v66-text\)!important/);
assert.match(html, /html\.vila-simple body header\.ds-header \.ds-model\{background:transparent!important;background-image:none!important/,
  'header model chip must defeat older higher-specificity gradient skin');
assert.match(html, /html\.vila-simple body \.ds-dock\.vila-input-dock\{background:var\(--v66-bg\)!important;background-image:none!important/,
  'composer dock must defeat the legacy simple-UI gradient');
assert.match(html, /id="vila-v68-cohesive-ui"/);
assert.doesNotMatch(html, /id="vila-v66-clean-ui"/);
assert.doesNotMatch(html, /id="vila-v37-cyan-ui-fix"|id="vila-v32-android-image-thinking-polish"/, 'legacy blue skins in the document head are removed');
assert.match(html, /id="vila-v68-settings-layout"[\s\S]*?Mobile sizing only/);
assert.match(html, /id="vila-v68-startup-and-content-layout"[\s\S]*?Structural styles only/);
assert.doesNotMatch(html, /toggleLayoutBtn|vilaCommandPanel|vilaCommandInput|openVilaCommand|vila-command-panel/, 'dead controls without markup are removed from the UI source');
assert.match(html, /--v66-bg:#171717/);
assert.match(html, /--v66-accent:#10a37f/);
assert.match(html, /html\[data-theme="light"\]/);
assert.match(html, /html body \[class\*="bg-cyan-"\]/, 'legacy neon background classes are normalized');
assert.match(html, /html body \[class\*="text-violet-"\]/, 'legacy neon text classes are normalized');
assert.match(html, /html body \[class\*="border-cyan-"\]/, 'legacy neon borders are normalized');

// Parse the actual cohesive CSS (not CSS snippets stored inside template strings).
const style = html.match(/<style id="vila-v68-cohesive-ui">([\s\S]*?)<\/style>/);
assert.ok(style);
postcss.parse(style[1], { from: 'vila-v68-cohesive-ui.css' });
assert.match(style[1], /\.ds-model-copy\{display:flex!important/);
assert.match(style[1], /\.ds-model-copy>small\{display:none!important/);
assert.match(style[1], /\.vila-model-search\{display:flex/);
assert.match(style[1], /\.vila-model-capability-filters\{display:flex/);
assert.match(style[1], /\.vila-model-sort-bar\{display:grid/);
assert.match(html, /class="vila-model-search"/);
assert.match(html, /class="vila-model-capability-filters"/);
assert.match(html, /id="vilaModelPickerList"/);

// The duplicate floating rails are removed, but real Stop and Voice Studio actions remain usable.
assert.doesNotMatch(html, /id="vila-sidebar-theme-v641"|id="vila-sidebar-theme-css"|id="vilaSideFab"|id="vilaSideRail"/, 'legacy floating navigation UI is removed, not merely hidden');
assert.doesNotMatch(html, /window\.vilaChatTabs = function|window\.vilaNewChatTab = function/, 'only one persistent chat history implementation remains');
assert.doesNotMatch(style[1], /#vilaSideFab,#vilaSideRail,#vilaStopGenBtn\{display:none!important\}/);
assert.doesNotMatch(html, /id="vila-stop-stream-ui"|id="vilaStopGenBtn"/, 'the duplicate floating Stop control is removed');
assert.match(html, /getElementById\('sendBtn'\)\?\.addEventListener\('click',e=>\{if\(isProcessing\)[\s\S]*?stopVilaGeneration\(\)/, 'the composer send button becomes the one Stop control while processing');
assert.match(html, /function stopVilaGeneration\(\)[\s\S]*?controller\.abort\(\)/, 'Stop aborts active request controllers');
assert.doesNotMatch(html, /class="ds-side-ranking"/, 'duplicate provider ranking panel is removed from the menu');
assert.doesNotMatch(html, /id="vilaInfoRail"/, 'legacy provider rail is removed from the layout on every viewport');
assert.match(style[1], /#vilaVoiceStudioBtn\{position:static!important/);
assert.match(html, /span>Voice Studio<\/span>/);

// Google labels remain explicit and both UI and SVG-based theme toggle are handled.
assert.match(html, /Đăng nhập bằng Google/);
assert.doesNotMatch(html, /Tiếp tục với Google/);
assert.match(extras, /btn\.querySelector\('i, svg'\)/);
assert.match(extras, /window\.vilaSetSvgIcon\(icon, glyph\)/);
assert.match(extras, /mode\(\) === 'light' \? 'dark' : 'light'/);
new vm.Script(extras, { filename: 'vila-extras.js' });
console.log('PASS V68 UI stability: early theme boot, pre-body CSS cascade, neutral provider badge, no neon particle engine, unique static IDs, resolved button handlers, functional Explore actions, real Model Hub selectors, and preserved Stop/Voice Studio actions');
