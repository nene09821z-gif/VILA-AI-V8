'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const postcss = require('postcss');
const root = path.join(__dirname, '..');
const read = rel => fs.readFileSync(path.join(root, rel), 'utf8');
const pkg = JSON.parse(read('package.json'));
const gateway = JSON.parse(read('server/package.json'));
const gradle = read('app/build.gradle');
const html = read('app/src/main/assets/index.html');
const extras = read('app/src/main/assets/vila-extras.js');
assert.equal(pkg.version, '70.0.0');
assert.equal(gateway.version, pkg.version);
assert.match(gradle, /versionCode\s+83/);
assert.match(gradle, /versionName\s+"70\.0\.0"/);
assert.match(read('server/src/server.js'), /const APP_VERSION = '70\.0\.0'/);
assert.match(html, /const current='70\.0\.0'/, 'in-app update checker matches release version');
assert.match(read('.github/workflows/main.yml'), /VILA-AI-70\.0\.0-debug\.apk/);
assert.match(read('.github/workflows/main.yml'), /VILA-AI-70\.0\.0-release\.aab/);
// Parse every stylesheet in the real app shell, excluding JS template strings.
const cssMarkup = html.replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, m => ' '.repeat(m.length));
let cssCount = 0;
for (const m of cssMarkup.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) postcss.parse(m[1], { from: `V70-style-${++cssCount}` });
assert.ok(cssCount >= 30, `expected existing component styles to parse, got ${cssCount}`);
// Core mobile composer controls must remain reachable and named for assistive technology.
for (const id of ['chatMessages','chatForm','userPrompt','sendBtn','vilaModelPickerTrigger','themeToggleBtn','liveFrame','previewPanel']) {
  assert.match(html, new RegExp(`id=["']${id}["']`), `missing core UI element #${id}`);
}
assert.match(html, /sandbox="allow-scripts allow-modals allow-forms"/, 'preview iframe stays isolated from parent origin');
assert.match(html, /prefers-reduced-motion:reduce/, 'reduced-motion preferences are respected');
assert.match(html, /#chatForm #userPrompt\{font-size:16px!important/, 'mobile text input remains readable and avoids tiny text');
assert.match(html, /button:focus-visible[\s\S]*?outline:2px solid var\(--v66-accent\)!important/, 'keyboard focus is visible');
assert.match(html, /min-height:32px!important;padding:6px 7px!important/, 'code actions keep practical touch targets on narrow screens');
// Legacy fallback must not simulate a sequence of reasoning stages with a timer.
assert.match(extras, /Honest fallback status: show elapsed time only/);
assert.match(extras, /Đang chờ phản hồi AI/);
assert.doesNotMatch(extras, /const STEPS\s*=|if\s*\(s\s*>\s*0\s*&&\s*s\s*%\s*2/);
assert.doesNotMatch(extras, /Đọc yêu cầu và ngữ cảnh phù hợp|Chọn hướng ổn nhất/);
// Buttons that toggle theme expose their action to screen readers.
assert.match(html, /id="themeToggleBtn"[^>]*aria-label=/);
console.log(`PASS V70 quality gates: version sync, ${cssCount} stylesheet parse, mobile core elements, isolated preview, reduced motion, honest reasoning status`);
