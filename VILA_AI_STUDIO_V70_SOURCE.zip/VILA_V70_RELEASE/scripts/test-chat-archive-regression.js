'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const corePath = path.join(root, 'app/src/main/assets/vila-chat-history-core.js');
const uiPath = path.join(root, 'app/src/main/assets/vila-chat-history-ui.js');
const htmlPath = path.join(root, 'app/src/main/assets/index.html');
const Core = require(corePath);
class MemoryStorage {
  constructor() { this.values = new Map(); }
  getItem(k) { return this.values.has(k) ? this.values.get(k) : null; }
  setItem(k, v) { this.values.set(String(k), String(v)); }
  removeItem(k) { this.values.delete(k); }
}
let clock = 1000; let id = 0;
const storage = new MemoryStorage();
const store = Core.createStore(storage, { now: () => ++clock, randomId: () => `r${++id}` });

const a = store.create('Thử nghiệm A', [{ role: 'system', content: 'không được lưu' }, { role: 'user', content: 'Xin chào' }]);
assert.ok(a && store.getActiveId() === a.id);
assert.equal(a.title, 'Thử nghiệm A');
assert.deepEqual(store.get(a.id).messages, [{ role: 'user', content: 'Xin chào' }], 'archive must drop system prompts');
assert.equal(store.saveActive([{ role: 'user', content: 'Dòng đầu' }, { role: 'assistant', content: 'Trả lời' }]), true);
assert.equal(store.get(a.id).title, 'Thử nghiệm A', 'an explicit title should be preserved');
assert.match(store.getLastError(), /^$/);
assert.equal(Core.normalizeMessages(Array.from({ length: 50 }, (_, i) => ({ role: 'user', content: String(i) }))).length, Core.MAX_MESSAGES);
assert.equal(store.rename(a.id, 'Tên riêng của người dùng'), true);
assert.equal(store.saveActive([{ role: 'user', content: 'Nội dung mới sau đổi tên' }]), true);
assert.equal(store.get(a.id).title, 'Tên riêng của người dùng', 'saving messages must not overwrite a manually renamed title');
assert.equal(store.rename(a.id, 'Thử nghiệm A'), true);
const b = store.create('Cuộc chat B', [{ role: 'assistant', content: 'B' }]);
assert.ok(b && store.getActiveId() === b.id);
assert.equal(store.setActiveId(a.id), true);
assert.equal(store.getActiveId(), a.id, 'switching stores active chat ID');
assert.equal(store.rename(a.id, '  Tên mới\n hợp lệ  '), true);
assert.equal(store.get(a.id).title, 'Tên mới hợp lệ');
assert.equal(store.remove(a.id).removed, true);
assert.equal(store.getActiveId(), b.id, 'deleting active chat selects a remaining chat');
assert.throws(() => store.importBackup({ chats: 'wrong' }), /không đúng định dạng/);
const imported = store.importBackup({ schema: 'vila-chat-archive', version: 1, chats: [{ title: 'Imported', createdAt: 1, messages: [{ role: 'user', content: 'hello' }, { role: 'system', content: 'secret prompt' }] }] });
assert.equal(imported.imported, 1);
assert.ok(store.list().some(c => c.title === 'Imported'));
assert.equal(imported.kept, 1, 'import reports the number actually retained after the 12-chat cap');
assert.ok(store.list().find(c => c.title === 'Imported').messages.every(m => m.role === 'user' || m.role === 'assistant'));
assert.equal(Core.normalizeMessages([{ role: 'user', content: 'x'.repeat(9000) }])[0].content.length, Core.MAX_MESSAGE_CHARS);
assert.equal(Core.cleanTitle('x'.repeat(500)).length, Core.MAX_TITLE_CHARS);
const backup = store.exportBackup();
assert.equal(backup.schema, 'vila-chat-archive');
assert.ok(backup.chats.length <= Core.MAX_CHATS);
// First-start migration should import the legacy conversation once.
const migrationStorage = new MemoryStorage();
const migrationStore = Core.createStore(migrationStorage, { now: () => ++clock, randomId: () => `m${++id}` });
const migrated = migrationStore.bootstrap([{ role: 'user', content: 'Lịch sử V66 cũ' }]);
assert.equal(migrated.messages[0].content, 'Lịch sử V66 cũ');
// After a user creates an empty chat, stale V66 global memory must not be copied into it on restart.
const emptyChat = migrationStore.create('Chat rỗng', []);
assert.equal(migrationStore.getActiveId(), emptyChat.id);
const restoredEmpty = migrationStore.bootstrap([{ role: 'user', content: 'Tin nhắn cũ không được chép lại' }]);
assert.equal(restoredEmpty.id, emptyChat.id);
assert.equal(restoredEmpty.messages.length, 0, 'an existing empty chat remains empty when app restarts');
// A stale active ID should recover to the newest valid archived conversation.
migrationStorage.setItem(Core.ACTIVE_KEY, 'missing-id');
assert.equal(migrationStore.bootstrap([{ role: 'user', content: 'stale' }]).id, emptyChat.id);
assert.equal(migrationStore.getActiveId(), emptyChat.id);

const src = fs.readFileSync(uiPath, 'utf8');
new vm.Script(src, { filename: 'vila-chat-history-ui.js' });
const html = fs.readFileSync(htmlPath, 'utf8');
assert.match(html, /vila-chat-history-core\.js/);
assert.match(html, /vila-chat-history-ui\.js/);
assert.match(src, /textContent/);
assert.match(src, /addEventListener\('click'/);
assert.match(src, /store\.saveActive\(messages\)/, 'UI saves content without overwriting a manually renamed title');
assert.doesNotMatch(src, /store\.saveActive\(messages,\s*firstUser/);
console.log('PASS V68 chat archive: migration-once, empty-chat restore, stale active recovery, rename/delete, validated backup import/export, bounded storage, and UI syntax');
