const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const a = f => path.join(root, 'app/src/main/assets', f);
const html = fs.readFileSync(a('index.html'), 'utf8');
const css = fs.readFileSync(a('vila-simple.css'), 'utf8');
const js = fs.readFileSync(a('vila-simple.js'), 'utf8');
assert.ok(html.includes('href="vila-simple.css"') && html.includes('src="vila-simple.js"'), 'simple UI assets must be linked');
const actualBodyIndex = html.indexOf('<body class=');
assert.ok(html.indexOf('id="vila-v60-360dpi-preview-429"') > html.indexOf('vila-simple.css') && html.indexOf('id="vila-v60-360dpi-preview-429"') < actualBodyIndex, 'V60 mobile override must follow simple CSS and load before body paint; behavior JS stays after markup');
assert.ok(html.includes("classList.add('vila-simple')") && !html.includes("getItem('vila_ui_simple')"), 'simple class always applied before first paint');
const cleanCss = css.replace(/\/\*[\s\S]*?\*\//g, '');
const cssStack = [];
let selectorBuffer = '';
for (const ch of cleanCss) {
  if (ch === '{') {
    const selector = selectorBuffer.trim();
    selectorBuffer = '';
    if (!selector) continue;
    if (selector.startsWith('@')) {
      cssStack.push({ type: 'at-rule', name: selector.toLowerCase() });
      continue;
    }
    const insideKeyframes = cssStack.some(entry => /@(?:-webkit-)?keyframes\b/.test(entry.name || ''));
    if (!insideKeyframes) {
      for (const part of selector.split(',').map(item => item.trim()).filter(Boolean)) {
        if (part.startsWith('html.vila-simple') || part.startsWith('#vilaKnowledge')) continue;
        assert.fail('CSS selector not scoped to html.vila-simple or #vilaKnowledge: ' + part);
      }
    }
    cssStack.push({ type: 'rule', name: selector });
  } else if (ch === '}') {
    selectorBuffer = '';
    cssStack.pop();
  } else {
    selectorBuffer += ch;
  }
}
assert.equal(cssStack.length, 0, 'CSS braces must be balanced');
assert.ok(js.includes('function isSimple() { return true; }') && js.includes('openVilaKnowledge') && !js.includes('vilaSimpleToggleBtn'), 'simple is the only UI; knowledge dialog exists');
assert.ok(js.includes("aria-modal") && js.includes('aria-label'), 'dialog is accessible');
assert.ok(!/innerHTML\s*=\s*[^;]*\+\s*(text|e\.message)\b/.test(js) || js.includes('function esc'), 'dynamic text must be escaped');
assert.ok(html.includes('window.vilaAuthedGatewayFetch=authedGatewayFetch'), 'gateway fetch helper exposed to the knowledge dialog');
assert.ok(!/githubToken|GithubToken|github_pat_/.test(html + js), 'no GitHub token UI');
assert.ok(js.includes('vila-img-failed') && css.includes('img.vila-img-failed'), 'broken images must get the neat placeholder');
assert.ok(css.includes('html.vila-simple body{margin:0}') && css.includes('.min-w-0'), 'layout and images must not depend on the Tailwind CDN');
assert.ok(/Cache-Control: public, max-age=86400/.test(fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8')), 'local server must cache images');
console.log('PASS: V54 simple UI, scoped CSS, knowledge dialog, GitHub token removal');
