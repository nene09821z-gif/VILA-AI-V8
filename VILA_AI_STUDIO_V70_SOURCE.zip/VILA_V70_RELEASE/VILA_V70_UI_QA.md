# VILA AI Studio V70 — UI QA checklist

## Source checks completed
- All CSS blocks in the main HTML parse with PostCSS as part of `npm test`.
- The theme bootstrap remains in `<head>` and the saved light/dark choice is applied before the UI is rendered.
- Core chat, composer, model selector, theme toggle, Preview panel and iframe elements are present.
- The Preview iframe remains sandboxed without `allow-same-origin`.
- The text input has a 16px font, bounded mobile height and visible focus treatment; reduced-motion preferences are respected.
- Static IDs, literal DOM references and inline action targets are covered by existing regression tests.

## Manual device QA — not yet completed
1. Install the debug APK built by GitHub Actions on the target OPPO/Android device.
2. Test first launch in Dark and Light; close/reopen and confirm the chosen theme persists without a visible color flash.
3. Open an empty chat, type a draft, clear it, send a message, stop generation, and trigger a provider error. Confirm the welcome never overlaps content and status reflects the actual state.
4. Open Model Hub at 360px and 393px widths; search, filter, select, favorite and close. Confirm all controls are reachable and selected model text is visible.
5. Request an HTML page, tap its **Xem trước** button, inspect the rendered iframe and intentionally test a JavaScript error. Confirm the app reports runtime errors and does not claim a failed render succeeded.
6. Open the main menu, Voice Studio, file picker, chat history, settings and sign-in. Check the composer is not covered by floating controls or the system navigation bar.
7. Repeat with keyboard open and with Android font/display scaling increased.

## Acceptance
Do not mark visual QA passed until screenshots or screen recordings from a real browser/device are reviewed. Source/CSS tests do not prove rendered pixels or provider behavior.
