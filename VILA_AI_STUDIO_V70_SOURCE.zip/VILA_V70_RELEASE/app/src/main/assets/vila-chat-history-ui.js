/* VILA V68 accessible chat history, switching, rename/delete, and validated backup import/export. */
(function () {
  'use strict';
  const Core = window.VilaChatArchiveCore;
  if (!Core || !window.localStorage) return;
  const store = Core.createStore(window.localStorage);
  const memoryKey = 'vila_conversation_memory_v7';
  let modal, listNode, searchNode, importNode;

  function notify(message, type) {
    if (typeof window.showToast === 'function') window.showToast(message, type || 'info');
    else console.info('[VILA history]', message);
  }
  function getCurrentMessages() {
    try {
      return (typeof conversationHistory !== 'undefined' && Array.isArray(conversationHistory) ? conversationHistory : [])
        .filter(m => m && (m.role === 'user' || m.role === 'assistant'))
        .map(m => {
          let content = m.content;
          if (Array.isArray(content) && typeof window.contentToDisplayText === 'function') content = window.contentToDisplayText(content);
          else if (typeof content !== 'string') content = String(content == null ? '' : content);
          // History backup contains text only: never persist image/base64 payloads a second time.
          content = String(content).replace(/data:image\/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=\r\n]+/g, '[Ảnh đính kèm đã không được đưa vào bản sao lưu]').slice(0, Core.MAX_MESSAGE_CHARS);
          return { role: m.role, content };
        });
    } catch (_) { return []; }
  }
  function persistCurrent() {
    const messages = getCurrentMessages();
    if (!store.getActiveId()) {
      const created = store.create('Cuộc trò chuyện mới', messages);
      if (!created) return false;
    }
    // Let the store auto-title only generic chats. Passing a title on every save
    // would overwrite a title the user explicitly renamed.
    const ok = store.saveActive(messages);
    if (!ok) notify(store.getLastError() || 'Không lưu được lịch sử.', 'error');
    return ok;
  }
  function setConversation(messages) {
    try {
      setupSystemPrompt();
      const clean = Core.normalizeMessages(messages);
      conversationHistory.push(...clean);
      localStorage.setItem(memoryKey, JSON.stringify({ version: 17, savedAt: Date.now(), messages: clean }));
      if (typeof renderConversationMessages === 'function') {
        if (clean.length) renderConversationMessages(clean);
        else if (typeof renderWelcomeState === 'function') renderWelcomeState();
      }
      if (typeof syncSendButtonState === 'function') syncSendButtonState();
      if (typeof updateVilaChatArchiveButton === 'function') updateVilaChatArchiveButton();
    } catch (error) {
      notify('Không mở được cuộc trò chuyện: ' + String(error && error.message || error), 'error');
    }
  }
  function activateChat(id) {
    persistCurrent();
    const chat = store.get(id);
    if (!chat || !store.setActiveId(id)) { notify('Không tìm thấy cuộc trò chuyện cần mở.', 'error'); return; }
    setConversation(chat.messages);
    closeHistory();
    renderList();
    notify('Đã mở: ' + chat.title, 'success');
  }
  function createChat() {
    persistCurrent();
    const chat = store.create('Cuộc trò chuyện mới', []);
    if (!chat) { notify(store.getLastError() || 'Không tạo được cuộc trò chuyện mới.', 'error'); return; }
    setConversation([]);
    if (typeof pendingAttachments !== 'undefined') {
      try { pendingAttachments = []; if (typeof renderAttachmentTray === 'function') renderAttachmentTray(); } catch (_) {}
    }
    closeHistory();
    renderList();
    if (typeof focusChat === 'function') focusChat();
    notify('Đã tạo cuộc trò chuyện mới.', 'success');
  }
  function makeButton(label, css, handler, aria) {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.className = css; b.setAttribute('aria-label', aria || label); b.addEventListener('click', handler); return b;
  }
  function buildModal() {
    modal = document.createElement('div'); modal.id = 'vilaV67HistoryModal'; modal.className = 'vila-v67-history-overlay';
    modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true'); modal.setAttribute('aria-labelledby', 'vilaV67HistoryTitle');
    const sheet = document.createElement('section'); sheet.className = 'vila-v67-history-sheet';
    const head = document.createElement('header'); head.className = 'vila-v67-history-head';
    const titleBox = document.createElement('div');
    const eyebrow = document.createElement('p'); eyebrow.className = 'vila-v67-history-eyebrow'; eyebrow.textContent = 'VILA AI STUDIO';
    const title = document.createElement('h2'); title.id = 'vilaV67HistoryTitle'; title.textContent = 'Lịch sử trò chuyện';
    const subtitle = document.createElement('p'); subtitle.className = 'vila-v67-history-subtitle'; subtitle.textContent = 'Lưu trên thiết bị này. Nội dung tệp/ảnh đính kèm không nằm trong bản sao lưu.';
    titleBox.append(eyebrow, title, subtitle);
    head.append(titleBox, makeButton('Đóng', 'vila-v67-history-button vila-v67-history-close', closeHistory, 'Đóng lịch sử trò chuyện'));
    const actions = document.createElement('div'); actions.className = 'vila-v67-history-actions';
    actions.append(
      makeButton('+ Chat mới', 'vila-v67-history-button primary', createChat),
      makeButton('Xuất sao lưu', 'vila-v67-history-button', exportBackup),
      makeButton('Nhập sao lưu', 'vila-v67-history-button', () => importNode.click())
    );
    searchNode = document.createElement('input'); searchNode.type = 'search'; searchNode.className = 'vila-v67-history-search'; searchNode.placeholder = 'Tìm trong tên cuộc trò chuyện…'; searchNode.setAttribute('aria-label', 'Tìm cuộc trò chuyện'); searchNode.maxLength = 100; searchNode.addEventListener('input', renderList);
    listNode = document.createElement('div'); listNode.className = 'vila-v67-history-list'; listNode.setAttribute('role', 'list');
    importNode = document.createElement('input'); importNode.type = 'file'; importNode.accept = 'application/json,.json'; importNode.hidden = true; importNode.addEventListener('change', importBackupFile);
    const foot = document.createElement('p'); foot.className = 'vila-v67-history-foot'; foot.textContent = 'Tối đa 12 cuộc trò chuyện · Chỉ lưu nội dung văn bản · Có thể đổi tên hoặc xóa từng cuộc trò chuyện.';
    sheet.append(head, actions, searchNode, listNode, importNode, foot); modal.appendChild(sheet);
    modal.addEventListener('click', e => { if (e.target === modal) closeHistory(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) closeHistory(); });
    document.body.appendChild(modal);
  }
  function openHistory() { persistCurrent(); if (!modal) buildModal(); renderList(); modal.classList.add('open'); setTimeout(() => searchNode && searchNode.focus(), 40); }
  function closeHistory() { if (modal) modal.classList.remove('open'); }
  function renderList() {
    if (!listNode) return;
    const q = String(searchNode && searchNode.value || '').trim().toLocaleLowerCase('vi');
    const activeId = store.getActiveId();
    const chats = store.list().filter(c => !q || c.title.toLocaleLowerCase('vi').includes(q));
    listNode.replaceChildren();
    if (!chats.length) {
      const empty = document.createElement('p'); empty.className = 'vila-v67-history-empty'; empty.textContent = q ? 'Không tìm thấy cuộc trò chuyện phù hợp.' : 'Chưa có lịch sử. Hãy tạo một cuộc trò chuyện mới.'; listNode.appendChild(empty); return;
    }
    chats.forEach(chat => {
      const row = document.createElement('article'); row.className = 'vila-v67-history-item' + (chat.id === activeId ? ' is-active' : ''); row.setAttribute('role', 'listitem');
      const main = document.createElement('button'); main.type = 'button'; main.className = 'vila-v67-history-open'; main.addEventListener('click', () => activateChat(chat.id));
      const name = document.createElement('strong'); name.textContent = chat.title;
      const details = document.createElement('span'); details.textContent = `${chat.messages.length} tin nhắn · ${new Date(chat.updatedAt).toLocaleString('vi-VN')}`;
      const preview = document.createElement('span'); const last = chat.messages.slice().reverse().find(m => m.role === 'user' && m.content); preview.textContent = last ? last.content.slice(0, 115) : 'Chưa có tin nhắn'; preview.className = 'vila-v67-history-preview';
      main.append(name, details, preview);
      const itemActions = document.createElement('div'); itemActions.className = 'vila-v67-history-item-actions';
      itemActions.append(
        makeButton('Đổi tên', 'vila-v67-history-mini', () => renameChat(chat), 'Đổi tên ' + chat.title),
        makeButton('Xóa', 'vila-v67-history-mini danger', () => deleteChat(chat), 'Xóa ' + chat.title)
      );
      row.append(main, itemActions); listNode.appendChild(row);
    });
  }
  function renameChat(chat) {
    const next = window.prompt('Tên cuộc trò chuyện mới:', chat.title);
    if (next == null) return;
    if (!String(next).trim()) { notify('Tên không được để trống.', 'error'); return; }
    if (!store.rename(chat.id, next)) notify(store.getLastError() || 'Không đổi được tên.', 'error');
    else { renderList(); notify('Đã đổi tên cuộc trò chuyện.', 'success'); }
  }
  function deleteChat(chat) {
    if (!window.confirm('Xóa cuộc trò chuyện “' + chat.title + '” khỏi thiết bị này?')) return;
    const active = store.getActiveId() === chat.id;
    const result = store.remove(chat.id);
    if (!result.removed) { notify(store.getLastError() || 'Không xóa được cuộc trò chuyện.', 'error'); return; }
    if (active) {
      const next = result.activeId && store.get(result.activeId);
      if (next) setConversation(next.messages);
      else {
        const fresh = store.create('Cuộc trò chuyện mới', []);
        if (fresh) setConversation([]);
        else notify(store.getLastError() || 'Không tạo được cuộc trò chuyện trống.', 'error');
      }
    }
    renderList(); notify('Đã xóa cuộc trò chuyện.', 'success');
  }
  function exportBackup() {
    persistCurrent();
    if (!window.confirm('Tệp sao lưu chứa nội dung tin nhắn của bạn. Chỉ lưu ở nơi đáng tin cậy. Tiếp tục xuất?')) return;
    const blob = new Blob([JSON.stringify(store.exportBackup(), null, 2)], { type: 'application/json;charset=utf-8' });
    const filename = 'VILA_chat_backup_' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
    if (window.Android && typeof window.Android.saveTextFile === 'function') {
      try {
        const saved = window.Android.saveTextFile(filename, JSON.stringify(store.exportBackup(), null, 2), 'application/json');
        if (saved === true) notify('Đã lưu tệp sao lưu vào Downloads.', 'success');
        else notify('Không xác nhận được việc lưu tệp sao lưu. Hãy kiểm tra Downloads rồi thử lại.', 'error');
        return;
      } catch (_) { notify('Không thể lưu bản sao lưu trên thiết bị.', 'error'); return; }
    }
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
    notify('Đã tạo yêu cầu tải tệp sao lưu. Hãy kiểm tra thư mục tải xuống của trình duyệt.', 'info');
  }
  async function importBackupFile() {
    const file = importNode.files && importNode.files[0]; if (!file) return;
    importNode.value = '';
    if (file.size > 5 * 1024 * 1024) { notify('Tệp sao lưu vượt quá 5 MB.', 'error'); return; }
    try {
      const data = JSON.parse(await file.text());
      if (!window.confirm('Nhập cuộc trò chuyện từ tệp sao lưu? Tối đa 12 cuộc trò chuyện mới nhất sẽ được giữ trên thiết bị.')) return;
      const result = store.importBackup(data);
      renderList(); notify(`Đã nhập ${result.kept} cuộc trò chuyện vào lịch sử.`, 'success');
    } catch (error) { notify(String(error && error.message || error), 'error'); }
  }
  function addMenuEntry() {
    const nav = document.querySelector('#mainMenu .ds-side-nav');
    if (!nav || nav.querySelector('[data-vila-nav="history"]')) return;
    const button = document.createElement('button'); button.type = 'button'; button.className = 'vila-menu-btn'; button.dataset.vilaNav = 'history';
    const icon = document.createElement('i'); icon.className = 'fa-solid fa-clock-rotate-left'; icon.setAttribute('aria-hidden', 'true');
    const label = document.createElement('span'); label.textContent = 'Lịch sử trò chuyện'; button.append(icon, label);
    button.addEventListener('click', () => { if (typeof closeMainMenu === 'function') closeMainMenu(); openHistory(); });
    const before = nav.querySelector('[data-vila-nav="settings"]'); nav.insertBefore(button, before || null);
  }
  function init() {
    const current = getCurrentMessages();
    // bootstrap imports the legacy V66 conversation only when the V67 archive is empty.
    // Existing empty chats must stay empty after restart rather than absorbing stale global memory.
    const startupChat = store.bootstrap(current);
    if (startupChat) setConversation(startupChat.messages);
    else setConversation(current);
    const originalSave = window.saveConversationMemory;
    if (typeof originalSave === 'function' && !window.__vilaV67SaveWrapped) {
      window.__vilaV67SaveWrapped = true;
      window.saveConversationMemory = function () { const r = originalSave.apply(this, arguments); persistCurrent(); return r; };
    }
    const newChatButton = document.getElementById('clearChatBtn');
    if (newChatButton && !newChatButton.dataset.vilaV67HistoryBound) {
      newChatButton.dataset.vilaV67HistoryBound = '1';
      newChatButton.addEventListener('click', event => { event.preventDefault(); event.stopImmediatePropagation(); createChat(); }, true);
    }
    window.vilaOpenChatHistory = openHistory;
    window.vilaStartNewPersistentChat = createChat;
    window.vilaPersistCurrentChat = persistCurrent;
    window.newVilaChat = createChat;
    addMenuEntry();
    window.addEventListener('pagehide', persistCurrent);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') persistCurrent(); });
    renderList();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true }); else init();
})();
