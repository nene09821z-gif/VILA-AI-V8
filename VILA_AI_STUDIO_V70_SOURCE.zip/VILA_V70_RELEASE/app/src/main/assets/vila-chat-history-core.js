/* VILA V68 chat archive core. Pure storage/validation functions, shared by browser and Node tests. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.VilaChatArchiveCore = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const STORAGE_KEY = 'vila_chat_archive_v1';
  const ACTIVE_KEY = 'vila_active_chat_v67';
  const MAX_CHATS = 12;
  const MAX_MESSAGES = 40;
  const MAX_MESSAGE_CHARS = 3000;
  const MAX_TITLE_CHARS = 72;

  function asString(value) { return typeof value === 'string' ? value : String(value == null ? '' : value); }
  function cleanTitle(value) {
    const title = asString(value).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, MAX_TITLE_CHARS);
    return title || 'Cuộc trò chuyện mới';
  }
  function normalizeMessages(messages) {
    if (!Array.isArray(messages)) return [];
    return messages.filter(m => m && (m.role === 'user' || m.role === 'assistant'))
      .slice(-MAX_MESSAGES).map(m => ({
        role: m.role,
        content: asString(m.content).replace(/\u0000/g, '').slice(0, MAX_MESSAGE_CHARS)
      }));
  }
  function validChatRecord(item) {
    return !!item && typeof item === 'object' && !Array.isArray(item) && Array.isArray(item.messages);
  }
  function createStore(storage, options) {
    const s = storage;
    const opts = options || {};
    const now = typeof opts.now === 'function' ? opts.now : Date.now;
    const randomId = typeof opts.randomId === 'function' ? opts.randomId : () => Math.random().toString(36).slice(2, 10);
    let lastError = '';

    function read() {
      try {
        const parsed = JSON.parse(s.getItem(STORAGE_KEY) || 'null');
        const chats = parsed && Array.isArray(parsed.chats) ? parsed.chats.filter(validChatRecord).map(c => ({
          id: asString(c.id).slice(0, 80) || ('chat-' + randomId()),
          title: cleanTitle(c.title),
          createdAt: Number(c.createdAt) || now(),
          updatedAt: Number(c.updatedAt) || Number(c.createdAt) || now(),
          messages: normalizeMessages(c.messages)
        })) : [];
        lastError = '';
        return { version: 1, chats: chats.slice(0, MAX_CHATS) };
      } catch (error) {
        lastError = 'Không đọc được kho lịch sử: ' + asString(error && error.message).slice(0, 120);
        return { version: 1, chats: [] };
      }
    }
    function write(state) {
      try {
        s.setItem(STORAGE_KEY, JSON.stringify({ version: 1, chats: state.chats.slice(0, MAX_CHATS) }));
        lastError = '';
        return true;
      } catch (error) {
        lastError = 'Không đủ dung lượng để lưu lịch sử. Hãy xóa bớt cuộc trò chuyện.';
        return false;
      }
    }
    function getActiveId() {
      try { return asString(s.getItem(ACTIVE_KEY)); } catch (_) { return ''; }
    }
    function setActiveId(id) {
      const state = read();
      const found = state.chats.some(c => c.id === id);
      if (!found) return false;
      try { s.setItem(ACTIVE_KEY, id); return true; } catch (_) { lastError = 'Không lưu được cuộc trò chuyện đang chọn.'; return false; }
    }
    function list() { return read().chats.slice().sort((a, b) => b.updatedAt - a.updatedAt); }
    function get(id) { return read().chats.find(c => c.id === id) || null; }
    function create(title, messages) {
      const state = read();
      const stamp = now();
      const normalized = normalizeMessages(messages || []);
      let normalizedTitle = cleanTitle(title);
      const firstUser = normalized.find(m => m.role === 'user' && m.content.trim());
      if (firstUser && (normalizedTitle === 'Cuộc trò chuyện mới' || /^Chat \d+$/.test(normalizedTitle))) {
        normalizedTitle = cleanTitle(firstUser.content.replace(/\s+/g, ' '));
      }
      const chat = { id: 'chat-' + stamp.toString(36) + '-' + randomId(), title: normalizedTitle, createdAt: stamp, updatedAt: stamp, messages: normalized };
      state.chats.unshift(chat);
      state.chats = state.chats.slice(0, MAX_CHATS);
      if (!write(state)) return null;
      try { s.setItem(ACTIVE_KEY, chat.id); } catch (_) { lastError = 'Đã tạo chat nhưng không lưu được lựa chọn hiện tại.'; }
      return chat;
    }
    function saveActive(messages, metadata) {
      const state = read();
      let id = getActiveId();
      let chat = state.chats.find(c => c.id === id);
      if (!chat) {
        const stamp = now();
        chat = { id: 'chat-' + stamp.toString(36) + '-' + randomId(), title: 'Cuộc trò chuyện mới', createdAt: stamp, updatedAt: stamp, messages: [] };
        state.chats.unshift(chat);
        id = chat.id;
        try { s.setItem(ACTIVE_KEY, id); } catch (_) {}
      }
      chat.messages = normalizeMessages(messages);
      chat.updatedAt = now();
      if (metadata && metadata.title) chat.title = cleanTitle(metadata.title);
      else {
        const firstUser = chat.messages.find(m => m.role === 'user' && m.content.trim());
        if (firstUser && (!chat.title || chat.title === 'Cuộc trò chuyện mới' || /^Chat \d+$/.test(chat.title))) {
          chat.title = cleanTitle(firstUser.content.replace(/\s+/g, ' '));
        }
      }
      return write(state);
    }
    function rename(id, title) {
      const state = read(); const chat = state.chats.find(c => c.id === id);
      if (!chat) return false;
      chat.title = cleanTitle(title); chat.updatedAt = now(); return write(state);
    }
    function remove(id) {
      const state = read(); const wasActive = getActiveId() === id;
      const before = state.chats.length; state.chats = state.chats.filter(c => c.id !== id);
      if (state.chats.length === before) return { removed: false, activeId: getActiveId() };
      if (!write(state)) return { removed: false, activeId: getActiveId() };
      if (wasActive) {
        if (state.chats[0]) { try { s.setItem(ACTIVE_KEY, state.chats[0].id); } catch (_) {} }
        else { try { s.removeItem(ACTIVE_KEY); } catch (_) {} }
      }
      return { removed: true, activeId: getActiveId() };
    }
    function importBackup(data) {
      if (!data || typeof data !== 'object' || Array.isArray(data) || !Array.isArray(data.chats)) throw new Error('Tệp sao lưu không đúng định dạng VILA.');
      if (data.chats.length > 100) throw new Error('Tệp sao lưu có quá nhiều cuộc trò chuyện (tối đa 100 khi nhập).');
      const state = read();
      const imported = data.chats.filter(validChatRecord).map(c => ({
        id: 'chat-' + now().toString(36) + '-' + randomId(), title: cleanTitle(c.title),
        createdAt: Number(c.createdAt) || now(), updatedAt: now(), messages: normalizeMessages(c.messages)
      }));
      if (!imported.length) throw new Error('Không tìm thấy cuộc trò chuyện hợp lệ trong tệp sao lưu.');
      state.chats = [...imported, ...state.chats].slice(0, MAX_CHATS);
      const importedIds = new Set(imported.map(c => c.id));
      const kept = state.chats.filter(c => importedIds.has(c.id)).length;
      if (!write(state)) throw new Error(lastError || 'Không lưu được tệp sao lưu.');
      if (!getActiveId() && state.chats[0]) { try { s.setItem(ACTIVE_KEY, state.chats[0].id); } catch (_) {} }
      return { imported: imported.length, kept };
    }
    function bootstrap(legacyMessages) {
      // Migrate V66's single global conversation only when no archive exists yet.
      // Never copy stale legacy memory into an intentionally empty V67 chat on restart.
      const existing = list();
      const activeId = getActiveId();
      let active = activeId ? get(activeId) : null;
      if (!active && existing.length) {
        active = existing[0];
        setActiveId(active.id);
      }
      if (active) return active;
      return create('Cuộc trò chuyện mới', normalizeMessages(legacyMessages || []));
    }
    function exportBackup() { return { schema: 'vila-chat-archive', version: 1, exportedAt: new Date(now()).toISOString(), chats: list() }; }
    return { list, get, getActiveId, setActiveId, create, saveActive, rename, remove, importBackup, exportBackup, bootstrap, getLastError: () => lastError, constants: { MAX_CHATS, MAX_MESSAGES, MAX_MESSAGE_CHARS, MAX_TITLE_CHARS } };
  }
  return { STORAGE_KEY, ACTIVE_KEY, MAX_CHATS, MAX_MESSAGES, MAX_MESSAGE_CHARS, MAX_TITLE_CHARS, cleanTitle, normalizeMessages, createStore };
});
