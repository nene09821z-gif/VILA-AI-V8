/* VILA extras: chế độ đen, giao diện suy luận tương thích, tạo video qua Gemini Omni Interactions. */
(function () {
  'use strict';
  // ---------- Theme: chỉ hai chế độ Sáng / Tối ----------
  const css = document.createElement('style');
  css.textContent = `
  .vila-think{margin:2px 0;color:#a1a1aa;font-size:12.5px}
  .vila-think summary{display:flex;align-items:center;gap:8px;cursor:pointer;list-style:none;user-select:none}
  .vila-think summary::-webkit-details-marker{display:none}
  .vila-think-dot{width:8px;height:8px;border-radius:50%;background:var(--v66-muted,#a3a3a3)}
  .vila-think.done .vila-think-dot{animation:none;background:#52525b}
  .vila-think-label{color:var(--v66-muted,#a3a3a3)}
  .vila-think.done .vila-think-label{animation:none;background:none;color:#a1a1aa}
  .vila-think-steps{margin:6px 0 0 4px;padding-left:14px;border-left:1px solid #3f3f46;list-style:none}
  .vila-think-steps li{padding:2px 0;opacity:.85}
  .vila-think-body{margin:6px 0 0;padding-left:14px;border-left:1px solid #3f3f46;white-space:pre-wrap;max-height:240px;overflow:auto}
`;
  document.head.appendChild(css);
  function syncThemeButton(mode) {
    const btn = document.getElementById('themeToggleBtn');
    const label = document.getElementById('themeText');
    const icon = btn && btn.querySelector('i, svg');
    if (label) label.textContent = mode === 'light' ? 'Sáng' : 'Tối';
    if (icon) {
      const glyph = mode === 'light' ? 'sun' : 'moon';
      if (icon.tagName && icon.tagName.toLowerCase() === 'svg' && typeof window.vilaSetSvgIcon === 'function') window.vilaSetSvgIcon(icon, glyph);
      else { icon.classList.remove('fa-moon', 'fa-sun'); icon.classList.add(mode === 'light' ? 'fa-sun' : 'fa-moon'); }
    }
    if (btn) btn.setAttribute('aria-label', mode === 'light' ? 'Đang dùng giao diện sáng; bấm để chuyển sang tối' : 'Đang dùng giao diện tối; bấm để chuyển sang sáng');
  }
  function applyTheme(t) {
    const mode = String(t).toLowerCase() === 'light' ? 'light' : 'dark';
    const root = document.documentElement;
    root.setAttribute('data-theme', mode);
    root.classList.toggle('vila-theme-light', mode === 'light');
    root.classList.toggle('dark', mode === 'dark');
    try { localStorage.setItem('vila_theme', mode); localStorage.setItem('vila_theme_light', mode === 'light' ? '1' : '0'); } catch (_) {}
    syncThemeButton(mode);
    return mode;
  }
  window.vilaSetTheme = applyTheme;
  const initialTheme = (function () { try { const saved=localStorage.getItem('vila_theme'); if(saved==='light'||saved==='dark') return saved; return localStorage.getItem('vila_theme_light')==='1'?'light':'dark'; } catch (_) { return 'dark'; } })();
  applyTheme(initialTheme);

  if (typeof window.updateVilaThinkingPanel !== 'function') {
    // ---------- Trạng thái suy nghĩ: fallback cho bản HTML cũ ----------
    // Honest fallback status: show elapsed time only; never fabricate staged reasoning events.
    window.appendTypingIndicator = function () {
      const box = document.getElementById('chatMessages'); if (!box) return '';
      const id = 'typing_' + Date.now(), t0 = Date.now(); window.__vilaThinkStart = t0;
      const d = document.createElement('div'); d.id = id; d.className = 'vila-thinking-compact';
      d.setAttribute('role', 'status'); d.setAttribute('aria-live', 'polite');
      d.innerHTML = '<span class="vila-think-dot" aria-hidden="true"></span><span class="vila-think-label">Đang chờ phản hồi AI…</span><span class="vila-think-time">0 giây</span>';
      box.appendChild(d); if (window.scrollToBottom) window.scrollToBottom();
      const tm = d.querySelector('.vila-think-time');
      const timer = setInterval(function () {
        if (!document.getElementById(id)) return clearInterval(timer);
        if (tm) tm.textContent = Math.floor((Date.now() - t0) / 1000) + ' giây';
      }, 1000);
      d.dataset.timerId = String(timer);
      return id;
    };
    window.vilaShowThought = function () {
      const box = document.getElementById('chatMessages'); if (!box) return;
      const secs = Math.max(0, Math.round((Date.now() - (window.__vilaThinkStart || Date.now())) / 1000));
      const el = document.createElement('div'); el.className = 'vila-think done';
      el.setAttribute('role', 'status');
      const label = document.createElement('span'); label.className = 'vila-think-label';
      label.textContent = 'Đã nhận phản hồi sau ' + secs + ' giây';
      el.appendChild(label); box.appendChild(el);
    };
  }

  // ---------- Tạo video thật qua Gemini API Veo long-running operation ----------
  function base64FromDataUrl(dataUrl) {
    const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=_-]+)$/i.exec(String(dataUrl || ''));
    return match ? { mimeType: match[1].toLowerCase(), data: match[2] } : null;
  }
  function readBlobAsBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || '').split(',')[1] || '');
      reader.onerror = () => reject(reader.error || new Error('Không đọc được video để lưu.'));
      reader.readAsDataURL(blob);
    });
  }
  // Reads simple options from the prompt (like Gemini/ChatGPT video): orientation, length, resolution.
  function parseVideoOptions(text, hasImage) {
    const t = String(text || '').toLowerCase();
    let aspectRatio = '16:9';
    if (/(?:\b9\s*:\s*16\b|video dọc|dọc|portrait|vertical|tiktok|reels|shorts|story)/.test(t)) aspectRatio = '9:16';
    let durationSeconds = 8;
    const m = t.match(/(\d{1,2})\s*(?:giây|s\b|sec|second)/);
    if (m) { const n = Number(m[1]); durationSeconds = n <= 4 ? 4 : n <= 6 ? 6 : 8; }
    let resolution = /1080\s*p|full\s*hd/.test(t) ? '1080p' : '720p';
    // Veo: 1080p and image-to-video require the 8 second length.
    if (resolution === '1080p' || hasImage) durationSeconds = 8;
    return { aspectRatio, durationSeconds, resolution };
  }
  window.vilaParseVideoOptions = parseVideoOptions;
  window.vilaMakeVideo = async function (prompt, imageDataUrl) {
    const E = window.VILA_ENDPOINTS && window.VILA_ENDPOINTS.gemini;
    const key = typeof window.getGeminiKey === 'function' ? String(window.getGeminiKey() || '').trim() : '';
    if (!E || !E.nativeBase || !E.videoModel) throw new Error('Cấu hình model video chưa đầy đủ.');
    if (!key) throw new Error('Cần Gemini API Key đã lưu để tạo video bằng Veo.');
    const cleanPrompt = String(prompt || '').trim();
    if (!cleanPrompt) throw new Error('Hãy nhập mô tả video trước.');
    const ref = imageDataUrl ? base64FromDataUrl(imageDataUrl) : null;
    if (imageDataUrl && !ref) throw new Error('Ảnh tham chiếu phải là PNG, JPEG hoặc WebP hợp lệ.');
    const base = E.nativeBase.replace(/\/+$/, '');
    const opts = parseVideoOptions(cleanPrompt, !!ref);
    const requestBody = {
      instances: [{ prompt: cleanPrompt, ...(ref ? { image: { inlineData: { mimeType: ref.mimeType, data: ref.data } } } : {}) }],
      parameters: { aspectRatio: opts.aspectRatio, durationSeconds: String(opts.durationSeconds), resolution: opts.resolution, numberOfVideos: 1 }
    };
    if (window.VILA_USER_STOP_REQUEST) throw new Error('Đã dừng tác vụ video theo yêu cầu.');
    const controller = typeof window.createVilaChatAbortController === 'function' ? window.createVilaChatAbortController() : new AbortController();
    let timedOut = false;
    const timeoutMs = 8 * 60 * 1000;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
    const headers = { 'Content-Type': 'application/json', 'x-goog-api-key': key };
    const fetchJson = async (url, init = {}) => {
      if (window.VILA_USER_STOP_REQUEST) throw new Error('Đã dừng tác vụ video theo yêu cầu.');
      const r = await fetch(url, { ...init, signal: controller.signal });
      const raw = await r.text(); let data = {};
      try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}
      if (!r.ok) {
        const msg = data?.error?.message || data?.message || `Veo API lỗi HTTP ${r.status}`;
        const err = new Error(msg); err.status = r.status; throw err;
      }
      return data;
    };
    try {
      if (typeof window.setAiStatus === 'function') window.setAiStatus('Veo • đang gửi yêu cầu tạo video…', 'busy');
      const submitWith = (modelId) => fetchJson(`${base}/models/${encodeURIComponent(modelId)}:predictLongRunning`, {
        method: 'POST', headers, body: JSON.stringify(requestBody)
      });
      let submitted;
      try { submitted = await submitWith(E.videoModel); }
      catch (submitError) {
        // Preview model not enabled for this key/region: fall back to the faster Veo tier instead of failing outright.
        const st = Number(submitError && submitError.status);
        if (E.videoFallbackModel && E.videoFallbackModel !== E.videoModel && (st === 404 || st === 403 || st === 400) && !window.VILA_USER_STOP_REQUEST) {
          if (typeof window.showToast === 'function') window.showToast('Model Veo chính chưa khả dụng, đang thử Veo Fast.', 'info');
          submitted = await submitWith(E.videoFallbackModel);
        } else throw submitError;
      }
      const startedAt = Date.now();
      const operationName = String(submitted?.name || submitted?.operation?.name || '').trim();
      if (!operationName) throw new Error('Veo không trả mã tác vụ. Kiểm tra quyền model video và hạn mức API.');
      const operationUrl = (() => {
        const u = operationName.startsWith('https://') ? new URL(operationName) : new URL(`${base}/${operationName.replace(/^\/+/, '')}`, `${base}/`);
        if (u.origin !== new URL(base).origin || !u.pathname.startsWith('/v1beta/')) throw new Error('Veo trả về đường dẫn tác vụ không hợp lệ.');
        return u.toString();
      })();
      let operation = submitted; let pollErrors = 0;
      const deadline = Date.now() + timeoutMs - 5000;
      while (operation?.done !== true) {
        if (window.VILA_USER_STOP_REQUEST) throw new Error('Đã dừng tác vụ video theo yêu cầu.');
        if (Date.now() >= deadline) throw new Error('Veo vẫn chưa hoàn tất sau 8 phút. Hãy kiểm tra quota hoặc thử lại sau.');
        await new Promise((resolve, reject) => {
          const id = setTimeout(resolve, 8000);
          if (controller.signal.aborted) { clearTimeout(id); reject(new DOMException('Aborted', 'AbortError')); }
          else controller.signal.addEventListener('abort', () => { clearTimeout(id); reject(new DOMException('Aborted', 'AbortError')); }, { once: true });
        });
        if (typeof window.setAiStatus === 'function') window.setAiStatus('Veo • đang dựng video ' + opts.aspectRatio + ' · ' + opts.durationSeconds + 's… ' + Math.round((Date.now() - startedAt) / 1000) + 's', 'busy');
        try { operation = await fetchJson(operationUrl, { method: 'GET', headers: { 'x-goog-api-key': key } }); pollErrors = 0; }
        catch (pollError) {
          // A single dropped poll (flaky mobile network, 429/5xx) must not discard a video that is still rendering.
          const ps = Number(pollError && pollError.status);
          const transient = !ps || ps === 429 || ps >= 500;
          if (!transient || window.VILA_USER_STOP_REQUEST || (pollError && pollError.name === 'AbortError') || ++pollErrors > 4) throw pollError;
          continue;
        }
        if (operation?.error) throw new Error(operation.error.message || 'Veo không thể tạo video.');
      }
      if (operation?.error) throw new Error(operation.error.message || 'Veo không thể tạo video.');
      const videoUri = operation?.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri
        || operation?.response?.generatedVideos?.[0]?.video?.uri
        || operation?.result?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri;
      if (!videoUri) throw new Error('Veo kết thúc nhưng không trả đường dẫn video. Hãy kiểm tra phản hồi tác vụ/quota.');
      if (typeof window.setAiStatus === 'function') window.setAiStatus('Veo • đang tải video thật…', 'busy');
      const mediaResponse = await fetch(videoUri, { headers: { 'x-goog-api-key': key }, signal: controller.signal });
      if (!mediaResponse.ok) throw new Error(`Không tải được video từ Google (HTTP ${mediaResponse.status}). Hãy thử lại.`);
      const blob = await mediaResponse.blob();
      if (!blob.size || (blob.type && !/^video\//i.test(blob.type) && !/octet-stream/i.test(blob.type))) throw new Error('Google không trả về dữ liệu video hợp lệ.');
      const mime = /^video\//i.test(blob.type) ? blob.type : 'video/mp4';
      const filename = `VILA_${Date.now()}.mp4`;
      const url = URL.createObjectURL(new Blob([blob], { type: mime }));
      // Android's current bridge accepts base64 only; keep it to a bounded size to avoid
      // multiplying a very large video in WebView memory. The Blob remains usable for preview/download.
      let data = '';
      const maxNativeSaveBytes = 48 * 1024 * 1024;
      if (blob.size <= maxNativeSaveBytes) data = await readBlobAsBase64(blob);
      else if (typeof window.showToast === 'function') window.showToast('Video lớn: có thể xem và tải bằng liên kết. Lưu trực tiếp vào Downloads qua bridge bị giới hạn để tránh treo máy.', 'info');
      return { url, data, mime, filename, size: blob.size };
    } catch (error) {
      if (window.VILA_USER_STOP_REQUEST || (error && error.name === 'AbortError' && !timedOut)) {
        const stopped = new Error('Đã dừng tác vụ video theo yêu cầu.'); stopped.name = 'AbortError'; throw stopped;
      }
      if (timedOut || (error && error.name === 'AbortError')) throw new Error('Tạo video đã quá 8 phút hoặc bị hủy. Thử prompt ngắn hơn hoặc kiểm tra quyền/quota của Veo.');
      throw error;
    } finally {
      clearTimeout(timer);
      if (typeof window.releaseVilaChatAbortController === 'function') window.releaseVilaChatAbortController(controller);
    }
  };
  window.vilaAppendVideo = function (result) {
    const box = document.getElementById('chatMessages'); if (!box) return;
    const video = typeof result === 'string' ? { url: result, data: '', mime: 'video/mp4', filename: 'VILA-video.mp4' } : (result || {});
    if (!video.url) throw new Error('Không có URL video để hiển thị.');
    const d = document.createElement('div'); d.className = 'flex gap-4 items-start';
    d.innerHTML = '<div class="vila-avatar shrink-0">V</div><div style="min-width:0;max-width:100%"><p style="margin-bottom:8px">Video đã tạo xong 🎬</p><video controls playsinline preload="metadata" style="max-width:100%;width:100%;border-radius:12px"></video><p style="margin-top:6px;display:flex;gap:14px;flex-wrap:wrap"><a class="vila-video-download-link" download="VILA-video.mp4" style="color:#67e8f9;text-decoration:underline">Tải video</a><button type="button" class="vila-video-save-device" style="color:#a5b4fc;text-decoration:underline">Lưu vào Downloads</button></p></div>';
    d.querySelector('video').src = video.url;
    const link = d.querySelector('.vila-video-download-link'); link.href = video.url; link.download = video.filename || 'VILA-video.mp4';
    const save = d.querySelector('.vila-video-save-device');
    if (!(window.Android && typeof window.Android.saveBase64File === 'function' && video.data)) save.style.display = 'none';
    else save.addEventListener('click', function () {
      try { window.Android.saveBase64File(video.filename || 'VILA-video.mp4', video.data, video.mime || 'video/mp4'); if (window.showToast) window.showToast('Đang lưu video vào Downloads.', 'success'); }
      catch (error) { if (window.showToast) window.showToast('Không thể lưu video: ' + String(error && error.message || error), 'error'); }
    });
    box.appendChild(d); if (window.scrollToBottom) window.scrollToBottom();
  };
})();

/* V19: menu "+", camera/ảnh/video/ZIP, nút Suy nghĩ, nhãn giao diện */
(function () {
  'use strict';
  const $ = function (id) { return document.getElementById(id); };
  const ready = function (fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); };
  const toast = function (m, t) { if (window.showToast) window.showToast(m, t || 'info'); };
  const closeMenu = function () { if (window.closeInputTools) window.closeInputTools(); };

  function videoToFrames(file, n) {
    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(file), v = document.createElement('video');
      v.muted = true; v.playsInline = true; v.preload = 'auto';
      const out = [], base = file.name.replace(/\.[^.]+$/, '');
      const fail = function (msg) { URL.revokeObjectURL(url); reject(new Error(msg)); };
      v.onerror = function () { fail(file.name + ': không đọc được video này.'); };
      v.onloadedmetadata = function () {
        const dur = v.duration || 1, W = Math.min(768, v.videoWidth || 768), H = Math.round(W * (v.videoHeight || 432) / (v.videoWidth || 768));
        const c = document.createElement('canvas'); c.width = W; c.height = H; let i = 0;
        v.onseeked = function () {
          c.getContext('2d').drawImage(v, 0, 0, W, H);
          c.toBlob(function (b) {
            if (!b) return fail('Không lấy được khung hình.');
            out.push(new File([b], base + '-khung' + (i + 1) + '.jpg', { type: 'image/jpeg' })); i++;
            if (i >= n) { URL.revokeObjectURL(url); resolve(out); } else v.currentTime = dur * (i + 0.5) / n;
          }, 'image/jpeg', 0.8);
        };
        v.currentTime = dur * 0.5 / n;
      };
      v.src = url;
    });
  }

  ready(function () {
    const tb = $('themeToggleBtn');
    const mode = () => document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
    if (tb && !tb.dataset.vilaThemeBound) {
      tb.dataset.vilaThemeBound = '1';
      tb.addEventListener('click', function () { window.vilaSetTheme(mode() === 'light' ? 'dark' : 'light'); });
    }
    syncThemeButton(mode());
    new MutationObserver(() => syncThemeButton(mode())).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    const deep = $('deepThinkToggle'), lvl = $('reasoningLevel');
    if (deep && lvl) {
      deep.checked = lvl.value === 'high';
      deep.addEventListener('change', function () { lvl.value = deep.checked ? 'high' : 'medium'; lvl.dispatchEvent(new Event('change')); });
    }

    const cam = $('cameraInput'), med = $('mediaInput');
    if ($('cameraBtn')) $('cameraBtn').addEventListener('click', function () { closeMenu(); cam.click(); });
    if ($('mediaBtn')) $('mediaBtn').addEventListener('click', function () { closeMenu(); med.click(); });
    if ($('makeVideoBtn')) $('makeVideoBtn').addEventListener('click', function () {
      closeMenu(); const t = $('userPrompt'); if (!t) return;
      if (!/^\/video\s/i.test(t.value)) t.value = '/video ' + t.value;
      t.focus(); t.dispatchEvent(new Event('input')); toast('Mô tả video rồi bấm gửi. Đính kèm 1 ảnh để biến ảnh thành video.');
    });
    if ($('generateImageBtn')) $('generateImageBtn').addEventListener('click', closeMenu);
    if ($('attachFileBtn')) $('attachFileBtn').addEventListener('click', closeMenu);
    if (cam) cam.addEventListener('change', function (ev) { const f = Array.from(ev.target.files || []); ev.target.value = ''; if (f.length) window.handleFiles(f); });
    if (med) med.addEventListener('change', async function (ev) {
      const files = Array.from(ev.target.files || []); ev.target.value = ''; const out = [];
      for (const f of files) {
        if (f.type.indexOf('video/') === 0) {
          if (f.size > 200 * 1024 * 1024) { toast(f.name + ': video quá lớn (tối đa 200MB).', 'error'); continue; }
          try { toast('Đang lấy khung hình từ video…'); out.push.apply(out, await videoToFrames(f, 3)); } catch (err) { toast(err.message, 'error'); }
        } else out.push(f);
      }
      if (out.length) window.handleFiles(out);
    });
  });
})();
