# VILA AI Studio V70.0.0 — Chat UX, Preview, and source test report

**Scope:** source-level cleanup after feedback about flashing legacy colors, a hidden model selector, overlapping Model Hub controls, duplicate history controls, and inconsistent secondary panels.

## Changes made

- **Welcome/chat overlap:** the large “Mình có thể giúp gì cho bạn?” welcome is limited to an empty chat. Adding a user message, AI answer, loading status, or error removes the stale welcome element; typing a draft also hides it, and clearing an empty draft can restore it. Mobile title size and margin are reduced.
- **Real explicit code Preview action:** supported fenced code blocks show a dedicated “Xem trước” button. The handler reads the visible code text, validates the language, stores the latest code/type, invokes the real `runGeneratedCode()` iframe/srcdoc preview path, and opens the Preview panel on narrow screens. It no longer reports success if the preview frame is missing or render setup fails. It does not auto-run every code answer.
- **Reasoning/loading panel:** replaced the fake multi-step checklist with a compact, truthful status row showing current status/provider/elapsed time. It does not claim internal hidden reasoning steps.
- **Voice Studio placement:** keeps one menu entry rather than a full-width bottom bar that steals composer space.

- **Latest no-flash correction:** moved the remaining 14 application stylesheet layers, including the final V68 palette, out of the document body and into the head in the original cascade order. Added higher-specificity overrides for the header model chip, composer dock, Explore panels, and generated-image action surfaces so legacy gradient rules no longer win. Also moved `vila-simple.css` into the head while leaving its behavior script after the markup. This prevents late style insertion from repainting the app from old cyan/purple/gradient skins after the first frame.
- Removed the unused neon particle canvas and perpetual animation loop rather than leaving it hidden and running. Provider status updates now use the same neutral badge classes for Puter, Gemini and other providers, rather than changing to separate violet/cyan/emerald palettes at runtime.
- Added first-paint guards for settings, account, memory, login, model-picker, composer and provider controls to use the shared dark/light palette.
- Fixed four Explore shortcuts that referenced removed button IDs; they now invoke the real Code Lab, web-search, image and video actions.

- **Follow-up fix after user reported persistent old-color flashes:** added an early, high-specificity legacy-color/animation guard in the first critical stylesheet and a final component pass after legacy styles. The Max/fast-mode controls, Voice Studio, focus rings, composer, search focus and Model Hub filter/sort layout now resolve to the same neutral palette instead of inheriting old neon/bright-green styles.

- Added a theme bootstrap in `<head>` so saved Light/Dark mode is applied before Tailwind and remote CSS/JS load; first-paint selectors now cover the header, model selector, message area and composer.
- Removed the animated neon welcome splash and its unused animation keyframes.
- Replaced old Tailwind brand/neon/dark palette values with neutral values while keeping old class names temporarily for markup compatibility.
- Replaced the duplicate, oversized V66 UI override stack with a single cohesive `vila-v68-cohesive-ui` layer using neutral charcoal/light surfaces, consistent borders and one restrained green accent. The final pass preserves small functional transitions and intentional card/dialog depth rather than globally disabling all motion or shadows; only old pulse/neon motion is suppressed.
- Removed legacy Model Hub presentation CSS and kept only its necessary fallback/image foundation rules; the Model Hub's live search, provider filters, sort row, model list, cards and footer are styled in one place.
- Fixed a structural CSS mistake that hid `.ds-model-copy`, the parent of the actual model-selector button. The selected model label is now intended to be visible and compact.
- Removed the redundant floating navigation/sidebar and its second, non-persistent chat-tab store. Conversation history uses the V68 local archive and is reachable in the main menu.
- Removed the separate floating Stop button; the composer Send button changes to Stop while a request is in progress and calls the existing abort routine.
- Removed pulse/shimmer and redundant neon provider ranking panel; secondary settings, gateway, preview and dialog surfaces share the same palette.
- Kept the Google sign-in button label clear and corrected the theme toggle so the SVG icon updates after an icon replacement.
- Added a dedicated regression suite for theme bootstrap behavior, the legacy splash, actual Model Hub selectors, old UI removal, theme button behavior and preservation of Stop/Voice Studio actions.

## V70 implementation delta

- Updated release metadata consistently to app/Gateway/package `70.0.0`, Android `versionCode 83`, CI artifact names, compose image, and in-app update checker.
- Removed the legacy fallback reasoning simulation in `vila-extras.js`: it no longer advances through a pre-scripted list of “thinking” milestones based only on elapsed time. The fallback now reports only the actual waiting state and elapsed seconds. The main V69 compact status implementation is preserved.
- Improved the existing final mobile repair stylesheet in-place (rather than adding another stylesheet layer): the composer text input uses a readable 16px font and bounded height, model search fields use readable sizing, keyboard focus is visible, and narrow-screen code actions retain a practical touch target.
- Added `scripts/test-v70-quality-gates.js` for release metadata synchronization, stylesheet parsing, key mobile controls, preview sandboxing, reduced-motion behavior, input sizing, focus visibility and truthful fallback status.

## V70 targeted regression coverage

- Added `scripts/test-v69-chat-preview-ux.js`. It checks version sync; parses the 33 actual stylesheet blocks after excluding inline script text; asserts the welcome lifecycle is wired into message/loading/error paths; asserts the compact status panel does not contain staged/fake steps; executes `previewCodeBlock()` in a VM with mocks to verify it hands code to the existing renderer, opens mobile Preview, and refuses empty/unsupported code or a failed render setup; and checks Voice Studio menu placement.
- Preview uses the app's existing isolated `iframe`/`srcdoc` renderer. Supported preview types are HTML/SVG/CSS/JS/JSON/XML/Markdown/text. Previewing CSS/JS without a full HTML document uses VILA's sample preview shell; raw XML is shown as code rather than executed as an app. A valid source assignment is not a guarantee the generated app itself has no runtime bugs; iframe diagnostics still report observed JS errors.

## Automated checks performed

- Added PostCSS as an explicit root development dependency and updated CI/build docs to install source-test dependencies instead of relying on a globally installed package.
- `npm test`: **35/35 test groups passed** after the V70 quality-gate and fallback-status changes. This includes the Gateway's existing unit/security/reliability checks and source regression tests.
- Existing UI stability regression tests passed: executes the early theme bootstrap against simulated Light/Dark/legacy-preference storage, parses the cohesive CSS with PostCSS, verifies the model-selector parent is displayed, checks the dynamic Model Hub selectors, asserts that obsolete floating history/Stop UI is gone while the real composer Stop action remains wired, and requires all final UI styles to load before `<body>`.
- Final static validation: **5/5 XML valid**, **3/3 JSON valid**, **165 static HTML IDs with no duplicates**, **93 literal `getElementById` targets with no missing references**, and no unresolved direct function names in static `onclick` handlers. The relevant final UI layers are all positioned before the body markup.
- Removed the debug keystore binary from the source package; CI creates an ephemeral debug key unless an owner supplies `ANDROID_DEBUG_KEYSTORE_BASE64` privately. A public source ZIP should not disclose a signing-key file.
- `npm run play:preflight`: **4 PASS · 3 WARN · 2 BLOCK**. The privacy policy and account-deletion pages still need true owner contact details and live HTTPS URLs; these are real release blockers, not UI test failures.

## Visual/runtime verification limits

- These changes eliminate late stylesheet insertion and the decorative particle loop at source level, and strengthen selectors that previously lost to legacy CSS specificity; however, **the final rendered pixels have not been visually verified** because the headless browser screenshot attempt timed out. Do not treat static CSS tests as visual QA.

- No Android SDK, ADB or standalone Gradle executable is available in this workspace; no APK/AAB was built here.
- Google/Firebase sign-in and live AI provider requests were not run during the offline regression tests.
- Install and inspect the build on the target OPPO/Android device after GitHub Actions creates the debug APK; recheck dark/light switching, Model Hub at narrow width, login flow, prompt submit/stop, chat history, attachments and Voice Studio.

## Release status

This is a **cleaned source-code package**, not a tested APK and not a Google Play-approved release. Do not claim the app is production-ready until browser/device rendering, live integrations, signed AAB build, network/security review and owner-provided privacy/account-deletion details are verified.
