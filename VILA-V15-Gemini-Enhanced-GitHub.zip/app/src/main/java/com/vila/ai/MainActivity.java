package com.vila.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    LocalProxy proxy;
    android.content.SharedPreferences prefs;
    static final int PORT = 18787;
    static final int REQ_NOTIFICATIONS = 1001;
    static final int REQ_AUDIO = 1002;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vila", MODE_PRIVATE);
        proxy = new LocalProxy(this, PORT);
        proxy.start();
        web = new WebView(this);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setBackgroundColor(Color.rgb(3,7,18));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setOffscreenPreRaster(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission("android.permission.RECORD_AUDIO") != getPackageManager().PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, REQ_AUDIO);
                        return;
                    }
                    request.grant(request.getResources());
                });
            }

            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try { startActivityForResult(intent, 2001); fileCallback = callback; return true; }
                catch (Exception e) { callback.onReceiveValue(null); return false; }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                req.setDescription("VILA AI đang tải file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
                dm.enqueue(req);
                Toast.makeText(this, "Đang tải file vào thư mục Downloads", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Không thể tải file", Toast.LENGTH_SHORT).show(); }
        });
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(web);
        web.loadUrl("http://127.0.0.1:" + PORT + "/");
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.RECORD_AUDIO") != getPackageManager().PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, REQ_AUDIO);
        } else if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != getPackageManager().PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFICATIONS);
        }
    }


    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2001 && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) results = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
    public class AndroidBridge {
        @android.webkit.JavascriptInterface public void setServerUrl(String url) {
            String u = url == null ? "" : url.trim();
            while (u.endsWith("/")) u = u.substring(0, u.length()-1);
            prefs.edit().putString("server_url", u).apply();
            proxy.setRemote(u);
        }
        @android.webkit.JavascriptInterface public String getServerUrl() { return proxy.remote == null ? "" : proxy.remote; }
    }

    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(proxy!=null) proxy.stopServer(); super.onDestroy(); }

    static class LocalProxy extends Thread {
        final MainActivity ctx; final int port; volatile boolean running=true; ServerSocket ss; volatile String remote;
        LocalProxy(MainActivity c,int p){ctx=c;port=p;remote=c.prefs.getString("server_url","").trim();}
        void setRemote(String u){remote=u;}
        public void run(){try{ss=new ServerSocket(); ss.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),port)); while(running){try{Socket s=ss.accept(); new Thread(()->handle(s)).start();}catch(Exception ignored){}}}catch(Exception ignored){}}
        void handle(Socket s){try{s.setSoTimeout(15000); BufferedInputStream in=new BufferedInputStream(s.getInputStream()); OutputStream out=s.getOutputStream(); String request=readLine(in); if(request==null){s.close();return;} String[] p=request.split(" "); String method=p[0], path=p[1]; Map<String,String> headers=new HashMap<>(); String line; while((line=readLine(in))!=null&&!line.isEmpty()){int i=line.indexOf(':');if(i>0)headers.put(line.substring(0,i).toLowerCase(),line.substring(i+1).trim());}
            int len=0; try{len=Integer.parseInt(headers.getOrDefault("content-length","0"));}catch(Exception ignored){} byte[] body=new byte[len]; int off=0; while(off<len){int n=in.read(body,off,len-off);if(n<0)break;off+=n;}
            if(path.equals("/")||path.startsWith("/index.html")){byte[] html=asset("index.html"); write(out,200,"text/html; charset=utf-8",html);}
            else if(path.startsWith("/api/")){forward(out,method,path,body);}
            else {write(out,404,"text/plain; charset=utf-8","Not found".getBytes(StandardCharsets.UTF_8));}
            s.close();}catch(Exception ignored){try{s.close();}catch(Exception x){}}}
        String readLine(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();int c,prev=-1;while((c=in.read())!=-1){if(prev=='\r'&&c=='\n'){b.write('\r');break;}b.write(c);prev=c;if(b.size()>8192)break;}String x=b.toString("ISO-8859-1");return x.replace("\r","").replace("\n","");}
        byte[] asset(String n)throws IOException{InputStream i=ctx.getAssets().open(n);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}
        void forward(OutputStream out,String method,String path,byte[] body)throws Exception{if(remote.isEmpty()){write(out,503,"application/json; charset=utf-8",("{\"message\":\"Chưa cấu hình VILA Server. Mở menu ⚙ Server.\"}").getBytes(StandardCharsets.UTF_8));return;} URL u=new URL(remote+path);HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(60000);c.setRequestProperty("Content-Type","application/json");c.setDoInput(true);if("POST".equals(method)){c.setDoOutput(true);c.getOutputStream().write(body);}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();byte[] data=readAll(is);String ct=c.getHeaderField("Content-Type");write(out,code,ct==null?"application/json; charset=utf-8":ct,data);c.disconnect();}
        byte[] readAll(InputStream i)throws IOException{if(i==null)return new byte[0];ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int k;while((k=i.read(x))>0)b.write(x,0,k);return b.toByteArray();}
        void write(OutputStream o,int code,String ct,byte[] data)throws IOException{String h="HTTP/1.1 "+code+" "+(code==200?"OK":code==503?"Service Unavailable":"Error")+"\r\nContent-Type: "+ct+"\r\nContent-Length: "+data.length+"\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n";o.write(h.getBytes(StandardCharsets.ISO_8859_1));o.write(data);o.flush();}
        void stopServer(){running=false;try{if(ss!=null)ss.close();}catch(Exception ignored){}}
    }
}
