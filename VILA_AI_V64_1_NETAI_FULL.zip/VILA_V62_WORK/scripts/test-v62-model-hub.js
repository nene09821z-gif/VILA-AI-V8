'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('app/src/main/assets/index.html');
const gradle = read('app/build.gradle');
const rootPkg = JSON.parse(read('package.json'));
const gatewayPkg = JSON.parse(read('server/package.json'));
const server = read('server/src/server.js');
const workflow = read('.github/workflows/main.yml');
const compose = read('compose.yaml');
const changelog = read('CHANGELOG.md');

assert.equal(rootPkg.version, '62.0.0');
assert.equal(gatewayPkg.version, '62.0.0');
assert.match(gradle, /versionCode 77/);
assert.match(gradle, /versionName "62\.0\.0"/);
assert.match(server, /const APP_VERSION = '62\.0\.0'/);
assert.match(compose, /vila-ai-gateway:62\.0\.0/);
assert.match(changelog, /^# VILA AI Studio 62\.0\.0/m);
assert.match(workflow, /node scripts\/test-v62-model-hub\.js/);

// Model Hub UI: capability filters, favourites/recent, Vietnamese accent-folded search and batch rendering.
for (const id of ['vilaModelPicker', 'vilaModelPickerTrigger', 'vilaModelPickerSearch', 'vilaModelPickerProviders', 'vilaModelPickerFilters', 'vilaModelPickerList']) {
  assert.ok(html.includes(`id="${id}"`), `missing UI node ${id}`);
}
assert.match(html, /FAVORITES_KEY='vila_model_favorites_v1'/);
assert.match(html, /RECENT_KEY='vila_model_recent_v1'/);
assert.match(html, /PAGE_SIZE=60/);
assert.match(html, /rows\.slice\(0,shownCount\)/);
assert.match(html, /normalize\(String\(search\?\.value\|\|''\)\.trim\(\)\)/);
assert.match(html, /replace\(\/\[\\u0300-\\u036f\]\/g,''\)/);
assert.match(html, /supportsImages\(m\)/);
assert.match(html, /supportsReasoning\(m\)/);
assert.match(html, /supportsWeb\(m\)/);
assert.match(html, /supportsCode\(m,id\)/);
assert.match(html, /aria-pressed/);
assert.match(html, /getClientRects\(\)\.length>0/);
assert.match(html, /Áp dụng cho tin sau.*FREE\* không bảo đảm quota/);
assert.match(html, /Không thể dựng Preview/);
assert.match(html, /const current='62\.0\.0'/);

// Compile the controller separately so syntax failures are caught without needing a browser DOM.
const scriptMatch = html.match(/<script id="vila-v62-model-picker-controller">([\s\S]*?)<\/script>/);
assert.ok(scriptMatch, 'V62 model picker controller missing');
new vm.Script(scriptMatch[1], { filename: 'vila-v62-model-picker-controller.js' });
const inlineScripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)]
  .filter(match => !/\bsrc\s*=/.test(match[1]) && match[2].trim() && !/type\s*=\s*["'](?:application\/ld\+json|application\/json|text\/template)["']/i.test(match[1]));
assert.ok(inlineScripts.length >= 10, `expected inline JavaScript blocks, found ${inlineScripts.length}`);
inlineScripts.forEach((match, index) => new vm.Script(match[2], { filename: `vila-inline-${index + 1}.js` }));
assert.equal((html.match(/<style\b/g) || []).length, (html.match(/<\/style>/g) || []).length, 'style tags must be balanced');
console.log('PASS V62 Model Hub filters, saved favourites/recent, accent-insensitive search, 60-item rendering, accessible dialog, Preview failure UI and release metadata');
