const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const a = f => path.join(root, 'app/src/main/assets', f);
const html = fs.readFileSync(a('index.html'), 'utf8');
const css = fs.readFileSync(a('vila-simple.css'), 'utf8');
const js = fs.readFileSync(a('vila-simple.js'), 'utf8');
assert.ok(html.includes('href="vila-simple.css"') && html.includes('src="vila-simple.js"'), 'simple UI assets must be linked');
assert.ok(html.indexOf('id="vila-v60-360dpi-preview-429"') > html.indexOf('vila-simple.css') && html.indexOf('id="vila-v60-360dpi-preview-429"') > html.indexOf('src="vila-simple.js"'), 'V60 mobile override must load after simple UI CSS/JS so compact rules win the cascade');
assert.ok(html.includes("classList.add('vila-simple')") && !html.includes("getItem('vila_ui_simple')"), 'simple class always applied before first paint');
const rules = css.split('}').map(r => r.trim()).filter(r => r && !r.startsWith('/*') && !r.startsWith('@') && !/^\s*(html:?|:root)/.test(r.split('{')[0]) === false);
for (const sel of css.replace(/\/\*[\s\S]*?\*\//g, '').split('}').map(x => x.split('{')[0].trim()).filter(Boolean)) {
  if (sel.startsWith('@media') || sel.startsWith('#vilaKnowledge') || sel.startsWith('html.vila-simple')) continue;
  assert.fail('CSS selector not scoped to html.vila-simple or #vilaKnowledge: ' + sel);
}
assert.ok(js.includes('function isSimple() { return true; }') && js.includes('openVilaKnowledge') && !js.includes('vilaSimpleToggleBtn'), 'simple is the only UI; knowledge dialog exists');
assert.ok(js.includes("aria-modal") && js.includes('aria-label'), 'dialog is accessible');
assert.ok(!/innerHTML\s*=\s*[^;]*\+\s*(text|e\.message)\b/.test(js) || js.includes('function esc'), 'dynamic text must be escaped');
assert.ok(html.includes('window.vilaAuthedGatewayFetch=authedGatewayFetch'), 'gateway fetch helper exposed to the knowledge dialog');
assert.ok(!/githubToken|GithubToken|github_pat_/.test(html + js), 'no GitHub token UI');
assert.ok(js.includes('vila-img-failed') && css.includes('img.vila-img-failed'), 'broken images must get the neat placeholder');
assert.ok(css.includes('html.vila-simple body{margin:0}') && css.includes('.min-w-0'), 'layout and images must not depend on the Tailwind CDN');
assert.ok(/Cache-Control: public, max-age=86400/.test(fs.readFileSync(path.join(root, 'app/src/main/java/com/vila/ai/MainActivity.java'), 'utf8')), 'local server must cache images');
console.log('PASS: V54 simple UI, scoped CSS, knowledge dialog, GitHub token removal');
