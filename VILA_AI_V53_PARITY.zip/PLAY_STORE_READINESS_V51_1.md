# VILA AI 51.1.0 — Google Play readiness review

**Status: source-prepared for further testing, NOT ready for public release yet.** This document is deliberately conservative. Passing static checks does not prove that the APK compiles, that Firebase operations work against the live project, or that Play Console will approve the listing.

## Improvements included in the source

- Android target SDK is 36, version is `51.1.0` and `versionCode` is 59. Google Play's current target API guidance says new apps and updates must target Android 16 / API 36 or above beginning 31 August 2026. See the [official target API requirements](https://support.google.com/googleplay/android-developer/answer/11926878?hl=en).
- Adds a loopback-only discovery UI for a short, explicit list of common local AI endpoints; it probes only after the user presses the button, bounds concurrent checks, doesn't send prompts or keys during discovery, and never scans arbitrary Internet addresses or LAN devices. CORS/WebView policy may still prevent a server from being detected.
- Adds an in-app privacy-policy entry and Firebase account-deletion action, plus draft copies of `privacy-policy.html` and `account-deletion.html` at the project root for a future HTTPS host.
- The policy and deletion pages are intentionally marked **drafts**; placeholders are still present because the project's real operator/contact information and public domain were not provided. Do not publish them unchanged.
- Adds CI regression checks for endpoint discovery, deletion UI/native bridge, and draft privacy pages.

## Required before submitting to Play Console

1. **Publish a real privacy policy.** Replace all `[TÊN ...]`, `[EMAIL ...]`, `[URL ...]`, and other placeholder text with factual information. Re-check every statement against final Android permissions, Firebase settings, third-party SDKs, provider routing, actual log retention, and data storage. Publish at a stable, public, HTTPS URL with no login/geofencing. Put the same URL in Play Console and keep the policy accessible in-app. Google says the policy must disclose developer/contact, data handling/sharing, security and retention; see [Google Play User Data policy](https://support.google.com/googleplay/android-developer/answer/10144311?hl=en).
2. **Deploy a working external account-deletion page.** Replace `[EMAIL_LIEN_HE]` and processing-time placeholders; ensure that contact channel is monitored and that users can request deletion without reinstalling the app. Enter the live HTTPS URL into Play Console's account-deletion URL field. Google requires both an in-app path and an external web resource, and deletion of associated data under the developer's control; see [Understanding account deletion requirements](https://support.google.com/googleplay/android-developer/answer/13327111?hl=en).
3. **Audit actual account data.** The included button deletes the current Firebase Authentication account and the app's managed local data/secrets. Before release, inspect Firebase/Firestore/Storage and Gateway deployment for any other user records. If anything else is stored server-side, implement and test deletion there too; do not state that all data is deleted until this is verified. Third-party-provider retention is outside the app's control and must be described accurately.
4. **Complete Data safety accurately.** Evaluate the actual release APK including Firebase SDKs, WebView, all enabled features, Gateway deployment and selected AI providers. Do not assume that endpoint discovery being local means the whole app collects no user data. Ensure Data safety answers and privacy policy agree. Google's [User Data policy](https://support.google.com/googleplay/android-developer/answer/10144311?hl=en) explicitly includes SDK data and sharing.
5. **Test Firebase live on real devices.** Test email registration/login/reset, Google login, deleting an account, recent-login-required failures, signing out/in and local secret clearing on Android. Verify account deletion removes user-side data actually controlled by the service, not just the Authentication record.
6. **Build and install the APK.** Run `.github/workflows/main.yml` and inspect the output artifact. The local source checks do not substitute for Android Gradle build verification. Install on a physical device and test Android 12+, current Android, rotations/small screens, WebView camera/microphone/file prompts, voice, uploads, cancellation, offline states and low-memory behavior.
7. **Production signing.** Configure a persistent private release signing key through GitHub Actions secrets. Do not publish the debug APK or use a committed debug keystore as the production signing key. Keep the signing key and passwords out of Git and ZIP release assets.
8. **HTTP endpoint security.** The current manifest allows cleartext traffic to support user-configured local HTTP AI servers. Before public release, review this tradeoff carefully: do not send API keys or prompts to untrusted remote HTTP endpoints. Prefer HTTPS for remote services and make the endpoint UI clearly identify insecure HTTP connections. Verify that tightening Android network security does not break legitimate local AI use.
9. **Store listing and policy review.** Prepare truthful screenshots, app description, category/content rating, support contact, Data safety responses and testing track. Review all permissions and third-party provider terms; only market features that work in the submitted APK.

## Scope of endpoint recognition

“Recognize all gateways” cannot literally mean discovering every API on the Internet. Providers may require keys, use different protocols, block CORS, or be intentionally private. This implementation recognizes a finite set of common local endpoints on loopback and tests already configured providers. It does not port-scan the Internet or other devices. Detection is best-effort, and every detected endpoint must be selected before the app uses it.

## What is and isn't verified

- Static regression scripts and Node Gateway tests can be run in this source package.
- Build APK, live provider requests, current Firebase/OAuth configuration, real account deletion, privacy-policy hosting and Play Console approval remain unverified until executed by the owner on CI/real infrastructure.
