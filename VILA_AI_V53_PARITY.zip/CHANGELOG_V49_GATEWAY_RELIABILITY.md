# VILA AI 49.0.0 — Chat status and Gateway reliability

## Fixes

- Corrected the thinking-status component lookup: the chat's status panel is the target element itself, so status updates now act on it directly rather than searching only its children.
- Made the current Gemini fallback model visible in the status line while VILA tries compatible model IDs.
- Added a bounded whole-request deadline to Gateway chat, including the time spent reading a streamed response. The deadline is configurable per call and capped at five minutes.
- Ensured Gateway abort controllers are released on success and failure, and added actionable errors for network/CORS problems, invalid JSON, empty responses, HTTP failures, and full-request timeout.
- Synchronized the Android app version, Gateway response metadata, and update checker to version 49.0.0 (`versionCode 56`).

## Gateway architecture

- Android app → HTTPS VILA Gateway → configured Gemini, OpenRouter, Groq, Cerebras, or administrator-configured OpenAI-compatible provider.
- The server keeps provider secrets in environment variables, verifies Firebase ID tokens in production, has bounded request rates/concurrency/provider attempts, and uses a circuit breaker plus fallback routing in auto mode.
- If the user enables Gateway mode, the app routes ordinary chat through the server. Direct image and Veo video calls still use the Gemini API flow in the app; they need valid Gemini access and provider quota.

## Not claimed as verified

- This ZIP contains server source; it does **not** mean a public server is already deployed or API keys are configured.
- Real provider calls require server-side API keys, Firebase Admin credentials, valid account permissions/quota, HTTPS hosting, and a URL configured in the app.
- Source checks and Node tests do not substitute for a successful GitHub Actions Android Gradle build or live end-to-end test on a device.
