# VILA AI V52.2.0 — Full file-by-file reliability sweep (Android local proxy recovery)

Scope of this pass: went through every source file in the project (all `server/src/*.js`,
`server/agent-server.mjs` + `server/server.js`, every Android `.java` file, every inline/
standalone JS asset the WebView loads, build/CI config) looking specifically for things that
fail silently or permanently rather than things that are merely incomplete (the incomplete
items — shared-state across replicas, persistent RAG, a factual-accuracy benchmark — are
architecture-level and listed again at the end; they are unchanged by this patch).

## Fixed — Android app (`MainActivity.java`)

The app's UI is a WebView pointed at a tiny local HTTP server (`LocalProxy`, bound to
`127.0.0.1:18787`) that serves the bundled `index.html`/JS/assets out of the APK. Two related
failure modes in that bridge could leave the user staring at a permanently blank/white screen
with **no error message and no way to recover short of force-closing the app**:

1. **`LocalProxy.bind()` had no retry.** If the port was briefly unavailable — most commonly
   right after an app restart, while the previous process's socket was still releasing — a
   single failed `bind()` left the server socket `null` forever. The accept loop in `run()`
   then returned immediately without ever listening, while `MainActivity` had already called
   `web.loadUrl("http://127.0.0.1:18787/")` unconditionally. Fix: `run()` now retries `bind()`
   up to 20 times with a 150ms backoff (bounded, on the background thread, never blocking the
   UI thread) before giving up; a new `onBindFailed` callback lets `MainActivity` react instead
   of failing invisibly.
2. **No recovery path for a failed/refused page load.** `WebViewClient` had no
   `onReceivedError` override at all, so any connection failure to the local server (the bind
   race above, or the OS briefly trimming the socket after the app was backgrounded) was a dead
   end. Fix: added `onReceivedError` (main-frame only) that triggers a bounded, backed-off retry
   of `loadUrl` (`retryLoadLocalPage()`, capped at 6 attempts, 250ms–3s backoff, counter reset on
   a successful `onPageFinished`), and `LocalProxy.onBindFailed` now routes into the same retry
   path with a one-time Toast telling the user what's happening. If every retry is exhausted
   (a genuinely stuck state), the user now sees one clear message — "hãy đóng hẳn và mở lại
   ứng dụng" — instead of silence.

Both additions are defensive/additive: the normal startup path (bind succeeds on the first
try, page loads normally) is completely unchanged.

## Reviewed, found already solid (no change needed)

- `VilaKeepAliveService.java`, `VilaNotifier.java`: null/SDK-version guarded throughout,
  `onDestroy`/`onTaskRemoved` correctly tear down the foreground notification; no leak or crash
  path found.
- `server/src/engine.js`, `server/src/security.js`: small, already defensively written
  (URL validation rejects credentials-in-URL, production CORS/`AUTH_MODE=off` refused at boot,
  structured error classification); no changes needed.
- `server/agent-server.mjs` (+ its `server/server.js` launcher shim): the one remaining
  all-async file without a wrapper, but it's already safe — every request is dispatched through
  `handle(req,res).catch(e => json(res,500,...))` at the `http.createServer` callback, so an
  error here already can't escape as an unhandled rejection the way the three Express routes
  patched in V52.1 could. Build-zip extraction already rejects path traversal and absolute/
  drive-letter paths; the build endpoint is off by default (`ALLOW_UNTRUSTED_BUILDS`) and auth
  uses `crypto.timingSafeEqual`. No change needed.
- All WebView-facing JS assets (`index.html`'s 9 inline script blocks, `vila-extras.js`,
  `vila-endpoint-core.js`, `vila-v38.js`, `endpoints.js`, `firebase-config.js`) still pass
  `node --check`; spot-checked the dozen `fetch()` call sites in the main inline script and all
  are `await`ed inside `try/catch` (143 try blocks in that one file). A browser-side unhandled
  promise rejection also isn't fatal the way a Node one is (it logs to console, doesn't kill the
  page), so this surface was lower priority than the two fixes above and the V52.1 server fixes.

## Verified

- `node --check` on every modified/reviewed `.js`/`.mjs` file: passed.
- `node --test server/test/*.test.js`: **23/23 passed, unchanged** (no server test-covered
  module was touched this round).
- Manual brace/paren balance check on the edited `MainActivity.java` (1445 parens, 390 braces,
  both balanced) since this sandbox has no Android SDK/Gradle to run a real `javac`/compile
  check — **a real build via the GitHub Actions workflow is still required before this is
  considered build-verified**, same limit as every prior audit in this project.

## Versioning

- Android `versionCode` 61 → 62, `versionName` "52.1.0" → "52.2.0".
- Server `package.json` / `APP_VERSION` → "52.2.0" (kept in lockstep with the app version per
  this project's existing convention; the server code itself is unchanged since V52.1).
- `compose.yaml` image tag → `vila-ai-gateway:52.2.0`.

## Still open (architecture-level, unchanged by this patch — same as prior audits)

- In-memory rate limit / concurrency / circuit-breaker state is per-process; multi-replica
  deployments still need a shared store.
- No persistent RAG/vector retrieval store; no calibrated factual-accuracy benchmark.
- Privacy policy / account-deletion pages are still templates.
- No real Android build or on-device test was performed in this environment — the fixed-port
  `LocalProxy` retry logic above is a logic fix for a real failure mode found by code review,
  not something exercised end-to-end on a device here.
