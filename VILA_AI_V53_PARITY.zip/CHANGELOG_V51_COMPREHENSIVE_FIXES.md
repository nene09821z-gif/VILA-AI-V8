# VILA AI V51 — audit and fixes

## Version consistency
- Bumped Android `versionCode` to `58` and `versionName` to `51.0.0`.
- Synchronized the app update checker, Gateway `/health` and `/v1/gateway/status`, runtime startup log, Node package metadata, and deployment example.
- Updated active source regression checks so they detect version drift instead of expecting V50 metadata.

## Android secret storage
- Corrected a mismatch between the UI promise and native implementation: the native bridge had actually written API keys, GitHub tokens, and the optional Agent bearer token as plaintext SharedPreferences/localStorage values.
- Gemini keys, provider API keys, GitHub tokens, and the optional Agent Server bearer token now use AES-GCM (`AES/GCM/NoPadding`) with a non-exportable AES key in Android Keystore.
- Existing plaintext preferences are migrated when read and successfully encrypted; the plaintext copy is removed only after encryption succeeds. If decryption fails, the secret is not silently returned from a plaintext fallback.
- Browser preview still relies on localStorage and does not inherit Android Keystore protection.

## Gateway security and reliability
- Added a reusable CORS/security policy: wildcard CORS and unauthenticated mode are refused in production; production with no explicit CORS list defaults to no browser-origin allowlist. Requests without an Origin header still require normal auth for protected endpoints.
- Refined request-error mapping: malformed JSON → `400`, oversized payload → `413`, interrupted upload → `400`; unexpected faults remain a generic `500` response without internal details.
- Added unit tests for these policies and static regressions for secret migration/storage.

## DeepSeek local connector
- Kept the preset as an OpenAI-compatible connector. Updated the setup command to allow the app's loopback WebView origin rather than recommending wildcard CORS.
- The model weights and runtime are not embedded; model compatibility, RAM, storage and device thermal limits still need to be checked on the target phone.

## Validation status
- The Node Gateway unit tests and bundled source regression scripts pass in the available environment. Static checks also verify the native Android Keystore/AES-GCM storage path.
- Android Gradle build/APK installation, Firebase live sign-in, hosted API requests, and on-device llama.cpp inference have not been verified in this environment. Run the repository GitHub Actions workflow for the actual Android build.
