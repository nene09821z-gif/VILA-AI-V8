'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseAllowedOrigins, assertProductionSecurity, classifyRequestError } = require('../src/security');

test('CORS defaults are permissive only outside production', () => {
  assert.deepEqual(parseAllowedOrigins(undefined, 'development'), ['*']);
  assert.deepEqual(parseAllowedOrigins(undefined, 'production'), []);
  assert.deepEqual(parseAllowedOrigins(' https://app.example, ,https://admin.example ', 'production'), [
    'https://app.example', 'https://admin.example'
  ]);
});

test('production refuses auth-off and wildcard CORS configurations', () => {
  assert.throws(() => assertProductionSecurity({ nodeEnv: 'production', authMode: 'off', allowedOrigins: ['https://app.example'] }), /AUTH_MODE=off/);
  assert.throws(() => assertProductionSecurity({ nodeEnv: 'production', authMode: 'firebase', allowedOrigins: ['*'] }), /CORS_ORIGINS/);
  assert.doesNotThrow(() => assertProductionSecurity({ nodeEnv: 'production', authMode: 'firebase', allowedOrigins: ['https://app.example'] }));
  assert.doesNotThrow(() => assertProductionSecurity({ nodeEnv: 'development', authMode: 'off', allowedOrigins: ['*'] }));
});

test('request errors map to useful HTTP status codes', () => {
  assert.deepEqual(classifyRequestError(Object.assign(new SyntaxError('bad JSON'), { body: '{' })), {
    status: 400, code: 'invalid_json', message: 'JSON gửi lên không hợp lệ.'
  });
  assert.equal(classifyRequestError({ type: 'entity.too.large', status: 413 }).status, 413);
  assert.equal(classifyRequestError({ type: 'request.aborted' }).status, 400);
  assert.equal(classifyRequestError(new Error('unexpected')).status, 500);
});
