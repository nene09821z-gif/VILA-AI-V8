'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  createTeamPlan, selectStagesWithinBudget, estimateComplexity, parseCriticResult,
  dedupeCitations, formatCitationBlock, buildStageSystemPrompt, teamEnginePreference, stripImagePayloads
} = require('../src/teams');

const msg = text => [{ role: 'user', content: text }];

test('team router keeps trivial greeting as a single low-latency call, even in deep UI mode', () => {
  const plan = createTeamPlan({ messages: msg('Xin chào'), task: 'general', reasoningLevel: 'high', teamMode: 'deep' });
  assert.equal(plan.mode, 'single');
  assert.equal(plan.reason, 'simple_prompt_no_orchestration');
});

test('complex code task dynamically allocates coder, critic, and synthesizer teams', () => {
  const plan = createTeamPlan({
    messages: msg('Hãy debug và refactor kiến trúc dự án Android, tìm nguyên nhân lỗi build, đánh giá bảo mật, sửa các tệp liên quan và đề xuất test kiểm chứng.'),
    task: 'coding', reasoningLevel: 'high', teamMode: 'deep'
  });
  assert.equal(plan.mode, 'deep');
  assert.deepEqual(plan.stages, ['coder', 'critic', 'synthesizer']);
});

test('web research allocates a researcher and preserves a synthesis stage', () => {
  const plan = createTeamPlan({
    messages: msg('Tìm kiếm và đối chiếu tài liệu chính thức mới nhất, giải thích sự khác nhau, dẫn nguồn và nêu các điểm chưa chắc chắn.'),
    task: 'research', reasoningLevel: 'high', teamMode: 'auto', webSearch: true
  });
  assert.equal(plan.mode, 'deep');
  assert.equal(plan.stages[0], 'researcher');
  assert.equal(plan.stages.at(-1), 'synthesizer');
  assert.ok(plan.stages.includes('critic'));
});

test('auto mode saves extra calls for simple prompts but allocates review for multi-part questions', () => {
  const simple = createTeamPlan({ messages: msg('2+2 bằng mấy?'), task: 'general', teamMode: 'auto' });
  const hard = createTeamPlan({ messages: msg('Phân tích sâu, so sánh ba kiến trúc, tìm rủi ro, kiểm chứng và đưa ra kế hoạch triển khai nhiều bước cho một Gateway AI.'), task: 'reasoning', teamMode: 'auto' });
  assert.equal(simple.mode, 'single');
  assert.notEqual(hard.mode, 'single');
});

test('image payload stays single-pass by default, while explicit deep mode uses one vision stage and text-only review stages', () => {
  const imageMessages = [{ role: 'user', content: [{ type: 'text', text: 'Mô tả hình này' }, { type: 'image_url', image_url: { url: 'data:image/png;base64,AAA' } }] }];
  const quick = createTeamPlan({ messages: imageMessages, task: 'multimodal', teamMode: 'auto' });
  assert.equal(quick.mode, 'single');
  const deep = createTeamPlan({ messages: imageMessages, task: 'multimodal', teamMode: 'deep' });
  assert.equal(deep.mode, 'deep');
  assert.deepEqual(deep.stages, ['vision_expert', 'domain_expert', 'critic', 'synthesizer']);
  const stripped = stripImagePayloads(imageMessages);
  assert.equal(stripped[0].content.some(part => part.type === 'image_url'), false);
  assert.equal(stripped[0].content[0].text, 'Mô tả hình này');
  const hugePlan = createTeamPlan({ messages: msg('x'.repeat(121000)), task: 'coding', teamMode: 'deep' });
  assert.equal(hugePlan.mode, 'single');
  assert.equal(hugePlan.reason, 'large_context_single_pass');
});

test('team stage cap keeps critic and synthesizer when the operator limits calls', () => {
  const selected = selectStagesWithinBudget(['researcher', 'vision_expert', 'domain_expert', 'critic', 'synthesizer'], 4);
  assert.deepEqual(selected, ['researcher', 'vision_expert', 'critic', 'synthesizer']);
  const low = selectStagesWithinBudget(['coder', 'critic', 'synthesizer'], 2);
  assert.deepEqual(low, ['coder', 'synthesizer']);
  const imageSearchLow = selectStagesWithinBudget(['researcher', 'vision_expert', 'domain_expert', 'critic', 'synthesizer'], 3);
  assert.deepEqual(imageSearchLow, ['researcher', 'vision_expert', 'synthesizer']);
});

test('critic parser accepts only recognized verdicts and fails uncertain on malformed JSON', () => {
  assert.equal(parseCriticResult('{"verdict":"ready","issues":[],"required_fixes":[],"confidence":"high"}').verdict, 'ready');
  const invalid = parseCriticResult('I think that is probably fine.');
  assert.equal(invalid.verdict, 'uncertain');
  assert.equal(invalid.parseOk, false);
});

test('citations only accept unique HTTP(S) URLs and format as safe Markdown references', () => {
  const citations = dedupeCitations([
    { title: 'Source A', url: 'https://example.com/a' },
    { title: 'Duplicate', url: 'https://example.com/a' },
    { title: 'Unsafe scheme', url: 'javascript:alert(1)' },
    { title: 'Credentials', url: 'https://user:pass@example.com/private' },
    { title: 'Source B', url: 'http://example.org/b' }
  ]);
  assert.equal(citations.length, 2);
  const block = formatCitationBlock(citations);
  assert.match(block, /https:\/\/example\.com\/a/);
  assert.match(block, /http:\/\/example\.org\/b/);
});

test('agent prompts forbid invented verification and do not ask to reveal private reasoning', () => {
  assert.match(buildStageSystemPrompt('researcher'), /không bịa URL/i);
  assert.match(buildStageSystemPrompt('coder'), /Không tuyên bố build hoặc test PASS/i);
  assert.match(buildStageSystemPrompt('critic'), /JSON/i);
  for (const stage of ['researcher', 'domain_expert', 'coder', 'critic', 'synthesizer']) {
    assert.match(buildStageSystemPrompt(stage), /Không tiết lộ|Không đưa ra chuỗi suy nghĩ|Không trình bày suy nghĩ/i);
  }
});

test('complexity estimator counts explicit web grounding and reasoning preference', () => {
  const base = estimateComplexity({ messages: msg('Phân tích thuật toán này'), task: 'reasoning' });
  const high = estimateComplexity({ messages: msg('Phân tích thuật toán này'), task: 'reasoning', reasoningLevel: 'high', webSearch: true });
  assert.ok(high.score > base.score);
});


test('each specialist team can use its own pinned provider and model engine', () => {
  const env = {
    VILA_TEAM_RESEARCHER_PROVIDER: 'gemini',
    VILA_TEAM_RESEARCHER_MODEL: 'gemini-search-model',
    VILA_TEAM_CODER_PROVIDER: 'openrouter',
    VILA_TEAM_CODER_MODEL: 'vendor/code-model',
    VILA_TEAM_CRITIC_PROVIDER: 'groq'
  };
  assert.deepEqual(teamEnginePreference('researcher', env), { provider: 'gemini', model: 'gemini-search-model', suffix: 'RESEARCHER' });
  assert.deepEqual(teamEnginePreference('coder', env), { provider: 'openrouter', model: 'vendor/code-model', suffix: 'CODER' });
  assert.equal(teamEnginePreference('critic', env).provider, 'groq');
  assert.equal(teamEnginePreference('synthesizer', env).provider, 'auto');
});

test('per-team provider preference is normalized but model ID remains exact', () => {
  const config = teamEnginePreference('domain_expert', { VILA_TEAM_EXPERT_PROVIDER: ' GEMINI ', VILA_TEAM_EXPERT_MODEL: 'gemini-2.5-flash' });
  assert.equal(config.provider, 'gemini');
  assert.equal(config.model, 'gemini-2.5-flash');
});
