'use strict';

/**
 * CORS defaults are permissive only in local development. Production must list
 * trusted browser origins explicitly; an omitted list denies cross-origin web
 * requests while still allowing non-browser clients that send no Origin header.
 */
function parseAllowedOrigins(raw, nodeEnv = 'development') {
  const fallback = String(nodeEnv).toLowerCase() === 'production' ? '' : '*';
  return String(raw == null ? fallback : raw)
    .split(',')
    .map(value => value.trim())
    .filter(Boolean);
}

function assertProductionSecurity({ nodeEnv = 'development', authMode = 'off', allowedOrigins = [] } = {}) {
  if (String(nodeEnv).toLowerCase() !== 'production') return;
  if (String(authMode).toLowerCase() === 'off') {
    throw new Error('Security configuration refused: AUTH_MODE=off is prohibited in production.');
  }
  if (!Array.isArray(allowedOrigins) || allowedOrigins.includes('*')) {
    throw new Error('Security configuration refused: production CORS_ORIGINS must list trusted origins and must not contain *.');
  }
}

function classifyRequestError(error) {
  if (error instanceof SyntaxError && error && 'body' in error) {
    return { status: 400, code: 'invalid_json', message: 'JSON gửi lên không hợp lệ.' };
  }
  if (error?.type === 'entity.too.large' || Number(error?.status) === 413) {
    return { status: 413, code: 'payload_too_large', message: 'Nội dung yêu cầu vượt giới hạn cho phép (20 MB).' };
  }
  if (error?.type === 'request.aborted') {
    return { status: 400, code: 'request_aborted', message: 'Yêu cầu bị ngắt trước khi gửi đủ dữ liệu.' };
  }
  if (String(error?.message || '').includes('Origin không được phép')) {
    return { status: 403, code: 'origin_not_allowed', message: String(error.message) };
  }
  return { status: 500, code: 'internal_error', message: 'Lỗi backend không mong đợi.' };
}

module.exports = { parseAllowedOrigins, assertProductionSecurity, classifyRequestError };
