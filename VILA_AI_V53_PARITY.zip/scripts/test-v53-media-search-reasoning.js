'use strict';
// V53 behaviour tests: extracts the real helper functions from the shipped sources and executes them.
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assets = path.join(__dirname, '..', 'app', 'src', 'main', 'assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const extras = fs.readFileSync(path.join(assets, 'vila-extras.js'), 'utf8');

function grab(src, startMarker) {
  const i = src.indexOf(startMarker); assert.ok(i >= 0, 'missing ' + startMarker);
  let j = src.indexOf('{', i), depth = 0;
  for (let k = j; k < src.length; k++) { if (src[k] === '{') depth++; else if (src[k] === '}' && --depth === 0) return src.slice(i, k + 1); }
  throw new Error('unbalanced ' + startMarker);
}
const ctx = vm.createContext({ TextEncoder, TextDecoder, Uint8Array, window: {} });
vm.runInContext([
  grab(html, 'function vilaAddInlineCitations'),
  grab(html, 'function vilaInferImageAspect'),
  grab(html, 'function vilaIsImageFollowUpEdit'),
  grab(extras, 'function parseVideoOptions')
].join('\n'), ctx);

// Inline citations use UTF-8 byte offsets (Vietnamese text has multi-byte chars).
const text = 'Hà Nội là thủ đô. Đây là câu thứ hai.';
const end = Buffer.byteLength('Hà Nội là thủ đô.');
const sources = [{ uri: 'https://a.example/x', title: 'A' }, { uri: 'https://b.example/y', title: 'B' }];
const out = ctx.vilaAddInlineCitations(text, [{ segment: { endIndex: end }, groundingChunkIndices: [0, 1] }], sources, new Map([[0, 0], [1, 1]]));
assert.strictEqual(out, 'Hà Nội là thủ đô. [[1]](https://a.example/x)[[2]](https://b.example/y) Đây là câu thứ hai.');
assert.strictEqual(ctx.vilaAddInlineCitations(text, [{ segment: { endIndex: 9999 }, groundingChunkIndices: [0] }], sources, new Map([[0, 0]])), text, 'out-of-range support is ignored');

// Image aspect + follow-up edit detection.
assert.strictEqual(ctx.vilaInferImageAspect('vẽ poster dọc cho tiktok'), '9:16');
assert.strictEqual(ctx.vilaInferImageAspect('tạo logo vuông'), '1:1');
assert.strictEqual(ctx.vilaInferImageAspect('tạo ảnh 3:2 hoàng hôn'), '3:2');
assert.strictEqual(ctx.vilaInferImageAspect('vẽ con mèo'), '');
assert.strictEqual(ctx.vilaIsImageFollowUpEdit('đổi nền thành màu xanh'), true);
assert.strictEqual(ctx.vilaIsImageFollowUpEdit('make the background darker'), true);
assert.strictEqual(ctx.vilaIsImageFollowUpEdit('Thủ đô của Pháp là gì?'), false);

// Video options.
const v = (t, img) => ctx.parseVideoOptions(t, img);
assert.deepStrictEqual({ ...v('video dọc cho tiktok 4 giây') }, { aspectRatio: '9:16', durationSeconds: 4, resolution: '720p' });
assert.deepStrictEqual({ ...v('cảnh biển 1080p 4 giây') }, { aspectRatio: '16:9', durationSeconds: 8, resolution: '1080p' });
assert.strictEqual(v('mèo chạy 6s', true).durationSeconds, 8, 'image-to-video forces 8s');

// Wiring checks.
assert.ok(html.includes('candidate?.groundingMetadata'), 'grounding metadata must be read from the candidate');
assert.ok(html.includes('includeThoughts:true') && html.includes('filter(part=>!part?.thought)'), 'thought summaries requested and kept out of the answer');
assert.ok(html.includes('url_context'), 'url_context tool enabled for pasted links');
assert.ok(extras.includes('videoFallbackModel') && fs.readFileSync(path.join(assets, 'endpoints.js'), 'utf8').includes('videoFallbackModel'));
console.log('V53 media/search/reasoning tests passed');
