# VILA AI V52.0.0 — Source audit and test report

Audit date: 11 October 2026  
Artifact type: source project ZIP; not an APK/AAB and not a production deployment.

## Changes in this build

- Android app, Gateway package and server identify as `52.0.0`; Android `versionCode` is `60`, `targetSdk` is `36`.
- Added a backend multi-team orchestration pipeline: dynamic task/complexity routing; researcher, domain expert, coder, vision expert, critic and synthesizer roles; separate provider/model pinning per team; bounded failover/deadlines; structured critic result; conservative source handling; and explicit uncertainty/fallback notices.
- Simple prompts retain the one-call route to reduce latency and usage. Deep mode can make multiple upstream calls and may increase latency, token consumption, provider charges and quota consumption.
- For explicit deep-mode image requests, the original image goes to the vision stage once, while later stages receive text-only observations.
- Added per-user weighted request limits, global in-process concurrency caps, health/readiness endpoints, graceful shutdown, container health checking and restart baseline.
- Updated configured Gemini text/image/video/TTS IDs against official model docs/release notes reviewed 11 October 2026. Provider entitlements, quotas, regional access and pricing still require live tests.
- Updated V52 technical map, changelog, privacy template and Google Play release checklist. `compose.yaml` default team-call budget is synchronized to five.

## Automated checks run locally

- `node --test server/test/*.test.js`: **23 passed, 0 failed**.
- Existing regression scripts: **14 of 14 passed** (`scripts/smoke-test-v32.js` and regression scripts through `scripts/test-v52-ai-teams.js`). Some scripts contain multiple assertions/test cases.
- `node --check` on JavaScript source under `server/src` and `app/src/main/assets`: passed.
- Inline JavaScript in `app/src/main/assets/index.html`: **9 script blocks passed syntax checking**.
- HTML ID scan: **197 IDs, no duplicates**.
- Android `AndroidManifest.xml`: parses successfully.
- `server/package.json`, `app/google-services.json`, and the historical QA JSON parse successfully.
- `compose.yaml` and `.github/workflows/main.yml` parse as YAML.
- Archive integrity is checked after packaging.

These tests confirm source-level software behavior only. They do not prove factual accuracy of AI answers, live access to provider APIs, billing/quota availability, Firebase sign-in, browser search quality, or successful operation on a physical phone.

## Important limits

- **No Android build was performed here.** Java is available, but Gradle/Android SDK/Gradle wrapper are not available in this environment. GitHub Actions must complete `assembleDebug`, `assembleRelease`, unit tests and lint before calling this build verified.
- **No live production APIs or Firebase account were tested.** Set valid provider keys and Firebase Admin credentials in a secret manager on the actual server, then verify with real requests.
- **No 24/7 deployment or uptime guarantee.** Docker Compose provides a restart and health-check baseline only. An always-on host, TLS reverse proxy, monitoring/alerts, quota controls and operational ownership are required. Current rate/concurrency/circuit metrics are in-memory and per process; multi-replica deployments need shared coordination/storage.
- **No persistent RAG/vector retrieval store is included yet**, and no calibrated factual-accuracy benchmark has been completed. The critic/team flow can catch some mistakes but cannot eliminate hallucinations.
- **The “20 technologies” list describes integrated engineering techniques/capabilities, not 20 newly trained models.** Team engines are provider/model configurations, not dedicated weights hosted inside the APK.
- Deep mode only works when the app is using this deployed V52 Gateway and a supported provider is configured. If only direct provider mode is enabled, the server-side team workflow is not running.
- The privacy policy/account deletion pages are templates. Replace placeholders, host them on HTTPS, and verify real deletion semantics before Google Play submission.
- The included debug keystore is for development/testing CI only. Never use it as the Play Store release key.

## Next release gates

1. Run the GitHub Actions workflow and archive its build/test logs.
2. Install the APK/AAB build on both an older/low-memory and a current Android device; test sign-in, search citations, deep-team routing, images, network failures, cancellation and account deletion.
3. Deploy the Gateway behind HTTPS with Firebase authentication, private secrets, strict origin policy, per-provider spending alerts and abuse monitoring.
4. Build a Vietnamese quality benchmark with reference answers, source expectations and adversarial prompt-injection examples; measure factual correctness/citation precision before enabling broad public access.
5. Add persistent RAG (document ingestion, chunking, embedding store, hybrid retrieval and reranking) if users need reliable long-term retrieval across files/knowledge bases.
6. Fill and host privacy/account-deletion pages; complete Play Console Data safety and other release declarations; obtain Play review.

## Official model documentation reviewed

- Model catalog/release notes: https://ai.google.dev/gemini-api/docs/models and https://ai.google.dev/gemini-api/docs/changelog
- Nano Banana image model: https://ai.google.dev/gemini-api/docs/image-generation
- Veo 3.1 model: https://ai.google.dev/gemini-api/docs/models/veo-3.1-generate-preview
- Gemini 3.8 Flash TTS: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash-tts
- Google Play target API requirement: https://support.google.com/googleplay/android-developer/answer/11926878?hl=en
