# VILA AI V50 — Gateway UI and Live Model Discovery

## Layout fixes

- Give the Gateway modal a viewport-based height on Android WebView and let the inner content pane use `flex: 1 1 0%` with independent vertical scrolling. Previously, the shell hid overflow while the content child could retain its intrinsic content height, making the lower section appear cut off.
- Remove paint containment and restrictive height/overflow behavior from the animated thinking/status panel, and allow long provider/model/status labels to wrap on narrow screens.
- Keep the chat message area and composer as separate flex children on small screens so the status and input panels do not fight for the same height.

## Current model discovery

- Query live provider model endpoints on the server. Gemini pagination is followed via `nextPageToken`, for up to 10 pages. OpenAI-compatible providers are queried through their `/models` endpoints.
- Preserve provider ID, model name/ID, context length, modalities, owner, and explicit zero-price metadata when the provider publishes them. Filter inactive records and common non-chat models; never report a successful model scan if the upstream API fails.
- Cache successful live catalog reads for 30 minutes. If an auto-routed provider’s configured model is no longer in that fresh catalog, choose a task-relevant model ID that the provider actually listed instead of repeatedly sending traffic to the stale ID.
- Add a searchable catalogue and explicit “Dùng” action to pin a selected `provider:model-id` for chat via Gateway. “Tự động” clears the pin and returns to server routing. Selection is only enabled for models fetched from the live Gateway server catalogue.
- Synchronize app/server/package/update metadata to `50.0.0`, Android `versionCode 57`.

## Validation boundary

Static/source tests validate the layout rules, route contract, pagination handling, model selection wiring, and synchronized versions. Live model lists still require a deployed Gateway and valid provider keys. Availability, account access, rate limits and billing remain controlled by each provider.
