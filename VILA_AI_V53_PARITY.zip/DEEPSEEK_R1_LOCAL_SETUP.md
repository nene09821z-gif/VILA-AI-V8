# VILA AI V51 — DeepSeek-R1 Local connector

This update adds a **DeepSeek-R1 Local** provider preset to VILA's existing OpenAI-compatible API client.

## Important limitation
This ZIP does **not** bundle the DeepSeek-R1 7B weights or a native inference runtime. The Android app is a WebView client; the model must be downloaded and run separately on the same phone with a compatible local server. The preset connects VILA to that server.

DeepSeek-R1 7B Q4 GGUF files are several GB and need substantial RAM in addition to the model file. A phone with limited RAM (including many entry-level devices) may be unable to run it reliably. Do not assume it will work on every Android phone.

## Termux + llama.cpp outline
1. Install/build a compatible `llama.cpp` with `llama-server` in Termux.
2. Download a trusted DeepSeek-R1 Distill 7B GGUF quantization only if the phone has enough free storage and RAM.
3. Start the local server with a matching alias, for example:

   ```sh
   ./llama-server -m ~/models/DeepSeek-R1-7B-Q4_K_M.gguf --host 127.0.0.1 --port 8080 --alias deepseek-r1-7b --ctx-size 2048 --n-gpu-layers 0 --cors-allow-origin 'http://127.0.0.1:18787'
   ```

   Adjust the model path to the actual downloaded file and confirm the options supported by your llama.cpp build. Keep the server bound to `127.0.0.1`; do not expose an unauthenticated model server to the public internet.

4. In VILA, open **Cài đặt → Nhà cung cấp → DeepSeek-R1 Local**. Base URL is `http://127.0.0.1:8080/v1`; select `DeepSeek-R1 7B (local GGUF)`. Leave API key blank if the server does not require one.
5. If the model does not appear or chat fails, check `http://127.0.0.1:8080/health` and `http://127.0.0.1:8080/v1/models` in a browser on the same phone. Ensure the server supports CORS for the WebView and the model ID exactly matches the server's listed ID.

This is a local-server connector, not a one-tap model installer. Model loading can take time and heat/battery use may be high.
