# VILA AI 51.1.0 — Endpoint Discovery & Play Store audit

## Endpoint recognition
- Added user-triggered discovery for a bounded list of common loopback AI endpoints: llama.cpp/OpenAI-compatible, Ollama, LM Studio, vLLM, and LocalAI.
- Discovery concurrency is capped at three; each model-list probe has a 4-second timeout. No prompt or API key is sent by the discovery step.
- Supports the OpenAI-compatible `/v1/models` catalog and Ollama's `/api/tags` fallback.
- Found endpoints appear with the endpoint URL, model count and latency; user must select one to apply it.
- Clarifies in UI that this does not scan Internet addresses or other LAN devices, and warns against sending keys/prompts over remote HTTP. CORS/WebView restrictions can produce false negatives.
- Renamed quick diagnostic to “Kiểm tra API đã cấu hình” so it is not confused with arbitrary network-port scanning.

## Account and privacy UX
- Added an in-app privacy-policy modal that opens `app/src/main/assets/privacy-policy.html`.
- Added account deletion through Firebase Authentication and clearing managed Android-stored secrets plus local app storage on confirmed successful deletion.
- Added root-level templates `privacy-policy.html` and `account-deletion.html` for eventual public HTTPS hosting.
- Both legal/operational pages intentionally contain explicit placeholders and draft notices. Real operator name, contact email, external deletion URL and processing time must be supplied and verified before Play submission.
- Added regression tests for the privacy/delete UI, Android deletion bridge, endpoint discovery and public-release guardrails.

## Verification status
- `node --test server/test/*.test.js`: 11/11 passed.
- Existing and new source regression scripts: all passed at last run.
- Nine inline JavaScript blocks passed `node --check`.
- Server JavaScript source syntax passed; `AndroidManifest.xml` parsed successfully.
- Android Gradle build, real-device sign-in/deletion, live provider endpoint tests, policy hosting and Play Console approval have not been proven by these source tests.
