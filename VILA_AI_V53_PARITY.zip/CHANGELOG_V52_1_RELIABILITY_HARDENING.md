# VILA AI Gateway V52.1.0 — Reliability hardening (process crash & memory leak fixes)

Context: the V52.0.0 audit report explicitly flagged that "no 24/7 deployment or uptime
guarantee" exists and that only a Docker restart/health-check baseline was in place. This
patch targets the two concrete, previously-unstable root causes behind that warning on the
server side; it does not touch provider logic, team orchestration behavior, prompts, or the
Android app's UI/login flow.

## Fixed

1. **A single unexpected error could crash the whole Gateway process.**
   `/v1/chat/completions`, `/v1/gateway/check` and `/v1/models` were `async` Express
   handlers with no wrapper. In Express 4, an error thrown (or a promise rejected) inside an
   `async` handler does **not** reach the error-handling middleware automatically — it
   becomes an unhandled promise rejection, which crashes the Node process by default and
   drops every other in-flight request/user, not just the one that triggered it.
   - Added an `asyncHandler(fn)` wrapper and applied it to all three routes so every error
     now flows into the existing `app.use((error, req, res, next) => ...)` handler and is
     answered as a normal JSON error response instead of taking the process down.
   - Added `process.on('unhandledRejection', ...)` and `process.on('uncaughtException', ...)`
     as a last-resort safety net for anything outside a route handler (timers, stream
     events, library callbacks). Both log a structured, metadata-only line (no prompts, no
     keys) and then drain connections through the existing `gracefulShutdown()` path instead
     of dying instantly, so the container's restart/health-check baseline in `compose.yaml`
     brings back a clean process instead of an abrupt, unlogged outage.

2. **`metrics.byUser` grew forever and was never freed.**
   It was a plain object keyed by Firebase `uid`; every unique user who ever called the
   Gateway added a permanent entry for the lifetime of the process — a genuine unbounded
   memory leak on a server meant to run continuously with a growing user base.
   - Converted it to a `Map` plus a small LRU-style cap (`MAX_TRACKED_USERS`, default
     20,000, configurable via env). Touching a user's entry refreshes its recency; once the
     map exceeds the cap, the least-recently-touched entry is evicted. All existing read/
     write call sites (`/v1/chat/completions` both the team and single-provider paths, and
     `/v1/gateway/usage`) were updated to the new `getUserMetrics(uid)` helper /
     `metrics.byUser.get(uid)` accessor; behavior and response shape are unchanged.

## Verified

- `node --test server/test/*.test.js`: **23/23 passed, unchanged** (these modules —
  `engine.js`, `reliability.js`, `security.js`, `teams.js` — were not modified).
- `node --check` on `server/src/server.js`: passed.
- `server/package.json` parses as valid JSON after the version bump.
- Added isolated logic tests (not part of the committed suite, run manually in this
  sandbox because npm/network access was unavailable here) replicating `getUserMetrics`
  and `asyncHandler` line-for-line: confirmed (a) per-user counters still accumulate
  correctly, (b) the tracked-user map never exceeds its cap and evicts the correct
  least-recently-touched entry, (c) a thrown/rejected error inside a wrapped handler
  reaches `next(err)` instead of escaping as an unhandled rejection.
- **Not verified here** (same limits as the V52.0.0 audit): no real `npm install` / Gradle
  build was run in this environment (no network access), and no live load test against a
  running process was performed to observe `uncaughtException` recovery end-to-end. Run the
  existing GitHub Actions workflow and a short soak test before shipping.

## Versioning

- Android `versionCode` 60 → 61, `versionName` "52.0.0" → "52.1.0".
- Server `package.json` and `APP_VERSION` → "52.1.0".
- `compose.yaml` image tag → `vila-ai-gateway:52.1.0`.

## Still open (carried over from the V52.0.0 audit, unchanged by this patch)

- In-memory rate limit / concurrency / circuit-breaker state is per-process; a
  multi-replica deployment still needs a shared store (e.g. Redis) for these to be
  coordinated across instances.
- No persistent RAG/vector retrieval store.
- No calibrated factual-accuracy benchmark for the critic/synthesizer flow.
- Privacy policy / account-deletion pages are still templates.
- No real Android build or on-device test was performed in this environment.
