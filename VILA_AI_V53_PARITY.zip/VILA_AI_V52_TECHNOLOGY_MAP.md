# VILA AI V52 — 20 integrated AI-engine techniques and honest capability map

This document counts **engineering techniques and engine behaviours**, not 20 pretrained models, 20 newly trained AI models, or 20 vendors. Actual answer quality still depends on the configured upstream model, provider tools/quotas, source quality, and workload. The V52 changes add orchestration and reliability around those engines; they do not train a new foundation model.

## The 20 techniques integrated in V52

1. **Task classification** — classify general, research, coding, reasoning and multimodal tasks before routing.
2. **Dynamic complexity scoring** — estimate difficulty from request shape, length, task class, explicit multi-step markers and search preference.
3. **Adaptive compute routing** — keep simple prompts on one call; allocate a review or deep workflow for harder tasks.
4. **Specialist prompt engines** — separate researcher, general expert, coder, vision/multimodal text, critic and synthesizer instructions.
5. **Per-team provider pinning** — configure a distinct provider for each specialist without hardcoding provider secrets in the app.
6. **Per-team model pinning** — select a provider-specific model ID for each team, with adaptive routing as the default.
7. **Native provider web-search tools** — use supported search/grounding tool interfaces instead of asking a model to invent web results.
8. **Structured citation extraction** — accept source links from provider grounding/citation metadata; a plain URL generated in prose is not proof of retrieval.
9. **Independent-review preference** — prefer a provider not yet used for the critic when an alternative is configured, and disclose when it shares a provider with earlier stages.
10. **Structured critic output** — require a small JSON verdict (`ready`, `revise`, `uncertain`) and conservatively treat malformed output as uncertain.
11. **Dynamic repair synthesis** — use critic findings to trigger a final correction pass when needed and when the call budget allows.
12. **Explicit uncertainty notes** — flag missing source evidence, an uncertain critic, shared-provider review, or failed synthesis instead of claiming certainty.
13. **Context trimming** — bound team input and retain a limited recent conversation window to control token growth.
14. **Multimodal payload control** — images remain single-pass by default. When deep mode is explicitly requested, the original image is sent only to the vision specialist; later text teams receive its written findings and not the raw image. Oversized non-image contexts remain single-pass.
15. **Provider circuit breaker** — temporarily avoid repeatedly failing providers and allow controlled recovery probes.
16. **Bounded failover/retries** — try configured provider alternatives within a defined attempt count instead of unbounded retry loops.
17. **Deadline-aware HTTP timeouts** — constrain each team-stage request to the remaining workflow deadline.
18. **Weighted usage limiting** — account for deep/reviewed requests as multiple rate-limit units because they create multiple upstream calls.
19. **Per-user and global concurrency caps** — prevent a single account or burst from consuming all configured request slots in one process.
20. **Liveness/readiness, health metrics, graceful shutdown and container recovery** — expose operational health endpoints, request IDs, metadata-only logs, and a Docker Compose restart/health-check baseline.

## Team and engine layout

| Team | Role | Env provider/model suffix |
|---|---|---|
| Research/search | Finds source-backed evidence through supported provider search tools | `RESEARCHER` |
| General expert | Solves the core task and checks assumptions | `EXPERT` |
| Coding/debug | Diagnoses and writes code with a test-oriented approach | `CODER` |
| Vision/multimodal | In explicit deep mode, sees the original image once and passes text-only observations to later stages | `VISION` |
| Critic/verifier | Reviews correctness, omissions, logic and unsupported claims | `CRITIC` |
| Final synthesizer | Applies review findings and creates the final answer | `SYNTHESIZER` |

Each team can be pinned with `VILA_TEAM_<TEAM>_PROVIDER` and `VILA_TEAM_<TEAM>_MODEL`. Supported provider IDs are `gemini`, `openrouter`, `groq`, `cerebras`, `custom`. Set the provider and model to `auto` for adaptive routing. A configured model ID must really be enabled for the selected account/provider; config cannot make an unsupported model available.

Deep/research workflows usually make 3–4 upstream calls, with a bounded extra repair pass possible up to the configured limit. This raises latency, token use and potential API charges. Configure a conservative call budget and provider spending alerts before opening the Gateway to public users.

## Important missing work / not claimed as implemented

- **No persistent RAG/vector database yet.** There is no durable chunking, embedding store, hybrid retrieval and reranking system across user files or a continuously updated knowledge base.
- **No benchmark proving factual accuracy.** Passing source/unit tests checks software behaviour, not whether an answer is factually correct. Build a versioned evaluation set of real Vietnamese prompts, reference answers, expected citations and adversarial cases before judging quality.
- **No public Gateway deployment is bundled.** Docker Compose is a starting point only. Continuous service requires a persistent host, HTTPS, Firebase Admin and provider secrets, alerting, backup/restore, abuse controls and a tested rollout/rollback process.
- **No guaranteed 24/7 uptime.** A restart policy can recover from some process failures; outages, quota exhaustion, host failures, network faults and provider downtime still occur. Current rate/circuit metrics are in-memory and per-process; multi-replica use needs shared storage/coordination.
- **No guarantee that provider grounding always returns URLs.** A provider/model may not support search, may fail, or may return insufficient sources; VILA should surface that limitation.
- **No automatic training/model installation.** The Gateway routes to upstream APIs and optionally to user-operated local servers. It does not download or train 20 models.
- **No Android APK or real-device pass in this source artifact.** GitHub Actions and hands-on device testing remain required.

## Official model catalog checked on 11 October 2026

The Android default endpoints are configured as `gemini-3.8-flash` for text, `gemini-nano-banana-2.1` for image generation, `veo-3.1-generate-preview` for video, and `gemini-3.8-flash-tts` for speech. These identifiers are listed in current official Gemini API documentation/release notes at the time of this audit; access, quotas, regional availability and pricing still depend on the user/provider account. VILA must not imply an API is reachable until a live request succeeds.

- Gemini 3.8 Flash and model catalog: https://ai.google.dev/gemini-api/docs/models
- Nano Banana 2.1 image generation: https://ai.google.dev/gemini-api/docs/image-generation
- Veo 3.1 model ID: https://ai.google.dev/gemini-api/docs/models/veo-3.1-generate-preview
- Gemini 3.8 Flash TTS: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash-tts
- API release notes (including deprecations and replacements): https://ai.google.dev/gemini-api/docs/changelog

## External technical references

- Gemini API Search grounding and citation support: https://ai.google.dev/gemini-api/docs/google-search/
- Retrieval-augmented generation concepts (a future quality improvement, not yet a persistent VILA subsystem): https://cloud.google.com/use-cases/retrieval-augmented-generation
- OpenTelemetry JavaScript observability (a future addition; V52 currently uses built-in metadata counters and logs): https://opentelemetry.io/docs/languages/js/
- OWASP GenAI risks, including misinformation, prompt injection and unbounded consumption: https://genai.owasp.org/initiatives/top-10-for-llm-and-genai/
