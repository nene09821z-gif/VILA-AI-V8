# VILA AI V52.0.0 — Multi-team reasoning and Gateway hardening

## App and backend identity
- Android `versionName` is `52.0.0`, `versionCode` is `60`.
- Node Gateway `package.json` and `APP_VERSION` are `52.0.0`.
- Android target SDK is 36. APK build still needs CI and device verification.

## AI response pipeline
- Added adaptive task/complexity planning and one-call bypass for trivial prompts, image payloads, and oversized context.
- Added researcher, general-expert, coder, vision-text, critic and final-synthesis stages.
- Critic output is parsed as JSON; invalid format becomes `uncertain` instead of a false positive.
- Search sources are accepted only from structured provider grounding/citation metadata; ordinary model-authored URLs are not treated as proof of retrieval.
- Added bounded correction synthesis and explicit caveats when sources are missing, the critic is uncertain, reviewers share a provider, synthesis fails, or an operator call cap skips a stage.
- For explicit deep-mode image questions, sends the image once to the vision specialist and passes text-only observations to subsequent expert/review/synthesis stages; normal image questions remain single-pass.
- Added independent-provider preference for the critic when available.
- Added environment configuration to pin a provider/model per team, with automatic ranked fallback when a preferred engine is unavailable.

## Reliability and operations
- Added deadline-aware timeout on each team HTTP call, call budget, weighted per-user rate limiting and global concurrency cap.
- Added or retained circuit breaking, bounded fallback, request-ID and metadata-only logs.
- Added `/health/live` and `/health/ready`, graceful SIGTERM/SIGINT shutdown and a Compose restart/health-check baseline.
- Added status view of team engine preferences and aggregate in-memory counters.

## Privacy and release quality
- The UI warns that deep mode may send conversation context to multiple configured providers and may increase API latency/usage/cost.
- Privacy policy template explains multi-provider processing, but remains a draft until customized/hosted and matched to actual production settings.
- No provider secrets belong in APK source. Use a secret manager for production Gateway keys and Firebase Admin credentials.

## What has not been proved
- No factual-accuracy benchmark has been completed; multi-agent review reduces some errors but cannot eliminate hallucinations.
- No persistent cross-file vector RAG is included yet.
- No production Gateway deployment, 24/7 uptime, hosted HTTPS pages, end-to-end account deletion, live provider search, Firebase real login or Android physical-device testing is claimed by source tests.
- The ZIP is source code, not an APK.

## Model identifiers reviewed
- Checked the configured Gemini text/image/video/TTS identifiers against the official model catalog and release notes on 11 October 2026. Provider entitlement, quota, pricing and availability still require live validation.
