# VILA AI V53.0.0 — Image, web, video, reasoning upgrades

## Bug fixed
- **Web search sources never appeared.** `requestGeminiWebSearch` read `data.groundingMetadata`, but Gemini returns it at `candidates[0].groundingMetadata`. Fixed (the server gateway already read it correctly).

## Web browsing
- Inline citation markers `[1][2]` placed after grounded sentences (UTF-8 byte offsets handled for Vietnamese text).
- Shows the queries Gemini searched ("🔎 Đã tìm: …").
- Links pasted by the user are opened with Gemini `url_context` alongside Google Search.

## Reasoning
- Gemini 3.x / 2.5 now request `includeThoughts`; the thought summary appears in the collapsible "Tóm tắt suy luận" panel and is kept out of the answer text. Respects the "show reasoning summary" setting; skipped on low effort.

## Image generation
- Aspect ratio inferred from the prompt (dọc / vuông / ngang / 3:2 …).
- Follow-up edits: right after an image, "đổi nền thành màu xanh" edits that image (kept aspect ratio) instead of making a new one.
- "Tạo lại" (regenerate) button on every generated image.

## Video (Veo)
- Prompt options: video dọc (9:16), 4/6/8 seconds, 1080p (forces 8s; image-to-video is 8s).
- Falls back to `veo-3.1-fast-generate-preview` if the main model is unavailable (404/403/400).
- Polling survives up to 4 transient network/429/5xx errors; status shows elapsed time.

## Housekeeping
- Version bumped to 53.0.0 (versionCode 63). Seven older tests pinned stale version numbers (they failed on the V52.2 zip); updated. Added `scripts/test-v53-media-search-reasoning.js`.

## Not verified
No live Gemini/Veo calls were possible here (no API key, restricted network). Logic is unit-tested; field names follow the Gemini API docs but should be smoke-tested on a device with a real key. Model availability (`veo-3.1-fast-generate-preview`) depends on the account.
