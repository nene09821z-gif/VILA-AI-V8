# VILA AI 51.1.0 — technical audit report

Date: 11 October 2026

## Summary

This source update improves endpoint discovery, security disclosures, and account/privacy controls. It remains a **source ZIP**, not a verified APK or a Play-approved release.

## Changes delivered

1. **AI endpoint discovery:** user-triggered discovery of five known loopback endpoints commonly used by llama.cpp, Ollama, LM Studio, vLLM, and LocalAI. It checks a model catalog, includes Ollama `/api/tags` fallback, gives a latency/model count, and requires the user to select an endpoint. The check is bounded to three concurrent requests with a 4-second timeout; it does not probe arbitrary ports, Internet addresses, or other LAN devices.
2. **Provider diagnostics clarity:** quick scan wording refers to configured APIs, deep-scan copy warns that a test prompt can consume quota, and Base URL help warns that remote HTTP does not encrypt prompts/keys.
3. **Account and privacy UX:** in-app privacy-policy entry, Firebase account deletion bridge, deletion of managed local storage/secrets after successful Firebase deletion, and public-host templates for privacy and external deletion requests.
4. **Security/release disclosure:** policy templates clearly mark missing owner/contact/domain information. Play-readiness checklist identifies legal/hosting/Data safety/signing/real-device work still required.
5. **Regression coverage:** automated source tests cover endpoint discovery, keyless local model catalog, privacy UI and native delete bridge; CI workflow runs the new checks.

## Test results run on source

- Node Gateway unit tests: **11/11 passed**.
- Existing and added `scripts/*.js` regression checks: **13 scripts passed**.
- Embedded JavaScript: **9 inline script blocks passed `node --check`**.
- App JavaScript assets: **5 files passed `node --check`**.
- Gateway JavaScript syntax checks: `server.js`, `engine.js`, and `reliability.js` passed.
- `AndroidManifest.xml` parsed successfully; CI structural check found no duplicate HTML IDs and required app functions were present.
- These are source-level results only; they do not prove Android compilation, live Firebase auth, upstream provider availability, account deletion on a real device, or Google Play acceptance.

## Release blockers

- `privacy-policy.html` is a draft with placeholders for the real operator name, contact address, public URL and facts that must be confirmed against the shipping build.
- `account-deletion.html` is a draft. Replace the contact and response-time placeholders; deploy it to a public HTTPS URL with a working, monitored request path; enter that URL in Play Console.
- Audit and test all account-related data held in Firebase/other server components so account deletion removes all developer-controlled user data, not merely the Firebase Authentication record and managed local data.
- Complete the Play Console Data safety and account-deletion sections accurately against all SDKs, enabled permissions, third-party AI providers and the deployed Gateway.
- Build with `.github/workflows/main.yml`; install and test the generated APK on real Android devices; test OAuth/Firebase and all enabled provider/media flows.
- Configure a private persistent production signing keystore in GitHub Secrets. Do not distribute the debug-signed APK as the public release.

## Scope/limitations

“Recognize all gateways” is not literally possible for every Internet service because endpoints may be private, authenticated, blocked by CORS, or use incompatible APIs. This implementation checks providers already configured in VILA and a finite list of well-known AI servers on loopback. Users retain control over endpoint selection and actual provider API calls.
