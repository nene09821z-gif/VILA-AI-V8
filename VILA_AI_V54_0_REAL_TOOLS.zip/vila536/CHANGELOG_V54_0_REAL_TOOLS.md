# VILA AI V54.0.0 — Real Agent Tools

## New tools (server/src/tools)
- `vila_web_search` — Tavily / Brave / SearXNG when configured; keyless DuckDuckGo HTML fallback (best-effort).
- `vila_web_fetch` — SSRF-safe fetch: scheme/port allowlist, DNS check on every address, manual redirect re-validation, size/time caps, HTML→text. Output marked untrusted.
- `vila_run_code` — JavaScript (vm context with no host objects + Node permission model) and Python (audit hook + rlimits). OFF unless VILA_ENABLE_CODE_EXEC=true.
- `vila_memory_save/search/delete` — per-user persistent memory (BM25 search). Endpoints: GET /v1/memory, DELETE /v1/memory/:id.
- `vila_search_documents` — BM25 over user-uploaded text. Endpoints: GET/POST /v1/docs, DELETE /v1/docs/:id.
## Agent loop
- Extracted to `src/agent-loop.js` (unit-tested); default budget 8 tool calls (cap 12), hard round ceiling, forced final answer.
- Response carries `vilaAgent.trace`; UI shows which tools were used. System note warns the model that web content is untrusted.
## Fixes
- Client-supplied `_vilaForceFinal` is stripped.
- Update checker constant in index.html was stale (53.6.0); versions synced to 54.0.0 / code 69.
- Missing local SVG icons `robot`, `screwdriver-wrench` added.
- 7 outdated version-pinned test scripts updated: all 16 scripts and 61 server tests pass.
## V54.0.1 additions
- `pinnedFetch`: connects only to the IP that passed validation (DNS-rebinding window closed); TLS still verified against the hostname.
- Context compaction: old tool outputs are shortened when the transcript exceeds VILA_AGENT_CONTEXT_CHARS (default 120000).
- Per-user tool quota: VILA_TOOL_CALLS_PER_MIN (default 40).
## Known limits
- Code sandbox is defense-in-depth, not a security boundary. Use a container.
- Gemini adapter still excluded from Agent mode; Agent responses are non-streaming.
- Not verified here: live provider calls, Android build, `npm install` (registry unreachable in the test sandbox).

## V54.0.2 — Simple UI, knowledge panel, GitHub token removed
- **GitHub token removed** from UI, JS bridge and Android code; any token stored by older versions is wiped on startup.
- **Simple UI** (`vila-simple.css/js`, default on): one centered chat column, neutral palette, one rounded composer, minimal header (menu · model · new chat), trimmed side menu. Menu → "Chế độ giao diện" switches back to the full UI. All CSS is scoped to `html.vila-simple`.
- **Agent knowledge dialog**: upload txt/md/csv/json/pdf/docx, list/delete documents, view/delete Agent memory (uses /v1/docs and /v1/memory).
- Tests: scripts/test-v54-ui.js (16/16 → 17/17 scripts), 64 server tests.
- Verified in headless Chromium at 390x844 with the CDN blocked; the real Tailwind layer was not loaded in that check.
