# Kế hoạch cải tiến chức năng ViLa — ưu tiên theo rủi ro

## Đã thực hiện đến v3.40.0
- v3.39.0: sửa logic nhiệm vụ “Chuỗi nhiệm vụ” để chỉ tăng khi nhận thưởng từ nhiệm vụ khác nhau, không tự hoàn thành chính nó và giới hạn ở 5.
- v3.40.0: state machine bắt tay UCI cho Stockfish; tooltip trạng thái hiển thị thời gian khởi động thực; lưu ván schema v3 có checksum và kiểm tra snapshot trước khi replay; hỗ trợ phục hồi snapshot v2 cũ; đồng bộ metadata và version test.
- Thêm test hồi quy cho UCI handshake, record bị sửa/cũ/không hợp lệ và kiểm tra cú pháp toàn bộ source.

## Nên triển khai tiếp theo
1. **Engine health panel**: hiển thị engine đang dùng, tệp đã tải, WASM/ASM fallback, thời gian khởi tạo và nút kiểm tra engine. Không hiện “sẵn sàng” nếu chưa nhận UCI `uciok` và `readyok`.
2. **Lưu ván an toàn**: snapshot có phiên bản schema, PGN/FEN, đồng hồ, cài đặt màu và lịch sử nước; khôi phục phải replay PGN và so khớp FEN, nếu lỗi thì giữ bản cũ và báo người dùng.
3. **Phân tích có căn cứ**: gắn nhãn sai lầm theo chênh lệch điểm đánh giá sau khi chuẩn hóa góc nhìn Trắng/Đen; phân biệt “chưa phân tích” với “nước xấu”; hủy tác vụ cũ khi đổi ván.
4. **Luyện tập chống lặp**: lưu ID câu đố/độ khó/kết quả, ưu tiên đề chưa gặp; không coi đề tải về là hợp lệ trước khi replay toàn bộ lời giải bằng chess.js.
5. **Đấu trường công bằng**: lưu PGN từng ván, lịch sử Elo riêng từng bot, cúp chỉ trao sau khi đủ số ván; không ghi Elo dự đoán thành Elo đã đo.
6. **Hiệu năng Android**: đo frame/input delay trên thiết bị; giảm render toàn bàn khi chỉ đổi chọn quân; tạm dừng engine khi app vào nền; giới hạn bộ nhớ và thời gian tìm kiếm theo thiết bị.
7. **Khả năng truy cập**: vùng chạm tối thiểu 44 CSS px, nhãn đọc màn hình, tương phản và hỗ trợ giảm chuyển động.

## Quy tắc nghiệm thu
- Không đánh dấu test đạt khi phụ thuộc bị thiếu; chạy `npm install`, `npm run test:static`, `npm test`, `npm run build`, sau đó build Android qua GitHub Actions.
- Kiểm tra ZIP bằng `unzip -t`; xác nhận Stockfish binary thật trong bundle và kiểm tra UCI trên Android.
- Kiểm thử thủ công trên màn 360 CSS px và máy OPPO A17k: bắt đầu ván, kéo quân, phong cấp, nhập thành, hết giờ, undo/redo, resume, puzzle offline, phân tích, đổi màn hình dọc/ngang.
