/** Select a Stockfish profile conservatively for mobile WebViews. */
export function resolveEngineProfile(preference = 'auto', device = {}) {
  if (preference === 'full-single') return 'full-single';
  if (preference === 'lite-single') return 'lite-single';
  // Stockfish 10 (classical eval, pure asm.js) is an optional, lighter engine for fast mistake-finding.
  if (preference === 'sf10') return 'sf10';
  // Full NNUE is included by the Android workflow. Keep lower-memory phones on Lite,
  // but prefer the stronger Full build when the browser reports at least 2 GiB-class memory
  // and 4 logical cores. If Full is absent or fails to initialize, the caller falls back to Lite.
  const memoryGiB = Number(device.deviceMemory) || 0;
  const cores = Number(device.hardwareConcurrency) || 0;
  if (memoryGiB >= 2 && cores >= 4 && device.fullEngineAvailable !== false) return 'full-single';
  return 'lite-single';
}

/**
 * Initialization-only fallback chain. ASM-JS is slower, but does not depend on
 * WebAssembly and can rescue older/restricted Android WebViews.
 */
export function nextEngineFallback(profile) {
  if (profile === 'full-single') return 'lite-single';
  if (profile === 'sf10') return 'lite-single';
  if (profile === 'lite-single') return 'asm';
  return null;
}

export function engineAssetFile(profile) {
  if (profile === 'full-single') return 'stockfish-19-single.js';
  if (profile === 'asm') return 'stockfish-19-asm.js';
  if (profile === 'sf10') return 'stockfish-10.js';
  return 'stockfish-19-lite-single.js';
}

export function describeEngineProfile(preference = 'auto', device = {}) {
  const selected = resolveEngineProfile(preference, device);
  if (preference === 'auto') return `${selected === 'full-single' ? 'Full NNUE' : 'Lite'} (tự động)`;
  if (selected === 'sf10') return 'Stockfish 10 (thủ công)';
  return selected === 'full-single' ? 'Full NNUE (thủ công)' : 'Lite (thủ công)';
}
