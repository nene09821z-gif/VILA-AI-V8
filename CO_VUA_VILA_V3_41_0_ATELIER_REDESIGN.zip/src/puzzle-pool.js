/** Bounded, validated cache for public Lichess tactical puzzles. */
export const LICHESS_PUZZLE_POOL_LIMIT = 50;

export function puzzlePoolKey(puzzle) {
  const fen = String(puzzle?.fen || '').trim();
  if (!fen) return '';
  return fen.split(/\s+/).slice(0, 4).join(' ');
}

export function normalizePuzzlePool(items, validator = () => true, limit = LICHESS_PUZZLE_POOL_LIMIT) {
  if (!Array.isArray(items)) return [];
  const seen = new Set();
  const valid = [];
  for (const item of items) {
    const key = puzzlePoolKey(item);
    if (!key || seen.has(key) || !Array.isArray(item?.moves) || !item.moves.length) continue;
    let accepted = false;
    try { accepted = Boolean(validator(item)); } catch { accepted = false; }
    if (!accepted) continue;
    seen.add(key);
    valid.push(item);
  }
  return valid.slice(-Math.max(1, Math.min(200, Math.floor(Number(limit) || LICHESS_PUZZLE_POOL_LIMIT))));
}

export function upsertPuzzlePool(items, item, validator = () => true, limit = LICHESS_PUZZLE_POOL_LIMIT) {
  const key = puzzlePoolKey(item);
  if (!key) return normalizePuzzlePool(items, validator, limit);
  const current = normalizePuzzlePool(items, validator, limit).filter(existing => puzzlePoolKey(existing) !== key);
  let accepted = false;
  try { accepted = Boolean(validator(item)); } catch { accepted = false; }
  if (accepted && Array.isArray(item?.moves) && item.moves.length) current.push(item);
  return current.slice(-Math.max(1, Math.min(200, Math.floor(Number(limit) || LICHESS_PUZZLE_POOL_LIMIT))));
}

export function chooseUnusedPuzzle(items, seenKeys = new Set(), validator = () => true) {
  const pool = normalizePuzzlePool(items, validator);
  const available = pool.filter(item => !seenKeys.has(puzzlePoolKey(item)));
  if (!available.length) return null;
  // Oldest first gives the offline queue a fair chance to rotate through its cache.
  return available[0];
}
