/** Daily missions and cosmetic rewards. Virtual coins have no cash value. */
export const DAILY_MISSIONS = Object.freeze([
  { id: 'checkin', title: 'Điểm danh hôm nay', description: 'Mở Cờ Vua ViLa mỗi ngày để giữ chuỗi hoạt động.', event: 'checkin', goal: 1, reward: 10, icon: '☀', category: 'Thói quen' },
  { id: 'finish_game', title: 'Hoàn thành một ván', description: 'Chơi hết một ván với Stockfish hoặc AI.', event: 'complete_game', goal: 1, reward: 35, icon: '♟', category: 'Thi đấu' },
  { id: 'play_three', title: 'Tập luyện đều đặn', description: 'Hoàn thành 3 ván cờ trong ngày.', event: 'complete_game', goal: 3, reward: 60, icon: '⚔', category: 'Thi đấu' },
  { id: 'win_game', title: 'Chiến thắng trong ngày', description: 'Đánh bại đối thủ AI ít nhất một lần.', event: 'win_game', goal: 1, reward: 70, icon: '🏆', category: 'Thi đấu' },
  { id: 'draw_game', title: 'Biết khi nào nên hòa', description: 'Kết thúc một ván cờ hòa.', event: 'draw_game', goal: 1, reward: 30, icon: '🤝', category: 'Thi đấu' },
  { id: 'play_moves', title: 'Luyện từng nước', description: 'Đi ít nhất 20 nước hợp lệ trong ngày.', event: 'make_move', goal: 20, reward: 35, icon: '♞', category: 'Kỹ năng' },
  { id: 'capture_pieces', title: 'Trao đổi quân', description: 'Thực hiện 5 nước bắt quân.', event: 'capture_piece', goal: 5, reward: 35, icon: '✦', category: 'Kỹ năng' },
  { id: 'castle_once', title: 'Đưa vua vào an toàn', description: 'Nhập thành ít nhất một lần.', event: 'castle', goal: 1, reward: 20, icon: '🏰', category: 'Kỹ năng' },
  { id: 'promote_once', title: 'Biến tốt thành hậu', description: 'Phong cấp một quân tốt.', event: 'promote', goal: 1, reward: 45, icon: '♛', category: 'Kỹ năng' },
  { id: 'check_king', title: 'Tạo sức ép', description: 'Chiếu vua đối phương 3 lần.', event: 'check_king', goal: 3, reward: 25, icon: '⚡', category: 'Kỹ năng' },
  { id: 'opening_visit', title: 'Học một khai cuộc', description: 'Mở thư viện khai cuộc và xem các biến mở đầu.', event: 'visit_openings', goal: 1, reward: 20, icon: '⌘', category: 'Học tập' },
  { id: 'coach_visit', title: 'Mở phòng phân tích', description: 'Mở công cụ phân tích và huấn luyện cờ vua.', event: 'visit_coach', goal: 1, reward: 20, icon: '✧', category: 'Học tập' },
  { id: 'analyze_game', title: 'Xem lại ván đấu', description: 'Chạy phân tích Stockfish sau ván đấu.', event: 'analyze_game', goal: 1, reward: 35, icon: '⌕', category: 'Học tập' },
  { id: 'open_history', title: 'Nhìn lại tiến bộ', description: 'Mở lịch sử và xem lại một ván đã lưu.', event: 'open_history', goal: 1, reward: 15, icon: '↶', category: 'Học tập' },
  { id: 'visit_puzzles', title: 'Thử sức với chiến thuật', description: 'Mở phòng câu đố cờ vua.', event: 'visit_puzzles', goal: 1, reward: 20, icon: '🧩', category: 'Học tập' },
  { id: 'solve_puzzles', title: 'Giải 3 câu đố', description: 'Tìm nước mạnh nhất trong ba thế cờ ngẫu nhiên.', event: 'solve_puzzle', goal: 3, reward: 55, icon: '🧠', category: 'Thử thách' },
  { id: 'streak_bonus', title: 'Chuỗi nhiệm vụ', description: 'Hoàn thành 5 mục tiêu nhiệm vụ bất kỳ.', event: 'claim_mission', goal: 5, reward: 80, icon: '🔥', category: 'Thử thách' },
  { id: 'win_twice', title: 'Thắng hai trận', description: 'Đánh bại AI hai lần trong ngày.', event: 'win_game', goal: 2, reward: 80, icon: '🏆', category: 'Thi đấu' },
  { id: 'solve_five_puzzles', title: 'Thợ săn chiến thuật', description: 'Giải đúng 5 câu đố; đề được xác minh bằng luật cờ.', event: 'solve_puzzle', goal: 5, reward: 75, icon: '🧠', category: 'Thử thách' },
  { id: 'solve_ten_puzzles', title: 'Bậc thầy chiến thuật', description: 'Giải đúng 10 câu đố trong ngày.', event: 'solve_puzzle', goal: 10, reward: 120, icon: '♛', category: 'Thử thách' },
  { id: 'visit_arena', title: 'Thăm đấu trường', description: 'Mở khu vực đấu bot và khám phá các cặp đấu.', event: 'visit_arena', goal: 1, reward: 15, icon: '🤖', category: 'Đấu trường' },
  { id: 'complete_arena', title: 'Tranh cúp ViLa', description: 'Hoàn thành ít nhất một giải đấu bot hợp lệ.', event: 'complete_arena', goal: 1, reward: 100, icon: '🏆', category: 'Đấu trường' },
  { id: 'visit_games', title: 'Giải lao có ích', description: 'Khám phá góc mini-game ngoại tuyến.', event: 'visit_games', goal: 1, reward: 10, icon: '🎮', category: 'Giải trí' },
  { id: 'play_mini_game', title: 'Thử thách nhanh', description: 'Thực hiện ít nhất một lượt chơi trong mini-game.', event: 'play_mini_game', goal: 1, reward: 20, icon: '🎯', category: 'Giải trí' },
  { id: 'download_puzzle_pack', title: 'Chuẩn bị khi mất mạng', description: 'Tải và lưu ít nhất một câu đố Lichess để luyện offline.', event: 'download_puzzle_pack', goal: 1, reward: 30, icon: '⬇', category: 'Học tập' },
  { id: 'analyze_three_games', title: 'Nhà phân tích', description: 'Phân tích toàn ván ba lần.', event: 'analyze_game', goal: 3, reward: 65, icon: '📊', category: 'Học tập' }
]);

export const COSMETICS = Object.freeze([
  { id: 'classic', name: 'Xanh lá & kem', description: 'Bàn cờ 2D xanh lá và kem, phong cách cờ vua trực tuyến cổ điển.', cost: 0, icon: '♟', colors: ['#eeeed2', '#769656'], defaultOwned: true },
  { id: 'ocean', name: 'Đại dương', description: 'Bàn cờ xanh biển dịu mắt.', cost: 100, icon: '🌊', colors: ['#d8eaf0', '#4d8298'] },
  { id: 'walnut', name: 'Gỗ óc chó', description: 'Tông gỗ ấm, cổ điển.', cost: 150, icon: '🪵', colors: ['#ead5b7', '#986543'] },
  { id: 'midnight', name: 'Nửa đêm', description: 'Bàn cờ than chì và bạc.', cost: 200, icon: '🌙', colors: ['#cbd4df', '#475568'] },
  { id: 'violet', name: 'Tím hoàng hôn', description: 'Tông tím trầm, dễ nhìn trong phòng tối.', cost: 240, icon: '☂', colors: ['#e4d9ef', '#84689b'] },
  { id: 'rose', name: 'Hồng đất', description: 'Bàn cờ tông hồng bụi nhẹ nhàng.', cost: 240, icon: '🌸', colors: ['#f0dcd7', '#bc8f91'] },
  { id: 'ice', name: 'Băng giá', description: 'Xanh lạnh và xám thép.', cost: 280, icon: '❄', colors: ['#e5eff4', '#7096ab'] },
  { id: 'forest', name: 'Rừng sâu', description: 'Hai sắc xanh rừng đậm.', cost: 300, icon: '🌲', colors: ['#d5e1cf', '#4f7153'] }
]);

const own = value => value && typeof value === 'object' && !Array.isArray(value);
const clampInt = (value, min = 0, max = 1_000_000) => Math.max(min, Math.min(max, Math.floor(Number(value) || 0)));
export function localDayKey(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function previousDayKey(key) {
  const [year, month, day] = String(key).split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() - 1);
  return localDayKey(d);
}
export function createDailyState(date = new Date()) {
  const day = localDayKey(date);
  return { version: 2, day, lastVisitDay: day, streak: 1, coins: 0, missionProgress: { checkin: 1 }, claimed: [], stats: { gamesCompleted: 0, openingsVisited: 0, coachVisited: 0, moves: 0, captures: 0, wins: 0, puzzlesVisited: 0, puzzlesSolved: 0 }, ownedCosmetics: ['classic'], activeCosmetic: 'classic' };
}
export function normalizeDailyState(input, date = new Date()) {
  const base = createDailyState(date);
  if (!own(input)) return base;
  const state = {
    ...base, ...input, version: 2,
    day: typeof input.day === 'string' ? input.day : base.day,
    lastVisitDay: typeof input.lastVisitDay === 'string' ? input.lastVisitDay : '',
    streak: clampInt(input.streak), coins: clampInt(input.coins),
    missionProgress: own(input.missionProgress) ? { ...input.missionProgress } : {},
    claimed: Array.isArray(input.claimed) ? input.claimed.filter(id => DAILY_MISSIONS.some(m => m.id === id)) : [],
    stats: own(input.stats) ? { ...base.stats, ...input.stats } : { ...base.stats },
    ownedCosmetics: Array.isArray(input.ownedCosmetics) ? [...new Set(input.ownedCosmetics.filter(id => COSMETICS.some(c => c.id === id)))] : ['classic'],
    activeCosmetic: COSMETICS.some(c => c.id === input.activeCosmetic) ? input.activeCosmetic : 'classic'
  };
  state.stats = Object.fromEntries(Object.entries(state.stats).map(([key, value]) => [key, clampInt(value)]));
  if (!state.ownedCosmetics.includes('classic')) state.ownedCosmetics.unshift('classic');
  if (!state.ownedCosmetics.includes(state.activeCosmetic)) state.activeCosmetic = 'classic';
  if (state.day !== localDayKey(date)) {
    const today = localDayKey(date);
    if (state.lastVisitDay !== today) state.streak = state.lastVisitDay === previousDayKey(today) ? state.streak + 1 : 1;
    state.day = today; state.lastVisitDay = today; state.missionProgress = { checkin: 1 }; state.claimed = [];
  }
  state.missionProgress.checkin = 1;
  for (const mission of DAILY_MISSIONS) state.missionProgress[mission.id] = Math.min(mission.goal, clampInt(state.missionProgress[mission.id]));
  return state;
}
export function recordMissionEvent(input, event, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const missions = DAILY_MISSIONS.filter(item => item.event === event);
  if (!missions.length) return state;
  for (const mission of missions) state.missionProgress[mission.id] = Math.min(mission.goal, (state.missionProgress[mission.id] || 0) + 1);
  if (event === 'complete_game') state.stats.gamesCompleted = clampInt(state.stats.gamesCompleted + 1);
  if (event === 'visit_openings') state.stats.openingsVisited = clampInt(state.stats.openingsVisited + 1);
  if (event === 'visit_coach') state.stats.coachVisited = clampInt(state.stats.coachVisited + 1);
  if (event === 'make_move') state.stats.moves = clampInt(state.stats.moves + 1);
  if (event === 'capture_piece') state.stats.captures = clampInt(state.stats.captures + 1);
  if (event === 'win_game') state.stats.wins = clampInt(state.stats.wins + 1);
  if (event === 'visit_puzzles') state.stats.puzzlesVisited = clampInt(state.stats.puzzlesVisited + 1);
  if (event === 'solve_puzzle') state.stats.puzzlesSolved = clampInt(state.stats.puzzlesSolved + 1);
  return state;
}
export function claimMissionReward(input, missionId, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const mission = DAILY_MISSIONS.find(item => item.id === missionId);
  if (!mission) return { state, ok: false, reason: 'unknown_mission', reward: 0 };
  if ((state.missionProgress[mission.id] || 0) < mission.goal) return { state, ok: false, reason: 'not_completed', reward: 0 };
  if (state.claimed.includes(mission.id)) return { state, ok: false, reason: 'already_claimed', reward: 0 };
  state.claimed.push(mission.id);
  state.coins = clampInt(state.coins + mission.reward);
  // "Chuỗi nhiệm vụ" means claiming five distinct rewards, not merely finishing games.
  // Claiming the streak reward itself must not satisfy its own progress.
  if (mission.id !== 'streak_bonus') {
    const streakMission = DAILY_MISSIONS.find(item => item.id === 'streak_bonus');
    if (streakMission) {
      state.missionProgress.streak_bonus = Math.min(
        streakMission.goal,
        clampInt(state.missionProgress.streak_bonus) + 1
      );
    }
  }
  return { state, ok: true, reason: '', reward: mission.reward };
}
export function purchaseCosmetic(input, cosmeticId, date = new Date()) {
  const state = normalizeDailyState(input, date); const item = COSMETICS.find(c => c.id === cosmeticId);
  if (!item) return { state, ok: false, reason: 'unknown_item' };
  if (state.ownedCosmetics.includes(item.id)) return { state, ok: false, reason: 'already_owned' };
  if (state.coins < item.cost) return { state, ok: false, reason: 'not_enough_coins' };
  state.coins -= item.cost; state.ownedCosmetics.push(item.id); return { state, ok: true, reason: '' };
}
export function equipCosmetic(input, cosmeticId, date = new Date()) {
  const state = normalizeDailyState(input, date);
  if (!COSMETICS.some(c => c.id === cosmeticId)) return { state, ok: false, reason: 'unknown_item' };
  if (!state.ownedCosmetics.includes(cosmeticId)) return { state, ok: false, reason: 'not_owned' };
  state.activeCosmetic = cosmeticId; return { state, ok: true, reason: '' };
}
export function getMissionSummary(input, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const completed = DAILY_MISSIONS.filter(m => (state.missionProgress[m.id] || 0) >= m.goal).length;
  return { coins: state.coins, streak: state.streak, completed, total: DAILY_MISSIONS.length, claimed: state.claimed.length };
}
