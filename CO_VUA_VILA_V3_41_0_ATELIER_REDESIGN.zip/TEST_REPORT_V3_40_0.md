# Cờ Vua ViLa v3.40.0 — Báo cáo rà soát và kiểm thử

## Thay đổi được triển khai

- **Stockfish/UCI:** thêm state machine theo dõi vòng đời khởi động. Trạng thái chỉ chuyển sang `ready` sau thứ tự `uciok` rồi `readyok`; `readyok` xuất hiện trước `uciok`, thông báo thông thường hoặc `bestmove` sớm không đánh dấu engine sẵn sàng. Khi bấm chip engine lúc đã sẵn sàng, app hiển thị chẩn đoán ở toast; thời gian khởi động và hồ sơ được đặt trong tooltip để không làm giãn nút.
- **Khôi phục ván:** snapshot mới dùng schema v3 và checksum FNV-1a để phát hiện bản lưu bị cắt/hỏng/sửa đổi ngoài dự kiến. Kiểm tra tuổi tối đa 7 ngày, timestamp tương lai, mode được cho phép, FEN, tọa độ nước đi, phong cấp, số nửa nước, đồng hồ và hướng quân trước khi replay. Snapshot schema v2 cũ vẫn được chấp nhận để tương thích; sau đó toàn bộ nước đi phải replay hợp lệ và FEN cuối phải khớp.
- **Đồng bộ phát hành:** cập nhật phiên bản package/giao diện/API health/Service Worker/tài liệu và các test hiện hành; không đổi các test đã mô tả lịch sử tính năng thành kiểm thử giả.

## Kết quả chạy được trong môi trường hiện tại

| Hạng mục | Kết quả |
|---|---:|
| `npm run test:static` | **233/233 đạt** |
| `node --check` toàn bộ `src`, `server`, `scripts`, `tests` | **123/123 đạt** |
| `node --test tests/engine-health.test.js tests/game-recovery.test.js tests/project-smoke.test.js` | **19/19 đạt** |
| `node --test tests/*.test.js` | **235/239 đạt** |
| `unzip -t` gói phát hành mới | Đạt sau khi đóng gói và kiểm tra tệp nén |

Bốn test trong full suite không khởi chạy, không phải lỗi assertion: `tests/alternate-engine.test.js`, `tests/chess.test.js` và `tests/v3-25-features.test.js` thiếu `chess.js`; `tests/social.test.js` thiếu `express`. `npm install --ignore-scripts --no-audit --no-fund` bị timeout và kiểm tra DNS đến `raw.githubusercontent.com` thất bại trong môi trường này.

## Các cổng phát hành CHƯA đạt/chưa xác minh

- `npm run build` chưa thành công vì chưa cài được dependency `chess.js`. Không tạo APK trong lượt này.
- `public/openings-eco.json` là placeholder 0 dòng trong ZIP nguồn. `npm run build` chạy `scripts/prepare-openings.mjs` để lấy dữ liệu khai cuộc Lichess CC0; môi trường hiện tại không có mạng để tạo kho. `scripts/verify-opening-catalog.mjs` vì vậy thất bại tại máy này với 0/3000 dòng. Workflow Android đặt `REQUIRE_OPENING_CATALOG=1` và sẽ dừng nếu runner không tải/kiểm chứng được ít nhất 3000 biến khai cuộc hợp lệ, duy nhất.
- `scripts/verify-android-project.mjs` dừng nếu chạy trước workflow vì ZIP chỉ chứa source; `android/` và Gradle wrapper được tạo qua `npx cap add android` trong GitHub Actions. Đây là gói source để build, không phải project Android sinh sẵn hoặc APK.
- Chưa chạy UCI với binary Stockfish thật, chưa hoàn tất build Gradle, chưa đo FPS/độ trễ cảm ứng và chưa thử trên OPPO A17k.

## Lệnh nghiệm thu bắt buộc trên GitHub Actions hoặc môi trường có mạng

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
node scripts/verify-opening-catalog.mjs
npx cap sync android
node scripts/verify-android-project.mjs
cd android && ./gradlew assembleDebug --no-daemon
```

Không coi release là nghiệm thu xong cho đến khi cổng test đầy đủ, kho khai cuộc, binary Stockfish 19/10, build APK và thử nghiệm thiết bị đều đạt.
