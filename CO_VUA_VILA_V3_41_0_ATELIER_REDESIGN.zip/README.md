# Cờ Vua ViLa v3.41.0 — VILA Atelier Chess Studio

## v3.41.0 — VILA Atelier

Bản này làm mới toàn diện giao diện theo phong cách studio sáng: nền giấy, panel trắng, xanh lá cho hành động chính và vàng dịu cho giải đấu. `src/vila-atelier.css` được nạp sau stylesheet cũ để giữ nguyên các ID, bộ xử lý nước đi và module chức năng trong khi thay đổi lớp trình bày. Thanh điều hướng được sắp cấp bậc lại; trên Android, phòng chơi ẩn thanh điều hướng dưới để tránh chồng vào thanh thao tác ván cờ. Các trạng thái điều hướng có `aria-current`, menu đồng bộ `aria-expanded` và đóng được bằng Escape.

Bỏ yêu cầu tải Google Fonts từ xa để UI khởi động bằng font hệ thống, kể cả offline. Bộ test tĩnh cho giao diện mới nằm trong `tests/atelier-ui.test.js`.

### QA v3.41.0

- Static suite: 239/239 đạt.
- JavaScript/MJS syntax: 126/126 đạt; CSS parse: 0 lỗi ở hai stylesheet.
- Full suite: 241/245; 4 test chưa khởi chạy được do thiếu `chess.js` hoặc `express` vì npm install timeout. Chưa xác nhận build APK hoặc kiểm tra trực tiếp trên Android.
- Chi tiết: [`TEST_REPORT_V3_41_0.md`](TEST_REPORT_V3_41_0.md).


VILA là ứng dụng cờ vua web đóng gói bằng Capacitor cho Android. Bản ZIP này là **mã nguồn để build**, không phải APK đã biên dịch.


## Nâng cấp v3.40.0

- Chip Stockfish chỉ báo sẵn sàng sau UCI handshake hợp lệ `uciok` → `readyok`; khi đã sẵn sàng, chạm chip để xem thời gian khởi động/profile trong thông báo.
- Lưu ván đang chơi dùng snapshot có checksum; ván hỏng, quá hạn, sai mode, nước đi/đồng hồ sai định dạng bị từ chối trước khi nạp; snapshot v2 cũ vẫn tương thích.
- Giữ các chế độ cờ, phân tích, câu đố, đấu trường, Rubik và mini-game hiện có; thay đổi tập trung vào tính đúng đắn, khả năng khôi phục và kiểm thử hồi quy.
- Test tĩnh: 233/233; cú pháp: 123/123; full suite: 235/239 do bốn tệp test thiếu dependency trong môi trường đóng gói. Build APK và UCI với binary thật còn chờ chạy trên GitHub Actions.


## Tính năng nền tảng từ v3.37.0

### Engine và sức mạnh bot
- Stockfish 19 Full NNUE được đưa vào quy trình build Android cùng bản Lite và ASM-JS dự phòng. Full single-threaded có kích thước khoảng 94 MB và không cần cross-origin isolation; Lite nhẹ hơn đáng kể nhưng yếu hơn. [Tài liệu Stockfish.js và các biến thể engine](https://github.com/nmrugg/stockfish.js/blob/master/README.md).
- Chế độ tự động ưu tiên Full NNUE khi WebView báo bộ nhớ thiết bị từ khoảng 2 GiB và ít nhất 4 lõi; máy yếu hơn chọn Lite. Nếu Full không khởi tạo được, ứng dụng có chuỗi dự phòng Lite rồi ASM-JS.
- Bot không còn bỏ lượt Stockfish để đi ngẫu nhiên/heuristic chỉ nhằm giả lập Elo thấp. Dưới ngưỡng UCI_Elo, VILA dùng Skill Level 0–7 của Stockfish; các mức Elo thấp là preset luyện tập, **không phải rating được benchmark**.
- Mặc định tìm kiếm sâu hơn (depth tối đa 30, tối đa 2,6 giây mỗi nước); cài đặt tùy chỉnh đã lưu của người chơi được giữ lại.

### Đấu trường có hai thế hệ Stockfish
- Đấu trường có Stockfish 19 Full NNUE và Stockfish 10 cổ điển như hai đối thủ độc lập. Stockfish 10 được phân phối từ gói `stockfish.js@10.0.2`, chạy UCI trong Web Worker riêng, có giới hạn thời gian và kiểm tra tính hợp lệ của nước đi. Đây là engine đời cũ dùng để so sánh, không được quảng bá là mạnh hơn Stockfish hiện tại.
- Bản Android release bắt buộc xác nhận đủ script Stockfish 10 và giấy phép GPL đi kèm; thiếu một trong hai thì build dừng trước khi ghi đè thư mục engine.

### Xem lại ván và phân tích
- Xem lại từng nửa nước với nút về đầu/trước/sau/cuối, bàn cờ có tô nước cuối, biểu đồ lợi thế và biên bản ghép theo cặp Trắng/Đen. Chạm một nước để nhảy đến đúng thế cờ.
- Phân tích từng nước lưu điểm trước/sau theo góc nhìn Trắng, mức mất điểm theo bên vừa đi, độ sâu engine, nước tốt nhất tìm thấy ở thế trước và biến chính SAN. Panel hiển thị nhãn và số lượng chất lượng nước đi riêng cho Trắng và Đen.
- Phân tích toàn ván, gợi ý nước, phân tích 3 biến và trợ lý cờ chạy ở mức sức mạnh tối đa của engine, không thừa hưởng giới hạn Elo của bot trong ván.
- Các nhãn “Tốt nhất”, “Xuất sắc”, “Tốt”, “Chưa chính xác”, “Sai lầm”, “Blunder”, “Khai cuộc” và “Bỏ lỡ cơ hội thắng” là **heuristic VILA dựa trên điểm Stockfish**, không tuyên bố dùng cùng công thức phân loại độc quyền của Chess.com. Nước “Thiên tài” không được tự gán chỉ vì có quân bị tấn công.

### Giao diện, bài tập và game giải trí
- App mở vào **sảnh Trang chủ VILA**, không mở thẳng bàn cờ. Từ sảnh mới chọn Chơi, Bot, Câu đố, Bài học, Phân tích, Đấu trường AI, lịch sử hoặc mini-game.
- Giao diện ưu tiên điện thoại: xanh đêm/xanh lá mang thương hiệu VILA, điều hướng đáy, vùng chạm lớn, safe-area Android và bàn cờ responsive. Bố cục lấy cảm hứng từ ứng dụng cờ hiện đại, không sao chép logo hoặc tài sản thương hiệu riêng của Chess.com.
- Giữ thư viện khai cuộc ECO cục bộ, tra cứu tên/ECO/nước đi và các biến. Workflow kiểm tra ngưỡng dữ liệu khai cuộc trước build.
- Câu đố ngày sử dụng Lichess API, xác minh dòng nước bằng `chess.js`, lưu cache ngày và có bài ngoại tuyến khi không có mạng. Luyện tự do, Rush và Sinh tồn tự chuyển bài sau khi giải; bộ đố offline có độ khó tăng dần theo tiến trình.
- Bốn mini-game ngoại tuyến: Rubik 3×3 xoay mặt bằng vuốt hoặc nút U/D/L/R/F/B, xáo trộn/hoàn tác/làm mới; 2048; lật thẻ nhớ; Trượt số 15 với xáo trộn chỉ bằng nước đi hợp lệ.
- Giữ các chức năng sẵn có: nhập/xuất PGN, lịch sử cục bộ, đồng hồ, hoàn tác/làm lại, chú thích mũi tên/ô cờ, khai cuộc, profile bot offline, nhạc nền và các luồng online đã tích hợp.

## Bản vá v3.37.1 — Stockfish 10 Đấu trường
- Đồng bộ UCI bằng `isready`/`readyok` trước từng lệnh `position`/`go`; reset `ucinewgame` chỉ một lần cho mỗi ván để không xóa bảng băm ở mọi nửa nước.
- Cô lập callback theo đúng Worker và dỡ callback trước khi huỷ worker timeout/lỗi, ngăn `bestmove` cũ làm hoàn tất lượt mới. Worker lỗi hoặc timeout được huỷ an toàn và tự khởi tạo lại ở lượt kế tiếp; lỗi Stockfish 10 được giữ rõ trên trạng thái Đấu trường khi dùng nước dự phòng.
- Bản phát hành tăng phiên bản Service Worker để thiết bị không giữ mã JavaScript cũ trong cache.

## Online và offline
- Chơi với Stockfish, luyện bài và mini-game chạy cục bộ sau khi các engine cần thiết đã được tải/cache.
- Câu đố ngày và dữ liệu mở rộng cần internet; cache cục bộ được dùng khi có sẵn.
- Xếp hạng/cộng đồng/server yêu cầu backend và tài khoản đã cấu hình. Không đăng nhập hay backend thì những luồng phụ thuộc server không thể hoạt động đầy đủ.
- Engine Full NNUE khoảng 94 MB; workflow build nhúng nó để tăng sức mạnh, vì vậy APK lớn hơn. Trên máy yếu có thể dùng Lite hoặc để chế độ tự động chọn phù hợp.

## Build APK bằng GitHub Actions

1. Giải nén ZIP và đẩy **toàn bộ nội dung bên trong** lên một GitHub repository, giữ nguyên thư mục `.github/workflows/`.
2. Mở tab **Actions** và chạy workflow **Cờ Vua ViLa Android build**. Workflow này cũng chạy khi có push/PR.
3. Runner cài Node.js 22 và Java 21; cài package, kiểm tra cú pháp, chạy `npm test`, tải tài nguyên engine/bộ quân/kho khai cuộc, build web, sync Capacitor và chạy `./gradlew assembleDebug`.
4. Chỉ khi các bước bắt buộc đều thành công, tải artifact **`covua-vila-debug-apk`**. Artifact `test-report` giúp xem lỗi test, còn `covua-vila-android-gradle-source` là gói mã nguồn Gradle do workflow sinh ra.
5. Workflow **Cờ Vua ViLa build from ZIP/source** là lựa chọn chạy thủ công riêng; nó không chạy trùng trên mỗi lần push.

### Lệnh cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

`npm run build` cần các package Node và tải dữ liệu build lần đầu. Đối với build Android cần môi trường Java/Android phù hợp hoặc dùng GitHub Actions.

## Báo cáo kiểm thử

Xem [`TEST_REPORT_V3_41_0.md`](TEST_REPORT_V3_41_0.md) để biết kết quả mới nhất. Bản v3.41.0 đạt 239/239 test tĩnh và 126/126 tệp cú pháp JS/MJS. Full suite đạt 241/245; 4 bài chưa khởi chạy do thiếu `chess.js`/`express` khi npm install timeout. Build APK và thử thiết bị thật chưa được xác nhận.

## Nguồn câu đố

Nguồn, license và cách tải kho câu đố theo lô được ghi trong [`PUZZLES_SOURCE.md`](PUZZLES_SOURCE.md). Dữ liệu Lichess được tải theo yêu cầu; không đóng gói cả cơ sở dữ liệu nhiều triệu câu vào APK.

## Nguồn và giấy phép

- Stockfish.js: [repository và README](https://github.com/nmrugg/stockfish.js); engine GPLv3, giấy phép được copy kèm asset khi build.
- Lichess API và dữ liệu công khai: [API](https://github.com/lichess-org/api/blob/master/doc/specs/lichess-api.yaml), [Open Database](https://database.lichess.org/) (câu đố dữ liệu công khai CC0). Bản này dùng API daily/cache, không nhúng toàn bộ kho hàng triệu câu đố.
- Các bộ quân SVG và giấy phép nguồn được liệt kê trong [`public/piece-sets/CREDITS.md`](public/piece-sets/CREDITS.md).
- Ý tưởng giao diện Rubik tương tác có tham khảo [Cubing.js](https://js.cubing.net/cubing/); logic xoay trong dự án này được hiện thực nội bộ, không tải thư viện từ CDN.


## Bản vá v3.37.2 — bố cục trận đấu trên Android

- Chuyển lời mời bắt đầu khỏi lớp phủ che mờ bàn cờ thành thẻ gọn nằm giữa thông tin đối thủ và bàn cờ.
- Đưa cửa sổ cuộn về đầu trang khi chuyển màn hình hoặc quay lại chơi từ màn xem lại.
- Bảo đảm vùng đệm cuối trang đủ cho thanh thao tác trận đấu cố định, tránh che nội dung cuối trên WebView di động.
- Tăng phiên bản Service Worker để thiết bị không tiếp tục dùng CSS/JS cũ sau khi cập nhật.
