# Cờ Vua ViLa v3.41.0 — VILA Atelier

## Thiết kế đã triển khai

1. Dùng lớp `src/vila-atelier.css` sau stylesheet legacy để thay ngôn ngữ thị giác mà không thay ID và điểm móc điều khiển chức năng.
2. Đồng bộ header, điều hướng chính/phụ, sảnh, phòng chơi, bàn cờ, panel đồng hồ/nước đi, câu đố/ranked, khai cuộc, huấn luyện, đấu trường/cúp, shop/tiến trình, mini-game, lịch sử, phân tích, mạng xã hội, inbox và admin.
3. Màu nền giấy sáng, panel trắng, xanh rừng cho hành động và vàng dịu cho cúp; focus ring bàn phím, reduced motion và font hệ thống offline-first.
4. Bàn cờ ưu tiên trên mobile, vùng an toàn Android, thanh thao tác không chồng với bottom navigation.
5. Điều hướng hiện tại dùng `aria-current`; nút menu đồng bộ `aria-expanded`; Escape đóng menu.
6. Thêm `tests/atelier-ui.test.js` để kiểm tra import stylesheet, biến màu, mobile layout, vẫn giữ các route hiện có, chủ đề các màn chuyên biệt và metadata version.

## Kiểm thử

- Static: 239/239 đạt.
- `node --check`: 126/126 JS/MJS đạt.
- CSS parse: 0 lỗi ở hai stylesheet.
- Full suite: 241/245, trong đó 4 bài không khởi chạy vì thiếu `chess.js`/`express`; npm install timeout trong môi trường hiện tại.

## Việc phải làm trước phát hành

1. Cài dependencies thành công trong GitHub Actions; chạy toàn bộ tests và `npm run build`.
2. Kiểm tra screenshot thật tại 360–390 CSS px, landscape ngắn và desktop; kiểm tra bàn cờ, overlay, menu, phân tích, lịch sử, social và các màn luyện tập.
3. Kiểm tra UCI handshake với binary engine, lưu/khôi phục ván, PGN, câu đố, cache offline, ranked server và các luồng xác thực trên build thật.
4. Nghiệm thu trên OPPO A17k Android 12; đo thao tác kéo quân, độ trễ, bộ nhớ WebView và độ ổn định khi chuyển nền.
5. Đánh giá và đo chức năng nghiệp vụ chuyên sâu sau khi nền build hoạt động; không gán kết quả thật khi chưa chạy được engine/server/thiết bị.
