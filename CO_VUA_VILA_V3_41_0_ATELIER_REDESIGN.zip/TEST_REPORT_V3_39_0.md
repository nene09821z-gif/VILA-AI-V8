# Cờ Vua ViLa v3.39.0 — Báo cáo kiểm thử

## Đã chạy
- `npm run test:static`: **225/225 đạt**.
- Kiểm tra cú pháp Node cho toàn bộ 121 tệp `.js`/`.mjs`: **121/121 đạt**.
- `node --test tests/daily-progress.test.js tests/project-smoke.test.js`: **19/19 đạt**.
- Toàn bộ `node --test tests/*.test.js`: **227/231 đạt**; 4 tệp test không khởi chạy do các dependency npm không có trong môi trường (`chess.js`, `express` và các test phụ thuộc chúng). Không coi 4 test đó là đạt.

## Thay đổi có kiểm thử
- Nhiệm vụ “Chuỗi nhiệm vụ” nay tăng tiến độ khi nhận thưởng của nhiệm vụ khác nhau, không phải mỗi lần hoàn thành ván.
- Nhận thưởng trùng không tăng tiến độ; tiến độ tối đa 5; phần thưởng chuỗi không thể tự hoàn thành chính nó.
- Release metadata và service-worker cache được cập nhật lên 3.39.0.

## Chưa xác minh
- Không chạy được build Vite/Android hoàn chỉnh do `node_modules` chưa được cài và môi trường không đảm bảo truy cập npm.
- Không thử trực tiếp trên OPPO A17k; không đo FPS/độ trễ cảm ứng thực tế.
- Không xác nhận engine Stockfish khởi tạo trên thiết bị thật trong lượt kiểm thử này.

## Lệnh nghiệm thu tiếp theo
```bash
npm install
npm run test:static
npm test
npm run build
```
Sau đó kiểm tra artifact Android trong GitHub Actions và thử các luồng quan trọng trên điện thoại thật.
