# VILA Chess v3.40.0 — kế hoạch và trạng thái nâng cấp

## Đã làm trong v3.40.0

1. **Khởi động engine có kiểm chứng:** state machine UCI, theo dõi profile/thời gian; chỉ báo ready sau `uciok` + `readyok`; lỗi/timeout không thể bị che bởi thông báo `bestmove` đến sớm.
2. **Khôi phục an toàn:** snapshot schema v3 có checksum, schema v2 được hỗ trợ tương thích, dữ liệu không hợp lệ/hết hạn bị từ chối trước khi replay. Nước đi được chạy lại bằng luật cờ và FEN cuối phải trùng khớp.
3. **Bảo vệ hồi quy:** 7 test mới cho UCI/state recovery và một kiểm thử tích hợp xác nhận code app gọi các guard; đồng bộ phiên bản hiện tại trên UI/server/cache.
4. **Xác minh nguồn:** giữ kho Lichess ECO theo cách tải/xác minh khi build; không phát minh 3000 dòng khai cuộc khi không tải được nguồn.

## Đang chờ cổng môi trường

- Không tải được npm dependencies trong môi trường hiện tại, nên 4 tệp test tích hợp phụ thuộc `chess.js`/`express` chưa chạy. GitHub Actions cần chạy lại `npm test` với dependencies đầy đủ.
- Không có mạng để lấy bộ ECO Lichess CC0; ZIP nguồn vẫn có `public/openings-eco.json` rỗng và quy trình release bắt buộc tạo, xác minh ít nhất 3000 biến hợp lệ trước khi build.
- Chưa build APK/chạy engine thật hoặc thử trên OPPO A17k.

## Các bước tiếp theo sau khi môi trường có mạng

1. Build và test UCI Stockfish 19 Full/Lite/ASM cùng Stockfish 10 trong Chromium/WebView Android; đo thời gian khởi động và có fallback hoạt động.
2. Tải và kiểm chứng kho ECO; kiểm tra tên/ECO/nước SAN đã hợp lệ và không trùng trước khi bundle offline.
3. Chạy `npm test`, build Vite, sync Capacitor, `assembleDebug`, thử bàn cờ cảm ứng/clock/undo-redo/resume/puzzle/review trên màn hình 360 CSS px.
4. Chạy trận benchmark giữa các profile bot; chỉ công bố rating khi có số ván, đối thủ và phương pháp tính rõ ràng.
