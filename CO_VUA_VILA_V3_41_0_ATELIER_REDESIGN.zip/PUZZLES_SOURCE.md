# Nguồn câu đố cờ vua — ViLa v3.38.0

## Nguồn dữ liệu

- Kho dữ liệu chính thức: <https://database.lichess.org/>
- Hướng dẫn câu đố Lichess: <https://lichess.org/training>
- API câu đố công khai dùng để tải trong ứng dụng: <https://lichess.org/api/puzzle/next?difficulty=normal>
- API câu đố trong ngày: <https://lichess.org/api/puzzle/daily>

Trang Open Database của Lichess ghi dữ liệu xuất kho câu đố theo giấy phép **CC0** và tại lần kiểm tra bản phát hành v3.38.0 liệt kê khoảng 6,157,341 câu đố. Không nhúng toàn bộ CSV nhiều triệu dòng vào ZIP/APK vì kích thước rất lớn.

## Cách ứng dụng sử dụng dữ liệu

1. Người dùng chủ động bấm **Tải 10 câu về máy** khi có mạng.
2. Ứng dụng lấy từng câu qua API công khai, giới hạn thời gian yêu cầu, xác minh PGN/FEN và kiểm tra từng nước lời giải bằng thư viện luật cờ `chess.js`.
3. Các thế cờ trùng nhau hoặc có lời giải không hợp lệ bị loại; kho cục bộ giữ tối đa 50 câu hợp lệ.
4. Các câu đã lưu được luân phiên để luyện ngoại tuyến. Lần tải đầu vẫn cần mạng; khi kho trống và không có mạng, ứng dụng dùng trình sinh câu đố ngoại tuyến hiện có.

## Phạm vi xác minh

Kiểm thử đơn vị xác minh giới hạn kho, loại vị trí trùng, luân phiên câu chưa dùng và cấu trúc API. Trong môi trường đóng gói bản này không thể truy cập `registry.npmjs.org`, vì vậy không thể cài dependencies để tải dữ liệu thật hoặc xác thực live API; cần chạy GitHub Actions/thiết bị có mạng để hoàn tất kiểm chứng tích hợp.
