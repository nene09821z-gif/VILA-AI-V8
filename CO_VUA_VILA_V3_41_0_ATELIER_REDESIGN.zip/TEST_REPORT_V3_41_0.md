# Cờ Vua ViLa v3.41.0 — Báo cáo rà soát VILA Atelier

## Thay đổi đã triển khai

- Thêm `src/vila-atelier.css`, lớp thiết kế mới cho phần lớn ứng dụng: sảnh, điều hướng, phòng chơi, bàn cờ, đồng hồ, panel nước đi, câu đố, đấu xếp hạng, khai cuộc, huấn luyện, đấu trường/cúp, cửa hàng/tiến trình, mini-game, lịch sử, phân tích toàn ván, cộng đồng, inbox, admin và hộp kết quả.
- Phong cách “Atelier”: nền sáng dịu, bề mặt trắng, xanh rừng cho hành động, vàng dịu cho thông tin giải đấu, viền và bóng nhẹ; lớp CSS được tải sau stylesheet cũ để giữ các ID, module và event hook.
- Mobile ưu tiên bàn cờ, thanh thao tác 5 cột với vùng safe-area; ẩn thanh điều hướng dưới khi đang ở phòng chơi để ngăn chồng lấp.
- Bỏ yêu cầu tải Google Fonts từ xa, dùng font hệ thống để khởi động offline ít phụ thuộc mạng hơn.
- Trạng thái menu có `aria-expanded`, trang hiện tại có `aria-current`, hỗ trợ Escape đóng menu; thêm test chuyên biệt cho giao diện và các màn hình con.
- Đồng bộ phiên bản giao diện, package, API health, service worker, favicon và tài liệu build thành 3.41.0.

## Kết quả kiểm thử cuối

- `npm run test:static`: **239/239 đạt**.
- `npm test`: **241/245 đạt**. 4 bài không khởi chạy được do dependency không có trong môi trường, không phải bài test nghiệp vụ đã được xác nhận là đạt:
  - `tests/alternate-engine.test.js` — thiếu `chess.js`.
  - `tests/chess.test.js` — thiếu `chess.js`.
  - `tests/v3-25-features.test.js` — thiếu `chess.js`.
  - `tests/social.test.js` — thiếu `express`.
- Kiểm tra cú pháp `node --check`: **126/126 tệp JS/MJS**, không có lỗi cú pháp.
- Kiểm tra cấu trúc CSS bằng `tinycss2`: `src/style.css` có 0 lỗi parse; `src/vila-atelier.css` có 0 lỗi parse.
- `npm install --ignore-scripts --no-audit --no-fund` đã thử lại nhưng timeout, nên không thể cài package để xác nhận bundle production trong môi trường này.
- ZIP được kiểm tra bằng `unzip -t` sau khi đóng gói.

## Chưa được xác minh — không tính là đạt

- Chưa chạy `npm run build`, workflow GitHub Actions hoặc tạo APK vì không tải được dependency ở môi trường hiện tại.
- Chưa có screenshot trình duyệt hoàn chỉnh/kiểm tra trực tiếp trên OPPO A17k Android 12; các bài UI ở đây kiểm tra cấu trúc, CSS, điều hướng và hồi quy tĩnh, không thay cho nghiệm thu trực quan.
- Chưa đo FPS, input latency, sức mạnh Elo hoặc UCI bằng binary engine đã chạy trên máy thật.
- Chưa làm mới kiến trúc nghiệp vụ backend/engine từ đầu. Bản này giữ logic hiện tại để tránh phá các chức năng cũ và tập trung làm mới giao diện, điều hướng và an toàn sử dụng.

## Khuyến nghị nghiệm thu

Trên GitHub Actions, chạy cài dependencies, `npm run test:static`, `npm test`, `npm run build` và workflow Android. Sau khi build thành công, kiểm tra bàn cờ, menu More, các nút trên thanh ván, review/PGN, câu đố, đấu trường, lịch sử, mạng xã hội và khôi phục ván trên thiết bị thật ở màn hình rộng 360 CSS px và landscape ngắn.
