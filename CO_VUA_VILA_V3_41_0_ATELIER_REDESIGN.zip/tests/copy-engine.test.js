import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const script = path.join(root, 'scripts', 'copy-engine.mjs');

function makeFixture({ withAsm = true } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vila-engine-copy-'));
  fs.mkdirSync(path.join(dir, 'scripts'), { recursive: true });
  fs.copyFileSync(script, path.join(dir, 'scripts', 'copy-engine.mjs'));
  const packageRoot = path.join(dir, 'node_modules', 'stockfish');
  fs.mkdirSync(packageRoot, { recursive: true });
  for (const name of ['stockfish-19-lite-single.js', 'stockfish-19-lite-single.wasm', ...(withAsm ? ['stockfish-19-asm.js'] : []), 'Copying.txt']) {
    fs.writeFileSync(path.join(packageRoot, name), `fixture:${name}`);
  }
  const destination = path.join(dir, 'public', 'engine');
  fs.mkdirSync(destination, { recursive: true });
  fs.writeFileSync(path.join(destination, 'old-engine-marker.txt'), 'keep-until-valid');
  return { dir, destination };
}

test('engine packager copies required Lite + ASM-JS assets and writes a manifest', t => {
  const fixture = makeFixture();
  t.after(() => fs.rmSync(fixture.dir, { recursive: true, force: true }));
  const result = spawnSync(process.execPath, [path.join(fixture.dir, 'scripts', 'copy-engine.mjs'), '--required'], {
    cwd: fixture.dir,
    env: { ...process.env, REQUIRE_STOCKFISH: '1', INCLUDE_STOCKFISH_FULL: '0' },
    encoding: 'utf8',
    timeout: 5000
  });
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
  for (const name of ['stockfish-19-lite-single.js', 'stockfish-19-lite-single.wasm', 'stockfish-19-asm.js', 'STOCKFISH-LICENSE.txt', 'engine-manifest.json']) {
    assert.ok(fs.existsSync(path.join(fixture.destination, name)), `Missing packaged asset ${name}`);
  }
  assert.equal(fs.existsSync(path.join(fixture.destination, 'old-engine-marker.txt')), false);
  const manifest = JSON.parse(fs.readFileSync(path.join(fixture.destination, 'engine-manifest.json'), 'utf8'));
  assert.equal(manifest.lite, true);
  assert.equal(manifest.asmFallback, true);
  assert.equal(manifest.full, false);
});

test('engine packager refuses missing required assets without deleting the last working bundle', t => {
  const fixture = makeFixture({ withAsm: false });
  t.after(() => fs.rmSync(fixture.dir, { recursive: true, force: true }));
  const result = spawnSync(process.execPath, [path.join(fixture.dir, 'scripts', 'copy-engine.mjs'), '--required'], {
    cwd: fixture.dir,
    env: { ...process.env, REQUIRE_STOCKFISH: '1', INCLUDE_STOCKFISH_FULL: '0' },
    encoding: 'utf8',
    timeout: 5000
  });
  assert.equal(result.status, 1, `${result.stdout}\n${result.stderr}`);
  assert.ok(fs.existsSync(path.join(fixture.destination, 'old-engine-marker.txt')), 'Existing bundle must remain untouched after failed asset validation');
});


test('engine packager includes Full NNUE when explicitly required and records it in the manifest', t => {
  const fixture = makeFixture();
  t.after(() => fs.rmSync(fixture.dir, { recursive: true, force: true }));
  const packageRoot = path.join(fixture.dir, 'node_modules', 'stockfish');
  for (const name of ['stockfish-19-single.js', 'stockfish-19-single.wasm']) fs.writeFileSync(path.join(packageRoot, name), `fixture:${name}`);
  const result = spawnSync(process.execPath, [path.join(fixture.dir, 'scripts', 'copy-engine.mjs'), '--required'], {
    cwd: fixture.dir, env: { ...process.env, REQUIRE_STOCKFISH: '1', INCLUDE_STOCKFISH_FULL: '1' }, encoding: 'utf8', timeout: 5000
  });
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
  for (const name of ['stockfish-19-single.js', 'stockfish-19-single.wasm']) assert.ok(fs.existsSync(path.join(fixture.destination, name)), `Missing ${name}`);
  const manifest = JSON.parse(fs.readFileSync(path.join(fixture.destination, 'engine-manifest.json'), 'utf8'));
  assert.equal(manifest.full, true);
  assert.equal(manifest.lite, true);
  assert.equal(manifest.asmFallback, true);
});
