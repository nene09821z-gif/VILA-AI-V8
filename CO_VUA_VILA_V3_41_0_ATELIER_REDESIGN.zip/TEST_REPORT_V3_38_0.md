# Báo cáo kiểm thử — Cờ Vua ViLa v3.38.0

## Kết quả đã xác minh

- **224/224 test tĩnh:** đạt (`npm run test:static`). Bao gồm bố cục điện thoại, luồng chọn người chơi, thanh bút chì, câu đố, kho offline, nhiệm vụ, mini-game, phân tích, Stockfish profile, script đóng gói engine và cấu hình Android Actions.
- **36/36 test trọng điểm riêng:** đạt cho bảng chọn Mới chơi/Đã hiểu luật, thanh bút chì gọn, kho câu đố chống trùng/giới hạn dung lượng, Cờ ca-rô minimax, cấu hình Stockfish 10, luật ký hiệu phân tích và nhận diện phiên bản.
- **230 test toàn bộ:** 226 đạt; 4 tệp test không thể khởi chạy vì môi trường không cài được dependency: `tests/alternate-engine.test.js`, `tests/chess.test.js`, `tests/v3-25-features.test.js` thiếu `chess.js`, và `tests/social.test.js` thiếu `express`. Không tính 4 bài này là pass.
- **119/119 tệp JavaScript/MJS:** `node --check` đạt.
- `package.json` và `capacitor.config.json` phân tích JSON hợp lệ.
- Gói ZIP phát hành đã kiểm tra tính toàn vẹn sau khi tạo.

## Tại sao bộ test đầy đủ chưa đạt 230/230

`npm install --no-audit --no-fund` bị quá thời gian chờ. Kiểm tra DNS độc lập với `curl https://registry.npmjs.org/chess.js` trả về `Could not resolve host: registry.npmjs.org`, do đó không tải được `chess.js`/`express`. `npm run test:static` không cần các dependency thiếu và đã chạy trọn vẹn 224 test.

## Giới hạn cần công khai

- Chưa chạy thành công `npm run build`, Gradle `assembleDebug`, hoặc xuất APK do dependencies/assets tải qua npm không có sẵn trong môi trường này.
- Chưa kiểm tra trực tiếp trên OPPO A17k/Android WebView.
- Chưa gọi live Lichess API hoặc tải 10 câu hỏi thật từ mạng trong môi trường này. Logic kiểm tra schema, nước UCI, giới hạn pool và loại thế cờ trùng được test cục bộ; hướng dẫn nguồn/giấy phép nằm ở `PUZZLES_SOURCE.md`.
- Script đóng gói Stockfish 10 được kiểm thử với fixture giả lập và build workflow đặt `REQUIRE_STOCKFISH_10=1`, nên CI sẽ dừng nếu thiếu engine/giấy phép. Tuy nhiên **chưa xác minh được binary Stockfish 10 thật trong APK của bản này**. Không nên coi bản build là đã nghiệm thu cho tới khi GitHub Actions thành công và thử trận/engine trên thiết bị.

## Các thay đổi chính được đưa vào test

1. Bảng chọn người mới/đã hiểu luật hiện trước bàn cờ; thiết lập người mới chọn sẵn mức bot nhẹ hơn.
2. Thanh bút chì vào luồng bố cục, bỏ tọa độ kéo cũ, gom mũi tên/khoanh ô/đổi màu/xóa; thanh thao tác đáy thu gọn và có nhãn nhỏ.
3. Huy hiệu mã ở góc phải hiển thị trạng thái Stockfish và có hành động thử tải lại.
4. Đấu trường có bảng Cúp lưu bảng xếp hạng; thêm nhiệm vụ thăm đấu trường, hoàn tất giải, mini-game và tải câu đố.
5. Thêm Cờ ca-rô offline với minimax; giữ Rubik, 2048, lật thẻ và trượt số.
6. Kho Lichess tải theo lô 10 câu, kiểm tra luật và giữ tối đa 50 câu offline. Không nhúng toàn bộ kho khoảng 6.1 triệu câu vào APK.
7. Chú giải phân tích phân biệt huy hiệu giao diện (★/✓/·) với các dấu nhận xét quen thuộc (?!/?/??); có ghi chú minh bạch rằng mức phân loại là heuristic theo centipawn-loss của ViLa, không phải CAPS2 hay thuật toán nội bộ của Chess.com.
