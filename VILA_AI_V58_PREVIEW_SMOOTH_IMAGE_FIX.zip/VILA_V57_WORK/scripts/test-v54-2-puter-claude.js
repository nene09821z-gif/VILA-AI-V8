#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const activity = fs.readFileSync('app/src/main/java/com/vila/ai/MainActivity.java', 'utf8');
assert.match(html, /puter\.ai\.listModels\(\)/, 'Puter should provide the live multi-provider model catalog');
assert.match(html, /puterModelId:String\(m\.puterModelId\|\|m\.id\)/, 'raw Puter model IDs must be preserved separately');
assert.match(html, /puterProvider:String\(m\.puterProvider\|\|'unknown'\)/, 'provider metadata must be cached');
assert.match(html, /options\.provider=entry\.puterProvider/, 'chat requests must route to selected Puter vendor');
assert.match(html, /stream:true,signal/, 'Puter requests must use stream options and cancellation signal');
assert.match(html, /part\?\.type==='error'/, 'stream error chunks must not be mistaken for successful empty output');
assert.match(html, /releaseVilaChatAbortController\(controller\)/, 'Puter request controllers should be released');
assert.match(activity, /setSupportMultipleWindows\(true\)/, 'Android WebView should support Puter authentication popups');
assert.match(activity, /onCreateWindow\(WebView parent/, 'authentication popup window should be handled in the app');
console.log('PASS: V56 Puter all-provider catalog, provider routing, cancellation/error handling and authentication popup checks.');
