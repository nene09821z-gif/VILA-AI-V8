#!/usr/bin/env node
'use strict';
// V57: per-model Puter profiles, request rules, fallback and error classification.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');

function slice(from, to) {
  const a = html.indexOf(from), b = html.indexOf(to, a);
  assert.ok(a >= 0 && b > a, `missing block ${from}`);
  return html.slice(a, b);
}
const catalogSrc = slice('// ===== Puter per-model profiles (V57)', 'async function listProviderModels(provider,key,base)');
const runtimeSrc = slice('// ===== Puter runtime (V57)', 'async function requestActiveProvider(messages)');
const store = {};
const sandbox = {
  localStorage: { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } },
  PROVIDERS: { puter: { models: [] } }, Date, JSON, Math, Set, Number, String, Array, Object,
  getResponseTokenBudget: () => 12288, getLatestUserText: () => '', classifyTaskForModel: () => 'chat',
  vilaCreativeTemperature: () => 0, isVilaFastMode: () => false, reasoningLevel: 'medium',
  showToast() {}, setAiStatus() {}, createVilaChatAbortController() {}, releaseVilaChatAbortController() {},
};
vm.createContext(sandbox);
vm.runInContext(catalogSrc + '\n' + runtimeSrc, sandbox, { timeout: 2000 });
const run = code => vm.runInContext(code, sandbox);
const P = (vendor, id, meta) => JSON.parse(JSON.stringify(run(`puterModelProfile(${JSON.stringify(vendor)},${JSON.stringify(id)},'',${JSON.stringify(meta || {})})`)));

// ---- families
assert.equal(P('claude', 'claude-opus-4-8').family, 'claude');
assert.equal(P('anthropic', 'whatever').family, 'claude', 'legacy vendor name must still map to Claude');
assert.equal(P('openai', 'gpt-5.6-luna').family, 'openai');
assert.equal(P('openai', 'gpt-oss-120b').family, 'gptoss', 'open-weight gpt-oss is not an OpenAI reasoning API model');
assert.equal(P('openrouter', 'openrouter:anthropic/claude-3.5-sonnet').family, 'claude', 'family comes from the model id, not the router');
assert.equal(P('google', 'gemini-2.5-flash').family, 'gemini');
assert.equal(P('x-ai', 'grok-4').family, 'grok');
assert.equal(P('meta', 'llama-4-maverick').family, 'llama');

// ---- tiers must not be fooled by substrings (minimax is not "mini"/"max")
assert.equal(P('minimax', 'minimax-m2').tier, 'balanced');
assert.equal(P('claude', 'claude-haiku-4-5').tier, 'fast');
assert.equal(P('claude', 'claude-opus-4-8').tier, 'flagship');
assert.equal(P('openai', 'gpt-4o-mini').tier, 'fast');
assert.equal(P('google', 'gemini-2.5-pro').tier, 'flagship');

// ---- vision: declared metadata wins, then family knowledge, unknown stays null
assert.equal(P('claude', 'claude-opus-4-8').vision, true);
assert.equal(P('claude', 'claude-2.1').vision, false);
assert.equal(P('openai', 'gpt-4o').vision, true);
assert.equal(P('openai', 'o3').vision, true);
assert.equal(P('openai', 'o3-mini').vision, false);
assert.equal(P('openai', 'o1-mini').vision, false);
assert.equal(P('openai', 'gpt-3.5-turbo').vision, false);
assert.equal(P('openai', 'gpt-oss-20b').vision, false);
assert.equal(P('x', 'some-model', { input_modalities: ['text'] }).vision, false, 'declared text-only must win');
assert.equal(P('x', 'some-model', { modalities: { input: ['text', 'image'] } }).vision, true);
assert.equal(P('qwen', 'qwen3-vl-235b').vision, true);
assert.equal(P('mistral', 'pixtral-large').vision, true);
assert.equal(P('qwen', 'qwen3-32b').vision, null, 'unknown capability must not be claimed or blocked');

// ---- reasoning and per-model request rules
const o3 = P('openai', 'o3');
assert.equal(o3.reasoning, true); assert.equal(o3.temperature, false, 'OpenAI reasoning models never get temperature');
assert.equal(o3.effortParam, true);
const gpt5chat = P('openai', 'gpt-5-chat');
assert.equal(gpt5chat.reasoning, false); assert.equal(gpt5chat.temperature, true);
const opus = P('claude', 'claude-opus-4-8');
assert.equal(opus.reasoning, true); assert.equal(opus.effortParam, false, 'reasoning_effort is OpenAI/Muse only');
assert.equal(opus.temperature, true);
assert.equal(P('openai', 'gpt-4o').reasoning, false);
assert.equal(P('openai', 'gpt-5.4').verbosity, true);
assert.equal(P('claude', 'claude-opus-4-8').verbosity, false);
assert.equal(P('meta', 'muse-spark').effortParam, true);

// ---- non-chat models are excluded from the catalog
const cat = JSON.parse(JSON.stringify(run(`normalizePuterCatalogEntries(${JSON.stringify([
  { id: 'claude-opus-4-8', provider: 'claude', context: 200000, max_tokens: 64000 },
  { id: 'claude-haiku-4-5', provider: 'claude' },
  { id: 'claude-opus-4-10', provider: 'claude' },
  { id: 'text-embedding-3-large', provider: 'openai' },
  { id: 'gpt-image-1', provider: 'openai' },
  { id: 'whisper-1', provider: 'openai' },
  { id: 'gemini-3-pro-image-preview', provider: 'google' },
  { id: 'gpt-5.4', provider: 'openai' },
])})`)));
assert.deepEqual(cat.map(m => m.puterModelId), ['claude-opus-4-10', 'claude-opus-4-8', 'claude-haiku-4-5', 'gpt-5.4'],
  'non-chat models dropped; newest flagship first; fast tier last; 4.10 sorts above 4.8');
assert.equal(cat[0].profile.family, 'claude');
assert.equal(cat[0].family, 'claude');

// ---- request building honours the profile
const entry = id => ({ id: 'puter:openai:' + id, puterModelId: id, puterProvider: 'openai', maxOutputTokens: 0 });
let o = JSON.parse(JSON.stringify(run(`buildPuterOptions(${JSON.stringify(entry('o3'))},[],null)`)));
assert.equal(o.model, 'o3'); assert.equal(o.provider, 'openai'); assert.equal(o.temperature, undefined);
assert.equal(o.reasoning_effort, 'medium'); assert.ok(o.max_tokens >= 16384, 'reasoning models need token headroom');
o = JSON.parse(JSON.stringify(run(`buildPuterOptions(${JSON.stringify({ id: 'puter:claude:claude-opus-4-8', puterModelId: 'claude-opus-4-8', puterProvider: 'claude', maxOutputTokens: 4096 })},[],null)`)));
assert.equal(o.reasoning_effort, undefined); assert.equal(o.max_tokens, 4096, 'token budget is capped by the model limit');
o = JSON.parse(JSON.stringify(run(`buildPuterOptions(${JSON.stringify({ id: 'puter:anthropic:claude-opus-4-8', puterModelId: 'claude-opus-4-8', puterProvider: 'anthropic' })},[],null)`)));
assert.equal(o.provider, undefined, 'legacy fallback entry must not pin an invalid provider');
o = JSON.parse(JSON.stringify(run(`buildPuterOptions(${JSON.stringify({ id: 'puter:unknown:x', puterModelId: 'x', puterProvider: 'unknown' })},[],null)`)));
assert.equal(o.provider, undefined);

// ---- error classification
const k = m => run(`classifyPuterError(${JSON.stringify({ message: m })})`);
assert.equal(k('429 Too Many Requests'), 'quota');
assert.equal(k('insufficient credits'), 'quota');
assert.equal(k('401 Unauthorized'), 'auth');
assert.equal(k('Model not found: foo'), 'model');
assert.equal(k('upstream overloaded (529)'), 'transient');
assert.equal(k('Failed to fetch'), 'network');
assert.equal(k('request timed out'), 'timeout');
assert.equal(k('blocked by content filter'), 'safety');
assert.equal(run(`classifyPuterError({name:'AbortError',message:'x'})`), 'abort');
assert.equal(run(`classifyPuterError({code:'network_error',message:'x'})`), 'network');
assert.equal(run(`classifyPuterError({code:'request_timeout',message:'x'})`), 'timeout');

// ---- fallback selection: same family for text, any vision-capable model for images, never a cooling model
const models = cat.concat([{ id: 'puter:openai:gpt-3.5', puterModelId: 'gpt-3.5', puterProvider: 'openai', name: 'old' }]);
run(`PROVIDERS.puter.models=${JSON.stringify(models)}`);
const target = cat.find(m => m.puterModelId === 'claude-opus-4-8');
let alt = run(`pickPuterFallback(${JSON.stringify(target)},{needVision:false,exclude:new Set()})`);
assert.equal(alt.family, 'claude', 'text fallback stays within the family');
assert.notEqual(alt.puterModelId, 'claude-opus-4-8');
const textOnly = { id: 'puter:openai:gpt-3.5', puterModelId: 'gpt-3.5', puterProvider: 'openai' };
alt = run(`pickPuterFallback(${JSON.stringify(textOnly)},{needVision:true,exclude:new Set()})`);
assert.equal(alt.profile.vision, true, 'a text-only model falls back to a vision-capable one for images');
run(`recordPuterOutcome(${JSON.stringify(cat.find(m => m.puterModelId === 'claude-opus-4-10'))},false,0,'model')`);
alt = run(`pickPuterFallback(${JSON.stringify(target)},{needVision:false,exclude:new Set()})`);
assert.equal(alt.puterModelId, 'claude-haiku-4-5', 'a model reported missing is skipped');
assert.equal(run(`puterModelCoolingDown(${JSON.stringify(cat.find(m => m.puterModelId === 'claude-opus-4-10'))})`), true);

// ---- source-level wiring
assert.match(html, /for\(let attempt=0;attempt<4;attempt\+\+\)/, 'bounded retry/fallback loop');
assert.match(html, /stallMs=profile\.reasoning\?240000:90000/, 'stalled streams are cut per model class');
assert.match(html, /Gửi "tiếp tục" để nhận phần còn lại/, 'partial replies are kept instead of retried');
console.log('PASS: V57 per-model Puter profiles, request rules, error classes and fallback selection.');
