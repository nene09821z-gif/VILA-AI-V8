'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');

assert.ok(html.includes("local: { name:'Local AI (llama.cpp / Ollama / OpenAI-compatible)'"), 'Generic local preset must exist');
assert.ok(html.includes('window.listProviderModels = listProviderModels;'), 'Gateway console must have access to the model-list scanner');
assert.ok(html.includes('window.persistProviderModelCatalog = function(provider, models)'), 'Gateway console must have access to the catalog persistence bridge');
assert.ok(html.includes("provider!=='openrouter' && provider!=='local'"), 'Local model catalog discovery must not require an API key');
assert.ok(html.includes("if(!key && provider!=='local')"), 'Keyless local chat must be allowed while cloud APIs retain key checks');
assert.ok(html.includes("if(testKey)testHeaders.Authorization=`Bearer ${testKey}`"), 'Keyless local tests must not send an empty Authorization header');
assert.ok(html.includes("const ids=['gemini','groq','cerebras','openrouter','local','custom']"), 'Local model endpoint must appear in Gateway diagnostics');
assert.ok(html.includes("(p.id==='local'&&p.base)"), 'Quick scans must include a local model server without an API key');
assert.ok(html.includes("deep&&(p.key||p.id==='local')"), 'Deep scans must be able to send a test prompt to a keyless local model');
assert.ok(workflow.includes('node scripts/test-v51-local-connector.js'), 'CI must run the V51 local connector regression');
console.log('PASS: generic local model discovery, Gateway helper bridge, keyless chat, and diagnostic scans.');
