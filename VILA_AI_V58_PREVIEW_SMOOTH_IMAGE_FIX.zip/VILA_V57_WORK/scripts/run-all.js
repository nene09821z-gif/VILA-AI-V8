'use strict';
// Chạy toàn bộ kiểm tra: test Gateway + mọi script trong thư mục scripts/.
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const jobs = [['node', ['--test', ...fs.readdirSync(path.join(root, 'server/test')).filter(f => f.endsWith('.test.js')).map(f => 'server/test/' + f)]]];
for (const f of fs.readdirSync(__dirname).sort()) {
  if (f.endsWith('.js') && f !== 'run-all.js') jobs.push(['node', [path.join('scripts', f)]]);
}
let failed = 0;
for (const [cmd, args] of jobs) {
  const r = spawnSync(cmd, args, { cwd: root, encoding: 'utf8' });
  const ok = r.status === 0;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${args.join(' ')}`);
  if (!ok) { failed++; console.log((r.stdout + r.stderr).split('\n').filter(l => !/^\s+at /.test(l)).slice(-12).join('\n')); }
}
console.log(failed ? `\n${failed} nhóm kiểm tra lỗi` : `\nTất cả ${jobs.length} nhóm kiểm tra đều đạt`);
process.exit(failed ? 1 : 0);
