#!/usr/bin/env node
'use strict';
// Regression test for the V56 fix to formatMarkdownText(): prose OUTSIDE fenced code blocks is
// model/web output (untrusted — can carry prompt-injected HTML) and is inserted via innerHTML, so it
// must be HTML-escaped exactly like fenced code already was. Without this, a reply containing
// "<img src=x onerror=...>" outside a code fence executed in the WebView, which exposes the native
// Android bridge (Firebase login, etc.) via window.Android — see appendAiMessage()/formatMarkdownText().
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');

const escStart = html.indexOf('function escapeHtml(str) {');
const escEnd = html.indexOf('/* Viewport Switching */', escStart);
assert.ok(escStart >= 0 && escEnd > escStart, 'escapeHtml must be present and bounded');

const fmtStart = html.indexOf('function formatMarkdownText(text) {');
const fmtEnd = html.indexOf('window.downloadCodeBlock = function', fmtStart);
assert.ok(fmtStart >= 0 && fmtEnd > fmtStart, 'formatMarkdownText must be present and bounded');

const source = html.slice(escStart, escEnd) + '\n' + html.slice(fmtStart, fmtEnd) +
  '\nthis.escapeHtml = escapeHtml; this.formatMarkdownText = formatMarkdownText;';
const sandbox = {};
vm.runInNewContext(source, sandbox, { timeout: 1000 });

// Prose outside a code fence must never reach the DOM as live markup.
const injected = sandbox.formatMarkdownText('Xin chào <img src=x onerror="alert(1)"> bạn');
assert.doesNotMatch(injected, /<img/i, 'an HTML tag in plain prose must be escaped, not rendered');
assert.match(injected, /&lt;img/i, 'the escaped form of the injected tag must be present');

const scripted = sandbox.formatMarkdownText('trước <script>fetch(1)</script> sau');
assert.doesNotMatch(scripted, /<script/i, 'a <script> tag in plain prose must be escaped, not rendered');

// Fenced code must still render as a visible, escaped code block (existing behavior, unchanged).
const withCode = sandbox.formatMarkdownText('Đây là code:\n```js\nconsole.log("<b>hi</b>")\n```\nXong.');
assert.match(withCode, /<pre class="p-4/, 'a fenced code block must still render as a code card');
assert.match(withCode, /&lt;b&gt;hi&lt;\/b&gt;/, 'code block content must still be escaped as before');
assert.doesNotMatch(withCode, /<b>hi<\/b>/, 'code block content must never render as live HTML');

// Prose surrounding a code block must also be escaped and still line-break on \n.
const mixed = sandbox.formatMarkdownText('a <i>x</i>\n```txt\nraw\n```\nb <i>y</i>');
assert.doesNotMatch(mixed.replace(/<pre[\s\S]*?<\/pre>/, ''), /<i>/, 'prose around a code block must be escaped');
assert.match(mixed, /a &lt;i&gt;x&lt;\/i&gt;<br>/, 'prose before a code block keeps newline-to-<br> conversion');

console.log('PASS: V56 formatMarkdownText escapes untrusted prose (code blocks still render as before).');

// V57: light markdown rendering must stay inside the same safety guarantee.
const md = sandbox.formatMarkdownText('## Tiêu đề\n**đậm** và *nghiêng* và `code <b>`\n- mục một\n[VILA](https://example.com/a?x=1&y=2)');
assert.match(md, /<strong[^>]*>Tiêu đề<\/strong>/, 'headings render');
assert.match(md, /<strong>đậm<\/strong>/, 'bold renders');
assert.match(md, /<em>nghiêng<\/em>/, 'italic renders');
assert.match(md, /<code[^>]*>code &lt;b&gt;<\/code>/, 'inline code is escaped');
assert.match(md, /\u2022 mục một/, 'bullets render');
assert.match(md, /<a href="https:\/\/example\.com\/a\?x=1&amp;y=2" rel="noopener noreferrer nofollow"/, 'https links render with escaped query');
const evil = sandbox.formatMarkdownText('[x](javascript:alert(1)) [y](https://a.com/"onmouseover="alert(1)) **<img src=x onerror=1>** `<script>`');
assert.doesNotMatch(evil, /href="javascript:/i, 'javascript: links are never produced');
assert.doesNotMatch(evil, /<img|<script|onmouseover="/i, 'no live markup or attribute injection through markdown');
assert.equal(sandbox.formatMarkdownText('2*3*4 và a * b * c'), '2*3*4 và a * b * c', 'math-like asterisks are untouched');
assert.doesNotMatch(sandbox.formatMarkdownText('x \u0000 0 \u0000 y'), /\u0000/, 'NUL placeholders cannot be forged');
console.log('PASS: V57 safe markdown rendering (headings, emphasis, code, bullets, https links).');
