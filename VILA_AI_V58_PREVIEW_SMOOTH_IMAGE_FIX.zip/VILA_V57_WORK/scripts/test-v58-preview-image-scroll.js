'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const htmlPath = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');

function extractBetween(start, end) {
  const a = html.indexOf(start);
  const b = html.indexOf(end, a);
  assert.notEqual(a, -1, `missing source marker: ${start}`);
  assert.notEqual(b, -1, `missing source marker: ${end}`);
  return html.slice(a, b);
}

const normalizeSource = extractBetween('        function normalizeVilaImagePayload(image){', '        function getVilaImageAspectRatio()');
const normContext = {};
vm.runInNewContext(normalizeSource + '\nthis.normalizeVilaImagePayload = normalizeVilaImagePayload;', normContext);
const normalize = normContext.normalizeVilaImagePayload;

const png = normalize({ data: 'data:image/jpeg;base64,iVBORw0KGgoAAAA', mime: 'image/jpeg' });
assert.equal(png.mime, 'image/png', 'PNG magic bytes should override a wrong endpoint MIME label');
assert.match(png.data, /^[A-Za-z0-9+/]+={0,2}$/);
assert.equal(png.data.length % 4, 0, 'base64 should be padded correctly');
const jpeg = normalize({ data: '/9j/4AAQ-_', mime: 'image/jpg' });
assert.equal(jpeg.mime, 'image/jpeg');
assert.ok(!jpeg.data.includes('-') && !jpeg.data.includes('_'), 'base64url characters should be normalized');
assert.throws(() => normalize({ data: 'not valid image !' }), /Base64/);

const previewSource = extractBetween('        function getPreviewType(code, hint) {', '        function setPreviewBadge(type, state) {');
function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
const previewContext = {
  escapeHtml,
  withStorageShim: (source) => source,
  JSON,
};
vm.runInNewContext(previewSource + '\nthis.preview = { getPreviewType, renderMarkdownPreview, buildPreviewDocument };', previewContext);
const preview = previewContext.preview;
assert.equal(preview.getPreviewType('<svg viewBox="0 0 1 1"></svg>', ''), 'svg');
assert.equal(preview.getPreviewType('const x = 1;', 'javascript'), 'js');
assert.equal(preview.getPreviewType('{"ok":true}', ''), 'json');
assert.equal(preview.getPreviewType('# Title\n\nSome text', ''), 'markdown');
const md = preview.buildPreviewDocument('# Tiêu đề\n\n<script>alert(1)</script>\n\n- mục', 'markdown');
assert.match(md, /<h1>Tiêu đề<\/h1>/);
assert.match(md, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/, 'Markdown preview should escape HTML input');
assert.match(md, /<li>mục<\/li>/);
const jsDoc = preview.buildPreviewDocument('console.log("$&");', 'js');
assert.match(jsDoc, /<script>/);
assert.match(jsDoc, /<\/script><\/body><\/html>/, 'JS preview document should have a real closing script tag');
assert.match(jsDoc, /console\.log/);

assert.doesNotMatch(html, /img\s*\{\s*content-visibility\s*:\s*auto/i, 'avoid WebView image painting regression');
assert.match(html, /event\.target\.tagName==='IMG'/, 'late image loads should trigger scroll settling');
assert.match(html, /function ensurePreviewDiagnostics\(/, 'preview should surface runtime errors');
assert.match(html, /<think>\(\[\\s\\S\]\*\?\)<\\\/think>/i, 'reasoning chunks should use a non-greedy extraction pattern');
console.log('V58 preview multi-format, image normalization, reasoning markup and scroll checks passed');
