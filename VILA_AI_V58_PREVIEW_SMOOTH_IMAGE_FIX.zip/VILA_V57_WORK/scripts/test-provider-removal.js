#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const forbidden = 'deep' + 'seek';
const ignoredDirs = new Set(['.git', 'node_modules', '.gradle', 'build', 'output']);
const binaryExts = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.ico', '.keystore', '.jar', '.class', '.wasm', '.apk', '.zip', '.pdf']);
const hits = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory() && ignoredDirs.has(entry.name)) continue;
    const file = path.join(dir, entry.name);
    const relative = path.relative(root, file).split(path.sep).join('/');
    if (relative.toLowerCase().includes(forbidden)) hits.push(`${relative} [path]`);
    if (entry.isDirectory()) { walk(file); continue; }
    if (!entry.isFile() || binaryExts.has(path.extname(entry.name).toLowerCase())) continue;
    const content = fs.readFileSync(file).toString('utf8').toLowerCase();
    if (content.includes(forbidden)) hits.push(`${relative} [content]`);
  }
}
walk(root);
if (hits.length) {
  console.error('FAIL: removed provider still referenced:');
  for (const hit of hits) console.error(` - ${hit}`);
  process.exit(1);
}
console.log('PASS: no removed-provider names, paths, UI controls, config keys, adapters, or Android bridge references remain.');
