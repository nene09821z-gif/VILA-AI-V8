#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
assert.match(html, /<div id="vilaStartup" class="hidden"/, 'startup configuration chooser must remain hidden');
assert.match(html, /function initVilaStartup\(\)[\s\S]*?closeStartup\(\)/, 'startup initialization must close without provider selection');
assert.match(html, /puter\.ai\.listModels\(\)/, 'live catalog should use Puter all-model discovery');
assert.match(html, /puterCatalogSearch/, 'catalog search should be wired into the model dropdown');
assert.match(html, /const cached=VILA_MODEL_CATALOGS\.puter\?\.models/, 'failed discovery should fall back to a previous valid catalog');
assert.match(html, /Puter AI Hub/, 'Puter should be independently discoverable in the UI');
assert.match(html, /if\(activeProvider==='puter'\) setTimeout\(\(\)=>refreshProviderModels/, 'selected Puter provider should refresh on launch');
assert.match(html, /window\.puter\.ai\.chat\(prepared\.chatMessages,false,options\)/, 'chat must use the documented messages overload');

// Execute the catalog normalizer in isolation with representative API responses.
const start = html.indexOf('// ===== Puter per-model profiles (V57)');
const end = html.indexOf('async function listProviderModels(provider,key,base)', start);
assert.ok(start >= 0 && end > start, 'catalog normalizer must be present and bounded');
const helperSource = html.slice(start, end) + '\nthis.normalizePuterCatalogEntries = normalizePuterCatalogEntries;';
const sandbox = {};
vm.runInNewContext(helperSource, sandbox, { timeout: 1000 });
const normalized = sandbox.normalizePuterCatalogEntries([
  { id: 'claude-opus-4-8', provider: 'anthropic', name: 'Claude Opus 4.8', context: 200000, max_tokens: 64000, cost: { currency: 'usd-cents', input: 500, output: 2500, tokens: 1000000 } },
  { id: 'claude-opus-4-8', provider: 'anthropic', name: 'Duplicate entry', context: 200000 },
  { id: 'gpt-5.6-luna', provider: 'openai', name: 'GPT Luna', context: 100000 },
  { id: 'hidden-model', provider: 'other', active: false },
  { id: 'vision-model', provider: 'xai', supports_images: true }
]);
assert.equal(normalized.length, 3, 'duplicate and inactive entries must be removed');
assert.equal(new Set(normalized.map(m => m.id)).size, 3, 'normalized model IDs must be unique');
assert.equal(normalized[0].id, 'puter:anthropic:claude-opus-4-8', 'Claude model should be provider-scoped and preferred');
assert.equal(normalized[0].puterModelId, 'claude-opus-4-8', 'raw API model ID must be preserved for requests');
assert.equal(normalized[0].puterProvider, 'anthropic', 'raw provider must be preserved for requests');
assert.equal(normalized[0].contextLength, 200000, 'context metadata must be retained');
assert.equal(normalized[0].maxOutputTokens, 64000, 'output token metadata must be retained');
assert.equal(normalized[0].cost.input, 500, 'cost metadata must be retained');
assert.equal(normalized.find(m => m.puterModelId === 'vision-model').supportsImages, true, 'declared image capability must be retained');
assert.deepEqual(Array.from(sandbox.normalizePuterCatalogEntries(null)), [], 'invalid catalog responses must fail safely');
console.log('PASS: V56 startup, live Puter AI Hub catalog, search/fallback, and runtime catalog normalization.');
