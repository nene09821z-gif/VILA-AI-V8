# Puter AI Hub trong VILA

VILA tích hợp Puter.js như một provider độc lập. Khi khả dụng, `puter.ai.listModels()` tải danh mục chat thực tế của Puter gồm nhiều nhà cung cấp; VILA không tạo danh sách hàng trăm model giả. Danh mục được lưu cục bộ để dùng làm cache khi mất mạng, nhưng model cũ có thể bị ngừng hoặc từ chối bởi dịch vụ.

## Cách sử dụng

1. Mở **Cài đặt → Puter AI Hub**.
2. Nhấn **Tải model mới nhất từ API** hoặc chờ danh mục tự đồng bộ.
3. Dùng ô tìm kiếm để lọc theo tên model hoặc provider, rồi chọn model ở bộ chọn trên thanh đầu.
4. Nhấn **Kiểm tra kết nối** để gửi một yêu cầu thử nghiệm ngắn. Chấp nhận đăng nhập Puter nếu được yêu cầu.

Puter.js tự quản lý endpoint; không cần nhập API key Anthropic/Puter vào VILA. Điều đó không đảm bảo miễn phí vô hạn. Quyền truy cập, quota, rate limit và chi phí nếu có phụ thuộc tài khoản và chính sách Puter.

## Ảnh và hội thoại

Ảnh của lượt hiện tại được truyền riêng như media cùng ngữ cảnh văn bản. Những ảnh ở các lượt cũ không tự được tải lại. Không phải model trong catalog nào cũng hỗ trợ ảnh; quyền hỗ trợ thực tế do model/provider quyết định.

## Chế độ dự phòng và lỗi

- Nếu catalog trực tiếp không tải được, VILA giữ catalog hợp lệ cuối cùng trong cache; nếu chưa từng tải thì chỉ dùng một model dự phòng được ghi trong tài liệu công khai.
- **Puter.js chưa tải:** kiểm tra Internet và quyền tải `https://js.puter.com/v2/`.
- **Đăng nhập/popup:** hoàn tất đăng nhập Puter trong cửa sổ xác thực.
- **Model không khả dụng:** tải lại catalog hoặc chọn model khác đang được công bố.
- **429/quota:** đó là giới hạn của dịch vụ; đổi URL hay bỏ xác thực không thể sửa được.

VILA không vượt qua xác thực, quota hoặc kiểm soát truy cập của Puter hay nhà cung cấp model.

## Hồ sơ năng lực từng model (V57)

Mỗi model trong catalog có một hồ sơ (họ, bậc, ảnh, suy luận) lấy từ metadata Puter trước, rồi từ họ model. Hồ sơ quyết định tham số gửi đi:

| Họ model | Tham số đặc biệt |
|---|---|
| OpenAI suy luận (o-series, GPT-5/6) | Không gửi `temperature`; gửi `reasoning_effort` theo mức suy luận; GPT-5/6 thêm `verbosity: low` ở chế độ nhanh |
| Meta Muse Spark | Gửi `reasoning_effort` |
| Claude, Gemini, Grok, Llama, Qwen, Mistral… | Chỉ `max_tokens` (và `temperature` cho tác vụ sáng tạo/code) |

`max_tokens` = ngân sách theo tác vụ, bị chặn bởi giới hạn đầu ra của chính model; model suy luận có tối thiểu 16.384 để còn chỗ cho token suy nghĩ.

Biểu tượng trong danh sách: 👁 đọc được ảnh, 🧠 suy luận, ⚡ bản nhanh, ⚠ vừa lỗi nên tạm bị bỏ qua khi tự chuyển model. Model chưa rõ khả năng ảnh vẫn được thử; model đã biết là không đọc ảnh sẽ tự chuyển sang model có 👁.

Khi lỗi tạm thời (mạng, quá tải, timeout, đứt luồng) VILA thử lại một lần; nếu model không khả dụng thì chuyển sang model cùng họ. Lỗi đăng nhập, quota và chính sách nội dung không bao giờ bị "né" bằng cách đổi model.
