'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { ProviderCircuitBreaker } = require('../src/reliability');
const { rankProviders, performanceAdjustment } = require('../src/engine');

test('breaker tracks EWMA latency and success rate per provider', () => {
  const cb = new ProviderCircuitBreaker({ failureThreshold: 99 });
  assert.equal(cb.performance('a').samples, 0);
  for (let i = 0; i < 5; i++) cb.success('a', '', 400);
  const p = cb.performance('a');
  assert.equal(p.samples, 5); assert.equal(p.successRate, 1); assert.equal(p.latencyMs, 400);
  cb.failure('a', { retryable: true, status: 503 });
  assert.ok(cb.performance('a').successRate < 1);
  assert.ok(cb.snapshot('a').performance.samples === 6);
});

test('non-retryable client errors do not count against provider reliability', () => {
  const cb = new ProviderCircuitBreaker();
  cb.failure('a', { retryable: false, status: 400 });
  assert.equal(cb.performance('a').samples, 0);
});

test('performanceAdjustment ignores thin data and is bounded', () => {
  assert.equal(performanceAdjustment({ samples: 2, successRate: 0, latencyMs: 99999 }), 0);
  assert.equal(performanceAdjustment(null), 0);
  const best = performanceAdjustment({ samples: 50, successRate: 1, latencyMs: 100 });
  const worst = performanceAdjustment({ samples: 50, successRate: 0, latencyMs: 60000 });
  assert.ok(best > 0 && best <= 20); assert.ok(worst < 0 && worst >= -30);
});

test('ranking prefers the faster, more reliable of two otherwise equal providers', () => {
  const mk = (id, perf) => ({ id, configured: true, model: 'm', perf });
  const slow = mk('together', { samples: 20, successRate: 0.7, latencyMs: 9000 });
  const fast = mk('fireworks', { samples: 20, successRate: 1, latencyMs: 300 });
  assert.equal(rankProviders([slow, fast], 'general')[0].id, 'fireworks');
  // static affinity still wins when stats are missing
  assert.equal(rankProviders([mk('mistral'), mk('groq')], 'general')[0].id, 'groq');
});
