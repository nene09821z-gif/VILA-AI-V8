'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'); const os = require('node:os'); const path = require('node:path');
const web = require('../src/tools/web');
const store = require('../src/tools/store');
const { runCode } = require('../src/tools/sandbox');
const { getToolDefinitions, runAgentTool } = require('../src/tools');

const pub = async () => [{ address: '93.184.216.34' }];
const resp = (status, body, headers = {}) => new Response(body, { status, headers });

test('isBlockedIp blocks private, loopback, link-local, mapped and metadata ranges', () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '172.20.0.1', '192.168.1.1', '169.254.169.254', '100.64.0.1', '0.0.0.0', '::1', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1', '::ffff:7f00:1']) assert.equal(web.isBlockedIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '93.184.216.34', '2606:4700::1111']) assert.equal(web.isBlockedIp(ip), false, ip);
});
test('isBlockedIp decodes 6to4 and Teredo IPv6 tunnels instead of trusting the outer literal', () => {
  // 6to4 (2002::/16): hextets 1-2 are the IPv4 address in cleartext.
  for (const ip of ['2002:7f00:1::', '2002:a00:1::', '2002:c0a8:1::']) assert.equal(web.isBlockedIp(ip), true, ip); // 127/10/192.168
  assert.equal(web.isBlockedIp('2002:0203:0405::'), false); // 2.3.4.5 is public
  // Teredo (2001:0::/32): last two hextets are the client IPv4, XORed with 0xffff per half.
  assert.equal(web.isBlockedIp('2001:0:1234:5678:1234:5678:80ff:fffe'), true); // 127.0.0.1
  assert.equal(web.isBlockedIp('2001:0:1234:5678:1234:5678:f5ff:fffe'), true); // 10.0.0.1
  assert.equal(web.isBlockedIp('2001:0:1234:5678:1234:5678:f7ff:f7f7'), false); // 8.8.8.8 is public
});
test('assertPublicUrl rejects bad schemes, creds, ports, internal names and private DNS results', async () => {
  for (const u of ['file:///etc/passwd', 'ftp://x.com', 'http://user:pw@x.com', 'http://x.com:22', 'http://localhost/', 'http://svc.internal/', 'http://127.0.0.1/', 'http://[::1]/', 'http://2130706433/']) await assert.rejects(() => web.assertPublicUrl(u, { lookup: pub }), u);
  await assert.rejects(() => web.assertPublicUrl('http://evil.example/', { lookup: async () => [{ address: '10.0.0.5' }] }));
  await assert.rejects(() => web.assertPublicUrl('http://mixed.example/', { lookup: async () => [{ address: '8.8.8.8' }, { address: '127.0.0.1' }] }));
});
test('safeFetch re-validates every redirect hop (redirect to metadata IP is blocked)', async () => {
  const f = async (u) => u.startsWith('http://a.example') ? resp(302, '', { location: 'http://169.254.169.254/latest/meta-data' }) : resp(200, 'secret');
  await assert.rejects(() => web.safeFetch('http://a.example/', { fetchImpl: f, lookup: pub }), /SSRF|nội bộ/);
});
test('safeFetch caps response size and redirect count', async () => {
  const big = async () => resp(200, 'x'.repeat(5000));
  const r = await web.safeFetch('http://a.example/', { fetchImpl: big, lookup: pub, maxBytes: 1000 });
  assert.equal(r.body.length, 1000); assert.equal(r.truncated, true);
  const loop = async () => resp(302, '', { location: 'http://a.example/' });
  await assert.rejects(() => web.safeFetch('http://a.example/', { fetchImpl: loop, lookup: pub }), /chuyển hướng/);
});
test('webFetch extracts readable text, drops scripts, and flags content untrusted', async () => {
  const html = '<html><head><title>Hi &amp; bye</title><script>evil()</script></head><body><h1>Tiêu đề</h1><p>Xin chào<br>thế giới</p><style>.a{}</style></body></html>';
  const r = await web.webFetch({ url: 'https://a.example/' }, { fetchImpl: async () => resp(200, html, { 'content-type': 'text/html; charset=utf-8' }), lookup: pub });
  assert.equal(r.title, 'Hi & bye'); assert.match(r.content, /Tiêu đề/); assert.doesNotMatch(r.content, /evil|\.a\{/); assert.equal(r.untrusted, true);
  await assert.rejects(() => web.webFetch({ url: 'https://a.example/x.png' }, { fetchImpl: async () => resp(200, 'x', { 'content-type': 'image/png' }), lookup: pub }), /không hỗ trợ/);
});
test('webSearch uses Tavily/Brave/SearXNG when configured and parses DuckDuckGo HTML fallback', async () => {
  let seen;
  const tav = await web.webSearch({ query: 'vila', max_results: 2 }, { fetchImpl: async (u, i) => { seen = [u, i]; return Response.json({ results: [{ title: 'T', url: 'https://t.example', content: 'c' }] }); } }, { TAVILY_API_KEY: 'k' });
  assert.equal(tav.engine, 'tavily'); assert.equal(seen[1].headers.Authorization, 'Bearer k'); assert.equal(tav.results[0].url, 'https://t.example');
  const br = await web.webSearch({ query: 'q' }, { fetchImpl: async () => Response.json({ web: { results: [{ title: 'B', url: 'https://b.example', description: '<b>d</b>' }] } }) }, { BRAVE_API_KEY: 'k' });
  assert.equal(br.results[0].snippet, 'd');
  const ddg = '<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fp&rut=1">Example <b>Org</b></a><a class="result__snippet" href="x">A &amp; B</a>';
  const d = await web.webSearch({ query: 'q' }, { fetchImpl: async () => new Response(ddg) }, {});
  assert.equal(d.results[0].url, 'https://example.org/p'); assert.equal(d.results[0].title, 'Example Org'); assert.equal(d.results[0].snippet, 'A & B');
  await assert.rejects(() => web.webSearch({ query: '' }, {}, {}));
});
test('memory and document search rank relevant text and isolate users', () => {
  const env = { VILA_DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'vila-t-')) };
  store.memorySave('u1', { text: 'Người dùng thích cà phê sữa đá' }, env); store.memorySave('u1', { text: 'Thủ đô của Pháp là Paris' }, env);
  assert.match(store.memorySearch('u1', { query: 'cà phê' }, env).results[0].text, /cà phê/);
  assert.equal(store.memorySearch('u2', { query: 'cà phê' }, env).results.length, 0);
  const id = store.memorySearch('u1', { query: 'Paris' }, env).results[0].id; assert.equal(store.memoryDelete('u1', { id }, env).deleted, 1);
  store.docAdd('u1', { name: 'a.txt', text: 'Hợp đồng thuê nhà có thời hạn 12 tháng.\n\nTiền cọc là hai tháng tiền nhà.' }, env);
  store.docAdd('u1', { name: 'b.txt', text: 'Công thức nấu phở bò cần xương ống và quế hồi.' }, env);
  const r = store.docSearch('u1', { query: 'tiền cọc nhà' }, env).results; assert.equal(r[0].doc, 'a.txt');
  assert.equal(store.docSearch('u2', { query: 'phở' }, env).results.length, 0);
  assert.throws(() => store.docAdd('u1', { name: 'x', text: 'a'.repeat(400001) }, env));
});
test('registry exposes extra tools by flag and rejects unknown/disabled ones', async () => {
  const names = e => getToolDefinitions(e).map(t => t.function.name);
  assert.ok(names({}).includes('vila_web_fetch') && names({}).includes('vila_memory_save'));
  assert.ok(!names({}).includes('vila_run_code')); assert.ok(names({ VILA_ENABLE_CODE_EXEC: 'true' }).includes('vila_run_code'));
  assert.ok(!names({ VILA_TOOL_WEB: 'false' }).includes('vila_web_search'));
  assert.ok(getToolDefinitions({}).every(t => t.function.parameters.additionalProperties === false));
  assert.equal((await runAgentTool('vila_run_code', { language: 'python', code: '1' }, { env: {} })).out.ok, false);
  assert.equal((await runAgentTool('bash', {}, {})).out.ok, false);
  const r = await runAgentTool('vila_calculate', { expression: '2+2' }, {}); assert.equal(r.out.result.result, 4); assert.equal(r.trace.tool, 'vila_calculate');
});
test('sandbox runs JS/Python, enforces timeouts and blocks escapes', async () => {
  const env = { VILA_ENABLE_CODE_EXEC: 'true', VILA_CODE_TIMEOUT_MS: '1500' };
  assert.equal((await runCode({ language: 'js', code: 'console.log(6*7)' }, env)).stdout, '42');
  assert.match((await runCode({ language: 'js', code: 'while(1){}' }, env)).error, /timed out/);
  assert.equal((await runCode({ language: 'js', code: 'console.log(typeof process, typeof require)' }, env)).stdout, 'undefined undefined');
  assert.ok((await runCode({ language: 'js', code: 'console.log(console.log.constructor("return process")())' }, env)).error);
  assert.equal((await runCode({ language: 'py', code: 'print(sum(range(10)))' }, env)).stdout.trim(), '45');
  for (const code of ['import socket;socket.socket()', 'import subprocess;subprocess.run(["id"])', 'open("/etc/passwd")', 'open("x","w")', 'import os;os.system("id")']) assert.match((await runCode({ language: 'py', code }, env)).error, /blocked/, code);
  await assert.rejects(() => runCode({ language: 'py', code: '1' }, {}), /tắt/);
  await assert.rejects(() => runCode({ language: 'ruby', code: '1' }, env));
});

test('pinnedFetch connects to the validated IP, not a re-resolved one (DNS rebinding closed)', async () => {
  const http = require('node:http');
  const srv = http.createServer((req, res) => { res.setHeader('content-type', 'text/plain'); res.end('host=' + req.headers.host); });
  await new Promise(r => srv.listen(0, '127.0.0.1', r)); const port = srv.address().port;
  try {
    // Hostname does not resolve anywhere real; the pinned address (loopback) is allowed only via the test hook.
    const r = await web.pinnedFetch(`http://pinned.test:${port}/`, {}, { allowPrivate: false, lookup: async () => [{ address: '8.8.8.8' }] }).then(() => 'connected', e => e.code || e.message);
    assert.notEqual(r, 'connected', 'must have tried 8.8.8.8 (unreachable/refused), not loopback');
    const ok = await web.pinnedFetch(`http://127.0.0.1:${port}/x`, {}, { allowPrivate: true });
    assert.equal(await ok.text(), `host=127.0.0.1:${port}`);
    await assert.rejects(() => web.pinnedFetch(`http://127.0.0.1:${port}/`, {}, {}), /SSRF|nội bộ|Cổng/);
  } finally { srv.close(); }
});
