'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../src/server.js'), 'utf8');
const envExample = fs.readFileSync(path.join(__dirname, '../.env.example'), 'utf8');
const engine = require('../src/engine');

test('server registry includes original providers and additive OpenAI-compatible pool members', () => {
  for (const id of ['gemini','openrouter','groq','cerebras','custom','openai','mistral','together','fireworks']) {
    assert.match(source, new RegExp(`make\\('${id}'`), `missing provider adapter ${id}`);
  }
  for (const key of ['OPENAI_API_KEY','MISTRAL_API_KEY','TOGETHER_API_KEY','FIREWORKS_API_KEY']) {
    assert.ok(envExample.includes(`${key}=`), `missing env example ${key}`);
  }
});

test('provider order includes new pool members and routing still ignores unconfigured providers', () => {
  for (const id of ['openai','mistral','together','fireworks']) assert.ok(engine.PROVIDER_ORDER.includes(id));
  const result = engine.rankProviders([
    { id:'openai', configured:true, model:'gpt-4.1-mini' },
    { id:'custom', configured:false, model:'private' }
  ], 'reasoning');
  assert.deepEqual(result.map(p => p.id), ['openai']);
});
