'use strict';
// Per-user persistent memory + document search (BM25). Plain JSON files, atomic writes, hard caps.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_ITEMS = 200, MAX_ITEM_CHARS = 2000, MAX_DOCS = 50, MAX_DOC_CHARS = 400000, CHUNK = 900;

function dataDir(env = process.env) { return env.VILA_DATA_DIR || path.join(process.cwd(), '.vila-data'); }
function userFile(kind, uid, env) {
  const h = crypto.createHash('sha256').update(String(uid || 'anon')).digest('hex').slice(0, 32);
  const dir = path.join(dataDir(env), kind); fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, `${h}.json`);
}
function load(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return []; } }
function save(file, data) { const tmp = `${file}.${process.pid}.${Date.now()}.tmp`; fs.writeFileSync(tmp, JSON.stringify(data)); fs.renameSync(tmp, file); }

// Index both the exact word and its accent-folded form so "tim kiem" finds "tìm kiếm" (users often type
// Vietnamese without diacritics). 'đ' has no decomposition, so it is mapped explicitly.
const fold = w => w.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd');
const tok = s => {
  const words = String(s).toLowerCase().normalize('NFC').match(/[\p{L}\p{N}]+/gu) || [];
  const out = [];
  for (const w of words) { out.push(w); const f = fold(w); if (f !== w) out.push(f); }
  return out;
};
function bm25(queryTokens, docs /* [{tokens}] */, k1 = 1.5, b = 0.75) {
  const N = docs.length || 1; const avg = docs.reduce((a, d) => a + d.tokens.length, 0) / N || 1;
  const df = new Map();
  for (const d of docs) for (const t of new Set(d.tokens)) df.set(t, (df.get(t) || 0) + 1);
  return docs.map(d => {
    const tf = new Map(); for (const t of d.tokens) tf.set(t, (tf.get(t) || 0) + 1);
    let score = 0;
    for (const q of new Set(queryTokens)) {
      const f = tf.get(q); if (!f) continue;
      const idf = Math.log(1 + (N - (df.get(q) || 0) + 0.5) / ((df.get(q) || 0) + 0.5));
      score += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * d.tokens.length / avg));
    }
    return score;
  });
}

// ---- memory ----
function memorySave(uid, { text, tags }, env) {
  const t = String(text || '').trim(); if (!t) throw new Error('Nội dung trống.');
  const f = userFile('memory', uid, env); const items = load(f);
  const item = { id: crypto.randomUUID().slice(0, 8), text: t.slice(0, MAX_ITEM_CHARS), tags: Array.isArray(tags) ? tags.slice(0, 5).map(x => String(x).slice(0, 30)) : [], at: new Date().toISOString() };
  items.push(item); while (items.length > MAX_ITEMS) items.shift();
  save(f, items); return { saved: true, id: item.id, total: items.length };
}
function memorySearch(uid, { query, limit }, env) {
  const items = load(userFile('memory', uid, env)); const n = Math.max(1, Math.min(10, Number(limit) || 5));
  if (!String(query || '').trim()) return { results: items.slice(-n).reverse().map(({ id, text, at }) => ({ id, text, at })) };
  const docs = items.map(i => ({ tokens: tok(i.text + ' ' + i.tags.join(' ')) })); const sc = bm25(tok(query), docs);
  return { results: items.map((i, k) => ({ id: i.id, text: i.text, at: i.at, score: Number(sc[k].toFixed(3)) })).filter(x => x.score > 0).sort((a, b) => b.score - a.score).slice(0, n) };
}
function memoryList(uid, env) { return { results: load(userFile('memory', uid, env)).slice().reverse().map(({ id, text, at }) => ({ id, text, at })) }; }
function memoryDelete(uid, { id }, env) {
  const f = userFile('memory', uid, env); const items = load(f); const next = id === 'all' ? [] : items.filter(i => i.id !== String(id));
  save(f, next); return { deleted: items.length - next.length };
}

// ---- documents ----
function chunkText(text) {
  const paras = String(text).split(/\n{2,}/); const out = []; let cur = '';
  for (const p of paras) { if ((cur + '\n\n' + p).length > CHUNK && cur) { out.push(cur); cur = p; } else cur = cur ? cur + '\n\n' + p : p; while (cur.length > CHUNK * 1.5) { out.push(cur.slice(0, CHUNK)); cur = cur.slice(CHUNK); } }
  if (cur.trim()) out.push(cur); return out;
}
function docAdd(uid, { name, text }, env) {
  const t = String(text || ''); if (!t.trim()) throw new Error('Tài liệu trống.'); if (t.length > MAX_DOC_CHARS) throw new Error(`Tài liệu vượt ${MAX_DOC_CHARS} ký tự.`);
  const f = userFile('docs', uid, env); const docs = load(f).filter(d => d.name !== String(name));
  docs.push({ id: crypto.randomUUID().slice(0, 8), name: String(name || 'untitled').slice(0, 120), chunks: chunkText(t), at: new Date().toISOString() });
  while (docs.length > MAX_DOCS) docs.shift(); save(f, docs); const d = docs[docs.length - 1];
  return { id: d.id, name: d.name, chunks: d.chunks.length };
}
function docList(uid, env) { return load(userFile('docs', uid, env)).map(d => ({ id: d.id, name: d.name, chunks: d.chunks.length, at: d.at })); }
function docDelete(uid, id, env) { const f = userFile('docs', uid, env); const d = load(f); const n = d.filter(x => x.id !== String(id)); save(f, n); return { deleted: d.length - n.length }; }
function docSearch(uid, { query, limit }, env) {
  const q = tok(query); if (!q.length) throw new Error('Truy vấn trống.');
  const docs = load(userFile('docs', uid, env)); const flat = [];
  for (const d of docs) d.chunks.forEach((c, i) => flat.push({ doc: d.name, chunk: i + 1, text: c, tokens: tok(c) }));
  if (!flat.length) return { results: [], note: 'Chưa có tài liệu nào được tải lên.' };
  const sc = bm25(q, flat); const n = Math.max(1, Math.min(6, Number(limit) || 4));
  return { results: flat.map((x, k) => ({ doc: x.doc, chunk: x.chunk, score: Number(sc[k].toFixed(3)), text: x.text })).filter(x => x.score > 0).sort((a, b) => b.score - a.score).slice(0, n) };
}
module.exports = { memorySave, memorySearch, memoryList, memoryDelete, docAdd, docList, docDelete, docSearch, bm25, tok };
