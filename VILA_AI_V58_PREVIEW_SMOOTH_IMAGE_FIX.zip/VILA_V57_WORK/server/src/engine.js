'use strict';

const PROVIDER_ORDER = ['gemini', 'openrouter', 'openai', 'mistral', 'together', 'fireworks', 'groq', 'cerebras', 'custom'];
const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);

function classifyTask(messages, explicitTask) {
  if (['general', 'coding', 'reasoning', 'research', 'multimodal'].includes(String(explicitTask || '').toLowerCase())) return String(explicitTask).toLowerCase();
  const last = [...(Array.isArray(messages) ? messages : [])].reverse().find(m => m && m.role === 'user');
  const content = Array.isArray(last?.content)
    ? last.content.map(p => typeof p === 'string' ? p : String(p?.text || '')).join(' ')
    : String(last?.content || '');
  if (Array.isArray(last?.content) && last.content.some(p => p && (p.type === 'image_url' || p.type === 'input_image'))) return 'multimodal';
  if (/(\bcode\b|program|coding|lập trình|javascript|typescript|\bhtml\b|\bcss\b|\bpython\b|\bjava\b|android|apk|debug|sửa code|fix code|\bbuild\s+(?:apk|app|script|error|lỗi)|gradle|npm|compile|biên dịch|refactor|source code|mã nguồn)/i.test(content)) return 'coding';
  if (/(phân tích|logic|toán|giải thích sâu|kiến trúc|thuật toán|suy luận|reasoning|nhiều bước|kiểm chứng|prove|proof)/i.test(content)) return 'reasoning';
  if (/(tìm kiếm|tìm trên web|tra cứu|nguồn chính thức|mới nhất|hiện tại|hôm nay|tin tức|giá hiện tại|latest|current|news|web search|internet)/i.test(content)) return 'research';
  if (/(ảnh|hình|image|vision|screenshot|video|âm thanh|audio)/i.test(content)) return 'multimodal';
  return 'general';
}

function normalizeOpenAIBase(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  let url;
  try { url = new URL(raw); } catch { throw new Error('Base URL không phải URL hợp lệ.'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Base URL chỉ được dùng HTTP hoặc HTTPS.');
  // Avoid returning credentials in URLs; providers must use Authorization headers.
  if (url.username || url.password) throw new Error('Không đặt API key trong URL; hãy dùng trường API key riêng.');
  let path = url.pathname.replace(/\/+$/, '');
  path = path.replace(/\/chat\/completions$/i, '').replace(/\/models$/i, '');
  url.pathname = path;
  url.search = '';
  url.hash = '';
  return url.toString().replace(/\/$/, '');
}

function isRetryableStatus(status, message = '') {
  const code = Number(status || 0);
  if (RETRYABLE_STATUS.has(code)) return true;
  if (code === 404 && /model|not found|unsupported/i.test(String(message))) return true;
  return code === 0; // network or timeout before a response was received
}

function modelFor(provider, task, env = process.env) {
  const p = String(provider || '').toUpperCase();
  const suffix = task === 'coding' ? 'CODING_MODEL' : task === 'reasoning' ? 'REASONING_MODEL' : 'GENERAL_MODEL';
  return String(env[`${p}_${suffix}`] || (provider === 'gemini' ? env.GEMINI_CHAT_MODEL : '') || '').trim();
}

function supportsFeature(provider, task, model) {
  if (task !== 'research') return true;
  const m = String(model || '').toLowerCase();
  return provider === 'gemini' || provider === 'openrouter' || (provider === 'groq' && /gpt-oss-(20b|120b)/.test(m));
}

/** Learned adjustment from live stats: reward fast, reliable providers; penalise flaky or slow ones.
 * Needs a few samples before it can outweigh the static task affinity, and is bounded so it never fully overrides it. */
function performanceAdjustment(perf) {
  if (!perf || !(perf.samples >= 3)) return 0;
  const reliability = (Math.max(0, Math.min(1, Number(perf.successRate))) - 0.9) * 150; // 100% => +15, 70% => -30
  const lat = Number(perf.latencyMs) || 0;
  const speed = lat > 0 ? Math.max(-8, Math.min(8, (4000 - lat) / 500)) : 0; // 0.5s => +7, 8s => -8
  return Math.max(-30, Math.min(20, reliability + speed));
}

function rankProviders(configured, task, options = {}) {
  const requested = String(options.provider || 'auto').toLowerCase();
  const model = String(options.model || 'auto');
  const candidates = (Array.isArray(configured) ? configured : []).filter(p => p && p.configured);
  if (requested !== 'auto') return candidates.filter(p => p.id === requested);
  let list = candidates.filter(p => supportsFeature(p.id, task, model === 'auto' ? p.model : model));
  const score = p => {
    const id = String(p.id || ''), mid = String(p.model || '').toLowerCase();
    let n = 0;
    if (task === 'multimodal') { if (id === 'gemini' || id === 'openrouter') n += 60; }
    if (task === 'coding') { if (id === 'groq' || id === 'cerebras' || id === 'openai') n += 25; if (/code|coder|qwen|gpt-oss-120b|glm|devstral/i.test(mid)) n += 22; }
    if (task === 'reasoning') { if (/120b|reason|thinking|pro|glm|o1|o3|r1|magistral/i.test(mid)) n += 30; if (id === 'openrouter' || id === 'openai') n += 10; }
    if (task === 'research') { if (id === 'gemini' || id === 'openrouter') n += 35; if (id === 'groq' && /gpt-oss/.test(mid)) n += 15; }
    if (task === 'general') { if (id === 'cerebras' || id === 'groq' || id === 'together' || id === 'fireworks') n += 20; if (id === 'openrouter' || id === 'openai' || id === 'mistral') n += 6; }
    if (p.health === 'ok') n += 5;
    n += performanceAdjustment(p.perf);
    return n;
  };
  list = list.sort((a, b) => score(b) - score(a) || PROVIDER_ORDER.indexOf(a.id) - PROVIDER_ORDER.indexOf(b.id));
  return list;
}

module.exports = { PROVIDER_ORDER, RETRYABLE_STATUS, classifyTask, normalizeOpenAIBase, isRetryableStatus, modelFor, supportsFeature, rankProviders, performanceAdjustment };
