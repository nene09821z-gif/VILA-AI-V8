# VILA Chess AI Arena v3.12.0

VILA Chess là app cờ vua ưu tiên Android/WebView, dùng Stockfish 19 để tính nước, luật cờ qua `chess.js`, AI Coach qua Gemini/các API tương thích, sách khai cuộc có trọng số, đánh giá MultiPV, âm thanh bàn cờ, gợi ý có mũi tên, phân tích toàn ván, đồng hồ, PGN và Lichess.

> **Đây là ZIP mã nguồn để build bằng GitHub Actions, không phải APK đã biên dịch.** Build phụ thuộc cài đặt thành công và xác thực thiết bị là cổng bắt buộc trước khi phát hành.

## Nền tảng cờ vua v3.9.4

- **Ký hiệu xem lại ván:** nước theo sách có biểu tượng 📖; nước thiên tài* `!!`; tốt nhất `★`; xuất sắc `!`; tốt `✓`; chưa chính xác `?!`; sai lầm `?`; blunder `??`. Di chuột/chạm giữ biểu tượng sẽ có mô tả; đánh giá vẫn là phân loại heuristic từ phân tích Stockfish, không phải nhãn chính thức của Chess.com.
- **Dải Elo đối thủ 500–3200:** có trong thiết lập nhanh, Cài đặt và Đấu trường AI. Elo dưới ~1320 dùng Skill Level 0, các nước heuristic và một tỷ lệ chọn ngẫu nhiên nước hợp lệ vì UCI_Elo có mức sàn khoảng 1320; Elo từ 1320 đến 3200 sử dụng UCI_Elo trong phạm vi engine (3200 ánh xạ gần 3190). Đây là mức ước lượng, không phải Elo được chứng nhận.
- **Kiểm thử hồi quy:** test ký hiệu đánh giá và ánh xạ Elo; `npm run test:static` đạt 128/128 bài.


- Chuẩn hóa endpoint Gemini khi người dùng nhập URL method đầy đủ; loại preset Gemini 3.7 đã bị deprecated khỏi danh sách nhanh.
- Stockfish Lite là profile tự động; nếu Full lỗi thì thử Lite, nếu Lite/WASM lỗi thì thử ASM-JS không cần WASM. Tệp engine được kiểm tra trước khi dọn bản cũ.
- Lưu lịch sử ván đã kết thúc vào thiết bị, xem lại từng nước, mở phân tích, xóa bản lưu và xuất PGN; PGN giữ FEN cho thế cờ tùy chỉnh.
- Nhạc piano Gymnopédie No. 1 có ghi công/giấy phép và nhạc Web Audio dự phòng khi offline.
- Test tĩnh sau chỉnh sửa: **128/128 đạt**. Bản này thêm kiểm tra thật cho bộ đóng gói asset Stockfish và chuỗi fallback. Toàn bộ `npm test` chưa thể xác nhận trong môi trường này vì dependencies chưa cài; `chess.js`/Vite/Stockfish được cài qua `npm install` khi chạy workflow. Không coi kết quả test tĩnh thay cho full suite hay build APK.


- **Kho khai cuộc mở rộng:** trước bước Vite build, workflow thử tải năm nhóm ECO `a.tsv`–`e.tsv` từ `lichess-org/chess-openings` (CC0-1.0), kiểm tra biến bằng `chess.js`, loại dòng trùng và đóng gói `public/openings-eco.json`. Khi dữ liệu ngoài không lấy được, 81 đường khai cuộc mẫu hiện có vẫn hoạt động.
- **AI dùng kho rộng hơn:** sách khai cuộc và nhận diện chạy qua cây tiền tố; cache được xây lại sau khi kho động tải thêm, tránh tình trạng giao diện đếm nhiều dòng nhưng AI còn dùng cache cũ. Kho giao diện tìm theo tên/mã ECO/nước đi, lọc hệ khai cuộc và tải thêm từng trang.
- **Phòng chơi kiểu Chess.com:** khu bàn cờ tông xanh lá/kem, hàng người chơi/đối thủ, đồng hồ, nhãn khai cuộc, phân tích engine, lịch sử nước và công cụ bên cạnh; bố cục tự co về một cột trên điện thoại. Đây là bố cục lấy cảm hứng, không phải bản sao chính thức.

- **Trang chủ VILA Chess mới:** app mở vào dashboard thay vì nhảy thẳng vào bàn cờ; có nút chơi nhanh, thiết lập ván, Đấu trường AI, AI Coach, Thư viện khai cuộc, Elo/xếp hạng và Lichess.
- **Thao tác Android nhanh hơn:** thanh Ván mới/Hoàn tác/Gợi ý cố định ở đáy màn hình; thiết lập trận được thu gọn; chọn ô chỉ cập nhật highlight thay vì dựng lại toàn bộ 64 ô; kéo quân dùng `requestAnimationFrame` và bỏ qua sự kiện click tổng hợp theo đúng ô.
- **Sửa trường hợp API trả rỗng:** đọc thêm định dạng OpenAI Responses `output[]`, wrapper của gateway và phản hồi `text/event-stream` của OpenAI-compatible, Gemini, Anthropic; giữ nguyên dấu cách khi ghép chunk, bỏ qua khối Gemini `thought`, và cải thiện chẩn đoán finish reason. Lỗi mạng được làm sạch key trước khi đưa ra giao diện.
- **Kéo quân trên WebView:** bỏ bộ lọc `drop-shadow` thay đổi theo từng frame, giữ chuyển động bằng transform compositor; dọn trạng thái khi mất pointer capture và bỏ nước đi đang chờ phong cấp nếu thế cờ/phiên ván đã đổi.
- **Giao diện di động:** hero cờ vua, thẻ công cụ responsive, thống kê Elo cục bộ và trạng thái cấu hình API; tối ưu bố cục nhỏ cho Android WebView.
- **Nhãn Android:** tên ứng dụng launcher chuyển thành `VILA Chess`, giữ nguyên application ID để không tự ý đổi định danh gói.
- **Phân tích Stockfish ổn định hơn (v3.5):** tuần tự hóa lượt tìm kiếm bị hủy, bỏ qua kết quả cũ theo FEN/phiên ván, watchdog khi engine không xác nhận dừng và giữ bảng phân tích với thông báo hữu ích khi thiếu biến thể.
- **Tính năng được giữ lại:** chơi với Stockfish, AI qua API, bàn cờ vuốt quân, đồng hồ, phân tích 3 biến, phân tích toàn ván, gợi ý, sách khai cuộc, nhạc nền, Elo cục bộ, đấu trường AI, PGN, Lichess và cấu hình provider.


## Cộng đồng, Top 100 và quản trị (v3.9.5)

- **Tài khoản cộng đồng:** đăng ký/đăng nhập bằng username + mật khẩu; mật khẩu được băm với scrypt trên backend. Email là tùy chọn. Phiên đăng nhập dùng token ký HMAC có thời hạn 7 ngày.
- **Bạn bè:** tìm hồ sơ theo username/tên hiển thị, gửi và nhận lời mời, chấp nhận hoặc hủy kết nối; trạng thái online dựa trên hoạt động gần đây trong app.
- **Top 100:** bảng công khai lấy 100 hồ sơ đầu từ API server và sắp theo Elo. Tài khoản mới khởi đầu 1200 Elo. **Bản này chưa triển khai ván PvP xếp hạng do server xác thực nước đi**, nên chưa tự cộng/trừ Elo online sau trận; không coi Elo hiện tại là xếp hạng thi đấu chống gian lận. Phần đó cần room/match API để server xác thực từng nước đi và kết quả.
- **Admin riêng:** bootstrap admin bằng `ADMIN_USERNAME` và `ADMIN_PASSWORD` trong biến môi trường bí mật của server. Mật khẩu admin cần ít nhất 14 ký tự. Admin xem uptime, bộ nhớ tiến trình, số người dùng, nhật ký audit, khóa/mở khóa tài khoản thường. Không có tài khoản/mật khẩu admin mặc định đóng gói trong APK. Chỉ API mới quyết định quyền admin.
- **OAuth sẵn cấu hình:** Google và GitHub dùng OAuth phía backend; không cần Firebase. Cấu hình `SOCIAL_PUBLIC_URL` là URL HTTPS backend và `SOCIAL_FRONTEND_URL` là URL web app trả về sau OAuth; thêm domain web vào `CORS_ORIGIN` (ví dụ `https://app.example.com,capacitor://localhost,https://localhost`), rồi thêm `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET` trong secrets của hosting. Callback URLs cần đăng ký chính xác là `https://TEN_BACKEND/api/social/auth/oauth/google/callback` và `https://TEN_BACKEND/api/social/auth/oauth/github/callback`. Không đưa client secret vào APK hoặc GitHub repository. OAuth redirect hiện phù hợp luồng web; muốn callback quay thẳng vào APK Capacitor cần cấu hình deep link/native redirect riêng.
- **Dữ liệu và bảo mật:** dữ liệu cộng đồng được lưu tại `data/social-store.json` ngoài thư mục public; file bị thêm vào `.gitignore`. Cần gắn persistent disk/volume và backup file này khi deploy; đặt restart policy của hosting thành `Always/On failure` để tiến trình được khởi động lại sau lỗi nghiêm trọng. Có rate limit, xác thực token, kiểm tra role ở server, giới hạn kích thước request và audit log. Đây là lớp bảo vệ ứng dụng, không thay thế HTTPS, firewall/WAF chống DDoS, giám sát, cập nhật hệ điều hành hay sao lưu ở tầng hosting. Không thể bảo đảm hệ thống miễn nhiễm mọi cuộc tấn công hoặc không bao giờ sập.

### Cấu hình server và tạo admin

1. Deploy backend Node.js trên hosting có HTTPS và persistent volume; không chỉ chạy APK vì tài khoản/bạn bè phải dùng chung một server. Trên hosting kiểu container, đặt `HOST=0.0.0.0` và dùng cổng `PORT` do nhà cung cấp cấp; bắt buộc đặt `TUBOR_ACCESS_TOKEN` ngẫu nhiên, dài và riêng cho các API AI/Lichess hiện có. Các route `/api/social` có xác thực tài khoản riêng.
2. Trong phần Environment/Secrets của hosting, đặt `ADMIN_USERNAME` và một `ADMIN_PASSWORD` riêng dài tối thiểu 14 ký tự. Đặt `SOCIAL_TOKEN_SECRET` ngẫu nhiên tối thiểu 32 bytes; không commit bí mật vào repo. Copy các biến mẫu trong `.env.example` để tham khảo. Nếu hosting chạy sau reverse proxy đáng tin cậy, cấu hình `TRUST_PROXY=1` để rate-limit dùng đúng địa chỉ nguồn; chỉ bật khi proxy được kiểm soát.
3. Khởi động lại server. Log sẽ xác nhận admin được tạo, nhưng **không** in mật khẩu. Nếu username đã được đăng ký với mật khẩu khác, server sẽ từ chối tự động nâng quyền; hãy chọn username mới hoặc xử lý recovery an toàn.
4. Mở VILA Chess → Cài đặt → nhập `API backend URL` là URL HTTPS của backend. Tạo tài khoản ở mục **Bạn bè**. Admin đăng nhập tài khoản bootstrap này để thấy tab **Admin**.
5. Trước khi phát hành cho nhiều người, xác minh HTTPS/CORS/callback OAuth, persistent storage, backup/restore, giới hạn request và kiểm thử tải. Không thể tạo tài khoản admin cho server chưa được bạn triển khai/cấu hình secrets.

## Build Android qua GitHub Actions

**Cách A — build trực tiếp từ ZIP đã tải:** tải `VILA_CHESS_v3_9_5_COMMUNITY_ADMIN.zip`, đưa file ZIP này vào thư mục gốc repository GitHub rồi commit/push. Repository phải có sẵn file workflow `.github/workflows/build-from-zip.yml` ở ngoài ZIP (GitHub không chạy workflow nằm bên trong một tệp ZIP); nếu chưa có, hãy giải nén thư mục `.github/workflows/` từ ZIP ra đúng vị trí rồi commit/push. Workflow **Build VILA Chess APK from uploaded ZIP** sẽ giải nén và build từ ZIP. Workflow tự tìm `package.json` bên trong ZIP sau khi giải nén; archive chứa thư mục dự án và không yêu cầu giải nén thủ công trước khi upload.

**Cách B — build từ các tệp đã giải nén:** giải nén mọi file vào gốc repository, giữ lại các file ẩn và `.github/workflows`; commit/push lên `main`, rồi chạy **Build VILA Chess APK** trong tab Actions.

Workflow cài dependencies, chạy static/full tests, yêu cầu asset Stockfish Lite + ASM-JS, build Vite, tạo/sync Capacitor Android, xác minh Gradle rồi build APK debug. Chỉ lấy APK artifact khi workflow hoàn tất thành công. ZIP nguồn không phải APK.

## Trạng thái kiểm thử v3.9.5

- Đã chạy kiểm tra cú pháp `node --check` cho các tệp JavaScript/MJS, kiểm tra JSON của `package.json` và `.env.example`, kiểm tra biên dịch Python cho script đóng gói, cùng các kiểm tra cấu trúc về endpoint, giao diện, phân quyền server và `.gitignore`.
- Đã thêm `tests/social.test.js` để kiểm thử đăng ký/đăng nhập, kết bạn, Top 100, phân quyền admin và khóa/mở khóa. **Bài test này chưa chạy được trong môi trường tạo ZIP** vì cài package qua npm bị timeout; các dependencies, gồm `express` và `chess.js`, chưa sẵn sàng tại đây.
- Vì vậy chưa xác nhận được integration test, toàn bộ `npm test`, Vite build, Gradle/APK, OAuth với tài khoản Google/GitHub thật hoặc thử tải/kiểm thử bảo mật trên server triển khai. Chạy GitHub Actions và chỉ phát hành sau khi workflow xanh; sau đó thử luồng đăng ký, bạn bè, admin và khôi phục backup trên backend HTTPS thật.
- Đây là nền tảng cộng đồng MVP lưu dữ liệu bằng file JSON và phù hợp **một instance server** có volume bền vững. Trước khi mở cho nhiều người hoặc chịu tải lớn, cần chuyển dữ liệu sang PostgreSQL/MySQL, dùng Redis hoặc bộ giới hạn dùng chung giữa instance, thiết lập backup/restore, giám sát và WAF/DDoS protection ở tầng hosting. Rate limit trong ứng dụng không thay thế bảo vệ hạ tầng và không thể bảo đảm không bao giờ sập hay hoàn toàn miễn nhiễm hacker.

## Model/API và an toàn

Trang chính thức có thể đổi model/giá bất kỳ lúc nào; hãy kiểm tra trước khi dùng:

- Gemini models/pricing: <https://ai.google.dev/gemini-api/docs/models> · <https://ai.google.dev/gemini-api/docs/pricing>
- Groq models/rate limits: <https://console.groq.com/docs/models> · <https://console.groq.com/docs/rate-limits>
- OpenRouter free router: <https://openrouter.ai/openrouter/free> · <https://openrouter.ai/pricing/>

Không commit API key vào repository công khai. Key được người dùng tự nhập trên thiết bị; không có khóa nhà cung cấp chung tích hợp sẵn. Backend public cần HTTPS và `TUBOR_ACCESS_TOKEN` mạnh. Đọc kỹ chính sách chia sẻ dữ liệu của từng provider.


## VILA Chess v3.10 — nhiệm vụ, xu và giao diện trang trí

- Có trang **Nhiệm vụ** và **Cửa hàng**: điểm danh theo ngày, chuỗi hoạt động, nhiệm vụ hoàn thành ván, thăm khai cuộc và AI Coach; nhận xu một lần cho từng nhiệm vụ trong ngày.
- Xu là điểm nội bộ, lưu cục bộ trên thiết bị hiện tại; chưa đồng bộ qua tài khoản/server, không quy đổi hay rút tiền.
- Có các theme bàn cờ Cổ điển, Đại dương, Gỗ óc chó và Nửa đêm; theme đã mở khóa sẽ áp dụng cho bàn cờ và đấu trường AI. Không bán lợi thế thi đấu.
- Xem `CHANGELOG_V3_10.md` và `MONETIZATION_V3_10.md` cho phạm vi và lộ trình kiếm doanh thu thật. **Chưa bật quảng cáo hay thanh toán thật** vì cần cấu hình native SDK, Play Console, ID quảng cáo/sản phẩm, kiểm thử và backend xác thực giao dịch.
- `node --test tests/daily-progress.test.js` chạy 5 test logic nhiệm vụ/cửa hàng độc lập. Full test suite/build vẫn cần chạy trong GitHub Actions sau khi dependency install thành công.


## VILA Chess v3.11 — Ranked & Tactical Lab

This release adds server-authoritative Elo matchmaking, original SVG chess pieces, a clearer end-of-game/review presentation, 17 daily missions, 8 virtual board cosmetics, and on-demand Stockfish-checked random-position puzzles.

**Online ranked play is not live until a backend is deployed.** A single backend instance with persistent storage is required by the current JSON store; use a transactional database for multi-instance/high-traffic operation. See `CHANGELOG_V3_11_0.md` and `TEST_REPORT_V3_11_0.md` for limitations and checks run.


## VILA Chess v3.12 — Touch Analysis & Ranked Clocks
- In solo Stockfish/API-AI games, open the tiny floating pencil tool on the board to draw an arrow, circle a square, clear marks, or drag the toolbar to a less intrusive location. The marks are local visual annotations and do not change chess moves.
- Rated online play has separate Bullet, Blitz, and Rapid ratings and a time-control selector. Use the same selected control as other players to enter that matchmaking queue. Undo/hint/new-game controls are intentionally absent from ranked match screens.
- Solo clocks offer UltraBullet/HyperBullet, Bullet, Blitz, and Rapid examples (including increment controls like 3+2). The server clock starts once a match is paired and is settled as players poll or submit moves.
- Stockfish is still the only built-in offline chess engine. API-AI and Lichess are separately selectable existing modes. A second offline engine such as Leela/LC0 or Maia needs its own runtime and neural model files; it is not falsely advertised as bundled in this version.

Build and test status: this ZIP contains source code, not a prebuilt or verified APK. A deployed persistent backend and end-to-end two-user testing are still required for live rated matchmaking.
