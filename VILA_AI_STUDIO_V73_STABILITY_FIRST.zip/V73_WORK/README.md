# VILA AI Studio 73.0.0 — Balanced Chat UI & Theme Repair

Ứng dụng Android WebView kết nối nhiều nhà cung cấp AI, kèm AI Gateway Node.js tùy chọn. ZIP này là **mã nguồn**, không phải APK/AAB đã build.

## Điểm thay đổi trong V72

- Đồng bộ giao diện chat sáng/tối bằng một bảng màu trung tính; bỏ nền tối/neon cứng trên nội dung assistant, câu trả lời, markdown và thanh trạng thái.
- Gỡ câu chào mẫu cũ khỏi lịch sử khi tải lại nếu nó đang nằm trước câu hỏi thật; không xóa tin nhắn người dùng hay câu trả lời khác.
- Không hiển thị khối `<think>`/suy luận thô do provider trả về; trạng thái chạy/fallback không tự phô tên provider hoặc mã model.
- Chuyển các chế độ suy luận, Agent, web và model vào menu dấu cộng; bỏ tooltip/toast thành công gây gián đoạn khi bật/tắt chế độ.
- Sửa lỗi chế độ lập trình tự nhét một đoạn chỉ thị dài vào ô nhập (và một đường gọi đã chèn đoạn đó hai lần). Chế độ lập trình nay là tuỳ chọn lưu cục bộ; ngữ cảnh được thêm riêng vào request.
- Nút kiểm tra code hiện chỉ điền câu lệnh ngắn vào ô nhập; mã Preview được đính kèm như ngữ cảnh khi gửi, không làm ô soạn thảo biến thành một khối code dài.
- Bảo vệ Enter khi bàn phím đang ghép ký tự tiếng Việt và khôi phục bản nháp/tệp đính kèm sẵn sàng khi yêu cầu API lỗi.
- Chuyển Voice Studio vào menu ba gạch, loại bỏ nút nổi trùng lặp và đồng bộ bảng màu sáng/tối.
- Giữ nguyên luồng chạy Live Preview/iframe và nút **Xem trước**.

## Trạng thái xác minh

- `node scripts/run-all.js`: 36/36 nhóm kiểm tra đạt; 14 inline scripts và 35 style blocks tĩnh phân tích cú pháp thành công.
- Đã thử render headless Chromium nhưng lệnh không hoàn tất trong giới hạn thời gian, nên chưa có ảnh render được xác nhận; cần kiểm tra thực tế trên Android/WebView.
- Chưa build APK/AAB tại đây. Workflow GitHub Actions có thể tạo APK debug; AAB chỉ được ký khi cấu hình đầy đủ signing secrets.
- Chưa thể tuyên bố app đã sẵn sàng phát hành Google Play: cần kiểm thử thiết bị, xác minh tích hợp đăng nhập/API, thông tin liên hệ chủ ứng dụng và URL HTTPS thật cho chính sách riêng tư/xóa tài khoản.

## Kiến trúc và giới hạn hiện tại

Sơ đồ thành phần và các giới hạn đã biết được ghi tại [`docs/TECHNOLOGY_MAP.md`](docs/TECHNOLOGY_MAP.md). Danh sách này phân biệt tính năng đã có mã nguồn, tính năng còn cần cấu hình dịch vụ và những điều chưa được đảm bảo trong môi trường production.

## Thư mục

- `app/` — ứng dụng Android Java/WebView và giao diện web trong `assets/`.
- `server/` — AI Gateway Node.js.
- `scripts/` và `server/test/` — kiểm tra hồi quy; hiện 36/36 nhóm đạt trong môi trường này.
- `tools/play-preflight.js` — kiểm tra các điều kiện trước phát hành.
- `docs/` — hướng dẫn build, Google Sign-In, Gateway và Play Store.
- `.github/workflows/main.yml` — CI build/verify Android.
- `CHANGELOG.md` — lịch sử các bản phát hành.
- `VILA_V72_TEST_REPORT.md` và `VILA_V72_UI_QA.md` — phạm vi thay đổi và các bước kiểm chứng còn lại.

## Build Android

Đưa **toàn bộ nội dung thư mục dự án** lên GitHub, chạy workflow **VILA AI - Android Build and Verify (V72)**, rồi tải artifact để cài thử APK debug. Hướng dẫn chi tiết: [`docs/BUILD_GUIDE_V72.md`](docs/BUILD_GUIDE_V72.md).

## Chạy AI Gateway

```bash
cp server/.env.example server/.env
cd server && npm install && npm start
```

Không đưa `.env`, API key, token, keystore hay thông tin bí mật vào GitHub hoặc ZIP công khai. Xem `docs/GATEWAY_DEPLOYMENT.md` khi triển khai server.


### Puter AI Hub

Puter AI Hub tích hợp catalog model trực tiếp theo tài khoản, hỗ trợ tìm kiếm nhà cung cấp và giữ rõ giới hạn/quota do Puter quản lý. Các provider khác vẫn dùng cấu hình endpoint/API riêng trong VILA.
