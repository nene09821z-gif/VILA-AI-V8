# VILA V73 — Android manual QA

1. Open an existing chat; verify no stale greeting appears above prior messages.
2. Tap model picker once; verify it opens once, no rules/prompt text is inserted.
3. Toggle coding/search/reasoning modes; verify the draft is unchanged.
4. Type Vietnamese with tone marks and send via button; repeat with Enter on supported keyboard.
5. Simulate API error; verify draft and queued attachments are recoverable.
6. Verify reasoning status is compact and uses the selected light/dark theme.
7. Open HTML and JavaScript Preview; run, close and reopen without losing the code.
8. Rotate device, open keyboard, use Back, switch light/dark and repeat.
9. Test timeout, 401, 429, 503 and offline behavior.
10. Build and install debug APK before considering release.
