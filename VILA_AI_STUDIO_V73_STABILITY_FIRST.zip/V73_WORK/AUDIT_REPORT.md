# VILA AI Studio V73.0.0 — Source Audit Summary

- App/Gateway/package metadata is updated to `73.0.0`; Android `versionCode 86`, `targetSdk 36`.
- V72 source changes include neutral Light/Dark chat surfaces, quiet mode/model controls, IME-safe Enter, preservation of failed drafts, and model-free transient status labels.
- Live Preview execution logic and iframe sandboxing were intentionally left unchanged; its panel styling alone was updated.
- Existing historical source-regression scripts were retained; stale expectations about version/docs/UI were updated rather than deleting tests. Added `scripts/test-v72-chat-interactions.js`.
- `node scripts/run-all.js`: **36/36 groups pass**. JavaScript syntax parses 14/14 inline scripts and 64/64 standalone JS files; PostCSS parses all 35 actual static CSS blocks in the HTML; 3/3 JSON files parse. The CSS scan strips script elements first to avoid false positives from dynamically generated Preview HTML strings.
- Headless Chromium rendering timed out, so there is no verified visual screenshot. No APK/AAB was built in this workspace. Android installation, real provider calls, Firebase/Google sign-in and Play submission remain unverified.
- Preflight result: 4 PASS, 3 WARN, 2 BLOCK. Policy/privacy and account-deletion pages still require true owner details and publicly hosted HTTPS URLs before Play release. Use `VILA_V72_TEST_REPORT.md` and `VILA_V72_UI_QA.md` for limits and manual follow-up.

This is source code, not a verified APK/AAB and not a Play-approved release.
