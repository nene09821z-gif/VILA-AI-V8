'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

const mainRow = html.match(/<div class="ds-row">([\s\S]*?)<\/div>\s*<\/div>\s*<div id="inputToolsMenu"/);
assert.ok(mainRow, 'composer control row must exist');
for (const id of ['deepThinkToggle', 'agentModeToggle', 'webSearchToggle', 'autoModelToggle', 'freeModelToggle']) {
  assert.ok(html.indexOf(`id="${id}"`) > html.indexOf('id="inputToolsMenu"'), `${id} belongs in advanced tools, not the typing row`);
  assert.ok(!mainRow[1].includes(`id="${id}"`), `${id} must not crowd the typing row`);
}
assert.doesNotMatch(html, /<div class="ds-model" title=/, 'model header must not trigger native title popups');
assert.match(html, /function normalizeChatStatus\(text\)/, 'transient statuses must be normalized for the chat UI');
assert.doesNotMatch(html, /showToast\(next\?'Đã bật phản hồi nhanh|showToast\(on\?'Đã bật Max Mode/, 'simple mode switches must not interrupt chat with success toasts');
assert.doesNotMatch(html, /showToast\('Đã bật tìm kiếm web cho câu hỏi tiếp theo/, 'turning web search on should not show a toast');
assert.match(html, /e\.isComposing\s*\|\|\s*e\.keyCode\s*===\s*229/, 'Enter must respect mobile IME composition');
assert.match(html, /if\(inputEl && !inputEl\.value\.trim\(\) && rawPrompt\)\{inputEl\.value=rawPrompt;autoResizeTextarea\(inputEl\);if\(attachCurrentCode\)inputEl\.dataset\.vilaAttachCurrentCode='1';\}/, 'failed API requests must preserve the prompt and one-shot code-review context for retry');
assert.match(html, /saved\.showReasoningSummary=false/, 'legacy settings migrate to the quieter reasoning UI');
assert.match(html, /body\.dataset\.vilaRawStream=raw/, 'streamed output must pass through response sanitation');
const codingModeFn = html.slice(html.indexOf('        function prepareCodingAgent()'), html.indexOf('        function buildProjectReadme()', html.indexOf('        function prepareCodingAgent()')));
assert.doesNotMatch(codingModeFn, /input\.value\s*=/, 'entering coding mode must never fill the composer with private instructions');
assert.match(codingModeFn, /localStorage\.setItem\('vila_coding_mode','1'\)/, 'coding mode is a persisted preference');
assert.match(html, /onclick="toggleVilaCodingMode\(\);openCodingLab\(\);closeMainMenu\(\);"/, 'menu coding action toggles mode without duplicate prompt insertion');
assert.match(html, /input\.dataset\.vilaAttachCurrentCode='1'/, 'code review attaches code only as hidden request context');
assert.match(html, /if\(attachCurrentCode\)promptText\+='/, 'review-code request receives the current source outside the visible composer');
assert.doesNotMatch(html, /input\.value = `Kiểm tra toàn bộ code hiện tại/, 'review action must not dump the whole code into the composer');
assert.doesNotMatch(html.slice(html.indexOf('function appendTypingIndicator()'), html.indexOf('window.vilaStreamAppend=')), /data-thinking-provider/, 'typing status must not show a provider/model label');
assert.match(read('server/.env.example'), /VILA_APP_LATEST_VERSION=73\.0\.0/);
assert.match(read('.env.production.example'), /VILA_APP_LATEST_VERSION=73\.0\.0/);
assert.match(read('README.md'), /docs\/TECHNOLOGY_MAP\.md/);

// Execute only pure sanitation helpers to test their behavior, not the app/WebView runtime.
const helperStart = html.indexOf('        function stripInternalReasoningBlocks(value)');
const helperEnd = html.indexOf('        function isImageGenerationIntent(userText)', helperStart);
assert.ok(helperStart >= 0 && helperEnd > helperStart, 'sanitation helpers must be present');
const helpers = new Function(`${html.slice(helperStart, helperEnd)}; return {stripInternalReasoningBlocks,stripPrivateInstructionEcho};`)();
assert.equal(helpers.stripInternalReasoningBlocks('Answer\n<think>private reasoning</think>\nDone'), 'Answer\n\nDone');
assert.equal(helpers.stripPrivateInstructionEcho('Useful answer\nSYSTEM PROMPT: secret instructions\nmore secret'), 'Useful answer');
assert.equal(helpers.stripPrivateInstructionEcho('```text\nSYSTEM PROMPT: example\n```'), '```text\nSYSTEM PROMPT: example\n```', 'fenced code examples must be preserved');
console.log('PASS V72 chat interactions: quieter controls, IME-safe input, prompt recovery, status sanitation, privacy and theme readiness');
