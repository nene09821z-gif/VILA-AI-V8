'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const postcss = require('postcss');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const serverPkg = JSON.parse(fs.readFileSync(path.join(root, 'server/package.json'), 'utf8'));
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');

assert.equal(pkg.version, '73.0.0');
assert.equal(serverPkg.version, pkg.version);
assert.match(gradle, /versionCode\s+86/);
assert.match(gradle, /versionName\s+"73\.0\.0"/);

// Parse real stylesheet blocks (style-like markup inside inline JavaScript templates is excluded).
const markupForCss = html.replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, match => ' '.repeat(match.length));
let parsedCssBlocks = 0;
for (const match of markupForCss.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) {
  postcss.parse(match[1], { from: `VILA-V69-style-${++parsedCssBlocks}` });
}
assert.ok(parsedCssBlocks >= 33, `expected stylesheet blocks to parse, got ${parsedCssBlocks}`);

// The welcome greeting is visible only on an empty chat and is actively removed before messages/loading/errors.
assert.match(html, /#chatMessages>\.ds-welcome:not\(:only-child\)[\s\S]*?display:none!important/);
assert.match(html, /#chatMessages>\.ds-welcome\[hidden\][\s\S]*?display:none!important/);
const removeFn = html.match(/function removeWelcomeGreeting\(chatBox\)\s*\{([\s\S]*?)\n\s*\}/);
assert.ok(removeFn && /querySelectorAll\(':scope > \.ds-welcome'\)/.test(removeFn[1]));
for (const name of ['appendUserMessage', 'appendAiMessage', 'appendTypingIndicator', 'appendErrorMessage']) {
  const m = html.match(new RegExp(`function ${name}\\([^)]*\\)\\s*\\{([\\s\\S]*?)\\n\\s*\\}`, 'm'));
  assert.ok(m, `${name} exists`);
  assert.match(m[1], /removeWelcomeGreeting\(chatBox\)/, `${name} removes stale greeting`);
}
assert.match(html, /font-size:clamp\(22px,5\.2vw,28px\)!important/, 'welcome title is compact at mobile widths');
assert.match(html, /userPromptEl\.addEventListener\('input', function\(\)[\s\S]*?greeting\.hidden=true[\s\S]*?greeting\.hidden=false/, 'draft typing hides the welcome and clearing an empty draft can restore it');

// Loading status reports only provider/status/time, not a fake list of staged progress milestones.
const typing = html.match(/function appendTypingIndicator\(\)\s*\{([\s\S]*?)\n\s*function vilaThinkLabel/);
assert.ok(typing);
assert.match(typing[1], /vila-thinking-compact/);
assert.match(typing[1], /data-thinking-title/);
assert.doesNotMatch(typing[1], /Tìm kiếm web khi cần|Rà soát câu trả lời trước khi gửi|vila-thinking-steps/);
const statusFn = html.match(/function updateVilaThinkingPanel\(text, mode='busy'\)\s*\{([\s\S]*?)\n\s*\}/);
assert.ok(statusFn, 'thinking panel updater exists');
assert.match(statusFn[1], /startsWith\(providerName\.toLocaleLowerCase\(\)\)/, 'provider prefix is separated from current status');
assert.match(html, /statusText\.slice\(0,100\)/, 'status label is bounded');
assert.match(html, /vila-thinking-compact \.vila-thinking-steps,html body #chatMessages \.vila-thinking-compact \.vila-thinking-live\{display:none!important\}/);
assert.match(html, /details>div\{[\s\S]*?max-height:180px!important;overflow:auto!important/);

// Every supported fenced code block exposes an explicit preview action and uses the isolated iframe renderer.
assert.match(html, /class="vila-code-preview-btn" title="Mở và chạy trong Live Preview"/);
assert.match(html, /onclick="previewCodeBlock\('\$\{codeId\}','\$\{escapeHtml\(normalized\)\}'\)"/);
assert.match(html, /const fence = \/```\(html\|htm\|css\|js\|javascript\|json\|python\|py\|txt\|text\|md\|markdown\|xml\|svg\|csv\)/, 'common previewable fence language labels are recognized');
const fnStart = html.indexOf('function previewCodeBlock(elementId, language) {');
const fnEnd = html.indexOf('\n        window.downloadCodeBlock = function', fnStart);
assert.ok(fnStart >= 0 && fnEnd > fnStart, 'preview action handler is defined before the download handler');
const fnSource = html.slice(fnStart, fnEnd) + '\nthis.previewCodeBlock = previewCodeBlock;';
let rendered = 0, renderedResult = true, shown = '', notice = '';
const memory = new Map();
const codeNodes = { code1: { textContent: '<!doctype html><html><body><h1>Chess</h1></body></html>' }, code2: { textContent: '   ' } };
const context = {
  document: { getElementById: id => codeNodes[id] || null },
  localStorage: { setItem: (k,v) => memory.set(k, String(v)) },
  window: { innerWidth: 390 },
  CODE_MEMORY_KEY: 'vila_test_code',
  latestGeneratedCode: '',
  latestGeneratedCodeType: '',
  runGeneratedCode: () => { rendered++; return renderedResult; },
  showMobilePanel: x => { shown = x; },
  showToast: (x) => { notice = x; }
};
vm.runInNewContext(fnSource, context);
assert.equal(context.previewCodeBlock('code1', 'html'), true);
assert.equal(context.latestGeneratedCode, codeNodes.code1.textContent);
assert.equal(context.latestGeneratedCodeType, 'html');
assert.equal(rendered, 1, 'Preview button runs the actual preview renderer');
assert.equal(shown, 'preview', 'Preview switches to the panel on small screens');
assert.equal(memory.get('vila_test_code'), codeNodes.code1.textContent);
notice = '';
renderedResult = false;
assert.equal(context.previewCodeBlock('code1', 'html'), false, 'missing preview surface does not report success');
assert.doesNotMatch(notice, /Đã chuyển mã vào Live Preview/, 'failed preview does not show success toast');
renderedResult = true;
assert.equal(context.previewCodeBlock('code2', 'html'), false, 'empty code does not report success');
assert.equal(context.previewCodeBlock('code1', 'py'), false, 'unsupported code is not falsely reported as runnable');
assert.match(notice, /hỗ trợ Preview trực tiếp/);

// Voice Studio must live in the side menu and must never remain a full-width floating body control.
assert.match(html, /#mainMenu #vilaVoiceStudioBtn\{position:static!important/);
assert.match(html, /html body>#vilaVoiceStudioBtn\{display:none!important\}/);
assert.match(html, /const buttons=\[\.\.\.document\.querySelectorAll\('\[id=\"vilaVoiceStudioBtn\"]'\)\]/, 'all duplicate Voice Studio buttons are normalized');

// Do not auto-open Preview for every generated code response; it opens on explicit command or button click.
assert.match(html, /if\(shouldRunPreviewCommand\(promptText\)\)/);
assert.doesNotMatch(html, /window\.previewCodeBlock = undefined/);
console.log('PASS V69 chat UX: greeting lifecycle, compact status, real preview button/renderer wiring, version sync, and Voice Studio placement');
