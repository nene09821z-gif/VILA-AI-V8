# VILA AI Studio V72 — kiểm tra giao diện và nhập liệu

## Đã kiểm tra tự động trên mã nguồn

- [x] Các mode nâng cao không còn nằm trên cùng hàng với ô nhập; chuyển vào menu dấu cộng.
- [x] Bật/tắt phản hồi nhanh, Max và tìm kiếm web không bật toast thành công mỗi lần chạm.
- [x] Vùng header model không có tooltip trình duyệt gây bật chữ khi nhấn/giữ.
- [x] Enter tôn trọng trạng thái composition/IME và không submit do auto-repeat.
- [x] Khi API lỗi, nội dung câu hỏi được khôi phục vào ô nhập; file sẵn sàng được khôi phục vào khay.
- [x] Trạng thái hoạt động/fallback không phô tên provider/model; khối `<think>` và header chỉ thị nội bộ được lọc khỏi đầu ra lưu/hiển thị.
- [x] 36/36 nhóm kiểm tra tự động; 14 inline script, 64 tệp JavaScript độc lập, 35 style blocks thực tế và 3 JSON được phân tích cú pháp thành công.

## Chưa xác minh — cần làm trên Android thật

1. Build APK debug rồi cài lên điện thoại. Thử gõ tiếng Việt có dấu, chọn từ gợi ý bàn phím, bấm Enter, bấm gửi và bấm gửi liên tục.
2. Làm một lượt API thành công, rồi thử API key sai hoặc mất mạng. Xác nhận câu hỏi không bị mất và có thể sửa/gửi lại.
3. Chạm các icon micro, dấu cộng, Max, Tìm kiếm web và bộ chọn model nhiều lần. Kiểm tra không có toast/tooltip vô duyên; model hiện tại vẫn rõ trong header.
4. Mở menu dấu cộng và bật/tắt Suy luận sâu, AI Agent, Tìm kiếm web, Tự chọn model, Ưu tiên miễn phí. Đóng menu rồi gửi câu hỏi để xác nhận lựa chọn được lưu.
5. Chuyển Dark → Light → Dark, tải lại và kiểm tra bong bóng người dùng, văn bản AI, mã, bảng, nút và thanh đang xử lý giữ đúng tương phản.
6. Mở Preview từ một khối HTML/JavaScript; thử nút Xem trước, đóng và mở lại. Xác nhận mã chạy trong iframe cô lập và lỗi thực tế không bị báo thành thành công.
7. Mở Voice Studio từ menu ba gạch, đóng bằng nút/X, rồi quay về chat; xác nhận không che ô nhập.
8. Lặp lại ở chiều rộng 360–430 px với bàn phím đang mở và cỡ chữ Android lớn.

**Chưa hoàn tất kiểm thử thiết bị:** không đánh dấu các mục trên là đạt cho tới khi kiểm tra trực quan trên Android/WebView thật. Build, API thật, login và phát hành Google Play chưa được xác minh trong phiên này.
