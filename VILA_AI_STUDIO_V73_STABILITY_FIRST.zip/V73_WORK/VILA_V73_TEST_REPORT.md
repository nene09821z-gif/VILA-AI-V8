# VILA AI Studio V73 — Stability First

## Changes
- Synchronized application version to 73.0.0 and Android versionCode 86 across runtime, Gateway, docs, workflow metadata and regression expectations.
- Added a final theme-stability CSS layer to remove provider/model labels and expanded raw reasoning details from the chat status panel.
- Normalized reasoning/status surfaces to shared theme variables and removed the old fixed dark-blue gradient from the final override layer.
- Kept the existing Preview execution implementation unchanged.
- Updated old version assertions in regression tests instead of deleting tests.

## Verification run in this workspace
- `node scripts/run-all.js`: **36/36 test groups passed**.

## Not yet verified
- Android Gradle build, signed APK/AAB, actual WebView rendering on a physical device, live API calls and real provider fallback.
- The CSS change reduces the reasoning panel to a compact status display. Confirm visually on the device with both light and dark themes before release.
