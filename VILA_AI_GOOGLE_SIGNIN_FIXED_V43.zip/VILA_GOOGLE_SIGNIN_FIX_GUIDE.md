# VILA AI — Khắc phục đăng nhập Google

## Những gì được sửa trong V43

- Nút Google chờ đúng lời gọi bất đồng bộ và hiện lỗi nếu không khởi chạy được.
- Android Credential Manager được bọc bằng xử lý ngoại lệ ở cả lúc mở hộp thoại và lúc nhận token.
- Lỗi hủy đăng nhập, không tìm thấy credential, lỗi mạng và lỗi OAuth được đưa ra màn hình thay vì để nút chờ im lặng.

## Cấu hình Firebase bắt buộc

1. Mở Firebase Console → project `vila-studio` → Authentication → Sign-in method → bật **Google**.
2. Vào Project settings → General → ứng dụng Android `com.vila.ai`; thêm SHA-1 của chứng thư đã ký **đúng APK đang cài**.
3. Giữ OAuth Client ID loại **Web application** làm `webClientId` — giá trị hiện có trong `app/google-services.json` đã là loại Web.
4. Build lại mã nguồn V43 trên GitHub Actions và cài APK mới để có xử lý lỗi mới.
5. Mở artifact `sha1-fingerprint.txt` của chính lần build đã tạo APK đang thử, rồi đối chiếu SHA-1. Nếu dùng release, tốt nhất ký bằng keystore ổn định và đăng ký SHA-1 của keystore đó. Đừng đăng ký SHA-1 của APK debug khác với APK đang cài.

`Firebase đã sẵn sàng` chỉ xác nhận Firebase Android khởi tạo được; nó không xác nhận Google OAuth đã khớp package + SHA-1. Nếu cấu hình đúng mà vẫn lỗi, đọc dòng thông báo mới trên màn hình đăng nhập sau khi bấm Google.

## Giới hạn kiểm tra

Các bài test trong gói kiểm tra logic/cấu trúc nguồn; đăng nhập Google thực tế phải được thử trên thiết bị với Firebase Console và chứng thư ký đúng. Trong môi trường đóng gói này không có Android SDK/Gradle để xác nhận một APK mới đã build thành công.
