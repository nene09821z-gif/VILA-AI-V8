# V43 — Google Sign-In no-response fix

- Await the browser/Android Google sign-in call from the login gate so immediate JavaScript bridge errors are surfaced.
- The login gate now restores button state and displays a clear error if Google sign-in fails to start.
- Wrap native Credential Manager launch and result parsing in exception handling; emit Firebase UI callbacks for synchronous and asynchronous errors rather than leaving the gate waiting.
- Add user-facing diagnostics for cancellation, missing credentials, network/provider errors, malformed OAuth client IDs, and likely Android certificate SHA-1 mismatch.

## Firebase Console requirement

Google Sign-In still requires the Android OAuth client for package `com.vila.ai` to contain the SHA-1 fingerprint of the certificate that actually signs the installed APK. The GitHub Actions debug signing key may differ from a previously registered SHA-1 and is not a stable release key. Use the SHA-1 artifact from the same build, add it in Firebase Console, and rebuild/reinstall; for releases, prefer a persistent keystore and register that key's SHA-1.
