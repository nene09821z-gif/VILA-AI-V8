# V43 — Firebase login button feedback fix

- Added validation for email and password on the VILA auth gate.
- Login/register/reset/Google actions now immediately update the visible status and disable buttons while the request is pending.
- Native Firebase auth callbacks now write success/failure details into the gate status and re-enable controls.
- If no auth callback arrives, the gate reports a timeout hint instead of appearing unresponsive.
- Verified JavaScript Firebase wiring, V42 gateway checks, 24 endpoint tests, and 5 backend tests.
- Note: live Firebase authentication still depends on Firebase Console providers, network connectivity, and correct project/signing configuration.
