# VILA AI V32 — build from GitHub

This ZIP contains the Android project source, not a prebuilt APK. Upload the complete repository to GitHub and run the existing Android Build and Verify workflow.

## New UI behavior
- Startup chooser no longer displays the very large VILA banner image; it uses a compact VILA mark and fits small Android screens.
- The first welcome overlay remains animated for about three seconds, unless the system requests reduced motion.
- Open the `+` tools menu to set image ratio (default `16:9`) and size (default `1K`) before choosing **Tạo ảnh AI**.
- During requests, the UI reports high-level stages such as processing, web lookup when enabled, and answer review. It does not display a model's private chain-of-thought.
- Search source favicon chips are shown only when actual source URLs are present in a `Nguồn Web`/`Sources` section.

## API key storage
- Android: API keys are encrypted with AES-GCM using Android Keystore-backed keys in app-private SharedPreferences. If secure save fails, the UI keeps settings open and reports an error instead of silently writing the secret to localStorage.
- Browser-only fallback: localStorage is used because Android Keystore is unavailable; do not use that mode on a shared device.
- Never commit API keys, Firebase service-account credentials, or GitHub tokens to the repository.

## Important limitations
Offline smoke tests can validate syntax, UI wiring, and helper logic. A real image generation request needs a valid Gemini API key, model access, quota, and network. A successful APK build must be confirmed by GitHub Actions.


### Current generation routes
- Image: `gemini-nano-banana-2.1` with selectable aspect ratio (default 16:9) and size (default 1K; 2K/4K where supported).
- Video: `gemini-omni-1.1-flash` through the Gemini Interactions REST API; REST video data is extracted from `steps[].content[]`.
- Speech: `gemini-3.8-flash-tts`, the stable model recommended by current Google docs.
- Thinking status shows task-level progress only; it does not expose hidden internal reasoning.
