# VILA v26 — provider model catalog and token-budget fix

- Defined `getProviderTokenBudget(provider, model, messages)` in the shared inline app script, fixing the runtime `ReferenceError` for Gemini and OpenAI-compatible providers. It uses task-aware budgets and clamps them to the selected model’s reported output limit when available.
- Added labeled starter suggestions for Gemini, Groq, Cerebras, and OpenRouter. These are only fallbacks; a successful `/models` request replaces them with models actually exposed to the configured API key/account. Custom APIs can still use a manually entered Model ID.
- Improved model discovery metadata and filtering for text/chat-capable models; OpenRouter model discovery asks for text-output models.
- Centralized model catalog caching so successful discovery from either “Tải model mới nhất từ API” or “Kiểm tra kết nối” is persisted and the selected model is saved.
- Saving configuration triggers model synchronization; the app now reports the number of models loaded or a clear message when synchronization fails.
- Updated the suggested default model IDs for Groq and Cerebras to GPT OSS IDs.

Provider model availability and API-key permissions are verified live by each provider endpoint; the starter suggestions do not guarantee availability for every account.
