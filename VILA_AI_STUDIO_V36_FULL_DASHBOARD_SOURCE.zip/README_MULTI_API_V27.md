# VILA AI V27 - Multi-provider models

## Build/import

This ZIP is the Android Gradle project root. The model-discovery HTML is already integrated into `app/src/main/assets/index.html`; do not copy the standalone HTML over other files. Open the project root containing `settings.gradle` and `build.gradle` in Android Studio/AIDE, allow Gradle sync, then build the debug APK. The app entry point is `app/src/main/java/com/vila/ai/MainActivity.java`.

## Load your available models

1. Open Settings and select Gemini, Groq, Cerebras, OpenRouter or Custom API.
2. Enter the API key and verify the Base URL is correct for that service. For Custom API, use the provider's OpenAI-compatible API root (usually ending in `/v1`).
3. When the API key/Base URL field loses focus, VILA attempts to fetch models automatically. You can also press **Tải model mới nhất từ API** to force a fresh request.
4. After a successful response, the main model selector refreshes with the model IDs returned by the selected provider and the catalog is cached per provider.

Suggestions displayed before a successful request are offline fallback entries and may not be enabled by your account. API responses are the source of truth for the live list. Provider-side quotas, billing, model permissions and service status can still prevent a returned model from generating a response. Never share your API keys.
