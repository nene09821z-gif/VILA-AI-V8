# VILA AI 25 — multi-provider reliability update

## What changed
- Fixed a blocking routing issue where submitting a chat forcibly switched the selected provider to Gemini. Selected provider is now retained.
- Gemini uses its native `models.list` and `models.generateContent` endpoints; uploaded image data is passed as inline image parts.
- Groq, Cerebras, OpenRouter, and Custom use OpenAI-compatible `GET /models` and `POST /chat/completions`. Model options are refreshed from the active provider API, so the list can follow that provider's live catalog instead of relying only on hard-coded examples.
- Model catalog cache stores a bounded snapshot for startup speed; use **Tải model mới nhất từ API** after entering/saving an API key to re-sync. Only models returned by the user's API key/provider can be selected. Known non-chat models are filtered using endpoint metadata and ID patterns. If a compatible Custom API has no `/models` listing, enter its model ID manually and use the API test/chat to verify access.
- Reasoning effort is sent only in compatible formats where possible. If an endpoint rejects an optional reasoning parameter, VILA retries once without that parameter. Reasoning configuration does not expose a model's private chain of thought.
- API keys for non-Gemini providers now use Android Keystore AES-GCM in the Android app; old localStorage keys are migrated where possible. Development/browser fallback uses localStorage only when the Android bridge is unavailable.
- Firebase email/password auth now requires a real Firebase project configuration and never pretends a local profile is a real cloud account. See `FIREBASE_SETUP_V25.txt`.
- Added Actions secret injection for Firebase config and bumped app version to 25.0.0.

## Providers and endpoints
- Gemini REST: `GET /v1beta/models`, `POST /v1beta/models/{model}:generateContent`.
- Groq: `https://api.groq.com/openai/v1/models` and `/chat/completions`.
- Cerebras: `https://api.cerebras.ai/v1/models` and `/chat/completions`.
- OpenRouter: `https://openrouter.ai/api/v1/models` and `/chat/completions`.
- Custom: OpenAI Chat Completions-compatible endpoint; use `/models` to populate the list or enter a manual Model ID if discovery is unavailable.

## Build output
GitHub Actions builds a debug APK, source ZIP, and complete ZIP artifact. The workflow does not artificially pad the APK; final size is determined by Android build output and bundled assets.

## Validation scope
JavaScript syntax and ZIP integrity can be checked in CI. Actual API authentication, provider quota, model availability, CORS/network policy, and Firebase sign-in must be verified with the user's own keys and Firebase project.

## API/model compatibility
- Gemini uses the native `generateContent` REST endpoint and response format.
- Groq, Cerebras, OpenRouter, and Custom API use OpenAI-compatible Chat Completions endpoints.
- Model IDs are discovered from each provider’s `/models` endpoint after the provider key is configured; model lists can change or be permission-limited.
- Non-chat models (embeddings, speech/transcription, moderation/guard, and outputs that are not text) are filtered from the chat selector where the API reports enough metadata.
- Custom API must implement OpenAI Chat Completions and an appropriate `/models` endpoint. API-specific proprietary protocols need a dedicated adapter.
- API keys are encrypted at rest through Android Keystore in the native Android build. They must still be sent to the selected provider to make inference requests.

## Firebase Authentication
A real Firebase project is required. Follow `FIREBASE_SETUP_V25.txt`; enable Email/Password in Firebase Console and provide Web App config through GitHub Actions secrets or `firebase-config.js`. Without valid config, the app correctly reports Firebase as not configured instead of pretending to sign in. Google redirect may be limited by embedded-WebView restrictions. Chat history is local; Firebase sign-in alone does not sync it to cloud.

## Verification scope
JavaScript syntax and archive integrity are checked in this package workflow. An actual API test requires each user's own valid API key and network; Android APK compilation must run in GitHub Actions. No exact APK size (including 17 MB) is guaranteed.
