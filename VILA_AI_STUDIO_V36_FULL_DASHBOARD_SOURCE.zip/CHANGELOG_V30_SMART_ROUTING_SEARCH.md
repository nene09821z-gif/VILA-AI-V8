# VILA AI V30 — Smart model routing, web search, and free-tier preference

## Added
- Provider-scoped Auto Model ranking for Gemini, Groq, Cerebras, OpenRouter, and custom OpenAI-compatible endpoints. The router never switches to a different provider's API key during an ordinary chat request.
- Adaptive task profile for coding/debugging, reasoning/math, multimodal input, and general chat. Complex tasks request higher reasoning effort where the provider/model supports it; private chain-of-thought is not exposed.
- Free-tier preference toggle. Auto Model can prioritize models whose provider catalog advertises zero pricing or whose current Gemini API pricing lists a Free Tier. The dropdown labels these as `Free`/`Free Tier`.
- OpenRouter free seeds: `openrouter/free`, `nvidia/nemotron-3-ultra-550b-a55b:free`, `nvidia/nemotron-3.5-lightning:free`, `poolside/laguna-s-2.1:free`, and `poolside/laguna-xs-2.1:free`. Successful `/models` synchronization remains authoritative, and free offerings can change or be rate-limited.
- Search mode for all configured providers: Gemini Google Search grounding, OpenRouter `openrouter:web_search`, Groq Browser Search on supported GPT-OSS models, or a bridge provider to retrieve web context before the selected model writes the answer.
- Gemini `gemini-2.5-flash`/`gemini-2.5-flash-lite` are the only Gemini grounding routes when Free preference is enabled; if they fail, app tries a separately configured Groq/OpenRouter bridge rather than silently switching to a possibly paid Gemini grounding route.
- Search toggle and automatic-search preference are now separate. Explicit Search mode is a user toggle; auto-search only runs for prompts detected as needing current information.
- Source regression smoke test runs in GitHub Actions.

## Correctness fixes
- Removed a dead provider bootstrap IIFE that executes while provider state variables are still in the JavaScript temporal dead zone and silently does nothing.
- Retry requests without unsupported reasoning parameters even when web-search tools are enabled.
- Use `max_completion_tokens` for Cerebras requests and Groq GPT-OSS requests.
- Guard against stale model IDs when auto-routing is disabled, and display a toast when Auto Model uses a different model than the manually displayed selection.

## Important limitations
- Free labels indicate provider-reported free pricing/free-tier availability, not guaranteed quota, permanent availability, or unrestricted use. Quotas and regional/account eligibility belong to the provider.
- Search costs/availability are provider-dependent. OpenRouter's server-side search may add search costs; Gemini 3.x grounding is unavailable on the free tier in the current price table. When Gemini-only free grounding is selected, VILA tries the free-grounded Gemini 2.5 Flash route; if the API denies it, the app needs another configured search bridge (Groq GPT-OSS or OpenRouter).
- Cerebras and arbitrary custom endpoints do not have a universal built-in search tool. To search while using these as the answer model, configure at least one search-capable provider key as a bridge.
- This changelog records code-level changes; the included tests are offline regression checks, not live provider/API certification.
