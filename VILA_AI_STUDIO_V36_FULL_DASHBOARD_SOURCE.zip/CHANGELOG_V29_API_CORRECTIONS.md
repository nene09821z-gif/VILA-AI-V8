# VILA AI V29 — API correctness fixes

## Fixed
- Bumped Android version to `29.0.0` / version code `38` so Android can accept this repair as an update over the V28 package (provided the signing key/package identity match).
- Declared the Gemini image, video, and text-to-speech model IDs in one endpoint registry; video requests no longer target `undefined`.
- Updated image generation to use `gemini-nano-banana-2.1` and the current Interactions API input shape.
- Updated text-to-speech to use `gemini-3.8-flash-tts` and structured user-input/speech-metadata content.
- Fixed REST TTS response parsing: raw Interactions API audio is read from `steps[].content[]` (with SDK-style `output_audio.data` also supported); added a 45-second request timeout.
- Fixed video API-key lookup so browser builds can read the saved `vila_gemini_key` as well as the Android secure bridge.
- Made image-action JSON detection brace-aware so braces inside a prompt do not truncate the action object.
- Fixed a duplicate `apiKeyLabel` HTML ID that caused provider changes to relabel the Base URL field instead of the API Key field; CI now rejects duplicate IDs.
- Fixed Google Search grounding while Groq/Cerebras/OpenRouter is selected: search now uses the separate Gemini key and Gemini base URL rather than the active provider key/URL.
- Added a 90-second timeout and recoverable timeout status to direct Gemini chat requests to prevent indefinite loading on stalled connections.
- Strengthened the assistant prompt to avoid inventing API/model names and to distinguish static inspection from executed tests.
- Added CI regression checks for configured model IDs and use of the central endpoint registry.

## Verification scope
- Node.js syntax checks for external and inline JavaScript, plus Android Manifest XML parsing.
- Static regression checks for the corrected API model wiring.
- A full Android Gradle build must still be confirmed by the GitHub Actions run because this local environment does not have the Android SDK/Gradle toolchain installed.
