# VILA AI V32 — Android UI, image generation, and API-key hardening

- Removed the oversized image banner from the startup chooser; replaced it with compact text/icon branding for Android screens.
- Added image aspect-ratio and resolution controls. Default: 16:9, 1K. Settings persist locally; image output uses the Gemini Interactions API `response_format`.
- Added a lightweight task-status panel showing high-level activity stages, not private chain-of-thought.
- Added source favicon chips for actual URLs found in a response's Web Sources section.
- Hardened API-key persistence: Android builds use Android Keystore and fail visibly rather than silently falling back to plaintext localStorage. Browser-only mode remains usable and warns about its weaker storage.
- Added one controlled retry at 1K for image-size/format rejections.
- Bumped Android version to 32.0.0 (versionCode 40).

## Validation

The included offline regression test checks source-level invariants and representative pure helpers. It does not prove provider API keys, quotas, live image generation, or a successful APK build; run GitHub Actions to build the Android artifact.

- Updated video/TTS endpoint seed IDs to the documented `veo-3.1-lite-generate-preview` and `gemini-3.1-flash-tts-preview` identifiers.


## Last-mile QA fixes
- The legacy extras script no longer overwrites the V32 task-status panel; its old animated thinking panel is only a fallback for older HTML builds.
- TTS uses the current stable `gemini-3.8-flash-tts` model and retains REST `steps[].content[]` audio extraction.
- Video generation uses `gemini-omni-1.1-flash` via the Interactions REST API, reads `steps[].content[]` video payloads, supports text-to-video and image-to-video, can be cancelled, and provides a native Downloads action on Android.
- Added regression coverage for both REST and SDK-shaped video output objects.
- Removed the unused 919 KB oversized startup banner asset.
- Released completed request abort controllers to prevent long-session growth in the cancellation set.
