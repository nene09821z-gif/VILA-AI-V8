# VILA Multi-API v26 — model discovery fix

## Changes
- Fixed the missing `getProviderTokenBudget()` runtime function used by Gemini and OpenAI-compatible chat calls.
- Added starter model suggestions for Gemini, Groq, Cerebras, and OpenRouter. Suggestions are replaced by the live account-specific catalog after model discovery succeeds.
- Model discovery uses Gemini `GET /v1beta/models`; Groq `GET /openai/v1/models`; Cerebras `GET /v1/models`; OpenRouter `GET /api/v1/models?output_modalities=text`; and the configured Custom API's compatible `/models` endpoint.
- Successful discovery from either **Tải model mới nhất từ API** or **Kiểm tra kết nối** is cached for the next app launch. Saving a provider configuration now triggers synchronization and reports the model count or a failure message.
- Output token budget respects the selected model's reported completion-token cap, when available.

## How to use
1. Open **Cài đặt** and choose the provider (Gemini, Groq, Cerebras, OpenRouter, or Custom API).
2. Enter the API key and check the provider-specific Base URL. Keep the provider's own base URL unless using a compatible proxy.
3. Tap **Lưu cấu hình**. The app attempts to refresh the list automatically.
4. Select a model from the dropdown in the main header. To reload later, return to **Cài đặt** and tap **Tải model mới nhất từ API**.
5. If a Custom API does not expose `/models`, enter the exact ID from that API in **Model ID thủ công**.

## Important
Starter entries marked `gợi ý` are a fallback list only and may not be enabled for every API key or account. The live provider `/models` result is authoritative. A real API key and internet connection are required to retrieve the live list and test inference. This source ZIP does not include a built APK.
