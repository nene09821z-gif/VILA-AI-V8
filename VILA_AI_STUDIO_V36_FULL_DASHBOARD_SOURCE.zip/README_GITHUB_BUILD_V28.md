# VILA AI V28 — GitHub Actions build and real API workflow

## Build APK on GitHub (recommended)

1. Create a new repository in your own GitHub account.
2. Upload/commit the **contents** of this ZIP to repository root (do not upload the ZIP file as a single file).
3. Open **Actions** and enable workflows for the repository if GitHub asks.
4. Open **VILA AI - Android Build and Verify**, select **Run workflow**, and run it on `main` or `master`. It also runs on pushes and pull requests to those branches.
5. Open the completed run and download artifact `VILA-AI-Build-Files-*`.
6. `VILA-AI-debug.apk` is the installable debug APK. `VILA-AI-release.apk` is unsigned unless you configure your own release signing secrets. Debug APK is for testing, not Play Store distribution.

The workflow runs Node syntax checks, HTML inline-script checks, Android manifest validation, Gradle unit-test task, `assembleDebug`, `assembleRelease`, and `lintDebug` on the GitHub runner. APK build success is only confirmed after the workflow completes successfully; the ZIP itself is source, not a prebuilt APK.

## Toolchain used by the workflow

- Android Gradle Plugin 9.1.1
- Gradle 9.3.1 (the version required by AGP 9.1.1)
- JDK 17
- compile SDK 37 / target SDK 36 / minimum SDK 24
- Node.js 24 for JavaScript syntax validation

Compatibility references: Android Developers, AGP 9.1.1 release notes: https://developer.android.com/build/releases/agp-9-1-0-release-notes

## Real AI behavior

- The app uses real provider APIs. Enter a provider API key in Settings and use **Load/Refresh models** or Save. The provider's `/models` or provider-specific model listing response is the source of actual available model IDs where supported.
- The displayed model list cannot include models a provider does not expose or your API key is not entitled to use. API keys are not shipped inside this source ZIP.
- Project ZIPs are parsed in the app; selected complete text files are included in the model request; returned full-file edits are validated and applied to the in-app workspace; ZIP and primary HTML exports are downloadable. Large projects may require narrower, iterative tasks due to model context limits; files omitted from the prompt are preserved, not falsely reported as edited.
- If using the optional Node agent server, set `VILA_SERVER_TOKEN` to a long, random value, configure `GEMINI_API_KEY`, use HTTPS, and host only on infrastructure you control. Authenticated requests fail closed when the token is missing. The build endpoint is disabled unless you explicitly set `ALLOW_UNTRUSTED_BUILDS=true`; enabling it permits executing untrusted submitted build files, so use only an isolated container/server you control. Do not commit API keys, tokens, or keystores.

## Release signing secrets (optional)

Add GitHub repository Actions secrets:

- `ANDROID_KEYSTORE_BASE64`: Base64 encoding of your own `.jks`/`.keystore` file
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Use a keystore you own and back it up securely. Never share it publicly. If these are not configured, the workflow still builds debug APK and an unsigned release APK.

Optional Firebase Web App configuration secrets are read only by the build workflow if provided: `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_STORAGE_BUCKET`, `FIREBASE_MESSAGING_SENDER_ID`, and `FIREBASE_APP_ID`.
