# VILA AI V31 — reasoning, file workspace and chat UX

- Adds adaptive task classification for coding, reasoning, research and multimodal work.
- Adds an optional second-pass answer verifier for complex coding/reasoning and web-search responses. It returns a checked final answer, not private chain-of-thought.
- Adds a visible Stop (square) button during AI requests and aborts supported chat, search, image and long-running video polling requests.
- Adds direct image-generation routing so requested images are generated and shown inline in chat when Gemini Image API access is configured.
- Adds a 3-second animated welcome splash and a local activity ranking board based on real device-local counters (no fabricated global rankings).
- Adds a full-workspace scope option; source files are selected in context limits, and the workspace editor continues preserving unedited files and binaries.
- Expands editable source/config file extensions and removes project creator attribution from the active UI/system prompt.

Validation performed offline: source syntax and project/workflow checks are run in GitHub Actions. Live provider access and APK build success still require configured API keys and the GitHub build workflow.

- Corrects the offline Gemini Free-tier seeds and cached model classification for Gemini 3.8/3.7/3.6/3.5 Flash, 3.5 Flash-Lite, 3.1 Flash-Lite, and 2.5 Flash/Flash-Lite. Search grounding is treated separately from free chat inference.
