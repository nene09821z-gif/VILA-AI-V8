# VILA AI V30 — Hướng dẫn Auto Model, Free và Tìm kiếm Web

## 1. Chọn model theo đúng cổng API

Mở **Cài đặt → Nhà cung cấp API**, chọn Gemini/Groq/Cerebras/OpenRouter hoặc Custom API, nhập API key và Base URL nếu cần, rồi bấm đồng bộ model. Danh sách lấy từ endpoint `/models` của chính cổng được chọn; danh sách tĩnh trong mã chỉ là dự phòng khi chưa đồng bộ.

- **Auto model** bật: VILA xếp hạng model theo tác vụ (code/debug, suy luận/toán, ảnh hoặc chat thường) và thử model thay thế khi model hiện tại không khả dụng.
- **Auto model** tắt: VILA cố định model đã chọn trong cổng đang dùng.
- **Ưu tiên Free** bật: Auto Model ưu tiên model có giá $0/free-tier được xác nhận từ metadata hoặc bảng giá chính thức hiện tại. `gemini-3.8-flash` vẫn có trong danh sách chất lượng cao nhưng không được VILA tự gắn nhãn miễn phí; tắt ưu tiên Free để cho nó cơ hội cao hơn.

Không phải nhà cung cấp nào cũng công bố giá trong `/models`. Nếu không có metadata giá, app không tự tuyên bố model đó miễn phí.

## 2. Tìm kiếm web

Công tắc **Tìm kiếm** trong thanh nhập là chế độ tìm web bắt buộc cho câu hỏi tiếp theo. Khi công tắc tắt, VILA vẫn tự bật tìm kiếm cho câu hỏi chứa dấu hiệu cần dữ liệu mới (tin tức, giá, phiên bản API/SDK, download, nguồn...). Quy tắc tự tìm được cấu hình riêng trong **Bảo mật & tự động hóa**.

- **Gemini:** dùng Google Search grounding; khi **Ưu tiên Free** bật, app chỉ dùng `gemini-2.5-flash`/`gemini-2.5-flash-lite` cho Google Search grounding để tránh âm thầm dùng tuyến grounding trả phí; nếu cả hai tuyến lỗi thì app thử bridge Groq/OpenRouter đã cấu hình. Tắt **Ưu tiên Free** mới cho phép thử các model Gemini khác để grounding. Tài liệu API hiện tại nêu grounding miễn phí với Gemini 2.5 Flash trong giới hạn của Google; Gemini 3.x grounding không nằm trong free tier ở bảng giá hiện hành.
- **OpenRouter:** dùng server tool `openrouter:web_search`; model tự quyết định có cần truy vấn hay không. Kết quả tìm kiếm có thể có phí ngoài phí token model.
- **Groq:** Browser Search gốc chỉ được hỗ trợ cho `openai/gpt-oss-20b`, `openai/gpt-oss-120b` và `openai/gpt-oss-safeguard-20b`. Model Groq khác có thể dùng GPT-OSS làm bridge nếu key Groq có quyền truy cập model đó.
- **Cerebras/Custom:** không có công cụ tìm kiếm web tiêu chuẩn dùng chung cho mọi endpoint. Cần thêm ít nhất một key tìm kiếm (Gemini/Groq/OpenRouter) để lấy dữ liệu web, rồi model được chọn sẽ tổng hợp câu trả lời.

Nếu provider từ chối tool, quota hết hoặc không có search bridge đã cấu hình, VILA sẽ báo lỗi rõ thay vì giả vờ đã tìm kiếm.

## 3. Model free được thêm làm dự phòng

Danh sách offline hiện gồm:
- Google Gemini API: `gemini-3.7-flash`, `gemini-3.6-flash` và `gemini-3.5-flash-lite` được gắn nhãn Free Tier; `gemini-2.5-flash` cùng `gemini-2.5-flash-lite` là tuyến Google Search grounding miễn phí trong giới hạn hiện hành. `gemini-3.5-flash` có trong catalog dự phòng nhưng không được gắn nhãn Free.
- OpenRouter: `openrouter/free`, `nvidia/nemotron-3-ultra-550b-a55b:free`, `nvidia/nemotron-3.5-lightning:free`, `poolside/laguna-s-2.1:free`, `poolside/laguna-xs-2.1:free`.
- Groq: `openai/gpt-oss-120b`, `openai/gpt-oss-20b`, `qwen/qwen3.8-27b` là model catalog gợi ý; mức giá/giới hạn tài khoản phải kiểm tra trong Groq Console.
- Cerebras: `gpt-oss-120b`, `zai-glm-4.7` và một model nhẹ làm catalog dự phòng; tình trạng khả dụng thực tế lấy từ `/models`.

Free catalog thay đổi thường xuyên. Hãy bấm **Làm mới model** để app đồng bộ từ endpoint thật; model free có thể bị giới hạn tốc độ, thay đổi hoặc ngừng cung cấp. API key hợp lệ vẫn bắt buộc.

## 4. Kiểm thử

GitHub Actions chạy `node scripts/smoke-test-v30.js`, kiểm tra cấu hình model, adapter tìm kiếm, tách riêng chế độ search và các lỗi tương thích request. Đây là kiểm tra mã nguồn offline. Để xác nhận API thật, chạy app với key của từng cổng và thử (1) chat thường, (2) câu hỏi thời sự khi Search tắt, (3) bật Search và hỏi thông tin mới, (4) đổi model khi Auto Model bật/tắt.
