> **V36 Full Dashboard:** xem [README_V36_FULL_DASHBOARD.md](README_V36_FULL_DASHBOARD.md) để biết thay đổi giao diện, icon SVG cục bộ, năm cổng API và lưu key an toàn. Muốn build APK bằng GitHub Actions, xem [README_GITHUB_BUILD_V28.md](README_GITHUB_BUILD_V28.md). ZIP này là mã nguồn, không phải APK đã build.

---

# VILA AI Studio V36 — Full Neon Dashboard & AI Project Workspace

- Gemini 3.8 Flash là model ưu tiên cho code; tác vụ lập trình tự dùng `reasoning_effort=high`.
- Tăng ngân sách output cho code để giảm tình trạng câu trả lời bị cắt giữa file.
- Gemini API Key được lưu bằng Android Keystore-backed AES-GCM và giữ qua các lần mở app; chỉ mất khi dữ liệu ứng dụng/khóa thiết bị bị xóa hoặc ứng dụng bị gỡ.
- Gửi ZIP tạo **Project Workspace**: đọc cây file, giữ file binary, giữ nguyên file không sửa và cho AI sửa trực tiếp các file cần thiết.
- AI Code Pro dùng giao thức `<file path="...">FULL CONTENT</file>` / `<delete path="..."/>`, tránh `...`, TODO hoặc placeholder.
- Có kiểm tra nhanh JavaScript/JSON và JavaScript trong HTML trước khi xuất ZIP.
- Xuất lại ZIP giữ toàn bộ project gốc, không còn chỉ đóng gói một file `generated.*`.
- Không tuyên bố build thành công nếu chưa chạy Gradle/build thật; kiểm tra tĩnh chỉ là lớp bảo vệ bổ sung.
- Web search, ảnh, PDF, DOCX, video/Veo và các chức năng Gemini hiện có được giữ nguyên.

## Lưu ý về API key

Key không thể được đảm bảo "vĩnh viễn" theo nghĩa tồn tại sau khi người dùng gỡ app hoặc xóa dữ liệu ứng dụng. Trong phạm vi cài đặt hiện tại, key được lưu bền trên thiết bị bằng Android Keystore và tự nạp lại sau khi mở app.


## V23 Agent mode
V23 adds an optional `server/` Agent Server. It can keep `GEMINI_API_KEY` off the APK, stream Gemini responses, build uploaded Android ZIPs, return compiler logs and APKs, and support an automatic repair loop. Configure the Agent Server URL in VILA Settings.

For real builds set `ALLOW_UNTRUSTED_BUILDS=true` only on a trusted/isolated server. Also set `VILA_SERVER_TOKEN` and use HTTPS/reverse proxy for remote access.
