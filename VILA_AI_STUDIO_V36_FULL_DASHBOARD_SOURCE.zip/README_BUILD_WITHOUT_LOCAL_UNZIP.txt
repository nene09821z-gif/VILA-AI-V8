VILA AI - BUILD FROM GITHUB ACTIONS

This ZIP includes the Android project and workflow at repository-root paths.
Workflow path: .github/workflows/main.yml
Android SDK setup uses android-actions/setup-android@v4 with packages: '' and then installs platform/build-tools explicitly.

IMPORTANT:
GitHub Actions does not execute a workflow that exists only inside an uploaded ZIP file. To run this workflow, the repository must contain the extracted project files at the repository root, including the hidden .github/workflows/main.yml file. You do not need to unzip it on your phone if you upload the files using GitHub's web editor or another repository upload method, but GitHub must see the files themselves, not only the ZIP archive.

After committing the project files: GitHub -> Actions -> VILA AI - Build APK and ZIP -> Run workflow.
