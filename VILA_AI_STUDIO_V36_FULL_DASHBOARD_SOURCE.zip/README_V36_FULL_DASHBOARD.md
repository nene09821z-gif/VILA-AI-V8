# VILA AI Studio V36 — Full Dashboard

This version updates the actual Android WebView app UI, not only a mockup.

## Highlights
- Three-area dashboard matching the supplied visual direction: navigation sidebar, chat workspace/tool header, and right-side provider/features panels.
- Sharp vector icons via inline SVG, so the icon display no longer depends on the Font Awesome CSS/font CDN.
- Provider-specific key slots for Gemini, Groq, Cerebras, OpenRouter, and Custom API remain independent. In the Android app, keys are stored using the existing Android Keystore-backed encryption bridge in `MainActivity.java`; in browser-only mode, fallback persistence uses localStorage, which is not equivalent to Android Keystore security.
- Existing chat, attachments, project ZIP, coding, image/video controls, voice, account/settings, memory, and code preview elements are preserved and wired to their existing handlers.

## Build
Use the repository's GitHub Actions workflow or Android Gradle build settings included here. The generated ZIP is source code, not a tested APK. Check `CHANGELOG_V36_FULL_DASHBOARD.md` for scope and validation limits.

## API key safety
Do not paste or commit real API keys into source code, GitHub Actions files, or screenshots. Configure keys in the app settings. Each provider has its own independent key slot. The providers' available models, rates, and quota can change and are not guaranteed by the UI.


## V36 key-handling details
- Settings keep independent credentials for Gemini, Groq, Cerebras, OpenRouter, and Custom API. Android builds call the existing Android Keystore bridge per provider; do not enter actual keys into source files.
- Browser-only mode has no Android Keystore and therefore still uses browser localStorage; this is less secure than the installed Android app.
- Inline SVG paths cover all 67 icon names found in the current static HTML; icon rendering no longer relies on Font Awesome's remote font/CSS.

- The icon map includes the eye-slash password visibility control; all Font Awesome icon names found in the current HTML have vector paths.
