# VILA AI Studio V36 — Full Dashboard

- Rebuilt the visible dashboard to follow the supplied reference: persistent left navigation, tool-rich header, central chat/composer, right model/API rail, and feature list.
- Replaced Font Awesome font dependency for UI icons with a local inline SVG icon engine. SVG icons use vector paths and are processed both on initial render and for dynamically inserted message/status controls.
- Preserved existing API settings and Android Keystore key storage. Added per-provider key state indicators for Gemini, Groq, Cerebras, OpenRouter, and Custom API; selecting each provider opens that provider's settings. Keys are not shown in the new model rail.
- Fixed startup provider selection so the selected provider is respected instead of always forcing Gemini. Added all supported provider choices to startup.
- Restored explicit Live Preview visibility when generated code is run and return-to-chat behavior when Preview is closed.
- Added interactive Explore AI dialog and wired header tools to the existing reasoning, web-search, code, image, video, and file actions.

## Validation note

This update is source-level. The ZIP and source structure can be checked locally, and JavaScript syntax/static smoke tests can run. A successful Android build, API authentication, media-generation support, and device-specific behavior still need to be verified in the target build environment and on an Android device. Provider model availability/free quota is controlled by each provider/account.

- V36: key-status icon updates now support converted SVG nodes, so switching providers and refreshing key status no longer relies on finding legacy `<i>` elements.
- V36: source regression checks cover the dashboard controls, five API-provider slots, Keystore encryption bridge, SVG icons, and code-preview visibility.

- Added the missing `eye-slash` vector path used by API-key visibility controls, eliminating the last missing icon name found in a static source scan.
