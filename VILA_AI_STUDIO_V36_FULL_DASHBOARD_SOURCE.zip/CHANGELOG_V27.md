# VILA AI V27 - model discovery integration

- Integrated the corrected HTML directly at `app/src/main/assets/index.html`, the asset served by the Android WebView.
- Added live provider model catalog cache source metadata and persistent per-provider catalogs.
- Added auto-discovery after the API key or Base URL field loses focus.
- Deduplicated matching model sync requests made by field blur and Save; explicit manual refresh forces a fresh API request.
- Kept model catalogs separated per provider and key material out of the saved catalog.
- Model discovery reads each provider's models endpoint; only the provider's actual response is considered live/authoritative. Seed entries remain suggestions until an API sync succeeds.

Note: provider entitlement, API credits, model deprecations, CORS/network conditions, and server-side availability are controlled by the provider. A returned model may still reject inference if its service has separate permission or quota requirements.
