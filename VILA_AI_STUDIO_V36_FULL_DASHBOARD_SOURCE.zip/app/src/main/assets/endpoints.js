/* VILA multi-provider API endpoints. No AI model runs on the phone. */
window.VILA_ENDPOINTS = Object.freeze({
  gemini: Object.freeze({
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    nativeBase: 'https://generativelanguage.googleapis.com/v1beta',
    defaultModel: 'gemini-3.8-flash',
    imageModel: 'gemini-nano-banana-2.1',
    videoModel: 'gemini-omni-1.1-flash',
    ttsModel: 'gemini-3.8-flash-tts'
  }),
  groq: Object.freeze({
    baseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'openai/gpt-oss-120b'
  }),
  cerebras: Object.freeze({
    baseUrl: 'https://api.cerebras.ai/v1',
    defaultModel: 'gpt-oss-120b'
  }),
  openrouter: Object.freeze({
    baseUrl: 'https://openrouter.ai/api/v1',
    defaultModel: 'openrouter/free'
  })
});
