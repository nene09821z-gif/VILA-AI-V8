/* Firebase Web App client configuration (public project identifiers; no server secrets).
 * Option A: configure GitHub repository Actions secrets described in FIREBASE_SETUP_V25.txt.
 * Option B: paste your own Firebase Web App config here before building.
 * Email/password login is REAL only after this config is valid and Email/Password is enabled.
 */
window.VILA_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
