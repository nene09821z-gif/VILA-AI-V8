/* VILA extras: chế độ đen, giao diện suy luận tương thích, tạo video qua Gemini Omni Interactions. */
(function () {
  'use strict';
  // ---------- Theme: Tối / Đen (AMOLED) ----------
  const css = document.createElement('style');
  css.textContent = `
  html[data-theme="black"]{--vila-bg:#000;--vila-panel:#000;--vila-card:#0a0a0a;--vila-border:#1c1c1c}
  html[data-theme="black"] body,html[data-theme="black"] [class*="bg-dark-"],html[data-theme="black"] .glass-panel{background:#000!important}
  .vila-think{margin:2px 0;color:#a1a1aa;font-size:12.5px}
  .vila-think summary{display:flex;align-items:center;gap:8px;cursor:pointer;list-style:none;user-select:none}
  .vila-think summary::-webkit-details-marker{display:none}
  .vila-think-dot{width:8px;height:8px;border-radius:50%;background:#a78bfa;animation:vilaPulse 1.1s ease-in-out infinite}
  .vila-think.done .vila-think-dot{animation:none;background:#52525b}
  .vila-think-label{background:linear-gradient(90deg,#71717a,#e4e4e7,#71717a);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:vilaShimmer 1.8s linear infinite}
  .vila-think.done .vila-think-label{animation:none;background:none;color:#a1a1aa}
  .vila-think-steps{margin:6px 0 0 4px;padding-left:14px;border-left:1px solid #3f3f46;list-style:none}
  .vila-think-steps li{padding:2px 0;opacity:.85}
  .vila-think-body{margin:6px 0 0;padding-left:14px;border-left:1px solid #3f3f46;white-space:pre-wrap;max-height:240px;overflow:auto}
  @keyframes vilaPulse{50%{opacity:.25;transform:scale(.7)}}
  @keyframes vilaShimmer{to{background-position:-200% 0}}`;
  document.head.appendChild(css);
  function applyTheme(t) { document.documentElement.setAttribute('data-theme', t); try { localStorage.setItem('vila_theme', t); } catch (_) {} }
  window.vilaSetTheme = applyTheme;
  applyTheme((function () { try { return localStorage.getItem('vila_theme') || 'dark'; } catch (_) { return 'dark'; } })());

  if (typeof window.updateVilaThinkingPanel !== 'function') {
    // ---------- Trạng thái suy nghĩ: fallback cho bản HTML cũ ----------
    const STEPS = ['Đọc kỹ câu hỏi', 'Lục lại trí nhớ cuộc trò chuyện', 'Cân nhắc vài hướng trả lời', 'Chọn hướng ổn nhất', 'Soạn câu trả lời có dấu đàng hoàng'];
    window.appendTypingIndicator = function () {
      const box = document.getElementById('chatMessages'); if (!box) return '';
      const id = 'typing_' + Date.now(), t0 = Date.now(); window.__vilaThinkStart = t0;
      const d = document.createElement('div'); d.id = id; d.className = 'flex gap-4 items-start';
      d.innerHTML = '<div class="vila-avatar shrink-0">V</div><details class="vila-think" open><summary><span class="vila-think-dot"></span><span class="vila-think-label">Đang suy nghĩ…</span><span class="vila-think-time">0s</span></summary><ol class="vila-think-steps"></ol></details>';
      box.appendChild(d); if (window.scrollToBottom) window.scrollToBottom();
      const ol = d.querySelector('ol'), tm = d.querySelector('.vila-think-time'); let i = 0;
      const add = function () { const li = document.createElement('li'); li.textContent = STEPS[i]; ol.appendChild(li); };
      add();
      const timer = setInterval(function () {
        if (!document.getElementById(id)) return clearInterval(timer);
        const s = Math.round((Date.now() - t0) / 1000); tm.textContent = s + 's';
        if (s > 0 && s % 2 === 0 && i < STEPS.length - 1) { i++; add(); }
      }, 1000);
      return id;
    };
    window.vilaShowThought = function (result) {
      const box = document.getElementById('chatMessages'); if (!box || !box.lastElementChild) return;
      const secs = Math.max(1, Math.round((Date.now() - (window.__vilaThinkStart || Date.now())) / 1000));
      const reviewed = !!(result && result.reviewed);
      const el = document.createElement('div'); el.className = 'vila-think done'; el.style.marginLeft = '48px';
      const head = '<span class="vila-think-dot"></span><span class="vila-think-label">🧠 Đã hoàn tất xử lý ' + secs + ' giây</span>';
      const steps = ['Đọc yêu cầu và ngữ cảnh phù hợp', 'Kiểm tra giả định và các trường hợp dễ sai', reviewed ? 'Đã rà soát câu trả lời thêm một lượt' : 'Kiểm tra nội dung đầu ra'];
      el.innerHTML = '<details><summary>' + head + '</summary><ol class="vila-think-steps"></ol></details>';
      const list = el.querySelector('.vila-think-steps');
      steps.forEach(function (step) { const li = document.createElement('li'); li.textContent = step; list.appendChild(li); });
      box.insertBefore(el, box.lastElementChild);
    };
  }

  // ---------- Tạo video bằng Gemini Omni Interactions API (REST) ----------
  function extractInteractionVideoData(payload) {
    if (!payload || typeof payload !== 'object') return null;
    const direct = payload.output_video || payload.outputVideo;
    if (direct && typeof direct.data === 'string' && direct.data.trim()) {
      return { data: direct.data.replace(/\s+/g, ''), mime: direct.mime_type || direct.mimeType || 'video/mp4' };
    }
    const steps = Array.isArray(payload.steps) ? payload.steps : [];
    for (let i = steps.length - 1; i >= 0; i--) {
      const step = steps[i];
      const contents = Array.isArray(step && step.content) ? step.content : [];
      for (let j = contents.length - 1; j >= 0; j--) {
        const item = contents[j];
        if (item && (item.type === 'video' || String(item.mime_type || '').toLowerCase().startsWith('video/')) && typeof item.data === 'string' && item.data.trim()) {
          return { data: item.data.replace(/\s+/g, ''), mime: item.mime_type || 'video/mp4' };
        }
      }
    }
    return null;
  }
  window.vilaExtractInteractionVideoData = extractInteractionVideoData;

  function interactionVideoBlob(data, mime) {
    const encoded = String(data || '').replace(/\s+/g, '');
    if (!encoded || !/^[A-Za-z0-9+/=_-]+$/.test(encoded)) throw new Error('Gemini trả về dữ liệu video không hợp lệ.');
    if (encoded.length > 300 * 1024 * 1024) throw new Error('Video trả về quá lớn để xử lý an toàn trên điện thoại. Hãy thử yêu cầu video ngắn hơn.');
    const binary = atob(encoded.replace(/-/g, '+').replace(/_/g, '/'));
    const chunks = [];
    const chunkSize = 64 * 1024;
    for (let offset = 0; offset < binary.length; offset += chunkSize) {
      const slice = binary.slice(offset, Math.min(binary.length, offset + chunkSize));
      const bytes = new Uint8Array(slice.length);
      for (let i = 0; i < slice.length; i++) bytes[i] = slice.charCodeAt(i);
      chunks.push(bytes);
    }
    const safeMime = /^video\/(mp4|webm|quicktime)$/i.test(String(mime || '')) ? String(mime).toLowerCase() : 'video/mp4';
    return new Blob(chunks, { type: safeMime });
  }

  window.vilaMakeVideo = async function (prompt, imageDataUrl) {
    const E = window.VILA_ENDPOINTS && window.VILA_ENDPOINTS.gemini;
    const key = typeof window.getGeminiKey === 'function' ? String(window.getGeminiKey() || '').trim() : '';
    if (!E || !E.nativeBase || !E.videoModel) throw new Error('Cấu hình model video chưa đầy đủ. Hãy cập nhật endpoints.js.');
    if (!key) throw new Error('Cần Gemini API Key đã lưu an toàn để tạo video.');
    const cleanPrompt = String(prompt || '').trim();
    if (!cleanPrompt) throw new Error('Hãy nhập mô tả video trước.');
    const input = [];
    const m = imageDataUrl && /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=_-]+)$/i.exec(imageDataUrl);
    if (imageDataUrl && !m) throw new Error('Ảnh tham chiếu phải là PNG, JPEG hoặc WebP hợp lệ.');
    if (m) input.push({ type: 'image', data: m[2], mime_type: m[1].toLowerCase() });
    input.push({ type: 'text', text: cleanPrompt });

    if (window.VILA_USER_STOP_REQUEST) throw new Error('Đã dừng tác vụ video theo yêu cầu.');
    const controller = typeof window.createVilaChatAbortController === 'function' ? window.createVilaChatAbortController() : new AbortController();
    const signal = controller.signal;
    let timedOut = false;
    const timer = setTimeout(function () { timedOut = true; controller.abort(); }, 300000);
    try {
      const response = await fetch(E.nativeBase.replace(/\/+$/, '') + '/interactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify({ model: E.videoModel, input: m ? input : cleanPrompt, response_format: { type: 'video', aspect_ratio: '16:9' } }),
        signal
      });
      const raw = await response.text();
      let payload = {};
      try { payload = raw ? JSON.parse(raw) : {}; } catch (_) {}
      if (!response.ok) {
        const error = new Error(payload?.error?.message || payload?.message || ('Gemini Video API lỗi HTTP ' + response.status));
        error.status = response.status;
        throw error;
      }
      if (payload.status && !['completed', 'succeeded'].includes(String(payload.status).toLowerCase())) {
        throw new Error('Tác vụ video chưa hoàn tất (trạng thái: ' + String(payload.status) + '). Hãy thử lại sau.');
      }
      const video = extractInteractionVideoData(payload);
      if (!video) throw new Error('Gemini không trả dữ liệu video trong steps[].content[].data. Hãy thử prompt ngắn hơn hoặc kiểm tra quyền model.');
      const blob = interactionVideoBlob(video.data, video.mime);
      const url = URL.createObjectURL(blob);
      return { url: url, data: video.data, mime: blob.type || 'video/mp4', filename: 'VILA_' + Date.now() + '.mp4' };
    } catch (error) {
      if (window.VILA_USER_STOP_REQUEST || (error && error.name === 'AbortError' && !timedOut)) {
        const stopped = new Error('Đã dừng tác vụ video theo yêu cầu.'); stopped.name = 'AbortError'; throw stopped;
      }
      if (timedOut || (error && error.name === 'AbortError')) throw new Error('Tạo video đã quá 5 phút hoặc bị hủy. Hãy thử mô tả ngắn hơn, rồi thử lại.');
      throw error;
    } finally {
      clearTimeout(timer);
      if (typeof window.releaseVilaChatAbortController === 'function') window.releaseVilaChatAbortController(controller);
    }
  };
  window.vilaAppendVideo = function (result) {
    const box = document.getElementById('chatMessages'); if (!box) return;
    const video = typeof result === 'string' ? { url: result, data: '', mime: 'video/mp4', filename: 'VILA-video.mp4' } : (result || {});
    if (!video.url) throw new Error('Không có URL video để hiển thị.');
    const d = document.createElement('div'); d.className = 'flex gap-4 items-start';
    d.innerHTML = '<div class="vila-avatar shrink-0">V</div><div style="min-width:0;max-width:100%"><p style="margin-bottom:8px">Video đã tạo xong 🎬</p><video controls playsinline preload="metadata" style="max-width:100%;width:100%;border-radius:12px"></video><p style="margin-top:6px;display:flex;gap:14px;flex-wrap:wrap"><a class="vila-video-download-link" download="VILA-video.mp4" style="color:#67e8f9;text-decoration:underline">Tải video</a><button type="button" class="vila-video-save-device" style="color:#a5b4fc;text-decoration:underline">Lưu vào Downloads</button></p></div>';
    d.querySelector('video').src = video.url;
    const link = d.querySelector('.vila-video-download-link'); link.href = video.url; link.download = video.filename || 'VILA-video.mp4';
    const save = d.querySelector('.vila-video-save-device');
    if (!(window.Android && typeof window.Android.saveBase64File === 'function' && video.data)) save.style.display = 'none';
    else save.addEventListener('click', function () {
      try { window.Android.saveBase64File(video.filename || 'VILA-video.mp4', video.data, video.mime || 'video/mp4'); if (window.showToast) window.showToast('Đang lưu video vào Downloads.', 'success'); }
      catch (error) { if (window.showToast) window.showToast('Không thể lưu video: ' + String(error && error.message || error), 'error'); }
    });
    box.appendChild(d); if (window.scrollToBottom) window.scrollToBottom();
  };
})();

/* V19: menu "+", camera/ảnh/video/ZIP, nút Suy nghĩ, nhãn giao diện */
(function () {
  'use strict';
  const $ = function (id) { return document.getElementById(id); };
  const ready = function (fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); };
  const toast = function (m, t) { if (window.showToast) window.showToast(m, t || 'info'); };
  const closeMenu = function () { if (window.closeInputTools) window.closeInputTools(); };

  function videoToFrames(file, n) {
    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(file), v = document.createElement('video');
      v.muted = true; v.playsInline = true; v.preload = 'auto';
      const out = [], base = file.name.replace(/\.[^.]+$/, '');
      const fail = function (msg) { URL.revokeObjectURL(url); reject(new Error(msg)); };
      v.onerror = function () { fail(file.name + ': không đọc được video này.'); };
      v.onloadedmetadata = function () {
        const dur = v.duration || 1, W = Math.min(768, v.videoWidth || 768), H = Math.round(W * (v.videoHeight || 432) / (v.videoWidth || 768));
        const c = document.createElement('canvas'); c.width = W; c.height = H; let i = 0;
        v.onseeked = function () {
          c.getContext('2d').drawImage(v, 0, 0, W, H);
          c.toBlob(function (b) {
            if (!b) return fail('Không lấy được khung hình.');
            out.push(new File([b], base + '-khung' + (i + 1) + '.jpg', { type: 'image/jpeg' })); i++;
            if (i >= n) { URL.revokeObjectURL(url); resolve(out); } else v.currentTime = dur * (i + 0.5) / n;
          }, 'image/jpeg', 0.8);
        };
        v.currentTime = dur * 0.5 / n;
      };
      v.src = url;
    });
  }

  ready(function () {
    const tb = $('themeToggleBtn'), tt = $('themeText');
    const label = function () { if (tt) tt.textContent = document.documentElement.getAttribute('data-theme') === 'black' ? 'Đen' : 'Tối'; };
    if (tb) tb.addEventListener('click', function () { window.vilaSetTheme(document.documentElement.getAttribute('data-theme') === 'black' ? 'dark' : 'black'); });
    new MutationObserver(label).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] }); label();

    const deep = $('deepThinkToggle'), lvl = $('reasoningLevel');
    if (deep && lvl) {
      deep.checked = lvl.value === 'high';
      deep.addEventListener('change', function () { lvl.value = deep.checked ? 'high' : 'medium'; lvl.dispatchEvent(new Event('change')); });
    }

    const cam = $('cameraInput'), med = $('mediaInput');
    if ($('cameraBtn')) $('cameraBtn').addEventListener('click', function () { closeMenu(); cam.click(); });
    if ($('mediaBtn')) $('mediaBtn').addEventListener('click', function () { closeMenu(); med.click(); });
    if ($('makeVideoBtn')) $('makeVideoBtn').addEventListener('click', function () {
      closeMenu(); const t = $('userPrompt'); if (!t) return;
      if (!/^\/video\s/i.test(t.value)) t.value = '/video ' + t.value;
      t.focus(); t.dispatchEvent(new Event('input')); toast('Mô tả video rồi bấm gửi. Đính kèm 1 ảnh để biến ảnh thành video.');
    });
    if ($('generateImageBtn')) $('generateImageBtn').addEventListener('click', closeMenu);
    if ($('attachFileBtn')) $('attachFileBtn').addEventListener('click', closeMenu);
    if (cam) cam.addEventListener('change', function (ev) { const f = Array.from(ev.target.files || []); ev.target.value = ''; if (f.length) window.handleFiles(f); });
    if (med) med.addEventListener('change', async function (ev) {
      const files = Array.from(ev.target.files || []); ev.target.value = ''; const out = [];
      for (const f of files) {
        if (f.type.indexOf('video/') === 0) {
          if (f.size > 200 * 1024 * 1024) { toast(f.name + ': video quá lớn (tối đa 200MB).', 'error'); continue; }
          try { toast('Đang lấy khung hình từ video…'); out.push.apply(out, await videoToFrames(f, 3)); } catch (err) { toast(err.message, 'error'); }
        } else out.push(f);
      }
      if (out.length) window.handleFiles(out);
    });
  });
})();
