# VILA V28 — Image action execution fix

## Change
- The normal chat response handler now detects a structured `action: generate_image` response.
- It calls the existing Gemini image-generation function, displays returned image bytes in chat, and replaces the raw JSON with a normal status message.
- If image generation fails, the chat reports the actual error rather than claiming an image was created.

## Scope
This connects the existing chat action response to the already implemented image-generation path. It does not guarantee that a configured Gemini model/API supports image generation; the runtime API response determines success.
