# VILA AI V28 — GitHub build / coding-agent hardening

- Modernized CI to AGP 9.1.1 + compatible Gradle 9.3.1, JDK 17, SDK 37/36 and Node 24.
- GitHub Actions performs real Gradle build/test/lint tasks and uploads debug/release APKs, complete source ZIP, logs and checksums.
- Improved request transcript isolation: workspace context is copied into a request rather than mutating saved chat messages.
- Workspace snapshots clone content before edits; snapshot is taken before the first file write/delete.
- Fixed `/video` branch loading-indicator reference ordering.
- Hardens the optional agent server: if no `VILA_SERVER_TOKEN` is configured, protected endpoints are not authorized. `/api/health` remains public.
- Project AI editing remains real API-based and only applies full-file responses for files that were included in the request context; binary and unselected files are preserved.
- Added README_GITHUB_BUILD_V28.md with repository setup, artifact retrieval, secrets, and server safety notes.

## Limitations

The source bundle was statically validated in this environment. A real Android APK cannot be claimed as built until the workflow is run on GitHub with network access to Gradle and Android SDK repositories. The project does not embed provider API keys.
