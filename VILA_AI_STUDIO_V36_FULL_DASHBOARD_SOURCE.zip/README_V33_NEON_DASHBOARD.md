# VILA AI Studio V33 — Neon Dashboard

This update redesigns the main workspace to follow the supplied VILA neon-blue reference: fixed desktop navigation, glowing model selector, hero welcome banner, dark glass panels, compact action controls, and a mobile-friendly layout. Existing chat, provider/model selection, file attachment, image/video generation, voice input/output, search, code tools, memory, settings, and export handlers are retained rather than replaced with mock buttons.

## Important
- This is Android/GitHub build source, **not a prebuilt APK**.
- Real AI replies and generation depend on a working provider API key, network access, supported model access, and any provider quotas. The UI cannot make every model free or guarantee every external API always works.
- The project was not compiled into an APK in this environment. Run the repository's GitHub Actions Android build and check its result before installing.
- Do not publish API keys in the repository or share them in screenshots.

## V34 — pixel-sharp icon refinement
- Preserves existing application handlers and feature logic while refining icon rendering and focus visibility.
- Replaces the emoji robot in the welcome banner with a crisp inline SVG robot illustration and uses the bundled VILA logo asset.
- Standardizes vector icon glyph alignment and high-DPI anti-aliasing styles.
- Note: Font Awesome remains loaded through the project's existing CDN reference; offline icon-font availability depends on network/cache.
