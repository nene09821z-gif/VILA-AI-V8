# Báo cáo kiểm thử — Cờ Vua VILA v3.38.0

Ngày thực hiện: 2026-10-19

## Tóm tắt kết quả

- **Test tĩnh:** 224/224 đạt (`npm run test:static`; trước khi sửa: 210/210, thêm 14 bài mới).
- **Kiểm tra cú pháp:** 117/117 tệp JavaScript/MJS trong `src`, `server`, `scripts`, `tests` qua `node --check`.
- **Full suite (`npm test`):** 226/230 đạt. 4 test không khởi tạo vì thiếu package, **không phải assertion fail**: `alternate-engine`, `chess`, `v3-25-features` (thiếu `chess.js`) và `social` (thiếu `express`). Môi trường chỉnh sửa không có mạng nên không cài được dependency.
- **Kiểm tra trình duyệt thật (Chromium 141, Playwright):** chạy trên **trang mẫu** dựng lại cấu trúc màn chơi, nạp `style.css` + `pro-ui.css` + `ui-pro.js` thật. **Chưa chạy toàn bộ ứng dụng** vì thiếu `chess.js`.
- **Build web/Vite, Capacitor, Gradle, APK:** chưa chạy, chưa có APK. **Chưa thử trên thiết bị Android thật.**

## Thay đổi trong bản này

Tất cả là bổ sung; không xóa hay đổi tên module nào. Bản v3.37.0 nguyên vẹn nằm trong ZIP sao lưu `CO_VUA_VILA_V3_37_0_BACKUP.zip`.

| Hạng mục | Tệp | Nội dung |
|---|---|---|
| Hàm thuần | `src/ui-pro.js` (mới) | `evalBarShare`, `evalBarText`, `evalBarAriaLabel`, `isMateScore`, `clockUrgency`, `currentPlyIndex`, `buildMoveRows` |
| Lớp CSS | `src/pro-ui.css` (mới) | vùng chạm 44 px (con trỏ thô), focus, thanh đánh giá, cảnh báo đồng hồ, nước đi hiện tại, safe-area, giảm chuyển động, tương phản cao, forced-colors |
| Nối vào app | `src/main.js` | import module/CSS; `updateEvaluationMeter`, `renderClockDisplay`, `renderMoveList`; thêm `#evaluationMeterText` và biến `clockBaseMs` |
| Phiên bản | `package.json`, `index.html`, `server/index.js`, `public/sw.js`, `scripts/fetch-piece-sets.mjs`, các test phiên bản | 3.37.0 → 3.38.0 |
| Tài liệu | `CHANGELOG.md`, `README.md`, `BUILD_ANDROID_GITHUB.md` | cập nhật; báo cáo cũ `TEST_REPORT_V3_37_0.md` được thay bằng báo cáo này (bản cũ còn trong ZIP sao lưu) |

Một lỗi nhỏ được phát hiện nhờ test mới và đã sửa ngay: `toFixed(1)` làm 0,35 hiện thành "0.3" nhưng 0,45 thành "0.5"; nhãn điểm nay làm tròn bằng số nguyên (nửa lên) nên đối xứng.

Một phát hiện về mã cũ: cuối `style.css` có các quy tắc `!important` cho `.clock-face`; lần chạy trình duyệt đầu cho thấy màu cảnh báo đồng hồ bị đè. Đã xử lý bằng bộ chọn `#app` + `!important` trong `pro-ui.css`. Các quy tắc `.is-active`/`.is-flagged` cũ trong `style.css` có thể cũng bị đè bởi chính các quy tắc `!important` đó; mình **không đổi** vì ngoài phạm vi và cần xem trên app thật.

## Kiểm tra đã chạy

| Phạm vi | Kết quả | Ghi chú |
|---|---:|---|
| `tests/ui-pro.test.js` | 7/7 đạt | đường cong thanh đánh giá (đơn điệu, đối xứng, chặn biên), điểm chiếu hết từ `scoreSideToWhiteCentipawns`, nhãn/aria, ngưỡng đồng hồ, hàng nước đi chỉ có 1 ô active |
| `tests/v3-38-upgrade.test.js` | 7/7 đạt | phiên bản đồng bộ, `pro-ui.css` nạp sau `style.css`, module cũ vẫn tồn tại, nối đúng vào `main.js`, CSS không ẩn control nào |
| Toàn bộ test tĩnh | 224/224 | gồm 210 bài cũ không đổi hành vi |
| Cú pháp | 117/117 | |
| Chromium, điện thoại 390×844 và 360×740 | đạt | không tràn ngang; mọi nút đo được ≥ 44×44 px; ô cờ 46 px / 42 px |
| Chromium, desktop 1280×800 | đạt | không tràn ngang; nút giữ kích thước cũ (không ép 44 px khi chuột) |
| Đồng hồ trong Chromium | đạt | "sắp hết giờ" chữ #FFB3B3 + viền/nền đỏ; "ít thời gian" chữ #FFC04D + viền vàng |
| `prefers-reduced-motion` | đạt | animation đồng hồ về `none` |
| Tương phản (tính tay theo WCAG) | đạt | nước hiện tại 9,55:1; đồng hồ vàng 10,75:1; đồng hồ đỏ 10,29:1 (trên nền panel #121A25) |

Trong Chromium có một lỗi tài nguyên `ERR_NAME_NOT_RESOLVED`: do `@import` Google Fonts ở đầu `style.css` khi không có mạng. Không liên quan đến mã mới; app cũ cũng có font dự phòng.

## Giới hạn — những gì chưa được kiểm chứng

1. **Chưa chạy app thật**: `main.js` chỉ được kiểm bằng `node --check` và test đối chiếu mã nguồn; việc nối thanh đánh giá, đồng hồ, danh sách nước đi vào luồng ván thật (kể cả cập nhật theo thời gian thực, hoàn tác/làm lại) **chưa được quan sát**.
2. **Chưa chạy 4 test tích hợp** cần `chess.js`/`express`.
3. **Chưa build** web/APK; chưa kiểm Stockfish 19/10 trong WebView Android, hiệu năng, bàn phím ảo, cử chỉ kéo quân, âm thanh, chế độ online/xếp hạng.
4. Trang mẫu dựng lại cấu trúc màn chơi nên **không thay thế** kiểm thử trên thiết bị: bố cục desktop hai cột, bottom-nav, màn xem lại, đấu trường, câu đố, trang chủ **chưa được chụp/đối chiếu** với CSS mới.
5. Phạm vi UI/UX bản này khá hẹp (bàn cờ, thanh đánh giá, đồng hồ, danh sách nước, trợ năng). Chưa làm: bảng kết thúc ván kiểu Chess.com, danh sách nước điều hướng được trong ván đang chơi, cài đặt tắt/mở hiệu ứng, bố cục một tay.
6. Thanh đánh giá và nhãn chất lượng là gợi ý trực quan/heuristic của VILA; không phải xác suất thắng đã hiệu chuẩn hay thuật toán của Chess.com.

## Cổng nghiệm thu còn lại

1. Đẩy toàn bộ ZIP lên GitHub; workflow phải qua `npm test` đầy đủ, `npm run build`, Capacitor sync và `./gradlew assembleDebug`.
2. Cài APK debug lên điện thoại: chơi một ván có đồng hồ ngắn (1+0) để xem cảnh báo đồng hồ, xem thanh đánh giá khi engine nghĩ, xem danh sách nước khi hoàn tác/làm lại, thử xoay ngang, chế độ giảm chuyển động của hệ thống.
3. Chỉ sau đó mới coi bản này là đã nghiệm thu.
