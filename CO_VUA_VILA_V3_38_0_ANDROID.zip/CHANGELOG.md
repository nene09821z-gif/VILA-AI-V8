# Changelog

## v3.38.0 — Lớp giao diện chuyên nghiệp (UI/UX), thanh đánh giá và đồng hồ rõ hơn

- Thêm lớp giao diện **chỉ bổ sung** `src/pro-ui.css` (nạp sau `style.css`) và module thuần `src/ui-pro.js`; không xóa, đổi tên hay ẩn bất kỳ module/chức năng cũ nào. Bản gốc v3.37.0 được giữ nguyên trong ZIP sao lưu đi kèm.
- **Thanh đánh giá**: dùng đường cong logistic thay cho `tanh` cũ, có vạch cân bằng ở 50%, nhãn số (+1.4, "Trắng chiếu hết"…), viền vàng khi có nước chiếu hết và `aria-label` tiếng Việt theo mức lợi thế. Đây là gợi ý trực quan, không phải xác suất thắng đã hiệu chuẩn.
- **Đồng hồ**: số có độ rộng cố định (tabular), cảnh báo "ít thời gian" (vàng) và "sắp hết giờ" (đỏ, nhấp nháy nhẹ) theo ngưỡng co giãn theo thời gian cơ bản; trạng thái cũng được đọc qua `aria-label`, không chỉ dựa vào màu. Các quy tắc `!important` cũ của `style.css` được vượt qua có chủ đích bằng bộ chọn `#app`.
- **Danh sách nước đi**: tô sáng nước vừa đi (`aria-current`), giữ cuộn xuống nước mới nhất, ô SAN dạng viên dễ chạm hơn.
- **Cảm ứng và trợ năng**: vùng chạm tối thiểu 44 px cho thiết bị con trỏ thô (điện thoại/máy tính bảng), vòng focus thống nhất, hỗ trợ `prefers-reduced-motion`, `prefers-contrast: more`, `forced-colors` và safe-area khi xoay ngang.
- Chốt phiên bản app/package/server/service worker ở 3.38.0; cập nhật các test phiên bản; thêm `tests/ui-pro.test.js` (7 bài) và `tests/v3-38-upgrade.test.js` (7 bài) vào `test:static`.
- Giới hạn: chưa build web/APK, chưa chạy trên thiết bị Android thật; giao diện được kiểm tra trên trang mẫu trong Chromium chứ chưa chạy toàn bộ app (thiếu `chess.js`/`express` trong môi trường chỉnh sửa). Chi tiết ở `TEST_REPORT_V3_38_0.md`.

## v3.37.0 — Stockfish 10 Arena, review page tách riêng, thêm bộ quân

- Thêm đối thủ Stockfish 10 (gói npm alias `stockfish-10` / `10.0.2`) dùng worker UCI riêng để thi đấu ở Đấu trường, không tranh worker với Stockfish 19. Build Android bắt buộc kiểm tra script và giấy phép engine cũ trước khi đóng gói.
- Trang kết quả/xem lại được tách thành route riêng, chia bố cục bàn cờ phát lại và biến engine với biểu đồ lợi thế, biên bản theo cặp, nhãn nước đi, thống kê Trắng/Đen và tải PGN. Không tuyên bố dùng CAPS2 của Chess.com.
- Bổ sung 3 palette quân gốc VILA (Amethyst, Sapphire, Bronze) và 4 bộ quân được cấp phép từ Lichess (`kiwen-suwi`, `firi`, `totoy`, `shapes`), kèm credit/license khi build.
- Chốt phiên bản app/package/server/workflow ở 3.37.0; thêm test cho giao thức UCI giả lập, cổng build Stockfish 10, route review và gradient SVG.
- Các bài test tĩnh được chạy trong môi trường sửa đổi; `npm install`, test tích hợp phụ thuộc `chess.js`/`express`, Gradle và chạy trên Android vẫn phải được xác nhận qua GitHub Actions/thiết bị. Không đánh dấu APK đã build nếu chưa có artifact.


## v3.36.0 — Bot mạnh hơn, đánh giá minh bạch và xem lại có gợi ý

- Android build thêm Stockfish 19 Full NNUE cùng Lite và ASM-JS dự phòng; thiết bị có bộ nhớ/CPU phù hợp tự ưu tiên Full. Máy yếu giữ Lite để giảm rủi ro tràn bộ nhớ; vẫn có thể chọn Full thủ công.
- Mặc định nghĩ sâu hơn (độ sâu trần 30, đến 2,6 giây mỗi nước); cài đặt tùy chỉnh của người dùng được giữ nguyên khi cập nhật.
- Gỡ nhánh tự bỏ qua Stockfish bằng nước heuristic/ngẫu nhiên trong chế độ Elo thấp. Dưới ngưỡng UCI_Elo của Stockfish, engine dùng Skill Level 0–7 theo từng mức; số Elo thấp được ghi rõ là preset luyện tập, không phải xếp hạng benchmark.
- Phân tích toàn ván dùng ngân sách thời gian hợp lý hơn, ghi lại nước tốt nhất engine tìm thấy trước từng nước thật, lưu SAN gợi ý, độ sâu, điểm trước/sau và mức điểm đã mất. Biên bản nay ghép nước Trắng/Đen theo lượt, hỗ trợ nhảy tới thế cờ và tổng hợp nhãn riêng cho mỗi bên.
- Xử lý vị trí chiếu hết/hòa cuối ván và quy đổi mate score; không còn tự gắn nhãn “Thiên tài” chỉ vì một quân có thể bị ăn. Chỉ đánh dấu nước khai cuộc khi mức mất điểm vẫn nhỏ. Changelog ghi lại các thay đổi theo từng phiên bản; ZIP phát hành chỉ kèm báo cáo tương ứng với phiên bản hiện tại.
- Bỏ các báo cáo cũ khỏi ZIP phát hành; giữ bộ test hồi quy lịch sử cần thiết.


## v3.35.0 — sảnh Trang chủ, câu đố Lichess và trải nghiệm Android

- Sửa lỗi khởi động sai: ứng dụng nay mở ở **Trang chủ/Sảnh VILA**, không mở thẳng vào bàn cờ. “Chơi ngay” mới bắt đầu ván, còn tùy chỉnh ván đấu đi tới thiết lập.
- Thiết kế lại trang chủ thành dashboard có thẻ hồ sơ/Elo cục bộ, thanh lối tắt 5 chế độ, hero chơi cờ, thẻ câu đố ngày, các chế độ AI/câu đố/bài học/phân tích/online, khu luyện tập và mini-game. Điều hướng gọn, responsive và safe-area cho Android.
- Kết nối Lichess Daily Puzzle qua `/api/puzzle/daily` và câu đố huấn luyện lần lượt qua `/api/puzzle/next` với 5 mức độ; kiểm tra PGN và toàn bộ dòng giải bằng `chess.js`, cache theo ngày, timeout và phương án dự phòng ngoại tuyến. Câu đố nhiều nước tự chơi nước đáp của đối thủ và chuyển câu tiếp sau khi giải.
- Giữ/chỉnh sửa lại hồ sơ Đấu trường AI, trang phân tích/xem lại, kho khai cuộc, chơi offline bằng Stockfish, luồng online qua backend/Lichess. Giữ rõ khác biệt giữa engine thật và profile phong cách.
- Bổ sung test hồi quy ngăn việc quay lại mở trực tiếp vào bàn cờ, test dữ liệu câu đố và validate cache.
- Ghi lại giới hạn: nếu không có mạng, daily cache chỉ hoạt động sau lần tải thành công trước đó; nếu không có cache, tự dùng thế đố sinh ngoại tuyến. APK phải build trên GitHub Actions trước khi coi là phát hành.

## v3.34.0 — VILA mobile-first refresh

- Thay shell điều hướng bằng thanh chế độ 5 mục, menu chức năng gọn và bottom navigation dành cho Android. Bản 3.34.0 mở thẳng vào phòng chơi; đây là lỗi đã được sửa ở v3.35.0 để app khởi động tại Sảnh Trang chủ.
- Thiết kế lại Đấu trường AI theo bố cục dọc: hồ sơ hai bot, bàn cờ lớn, biên bản nước đi và thiết lập nâng cao có thể thu gọn. Giữ nguyên Stockfish, luật chess.js, chế độ đấu trận/giải vòng tròn và tải PGN.
- Thêm trung tâm Mini-game ngoại tuyến: Rubik 3×3 với trạng thái sticker thật, xoay mặt qua swipe/nút U/D/L/R/F/B, xáo trộn, hoàn tác và kiểm tra đã giải; thêm 2048 (phím/swipe/nút hướng), lật thẻ ghi nhớ và Trượt số 15 với xáo trộn bằng các bước hợp lệ.
- Câu đố Luyện tự do, Puzzle Rush và Sinh tồn tự động chuyển bài sau khi giải đúng; thử thách hằng ngày vẫn giữ nguyên chính sách một đề mỗi ngày.
- Thêm kiểm thử thuần Node cho xoay Rubik/đảo ngược/xáo trộn và logic 2048.
- Các bot phong cách vẫn là profile tìm kiếm VILA dựa trên engine cục bộ, không được quảng cáo là các engine neural độc lập. Cần hoàn tất npm test và GitHub Actions để xác nhận build APK trước phát hành.


## v3.33.0 — giao diện phòng đấu và độ trễ thao tác
- Làm mới phòng đấu theo tông xanh đêm, thẻ người chơi/đồng hồ, thanh chức năng riêng và thanh thao tác năm nút trên điện thoại.
- Giảm chi phí chọn quân: chỉ cập nhật các ô cờ đổi trạng thái; chỉ tính nước hợp lệ khi cử chỉ đã thành thao tác kéo.
- Dùng hình học bàn cờ đã cache để xác định ô thả, tránh hit-test DOM qua `elementFromPoint()` trong lúc kéo.
- Giữ các view/chức năng cũ; thêm nút hủy lựa chọn nước đi.
- Pin phiên bản cụ thể cho các dependency trực tiếp; ZIP phát hành hiện tại kèm báo cáo `TEST_REPORT_V3_37_0.md`; báo cáo của phiên bản cũ không được đóng gói lại.

## v3.32.0 — kiểm thử và độ tin cậy
- Sửa lỗi cú pháp trong `tests/visual-settings.test.js` khiến bộ kiểm thử tĩnh không thể khởi chạy đầy đủ.
- Chuẩn hóa kỳ vọng của test: `normalizeVisualSettings` chỉ giữ các tùy chọn giao diện mà module thực sự hỗ trợ; không giả định module này quản lý kiểu quân cờ.
- Đồng bộ phiên bản package, tiêu đề, API health, service-worker cache và nhận diện tác vụ tải tài nguyên sang 3.32.0.
- Thêm cổng kiểm tra cú pháp JavaScript toàn bộ `src`, `server`, `scripts`, `tests` vào quy trình nghiệm thu thủ công.
- Xác minh lại 169 test tĩnh và ghi rõ bốn test tích hợp bị chặn bởi dependency chưa cài trong môi trường.

## v3.31.0 — phòng đấu hợp nhất, thương hiệu mới và luyện tập mở rộng

- Tái thương hiệu toàn bộ giao diện web/Android thành **Cờ Vua ViLa**, icon mới và bảng màu xanh ngọc–vàng.
- Phòng đấu gom thao tác nhanh, thiết lập đối thủ, khai cuộc, danh sách nước và phân tích vào một màn hình.
- Sửa hoàn tác để khôi phục đúng clock snapshot trước nước đi; thêm Làm lại và lịch sử đồng hồ theo từng nửa nước đi.
- Có 18 profile bot offline cấu hình được chọn (bao gồm 6 profile mới: Mentor, Hunter, Sentinel, Strategist, Endgame Pro, Chaos), ngoài engine Stockfish; phân biệt rõ profile cấu hình với engine neural được train độc lập.
- Mở rộng lên 19 kiểu quân cờ: 14 kiểu nội bộ (1 PNG + 13 phối màu vector) và 5 bộ SVG nguồn mở được tải, kiểm tra giấy phép, đóng gói offline trong release GitHub.
- Thêm Luyện tự do, Đề hôm nay xác định theo ngày, Puzzle Rush 3 phút và Sinh tồn 3 mạng; chống kết quả Worker cũ ghi đè lượt hết giờ.
- Test: 166/167 bài kiểm thử tĩnh đạt; full suite 168/173 đạt (5 lỗi khởi tạo trong môi trường hiện tại).

## Lịch sử trước đó

Các thay đổi lịch sử từ các bản v3.x trước được gom vào các tệp nguồn, commit và kiểm thử hiện tại. Báo cáo audit/changelog lặp theo từng phiên bản cũ đã được loại khỏi ZIP để giảm nhiễu.
