# Cờ Vua VILA v3.38.0 — Android-first chess club

VILA là ứng dụng cờ vua web đóng gói bằng Capacitor cho Android. Bản ZIP này là **mã nguồn để build**, không phải APK đã biên dịch.

## Điểm mới trong v3.38.0

### Giao diện và trải nghiệm cờ chuyên nghiệp
- **Thanh đánh giá** mượt hơn (đường cong logistic), có vạch cân bằng, nhãn số và viền vàng khi có chiếu hết; mô tả trợ năng bằng tiếng Việt. Chỉ là gợi ý trực quan từ điểm engine, không phải xác suất thắng.
- **Đồng hồ** có chữ số cố định chiều rộng và hai mức cảnh báo (ít thời gian / sắp hết giờ), không chỉ dựa vào màu.
- **Danh sách nước đi** tô sáng nước mới nhất và tự cuộn.
- **Chạm và trợ năng**: vùng chạm 44 px trên màn hình cảm ứng, vòng focus rõ, hỗ trợ giảm chuyển động, tương phản cao, forced-colors và safe-area khi xoay ngang.
- Tất cả là lớp bổ sung (`src/pro-ui.css`, `src/ui-pro.js`); chức năng và module cũ giữ nguyên.

## Điểm mới trong v3.37.0

### Engine và sức mạnh bot
- Stockfish 19 Full NNUE được đưa vào quy trình build Android cùng bản Lite và ASM-JS dự phòng. Full single-threaded có kích thước khoảng 94 MB và không cần cross-origin isolation; Lite nhẹ hơn đáng kể nhưng yếu hơn. [Tài liệu Stockfish.js và các biến thể engine](https://github.com/nmrugg/stockfish.js/blob/master/README.md).
- Chế độ tự động ưu tiên Full NNUE khi WebView báo bộ nhớ thiết bị từ khoảng 2 GiB và ít nhất 4 lõi; máy yếu hơn chọn Lite. Nếu Full không khởi tạo được, ứng dụng có chuỗi dự phòng Lite rồi ASM-JS.
- Bot không còn bỏ lượt Stockfish để đi ngẫu nhiên/heuristic chỉ nhằm giả lập Elo thấp. Dưới ngưỡng UCI_Elo, VILA dùng Skill Level 0–7 của Stockfish; các mức Elo thấp là preset luyện tập, **không phải rating được benchmark**.
- Mặc định tìm kiếm sâu hơn (depth tối đa 30, tối đa 2,6 giây mỗi nước); cài đặt tùy chỉnh đã lưu của người chơi được giữ lại.

### Đấu trường có hai thế hệ Stockfish
- Đấu trường có Stockfish 19 Full NNUE và Stockfish 10 cổ điển như hai đối thủ độc lập. Stockfish 10 được phân phối từ gói `stockfish.js@10.0.2`, chạy UCI trong Web Worker riêng, có giới hạn thời gian và kiểm tra tính hợp lệ của nước đi. Đây là engine đời cũ dùng để so sánh, không được quảng bá là mạnh hơn Stockfish hiện tại.
- Bản Android release bắt buộc xác nhận đủ script Stockfish 10 và giấy phép GPL đi kèm; thiếu một trong hai thì build dừng trước khi ghi đè thư mục engine.

### Xem lại ván và phân tích
- Xem lại từng nửa nước với nút về đầu/trước/sau/cuối, bàn cờ có tô nước cuối, biểu đồ lợi thế và biên bản ghép theo cặp Trắng/Đen. Chạm một nước để nhảy đến đúng thế cờ.
- Phân tích từng nước lưu điểm trước/sau theo góc nhìn Trắng, mức mất điểm theo bên vừa đi, độ sâu engine, nước tốt nhất tìm thấy ở thế trước và biến chính SAN. Panel hiển thị nhãn và số lượng chất lượng nước đi riêng cho Trắng và Đen.
- Phân tích toàn ván, gợi ý nước, phân tích 3 biến và trợ lý cờ chạy ở mức sức mạnh tối đa của engine, không thừa hưởng giới hạn Elo của bot trong ván.
- Các nhãn “Tốt nhất”, “Xuất sắc”, “Tốt”, “Chưa chính xác”, “Sai lầm”, “Blunder”, “Khai cuộc” và “Bỏ lỡ cơ hội thắng” là **heuristic VILA dựa trên điểm Stockfish**, không tuyên bố dùng cùng công thức phân loại độc quyền của Chess.com. Nước “Thiên tài” không được tự gán chỉ vì có quân bị tấn công.

### Giao diện, bài tập và game giải trí
- App mở vào **sảnh Trang chủ VILA**, không mở thẳng bàn cờ. Từ sảnh mới chọn Chơi, Bot, Câu đố, Bài học, Phân tích, Đấu trường AI, lịch sử hoặc mini-game.
- Giao diện ưu tiên điện thoại: xanh đêm/xanh lá mang thương hiệu VILA, điều hướng đáy, vùng chạm lớn, safe-area Android và bàn cờ responsive. Bố cục lấy cảm hứng từ ứng dụng cờ hiện đại, không sao chép logo hoặc tài sản thương hiệu riêng của Chess.com.
- Giữ thư viện khai cuộc ECO cục bộ, tra cứu tên/ECO/nước đi và các biến. Workflow kiểm tra ngưỡng dữ liệu khai cuộc trước build.
- Câu đố ngày sử dụng Lichess API, xác minh dòng nước bằng `chess.js`, lưu cache ngày và có bài ngoại tuyến khi không có mạng. Luyện tự do, Rush và Sinh tồn tự chuyển bài sau khi giải; bộ đố offline có độ khó tăng dần theo tiến trình.
- Bốn mini-game ngoại tuyến: Rubik 3×3 xoay mặt bằng vuốt hoặc nút U/D/L/R/F/B, xáo trộn/hoàn tác/làm mới; 2048; lật thẻ nhớ; Trượt số 15 với xáo trộn chỉ bằng nước đi hợp lệ.
- Giữ các chức năng sẵn có: nhập/xuất PGN, lịch sử cục bộ, đồng hồ, hoàn tác/làm lại, chú thích mũi tên/ô cờ, khai cuộc, profile bot offline, nhạc nền và các luồng online đã tích hợp.

## Online và offline
- Chơi với Stockfish, luyện bài và mini-game chạy cục bộ sau khi các engine cần thiết đã được tải/cache.
- Câu đố ngày và dữ liệu mở rộng cần internet; cache cục bộ được dùng khi có sẵn.
- Xếp hạng/cộng đồng/server yêu cầu backend và tài khoản đã cấu hình. Không đăng nhập hay backend thì những luồng phụ thuộc server không thể hoạt động đầy đủ.
- Engine Full NNUE khoảng 94 MB; workflow build nhúng nó để tăng sức mạnh, vì vậy APK lớn hơn. Trên máy yếu có thể dùng Lite hoặc để chế độ tự động chọn phù hợp.

## Build APK bằng GitHub Actions

1. Giải nén ZIP và đẩy **toàn bộ nội dung bên trong** lên một GitHub repository, giữ nguyên thư mục `.github/workflows/`.
2. Mở tab **Actions** và chạy workflow **Cờ Vua ViLa Android build**. Workflow này cũng chạy khi có push/PR.
3. Runner cài Node.js 22 và Java 21; cài package, kiểm tra cú pháp, chạy `npm test`, tải tài nguyên engine/bộ quân/kho khai cuộc, build web, sync Capacitor và chạy `./gradlew assembleDebug`.
4. Chỉ khi các bước bắt buộc đều thành công, tải artifact **`covua-vila-debug-apk`**. Artifact `test-report` giúp xem lỗi test, còn `covua-vila-android-gradle-source` là gói mã nguồn Gradle do workflow sinh ra.
5. Workflow **Cờ Vua ViLa build from ZIP/source** là lựa chọn chạy thủ công riêng; nó không chạy trùng trên mỗi lần push.

### Lệnh cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

`npm run build` cần các package Node và tải dữ liệu build lần đầu. Đối với build Android cần môi trường Java/Android phù hợp hoặc dùng GitHub Actions.

## Báo cáo kiểm thử

Xem [`TEST_REPORT_V3_38_0.md`](TEST_REPORT_V3_38_0.md). Trong môi trường biên tập ZIP, `npm install` đã hết thời gian chờ và không cài được dependencies; vì vậy test tĩnh và cú pháp đã chạy, nhưng 4 test tích hợp nhập `chess.js`/`express` không thể khởi tạo, và chưa thể xác nhận Gradle/APK hoặc thử nghiệm trên thiết bị thật. Không tuyên bố APK đã build thành công; GitHub Actions là cổng nghiệm thu cuối.

## Nguồn và giấy phép

- Stockfish.js: [repository và README](https://github.com/nmrugg/stockfish.js); engine GPLv3, giấy phép được copy kèm asset khi build.
- Lichess API và dữ liệu công khai: [API](https://github.com/lichess-org/api/blob/master/doc/specs/lichess-api.yaml), [Open Database](https://database.lichess.org/) (câu đố dữ liệu công khai CC0). Bản này dùng API daily/cache, không nhúng toàn bộ kho hàng triệu câu đố.
- Các bộ quân SVG và giấy phép nguồn được liệt kê trong [`public/piece-sets/CREDITS.md`](public/piece-sets/CREDITS.md).
- Ý tưởng giao diện Rubik tương tác có tham khảo [Cubing.js](https://js.cubing.net/cubing/); logic xoay trong dự án này được hiện thực nội bộ, không tải thư viện từ CDN.
