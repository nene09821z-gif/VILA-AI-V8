# Build APK Cờ Vua VILA v3.38.0 bằng GitHub Actions

ZIP `CO_VUA_VILA_V3_38_0_ANDROID.zip` chứa mã nguồn web/Capacitor và workflow Android; **không phải APK**.

## Các bước

1. Giải nén ZIP, tạo repository GitHub rồi đẩy toàn bộ nội dung bên trong lên repository. Không bỏ thư mục `.github/workflows/`.
2. Mở tab **Actions**, chọn **Cờ Vua ViLa Android build**, bấm **Run workflow**; workflow này cũng tự chạy trên push/PR.
3. Runner dùng Node.js 22 và Java 21, cài dependencies, kiểm tra cú pháp, chạy toàn bộ `npm test`, tạo kho khai cuộc, tải bộ quân, kiểm tra Stockfish 19 Lite/Full NNUE/ASM-JS và Stockfish 10 cổ điển cùng giấy phép GPL, build web, sync Capacitor và build `assembleDebug`.
4. Nếu tất cả bước bắt buộc đạt, tải artifact **`covua-vila-debug-apk`** để lấy `app-debug.apk`. `test-report` chứa đầu ra test; `covua-vila-android-gradle-source` là gói nguồn Gradle được sinh khi build.

## Nếu workflow thất bại

- Mở step lỗi đầu tiên và tải artifact `test-report`; không tắt test để ép đóng gói APK.
- Nếu thiếu Stockfish 19 hoặc Stockfish 10/giấy phép GPL, xem log của `scripts/copy-engine.mjs` và tên file trong `public/engine/engine-manifest.json`.
- Nếu lỗi bộ quân/kho khai cuộc, kiểm tra runner có thể lấy dữ liệu từ các URL nguồn được ghi trong mã và `public/piece-sets/CREDITS.md`.
- Nếu lỗi Gradle, xem log các bước `cap sync android`, `verify-android-project.mjs` và `assembleDebug`.

## Build cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

Cần Node 22, Java/Android SDK phù hợp và kết nối mạng để tải package/data khi chưa có cache. Full Stockfish NNUE làm APK lớn hơn Lite đáng kể; auto fallback vẫn được giữ cho WebView không khởi tạo được Full.

## Giới hạn xác minh của bản ZIP

Báo cáo chi tiết ở `TEST_REPORT_V3_38_0.md`. Trong môi trường chỉnh sửa hiện tại, npm install đã quá thời gian chờ và 4 test tích hợp cần `chess.js`/`express` chưa thể khởi tạo; test tĩnh và kiểm tra cú pháp đã chạy. Chưa có bằng chứng build APK hoặc chạy trực tiếp trên điện thoại thành công cho đến khi GitHub Actions và thiết bị xác minh xong.
