import test from 'node:test';
import assert from 'node:assert/strict';
import { buildOpeningBookPrefixes, classifyCentipawnLoss, classifyReviewedMove, estimateMoveLoss, scoreSideToWhiteCentipawns, reviewSymbolForJudgement, reviewSymbolDescription } from '../src/game-review.js';

test('move-loss classifier separates best, excellent, good, inaccuracies, mistakes and blunders', () => {
  assert.equal(classifyCentipawnLoss(0).key, 'best');
  assert.equal(classifyCentipawnLoss(10).key, 'excellent');
  assert.equal(classifyCentipawnLoss(20).key, 'good');
  assert.equal(classifyCentipawnLoss(30).key, 'inaccuracy');
  assert.equal(classifyCentipawnLoss(100).key, 'mistake');
  assert.equal(classifyCentipawnLoss(180).key, 'blunder');
});

test('review scores use White POV and estimate loss from the mover perspective', () => {
  assert.equal(scoreSideToWhiteCentipawns(40, 'w', 'cp'), 40);
  assert.equal(scoreSideToWhiteCentipawns(40, 'b', 'cp'), -40);
  assert.equal(scoreSideToWhiteCentipawns(0, 'w', 'mate'), -10000);
  assert.equal(scoreSideToWhiteCentipawns(0, 'b', 'mate'), 10000);
  assert.equal(estimateMoveLoss(70, 20, 'w'), 50);
  assert.equal(estimateMoveLoss(20, 70, 'b'), 50);
  assert.equal(estimateMoveLoss(null, 70, 'b'), null);
});


test('review avoids unsupported brilliant labels and checks opening moves against engine loss', () => {
  assert.deepEqual(classifyReviewedMove(20, true), { label: 'Tốt', key: 'good' });
  assert.deepEqual(classifyReviewedMove(10, false, true), { label: 'Khai cuộc', key: 'book' });
  assert.equal(classifyReviewedMove(150, false, true).key, 'blunder');
  assert.equal(classifyReviewedMove(90, true).key, 'mistake');
  assert.equal(classifyReviewedMove(10, false).key, 'excellent');
  assert.deepEqual(classifyReviewedMove(null), { label: 'Chưa đánh giá', key: 'unrated' });
});


test('opening-book prefixes only mark exact move sequences already in the catalogue', () => {
  const prefixes = buildOpeningBookPrefixes([{ san: ['e4', 'e5', 'Nf3'] }, { san: ['d4', 'd5'] }]);
  assert.equal(prefixes.has('e4'), true);
  assert.equal(prefixes.has('e4 e5'), true);
  assert.equal(prefixes.has('e4 e5 Bc4'), false);
  assert.equal(prefixes.has('e4 d5'), false);
});


test('review list exposes compact move symbols for each review category', () => {
  assert.equal(reviewSymbolForJudgement({ key: 'book' }), 'BK');
  assert.equal(reviewSymbolForJudgement({ key: 'brilliant' }), '!!');
  assert.equal(reviewSymbolForJudgement({ key: 'best' }), '★');
  assert.equal(reviewSymbolForJudgement({ key: 'excellent' }), '!');
  assert.equal(reviewSymbolForJudgement({ key: 'good' }), '✓');
  assert.equal(reviewSymbolForJudgement({ key: 'inaccuracy' }), '?!');
  assert.equal(reviewSymbolForJudgement({ key: 'mistake' }), '?');
  assert.equal(reviewSymbolForJudgement({ key: 'blunder' }), '??');
  assert.match(reviewSymbolDescription({ key: 'blunder' }), /nghiêm trọng/);
});


test('review recognises a large missed-win swing from the mover perspective', () => {
  assert.deepEqual(classifyReviewedMove(420, false, false, { moverBeforeCp: 620, moverAfterCp: 40 }), {
    label: 'Bỏ lỡ cơ hội thắng', key: 'missed-win'
  });
  assert.equal(classifyReviewedMove(420, false, false, { moverBeforeCp: 120, moverAfterCp: -300 }).key, 'blunder');
  assert.equal(reviewSymbolForJudgement({ key: 'missed-win' }), '⊘');
});
