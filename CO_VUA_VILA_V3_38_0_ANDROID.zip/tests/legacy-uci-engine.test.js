import test from 'node:test';
import assert from 'node:assert/strict';
import { LegacyUciEngine } from '../src/legacy-uci-engine.js';

class FakeUciWorker {
  constructor() { this.onmessage = null; this.onerror = null; this.terminated = false; this.lines = []; }
  postMessage(line) {
    this.lines.push(line);
    queueMicrotask(() => {
      if (line === 'uci') this.onmessage?.({ data: 'uciok' });
      else if (line === 'isready') this.onmessage?.({ data: 'readyok' });
      else if (line.startsWith('go movetime ')) {
        this.onmessage?.({ data: 'info depth 12 score cp 34 nodes 12000 pv e2e4 e7e5' });
        this.onmessage?.({ data: 'bestmove e2e4 ponder e7e5' });
      } else if (line === 'stop') this.onmessage?.({ data: 'bestmove e2e4' });
    });
  }
  terminate() { this.terminated = true; }
}

test('legacy UCI worker handshakes, sets safe mobile options and returns a parsed best move', async () => {
  const worker = new FakeUciWorker();
  const engine = new LegacyUciEngine(() => worker, { initTimeoutMs: 500, defaultSearchTimeoutMs: 1500 });
  const result = await engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { skill: 17, moveTimeMs: 150 });
  assert.deepEqual(result, { uci: 'e2e4', depth: 12, score: 34, pv: 'e2e4' });
  assert.ok(worker.lines.includes('setoption name Threads value 1'));
  assert.ok(worker.lines.includes('setoption name Hash value 8'));
  assert.ok(worker.lines.includes('setoption name Skill Level value 17'));
  assert.ok(worker.lines.includes('position fen rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'));
  engine.dispose();
  assert.equal(worker.terminated, true);
});

test('legacy UCI worker rejects malformed positions and isolates timed-out searches', async () => {
  let worker;
  const engine = new LegacyUciEngine(() => (worker = new FakeUciWorker()), { initTimeoutMs: 500, defaultSearchTimeoutMs: 200 });
  await assert.rejects(() => engine.bestMove('not a FEN'), /FEN/);
  await engine.ensureReady();
  // Force the fake worker to remain silent for a search to verify timeout teardown.
  worker.postMessage = line => { worker.lines.push(line); if (line === 'uci') queueMicrotask(() => worker.onmessage?.({ data: 'uciok' })); if (line === 'isready') queueMicrotask(() => worker.onmessage?.({ data: 'readyok' })); };
  await assert.rejects(() => engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 150, timeoutMs: 180 }), /vượt thời gian/);
  assert.equal(worker.terminated, true);
  engine.dispose();
});
