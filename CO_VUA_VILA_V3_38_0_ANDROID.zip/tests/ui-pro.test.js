import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evalBarShare, evalBarText, evalBarAriaLabel, isMateScore,
  clockUrgency, currentPlyIndex, buildMoveRows, MIN_TOUCH_TARGET_PX,
} from '../src/ui-pro.js';
import { scoreSideToWhiteCentipawns } from '../src/game-review.js';

test('evaluation bar is centred at equality, monotonic, bounded and symmetric', () => {
  assert.equal(evalBarShare(0), 50);
  let previous = -1;
  for (const cp of [-5000, -1500, -800, -300, -100, -20, 0, 20, 100, 300, 800, 1500, 5000]) {
    const share = evalBarShare(cp);
    assert.ok(share >= previous, `non-decreasing at ${cp}`);
    assert.ok(share >= 3 && share <= 97, `bounded at ${cp}`);
    previous = share;
  }
  for (const cp of [50, 200, 700, 1200]) {
    assert.ok(Math.abs(evalBarShare(cp) + evalBarShare(-cp) - 100) < 0.11, `symmetric at ${cp}`);
  }
});

test('evaluation bar never leaves a side with an empty bar and handles bad input', () => {
  assert.equal(evalBarShare(99999), 97);
  assert.equal(evalBarShare(-99999), 3);
  for (const bad of [NaN, undefined, null, 'abc', Infinity]) {
    assert.equal(evalBarShare(bad), 50, `fallback for ${String(bad)}`);
  }
});

test('mate scores from scoreSideToWhiteCentipawns are recognised and worded correctly', () => {
  const whiteMates = scoreSideToWhiteCentipawns(3, 'w', 'mate');
  const blackMates = scoreSideToWhiteCentipawns(3, 'b', 'mate');
  assert.ok(isMateScore(whiteMates) && whiteMates > 0);
  assert.ok(isMateScore(blackMates) && blackMates < 0);
  assert.equal(evalBarText(whiteMates), 'Trắng chiếu hết');
  assert.equal(evalBarText(blackMates), 'Đen chiếu hết');
  assert.equal(isMateScore(450), false);
  assert.equal(isMateScore(NaN), false);
});

test('evaluation text and aria label are consistent and Vietnamese', () => {
  assert.equal(evalBarText(0), '0.0');
  assert.equal(evalBarText(5), '0.0');
  assert.equal(evalBarText(140), '+1.4');
  assert.equal(evalBarText(-35), '-0.4');
  assert.equal(evalBarText(NaN), '—');
  assert.match(evalBarAriaLabel(0), /cân bằng/);
  assert.match(evalBarAriaLabel(150), /Trắng hơn/);
  assert.match(evalBarAriaLabel(-150), /Đen hơn/);
  assert.match(evalBarAriaLabel(60), /nhỉnh hơn/);
  assert.match(evalBarAriaLabel(900), /gần như thắng/);
  assert.match(evalBarAriaLabel(NaN), /chưa có dữ liệu/);
});

test('clock urgency uses fixed thresholds without a base time and scales for bullet', () => {
  assert.equal(clockUrgency(60000), '');
  assert.equal(clockUrgency(25000), 'low');
  assert.equal(clockUrgency(9000), 'critical');
  assert.equal(clockUrgency(0), '');
  assert.equal(clockUrgency(5000, { enabled: false }), '');
  assert.equal(clockUrgency(NaN), '');
  // 1-minute game: 20% = 12 s is "low", 10% = 6 s is "critical"
  assert.equal(clockUrgency(40000, { baseMs: 60000 }), '');
  assert.equal(clockUrgency(11000, { baseMs: 60000 }), 'low');
  assert.equal(clockUrgency(5000, { baseMs: 60000 }), 'critical');
  // long game never goes "low" later than the fixed 30 s ceiling
  assert.equal(clockUrgency(29000, { baseMs: 3600000 }), 'low');
  assert.equal(clockUrgency(31000, { baseMs: 3600000 }), '');
});

test('current ply index and move rows highlight exactly one half-move', () => {
  assert.equal(currentPlyIndex(0), -1);
  assert.equal(currentPlyIndex(5), 4);
  assert.equal(currentPlyIndex(5, 2), 2);
  assert.equal(currentPlyIndex(5, 99), 4);
  assert.equal(currentPlyIndex(5, -7), -1);
  const rows = buildMoveRows(['e4', 'e5', 'Nf3']);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0].white, { san: 'e4', ply: 0, active: false });
  assert.equal(rows[1].black, null);
  assert.equal(rows[1].white.active, true);
  const active = buildMoveRows(['e4', 'e5', 'Nf3', 'Nc6']).flatMap(r => [r.white, r.black]).filter(m => m?.active);
  assert.equal(active.length, 1);
  assert.equal(active[0].san, 'Nc6');
  assert.deepEqual(buildMoveRows([]), []);
  assert.deepEqual(buildMoveRows(null), []);
  assert.equal(buildMoveRows(['e4', 'e5'], 0).flatMap(r => [r.white, r.black]).find(m => m.active).san, 'e4');
});

test('touch target constant matches the 44px platform guideline', () => {
  assert.equal(MIN_TOUCH_TARGET_PX, 44);
});
