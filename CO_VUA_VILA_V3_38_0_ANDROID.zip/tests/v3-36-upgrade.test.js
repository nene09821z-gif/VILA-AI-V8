import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const pkg = JSON.parse(read('package.json'));
const main = read('src/main.js');
const css = read('src/style.css');
const workflow = read('.github/workflows/build-android.yml');
const engineScript = read('scripts/copy-engine.mjs');

test('v3.36 improves the real Stockfish engine path without random move substitution', () => {
  assert.equal(pkg.version, '3.38.0');
  assert.match(main, /resolveStockfishStrength\(settings\.botElo\)/);
  assert.match(main, /setoption name UCI_LimitStrength value/);
  assert.match(main, /setoption name Skill Level value \$\{strength\.skillLevel\}/);
  assert.doesNotMatch(main, /chooseBeginnerMoveFor|randomLegalMoveProbability|heuristicMoveProbability/);
  assert.match(read('src/elo-strength.js'), /targetElo - 500/);
  assert.match(read('src/engine-profile.js'), /memoryGiB >= 2 && cores >= 4/);
});

test('full-game review stores the engine principal variation before the played move', () => {
  assert.match(main, /bestMoveUci = session\.lastBestUci/);
  assert.match(main, /bestMoveSan = bestMoveUci \?/);
  assert.match(main, /bestLineUci/);
  assert.match(main, /BIẾN ENGINE/);
  assert.match(main, /moveWasBest: Boolean\(bestMoveUci && position\.uci && bestMoveUci === position\.uci\)/);
  assert.match(main, /updateReviewMoveDetail\(\)/);
  assert.match(main, /Nước thay thế:/);
  assert.match(main, /engineDepth: session\.currentDepth/);
  assert.match(main, /position\.terminalScoreWhiteCp/);
  assert.match(main, /reviewSession = null;[\s\S]{0,180}retireStockfishWorker\(reviewStatus\)/);
  assert.match(css, /\.review-move-detail-grid/);
});

test('mate-zero and opening annotations avoid false brilliant labels', () => {
  assert.match(read('src/analysis-utils.js'), /raw === 0/);
  assert.match(read('src/game-review.js'), /Do not call a move brilliant merely/);
  assert.match(read('src/game-review.js'), /if \(bookMove && loss <= 15\)/);
  assert.match(main, /Không gắn nhãn “Thiên tài” nếu chưa có cơ sở chiến thuật rõ ràng/);
});

test('Android build requires Full NNUE, Lite and ASM fallbacks, while the manifest reflects Full', () => {
  assert.match(workflow, /INCLUDE_STOCKFISH_FULL: '1'/);
  assert.match(workflow, /Require Stockfish 19 Full NNUE, Lite, ASM-JS and Stockfish 10 opponent assets/);
  assert.match(workflow, /REQUIRE_STOCKFISH_10: '1'/);
  assert.match(workflow, /STOCKFISH-10-LICENSE\.txt/);
  assert.match(engineScript, /stockfish-19-single\.wasm/);
  assert.match(engineScript, /full: includeFull/);
});


test('analysis, coach, review and hint explicitly clear the bot Elo limit before searching', () => {
  assert.match(main, /function configureStockfishForAnalysis\(multiPv = 1\)/);
  assert.match(main, /setoption name UCI_LimitStrength value false/);
  assert.match(main, /setoption name Skill Level value 20/);
  for (const name of ['toggleAnalysis', 'analyzeLocallyForCoach', 'beginReviewPosition', 'requestHint']) {
    const start = main.indexOf(`function ${name}(`);
    assert.ok(start >= 0, `Missing ${name}`);
    const end = main.indexOf('\nfunction ', start + 10);
    const body = main.slice(start, end < 0 ? main.length : end);
    assert.match(body, /configureStockfishForAnalysis\(/, `${name} must use full-strength analysis`);
  }
});


test('review replay no longer references the removed sacrifice-heuristic temporary', () => {
  const start = main.indexOf('function getReviewReplayState()');
  const end = main.indexOf('\nfunction renderReplayBoardMarkup', start);
  const replay = main.slice(start, end);
  assert.doesNotMatch(replay, /sacrificeCandidate/);
  assert.match(replay, /positions\.push\(\{ fen: replay\.fen\(\), ply: index \+ 1/);
});


test('review view uses a paired White/Black scorecard and updates separate quality totals', () => {
  assert.match(main, /renderReviewMoveListMarkup\(reviewRows\)/);
  assert.match(main, /review-move-header/);
  assert.match(main, /review-move-pair/);
  assert.match(main, /data-review-ply=\"\$\{Number\(row\.ply\)\}/);
  assert.match(main, /reviewSideStats/);
  assert.match(main, /summarizeReviewSide\(rows, side\)/);
  assert.match(css, /\.review-ply-move\.review-move-active/);
  assert.match(read('src/review-list.js'), /groupReviewedMoves/);
});
