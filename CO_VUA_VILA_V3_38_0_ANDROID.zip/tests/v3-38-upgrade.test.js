import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const exists = name => fs.existsSync(path.join(root, name));
const pkg = JSON.parse(read('package.json'));

test('v3.38 is versioned consistently across app, server and service worker', () => {
  assert.equal(pkg.version, '3.38.0');
  assert.match(read('index.html'), /Chess Arena v3\.38\.0/);
  assert.match(read('server/index.js'), /version: '3\.38\.0'/);
  assert.match(read('public/sw.js'), /covua-vila-v3\.38\.0/);
});

test('UI layer is additive: new files exist and style.css is still loaded before it', () => {
  assert.ok(exists('src/ui-pro.js'));
  assert.ok(exists('src/pro-ui.css'));
  const main = read('src/main.js');
  const styleAt = main.indexOf("import './style.css';");
  const proAt = main.indexOf("import './pro-ui.css';");
  assert.ok(styleAt > -1 && proAt > styleAt, 'pro-ui.css must load after style.css so it can refine it');
  assert.match(main, /from '\.\/ui-pro\.js'/);
});

test('modules that earlier versions depend on were not removed', () => {
  const required = [
    'src/main.js', 'src/style.css', 'src/engine-profile.js', 'src/legacy-uci-engine.js', 'src/premove.js',
    'src/game-review.js', 'src/review-list.js', 'src/clock.js', 'src/move-clock-history.js', 'src/pieces.js',
    'src/sound.js', 'src/opening-book.js', 'src/opening-catalog.js', 'src/puzzle-worker.js', 'src/mini-games.js',
    'src/alternate-engine.js', 'src/engines/search-core.js', 'src/daily-progress.js', 'src/notifications.js',
    'server/index.js', 'server/ranked-chess.js', 'server/social.js', 'scripts/copy-engine.mjs',
  ];
  for (const file of required) assert.ok(exists(file), `${file} must still exist`);
});

test('evaluation bar, clocks and move list are wired to the pure helpers', () => {
  const main = read('src/main.js');
  assert.match(main, /evalBarShare\(whiteCp\)/);
  assert.match(main, /evalBarAriaLabel\(whiteCp\)/);
  assert.match(main, /id="evaluationMeterText"/);
  assert.match(main, /clockUrgency\(clockState\.remaining\[color\]/);
  assert.match(main, /clockBaseMs = enabled/);
  assert.match(main, /buildMoveRows\(history\)/);
  assert.match(main, /aria-current="true"/);
  assert.doesNotMatch(main, /Math\.tanh\(whiteCp \/ 500\)/, 'old linear-ish meter mapping was replaced');
});

test('pro-ui.css covers touch targets, focus, urgency, reduced motion, contrast and safe areas', () => {
  const css = read('src/pro-ui.css');
  assert.match(css, /@media \(pointer: coarse\)/);
  assert.match(css, /--pro-touch-min: 44px/);
  assert.match(css, /:focus-visible/);
  assert.match(css, /\.is-critical/);
  assert.match(css, /is-critical strong[^}]*color:[^;]*!important/, "urgency must beat style.css !important clock rules");
  assert.match(css, /\.is-low/);
  assert.match(css, /\.move-san\.is-current/);
  assert.match(css, /prefers-reduced-motion: reduce/);
  assert.match(css, /prefers-contrast: more/);
  assert.match(css, /forced-colors: active/);
  assert.match(css, /safe-area-inset-bottom/);
  assert.doesNotMatch(css, /!important[^;}]*;[^}]*display\s*:\s*none/, 'must not hide existing controls');
});

test('pro-ui.css only refines: it never hides or removes existing UI', () => {
  const css = read('src/pro-ui.css');
  assert.doesNotMatch(css, /display\s*:\s*none/);
  assert.doesNotMatch(css, /visibility\s*:\s*hidden/);
  assert.doesNotMatch(css, /pointer-events\s*:\s*none[^;]*;[^}]*\.square\b/);
});

test('new tests are part of the static suite', () => {
  assert.match(pkg.scripts['test:static'], /tests\/ui-pro\.test\.js/);
  assert.match(pkg.scripts['test:static'], /tests\/v3-38-upgrade\.test\.js/);
});
