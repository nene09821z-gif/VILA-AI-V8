/*
 * Pure helpers for the v3.38 "professional chess UI" layer.
 * No DOM access here so every function can be unit-tested in plain Node.
 * Visual cues only: none of this changes game rules, engine strength or ratings.
 */

const MAX_CP_FOR_BAR = 1500;

/**
 * Share (percent) of the evaluation bar filled for White.
 * Uses a logistic curve (flatter near equality, saturating for decisive scores)
 * and keeps a thin sliver for the losing side so the bar never looks empty.
 * `whiteCp` is centipawns from White's point of view; mate scores are passed as
 * large values by scoreSideToWhiteCentipawns (>= 9000).
 */
export function evalBarShare(whiteCp) {
  const cp = Number(whiteCp);
  if (!Number.isFinite(cp)) return 50;
  const clamped = Math.max(-MAX_CP_FOR_BAR, Math.min(MAX_CP_FOR_BAR, cp));
  const winChance = 2 / (1 + Math.exp(-0.00368208 * clamped)) - 1; // -1..1
  const share = 50 + 50 * winChance;
  return Math.round(Math.max(3, Math.min(97, share)) * 10) / 10;
}

/** True when the score is a forced mate (as encoded by scoreSideToWhiteCentipawns). */
export function isMateScore(whiteCp) {
  return Number.isFinite(whiteCp) && Math.abs(whiteCp) >= 9000;
}

/** Short human text such as "+1.4", "-0.3", "Hòa", "Chiếu hết Trắng". */
export function evalBarText(whiteCp) {
  const cp = Number(whiteCp);
  if (!Number.isFinite(cp)) return '—';
  if (isMateScore(cp)) return cp > 0 ? 'Trắng chiếu hết' : 'Đen chiếu hết';
  if (Math.abs(cp) < 8) return '0.0';
  // Integer rounding (half up) avoids toFixed() float artefacts such as 0.35 -> "0.3".
  const tenths = Math.round(Math.abs(cp) / 10);
  return `${cp > 0 ? '+' : '-'}${Math.floor(tenths / 10)}.${tenths % 10}`;
}

/** Spoken/ARIA description of the bar (Vietnamese, matching the app). */
export function evalBarAriaLabel(whiteCp) {
  const cp = Number(whiteCp);
  if (!Number.isFinite(cp)) return 'Thanh đánh giá: chưa có dữ liệu';
  if (isMateScore(cp)) return cp > 0 ? 'Thanh đánh giá: Trắng sắp chiếu hết' : 'Thanh đánh giá: Đen sắp chiếu hết';
  const abs = Math.abs(cp);
  if (abs < 25) return 'Thanh đánh giá: cân bằng';
  const side = cp > 0 ? 'Trắng' : 'Đen';
  const degree = abs < 80 ? 'nhỉnh hơn' : abs < 200 ? 'hơn' : abs < 500 ? 'hơn rõ' : 'gần như thắng';
  return `Thanh đánh giá: ${side} ${degree} (${evalBarText(cp)})`;
}

/**
 * Clock urgency for styling. Thresholds scale a little with the base time so a
 * 1-minute bullet game is not "low" for its whole length.
 */
export function clockUrgency(remainingMs, { enabled = true, baseMs = 0 } = {}) {
  if (!enabled) return '';
  const ms = Number(remainingMs);
  if (!Number.isFinite(ms) || ms <= 0) return '';
  const criticalAt = Math.min(10000, baseMs > 0 ? Math.max(3000, baseMs * 0.1) : 10000);
  const lowAt = Math.min(30000, baseMs > 0 ? Math.max(8000, baseMs * 0.2) : 30000);
  if (ms <= criticalAt) return 'critical';
  if (ms <= lowAt) return 'low';
  return '';
}

/**
 * Index (0-based ply) of the move that should be highlighted in the move list.
 * `viewPly` null/undefined means "latest move".
 */
export function currentPlyIndex(historyLength, viewPly = null) {
  const length = Math.max(0, Number(historyLength) || 0);
  if (!length) return -1;
  if (viewPly === null || viewPly === undefined) return length - 1;
  const ply = Math.floor(Number(viewPly));
  if (!Number.isFinite(ply)) return length - 1;
  return Math.max(-1, Math.min(length - 1, ply));
}

/** Group a flat SAN history into numbered rows with active-ply flags. */
export function buildMoveRows(history, viewPly = null) {
  const list = Array.isArray(history) ? history : [];
  const active = currentPlyIndex(list.length, viewPly);
  const rows = [];
  for (let i = 0; i < list.length; i += 2) {
    rows.push({
      number: Math.floor(i / 2) + 1,
      white: { san: String(list[i]), ply: i, active: i === active },
      black: i + 1 < list.length ? { san: String(list[i + 1]), ply: i + 1, active: i + 1 === active } : null,
    });
  }
  return rows;
}

/** Minimum comfortable touch target (CSS px) used by the UI layer and its tests. */
export const MIN_TOUCH_TARGET_PX = 44;
