/** Pure helpers for the post-game review panel; move legality is checked by chess.js in the caller. */
export function classifyCentipawnLoss(lossCp) {
  const loss = Math.max(0, Number(lossCp) || 0);
  if (loss <= 5) return { label: 'Tốt nhất', key: 'best' };
  if (loss <= 15) return { label: 'Xuất sắc', key: 'excellent' };
  if (loss < 25) return { label: 'Tốt', key: 'good' };
  if (loss < 70) return { label: 'Chưa chính xác', key: 'inaccuracy' };
  if (loss < 150) return { label: 'Sai lầm', key: 'mistake' };
  return { label: 'Blunder', key: 'blunder' };
}

export function scoreSideToWhiteCentipawns(score, sideToMove, scoreType = 'cp') {
  const value = Number(score) || 0;
  if (scoreType === 'mate') {
    // UCI mate 0 means the root side to move is already checkmated (therefore losing).
    const signed = value === 0
      ? (sideToMove === 'w' ? -1 : 1)
      : value * (sideToMove === 'b' ? -1 : 1);
    return Math.sign(signed) * (10000 - Math.min(999, Math.abs(value)) * 10);
  }
  return sideToMove === 'b' ? -value : value;
}

export function estimateMoveLoss(previousWhiteCp, currentWhiteCp, mover) {
  if (previousWhiteCp == null || currentWhiteCp == null || previousWhiteCp === '' || currentWhiteCp === '' ||
      !Number.isFinite(Number(previousWhiteCp)) || !Number.isFinite(Number(currentWhiteCp))) return null;
  const delta = mover === 'w' ? Number(previousWhiteCp) - Number(currentWhiteCp) : Number(currentWhiteCp) - Number(previousWhiteCp);
  return Math.max(0, Math.round(delta));
}

/** A conservative review label. Do not call a move brilliant merely because a piece can be captured.
 * An opening tag is shown only when the move also retained a strong evaluation. */
export function classifyReviewedMove(lossCp, _sacrificeCandidate = false, bookMove = false, context = {}) {
  if (lossCp == null || !Number.isFinite(Number(lossCp))) return { label: 'Chưa đánh giá', key: 'unrated' };
  const loss = Math.max(0, Number(lossCp));
  const before = Number(context.moverBeforeCp);
  const after = Number(context.moverAfterCp);
  // A big swing from a clearly winning position to an equal/losing one is more useful
  // to describe as a missed win than a generic blunder. Thresholds are transparent heuristics.
  if (Number.isFinite(before) && Number.isFinite(after) && before >= 350 && after <= 100 && loss >= 100) {
    return { label: 'Bỏ lỡ cơ hội thắng', key: 'missed-win' };
  }
  if (bookMove && loss <= 15) return { label: 'Khai cuộc', key: 'book' };
  return classifyCentipawnLoss(loss);
}

/** Chess-annotation style symbols for the review list. These are local heuristic labels, not official Chess.com marks. */
export function reviewSymbolForJudgement(judgement) {
  const key = typeof judgement === 'string' ? judgement : judgement?.key;
  return ({
    book: 'BK',
    'missed-win': '⊘',
    brilliant: '!!',
    best: '★',
    excellent: '!',
    good: '✓',
    inaccuracy: '?!',
    mistake: '?',
    blunder: '??'
  })[key] || '';
}

export function reviewSymbolDescription(judgement) {
  const key = typeof judgement === 'string' ? judgement : judgement?.key;
  return ({
    book: 'Nước trong sách khai cuộc',
    'missed-win': 'Bỏ lỡ cơ hội thắng từ một thế đang thắng rõ',
    brilliant: 'Nước thiên tài ước lượng',
    best: 'Nước tốt nhất',
    excellent: 'Nước xuất sắc',
    good: 'Nước tốt',
    inaccuracy: 'Nước chưa chính xác',
    mistake: 'Sai lầm',
    blunder: 'Blunder — sai lầm nghiêm trọng'
  })[key] || 'Chưa có đánh giá';
}


/** Build SAN-prefix keys from the current opening catalogue for quick book tagging. */
export function buildOpeningBookPrefixes(openings = []) {
  const prefixes = new Set();
  for (const opening of openings) {
    if (!Array.isArray(opening?.san)) continue;
    const path = [];
    for (const san of opening.san) {
      if (typeof san !== 'string' || !san.trim()) break;
      path.push(san.trim());
      prefixes.add(path.join(' '));
    }
  }
  return prefixes;
}
