/**
 * Small, isolated UCI session for Stockfish 10 (ASM.js).
 * It never shares the main Stockfish 19 worker, so a legacy-engine arena match
 * cannot steal results from the player's game or analysis session.
 */
export class LegacyUciEngine {
  constructor(workerFactory, { initTimeoutMs = 20_000, defaultSearchTimeoutMs = 8_000 } = {}) {
    if (typeof workerFactory !== 'function') throw new TypeError('workerFactory must be a function');
    this.workerFactory = workerFactory;
    this.initTimeoutMs = initTimeoutMs;
    this.defaultSearchTimeoutMs = defaultSearchTimeoutMs;
    this.worker = null;
    this.state = 'idle';
    this.initPromise = null;
    this.resolveInit = null;
    this.rejectInit = null;
    this.initTimer = null;
    this.search = null;
    this.disposed = false;
  }

  async ensureReady() {
    if (this.disposed) throw new Error('Stockfish 10 session was disposed.');
    if (this.state === 'ready') return;
    if (this.initPromise) return this.initPromise;
    this.state = 'starting';
    this.initPromise = new Promise((resolve, reject) => {
      this.resolveInit = resolve;
      this.rejectInit = reject;
      try {
        this.worker = this.workerFactory();
        this.worker.onmessage = event => this.#onMessage(String(event?.data ?? ''));
        this.worker.onerror = error => this.#fail(new Error(error?.message || 'Stockfish 10 worker failed.'));
        this.initTimer = setTimeout(() => this.#fail(new Error('Stockfish 10 khởi tạo quá thời gian.')), this.initTimeoutMs);
        this.worker.postMessage('uci');
      } catch (error) { this.#fail(error instanceof Error ? error : new Error(String(error))); }
    });
    return this.initPromise;
  }

  #post(line) {
    if (!this.worker) throw new Error('Stockfish 10 worker chưa khởi tạo.');
    this.worker.postMessage(line);
  }

  #onMessage(line) {
    if (this.state === 'starting' && line.includes('uciok')) {
      try {
        this.#post('setoption name Threads value 1');
        this.#post('setoption name Hash value 8');
        this.#post('setoption name MultiPV value 1');
        this.#post('isready');
      } catch (error) { this.#fail(error instanceof Error ? error : new Error(String(error))); }
      return;
    }
    if (this.state === 'starting' && line.includes('readyok')) {
      clearTimeout(this.initTimer);
      this.initTimer = null;
      this.state = 'ready';
      const resolve = this.resolveInit;
      this.resolveInit = null;
      this.rejectInit = null;
      resolve?.();
      return;
    }
    if (!this.search) return;
    const info = line.match(/^info\b.*?\bdepth\s+(\d+)\b.*?\bscore\s+(cp|mate)\s+(-?\d+).*?\bpv\s+([a-h][1-8][a-h][1-8][qrbn]?)/i);
    if (info) {
      const depth = Number(info[1]);
      if (depth >= this.search.depth) {
        this.search.depth = depth;
        this.search.score = info[2] === 'mate' ? Math.sign(Number(info[3]) || 1) * (30_000 - Math.min(999, Math.abs(Number(info[3])))) : Number(info[3]);
        this.search.pv = info[4].toLowerCase();
      }
    }
    const best = line.match(/^bestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000)/i);
    if (!best) return;
    const pending = this.search;
    this.search = null;
    clearTimeout(pending.timer);
    if (pending.cancelled) pending.resolve(null);
    else if (best[1].toLowerCase() === '0000') pending.reject(new Error('Stockfish 10 không trả về nước đi.'));
    else pending.resolve({ uci: best[1].toLowerCase(), depth: pending.depth, score: pending.score, pv: pending.pv });
  }

  #fail(error) {
    clearTimeout(this.initTimer);
    this.initTimer = null;
    this.state = 'failed';
    const reject = this.rejectInit;
    this.resolveInit = null;
    this.rejectInit = null;
    reject?.(error);
    if (this.search) {
      const pending = this.search;
      this.search = null;
      clearTimeout(pending.timer);
      pending.reject(error);
    }
    try { this.worker?.terminate?.(); } catch {}
    this.worker = null;
    this.initPromise = null;
  }

  async bestMove(fen, { skill = 20, moveTimeMs = 900, timeoutMs = this.defaultSearchTimeoutMs } = {}) {
    await this.ensureReady();
    if (this.search) throw new Error('Stockfish 10 đang tính một nước khác.');
    if (typeof fen !== 'string' || fen.trim().split(/\s+/).length < 4) throw new Error('FEN không hợp lệ cho Stockfish 10.');
    const safeSkill = Math.max(0, Math.min(20, Math.round(Number(skill) || 0)));
    const safeTime = Math.max(150, Math.min(5_000, Math.round(Number(moveTimeMs) || 900)));
    const safeTimeout = Math.max(safeTime + 1_500, Math.min(20_000, Math.round(Number(timeoutMs) || this.defaultSearchTimeoutMs)));
    return new Promise((resolve, reject) => {
      const pending = { resolve, reject, depth: 0, score: null, pv: null, timer: null, cancelled: false };
      pending.timer = setTimeout(() => {
        if (this.search !== pending) return;
        this.search = null;
        try { this.#post('stop'); } catch {}
        reject(new Error('Stockfish 10 vượt thời gian suy nghĩ.'));
        // Retire a timed-out worker so an old bestmove cannot be mistaken for a later position.
        try { this.worker?.terminate?.(); } catch {}
        this.worker = null; this.state = 'idle'; this.initPromise = null;
      }, safeTimeout);
      this.search = pending;
      try {
        this.#post('setoption name Skill Level value ' + safeSkill);
        this.#post('setoption name MultiPV value 1');
        this.#post('ucinewgame');
        this.#post(`position fen ${fen.trim()}`);
        this.#post(`go movetime ${safeTime}`);
      } catch (error) {
        clearTimeout(pending.timer);
        this.search = null;
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }

  stop() {
    if (!this.search || !this.worker) return false;
    this.search.cancelled = true;
    try { this.#post('stop'); return true; } catch { return false; }
  }

  dispose() {
    this.disposed = true;
    clearTimeout(this.initTimer);
    if (this.search) {
      clearTimeout(this.search.timer);
      this.search.reject(new Error('Stockfish 10 session disposed.'));
      this.search = null;
    }
    try { this.worker?.terminate?.(); } catch {}
    this.worker = null;
    this.state = 'disposed';
    this.initPromise = null;
  }
}
