import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const required = process.env.REQUIRE_STOCKFISH === '1' || process.argv.includes('--required');
// Full Stockfish is about 94 MB. Keep routine web/APK builds small and reliable;
// add the optional Full build only when explicitly requested.
const includeFull = process.env.INCLUDE_STOCKFISH_FULL === '1';
const packageRoot = path.join(root, 'node_modules', 'stockfish');
const destination = path.join(root, 'public', 'engine');
const liteFiles = ['stockfish-19-lite-single.js', 'stockfish-19-lite-single.wasm'];
// Small JavaScript-only recovery engine for Android WebViews that cannot load WASM.
const asmFiles = ['stockfish-19-asm.js'];
const fullFiles = ['stockfish-19-single.js', 'stockfish-19-single.wasm'];
function findFile(dir, file, depth = 0) {
  if (!fs.existsSync(dir) || depth > 6) return null;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
  for (const entry of entries) if (entry.isFile() && entry.name === file) return path.join(dir, entry.name);
  for (const entry of entries) if (entry.isDirectory() && !entry.name.startsWith('.')) {
    const found = findFile(path.join(dir, entry.name), file, depth + 1);
    if (found) return found;
  }
  return null;
}
function fail(message) {
  if (required) { console.error(message); process.exit(1); }
  console.warn(message);
}
if (!fs.existsSync(packageRoot)) {
  fail('[VILA Chess] Stockfish package is not installed. Run npm install first.');
  process.exit(required ? 1 : 0);
}
const wanted = [...liteFiles, ...asmFiles, ...(includeFull ? fullFiles : [])];
const sources = new Map(wanted.map(file => [file, findFile(packageRoot, file)]));
const missing = wanted.filter(file => !sources.get(file));
// Validate sources BEFORE clearing public/engine, so a failed build cannot erase
// previously bundled engine files and leave an installed app in a broken state.
if (missing.length) {
  fail(`[VILA Chess] Missing Stockfish assets: ${missing.join(', ')}.`);
  process.exit(required ? 1 : 0);
}
fs.mkdirSync(destination, { recursive: true });
for (const entry of fs.readdirSync(destination)) fs.rmSync(path.join(destination, entry), { recursive: true, force: true });
for (const file of wanted) fs.copyFileSync(sources.get(file), path.join(destination, file));
for (const licenseName of ['Copying.txt', 'COPYING.txt', 'COPYING', 'LICENSE.txt', 'LICENSE']) {
  const licensePath = findFile(packageRoot, licenseName);
  if (licensePath) { fs.copyFileSync(licensePath, path.join(destination, 'STOCKFISH-LICENSE.txt')); break; }
}
const manifest = { lite: true, asmFallback: true, full: includeFull, version: '19.0.1', buildNote: includeFull ? 'Full falls back to Lite, then ASM-JS; Lite falls back to ASM-JS' : 'Lite is default; if Lite WASM fails, ASM-JS is used. Full is optional and falls back to Lite then ASM-JS.' };
fs.writeFileSync(path.join(destination, 'engine-manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`[VILA Chess] Stockfish Lite + ASM-JS recovery engine ready. ${includeFull ? 'Full engine also bundled.' : 'Skipping optional 94 MB Full engine.'}`);
