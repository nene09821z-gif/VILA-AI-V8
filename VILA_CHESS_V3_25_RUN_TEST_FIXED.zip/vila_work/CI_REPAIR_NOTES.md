# CI repair notes

This package adds a reproducible GitHub Actions Android workflow at `.github/workflows/build-android.yml` (and `build-from-zip.yml` for manual runs).
It installs dependencies before tests, checks JavaScript syntax, runs the project's full test suite,
builds the web assets, syncs the Capacitor Android project, builds a debug APK, verifies that the APK
exists, and uploads it as an artifact.

## Verification performed in the available workspace

- JavaScript/MJS syntax checks: passed.
- Targeted static tests previously selected: 33/33 passed.
- Full `npm test` in this workspace: 174 passed, 7 failed because dependencies are not installed here
  (`chess.js` and `express` could not be resolved). This environment therefore cannot certify the full
  suite or the APK build. CI will install declared dependencies before executing the suite.

The screenshot from the user's previous CI run reports 193 tests with 4 failures. Those four specific
assertion failures cannot be diagnosed from the screenshot because the failure names and stack traces
are not visible. The workflow intentionally does not suppress or skip failing tests; it will expose the
full failure output and stop before packaging if any test fails.

## V3 fixes

- Both workflows used `actions/setup-node` with `cache: npm`, but the repository has no `package-lock.json`;
  setup-node aborts in that case before any test runs. The cache option was removed.
- `build-from-zip.yml` shared the `android-${{ github.ref }}` concurrency group with `build-android.yml`, so one run
  could cancel the other. It now uses `android-zip-${{ github.ref }}`.
- `Dockerfile` ran `npm install` after copying only `package*.json`; the `postinstall` hook
  (`node scripts/copy-engine.mjs`) therefore failed with a missing-module error. It now uses
  `npm install --ignore-scripts`; `npm run build` still runs `copy-engine.mjs --required`.
- `@capacitor/core` is now declared explicitly (it was only an implicit peer dependency of `@capacitor/android`).
- `src/engines/search-core.js`: the transposition-table key included the halfmove clock, so identical positions
  reached by different routes never shared entries. The key is now board + side + castling + en passant.
- New `tests/ci-config.test.js` guards these regressions.

Local verification used a small chess.js/express stand-in (no network), so run `npm install && npm test` in CI to confirm
with the real packages.

Not changed (tests pin it): `package.json` is 3.22.3 while the changelog and features are 3.23, and `server/index.js`,
`index.html` and `README.md` still say 3.18.
