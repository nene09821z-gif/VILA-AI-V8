# Chess Bot AI Arena v2.6

Phiên bản mã nguồn: **1.6.1 (Chess Bot v2.6.1 Stability Fix)**. Bản v2.6.1 tập trung vào độ bền luồng API và Lichess: tránh mất bản nháp AI Coach, timeout yêu cầu, xác thực cấu hình chế độ AI, hủy stream upstream đúng cách và xử lý NDJSON cuối luồng. Các phần v2.6 như schema cài đặt, thư viện khai cuộc và guard phản hồi cũ vẫn được giữ. Bộ logo Chess Bot, icon native và workflow Android tiếp tục được đồng bộ. Đây là mã nguồn dự án; APK chưa được biên dịch trong môi trường tạo tệp này.

> **Lưu ý về Gradle:** ZIP v2.6 là gói nguồn web/Capacitor nên chưa chứa `android/settings.gradle` hay `android/gradlew`. Đừng đưa ZIP này thẳng vào công cụ chỉ nhận Android Gradle. Chạy workflow GitHub Actions trong hướng dẫn để tạo và tải artifact `chess-bot-android-gradle-source` (ZIP có các tệp Gradle thật) và `chess-bot-debug-apk`.

Chess Bot là ứng dụng cờ vua ưu tiên điện thoại: luật cờ tiêu chuẩn, Stockfish 19 thích ứng Lite/Full, đấu trường nhiều AI, thư viện khai cuộc và cầu nối Lichess. Đây là **mã nguồn dự án**; APK chưa được biên dịch trong môi trường tạo tệp này. Workflow GitHub Actions bên dưới có thể build APK tự động.

## Nhận diện Chess Bot

- Thanh đầu giao diện dùng icon Chess Bot nét cao; trang Cài đặt hiển thị wordmark đầy đủ. Tông giao diện được đồng bộ sang xanh navy, xanh điện và vàng kim để ăn khớp logo.
- Favicon và ảnh icon web đã được tối ưu dung lượng. Bộ launcher icon Android gồm các mức mdpi → xxxhdpi và adaptive icon Android 8+.
- Sau `npx cap sync android`, chạy `node scripts/apply-android-branding.mjs` để áp dụng icon và nhãn **Chess Bot**. `appId` vẫn giữ `com.tubor.chessai` để tránh đổi định danh gói đang có; biến môi trường `TUBOR_ACCESS_TOKEN` cũng được giữ tương thích.

## Có gì trong dự án?

- **Bàn cờ tiêu chuẩn**: chọn quân bằng chạm, gợi ý nước hợp lệ, bắt quân, nhập thành, bắt tốt qua đường, phong cấp, chiếu/chiếu hết, hòa, hoàn tác, đảo bàn, xuất PGN và xem FEN.
- **Stockfish 19 thích ứng**: chế độ `Tự động theo thiết bị` chọn Full single-thread nếu WebView báo ít nhất 6 GB RAM và 6 luồng CPU; nếu không có dữ liệu hoặc cấu hình thấp hơn thì chọn Lite để giảm áp lực bộ nhớ/nhiệt. Có thể ép chọn Lite hoặc Full thủ công. Cả hai engine được đóng gói để chơi offline, vì vậy bản APK chứa cả hai và có thể lớn hơn 100 MB sau đóng gói. Sau `npm install`, script copy engine vào `public/engine/`. Đổi cấu hình cần tải lại app. Skill 0–20 và độ sâu có thể điều chỉnh; mức Skill không phải cam kết Elo chính xác.
- **Chế độ chơi**: người với Stockfish, hai người trên cùng thiết bị, hoặc AI LLM qua API (AI LLM có thể trả nước sai; các nước được xác thực bằng danh sách nước hợp lệ trước khi áp dụng).
- **Đấu trường AI**: ghép Stockfish với AI hiện tại hoặc tối đa 20 hồ sơ endpoint riêng; giải vòng tròn tối đa 6 đối thủ, mỗi cặp chơi hai ván đổi màu; kết quả thắng/hòa/thua, bảng điểm và xuất PGN. Có thể chọn độ sâu đến 30 và giới hạn sức mạnh Stockfish bằng Elo UCI.
- **Nhiều nhà cung cấp**: OpenAI-compatible, OpenRouter, Google Gemini API và Anthropic Messages API; preset cho OpenAI, Groq, DeepSeek, Together, Mistral, Fireworks, Cerebras, xAI và Ollama. Cần endpoint/model/key đúng của từng dịch vụ; không thể tự động dùng mọi AI nếu không có quyền API.
- **Thư viện khai cuộc**: 25 đường mẫu với chuỗi nước SAN, có thể nạp thế cờ mẫu lên bàn; tra thống kê nước phổ biến qua Lichess Opening Explorer.
- **AI Coach**: hỏi bằng tiếng Việt về FEN/PGN, kế hoạch, chiến thuật và khai cuộc.
- **Lichess bridge**: kiểm tra token, tạo thử thách AI hoặc gửi lời mời thách đấu, mở luồng sự kiện ván cờ và gửi nước đi trong app khi token/scope/trạng thái ván cho phép.
- **AI endpoint**: kiểu Gemini API gốc hoặc các nhà cung cấp dùng API tương thích OpenAI `/chat/completions`. Có thể nhập endpoint/model/key; không có API chung duy nhất hoạt động với mọi dịch vụ.
- **Android**: Capacitor và workflow GitHub Actions để tạo APK debug.

## Chạy ở máy tính

Cần Node.js 22+ và npm.

```bash
npm install
npm test
npm run dev
```

Sau đó mở URL Vite hiển thị trong terminal (thường là `http://localhost:5173`). Backend API chạy riêng trên `127.0.0.1:8787` và được Vite proxy qua `/api`.

Bản production chạy cùng một máy chủ:

```bash
npm run build
npm start
```

Mở `http://127.0.0.1:8787`.

## Thiết lập AI

Vào **Cài đặt → Kết nối mô hình ngôn ngữ**:

1. Chọn `OpenAI-compatible`, `Google Gemini API` hoặc `Anthropic Messages API`.
2. Nhập endpoint cơ sở và tên model chính xác của nhà cung cấp.
3. Dán API key trên thiết bị rồi bấm **Lưu cấu hình**.
4. Bấm **Kiểm tra AI**.

Ví dụ định dạng endpoint:

- OpenAI-compatible: `https://api.openai.com/v1`
- Ollama local: `http://localhost:11434/v1` (Ollama phải chạy trên cùng máy đang chạy backend; với điện thoại Android không được giả định `localhost` là máy chủ khác).
- Gemini: `https://generativelanguage.googleapis.com`, chọn kiểu `Google Gemini API`.

Đối với dịch vụ khác, hãy kiểm tra tài liệu của nhà cung cấp: URL, model, phương thức xác thực và định dạng có thể khác nhau. Tên model và khả năng truy cập do tài khoản/nhà cung cấp quyết định. Không có cách an toàn để tự động tích hợp “tất cả AI hiện nay” chỉ với một endpoint. Để dùng nhiều model cùng một lúc, mở tab **Đấu trường AI → Thêm AI giao lưu**, tạo một hồ sơ cho từng model, kiểm tra kết nối, rồi chọn đối thủ và bấm **Giải giao lưu**. OpenRouter có thể làm cổng chung cho nhiều model tùy danh mục và quyền truy cập tài khoản.

## Lichess

Mở **Lichess**, nhập Personal Access Token, rồi bấm **Kiểm tra kết nối**. Token được giữ trong `sessionStorage` của trình duyệt/phiên app, không được ghi vào file dự án. Chọn API phù hợp:

- **Board API** cho tài khoản Lichess thông thường có scope cần thiết.
- **Bot API** chỉ khi tài khoản đã được nâng cấp thành tài khoản bot và có `bot:play` scope.

Sau đó tạo ván với AI Lichess hoặc gửi lời mời cho người chơi. Một số lời mời phải được đối thủ chấp nhận trước khi luồng ván bắt đầu. Nếu Lichess từ chối, giao diện sẽ hiện lỗi API; không phải mọi trạng thái challenge đều có thể chơi ngay trong app.

Tài liệu chính thức: https://lichess-org.github.io/api/ và trang quản lý token: https://lichess.org/account/oauth/token

## Xây dựng APK Android

### Cách tự build trên máy có Android SDK

```bash
npm install
npm test
npm run build
npx cap add android
npx cap sync android
node scripts/apply-android-branding.mjs
npx cap open android
```

Trong Android Studio, build `app` để lấy debug APK. Nếu đã có thư mục `android/`, bỏ qua `npx cap add android` và dùng `npx cap sync android`.

### Cách build qua GitHub Actions

1. Tạo repository GitHub và tải toàn bộ nội dung ZIP này lên repository.
2. Mở tab **Actions**, chạy workflow **Build Chess Bot APK** (hoặc push lên nhánh `main`).
3. Khi chạy xong, tải artifact `chess-bot-debug-apk`; bên trong có `app-debug.apk`.

APK dùng WebView và đóng gói luật cờ + Stockfish. **AI API và các thao tác Lichess cần backend được triển khai riêng có HTTPS**: sau khi cài app, vào **Cài đặt → API backend URL** và nhập URL máy chủ của bạn. Backend không tự chạy bên trong APK. Server sẽ từ chối khởi động nếu bind ra địa chỉ không phải loopback nhưng chưa đặt `TUBOR_ACCESS_TOKEN`; endpoint AI còn có giới hạn yêu cầu theo IP. Đây là lớp bảo vệ cơ bản, vẫn cần HTTPS, CORS đúng, quản lý quota và xác thực người dùng khi công khai.

## Cấu hình backend khi triển khai

Máy chủ mặc định chỉ nghe trên `127.0.0.1` để tránh mở proxy ra mạng ngoài. Khi bạn chủ động triển khai qua Docker/hosting, dùng biến môi trường để mở cổng và giới hạn nguồn gọi:

- `HOST=0.0.0.0`
- `PORT=8787`
- `CORS_ORIGIN=https://ten-mien-cua-ban,capacitor://localhost,https://localhost`
- `TUBOR_ACCESS_TOKEN=chuoi-random-dai-va-kho-doan` (bắt buộc nếu HOST không phải loopback; client phải cấu hình cùng chuỗi trong Cài đặt)
- `AI_RATE_LIMIT_PER_MINUTE=120` (giới hạn mặc định 120 yêu cầu AI mỗi phút cho từng IP; có thể điều chỉnh 10–600)

Không dùng API key của nhà cung cấp trong URL công khai, không ghi token vào log, không commit `.env`. Token backend nhúng trong một APK công khai có thể bị trích xuất; với ứng dụng phát hành rộng, hãy dùng cơ chế đăng nhập/ủy quyền theo người dùng, quota và rate limiting ở tầng server thay vì một bí mật dùng chung.

Docker:

```bash
docker build -t chess-bot-ai .
docker run --rm -p 8787:8787 \
  -e HOST=0.0.0.0 \
  -e CORS_ORIGIN='https://ten-mien-cua-ban,capacitor://localhost,https://localhost' \
  -e TUBOR_ACCESS_TOKEN='chuoi-random-dai' \
  chess-bot-ai
```

## Vì sao ZIP nguồn không có `settings.gradle` và `gradlew`?

ZIP nguồn web **không phải** dự án Gradle Android đã khởi tạo. Android native được Capacitor sinh ra sau khi cài dependencies. Vì vậy không thể mở ZIP nguồn rồi chạy `gradlew` trực tiếp ngay. Đây là chủ ý của gói nguồn, nhưng lần bàn giao trước chưa làm rõ nên dễ gây nhầm lẫn.

Quy trình tự động giờ kiểm tra bắt buộc `android/settings.gradle` (hoặc `.kts`), `android/gradlew`, `android/gradle/wrapper/gradle-wrapper.jar`, `gradle-wrapper.properties` và `android/app/build.gradle` (hoặc `.kts`) sau bước `npx cap add android` / `npx cap sync android`. Khi build thành công, GitHub Actions tạo thêm artifact **`chess-bot-android-gradle-source`** — đây mới là ZIP có thư mục `android/` cùng Gradle wrapper. Artifact `chess-bot-debug-apk` vẫn là file APK để cài đặt.

Nếu muốn tạo dự án Android thủ công trên máy có Node.js và Java, chạy từ thư mục chứa `package.json`:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
node scripts/apply-android-branding.mjs
node scripts/verify-android-project.mjs
cd android
./gradlew assembleDebug
```

Nếu thư mục `android/` đã có sẵn, bỏ lệnh `npx cap add android` và chạy tiếp `npx cap sync android`. Trên Windows, dùng `gradlew.bat assembleDebug`.

## Báo cáo kiểm tra bản nguồn 1.6.1 Chess Bot

Đã chạy thành công `npm run test:static`: **31/31 test đạt**, bao gồm engine profile, schema cài đặt, tài nguyên thương hiệu, workflow build, và các guard chống dữ liệu Lichess cũ. `node --check` chạy qua toàn bộ tệp JavaScript/MJS của dự án. Script icon Android cũng đã được kiểm tra trên một Android fixture tạm: nhãn app, manifest, 15 PNG mật độ icon và XML adaptive đều hợp lệ.

**Chưa xác minh:** `npm test` đầy đủ kết thúc với lỗi vì test luật cờ không thể nạp package `chess.js` chưa được cài trong môi trường (`ERR_MODULE_NOT_FOUND`); 31 bài test độc lập đạt nhưng không được tính là bộ test đầy đủ đã qua. `npm install` không tải được dependencies từ npm registry do lỗi DNS. Vì vậy luật cờ trên thư viện thật, Vite production build, khởi động Stockfish WASM, kết nối API/Lichess thực tế và APK Android vẫn cần chạy trong GitHub Actions hoặc máy có dependencies/Android SDK. Workflow Android bắt buộc có đủ Stockfish Lite + Full và dừng nếu thiếu, không cố tạo APK thiếu engine.

## Cấu trúc thư mục

```text
src/main.js              UI, bàn cờ, luồng bot, khai cuộc, AI và Lichess
src/engine-profile.js    Chọn Stockfish Lite/Full theo thiết bị
src/style.css            Giao diện responsive cho mobile/desktop
server/index.js          API proxy AI, Lichess và Opening Explorer
scripts/copy-engine.mjs  Copy engine JS/WASM từ npm package Stockfish
scripts/start.mjs        Khởi chạy production server
public/engine/           Tệp Stockfish được copy sau npm install
tests/chess.test.js       Kiểm thử luật cờ cơ bản và tính hợp lệ 25 khai cuộc
.github/workflows/       Workflow build APK
capacitor.config.json    Cấu hình Capacitor Android
```

## Đấu trường AI và giới hạn sức mạnh

- **Stockfish là engine cờ chuyên dụng**; hãy chọn **Tối đa**, Skill 20, và độ sâu cao để ưu tiên sức mạnh. Độ sâu 28–30 có thể tính lâu và làm điện thoại nóng/chậm; thử 18–24 trên điện thoại phổ thông.
- Elo ở đây là giới hạn sức mạnh ước lượng từ tùy chọn UCI của engine, không phải Elo online được chứng nhận và không tương đương chính xác với Chess.com/Lichess.
- Các mô hình hội thoại không phải engine cờ được huấn luyện chuyên dụng. Chess Bot chỉ chấp nhận nước hợp lệ; khi API lỗi hoặc trả nước sai, app dùng nước dự phòng và đánh dấu số lần dự phòng ở kết quả giải để người dùng không hiểu nhầm đó là nước do model chọn.
- Giải vòng tròn tối đa 6 đối thủ (tối đa 30 ván khi đủ 6 AI), hai ván mỗi cặp đổi màu. Mỗi nước LLM có thể dùng hạn mức/bị tính phí API.
- API key của hồ sơ AI được lưu trong localStorage trên thiết bị này, không được mã hóa bởi ứng dụng. Không dùng trên máy dùng chung; với dịch vụ công khai nên đặt key trên backend có xác thực, giới hạn tốc độ và quota.

## Kiểm thử và giới hạn

- Auto engine: chọn Full khi cả hai tín hiệu `navigator.deviceMemory >= 6` và `navigator.hardwareConcurrency >= 6`; khi thiếu dữ liệu chọn Lite. Đây là heuristic bảo thủ, không phải phép đo RAM chính xác; người dùng có thể chọn thủ công.

- `npm test` kiểm tra vị trí ban đầu, nước đi sai, nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hòa và PGN; đồng thời chạy các smoke test cấu trúc dự án. Cần cài dependencies trước.
- `npm run test:static` chạy các test độc lập không cần `node_modules` (31 test hiện tại).
- `node --check src/main.js`, `node --check src/engine-profile.js`, `node --check server/index.js`, `node --check scripts/copy-engine.mjs` và `node --check scripts/apply-android-branding.mjs` kiểm tra cú pháp JavaScript.
- `REQUIRE_STOCKFISH=1 npm run build` yêu cầu đủ bốn tệp JS/WASM của Stockfish Lite Single và Full Single; workflow Android bật cờ này để không đóng gói APK thiếu engine.
- `npm run build` kiểm tra bundling frontend; cần internet khi tải các package lần đầu.
- Nếu Stockfish không được copy/tải, ứng dụng sẽ hiện **Bot dự phòng** dùng nước đi hợp lệ với heuristic đơn giản. Đây không phải sức mạnh Stockfish.
- Bot LLM có thể đưa nước không hợp lệ; app kiểm tra nước trước khi áp dụng và dự phòng khi API lỗi.
- Giao diện tham khảo phong cách game cờ hiện đại nhưng không sao chép logo, tài sản hay nhận diện Chess.com.
- Stockfish theo GPL-3.0; chess.js theo BSD-2-Clause. Trước khi phân phối công khai, kiểm tra giấy phép và giữ thông báo bản quyền/phần mã nguồn tương ứng theo yêu cầu giấy phép.

## Tự động build khi tải ZIP lên GitHub (dấu xanh ✅)

Đã có workflow `.github/workflows/build-from-zip.yml`. Workflow này tìm ZIP mới nhất ở **thư mục gốc repository**, giải nén an toàn, cài dependencies, chạy test, yêu cầu đủ Stockfish Lite + Full, rồi build và tải APK lên Artifact. Dấu xanh chỉ hiện khi mọi bước bắt buộc đều thành công.

**Thiết lập một lần trên GitHub (điện thoại cũng làm được):**

1. Tạo/mở repository GitHub và vào **Add file → Create new file**. Đặt tên file là `.github/workflows/build-from-zip.yml`, dán nội dung từ file workflow cùng tên trong dự án, rồi Commit vào nhánh `main`.
2. Quay lại repository, chọn **Add file → Upload files** và tải ZIP dự án lên **thư mục gốc** repository, rồi Commit changes.
3. Mở **Actions → Build Android from uploaded ZIP**. Khi job xanh, mở lần chạy đó và tải `chess-bot-debug-apk` để cài đặt. Nếu công cụ build yêu cầu trực tiếp dự án Gradle, tải thêm artifact `chess-bot-android-gradle-source`; ZIP này đã có thư mục `android/`, `settings.gradle`, `gradlew` và wrapper jar.  Nếu đỏ, mở bước bị lỗi để xem log.

**Quan trọng:** GitHub không chạy workflow nằm bên trong một file ZIP chưa giải nén. Vì thế cần thêm workflow riêng vào `.github/workflows/` một lần trước (hoặc giải nén mã nguồn vào repository). Sau lần thiết lập ban đầu, việc commit ZIP mới ở thư mục gốc sẽ tự kích hoạt build. Workflow hiện hỗ trợ nhánh `main` và ZIP nằm ở thư mục gốc, không tự chạy khi ZIP chỉ nằm trong thư mục con.


## Bản sửa ổn định v2.6.1

- Chặn mất nội dung nháp AI Coach khi đang có yêu cầu khác chạy.
- Thêm timeout 90 giây cho lời gọi API từ giao diện và giữ hành vi hủy từ bên gọi.
- Chặn bắt đầu AI qua API khi thiếu API key bắt buộc với Gemini/Anthropic.
- Hủy luồng Lichess upstream đúng cách khi client ngắt kết nối; xử lý bản ghi NDJSON cuối kể cả khi không kết thúc bằng newline.
- Bổ sung kiểm tra hồi quy tĩnh cho các hành vi trên.

## Thay đổi và rà soát bản v2.6

- Bổ sung kiểm tra Gradle wrapper sau khi Capacitor tạo dự án Android; không chạy lệnh `./gradlew` nếu thiếu file cần thiết. Khi build thành công, CI xuất thêm `chess-bot-android-gradle-source` chứa dự án native đã tạo, bên cạnh APK.

- Đã chuẩn hóa/di trú cài đặt bằng `src/settings-schema.js`; giá trị số ngoài phạm vi hoặc endpoint không an toàn được thay bằng mặc định, hồ sơ trùng/không hợp lệ được lọc. Lưu cài đặt báo rõ khi bộ nhớ thiết bị không ghi được.
- Đã tách 25 khai cuộc vào `src/openings.js` để kiểm thử cả chuỗi SAN bằng `chess.js` trong pipeline CI.
- Luồng Stockfish dùng timer/epoch/FEN để bỏ nước đi cũ; yêu cầu hint có timeout và không đè handler Worker đang dùng; các yêu cầu bot đã lên lịch bị hủy khi đổi ván/chế độ.
- AI Coach chặn gửi lặp, cho phép hủy khi xóa hội thoại và bỏ qua phản hồi đến trễ. Kết quả Opening Explorer cũ không được ghi đè thế cờ mới.
- Lichess dùng token trong bộ nhớ/session thay vì tệp dự án. Nút ngắt kết nối hủy stream và xóa session hiện tại; mỗi luồng có mã ván/AbortController riêng nên phản hồi cũ bị bỏ qua. Link Lichess chỉ cho phép host `lichess.org` qua HTTPS và không nhận URL có userinfo/cổng lạ. Nút trong khung kết quả không trùng ID với nút khu vực ván đang hoạt động.
- Script Stockfish dọn toàn bộ thư mục engine chuyên dụng trước khi copy; production build yêu cầu đủ bốn tệp JS/WASM Lite + Full để không đóng gói nhầm tệp từ lần build trước. Nhãn tọa độ file a–h cũng được render trên đủ tám ô ở hàng cuối của cả bàn cờ chính và bàn Arena.
- Bộ `npm run test:static` hiện có 31 bài test. Chúng không thay thế kiểm thử cờ thực tế, kiểm thử mạng hay build APK.

## Branding resources

```text
public/chess-bot-logo.webp                       Full Chess Bot wordmark for the UI
public/chess-bot-icon.webp                       Optimized square icon used in the app header
public/chess-bot-icon.png                        High-resolution PNG icon
public/favicon.ico / public/favicon.png          Browser tab icons
resources/branding/                              Original high-resolution logo and icon master
resources/android-icons/                         Launcher icons at Android density sizes + adaptive XML
scripts/apply-android-branding.mjs               Copies icons and sets the native app label
scripts/verify-android-project.mjs               Verifies settings.gradle and the real Gradle wrapper
scripts/package-android-source.py                Packages generated Android/Gradle source for download
```

The source ZIP includes the logo assets but not a precompiled APK. The Android artifact is produced by the GitHub Actions build after dependency installation, tests, Stockfish asset checks, Capacitor sync and Gradle compilation.
