# Changelog

## v2.6.1 — Stability Fix (package version 1.6.1)

- Giữ bản nháp AI Coach khi có yêu cầu khác đang chạy.
- Timeout API dùng chung 90 giây và hỗ trợ abort từ caller.
- Kiểm tra cấu hình trước khi vào chế độ AI; không tự chuyển lỗi cấu hình thành nước đi dự phòng mà không cảnh báo.
- Hủy upstream Lichess đúng cách khi client disconnect.
- Xử lý NDJSON record cuối khi không có newline kết thúc.
- Thêm 5 kiểm tra hồi quy tĩnh.
- Đồng bộ phiên bản `/api/health` và tài liệu.
- Xác minh static 36/36; full tests/build bị giới hạn bởi DNS/npm dependency trong môi trường rà soát.
