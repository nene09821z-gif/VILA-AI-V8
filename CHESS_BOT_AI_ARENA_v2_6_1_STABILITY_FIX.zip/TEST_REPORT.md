# Chess Bot AI Arena v2.6.1 — Báo cáo kiểm tra

Ngày rà soát: 2026-10-16  
Phiên bản package/backend: 1.6.1

## Kết quả đã chạy

- `npm run test:static`: **36/36 passed, 0 failed**.
- `node --check` trên toàn bộ `.js` và `.mjs` trong `src/`, `server/`, `scripts/`, `tests/`: passed.
- JSON files: parse passed.
- XML files trong tài nguyên Android: parse passed.
- `unzip -t` trên ZIP phát hành: passed.

## Lỗi đã xác định và sửa trong 1.6.1

1. **AI Coach có thể làm mất bản nháp khi đang đợi câu trả lời.** Trước đây form xóa ô nhập rồi mới gọi hàm có guard `coachRequestActive`. Đã chuyển guard lên trước thao tác xóa.
2. **Yêu cầu API có thể chờ vô hạn ở giao diện.** `apiFetch()` có timeout 90 giây; tín hiệu hủy từ caller vẫn được truyền và listener được dọn trong `finally`.
3. **Chế độ AI có thể gọi endpoint dù thiếu thông tin truy cập bắt buộc.** Thêm `aiRequestConfigured()`; Gemini/Anthropic cần API key trước khi bắt đầu ván hoặc chuyển sang chế độ AI qua API.
4. **Stream Lichess phía backend có thể không hủy upstream đúng cách khi client ngắt.** Không còn gọi `ReadableStream.cancel()` sau khi stream bị `Readable.fromWeb()` khóa; thay bằng `AbortController` cho fetch và hủy stream Node khi response đóng.
5. **Bản ghi NDJSON cuối có thể mất nếu stream đóng mà không có newline.** Client flush decoder và xử lý dòng pending khi `reader.read()` trả `done`.
6. **Phiên bản backend health endpoint** đồng bộ với package version 1.6.1.

## Giới hạn chưa xác minh

- `npm test` đầy đủ hiện **không đạt trong môi trường này**: Node không tìm thấy `chess.js` vì dependencies chưa cài. `npm install --no-audit --no-fund` đã hết thời gian chờ do DNS `EAI_AGAIN` khi truy cập `registry.npmjs.org`.
- Vì vậy file `tests/chess.test.js` không thể tải và chạy: các kiểm tra luật cờ cùng bài xác minh 25 chuỗi khai cuộc trong file đó chưa được thực thi tại môi trường hiện tại. Lần `npm test` mới nhất có 36 bài tĩnh qua và một lỗi tải file test do thiếu dependency.
- Chưa hoàn tất `npm run build`, Capacitor/Gradle build, khởi động Stockfish JS/WASM trong Web Worker hay cài APK trên Android thật.
- ZIP nguồn không chứa `node_modules`, `dist`, APK hoặc Android Gradle project được sinh; build cần cài dependencies và chạy workflow hướng dẫn.
- ZIP nguồn không có `package-lock.json`, vì môi trường không thể truy cập npm registry để sinh lockfile đáng tin cậy. Đây là việc nên hoàn tất trong môi trường có mạng trước khi phát hành.

## Lệnh xác minh lại khi môi trường có mạng

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
REQUIRE_STOCKFISH=1 npm run build
npm run android:init
```

Sau đó chạy `./gradlew assembleDebug` trong thư mục `android/`, cài APK trên thiết bị thật, thử các luồng Stockfish, gợi ý, AI Coach, stream Lichess, PGN và đổi chế độ.

## Lưu ý về mức độ kiểm chứng

Các bài test tĩnh xác nhận hiện diện/hình dạng các guard và hành vi ở mã nguồn; chúng **không thay thế** kiểm thử tích hợp hoặc thử trực tiếp trên điện thoại. Không coi báo cáo này là xác nhận ứng dụng không có lỗi.
