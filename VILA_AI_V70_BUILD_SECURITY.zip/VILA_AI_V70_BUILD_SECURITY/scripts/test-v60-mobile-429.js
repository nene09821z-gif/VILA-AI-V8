'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const gatewayPkg = JSON.parse(fs.readFileSync(path.join(root, 'server/package.json'), 'utf8'));
const server = fs.readFileSync(path.join(root, 'server/src/server.js'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');

// 360px mobile UI & preview viewport must be explicit and applied after the old stylesheets.
assert.match(html, /id="vila-v60-360dpi-preview-429"/);
assert.match(html, /@media \(max-width: 390px\)/);
assert.match(html, /width',type==='mobile'\?'360px'/);
assert.match(html, /min-width',type==='desktop'\?'0':\(type==='tablet'\?'768px':'360px'\)/);
assert.match(html, /Điện thoại · 360px \(Android\)/);
assert.match(html, /#voiceBtn,html\.vila-simple #inputPlusBtn,html\.vila-simple #sendBtn/);
assert.match(html, /flex:0 0 32px!important;width:32px!important;min-width:32px!important;max-width:32px!important;height:34px!important/);
assert.match(html, /#previewPanel \.preview-toolbar-actions button\{width:30px/);

function exportBetween(startText, endText, names, globals = {}) {
  const start = html.indexOf(startText);
  const end = html.indexOf(endText, start);
  assert.notEqual(start, -1, `missing start ${startText}`);
  assert.notEqual(end, -1, `missing end ${endText}`);
  const source = html.slice(start, end);
  const context = {
    MAX_PROVIDER_COOLDOWN_MS: 15 * 60 * 1000,
    MAX_RETRY_WAIT_MS: 12000,
    REQUEST_COOLDOWN_KEY: 'vila_model_cooldowns_v2',
    modelCooldowns: {},
    localStorage: { setItem(k, v) { this[k] = v; } },
    Date,
    Math,
    ...globals,
  };
  vm.runInNewContext(source + '\n' + names.map(n => `this.${n}=${n};`).join('\n'), context);
  return context;
}
const rate = exportBetween(
  '        function isHardBillingLimitError(',
  '        async function requestOpenAIWithModelFallback(',
  ['isHardBillingLimitError','getProviderRateLimitCooldownMs','shouldRetryAnotherModel']
);
assert.equal(rate.shouldRetryAnotherModel({ status: 429, message: 'rate limit exceeded, retry later' }), true);
assert.equal(rate.shouldRetryAnotherModel({ status: 429, message: 'Quota exhausted for this model' }), true);
assert.equal(rate.shouldRetryAnotherModel({ status: 429, message: 'Billing is disabled for this project' }), false);
assert.equal(rate.shouldRetryAnotherModel({ status: 429, message: 'payment required' }), false);
assert.equal(rate.shouldRetryAnotherModel({ status: 401, message: 'Unauthorized' }), false);
assert.equal(rate.getProviderRateLimitCooldownMs({status:429}), 30000);
assert.equal(rate.getProviderRateLimitCooldownMs({status:429,retryAfterMs:60000}), 60000);

const cooldown = exportBetween(
  '        function parseRetryAfterMs(',
  '        function classifyGeminiError(',
  ['parseRetryAfterMs','markModelCooldown','getModelCooldown']
);
assert.equal(cooldown.parseRetryAfterMs({headers:{get(){return '7';}}},{}),7000);
assert.equal(cooldown.parseRetryAfterMs({headers:{get(){return '99999';}}},{}),15*60*1000);
assert.equal(cooldown.parseRetryAfterMs({headers:{get(){return null;}}},{error:{message:'Please retry after 4s'}}),4000);
cooldown.markModelCooldown('groq:model-A',30000);
assert.ok(cooldown.getModelCooldown('groq:model-A') > 0);
assert.ok(JSON.parse(cooldown.localStorage.vila_model_cooldowns_v2)['groq:model-A']);

assert.match(html, /if\(response\.status===429\)\{err\.retryAfterMs=parseRetryAfterMs\(response,parsed\.data\);markModelCooldown\(`\$\{provider\}:\$\{model\}`/);
assert.match(html, /markModelCooldown\(`gemini:\$\{model\}`/);
assert.match(html, /const order=allOrder\.filter\(model=>getModelCooldown\(`\$\{provider\}:\$\{model\}`\)===0\)/);
assert.match(html, /if\(status===429\)return !isHardBillingLimitError\(err\)/);
const streamStart = html.indexOf('async function vilaGeminiStreamWithThoughts(');
const streamEnd = html.indexOf('async function requestGeminiFast(', streamStart);
assert.notEqual(streamStart, -1, 'Gemini stream function exists');
assert.notEqual(streamEnd, -1, 'Gemini stream function end marker exists');
const streamSource = html.slice(streamStart, streamEnd);
assert.match(streamSource, /if\(response\.status===429\)\{\s*const raw=await response\.text\(\)/);
assert.match(streamSource, /error\.retryAfterMs=parseRetryAfterMs\(response,data\)/);
assert.match(streamSource, /markModelCooldown\(`gemini:\$\{model\}`/);
assert.match(html, /Number\(streamErr\?\.status\)===429/);
assert.match(html, /if\(response\.status!==429\|\|attempt>0\)break/);
assert.match(html, /function gatewayRetryAfterMs\(/);
assert.match(html, /window\.setAiStatus\(`Gateway đang giới hạn lượt · tự thử lại sau/);
assert.match(server, /Access-Control-Expose-Headers', 'Retry-After, X-VILA-Provider/);
assert.match(server, /const RPM = Number\.isFinite\(RPM_RAW\) \? \(RPM_RAW <= 0 \? 0/);
assert.match(server, /if \(RPM > 0 && bucket\.count > RPM\)/);
assert.match(server, /provider quotas still apply/i);
assert.equal(pkg.version, '67.0.0');
assert.equal(gatewayPkg.version, '67.0.0');
assert.match(gradle, /versionCode 79/);
assert.match(gradle, /versionName "67\.0\.0"/);
assert.match(server, /const APP_VERSION = '67\.0\.0'/);
assert.match(workflow, /node scripts\/run-all\.js/);
console.log('V60 360px UI, preview sizing, HTTP 429 recovery, Retry-After/cooldown and release metadata checks passed');

assert.match(html, /id="vilaModelPicker"/);
assert.match(html, /id="vilaModelPickerTrigger"/);
assert.match(html, /function chooseModel\(pid,id\)/);
assert.match(html, /vila-model-provider-tabs/);
assert.match(html, /model được áp dụng cho tin nhắn tiếp theo/);
