'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html'), 'utf8');
function getFunctionSource(name, nextMarker) {
  const start = html.indexOf(`function ${name}(`);
  const end = html.indexOf(nextMarker, start);
  assert.notEqual(start, -1, `missing ${name}`);
  assert.notEqual(end, -1, `missing end marker for ${name}`);
  return html.slice(start, end);
}

// Preview-only command is recognized locally; compound build requests still go to the AI.
const commandSource = getFunctionSource('isPreviewOnlyCommand', '        function loadWorkspaceCodeForPreview');
const commandCtx = {};
vm.runInNewContext(commandSource + '\nthis.check = isPreviewOnlyCommand;', commandCtx);
assert.equal(commandCtx.check('Chạy preview'), true);
assert.equal(commandCtx.check('Hãy chạy preview đi!'), true);
assert.equal(commandCtx.check('mở bảng xem trước'), true);
assert.equal(commandCtx.check('tạo website rồi chạy preview'), false);

// Extract full HTML from generated file blocks, fenced HTML and plain HTML.
const extractSource = getFunctionSource('extractAndExecuteCode', '        function validateProjectWorkspace');
function extractionContext() {
  const saved = {};
  const ctx = {
    CODE_MEMORY_KEY: 'test-code', latestGeneratedCode: '', latestGeneratedCodeType: '',
    localStorage: { setItem(k, v) { saved[k] = v; } },
    saved,
    window: { innerWidth: 400 }, previews: 0, mobilePanels: 0,
  };
  ctx.runGeneratedCode = () => { ctx.previews++; };
  ctx.showMobilePanel = () => { ctx.mobilePanels++; };
  vm.runInNewContext(extractSource + '\nthis.extract = extractAndExecuteCode;', ctx);
  return ctx;
}
let ctx = extractionContext();
assert.equal(ctx.extract('Here is the app:\n<file path="index.html"><!doctype html><html><body><h1>VILA</h1></body></html></file>'), true);
assert.match(ctx.latestGeneratedCode, /<h1>VILA<\/h1>/);
assert.equal(ctx.latestGeneratedCodeType, 'html');
assert.equal(ctx.previews, 1);
assert.equal(ctx.mobilePanels, 1);
ctx = extractionContext();
assert.equal(ctx.extract('```html\n<!doctype html><html><body>Preview</body></html>\n```'), true);
assert.match(ctx.latestGeneratedCode, /Preview/);
ctx = extractionContext();
assert.equal(ctx.extract('Intro text\n<!doctype html><html><body>Bare</body></html>'), true);
assert.match(ctx.latestGeneratedCode, /Bare/);

// Workspace candidate prioritizes index.html, allowing Preview when no generated-code cache exists.
const workspaceSource = getFunctionSource('loadWorkspaceCodeForPreview', '        function shouldRunPreviewCommand');
const workspaceCtx = {
  projectWorkspace: {
    'assets/view.html': { kind: 'text', content: '<html><body>other</body></html>' },
    'index.html': { kind: 'text', content: '<!doctype html><html><body>index</body></html>' },
  },
  latestGeneratedCode: '', latestGeneratedCodeType: '', CODE_MEMORY_KEY: 'test-code',
  localStorage: { setItem() {} },
};
vm.runInNewContext(workspaceSource + '\nthis.load = loadWorkspaceCodeForPreview;', workspaceCtx);
assert.equal(workspaceCtx.load(), true);
assert.match(workspaceCtx.latestGeneratedCode, /index/);
assert.equal(workspaceCtx.latestGeneratedCodeType, 'html');

// A live Gemini model catalog is consulted only after the static fallback attempts fail.
const geminiSource = getFunctionSource('requestGeminiWithFallback', '        function geminiGenerateContentUrlForBase');
assert.match(geminiSource, /listProviderModels\('gemini'/);
assert.match(geminiSource, /model dự phòng/);
assert.match(geminiSource, /isGeminiFallbackEligible\(err\)/);
assert.match(html, /id="vila-v59-final-mobile-overflow-fix"/);
assert.match(html, /#previewPanel\.mobile-visible #liveFrame/);
assert.match(html, /if\(rawPrompt && isPreviewOnlyCommand\(rawPrompt\) && pendingAttachments\.length===0\)/);
assert.doesNotMatch(html, /Suy luận nhiều đội cần bật và triển khai AI Gateway VILA/);
const workflow = fs.readFileSync(path.join(__dirname, '..', '.github', 'workflows', 'main.yml'), 'utf8');
assert.match(workflow, /node scripts\/run-all\.js/);

console.log('V59 preview local command, HTML extraction, workspace loading, Gemini fallback and mobile overflow checks passed');
