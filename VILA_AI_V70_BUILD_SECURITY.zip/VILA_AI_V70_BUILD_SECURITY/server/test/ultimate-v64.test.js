'use strict';
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { classifyTask, dynamicReasoningProfile, rankProviders } = require('../src/engine');

describe('V64 Ultimate engine', () => {
  it('classifies long multi-question as reasoning', () => {
    const msgs = [{ role: 'user', content: 'Tại sao A? Vì sao B? So sánh C với D? Giải thích sâu.' }];
    assert.equal(classifyTask(msgs), 'reasoning');
  });
  it('dynamic reasoning high for coding on gemini', () => {
    const p = dynamicReasoningProfile('gemini', 'gemini-2.5-pro', 'coding', 'sửa bug', 'auto');
    assert.equal(p.effort, 'high');
    assert.ok(p.gemini?.thinkingConfig?.thinkingBudget >= 8192);
  });
  it('dynamic reasoning openrouter effort', () => {
    const p = dynamicReasoningProfile('openrouter', 'auto', 'reasoning', 'chứng minh', 'auto');
    assert.equal(p.effort, 'high');
    assert.equal(p.openrouter?.reasoning?.effort, 'high');
  });
  it('openai-compatible reasoning_effort for groq', () => {
    const p = dynamicReasoningProfile('groq', 'gpt-oss-120b', 'reasoning', 'x', 'high');
    assert.equal(p.openaiCompatible?.reasoning_effort, 'high');
  });
  it('rankProviders prefers reasoning models', () => {
    const list = rankProviders([
      { id: 'cerebras', configured: true, model: 'llama3.1-8b', health: 'ok' },
      { id: 'openrouter', configured: true, model: 'qwen3-reasoning', health: 'ok' }
    ], 'reasoning', { provider: 'auto' });
    assert.ok(list.length >= 1);
    assert.equal(list[0].id, 'openrouter');
  });
});
