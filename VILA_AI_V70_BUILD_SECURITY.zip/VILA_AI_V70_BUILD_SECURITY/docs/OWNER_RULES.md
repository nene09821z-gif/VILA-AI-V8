# VILA — Quy tắc chủ sở hữu (đã gỡ)

Từ bản **63.1.0-VIP**, quy tắc chủ nhân mặc định **đã được xóa**.

- System prompt không còn ép “QUY TẮC RIÊNG CỦA CHỦ”.
- Người dùng có thể tự nhập quy tắc tùy chỉnh trong Cài đặt (tùy chọn); để trống = không inject.
- Suy luận động (dynamic reasoning) áp dụng cho **mọi** provider API: Gemini, OpenRouter, OpenAI, Groq, Cerebras, Mistral, Together, Fireworks, Custom, Puter.

Không còn ưu tiên “chủ VILA” hay bypass bất kỳ chính sách bảo mật nào.
