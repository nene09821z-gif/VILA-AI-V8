# Build GitHub ổn định SHA-1 (Ultimate)

## Secrets bắt buộc cho release keystore cố định
Trong GitHub → Settings → Secrets and variables → Actions:

| Secret | Mô tả |
|--------|--------|
| `ANDROID_KEYSTORE_BASE64` | File `.jks`/`.keystore` encode base64 |
| `ANDROID_KEYSTORE_PASSWORD` | Mật khẩu keystore |
| `ANDROID_KEY_ALIAS` | Alias key |
| `ANDROID_KEY_PASSWORD` | Mật khẩu key |

Tạo base64 (Linux/macOS):
```bash
base64 -w0 release.keystore > keystore.b64
```

## Firebase
1. Chạy workflow → tải artifact → mở `sha1-fingerprint.txt`
2. Thêm SHA-1 vào Firebase Console → Project settings → Android app
3. Tải lại `google-services.json` nếu cần → commit → build lại

## Không làm
- Không dùng APK debug ngẫu nhiên để kết luận Google Sign-In
- Không commit file keystore/password vào git
