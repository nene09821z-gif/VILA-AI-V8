# VILA AI Studio V67 — Google Play release gate

Do not submit this source build to the Play Store until each production item has an owner and evidence.

## Build and device validation
- [ ] GitHub Actions passes `npm test`, all regression scripts, Android `testDebugUnitTest`, `assembleDebug`, and `lintDebug`; when private signing secrets are configured, it also passes `bundleRelease` and `lintRelease`.
- [ ] Test installation on a low-memory/older supported device and a current Android device.
- [ ] Test sign-up, Google sign-in, password reset, expired session and account deletion end-to-end.
- [ ] Test provider failure, empty output, timeouts, rate limits, stream mode, image requests and deep team mode.
- [ ] Confirm the release APK is signed with a private release keystore; never use the committed debug key as the store signing key.
- [ ] Verify package ID, version code, target SDK, supported devices and native libraries in the actual AAB/APK.

## Backend operation
- [ ] Deploy Gateway to an always-on server with HTTPS/TLS and a restricted network policy.
- [ ] Firebase Admin credentials and provider keys are stored in the hosting secret manager; no real `.env` file is committed or bundled in the app.
- [ ] Set `AUTH_MODE=firebase`, correct Firebase project ID and the observed app/web CORS origins. Never use wildcard production CORS.
- [ ] Configure spending/quota caps at each upstream provider and alert on 401/403/429, fallback spikes, elevated latency and provider errors.
- [ ] Verify `/health/live`, `/health/ready`, authenticated `/v1/gateway/status` and a live test against each configured provider.
- [ ] Before deploying multiple replicas, move rate limits, usage accounting and circuit-breaker coordination out of per-process memory.
- [ ] Add a rollout/rollback strategy, routine backups where data persists, a security update process and an operator contact path.
- [ ] Compose `restart: unless-stopped` helps recovery but is not an uptime/SLA guarantee.

## User data and Play Console
- [ ] Replace every placeholder in `privacy-policy.html` and `account-deletion.html` with verified operator details and real procedures.
- [ ] Host policy and account-deletion request pages publicly on HTTPS and test from an unauthenticated browser after uninstalling the app.
- [ ] Confirm actual backend retention, provider processing, analytics/logging, account data, uploaded content and deletion semantics; update the policy to match reality, not this template alone.
- [ ] Complete Play Console Data safety, content rating, target audience, ads declaration (if relevant), app access instructions and contact details accurately.
- [ ] Test that account deletion invalidates Firebase credentials and removes all VILA-controlled data; document any legally required retention.
- [ ] Disclose that deep reasoning may transmit the conversation to more than one configured provider and can increase latency or cost/quota usage.
- [ ] Review third-party provider terms, data-processing conditions and licenses for the actual providers/models enabled.

## Release status

**Not yet release-approved.** This repo is source code. The API 36 target is configured, but CI build logs, live deployment checks, real-device QA and Play Console review can confirm readiness. The current workflow does not intentionally publish an unsigned `assembleRelease` artifact; it only produces a signed release AAB when all private keystore secrets are present. As of 31 August 2026, Google Play requires new apps and updates to target API 36 or higher; see the official requirement: https://support.google.com/googleplay/android-developer/answer/11926878?hl=en.
