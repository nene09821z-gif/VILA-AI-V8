# VILA AI Studio 67.0.0 — AI Workspace + Chat Archive

Ứng dụng Android (WebView) kết nối nhiều nhà cung cấp AI, kèm AI Gateway (Node.js) tuỳ chọn. Gói này là mã nguồn, không phải APK/AAB dựng sẵn.

## V67 — Reliability and Play release lane
- Real conversation archive with switching, rename/delete, JSON text-only backup import/export, and bounded local persistence.
- GitHub Actions builds a debug APK for device testing and builds a signed release AAB only when all private signing secrets are configured. Missing signing keys are reported explicitly; no unsigned release bundle is presented as Play-ready.
- `npm run play:preflight` reports release readiness blockers; `npm run play:preflight:strict` exits nonzero while mandatory owner-provided Play data is missing.
- Version metadata: app/Gateway `67.0.0`, Android `versionCode 79`, `targetSdk 36`.
- **Not Play-approved yet:** owner contact details and real public HTTPS privacy/account-deletion URLs are intentionally not fabricated. See `docs/PLAY_STORE_READINESS.md` and `docs/BUILD_GUIDE_V67.md`.

## V66 Clean UI
- Compact mobile-first chat layout with only Light/Dark theme modes.
- Model Hub filters wrap cleanly instead of overlapping the sorting selector.
- Google sign-in buttons explicitly say “Đăng nhập bằng Google”.
- Removed the duplicate floating navigation control; moved Voice Studio into the main menu so it no longer covers the composer. Max Mode is placed in the chat status row.
- Source ZIP only. Android build/sign-in and provider calls still need verification in the actual configured environment.

## Puter AI Hub
Puter.js được tích hợp như một provider độc lập. VILA tự đồng bộ danh mục model chat do Puter công bố qua `puter.ai.listModels()` và cho phép tìm theo model/provider. Danh mục thay đổi theo dịch vụ; chỉ các model thực tế từ catalog được đưa vào danh sách động. Puter có thể yêu cầu đăng nhập, giới hạn/quota và chi phí (nếu có) phụ thuộc tài khoản/chính sách dịch vụ. Xem `docs/CLAUDE_PUTER.md`.

## Model Hub Turbo (V62)
Danh mục model có tìm kiếm không phân biệt dấu tiếng Việt, lọc theo provider/khả năng, mục yêu thích, lịch sử model gần đây và tải hiển thị theo lô 60 mục để giảm tải trên điện thoại. Khả năng ảnh/suy luận/web ưu tiên metadata do provider công bố; bộ lọc lập trình có thể dùng tên model làm gợi ý. Nhãn `FREE*` không bảo đảm model còn miễn phí, quota hoặc khả dụng tại thời điểm gửi.

## Cấu trúc
- `app/` — ứng dụng Android (Java + giao diện web trong `assets/`)
- `server/` — AI Gateway (Express, Firebase Admin, định tuyến nhiều provider, đa đội suy luận, công cụ agent)
- `scripts/` — kiểm tra hồi quy mã nguồn (không cần mạng)
- `tools/play-preflight.js` — kiểm tra các điều kiện phát hành và chặn nếu còn placeholder bắt buộc
- `docs/` — Firebase, đăng nhập Google, Gateway, Play Store, bản đồ kỹ thuật và quy tắc chủ sở hữu
- `.github/workflows/main.yml` — CI: test, build APK, kiểm tra SHA-1 Google OAuth
- `CHANGELOG.md` — lịch sử thay đổi
- `V67_TEST_REPORT.md` — kết quả kiểm thử thực tế và các giới hạn chưa xác minh

## Chạy kiểm tra
```bash
npm test                       # Gateway + kiểm tra hồi quy giao diện/mã nguồn
npm run play:preflight         # Báo cáo các điều kiện còn thiếu trước khi phát hành
npm run play:preflight:strict  # Mã thoát khác 0 nếu còn hạng mục chặn phát hành
```

## Chạy Gateway
```bash
cp server/.env.example server/.env   # điền khoá provider của bạn
cd server && npm install && npm start
```
Triển khai production: xem `docs/GATEWAY_DEPLOYMENT.md` và `compose.yaml` (chỉ bind loopback; cần reverse proxy HTTPS).

**Giới hạn lượt nội bộ:** Gateway mặc định giới hạn theo `REQUESTS_PER_MINUTE=30`. Chủ server có thể đặt `REQUESTS_PER_MINUTE=0` để tắt riêng giới hạn RPM nội bộ của VILA; giới hạn đồng thời và quota/rate limit của từng nhà cung cấp AI vẫn áp dụng. Không có cài đặt nào biến quota của Google/nhà cung cấp thành vô hạn.

## Build APK
Đẩy toàn bộ nội dung thư mục này lên GitHub, chạy workflow **VILA AI - Android Build and Verify** và tải artifact. Xem `docs/BUILD_GUIDE_V67.md` để build APK kiểm thử và tạo AAB ký phát hành bằng GitHub Actions.

## Giới hạn đã biết
- APK chỉ được coi là build thành công sau khi GitHub Actions chạy xong; đăng nhập Google cần SHA-1 khớp với Firebase.
- Danh mục Puter là dữ liệu trực tiếp của dịch vụ, không cam kết mọi model đều truy cập được hoặc miễn phí.
- `privacy-policy.html` và `account-deletion.html` là bản nháp, cần điền thông tin thật và host HTTPS trước khi lên Play Store (`docs/PLAY_STORE_READINESS.md`).
- Đã có `gradlew`/`gradlew.bat`, nhưng `gradle/wrapper/gradle-wrapper.jar` (file nhị phân) vẫn thiếu vì môi trường tạo ZIP này không có mạng để tải — cần chạy `gradle wrapper --gradle-version 9.3.1` một lần ở máy có cài Gradle + mạng để sinh file đó, rồi mới `./gradlew` build local được. CI không cần file này vì tự cài Gradle 9.3.1 trực tiếp. Chưa có APK/AAB đã xác minh trong ZIP này.
- Đã thêm `app/src/main/res/xml/network_security_config.xml`, thay cho `usesCleartextTraffic="true"` áp toàn app: chỉ máy chủ UI nội bộ 127.0.0.1 được phép HTTP, các nhà cung cấp AI dựng sẵn vẫn luôn gọi HTTPS. Nếu Custom API trỏ sang server LAN tự host qua HTTP, cần tự thêm IP/host đó vào file cấu hình này (Android không cho khai cả dải IP LAN một lần).
- Không có cam kết uptime 24/7; xem `docs/TECHNOLOGY_MAP.md`.
