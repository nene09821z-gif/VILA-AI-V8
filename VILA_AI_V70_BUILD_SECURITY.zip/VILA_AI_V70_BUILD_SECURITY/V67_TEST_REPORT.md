# VILA AI Studio V67 — Test & Release Audit

**Audit date:** 2026-10-15  
**Project version:** 67.0.0  
**Android versionCode:** 79  
**Scope:** source update, offline regression tests, source/config parsing, and Play release preflight.

## Summary

- `npm test`: **32/32 regression groups passed** on Node.js 22.16.0.
- V67 source quality check: **passed**; 16 inline JavaScript blocks and every standalone JavaScript asset under `app/src/main/assets/` parse without syntax errors.
- XML parsing: **5/5** Android/resource XML files parsed.
- JSON parsing: **3/3** project JSON files parsed.
- GitHub Actions workflow YAML: syntax parse passed.
- `npm run play:preflight`: **4 passed, 3 warnings, 2 release blockers** (listed below).
- `npm run play:preflight:strict`: correctly exits nonzero while owner-specific release requirements remain unresolved.

These results describe local source tests and static checks. They are not proof that Android compiled, that a Play AAB was signed, or that external integrations work live.

## V67 work included

1. Aligned app and Gateway metadata to `67.0.0`, Android `versionCode 79`, and `targetSdk 36`.
2. Added bounded local conversation archive with chat switching, rename/delete, JSON text-only backup import/export, and limits of 12 stored chats, 40 messages per chat, and 3,000 characters per message. Binary attachments and API keys are not included in chat backups.
3. Added migration-once behavior: the V66 legacy single conversation is imported only if there is no V67 archive; an intentionally empty V67 chat is not repopulated with stale legacy messages after restart. Tests cover stale active IDs, manual title preservation, message bounds and archive import/export validation.
4. Changed native `saveTextFile` bridge to return a real success/failure value; code and history export no longer display success simply because the call returned without throwing.
5. Added native cleanup for all provider-key preference entries and the local encryption alias during the existing account-deletion path. Runtime/device verification remains outstanding; failed key cleanup is surfaced as incomplete rather than reported as a full wipe.
6. Fixed the Google OAuth CI check to require the configured stable debug SHA-1 while allowing additional valid release-certificate SHA-1 clients in Firebase configuration.
7. Hardened release CI: debug APK is built for testing; signed release AAB is built only when all private keystore secrets are supplied. Partial signing configuration fails the workflow. The workflow does not label a debug APK as Play-ready.
8. Enabled Android lint failures and added Play preflight/build instructions.

## Exact local checks

### Passed

- `npm test` — 32 regression groups passed. Includes Gateway unit tests and legacy regressions for API routing, fallback/reliability, model hub, media, Firebase source wiring, UI, secret storage and release gates.
- `node scripts/test-v67-source-quality.js` — passed; 16 inline scripts parsed and all standalone asset JavaScript parsed.
- Python `xml.etree.ElementTree` — 5 XML files parsed.
- Python JSON parser — 3 JSON files parsed.
- PyYAML BaseLoader — `.github/workflows/main.yml` parsed.
- `npm run play:preflight` — reported current conditions without pretending unresolved requirements are complete.

### Known blockers and warnings

**BLOCK — Privacy policy:** `privacy-policy.html` still has owner/contact/URL placeholders. Real policy details and a public HTTPS URL must be supplied by the app owner and must match actual data handling.

**BLOCK — External account deletion:** `account-deletion.html` is explicitly a template and still has contact email and deletion-period placeholders. It must be made publicly reachable over HTTPS and the request path must work without installing the app. The app contains an in-app Firebase account-delete path, but this does not replace the separate external request link.

**WARN — Cleartext networking:** `AndroidManifest.xml` currently has `usesCleartextTraffic="true"` because the app serves a loopback UI and supports configurable local/LAN endpoints. Review the actual network-security model before public release; do not send private prompts or credentials to untrusted HTTP endpoints.

**WARN — Gradle Wrapper incomplete:** only `gradle/wrapper/gradle-wrapper.properties` is present; `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar` are missing. CI uses Gradle 9.3.1 via the GitHub Actions setup step. The ZIP therefore does not claim a local `./gradlew` build path.

**WARN — Release/runtime evidence absent:** no signed AAB, APK install test, live Firebase OAuth, provider API call, real-device visual pass, public HTTPS check, or Play Console validation was completed in this workspace.

## What is present vs what is runtime-verified

| Area | Source status | Runtime status in this audit |
|---|---|---|
| Chat archive logic | Implemented; core behavior tested in Node | UI not exercised end-to-end on Android |
| AI providers / model routing | Existing integration and regression tests retained | No live provider requests in this audit |
| Google/email authentication | Native/web integration source and configuration checks exist | No live sign-in/register/reset/delete test |
| Code workspace / files | Existing project features retained; native save result improved | No complete ZIP-edit-run-export scenario tested on device |
| Voice, image, video | Existing feature code retained | Device permissions and live provider response not tested |
| Android app | Build configuration prepared; lint strict | No APK/AAB built here; no SDK/Gradle installed locally |
| Gateway server | Existing Node unit tests pass | Full external-service deployment not started here |
| Google Play readiness | CI release signing gate and preflight added | **Not ready to submit** until blockers/warnings and live QA are cleared |

## Suggested release sequence

1. Resolve placeholders and publish the actual HTTPS privacy and account-deletion pages.
2. Review cleartext networking, actual provider endpoints and permission use.
3. Add private keystore secrets to GitHub Actions; never commit the release keystore/password.
4. Run the Android workflow and keep successful CI logs plus the signed AAB artifact.
5. Install/test from an internal test track on real Android devices: signup/login/reset/delete, restore/switch chats, save/export files, attachments, voice and provider failures.
6. Complete Data safety, app access, content rating, developer contact, store listing and Play Console declarations accurately.
7. Run `npm run play:preflight:strict` again. It should not pass until all mandatory owner-specific placeholders are genuinely resolved.

## Policy references checked on 2026-10-15

- Google Play target API requirements: https://support.google.com/googleplay/android-developer/answer/11926878?hl=en — new apps and updates must target API 36+ from 2026-08-31 for the standard Android app category.
- Google Play account deletion requirements: https://support.google.com/googleplay/android-developer/answer/13327111?hl=en — apps that allow account creation need an in-app deletion path and a public web resource for deletion requests.
- Android Gradle Plugin 9.1.1 compatibility: https://developer.android.com/build/releases/agp-9-1-0-release-notes — supports API 37 and Gradle 9.3.1.
