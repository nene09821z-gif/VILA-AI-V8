# VILA AI Studio V9 — Android APK

Bản Android native WebView, chạy độc lập khỏi Chrome. Giao diện VILA V8 được đóng trong APK; app có một proxy HTTP cục bộ để chuyển `/api/*` tới Node.js VILA Server. API key vẫn nằm ở server, không nằm trong APK.

## Chạy server
Node.js >= 18:

```bash
npm install
GEMINI_API_KEY=YOUR_KEY npm start
```

Server cần có internet để gọi Gemini. Sau khi deploy, mở APK → ⚙ Server → nhập `https://domain-cua-ban`.

## Build APK
Mở thư mục này bằng Android Studio, Sync Gradle, rồi Build > Build APK(s).

Hoặc dùng Gradle 8.7+:

```bash
gradle assembleDebug
```

APK debug: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Có workflow `.github/workflows/build-apk.yml`; push project lên GitHub rồi vào Actions để build APK tự động.

## V9.1 Server selector
- Mở Cài đặt trong app để chọn server nội bộ hoặc nhập server online.
- Server online phải có endpoint `/api/health` và `/api/chat`.
- API key nên chỉ nằm ở server.
- App lưu địa chỉ server đã chọn.


VILA V13: performance optimized for Android/WebView, reduced mobile effects, disabled particle animation on mobile, reduced shadows/backdrop blur, hardware-accelerated WebView.


## VILA V15 Gemini Enhanced

Bản nâng cấp giữ VILA V15 làm gốc và bổ sung lớp giao diện/điều khiển theo phong cách trợ lý AI hiện đại:

- Chat mới và lịch sử chat trên thiết bị.
- Bộ nhớ dự án chỉnh sửa được.
- Chế độ Tự động / Lập trình / Soạn văn / Suy luận / Nhanh.
- Đính kèm nhiều file và đọc PDF/DOCX/text/code.
- Ảnh được gửi theo multimodal `image_url` khi endpoint hỗ trợ.
- Ghi giọng nói bằng Web Speech API khi WebView/thiết bị hỗ trợ.
- Nút Dừng để hủy request đang chạy bằng `AbortController`.
- Smart model routing theo tác vụ và fallback chống 429.
- Live Preview, kiểm tra code và xuất file.
- Sửa các nút Settings, Attach, Clear/New Chat và các điều khiển V15 bị thiếu event.
- Server tăng body limit cho file/ảnh và có `/api/models` để lấy model Gemini khả dụng.
- GitHub Actions build APK trực tiếp bằng Gradle.

Lưu ý: API key nên để ở server khi triển khai công khai. Bản client vẫn hỗ trợ cấu hình key cho mục đích cá nhân.
