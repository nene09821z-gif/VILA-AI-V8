# VILA V15 Gemini Enhanced - GitHub Build

This archive is a flat Android Gradle project. Do not put another ZIP inside the repository.

Repository root must contain:
- app/
- build.gradle
- settings.gradle
- gradle.properties
- .github/workflows/main.yml

GitHub Actions builds `app-debug.apk` and uploads it as an artifact named `VILA-V15-Gemini-Enhanced-debug`.
