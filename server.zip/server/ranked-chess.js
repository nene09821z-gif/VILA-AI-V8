/** Pure helpers for server-authoritative ranked chess. */
export function eloExpectedScore(playerElo, opponentElo) {
  const player = Number.isFinite(Number(playerElo)) ? Number(playerElo) : 1200;
  const opponent = Number.isFinite(Number(opponentElo)) ? Number(opponentElo) : 1200;
  return 1 / (1 + (10 ** ((opponent - player) / 400)));
}

export function calculateRankedEloChange(playerElo, opponentElo, score, kFactor = 24, bonus = 0) {
  const player = Math.max(100, Math.min(4000, Math.round(Number(playerElo) || 1200)));
  const opponent = Math.max(100, Math.min(4000, Math.round(Number(opponentElo) || 1200)));
  const result = Math.max(0, Math.min(1, Number(score)));
  const k = Math.max(16, Math.min(40, Math.round(Number(kFactor) || 24)));
  const variance = Math.max(0, Math.min(6, Math.round(Number(bonus) || 0)));
  let delta = Math.round(k * (result - eloExpectedScore(player, opponent)));
  if (result === 1 && variance) delta += variance;
  if (result === 0 && variance) delta -= Math.min(2, variance);
  const next = Math.max(100, Math.min(4000, player + delta));
  return { before: player, after: next, delta: next - player };
}

export function matchmakingWindow(waitSeconds = 0) {
  return Math.min(500, 100 + Math.floor(Math.max(0, Number(waitSeconds) || 0) / 10) * 50);
}

export function chooseRandomOpponent(queue, userId, elo, now = Date.now(), random = Math.random) {
  const candidates = (Array.isArray(queue) ? queue : []).filter(entry => {
    if (!entry || entry.userId === userId || !Number.isFinite(Number(entry.elo))) return false;
    const waited = Math.max(0, (now - Number(entry.joinedAt || now)) / 1000);
    return Math.abs(Number(entry.elo) - Number(elo)) <= matchmakingWindow(waited);
  });
  if (!candidates.length) return null;
  const index = Math.max(0, Math.min(candidates.length - 1, Math.floor(random() * candidates.length)));
  return candidates[index];
}

export function rankedResultFromChess(chess) {
  if (!chess || typeof chess.isGameOver !== 'function' || !chess.isGameOver()) return null;
  if (chess.isCheckmate()) return chess.turn() === 'w' ? '0-1' : '1-0';
  return '1/2-1/2';
}

/** Return true when a player's last server-observed presence exceeds the disconnect grace period. */
export function hasRankedPresenceExpired(lastSeenAt, now = Date.now(), timeoutMs = 90_000) {
  const lastSeen = Number(lastSeenAt);
  if (!Number.isFinite(lastSeen) || lastSeen <= 0) return false;
  return Number(now) - lastSeen > Math.max(1_000, Number(timeoutMs) || 90_000);
}

/** Subtract elapsed time from the server-authoritative side-to-move clock. Returns the flagged color, or null. */
export function settleRankedClock(match, now = Date.now(), sideToMove = 'w') {
  if (!match || !match.clockEnabled || !match.clockRemainingMs || !['w', 'b'].includes(sideToMove)) return null;
  const updatedAt = Number(match.clockUpdatedAt) || Number(now);
  const elapsed = Math.max(0, Number(now) - updatedAt);
  const prior = Math.max(0, Number(match.clockRemainingMs[sideToMove]) || 0);
  const next = Math.max(0, prior - elapsed);
  match.clockRemainingMs[sideToMove] = next;
  match.clockUpdatedAt = Number(now);
  return next <= 0 ? sideToMove : null;
}
