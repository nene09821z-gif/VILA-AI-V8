import { Chess } from 'chess.js';
import { resolveEngineProfile, nextEngineFallback, engineAssetFile } from './engine-profile.js';
import { formatUciScore, parseUciInfoLine } from './analysis-utils.js';
import { isCurrentAnalysisSession, mergeAnalysisVariation } from './analysis-session.js';
import { calculateBoardFrameMaxWidth, calculateChessSquareSize } from './board-layout.js';
import { CLOCK_PRESETS, RANKED_CLOCK_PRESETS, classifyTimeControl, formatClockTime, parseClockPreset } from './clock.js';
import { OPENINGS } from './openings.js';
import { mergeOpeningEntries } from './opening-catalog.js';
import { findOpeningBookMove } from './opening-book.js';
import { recognizeOpening } from './opening-recognition.js';
import { buildOpeningBookPrefixes, classifyReviewedMove, estimateMoveLoss, scoreSideToWhiteCentipawns, reviewSymbolForJudgement, reviewSymbolDescription } from './game-review.js';
import { resolveStockfishStrength } from './elo-strength.js';
import { BUILTIN_FREE_MODEL_PRESETS, freePresetsForProvider, isLocalNoKeyEndpoint } from './builtin-models.js';
import { playBoardSound, unlockBoardSound, isChessMusicPlaying, setChessMusicPlaying } from './sound.js';
import { applyEloResult } from './elo.js';
import { DEFAULTS, normalizeSettings } from './settings-schema.js';
import { DAILY_MISSIONS, COSMETICS, normalizeDailyState, recordMissionEvent, claimMissionReward, purchaseCosmetic, equipCosmetic, getMissionSummary } from './daily-progress.js';
import { addNotification, clearReadNotifications, markAllNotificationsRead, markNotificationRead, normalizeNotifications, unreadNotificationCount } from './notifications.js';
import { buildSystemChecks, REQUIRED_OPENING_COUNT } from './system-health.js';
import './style.css';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const STORAGE_KEY = 'tubor.chess.settings.v1';
const lichessTokenKey = 'tubor.chess.lichessToken.session';
const RATING_KEY = 'chessbot.local.rating.v1';
const RATING_HISTORY_KEY = 'chessbot.local.rating.history.v1';
const GAME_HISTORY_KEY = 'vila.chess.saved-games.v1';
const SOCIAL_SESSION_KEY = 'vila.chess.social.session.v1';
const SOCIAL_USER_KEY = 'vila.chess.social.user.v1';
const DAILY_PROGRESS_KEY = 'vila.chess.daily-progress.v1';
const NOTIFICATIONS_KEY = 'vila.chess.notifications.v1';
function readSocialCache(key, fallback = null) { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; } }
function readDailyProgress() {
  let raw = null;
  try { raw = localStorage.getItem(DAILY_PROGRESS_KEY); } catch {}
  const stored = raw ? (() => { try { return JSON.parse(raw); } catch { return null; } })() : null;
  const state = normalizeDailyState(stored, new Date());
  const normalized = JSON.stringify(state);
  if (raw !== normalized) { try { localStorage.setItem(DAILY_PROGRESS_KEY, normalized); } catch { /* Progress remains best-effort when storage is disabled. */ } }
  applyBoardCosmetic(state.activeCosmetic);
  return state;
}
function persistDailyProgress(state) {
  try { localStorage.setItem(DAILY_PROGRESS_KEY, JSON.stringify(state)); } catch { /* Local progression is optional; chess stays playable if storage is unavailable. */ }
  applyBoardCosmetic(state?.activeCosmetic || 'classic');
}
function applyBoardCosmetic(id) {
  if (typeof document === 'undefined') return;
  const known = COSMETICS.some(item => item.id === id) ? id : 'classic';
  document.documentElement.dataset.boardTheme = known;
}
function recordDailyEvent(event) {
  const state = recordMissionEvent(readDailyProgress(), event, new Date());
  persistDailyProgress(state);
  return state;
}
const persistedSocialToken = (() => { try { return localStorage.getItem(SOCIAL_SESSION_KEY) || ''; } catch { return ''; } })();
let socialState = { token: persistedSocialToken, user: persistedSocialToken ? readSocialCache(SOCIAL_USER_KEY) : null, friends: [], incoming: [], outgoing: [], searchResults: [], leaderboard: [], adminOverview: null, adminUsers: [], auditEvents: [], error: '', loading: false };
let appNotifications = (() => { try { return normalizeNotifications(JSON.parse(localStorage.getItem(NOTIFICATIONS_KEY) || '[]')); } catch { return []; } })();
let healthBackendStatus = 'unknown';
function saveSocialSession(token, user) {
  const nextToken = String(token || '').trim();
  socialState.token = nextToken;
  socialState.user = user && typeof user === 'object' ? user : null;
  let saved = true;
  try {
    if (nextToken) localStorage.setItem(SOCIAL_SESSION_KEY, nextToken);
    else localStorage.removeItem(SOCIAL_SESSION_KEY);
    if (socialState.user) localStorage.setItem(SOCIAL_USER_KEY, JSON.stringify(socialState.user));
    else localStorage.removeItem(SOCIAL_USER_KEY);
  } catch (error) {
    saved = false;
    console.warn('[VILA Chess] Account session could not be persisted on this device:', error?.message || error);
  }
  if (!nextToken) {
    socialState.friends = [];
    socialState.incoming = [];
    socialState.outgoing = [];
    socialState.searchResults = [];
    socialState.leaderboard = [];
    socialState.adminOverview = null;
    socialState.adminUsers = [];
    socialState.auditEvents = [];
  }
  syncSocialNav();
  return saved;
}
function persistNotifications() {
  try { localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(appNotifications)); return true; }
  catch (error) { console.warn('[VILA Chess] Notification inbox could not be saved:', error?.message || error); return false; }
}
function syncInboxBadge() {
  const badge = $('#inboxBadge');
  if (!badge) return;
  const count = unreadNotificationCount(appNotifications);
  badge.textContent = count > 99 ? '99+' : String(count);
  badge.hidden = count < 1;
  $('#openInbox')?.setAttribute('aria-label', count ? `Hộp thư, ${count} thông báo chưa đọc` : 'Mở hộp thư');
}
function addAppNotification(payload) {
  const result = addNotification(appNotifications, payload);
  if (!result.added) return result.notification;
  appNotifications = result.items;
  persistNotifications();
  syncInboxBadge();
  return result.notification;
}
function syncSocialNav() {
  const adminTab = $('[data-view="admin"]');
  if (adminTab) adminTab.hidden = socialState.user?.role !== 'admin';
  const user = socialState.user;
  const avatar = $('#accountAvatar');
  const label = $('#accountShortcutLabel');
  const shortcut = $('#accountShortcut');
  if (avatar) avatar.textContent = String((user?.displayName || user?.username || '♙').trim()).slice(0, 1).toUpperCase();
  if (label) label.textContent = user ? String(user.displayName || user.username || 'Tài khoản').slice(0, 14) : 'Tài khoản';
  if (shortcut) {
    shortcut.title = user ? `${user.displayName || user.username} · mở hồ sơ` : 'Đăng nhập hoặc tạo tài khoản';
    shortcut.setAttribute('aria-label', shortcut.title);
  }
  syncInboxBadge();
}
function socialBackendBase() {
  const configured = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  if (configured) return configured;
  if (location.protocol === 'http:' || location.protocol === 'https:') return '';
  throw new Error('Chưa cấu hình URL backend. Mở Cài đặt → Máy chủ cộng đồng, nhập URL HTTPS của server VILA Chess rồi lưu. Đăng nhập Google/GitHub không thể hoạt động nếu chưa có backend thật.');
}
async function socialApi(path, options = {}) {
  const base = socialBackendBase();
  const headers = { ...(options.headers || {}) };
  if (socialState.token) headers.Authorization = `Bearer ${socialState.token}`;
  if (options.body && typeof options.body === 'string') headers['Content-Type'] = 'application/json';
  const response = await fetch(`${base}/api/social${path}`, { ...options, headers, signal: options.signal || AbortSignal.timeout(15000) });
  const type = response.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
  if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
  return data;
}
function captureIncomingFriendNotifications(incoming) {
  if (!Array.isArray(incoming)) return;
  for (const request of incoming) {
    const name = request?.user?.displayName || request?.user?.username;
    if (!request?.id || !name) continue;
    addAppNotification({
      title: 'Lời mời kết bạn mới',
      message: `@${request.user.username || name} muốn kết bạn với bạn. Mở mục Bạn bè để phản hồi.`,
      type: 'info',
      sourceKey: `friend-request:${request.id}`
    });
  }
}
function socialHandleError(error, fallback = 'Không thể kết nối máy chủ cộng đồng.') {
  const message = String(error?.message || error || fallback);
  if (/Phiên đăng nhập hết hạn|phiên đăng nhập|không hợp lệ|HTTP 401|HTTP 403/i.test(message)) saveSocialSession('', null);
  toast(message);
  return message;
}
function adoptSocialCallback() { try { const hash = new URLSearchParams(location.hash.replace(/^#/, '')); const token = hash.get('social_token'); const error = hash.get('social_error'); if (token) { saveSocialSession(token, null); history.replaceState(null, '', location.pathname + location.search); socialApi('/auth/me').then(data => { saveSocialSession(token, data.user); toast('Đăng nhập thành công.'); if (currentView === 'friends' || currentView === 'admin') renderView(); }).catch(socialHandleError); } else if (error) { history.replaceState(null, '', location.pathname + location.search); toast(error); } } catch {} }
let ratedGameSignature = '';
function readRatingProfile() { try { const p = JSON.parse(localStorage.getItem(RATING_KEY) || '{}'); return { elo: Number(p.elo) || 1200, games: Number(p.games) || 0, wins: Number(p.wins) || 0, draws: Number(p.draws) || 0, losses: Number(p.losses) || 0, lastChange: Number(p.lastChange) || 0 }; } catch { return { elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, lastChange: 0 }; } }
function readRatingHistory() { try { const h = JSON.parse(localStorage.getItem(RATING_HISTORY_KEY) || '[]'); return Array.isArray(h) ? h.slice(-100) : []; } catch { return []; } }
function maybeRecordRatedGame() {
  if (!gameStarted || !['stockfish', 'ai'].includes(mode) || (!game.isGameOver() && !clockFlagged && !manualGameResult)) return;
  const result = getGameResult(); if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const signature = `${mode}|${gameStartFen}|${game.pgn()}|${result.token}|${manualGameResult?.reason || ''}|${clockFlagged || ''}`;
  if (!signature || signature === ratedGameSignature) return;
  const history = readRatingHistory(); if (history.some(item => item.signature === signature)) { ratedGameSignature = signature; return; }
  const humanScore = result.token === '1/2-1/2' ? 0.5 : ((result.token === '1-0') === (humanColor === 'w') ? 1 : 0);
  const opponentElo = settings.botStrengthMode === 'elo' ? Number(settings.botElo || 1800) : 2200;
  const before = readRatingProfile(); const after = applyEloResult(before, opponentElo, humanScore);
  try { localStorage.setItem(RATING_KEY, JSON.stringify(after)); history.push({ signature, date: new Date().toISOString(), result: result.token, title: result.title, opponent: mode === 'ai' ? `AI API · ${settings.model || 'AI'}` : `Stockfish · ${opponentElo} Elo ước lượng`, opponentElo, score: humanScore, change: after.lastChange, elo: after.elo, plies: game.history().length }); localStorage.setItem(RATING_HISTORY_KEY, JSON.stringify(history.slice(-100))); ratedGameSignature = signature; recordDailyEvent('complete_game'); recordDailyEvent(humanScore === 1 ? 'win_game' : humanScore === 0.5 ? 'draw_game' : 'lose_game'); } catch { /* Keep the game playable when local storage is disabled. */ }
}
function safeSessionGet(key) {
  try { return sessionStorage.getItem(key) || ''; } catch { return ''; }
}
function safeSessionSet(key, value) {
  try { sessionStorage.setItem(key, String(value ?? '')); return true; } catch { return false; }
}
function safeSessionRemove(key) {
  try { sessionStorage.removeItem(key); return true; } catch { return false; }
}
function getLichessToken() {
  return String($('#lichessToken')?.value?.trim() || activeLichessToken || safeSessionGet(lichessTokenKey) || '').trim();
}

let settings = loadSettings();
let currentView = 'home';
let game = new Chess();
let gameStartFen = game.fen();
let reviewStatus = '';
let gameStarted = false; // New launches always wait for explicit Start.
let manualGameResult = null; // Resign/agree-draw result; does not falsify chess.js move history.
let reviewSession = null;
let completedReviewRows = [];
let reviewReplayState = null;
let historyRestoreSignature = '';
let dragState = null;
let dragGhost = null;
let dragMoveFrame = 0;
let dragLatestPoint = null;
let boardSquareMap = new Map();
let suppressSquareClick = null;
let mode = 'stockfish'; // stockfish, ai, local
let humanColor = 'w';
let orientation = 'w';
let selected = null;
let selectedTargets = [];
let botThinking = false;
let currentOpening = null;
let openingPageLimit = 48;
let openingCatalogLoadPromise = null;
let lastHintMove = null;
let boardAnnotations = [];
let annotationTool = null; // null = normal chess movement; 'arrow'/'circle' = touch drawing mode.
let annotationColor = 'green';
let annotationCollapsed = true;
let annotationPointer = null;
let annotationWidgetRaf = 0;
let annotationWidgetPosition = readSocialCache('vila.chess.annotation-widget-position.v1', null);
let randomBotEloEnabled = false;
let experienceLevel = readSocialCache('vila.chess.experience.v1', '');
if (!['beginner', 'experienced'].includes(experienceLevel)) experienceLevel = '';
let selectedRankedTimeControl = readSocialCache('vila.chess.ranked-time-control.v1', '3+2');
if (!RANKED_CLOCK_PRESETS.some(item => item.value === selectedRankedTimeControl)) selectedRankedTimeControl = '3+2';
const recentOpeningChoices = new Map();
let pendingCoachAnalysis = null;
let loadedApiModels = [];
let loadedModelContext = ''; 
let lastMove = null;
let engineWorker = null;
let engineInitTimeout = null;
let engineInitFallbacksTried = new Set();
let engineReady = false;
let engineUciInitialized = false;
let engineFailed = false;
let boardResizeObserver = null;
let boardResizeRaf = 0;
let engineQueue = [];
let engineSearchActive = false;
let pendingEngineRequest = null;
let pendingHintRequest = null;
let apiMoveAbortController = null;
let mainEngineTimer = null;
let mainBotKickTimer = null;
let gameEpoch = 0;
let mainEngineSearchEpoch = -1;
let mainEngineSearchFen = '';
let queuedMainEngineMove = false;
let clockState = { enabled: false, running: false, remaining: { w: 0, b: 0 }, incrementMs: 0, lastTickAt: 0 };
let clockFlagged = null;
let clockInterval = null;
let analysisActive = false;
let analysisVisible = false;
let analysisFen = '';
let analysisEpoch = -1;
let analysisVariants = [];
let analysisTimeout = null;
let engineStopTimeout = null;
let engineStopPending = false;
let analysisLastPaintAt = 0;
let arenaGame = new Chess();
let arenaRunning = false;
let arenaStopRequested = false;
let arenaAbortController = null;
let arenaLastMove = null;
let arenaPgnHeaders = {};
let arenaLastPgnResult = '*';
let arenaPgnArchive = [];
let arenaLastResult = '';
let arenaCurrentPlayers = { w: null, b: null };
let arenaGameCounter = 0;
let arenaLastNote = '';
let arenaTournamentSummary = '';
let arenaSelectedLeague = new Set(['stockfish', 'current']);
let arenaFallbackMoves = new Map();
let activeOnlineGame = null;
let activeLichessUsername = safeSessionGet('tubor.chess.lichessUsername');
let activeLichessToken = safeSessionGet(lichessTokenKey);
let onlineStreamController = null;
let lastExplorerData = null;
let explorerRequestId = 0;
let chatMessages = [];
let coachRequestActive = false;
let coachRequestId = 0;
let coachAbortController = null;
let toastTimer = null;

function loadSettings() {
  try {
    return normalizeSettings(JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'));
  } catch {
    return normalizeSettings(DEFAULTS);
  }
}
function saveSettings() {
  try {
    const normalized = normalizeSettings(settings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    settings = normalized;
    return true;
  } catch (error) {
    console.warn('[Chess Bot] Settings could not be stored:', error);
    toast('Không lưu được cài đặt trên thiết bị này. Hãy kiểm tra dung lượng hoặc quyền lưu trữ.');
    return false;
  }
}
function apiUrl(path) {
  const base = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  return `${base}${path}`;
}
function isSafeHttpEndpoint(value) {
  try {
    const parsed = new URL(String(value || '').trim());
    return ['http:', 'https:'].includes(parsed.protocol) && Boolean(parsed.hostname) &&
      !parsed.username && !parsed.password && !parsed.search && !parsed.hash;
  } catch {
    return false;
  }
}
function safeLichessUrl(value, gameId) {
  const cleanId = String(gameId || '').trim();
  const fallback = cleanId ? `https://lichess.org/${encodeURIComponent(cleanId)}` : 'https://lichess.org/';
  try {
    const parsed = new URL(String(value || fallback));
    return parsed.protocol === 'https:' && parsed.hostname === 'lichess.org' && !parsed.username && !parsed.password && !parsed.port ? parsed.href : fallback;
  } catch {
    return fallback;
  }
}
async function apiFetch(path, options = {}) {
  // Bound ordinary API requests so a broken backend/network cannot leave chat,
  // settings or arena controls in a permanent loading state.
  const controller = new AbortController();
  const callerSignal = options.signal;
  let timedOut = false;
  const abortFromCaller = () => controller.abort();
  if (callerSignal?.aborted) controller.abort();
  else callerSignal?.addEventListener('abort', abortFromCaller, { once: true });
  const timeoutMs = Math.max(1000, Math.min(90_000, Number(options.timeoutMs) || 90_000));
  const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
  try {
    const { signal: _callerSignal, timeoutMs: _timeoutMs, ...fetchOptions } = options;
    const response = await fetch(apiUrl(path), {
      ...fetchOptions,
      signal: controller.signal,
      headers: {
        ...(options.headers || {}),
        ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}),
        ...(options.body && typeof options.body === 'string' ? { 'Content-Type': 'application/json' } : {})
      }
    });
    const type = response.headers.get('content-type') || '';
    const data = type.includes('application/json') ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
    if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (timedOut) throw new Error(`Yêu cầu quá thời gian chờ ${Math.round(timeoutMs / 1000)} giây. Hãy kiểm tra mạng/model rồi thử lại.`);
    throw error;
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener('abort', abortFromCaller);
  }
}

function aiRequestConfigured() {
  const endpoint = String(settings.endpoint || '').trim();
  const needsKey = settings.aiMode === 'gemini' || settings.aiMode === 'anthropic' || !isLocalNoKeyEndpoint(endpoint);
  return Boolean(endpoint && String(settings.model || '').trim() && (!needsKey || String(settings.apiKey || '').trim()));
}
function providerNeedsKey(mode, endpoint) {
  return mode === 'gemini' || mode === 'anthropic' || !isLocalNoKeyEndpoint(endpoint);
}
function friendlyApiError(message) {
  const text = String(message || 'Lỗi không xác định.').trim();
  if (/API key.*(không hợp lệ|invalid|thiếu)|invalid api key|invalid_api_key|api_key_invalid|unauthorized|\b401\b/i.test(text)) return 'API key sai, hết hạn hoặc không thuộc endpoint đang chọn. Kiểm tra key ở nhà cung cấp và lưu lại; không đăng key lên GitHub.';
  if (/\b403\b|forbidden|permission|billing|not allowed/i.test(text)) return 'Nhà cung cấp từ chối quyền truy cập. Kiểm tra quyền API, billing, khu vực và quyền sử dụng model.';
  if (/\b404\b|model.*not found|unknown model|endpoint.*not found/i.test(text)) return 'Không tìm thấy model hoặc endpoint. Chọn đúng model ID và Base URL của cùng nhà cung cấp.';
  if (/\b429\b|quota|rate.?limit|resource exhausted|too many requests/i.test(text)) return 'API đã vượt quota hoặc giới hạn tốc độ. Chờ rồi thử lại, hoặc chọn model Free Tier khác.';
  if (/quá thời gian|timeout|timed out|aborterror|econn|fetch failed|network/i.test(text)) return 'Yêu cầu API quá chậm hoặc mất kết nối. Kiểm tra mạng, endpoint và backend rồi thử lại.';
  return text.slice(0, 450);
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function makeMessageId() {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch { /* Some embedded WebViews restrict crypto APIs outside secure contexts. */ }
  return `message-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function toast(message, type = '') {
  const element = $('#toast');
  if (!element) return;
  element.textContent = message;
  element.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.className = 'toast'; }, 3300);
}
function setHintSuggestion(move, source = 'Stockfish') {
  if (!move) return;
  lastHintMove = { fen: game.fen(), from: move.from, to: move.to, promotion: move.promotion || null, san: move.san, source };
  const output = $('#hintSuggestionText');
  if (output) output.textContent = `${source}: ${move.san} · ${move.from} → ${move.to}${move.promotion ? ` · phong cấp ${move.promotion.toUpperCase()}` : ''}`;
  $('#speakHint')?.removeAttribute('disabled');
  $('#useHint')?.removeAttribute('disabled');
  renderHintArrow();
}
function speakTextVietnamese(text) {
  const clean = String(text || '').trim();
  if (!clean) return;
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    toast('Thiết bị/WebView chưa hỗ trợ đọc chỉ dẫn bằng giọng nói.'); return;
  }
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = 'vi-VN'; utterance.rate = 0.94; utterance.pitch = 1;
    const voice = window.speechSynthesis.getVoices().find(item => /^vi(-|_)/i.test(item.lang));
    if (voice) utterance.voice = voice;
    utterance.onerror = () => toast('Không thể phát giọng đọc trên thiết bị này.');
    window.speechSynthesis.speak(utterance);
  } catch { toast('Không thể khởi chạy giọng đọc trên WebView này.'); }
}
function speakCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Hãy lấy gợi ý mới cho thế cờ hiện tại trước.'); return; }
  speakTextVietnamese(`Gợi ý ${lastHintMove.source}. Đi nước ${lastHintMove.san}. Di chuyển quân từ ô ${lastHintMove.from} đến ô ${lastHintMove.to}.`);
}
function applyCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Gợi ý đã cũ. Hãy tính lại ở thế cờ hiện tại.'); return; }
  if (arenaRunning || game.isGameOver() || botThinking || clockFlagged) { toast('Chưa thể áp dụng gợi ý trong trạng thái hiện tại.'); return; }
  if (mode !== 'local' && game.turn() !== humanColor) { toast('Chỉ áp dụng gợi ý khi đến lượt của bạn.'); return; }
  const move = game.moves({ verbose: true }).find(candidate => candidate.from === lastHintMove.from && candidate.to === lastHintMove.to && (candidate.promotion || null) === (lastHintMove.promotion || null));
  if (!move) { toast('Nước gợi ý không còn hợp lệ ở vị trí hiện tại.'); return; }
  playMove(move.from, move.to, move.promotion);
}
function clockPlayerName(color) {
  if (mode === 'lichess') return color === humanColor ? 'Bạn' : 'Đối thủ';
  if (mode === 'local') return color === 'w' ? 'Trắng' : 'Đen';
  return color === humanColor ? 'Bạn' : (mode === 'ai' ? 'AI qua API' : 'Stockfish');
}
function resetClock(preset = settings.clockPreset) {
  const parsed = parseClockPreset(preset);
  const enabled = parsed.enabled && mode !== 'lichess';
  clockFlagged = null;
  clockState = {
    enabled,
    running: enabled && gameStarted && !game.isGameOver() && !manualGameResult,
    remaining: { w: parsed.baseMs, b: parsed.baseMs },
    incrementMs: parsed.incrementMs,
    lastTickAt: typeof performance !== 'undefined' ? performance.now() : Date.now()
  };
  renderClockDisplay();
}
function stopClock() {
  clockState.running = false;
  renderClockDisplay();
}
function renderClockDisplay() {
  const white = $('#clockWhite');
  const black = $('#clockBlack');
  if (!white || !black) return;
  for (const [color, element] of [['w', white], ['b', black]]) {
    const value = clockState.enabled ? formatClockTime(clockState.remaining[color], true) : (mode === 'lichess' ? 'Lichess' : '∞');
    element.textContent = value;
    element.classList.toggle('is-active', clockState.enabled && clockState.running && game.turn() === color && !clockFlagged);
    element.classList.toggle('is-flagged', clockFlagged === color);
    element.setAttribute('aria-label', `${clockPlayerName(color)}: ${value}`);
  }
  const whiteName = $('#clockWhiteName');
  const blackName = $('#clockBlackName');
  if (whiteName) whiteName.textContent = clockPlayerName('w');
  if (blackName) blackName.textContent = clockPlayerName('b');
  const hint = $('#clockHint');
  if (hint) hint.textContent = clockFlagged ? `${clockPlayerName(clockFlagged)} đã hết giờ` : clockState.enabled ? `Thời gian + ${Math.round(clockState.incrementMs / 1000)} giây cộng mỗi nước` : (mode === 'lichess' ? 'Đồng hồ do Lichess quản lý' : 'Đồng hồ không giới hạn');
}
function tickClock() {
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (arenaRunning) { clockState.lastTickAt = now; return; }
  if (!clockState.enabled || !clockState.running || clockFlagged || mode === 'lichess' || game.isGameOver()) return;
  const elapsed = Math.max(0, now - clockState.lastTickAt);
  clockState.lastTickAt = now;
  const side = game.turn();
  clockState.remaining[side] = Math.max(0, clockState.remaining[side] - elapsed);
  if (clockState.remaining[side] <= 0) {
    clockFlagged = side;
    clockState.running = false;
    botThinking = false;
    cancelScheduledBotMove();
    cancelPendingHint();
    stopAnalysis(true);
    cancelMainEngineSearch();
    if (currentView === 'play') renderView();
    toast(`${clockPlayerName(side)} hết giờ. Ván cờ kết thúc.`, 'success');
    return;
  }
  renderClockDisplay();
}
function creditClockForMove(mover) {
  if (!clockState.enabled || clockFlagged) return;
  clockState.remaining[mover] += clockState.incrementMs;
  clockState.lastTickAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
  renderClockDisplay();
}
function requestEngineStop() {
  if (engineStopPending) return;
  // Do not wait for a terminal line when the previous search has already ended.
  if (!engineWorker || engineFailed || !engineSearchActive) { engineSearchActive = false; return; }
  // UCI does not tag `bestmove` with a request ID. Lock the shared worker until
  // the cancelled job emits its terminal line; all new searches stay queued.
  engineStopPending = true;
  engineSearchActive = true;
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 1');
  } catch {
    retireStockfishWorker('Không thể gửi lệnh dừng Stockfish an toàn.');
    return;
  }
  if (engineStopTimeout) clearTimeout(engineStopTimeout);
  engineStopTimeout = setTimeout(() => {
    if (!engineStopPending) return;
    const resumeBot = queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && !clockFlagged;
    queuedMainEngineMove = false;
    engineStopTimeout = null;
    retireStockfishWorker('Stockfish không xác nhận dừng tác vụ đúng hạn.');
    if (resumeBot) scheduleBotMove(0);
  }, 2500);
}
function stopAnalysis(clearResults = true) {
  const wasActive = analysisActive;
  analysisActive = false;
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  if (wasActive) requestEngineStop();
  if (clearResults) analysisVisible = false;
  analysisFen = '';
  analysisEpoch = -1;
  if (clearResults) analysisVariants = [];
  renderAnalysisPanel();
}
function uciPvToSan(fen, pv) {
  const clone = new Chess(fen);
  const san = [];
  for (const uci of pv) {
    try {
      const move = clone.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!move) break;
      san.push(move.san);
    } catch { break; }
  }
  return san;
}
function renderAnalysisPanel() {
  const panel = $('#analysisPanel');
  const lines = $('#analysisLines');
  const button = $('#analyzePosition');
  if (!panel || !lines) return;
  panel.hidden = !(analysisVisible || analysisActive || analysisVariants.length);
  if (button) {
    button.disabled = engineStopPending;
    button.textContent = analysisActive ? '■ Dừng phân tích' : engineStopPending ? 'Đang dừng…' : '♙ Phân tích 3 biến';
    button.setAttribute('aria-busy', String(analysisActive || engineStopPending));
  }
  if (!analysisVariants.length) {
    const emptyText = analysisActive
      ? 'Stockfish đang phân tích nhiều phương án…'
      : engineStopPending
        ? 'Đang yêu cầu Stockfish kết thúc lượt phân tích an toàn…'
        : analysisVisible
          ? 'Chưa nhận được biến thể hợp lệ từ Stockfish. Kiểm tra trạng thái engine rồi thử phân tích lại.'
          : 'Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.';
    lines.innerHTML = `<div class="analysis-empty">${emptyText}</div>`;
    renderHintArrow();
    return;
  }
  const expectedFen = analysisVariants[0]?.fen || game.fen();
  lines.innerHTML = analysisVariants.sort((a, b) => a.multipv - b.multipv).map(variation => {
    const san = uciPvToSan(expectedFen, variation.pv).slice(0, 8).join(' ');
    return `<div class="analysis-line"><b>${variation.multipv}</b><strong>${esc(formatUciScore(variation))}</strong><span>Độ sâu ${variation.depth}</span><small>${esc(san || 'Đang tìm biến…')}</small></div>`;
  }).join('');
  renderHintArrow();
}
function receiveAnalysisInfo(line) {
  if (!analysisActive) return;
  if (!isCurrentAnalysisSession({ active: analysisActive, sessionFen: analysisFen, currentFen: game.fen(), sessionEpoch: analysisEpoch, currentEpoch: gameEpoch })) {
    stopAnalysis(true);
    return;
  }
  const parsed = parseUciInfoLine(line);
  if (!parsed) return;
  analysisVariants = mergeAnalysisVariation(analysisVariants, parsed, analysisFen);
  const now = Date.now();
  if (now - analysisLastPaintAt >= 180) {
    analysisLastPaintAt = now;
    renderAnalysisPanel();
  }
}
function toggleAnalysis() {
  if (!gameStarted) { toast('Bắt đầu ván trước khi phân tích.'); return; }
  if (analysisActive) { stopAnalysis(false); toast('Đã dừng phân tích.'); return; }
  if (engineStopPending) { toast('Stockfish đang kết thúc lượt phân tích trước; thử lại sau giây lát.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi phân tích bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged) { toast('Ván cờ đã kết thúc; hãy bắt đầu ván mới để phân tích tiếp.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng. Kiểm tra engine rồi thử lại.'); return; }
  if (botThinking || engineSearchActive || pendingEngineRequest || pendingHintRequest) { toast('Đợi Stockfish hoàn tất nước đi hoặc gợi ý trước khi phân tích.'); return; }
  analysisActive = true;
  analysisVisible = true;
  analysisFen = game.fen();
  analysisEpoch = gameEpoch;
  analysisVariants = [];
  analysisLastPaintAt = 0;
  engineSearchActive = true;
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  renderAnalysisPanel();
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 3');
    engineWorker.postMessage(`position fen ${analysisFen}`);
    const budget = Math.max(1000, Math.min(8000, Number(settings.analysisMoveTimeMs) || 2600));
    engineWorker.postMessage(`go movetime ${budget}`);
    analysisTimeout = setTimeout(() => {
      if (!analysisActive) return;
      stopAnalysis(false);
      retireStockfishWorker('Stockfish không hoàn tất phân tích đúng hạn.');
      reviewStatus = 'Đã dừng phân tích vì Stockfish quá thời gian.';
      updateReviewPanel();
      toast('Stockfish quá thời gian phân tích; chạm trạng thái engine ở đầu trang để thử tải lại.');
    }, budget + 3500);
  } catch (error) {
    stopAnalysis(true);
    toast(`Không thể khởi chạy phân tích: ${error.message || error}`);
  }
}
function analyzeLocallyForCoach() {
  return new Promise((resolve, reject) => {
    if (!engineWorker || !engineReady || engineFailed) return reject(new Error('Stockfish chưa sẵn sàng. Hãy chờ trạng thái engine sẵn sàng rồi thử lại.'));
    if (botThinking || engineStopPending || engineSearchActive || pendingEngineRequest || pendingHintRequest || analysisActive || pendingCoachAnalysis) {
      return reject(new Error('Engine đang bận. Đợi nước đi hoặc phân tích hiện tại kết thúc rồi thử lại.'));
    }
    const request = { fen: game.fen(), epoch: gameEpoch, variants: new Map(), resolve, reject, timeout: null };
    pendingCoachAnalysis = request;
    engineSearchActive = true;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    const budget = Math.max(1200, Math.min(5000, Number(settings.analysisMoveTimeMs) || 2600));
    request.timeout = setTimeout(() => {
      if (pendingCoachAnalysis !== request) return;
      pendingCoachAnalysis = null;
      engineSearchActive = false;
      retireStockfishWorker('Stockfish quá thời gian phân tích.');
      reject(new Error('Stockfish quá thời gian phân tích. Engine đã dừng để bỏ qua kết quả cũ; hãy chạm trạng thái engine để thử lại.'));
    }, budget + 3000);
    try {
      engineWorker.postMessage('stop');
      engineWorker.postMessage('setoption name MultiPV value 3');
      engineWorker.postMessage(`position fen ${request.fen}`);
      engineWorker.postMessage(`go movetime ${budget}`);
    } catch (error) {
      clearTimeout(request.timeout); pendingCoachAnalysis = null; engineSearchActive = false;
      try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
      reject(error);
    }
  });
}
function receiveCoachAnalysisInfo(line) {
  const request = pendingCoachAnalysis;
  if (!request || request.epoch !== gameEpoch || request.fen !== game.fen()) return;
  const parsed = parseUciInfoLine(line);
  if (!parsed || !parsed.pv?.length) return;
  const old = request.variants.get(parsed.multipv);
  if (!old || parsed.depth >= old.depth) request.variants.set(parsed.multipv, { ...parsed, fen: request.fen });
}
function ensureClockTicker() {
  if (clockInterval) return;
  clockInterval = setInterval(tickClock, 100);
}
function preferredHashMb() {
  const memory = Number(navigator?.deviceMemory || 0);
  // Unknown WebView memory should take the safer allocation on low-RAM phones.
  return memory >= 4 ? 32 : 16;
}
function cancelScheduledBotMove() {
  if (mainBotKickTimer) {
    clearTimeout(mainBotKickTimer);
    mainBotKickTimer = null;
  }
}
function cancelApiMoveRequest() {
  if (!apiMoveAbortController) return;
  const controller = apiMoveAbortController;
  apiMoveAbortController = null;
  try { controller.abort(); } catch {}
}
function cancelMainEngineWatchdog() {
  if (mainEngineTimer) {
    clearTimeout(mainEngineTimer);
    mainEngineTimer = null;
  }
}
function scheduleBotMove(delay = 220) {
  cancelScheduledBotMove();
  const expectedEpoch = gameEpoch;
  const expectedFen = game.fen();
  const expectedMode = mode;
  mainBotKickTimer = setTimeout(() => {
    mainBotKickTimer = null;
    if (expectedEpoch !== gameEpoch || expectedFen !== game.fen() || expectedMode !== mode ||
        !botThinking || game.isGameOver() || game.turn() === humanColor) return;
    if (expectedMode === 'stockfish') askStockfishMove();
    else if (expectedMode === 'ai') askAiMove();
  }, Math.max(0, Math.min(5000, Number(delay) || 0)));
}
function cancelPendingHint() {
  if (!pendingHintRequest) return false;
  clearTimeout(pendingHintRequest.timeout);
  pendingHintRequest = null;
  if (engineSearchActive && !pendingEngineRequest) requestEngineStop();
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  return true;
}
function cancelMainEngineSearch() {
  cancelMainEngineWatchdog();
  // A new game may start while the current worker is cancelling; keep it locked
  // until the terminal line arrives, then resume only a still-current bot turn.
  if (engineStopPending) {
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    queuedMainEngineMove = false;
    engineSearchActive = true;
    return;
  }
  if (engineSearchActive && !pendingEngineRequest) requestEngineStop();
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
}
function setView(view) {
  if (currentView === 'ranked' && view !== 'ranked') void quitRankedMatch(true);
  if (view === 'openings') recordDailyEvent('visit_openings');
  if (view === 'coach') recordDailyEvent('visit_coach');
  if (view === 'history') recordDailyEvent('open_history');
  if (view === 'puzzles') recordDailyEvent('visit_puzzles');
  currentView = view;
  $$('.tab').forEach(tab => tab.classList.toggle('active', tab.dataset.view === view));
  $('#mainMenu')?.classList.remove('menu-open');
  $('#openMenu')?.setAttribute('aria-expanded', 'false');
  renderView();
}
function pieceGlyph(piece) {
  // Balanced, original Staunton-style silhouettes designed for small Android screens.
  // Keep every piece as a local SVG: crisp at any DPI and independent of symbol fonts.
  const shapes = {
    k: {
      body: '<path d="M28 7h8v6h5v5h-5v6h-8v-6h-5v-5h5z"/><path d="M23 27h18l3 7 2 11 5 5v3H13v-3l5-5 2-11z"/><path d="M16 51h32l3 5H13z"/>',
      detail: '<path d="M23 31h18M21 44h22M19 49h26M29 29l-3 15m9-15 3 15"/>'
    },
    q: {
      body: '<path d="M17 20l10 8 5-13 5 13 10-8-4 16H21z"/><circle cx="17" cy="17" r="3.2"/><circle cx="32" cy="11.5" r="3.2"/><circle cx="47" cy="17" r="3.2"/><path d="M22 38h20l3 7 4 5v3H15v-3l4-5z"/><path d="M16 51h32l3 5H13z"/>',
      detail: '<path d="M22 41h20M20 48h24M23 32h18"/>'
    },
    r: {
      body: '<path d="M18 14h7v6h5v-6h5v6h5v-6h6v15H18z"/><path d="M21 29h22l-2 16 5 5v3H18v-3l5-5z"/><path d="M17 51h30l4 5H13z"/>',
      detail: '<path d="M22 33h20M23 45h18M19 49h26"/>'
    },
    b: {
      body: '<path d="M32 12c-7 5-11 12-8 20l4 7h8l4-7c3-8-1-15-8-20z"/><path d="M25 38h14l3 7 5 5v3H17v-3l5-5z"/><path d="M17 51h30l4 5H13z"/>',
      detail: '<path d="M29 19l6 9-5 4 5 8M25 42h14M22 49h20"/>'
    },
    n: {
      body: '<path d="M18 49l4-8-2-8 6-5-1-8 7-7 4 7 8 3 5 8-6 7-1 11z"/><path d="M25 41l-3 4-1 5h25l-4-5-1-5"/><path d="M17 51h30l4 5H13z"/>',
      detail: '<path d="M29 22l6 6 7 1-4 4M27 37l-3 7h17"/><circle cx="35" cy="23" r="1.5" fill="var(--piece-outline, #18202b)" stroke="none"/>'
    },
    p: {
      body: '<circle cx="32" cy="20" r="8"/><path d="M27 29h10l2 8 4 7 5 6v3H16v-3l5-6 4-7z"/><path d="M17 51h30l4 5H13z"/>',
      detail: '<path d="M27 34h10M25 44h14M19 49h26"/>'
    }
  };
  const shape = shapes[piece?.type];
  if (!shape || !['w', 'b'].includes(piece?.color)) return '';
  return `<svg class="piece-svg piece-svg-${piece.type}" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><g class="piece-silhouette" fill="currentColor" stroke="var(--piece-outline, #18202b)" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round">${shape.body}</g><g class="piece-detail" fill="none" stroke="var(--piece-outline, #18202b)" stroke-width="1.15" stroke-linejoin="round" stroke-linecap="round">${shape.detail}</g></svg>`;
}
function squareColor(square) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 1 ? 'dark' : 'light';
}
function syncBoardLayout() {
  const board = $('#board');
  const frame = board?.closest('.board-frame');
  const column = board?.closest('.board-column');
  if (!board || !frame || !column) return;

  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: column.getBoundingClientRect().width,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';

  // Derive piece scale from the actual inner board width rather than vw/DPI
  // heuristics; this survives Android WebView inset and split-screen changes.
  const boardWidth = board.getBoundingClientRect().width;
  const squareSize = calculateChessSquareSize(boardWidth);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function syncArenaBoardLayout() {
  const board = $('#arenaBoard');
  const frame = board?.closest('.arena-board-frame');
  const container = frame?.parentElement;
  if (!board || !frame || !container) return;
  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: container.clientWidth,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';
  const squareSize = calculateChessSquareSize(board.getBoundingClientRect().width);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function scheduleBoardLayoutSync() {
  if (boardResizeRaf) cancelAnimationFrame(boardResizeRaf);
  boardResizeRaf = requestAnimationFrame(() => { boardResizeRaf = 0; syncBoardLayout(); syncArenaBoardLayout(); });
}
function watchBoardLayout() {
  boardResizeObserver?.disconnect();
  boardResizeObserver = null;
  const column = $('.board-column');
  if (column && typeof ResizeObserver !== 'undefined') {
    boardResizeObserver = new ResizeObserver(scheduleBoardLayoutSync);
    boardResizeObserver.observe(column);
  }
  scheduleBoardLayoutSync();
}

function squareToOverlayPoint(square) {
  if (!/^[a-h][1-8]$/.test(String(square || ''))) return null;
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const x = files.indexOf(square[0]); const y = ranks.indexOf(Number(square[1]));
  return x < 0 || y < 0 ? null : { x: x + .5, y: y + .5 };
}
function renderHintArrow() {
  const svg = $('#boardArrows');
  const hintGroup = $('#hintArrowLine');
  const manualGroup = $('#manualAnnotationLines');
  if (!svg || !hintGroup || !manualGroup) return;
  let move = null;
  if (lastHintMove && lastHintMove.fen === game.fen()) move = lastHintMove;
  else if (analysisVariants.length && analysisVariants[0]?.fen === game.fen() && analysisVariants[0]?.pv?.length) {
    const uci = analysisVariants[0].pv[0];
    if (uci && /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) move = { from: uci.slice(0, 2), to: uci.slice(2, 4), source: 'analysis' };
  }
  const a = move ? squareToOverlayPoint(move.from) : null;
  const b = move ? squareToOverlayPoint(move.to) : null;
  hintGroup.innerHTML = a && b
    ? `<line class="hint-arrow-line ${move.source === 'analysis' ? 'analysis-arrow' : ''}" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" marker-end="url(#hintArrowHead)"/>`
    : '';
  const items = boardAnnotations.slice(-48).map(mark => {
    const from = squareToOverlayPoint(mark.from);
    const to = squareToOverlayPoint(mark.to || mark.from);
    if (!from || !to) return '';
    const cls = `manual-${mark.type} manual-${mark.type}-${mark.color || 'green'}`;
    if (mark.type === 'circle') return `<circle class="${cls}" cx="${to.x}" cy="${to.y}" r=".36"/>`;
    if (mark.from === mark.to) return `<circle class="${cls}" cx="${to.x}" cy="${to.y}" r=".36"/>`;
    const marker = `manualArrowHead${({ green: 'Green', red: 'Red', yellow: 'Yellow' })[mark.color] || 'Green'}`;
    return `<line class="${cls}" x1="${from.x}" y1="${from.y}" x2="${to.x}" y2="${to.y}" marker-end="url(#${marker})"/>`;
  }).join('');
  manualGroup.innerHTML = items;
  svg.hidden = !(a && b) && boardAnnotations.length === 0;
}
function canAnnotateBoard() {
  return Boolean(gameStarted && ['stockfish', 'ai'].includes(mode) && !arenaRunning && !game.isGameOver() && !clockFlagged && !manualGameResult);
}
function syncAnnotationWidget() {
  const widget = $('#boardAnnotationWidget');
  if (!widget) return;
  const allowed = canAnnotateBoard();
  widget.hidden = !allowed;
  widget.classList.toggle('is-collapsed', annotationCollapsed);
  const tools = $('#boardAnnotationTools');
  if (tools) tools.hidden = annotationCollapsed;
  const toggle = $('#annotationWidgetToggle');
  if (toggle) {
    toggle.setAttribute('aria-expanded', String(!annotationCollapsed));
    toggle.setAttribute('aria-label', annotationCollapsed ? 'Mở công cụ vẽ phân tích' : 'Thu gọn công cụ vẽ phân tích');
  }
  const colorButton = $('#annotationColorCycle', widget);
  if (colorButton) {
    colorButton.classList.remove('color-green', 'color-red', 'color-yellow');
    colorButton.classList.add(`color-${annotationColor}`);
    const labels = { green: 'xanh lá', red: 'đỏ', yellow: 'vàng' };
    colorButton.setAttribute('aria-label', `Màu nét: ${labels[annotationColor] || labels.green}`);
    colorButton.title = `Đổi màu nét (hiện tại: ${labels[annotationColor] || labels.green})`;
  }
  $$('[data-annotation-tool]', widget).forEach(button => {
    const active = button.dataset.annotationTool === annotationTool;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  if (annotationWidgetPosition && Number.isFinite(annotationWidgetPosition.left) && Number.isFinite(annotationWidgetPosition.top)) {
    widget.style.left = `${annotationWidgetPosition.left}px`;
    widget.style.top = `${annotationWidgetPosition.top}px`;
    widget.style.right = 'auto';
  }
}
function squareAtBoardPoint(clientX, clientY, rect) {
  if (!rect?.width || !rect?.height || clientX < rect.left || clientY < rect.top || clientX >= rect.right || clientY >= rect.bottom) return '';
  const col = Math.max(0, Math.min(7, Math.floor((clientX - rect.left) / rect.width * 8)));
  const row = Math.max(0, Math.min(7, Math.floor((clientY - rect.top) / rect.height * 8)));
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  return `${files[col]}${ranks[row]}`;
}
function finishAnnotationPointer(event, board, cancelled = false) {
  const state = annotationPointer;
  if (!state || state.pointerId !== event.pointerId) return false;
  annotationPointer = null;
  if (!cancelled && canAnnotateBoard() && state.epoch === gameEpoch && state.fen === game.fen()) {
    const to = squareAtBoardPoint(event.clientX, event.clientY, state.rect) || state.from;
    if (annotationTool === 'arrow' && to !== state.from) boardAnnotations.push({ type: 'arrow', color: annotationColor, from: state.from, to });
    else if (annotationTool === 'circle') boardAnnotations.push({ type: 'circle', color: annotationColor, from: to, to });
    boardAnnotations = boardAnnotations.slice(-48);
  }
  try { board.releasePointerCapture(event.pointerId); } catch {}
  event.preventDefault?.();
  renderHintArrow();
  return true;
}
function wireAnnotationWidget() {
  const widget = $('#boardAnnotationWidget');
  if (!widget || widget.dataset.wired === 'true') return;
  widget.dataset.wired = 'true';
  syncAnnotationWidget();
  $('#annotationWidgetToggle', widget)?.addEventListener('click', () => {
    annotationCollapsed = !annotationCollapsed;
    syncAnnotationWidget();
  });
  $$('[data-annotation-tool]', widget).forEach(button => button.addEventListener('click', () => {
    const requested = button.dataset.annotationTool;
    annotationTool = annotationTool === requested ? null : requested;
    syncAnnotationWidget();
    toast(annotationTool ? (annotationTool === 'arrow' ? 'Kéo từ ô xuất phát đến ô đích để vẽ mũi tên. Chạm biểu tượng lần nữa để chơi quân.' : 'Chạm hoặc kéo tới ô cần khoanh. Chạm biểu tượng lần nữa để chơi quân.') : 'Đã tắt chế độ vẽ; bàn cờ nhận nước đi như bình thường.');
  }));
  $('#annotationClear', widget)?.addEventListener('click', () => {
    boardAnnotations = [];
    annotationTool = null;
    renderHintArrow();
    syncAnnotationWidget();
  });
  $('#annotationColorCycle', widget)?.addEventListener('click', () => {
    const colors = ['green', 'red', 'yellow'];
    annotationColor = colors[(colors.indexOf(annotationColor) + 1) % colors.length];
    syncAnnotationWidget();
  });
  const grip = $('#annotationWidgetGrip', widget);
  let moving = null;
  grip?.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    const surface = widget.closest('.board-surface');
    if (!surface) return;
    const surfaceRect = surface.getBoundingClientRect();
    const widgetRect = widget.getBoundingClientRect();
    const left = widgetRect.left - surfaceRect.left;
    const top = widgetRect.top - surfaceRect.top;
    moving = {
      pointerId: event.pointerId, startX: event.clientX, startY: event.clientY,
      left, top, surfaceRect, width: widgetRect.width, height: widgetRect.height,
      deltaX: 0, deltaY: 0
    };
    widget.style.left = `${left}px`;
    widget.style.top = `${top}px`;
    widget.style.right = 'auto';
    widget.style.transform = 'translate3d(0,0,0)';
    widget.classList.add('is-moving');
    try { grip.setPointerCapture(event.pointerId); } catch {}
    event.preventDefault(); event.stopPropagation();
  });
  widget.addEventListener('pointermove', event => {
    if (!moving || moving.pointerId !== event.pointerId) return;
    moving.deltaX = event.clientX - moving.startX;
    moving.deltaY = event.clientY - moving.startY;
    // Coalesce high-frequency touch events and move on the compositor instead of
    // recalculating layout for every pointer event on slower Android WebViews.
    if (!annotationWidgetRaf) annotationWidgetRaf = requestAnimationFrame(() => {
      annotationWidgetRaf = 0;
      const state = moving;
      if (!state) return;
      const maxLeft = Math.max(0, state.surfaceRect.width - state.width);
      const maxTop = Math.max(0, state.surfaceRect.height - state.height);
      const left = Math.max(0, Math.min(maxLeft, state.left + state.deltaX));
      const top = Math.max(0, Math.min(maxTop, state.top + state.deltaY));
      widget.style.transform = `translate3d(${left - state.left}px, ${top - state.top}px, 0)`;
    });
    event.preventDefault();
  }, { passive: false });
  const endMove = event => {
    if (!moving || moving.pointerId !== event.pointerId) return;
    if (annotationWidgetRaf) cancelAnimationFrame(annotationWidgetRaf);
    annotationWidgetRaf = 0;
    const state = moving;
    moving = null;
    const maxLeft = Math.max(0, state.surfaceRect.width - state.width);
    const maxTop = Math.max(0, state.surfaceRect.height - state.height);
    const left = Math.max(0, Math.min(maxLeft, state.left + state.deltaX));
    const top = Math.max(0, Math.min(maxTop, state.top + state.deltaY));
    // Commit the final position once when the gesture ends; no forced layout read.
    widget.style.left = `${left}px`;
    widget.style.top = `${top}px`;
    widget.style.transform = '';
    widget.classList.remove('is-moving');
    annotationWidgetPosition = { left, top };
    try { localStorage.setItem('vila.chess.annotation-widget-position.v1', JSON.stringify(annotationWidgetPosition)); } catch {}
    try { grip.releasePointerCapture(event.pointerId); } catch {}
  };
  widget.addEventListener('pointerup', endMove);
  widget.addEventListener('pointercancel', endMove);
}
function canStartBoardDrag(piece) {
  return Boolean(gameStarted && !manualGameResult && piece && !arenaRunning && !game.isGameOver() && !clockFlagged && !botThinking &&
    (mode === 'local' ? piece.color === game.turn() : game.turn() === humanColor && piece.color === humanColor) && piece.color === game.turn());
}
function clearDragGhost() {
  if (dragMoveFrame) cancelAnimationFrame(dragMoveFrame);
  dragMoveFrame = 0;
  dragLatestPoint = null;
  dragGhost?.remove(); dragGhost = null;
  document.body.classList.remove('board-dragging');
}
function updateDragSelection(board, from, legal) {
  selected = from;
  selectedTargets = legal;
  const targetsBySquare = new Map();
  for (const move of legal) {
    if (!targetsBySquare.has(move.to)) targetsBySquare.set(move.to, []);
    targetsBySquare.get(move.to).push(move);
  }
  for (const [squareName, cell] of boardSquareMap) {
    const targetMoves = targetsBySquare.get(squareName) || [];
    const occupied = Boolean(game.get(squareName));
    cell.classList.toggle('selected', squareName === from);
    cell.classList.toggle('legal-target', targetMoves.length > 0 && !occupied);
    cell.classList.toggle('capture-target', targetMoves.length > 0 && occupied);
    const dot = cell.querySelector('.move-dot');
    if (targetMoves.length && !occupied && !dot) cell.insertAdjacentHTML('beforeend', '<span class="move-dot"></span>');
    else if ((!targetMoves.length || occupied) && dot) dot.remove();
  }
}
function wireBoardSquareClicks(board) {
  if (!board || board.dataset.clickWired === 'true') return;
  board.dataset.clickWired = 'true';
  // One delegated listener survives board redraws; do not allocate 64 listeners after every move.
  board.addEventListener('click', event => {
    if (annotationTool && canAnnotateBoard()) { event.preventDefault(); return; }
    const square = event.target?.closest?.('.square[data-square]');
    if (!square || !board.contains(square)) return;
    const suppress = suppressSquareClick;
    if (suppress && Date.now() <= suppress.until && square.dataset.square === suppress.square) {
      suppressSquareClick = null; event.preventDefault(); return;
    }
    if (suppress && Date.now() > suppress.until) suppressSquareClick = null;
    handleSquareClick(square.dataset.square);
  });
}
function wireBoardPointerDrag(board) {
  if (!board || board.dataset.dragWired === 'true') return;
  board.dataset.dragWired = 'true';
  board.addEventListener('pointerdown', event => {
    if (annotationTool && canAnnotateBoard()) {
      const square = event.target?.closest?.('.square[data-square]');
      if (!square || !board.contains(square)) return;
      const rect = board.getBoundingClientRect();
      annotationPointer = { pointerId: event.pointerId, from: square.dataset.square, rect, epoch: gameEpoch, fen: game.fen() };
      try { board.setPointerCapture(event.pointerId); } catch {}
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    const square = event.target?.closest?.('.square[data-square]');
    if (!square || !board.contains(square)) return;
    const from = square.dataset.square;
    const piece = game.get(from);
    if (!canStartBoardDrag(piece)) return;
    const legal = game.moves({ square: from, verbose: true });
    if (!legal.length) return;
    const surface = board.closest('.board-surface') || board;
    const rect = surface.getBoundingClientRect();
    dragState = {
      from, pointerId: event.pointerId, x: event.clientX, y: event.clientY,
      epoch: gameEpoch, fen: game.fen(), moved: false, legal, piece, sourcePiece: square.querySelector('.piece'),
      surface, rect: { left: rect.left, top: rect.top }
    };
    try { board.setPointerCapture(event.pointerId); } catch {}
  }, { passive: false });

  board.addEventListener('pointermove', event => {
    if (annotationPointer && annotationPointer.pointerId === event.pointerId) {
      event.preventDefault();
      return;
    }
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (!state.moved && Math.hypot(event.clientX - state.x, event.clientY - state.y) < 6) return;
    event.preventDefault?.();
    if (!state.moved) {
      state.moved = true;
      updateDragSelection(board, state.from, state.legal);
      if (state.piece) {
        dragGhost = document.createElement('span');
        dragGhost.className = `drag-ghost piece ${state.piece.color === 'w' ? 'white-piece' : 'black-piece'}`;
        dragGhost.innerHTML = pieceGlyph(state.piece);
        state.surface.appendChild(dragGhost);
        document.body.classList.add('board-dragging');
      }
      if (state.sourcePiece) state.sourcePiece.style.opacity = '.22';
    }
    // Pointer events can fire faster than the display refresh. Coalesce DOM writes to one RAF
    // and use a cached board rectangle, avoiding a forced layout read on every touch event.
    dragLatestPoint = { x: event.clientX, y: event.clientY };
    if (!dragMoveFrame) dragMoveFrame = requestAnimationFrame(() => {
      dragMoveFrame = 0;
      const current = dragState;
      const point = dragLatestPoint;
      if (!current || !current.moved || !dragGhost || !point) return;
      dragGhost.style.transform = `translate3d(${point.x - current.rect.left}px, ${point.y - current.rect.top}px, 0) translate(-50%, -50%)`;
    });
  }, { passive: false });

  const finish = async event => {
    if (finishAnnotationPointer(event, board)) return;
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    dragState = null;
    if (state.sourcePiece) state.sourcePiece.style.opacity = '';
    clearDragGhost();
    if (!state.moved) {
      // Pointer capture on Android WebView may retarget the following click to the board itself.
      // Handle taps explicitly, then suppress the synthetic click to prevent double moves.
      suppressSquareClick = { square: state.from, until: Date.now() + 160 };
      handleSquareClick(state.from);
      return;
    }
    event.preventDefault?.();
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest?.('.square[data-square]');
    const to = target && board.contains(target) ? target.dataset.square : '';
    // Suppress only a synthetic click for this exact drop square; never block the next real tap.
    suppressSquareClick = { square: to || state.from, until: Date.now() + 160 };
    const choices = to ? state.legal.filter(move => move.to === to) : [];
    if (!choices.length) { updateDragSelection(board, state.from, state.legal); return; }
    let promotion = choices.find(move => move.promotion)?.promotion || null;
    if (choices.some(move => move.promotion)) promotion = await choosePromotion(game.turn());
    // A promotion chooser can stay open while the player starts a new game or the position changes.
    // Do not apply a drag originating from a stale board state.
    if (state.epoch !== gameEpoch || state.fen !== game.fen()) return;
    if (promotion || !choices.some(move => move.promotion)) playMove(state.from, to, promotion);
  };
  board.addEventListener('pointerup', finish, { passive: false });
  const cancelDrag = event => {
    if (finishAnnotationPointer(event, board, true)) return;
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (state.sourcePiece) state.sourcePiece.style.opacity = '';
    dragState = null; clearDragGhost();
    if (boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets); else renderBoard();
  };
  board.addEventListener('pointercancel', cancelDrag, { passive: true });
  board.addEventListener('lostpointercapture', cancelDrag, { passive: true });
}

function getGameResult() {
  if (!gameStarted) return { token: '*', title: 'Chưa bắt đầu', detail: 'Bắt đầu ván để chơi và ghi lại kết quả.' };
  if (manualGameResult) return { ...manualGameResult };
  if (clockFlagged) {
    const winner = clockFlagged === 'w' ? 'Đen' : 'Trắng';
    const token = clockFlagged === 'w' ? '0-1' : '1-0';
    return { token, title: `${winner} thắng do hết giờ`, detail: `${clockPlayerName(clockFlagged)} đã hết thời gian.` };
  }
  if (game.isCheckmate()) {
    const winner = game.turn() === 'w' ? 'Đen' : 'Trắng';
    return { token: winner === 'Trắng' ? '1-0' : '0-1', title: `Chiếu hết — ${winner} thắng`, detail: 'Vua bên thua không còn nước đi hợp lệ để thoát chiếu.' };
  }
  if (game.isStalemate()) return { token: '1/2-1/2', title: 'Hòa do hết nước đi', detail: 'Bên tới lượt không bị chiếu nhưng không có nước đi hợp lệ.' };
  if (game.isThreefoldRepetition()) return { token: '1/2-1/2', title: 'Hòa do lặp thế cờ', detail: 'Thế cờ đã lặp lại ba lần.' };
  if (game.isInsufficientMaterial()) return { token: '1/2-1/2', title: 'Hòa do không đủ quân chiếu hết', detail: 'Không còn đủ lực lượng để chiếu hết theo luật cờ.' };
  if (game.isDraw()) return { token: '1/2-1/2', title: 'Ván cờ hòa', detail: 'Ván đấu kết thúc theo luật cờ vua.' };
  return { token: '*', title: 'Ván cờ đang diễn ra', detail: '' };
}
function reviewMoveLabel(row) {
  const number = Math.ceil(row.ply / 2);
  return row.mover === 'w' ? `${number}. ${row.san}` : `${number}... ${row.san}`;
}
function reviewMoveNotationLabel(row) {
  const notation = reviewMoveLabel(row);
  const symbol = reviewSymbolForJudgement(row?.judgement);
  return symbol ? `${notation} ${symbol}` : notation;
}
function readSavedGames() {
  try {
    const stored = JSON.parse(localStorage.getItem(GAME_HISTORY_KEY) || '[]');
    return Array.isArray(stored) ? stored.filter(item => item && item.id && item.pgn && item.signature).slice(0, 100) : [];
  } catch { return []; }
}
function writeSavedGames(items) {
  try { localStorage.setItem(GAME_HISTORY_KEY, JSON.stringify(items.slice(0, 100))); return true; }
  catch { return false; }
}
function currentGameHistorySignature(result = getGameResult()) {
  return `${mode}|${gameStartFen}|${game.pgn()}|${result.token}|${manualGameResult?.reason || ''}|${clockFlagged || ''}`;
}
function maybeArchiveCompletedGame() {
  if (!gameStarted || mode === 'lichess' || (!game.isGameOver() && !clockFlagged && !manualGameResult)) return;
  const result = getGameResult();
  if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const signature = historyRestoreSignature || currentGameHistorySignature(result);
  const games = readSavedGames();
  const existing = games.findIndex(item => item.signature === signature);
  const reviewRows = completedReviewRows.filter(row => row.ply > 0);
  if (existing >= 0) {
    if (reviewRows.length && reviewRows.length >= (games[existing].reviewRows?.length || 0)) {
      games[existing] = { ...games[existing], reviewRows, reviewStatus: reviewStatus || `Đã phân tích ${reviewRows.length} nửa nước.` };
      writeSavedGames(games);
    }
    return;
  }
  const pgn = gamePgnWithResult();
  const record = {
    id: `g${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
    signature, date: new Date().toISOString(), resultToken: result.token, title: result.title,
    detail: result.detail || '', mode, plies: game.history().length,
    opening: recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định',
    opponent: mode === 'ai' ? `AI API · ${settings.model || 'AI'}` : mode === 'stockfish' ? 'Stockfish' : 'Hai người chơi',
    pgn, startFen: gameStartFen, reviewRows, reviewStatus: reviewStatus || ''
  };
  games.unshift(record);
  writeSavedGames(games.slice(0, 100));
}
function syncArchivedGameReview() {
  const signature = historyRestoreSignature || currentGameHistorySignature(getGameResult());
  const games = readSavedGames();
  const index = games.findIndex(item => item.signature === signature);
  if (index < 0) return;
  games[index] = { ...games[index], reviewRows: completedReviewRows.filter(row => row.ply > 0), reviewStatus: reviewStatus || '' };
  writeSavedGames(games);
}
function getReviewReplayState() {
  const signature = `${gameStartFen}|${game.pgn()}`;
  if (reviewReplayState?.signature === signature) return reviewReplayState;
  const replay = new Chess(gameStartFen);
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '' }];
  const history = game.history({ verbose: true });
  for (let index = 0; index < history.length; index += 1) {
    const move = history[index];
    let made;
    try { made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); }
    catch { made = null; }
    if (!made) break;
    const legalReplies = replay.moves({ verbose: true });
    const sacrificeCandidate = ['n', 'b', 'r', 'q'].includes(made.piece) && legalReplies.some(reply => reply.to === made.to && Boolean(reply.captured));
    positions.push({ fen: replay.fen(), ply: index + 1, san: made.san, mover: made.color, sacrificeCandidate });
  }
  reviewReplayState = { signature, positions, ply: positions.length - 1 };
  return reviewReplayState;
}
function renderReplayBoardMarkup(fen, lastMove = null, judgement = null) {
  let snapshot;
  try { snapshot = new Chess(fen).board(); } catch { snapshot = new Chess().board(); }
  const html = [];
  const symbol = reviewSymbolForJudgement(judgement);
  const tone = judgement?.key || 'neutral';
  const label = judgement?.label || '';
  // Keep the white-at-bottom orientation while pinning the judgement to the moved piece's destination.
  for (let row = 0; row < 8; row += 1) {
    const rank = 8 - row;
    for (let file = 0; file < 8; file += 1) {
      const piece = snapshot[row][file];
      const square = `${String.fromCharCode(97 + file)}${rank}`;
      const light = (row + file) % 2 === 0;
      const fromClass = lastMove?.from === square ? ' review-last-from' : '';
      const toClass = lastMove?.to === square ? ' review-last-to' : '';
      const annotation = lastMove?.to === square && symbol ? `<span class="review-piece-annotation annotation-${esc(tone)}" title="${esc(label)}" aria-label="${esc(label)}">${esc(symbol)}</span>` : '';
      html.push(`<div class="review-replay-square ${light ? 'review-light' : 'review-dark'}${fromClass}${toClass}" role="gridcell" aria-label="${square}${lastMove?.to === square && label ? `, ${esc(label)}` : ''}">${piece ? `<span class="review-replay-piece ${piece.color === 'w' ? 'piece-white' : 'piece-black'}">${pieceGlyph(piece)}</span>` : ''}${annotation}</div>`);
    }
  }
  return html.join('');
}
function updateReviewReplay() {
  const board = $('#reviewReplayBoard');
  if (!board) return;
  const state = getReviewReplayState();
  state.ply = Math.max(0, Math.min(state.positions.length - 1, Number(state.ply) || 0));
  const position = state.positions[state.ply] || state.positions[0];
  const replayMoves = game.history({ verbose: true });
  const lastMove = state.ply > 0 ? replayMoves[state.ply - 1] : null;
  const judgedPosition = completedReviewRows.find(row => row.ply === state.ply);
  board.innerHTML = renderReplayBoardMarkup(position.fen, lastMove, judgedPosition?.judgement);
  const label = $('#reviewReplayPosition');
  if (label) {
    const shownMove = judgedPosition ? reviewMoveNotationLabel(judgedPosition) : reviewMoveLabel(position);
    label.textContent = state.ply === 0 ? 'Vị trí bắt đầu' : `Sau ${shownMove} · ${state.ply}/${state.positions.length - 1}`;
  }
  $$('[data-review-step]').forEach(button => {
    const step = button.dataset.reviewStep;
    button.disabled = (step === 'first' || step === 'prev') ? state.ply === 0 : (step === 'next' || step === 'last') ? state.ply >= state.positions.length - 1 : false;
  });
  $$('[data-review-ply]').forEach(button => {
    const active = Number(button.dataset.reviewPly) === state.ply;
    button.classList.toggle('review-move-active', active);
    if (active) button.setAttribute('aria-current', 'step'); else button.removeAttribute('aria-current');
  });
}
function setReviewReplayPly(value) {
  const state = getReviewReplayState();
  const next = typeof value === 'function' ? value(state.ply, state.positions.length - 1) : value;
  state.ply = Math.max(0, Math.min(state.positions.length - 1, Number(next) || 0));
  updateReviewReplay();
}
function restoreSavedGame(record, analyze = false) {
  if (!record) return;
  try {
    cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopFullGameReview(false); stopAnalysis(true); cancelMainEngineSearch(); stopClock();
    const restored = new Chess();
    let archivedPgn = String(record.pgn || '');
    const archivedStartFen = record.startFen || new Chess().fen();
    if (archivedStartFen !== new Chess().fen() && !/\[FEN\s+"/i.test(archivedPgn)) {
      // Backward-compatibility for records saved before custom-FEN PGN headers
      // were added; reconstruct them from the separate archive field.
      const headerEnd = archivedPgn.indexOf('\n\n');
      const fenTags = `[SetUp "1"]\n[FEN "${pgnEscape(archivedStartFen)}"]`;
      archivedPgn = headerEnd >= 0
        ? `${archivedPgn.slice(0, headerEnd)}\n${fenTags}${archivedPgn.slice(headerEnd)}`
        : `${fenTags}\n\n${archivedPgn}`;
    }
    restored.loadPgn(archivedPgn);
    game = restored;
    gameStartFen = archivedStartFen;
    mode = 'local'; humanColor = 'w'; orientation = 'w'; gameStarted = true;
    clockFlagged = null;
    manualGameResult = { token: record.resultToken || '*', title: record.title || 'Ván đã lưu', detail: record.detail || 'Đang xem lại ván đã lưu.', reason: 'saved-replay' };
    completedReviewRows = Array.isArray(record.reviewRows) ? record.reviewRows : [];
    reviewStatus = record.reviewStatus || (completedReviewRows.length ? `Đã tải ${completedReviewRows.length} đánh giá đã lưu.` : 'Ván đã lưu. Có thể phân tích lại bằng Stockfish.');
    historyRestoreSignature = record.signature;
    reviewReplayState = null; selected = null; selectedTargets = []; lastMove = null; botThinking = false;
    resetClock('untimed');
    setView('play');
    if (analyze) setTimeout(() => startFullGameReview(), 120);
  } catch (error) { toast(`Không mở được PGN đã lưu: ${error.message || error}`); }
}
function renderHistoryView() {
  const games = readSavedGames();
  const items = games.map(record => {
    const date = Number.isFinite(Date.parse(record.date)) ? new Date(record.date).toLocaleString('vi-VN') : 'Ngày không rõ';
    const reviewed = record.reviewRows?.length || 0;
    return `<article class="saved-game-card"><div class="saved-game-top"><span class="saved-result ${record.resultToken === '1/2-1/2' ? 'draw' : ''}">${esc(record.resultToken)}</span><div><h3>${esc(record.title || 'Ván đã lưu')}</h3><small>${esc(date)} · ${Number(record.plies) || 0} nửa nước</small></div></div><p>${esc(record.opponent || 'Đối thủ') } · Khai cuộc: ${esc(record.opening || 'Chưa xác định')}</p><div class="saved-game-meta"><span>${reviewed ? `${reviewed} nước đã phân tích` : 'Chưa có phân tích'}</span><span>${esc(record.mode || 'local')}</span></div><div class="saved-game-actions"><button class="primary-btn" type="button" data-history-review="${esc(record.id)}">↶ Xem lại</button><button class="secondary-btn" type="button" data-history-analyze="${esc(record.id)}">♞ Phân tích</button><button class="secondary-btn" type="button" data-history-pgn="${esc(record.id)}">Tải PGN</button><button class="text-btn" type="button" data-history-delete="${esc(record.id)}">Xóa</button></div></article>`;
  }).join('');
  return `<section class="history-view"><header class="page-heading"><div><small class="eyebrow">VÁN ĐẤU CỦA BẠN</small><h1>Lịch sử & xem lại</h1><p>Các ván kết thúc được lưu cục bộ trên thiết bị này. Chọn xem lại, phân tích bằng Stockfish hoặc xuất PGN.</p></div><div class="history-count">${games.length}/100 ván</div></header><div class="saved-games-list">${items || '<div class="panel empty-state"><b>Chưa có ván đã lưu</b><p>Chơi và kết thúc một ván để nó tự xuất hiện ở đây.</p><button class="primary-btn" type="button" data-history-start>♟ Chơi ván mới</button></div>'}</div><p class="field-hint history-privacy-note">Lịch sử chỉ lưu trong bộ nhớ cục bộ của trình duyệt/WebView này; xóa dữ liệu ứng dụng có thể xóa lịch sử.</p></section>`;
}
function wireHistoryActions() {
  const find = id => readSavedGames().find(record => record.id === id);
  $$('[data-history-review]').forEach(button => button.addEventListener('click', () => restoreSavedGame(find(button.dataset.historyReview), false)));
  $$('[data-history-analyze]').forEach(button => button.addEventListener('click', () => restoreSavedGame(find(button.dataset.historyAnalyze), true)));
  $$('[data-history-pgn]').forEach(button => button.addEventListener('click', () => {
    const record = find(button.dataset.historyPgn);
    if (record) downloadTextFile(record.pgn, `vila-chess-${String(record.date || '').slice(0, 10) || 'game'}.pgn`, 'application/x-chess-pgn;charset=utf-8');
  }));
  $$('[data-history-delete]').forEach(button => button.addEventListener('click', () => {
    const record = find(button.dataset.historyDelete);
    if (!record || (typeof window.confirm === 'function' && !window.confirm('Xóa ván đã lưu này khỏi thiết bị?'))) return;
    writeSavedGames(readSavedGames().filter(item => item.id !== record.id)); renderView();
  }));
  $('[data-history-start]')?.addEventListener('click', () => { mode = 'stockfish'; historyRestoreSignature = ''; setView('play'); startGameFromSetup(); });
}
function renderFullGameResultPanel() {
  const result = getGameResult();
  const reviewRows = completedReviewRows.slice(-160);
  const done = reviewRows.filter(row => row.ply > 0).length;
  const blunders = reviewRows.filter(row => row.judgement?.key === 'blunder').length;
  const brilliant = reviewRows.filter(row => row.judgement?.key === 'brilliant').length;
  const mistakes = reviewRows.filter(row => row.judgement?.key === 'mistake').length;
  const rowHtml = reviewRows.filter(row => row.ply > 0).map(row => {
    const tone = row.judgement?.key || 'neutral';
    const evalText = Number.isFinite(row.scoreWhiteCp) ? `${row.scoreWhiteCp >= 0 ? '+' : ''}${(row.scoreWhiteCp / 100).toFixed(1)}` : '—';
    const lossText = Number.isFinite(row.lossCp) ? `−${(row.lossCp / 100).toFixed(1)}` : '—';
    const symbol = reviewSymbolForJudgement(row.judgement);
    const symbolTitle = reviewSymbolDescription(row.judgement);
    return `<button type="button" class="review-move-row" data-review-ply="${row.ply}"><span class="review-ply">${esc(reviewMoveLabel(row))}${symbol ? ` <b class="review-move-symbol symbol-${tone}" title="${esc(symbolTitle)}" aria-label="${esc(symbolTitle)}">${esc(symbol)}</b>` : ''}</span><span class="review-verdict verdict-${tone}">${esc(row.judgement?.label || 'Chưa đánh giá')}</span><span class="review-eval">${evalText}</span><small>${lossText}</small></button>`;
  }).join('');
  const reviewing = Boolean(reviewSession);
  const reviewSummary = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish…`
    : reviewStatus || (done ? `Đã phân tích ${done} nửa nước · ${brilliant} thiên tài* · ${mistakes} sai lầm · ${blunders} blunder.` : 'Chưa phân tích ván. Bấm “Phân tích toàn ván” để đánh giá từng nửa nước bằng Stockfish nội bộ.');
  const ratingProfile = readRatingProfile();
  const ratingStrip = ['stockfish', 'ai'].includes(mode) && ['1-0', '0-1', '1/2-1/2'].includes(result.token)
    ? `<div class="rating-result-strip"><span>Elo hiện tại <b>${ratingProfile.elo}</b></span><span>Biến động gần nhất <b class="${ratingProfile.lastChange > 0 ? 'positive' : ratingProfile.lastChange < 0 ? 'negative' : ''}">${ratingProfile.lastChange > 0 ? '+' : ''}${ratingProfile.lastChange}</b></span><small>Điểm Elo ước lượng lưu trên thiết bị</small></div>` : '';
  const replayNow = getReviewReplayState();
  const replayMoveNow = replayNow.ply > 0 ? game.history({ verbose: true })[replayNow.ply - 1] : null;
  const replayJudgementNow = completedReviewRows.find(row => row.ply === replayNow.ply)?.judgement;
  return `<section class="panel full-game-result" id="fullGameResult"><div class="panel-heading"><div><small class="eyebrow">KẾT QUẢ & ĐÁNH GIÁ</small><h2>${esc(result.title)}</h2></div><span class="result-token">${esc(result.token)}</span></div><p class="result-detail">${esc(result.detail)}</p>${ratingStrip}<div class="result-stats"><span><small>Số nước</small><b>${game.history().length}</b></span><span><small>Khai cuộc</small><b>${esc(recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định')}</b></span><span><small>Engine</small><b>Stockfish</b></span></div><section class="review-replay-panel"><div class="review-replay-head"><b>♟ Xem lại từng nước</b><span id="reviewReplayPosition">Đang ở nước cuối</span></div><div id="reviewReplayBoard" class="review-replay-board" role="grid" aria-label="Bàn cờ xem lại">${renderReplayBoardMarkup(replayNow.positions[replayNow.ply]?.fen || game.fen(), replayMoveNow, replayJudgementNow)}</div><div class="review-replay-controls"><button type="button" class="secondary-btn" data-review-step="first" aria-label="Về đầu">|◀</button><button type="button" class="secondary-btn" data-review-step="prev" aria-label="Nước trước">‹ Trước</button><button type="button" class="secondary-btn" data-review-step="next" aria-label="Nước sau">Sau ›</button><button type="button" class="secondary-btn" data-review-step="last" aria-label="Đến cuối">▶|</button></div><p class="review-replay-caption">Chạm một nước trong bảng đánh giá để nhảy nhanh tới thế cờ đó.</p></section><div class="review-progress" id="reviewProgress">${esc(reviewSummary)}</div><div class="review-symbol-legend" aria-label="Chú giải ký hiệu đánh giá"><span><b class="symbol-book">📖</b> Sách</span><span><b class="symbol-best">★</b> Tốt nhất</span><span><b class="symbol-excellent">!</b> Xuất sắc</span><span><b class="symbol-good">✓</b> Tốt</span><span><b class="symbol-inaccuracy">?!</b> Chưa chuẩn</span><span><b class="symbol-mistake">?</b> Sai lầm</span><span><b class="symbol-blunder">??</b> Blunder</span><span><b class="symbol-brilliant">!!</b> Thiên tài*</span></div><p class="review-classification-note">Thiên tài* là heuristic: nước có dấu hiệu hy sinh quân lớn và đánh giá engine không giảm đáng kể. Đây không phải nhãn chính thức của Chess.com.</p><div class="review-move-list" id="reviewMoveAnalysis">${rowHtml || '<div class="empty-state small-empty">Khi phân tích xong, đánh giá từng nước sẽ hiện ở đây.</div>'}</div><div class="review-actions"><button id="reviewGameBtn" type="button" class="primary-btn" ${reviewing ? 'disabled' : ''}>♞ Phân tích toàn ván</button><button id="stopReviewBtn" type="button" class="secondary-btn" ${reviewing ? '' : 'disabled'}>Dừng</button><button id="reviewDownloadPGN" type="button" class="secondary-btn">Tải PGN</button><button id="explainGameBtn" type="button" class="secondary-btn">Giải thích bằng AI</button></div></section>`;
}
function updateReviewPanel() {
  const progress = $('#reviewProgress');
  const list = $('#reviewMoveAnalysis');
  if (!progress || !list) { if (currentView === 'play') renderView(); return; }
  const rows = completedReviewRows.filter(row => row.ply > 0);
  const reviewing = Boolean(reviewSession);
  progress.textContent = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish…`
    : reviewStatus || `Đã phân tích ${rows.length} nửa nước.`;
  list.innerHTML = rows.slice(-160).map(row => {
    const tone = row.judgement?.key || 'neutral';
    const score = Number.isFinite(row.scoreWhiteCp) ? `${row.scoreWhiteCp >= 0 ? '+' : ''}${(row.scoreWhiteCp / 100).toFixed(1)}` : '—';
    const loss = Number.isFinite(row.lossCp) ? `−${(row.lossCp / 100).toFixed(1)}` : '—';
    const symbol = reviewSymbolForJudgement(row.judgement);
    const symbolTitle = reviewSymbolDescription(row.judgement);
    return `<button type="button" class="review-move-row" data-review-ply="${row.ply}"><span class="review-ply">${esc(reviewMoveLabel(row))}${symbol ? ` <b class="review-move-symbol symbol-${tone}" title="${esc(symbolTitle)}" aria-label="${esc(symbolTitle)}">${esc(symbol)}</b>` : ''}</span><span class="review-verdict verdict-${tone}">${esc(row.judgement?.label || 'Chưa đánh giá')}</span><span class="review-eval">${score}</span><small>${loss}</small></button>`;
  }).join('') || '<div class="empty-state small-empty">Khi phân tích xong, đánh giá từng nước sẽ hiện ở đây.</div>';
  updateReviewReplay();
}
function stopFullGameReview(announce = false) {
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  const wasReviewing = Boolean(reviewSession);
  reviewSession = null;
  if (wasReviewing) {
    requestEngineStop();
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
  }
  if (announce && wasReviewing) { reviewStatus = 'Đã dừng phân tích theo yêu cầu.'; updateReviewPanel(); }
}
function beginReviewPosition() {
  if (!reviewSession) return;
  if (reviewSession.index >= reviewSession.positions.length) {
    reviewStatus = `Hoàn tất phân tích ${completedReviewRows.filter(row => row.ply > 0).length} nửa nước.`;
    reviewSession = null;
    engineSearchActive = false;
    try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
    syncArchivedGameReview();
    updateReviewPanel();
    return;
  }
  if (!engineWorker || !engineReady || engineFailed) {
    reviewStatus = 'Không thể tiếp tục: Stockfish chưa sẵn sàng.';
    reviewSession = null; engineSearchActive = false; updateReviewPanel(); return;
  }
  const position = reviewSession.positions[reviewSession.index];
  reviewSession.currentScoreWhite = null;
  reviewSession.currentDepth = 0;
  reviewSession.waiting = true;
  engineSearchActive = true;
  mainEngineSearchEpoch = -3;
  mainEngineSearchFen = position.fen;
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 1');
    engineWorker.postMessage(`position fen ${position.fen}`);
    engineWorker.postMessage('go movetime 220');
    reviewSession.timeout = setTimeout(() => finishReviewPosition(true), 5000);
    updateReviewPanel();
  } catch {
    finishReviewPosition(true);
  }
}
function receiveReviewInfo(line) {
  if (!reviewSession?.waiting) return;
  const match = line.match(/\bscore\s+(cp|mate)\s+(-?\d+)/);
  if (!match) return;
  const depth = Number(line.match(/\bdepth\s+(\d+)/)?.[1] || 0);
  if (depth < reviewSession.currentDepth) return;
  const position = reviewSession.positions[reviewSession.index];
  const turn = String(position.fen).split(/\s+/)[1] || 'w';
  reviewSession.currentDepth = depth;
  reviewSession.currentScoreWhite = scoreSideToWhiteCentipawns(Number(match[2]), turn, match[1]);
}
function finishReviewPosition(timedOut = false) {
  if (!reviewSession?.waiting) return;
  const session = reviewSession;
  if (session.timeout) clearTimeout(session.timeout);
  session.timeout = null;
  session.waiting = false;
  const position = session.positions[session.index];
  const scoreWhiteCp = Number.isFinite(session.currentScoreWhite) ? session.currentScoreWhite : null;
  if (timedOut) {
    reviewStatus = `Dừng tại ${session.index}/${session.positions.length}: Stockfish không phản hồi kịp. Các kết quả đã có vẫn được giữ; chạm trạng thái engine để thử khởi tạo lại.`;
    retireStockfishWorker(reviewStatus);
    updateReviewPanel();
    return;
  }
  if (session.index === 0) {
    completedReviewRows = [{ ply: 0, san: '', mover: '', scoreWhiteCp, lossCp: null, judgement: null }];
  } else {
    const lossCp = estimateMoveLoss(session.lastScoreWhite, scoreWhiteCp, position.mover);
    completedReviewRows.push({ ply: position.ply, san: position.san, mover: position.mover, scoreWhiteCp, lossCp, judgement: lossCp == null ? null : classifyReviewedMove(lossCp, position.sacrificeCandidate, position.bookMove), bookMove: Boolean(position.bookMove) });
    syncArchivedGameReview();
  }
  if (scoreWhiteCp != null) session.lastScoreWhite = scoreWhiteCp;
  session.index += 1;
  mainEngineSearchEpoch = -1; mainEngineSearchFen = '';
  engineSearchActive = false;
  try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
  updateReviewPanel();
  setTimeout(beginReviewPosition, 20);
}
function startFullGameReview() {
  if (!gameStarted || game.history().length < 1) { toast('Chơi ít nhất một nước rồi mới có thể phân tích toàn ván.'); return; }
  if (!game.isGameOver() && !clockFlagged && !manualGameResult) { toast('Phân tích toàn ván khả dụng sau khi trận kết thúc. Bạn vẫn có thể dùng “Phân tích 3 biến” giữa ván.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng; hãy kiểm tra tệp engine và thử lại.'); return; }
  if (arenaRunning || botThinking || engineStopPending || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || engineSearchActive) { toast('Đợi tác vụ Stockfish hiện tại kết thúc rồi mới phân tích ván.'); return; }
  stopFullGameReview(false);
  completedReviewRows = [];
  reviewStatus = 'Đang chuẩn bị phân tích…';
  const replay = new Chess(gameStartFen);
  const history = game.history({ verbose: true });
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '', bookMove: false }];
  const openingPrefixes = buildOpeningBookPrefixes(OPENINGS);
  const sanPath = [];
  const maxPlies = Math.min(history.length, 160);
  for (let i = 0; i < maxPlies; i += 1) {
    const move = history[i];
    const made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    if (!made) { toast(`Không thể dựng lại lịch sử ở nửa nước ${i + 1}; phân tích đã hủy.`); return; }
    const legalReplies = replay.moves({ verbose: true });
    const sacrificeCandidate = ['n', 'b', 'r', 'q'].includes(made.piece) && legalReplies.some(reply => reply.to === made.to && Boolean(reply.captured));
    sanPath.push(made.san);
    const bookMove = openingPrefixes.has(sanPath.join(' '));
    positions.push({ fen: replay.fen(), ply: i + 1, san: made.san, mover: made.color, sacrificeCandidate, bookMove });
  }
  reviewSession = { positions, index: 0, rows: [], lastScoreWhite: null, currentScoreWhite: null, waiting: false, timeout: null };
  if (history.length > maxPlies) reviewStatus = 'Giới hạn phân tích ở 160 nửa nước để giữ ổn định trên điện thoại.';
  updateReviewPanel();
  beginReviewPosition();
}
function explainCompletedGame() {
  if (!gameStarted) { toast('Chưa có ván để giải thích.'); return; }
  const result = getGameResult();
  const review = completedReviewRows.filter(row => row.ply > 0).slice(-60).map(row => `${reviewMoveLabel(row)}: ${row.judgement?.label || 'chưa đánh giá'}, đánh giá ${Number.isFinite(row.scoreWhiteCp) ? (row.scoreWhiteCp / 100).toFixed(1) : '—'}`).join('\n');
  const prompt = `Hãy giải thích ván cờ đã kết thúc bằng tiếng Việt, nêu 3 thời điểm quan trọng, các lỗi lớn và cách cải thiện. Không bịa phân tích engine nếu chưa có. Kết quả: ${result.title}. PGN:\n${gamePgnWithResult().slice(-7000)}\nĐánh giá Stockfish theo từng nửa nước:\n${review || 'Chưa có phân tích Stockfish từng nước.'}`;
  setView('coach');
  setTimeout(() => {
    const input = $('#coachInput');
    if (input) input.value = '';
    // Whole-game natural-language explanation must use the configured provider,
    // even if ordinary Coach questions are currently set to local engine mode.
    void sendCoachMessage(prompt, { forceApi: true });
  }, 0);
}

function renderBoard() {
  const board = $('#board');
  if (!board) return;
  const rows = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const targetMovesBySquare = new Map();
  for (const move of selectedTargets) {
    if (!targetMovesBySquare.has(move.to)) targetMovesBySquare.set(move.to, []);
    targetMovesBySquare.get(move.to).push(move);
  }
  const legalTargetSet = new Set(targetMovesBySquare.keys());
  const inCheck = game.isCheck();
  const sideToMove = game.turn();
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = game.get(sq);
    const isLastFrom = lastMove && (lastMove.from === sq || lastMove.to === sq);
    const checkKing = inCheck && piece?.type === 'k' && piece.color === sideToMove;
    const isSelected = selected === sq;
    const targetMoves = targetMovesBySquare.get(sq) || [];
    const capture = targetMoves.length && piece;
    const classes = ['square', squareColor(sq), isSelected ? 'selected' : '', legalTargetSet.has(sq) ? (capture ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-move' : '', checkKing ? 'in-check' : ''].filter(Boolean).join(' ');
    const pieceName = piece ? ({ k: 'vua', q: 'hậu', r: 'xe', b: 'tượng', n: 'mã', p: 'tốt' }[piece.type] || 'quân') : '';
    const glyph = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}" aria-hidden="true">${pieceGlyph(piece)}</span>` : '';
    const accessibleSquareLabel = `Ô ${sq}${piece ? `, ${piece.color === 'w' ? 'quân Trắng' : 'quân Đen'} ${pieceName}` : ''}${isSelected ? ', đang chọn' : ''}${legalTargetSet.has(sq) ? ', nước đi hợp lệ' : ''}`;
    // Rank labels stay on the left; every square on the bottom row gets its
    // file label. `files` is already reversed when the board is flipped.
    const coord = (colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : '') + (rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : '');
    html += `<button type="button" class="${classes}" data-square="${sq}" aria-label="${accessibleSquareLabel}">${glyph}${targetMoves.length && !capture ? '<span class="move-dot"></span>' : ''}${coord}</button>`;
  }));
  board.innerHTML = html;
  boardSquareMap = new Map($$('.square[data-square]', board).map(square => [square.dataset.square, square]));
  syncBoardLayout();
  wireBoardSquareClicks(board);
  wireBoardPointerDrag(board);
  renderHintArrow();
  syncAnnotationWidget();
  $('#boardStatus')?.replaceChildren(document.createTextNode(gameStarted ? positionStatus() : 'Sẵn sàng — nhấn Bắt đầu ván mới để chơi.'));
  const moveList = $('#moveList');
  if (moveList) renderMoveList(moveList);
  const fenBox = $('#fenText');
  if (fenBox) fenBox.textContent = game.fen();
  const pgnBox = $('#pgnText');
  if (pgnBox) pgnBox.textContent = game.pgn();
  const evalBox = $('#evalNumber');
  if (evalBox && !engineSearchActive) evalBox.textContent = '—';
  $('#turnChip')?.replaceChildren(document.createTextNode(game.turn() === 'w' ? 'Lượt Trắng' : 'Lượt Đen'));
  $('#resignBtn')?.toggleAttribute('disabled', !gameStarted || game.isGameOver() || Boolean(clockFlagged) || Boolean(manualGameResult));
  const moveCount = $('#gameMoveCount');
  if (moveCount) moveCount.textContent = String(game.history().length);
  const statusText = $('#gameStatusText');
  if (statusText) statusText.textContent = !gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged || manualGameResult) ? 'Kết thúc' : botThinking ? 'Bot đang tính' : 'Đang chơi';
  const openingLabel = $('#openingRecognition');
  if (openingLabel) {
    const recognized = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
    openingLabel.textContent = recognized ? `Khai cuộc nhận diện: ${recognized.name}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước');
  }
  renderClockDisplay();
  renderAnalysisPanel();
}
function positionStatus(chess = game) {
  if (chess === game && clockFlagged) return `Hết giờ — ${clockPlayerName(clockFlagged)} thua`;
  if (chess.isCheckmate()) return `Chiếu hết — ${chess.turn() === 'w' ? 'Đen' : 'Trắng'} thắng`;
  if (chess.isStalemate()) return 'Hòa do hết nước đi';
  if (chess.isThreefoldRepetition()) return 'Hòa do lặp lại thế cờ';
  if (chess.isInsufficientMaterial()) return 'Hòa do không đủ quân chiếu hết';
  if (chess.isDraw()) return 'Ván cờ hòa';
  return `${chess.turn() === 'w' ? 'Trắng' : 'Đen'} đang đi${chess.isCheck() ? ' — đang bị chiếu!' : ''}`;
}
function renderMoveList(element) {
  const history = game.history();
  if (!history.length) { element.innerHTML = '<div class="empty-state">Nước đi của bạn sẽ xuất hiện ở đây.</div>'; return; }
  let rows = '';
  for (let i = 0; i < history.length; i += 2) {
    rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2) + 1}.</span><span class="move-san">${esc(history[i])}</span><span class="move-san">${esc(history[i + 1] || '…')}</span></div>`;
  }
  element.innerHTML = rows;
  element.scrollTop = element.scrollHeight;
}
function handleSquareClick(square) {
  if (!gameStarted) { toast('Nhấn “Bắt đầu ván mới” để bắt đầu trận.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (arenaRunning) { toast('Đấu trường AI đang dùng Stockfish; hãy dừng trận trước khi chơi bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged || botThinking) return;
  if (mode !== 'local' && game.turn() !== humanColor) { toast(mode === 'lichess' ? 'Đang chờ đối thủ đi.' : 'Đang đến lượt bot.'); return; }
  const piece = game.get(square);
  if (selected && selectedTargets.some(m => m.to === square)) {
    const choices = selectedTargets.filter(m => m.to === square);
    const promotion = choices.find(m => m.promotion)?.promotion;
    if (promotion) choosePromotion(game.turn()).then(type => type && playMove(selected, square, type));
    else playMove(selected, square);
    return;
  }
  if (piece && (mode === 'local' || piece.color === game.turn())) {
    selected = square;
    selectedTargets = game.moves({ square, verbose: true });
  } else {
    selected = null;
    selectedTargets = [];
  }
  const board = $('#board');
  if (board && boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets);
  else renderBoard();
}
function choosePromotion(color) {
  return new Promise(resolve => {
    const root = $('#modalRoot');
    root.innerHTML = `<div class="modal-backdrop"><div class="modal-card"><h3>Phong cấp tốt</h3><p>Chọn quân muốn phong cấp.</p><div class="promotion-options">${['q','r','b','n'].map(type => `<button data-promotion="${type}" class="promotion-choice ${color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph({ color, type })}<small>${({ q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã' })[type]}</small></button>`).join('')}</div><button id="cancelPromotion" class="secondary-btn full-width">Hủy</button></div></div>`;
    $$('[data-promotion]', root).forEach(button => button.addEventListener('click', () => { root.innerHTML = ''; resolve(button.dataset.promotion); }));
    $('#cancelPromotion', root).addEventListener('click', () => { root.innerHTML = ''; resolve(null); });
  });
}
function playMove(from, to, promotion) {
  if (!gameStarted) { toast('Bắt đầu ván mới trước khi đi quân.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (clockFlagged) { toast('Ván cờ đã kết thúc do hết giờ.'); return; }
  tickClock();
  if (clockFlagged) return;
  stopAnalysis(true);
  const mover = game.turn();
  try {
    const move = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!move) return;
    playBoardSound(move, game, settings.soundEnabled);
    recordDailyEvent('make_move');
    if (move.captured) recordDailyEvent('capture_piece');
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) recordDailyEvent('castle');
    if (move.promotion) recordDailyEvent('promote');
    if (game.isCheck()) recordDailyEvent('check_king');
    lastHintMove = null;
    boardAnnotations = []; annotationTool = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: move.from, to: move.to };
    selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null;
    if (mode === 'lichess') submitLichessMove(`${move.from}${move.to}${move.promotion || ''}`);
    onMoveComplete();
  } catch (error) { toast(`Nước đi không hợp lệ: ${error.message}`); }
}
function onMoveComplete() {
  const isOver = game.isGameOver();
  const needsBot = !isOver && ['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor;
  // Set this before rendering so a move only rebuilds the view once rather than twice.
  botThinking = needsBot;
  if (needsBot && mode === 'ai' && !aiRequestConfigured()) botThinking = false;
  if (isOver || currentView !== 'play') renderView();
  else renderBoard();
  if (isOver) {
    botThinking = false;
    stopClock();
    const outcome = game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.';
    toast(outcome, 'success');
    return;
  }
  if (needsBot) {
    if (mode === 'ai' && !aiRequestConfigured()) {
      toast('AI qua API chưa được cấu hình đầy đủ. Hãy hoàn tất Cài đặt hoặc đổi sang Stockfish.');
      return;
    }
    scheduleBotMove(220);
  }
  if (currentView === 'play') queryOpeningExplorer(false);
}
function resignCurrentGame() {
  if (!gameStarted || game.isGameOver() || clockFlagged || manualGameResult) return;
  if (mode === 'lichess') { toast('Đầu hàng trong ván Lichess phải thực hiện trên dịch vụ Lichess.'); return; }
  const resigning = mode === 'local' ? game.turn() : humanColor;
  const winner = resigning === 'w' ? 'Đen' : 'Trắng';
  if (typeof window.confirm === 'function' && !window.confirm(`Đầu hàng? ${winner} sẽ thắng ván này.`)) return;
  cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
  gameEpoch += 1; botThinking = false; queuedMainEngineMove = false;
  manualGameResult = {
    token: resigning === 'w' ? '0-1' : '1-0',
    title: `Đầu hàng — ${winner} thắng`,
    detail: `${resigning === 'w' ? 'Trắng' : 'Đen'} đã đầu hàng. Lịch sử nước đi được giữ nguyên để xem lại.`,
    reason: 'resignation'
  };
  stopClock(); renderView();
}

function freshGame({ startFen = null } = {}) {
  historyRestoreSignature = ''; reviewReplayState = null;
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi tạo ván khác.'); return; }
  if (mode === 'ai' && !aiRequestConfigured()) {
    toast('AI qua API chưa được cấu hình đầy đủ. Hãy hoàn tất Cài đặt trước khi bắt đầu ván.');
    setView('settings');
    return;
  }
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  manualGameResult = null;
  if (mode === 'stockfish' && randomBotEloEnabled) {
    settings.botStrengthMode = 'elo'; settings.botElo = 500 + Math.floor(Math.random() * 28) * 100; settings.botSkill = 20; saveSettings();
  }
  if (mode === 'lichess') mode = 'stockfish';
  stopOnlineStream();
  game = startFen ? new Chess(startFen) : new Chess();
  gameStartFen = game.fen();
  completedReviewRows = []; reviewStatus = '';
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  selected = null; selectedTargets = []; lastMove = null; lastHintMove = null; boardAnnotations = []; annotationTool = null; botThinking = false; currentOpening = null;
  resetClock(settings.clockPreset);
  renderView();
  if (['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true;
    scheduleBotMove(250);
  }
}
function undoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi hoàn tác.'); return; }
  if (mode === 'lichess') { toast('Không thể tự hoàn tác ván Lichess; hãy dùng chức năng takeback trên Lichess.'); return; }
  if (!game.history().length || botThinking) return;
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  game.undo();
  boardAnnotations = []; annotationTool = null;
  if (mode !== 'local' && game.history().length && game.turn() !== humanColor) game.undo();
  manualGameResult = null;
  gameEpoch += 1;
  completedReviewRows = []; reviewStatus = '';
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null; lastHintMove = null;
  resetClock(settings.clockPreset);
  renderView();
}

function updateEvaluationMeter(scoreType, scoreValue, sideToMove) {
  const fill = $('#evaluationMeterWhite');
  const meter = $('#evaluationMeter');
  if (!fill || !meter) return;
  const whiteCp = scoreSideToWhiteCentipawns(Number(scoreValue), sideToMove, scoreType);
  if (!Number.isFinite(whiteCp)) return;
  // Smoothly map centipawns to a bounded share. This is a visual cue, not win probability.
  const share = Math.max(4, Math.min(96, 50 + 46 * Math.tanh(whiteCp / 500)));
  fill.style.width = `${share.toFixed(1)}%`;
  meter.setAttribute('aria-label', `Thanh đánh giá: ${whiteCp > 0 ? 'Trắng hơn' : whiteCp < 0 ? 'Đen hơn' : 'cân bằng'}`);
}

function retireStockfishWorker(message = 'Stockfish không khả dụng.') {
  if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
  // Terminate rather than only sending `stop`: a late bestmove from a timed-out
  // search must never be mistaken for the next request's result.
  const retired = engineWorker;
  engineWorker = null;
  try { retired?.terminate(); } catch {}
  engineReady = false;
  engineFailed = true;
  engineUciInitialized = false;
  engineSearchActive = false;
  engineStopPending = false;
  if (engineStopTimeout) { clearTimeout(engineStopTimeout); engineStopTimeout = null; }
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  cancelMainEngineWatchdog();
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  analysisActive = false;
  if (pendingHintRequest) { clearTimeout(pendingHintRequest.timeout); pendingHintRequest = null; }
  if (pendingEngineRequest) {
    const pending = pendingEngineRequest;
    pendingEngineRequest = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (pendingCoachAnalysis) {
    const pending = pendingCoachAnalysis;
    pendingCoachAnalysis = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  if (reviewSession) {
    reviewSession = null;
    reviewStatus = message;
    updateReviewPanel();
  }
  const status = $('#engineStatus');
  if (status) {
    status.innerHTML = '<i></i> Stockfish lỗi · chạm để tải lại';
    status.classList.remove('ready');
    status.title = message;
  }
  renderAnalysisPanel();
  console.warn('[Chess Bot] Stockfish worker retired:', message);
}

function retryStockfishEngine() {
  if (engineStopPending || engineSearchActive || botThinking || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || reviewSession) {
    toast('Đợi tác vụ cờ hiện tại kết thúc rồi mới tải lại engine.');
    return;
  }
  if (engineWorker && engineReady && !engineFailed) {
    toast('Stockfish đã sẵn sàng.');
    return;
  }
  if (engineWorker && !engineReady && !engineFailed) {
    toast('Stockfish đang khởi tạo; chờ thêm một chút trước khi thử lại.');
    return;
  }
  retireStockfishWorker('Đang tải lại Stockfish…');
  engineFailed = false;
  const status = $('#engineStatus');
  if (status) {
    status.innerHTML = '<i></i> Đang tải Stockfish…';
    status.title = 'Đang khởi tạo engine';
  }
  engineInitFallbacksTried = new Set();
  initEngine();
  toast('Đang thử khởi tạo lại Stockfish…');
}

function fallbackEngineLabel(profile) {
  if (profile === 'full-single') return 'Stockfish Full';
  if (profile === 'lite-single') return 'Stockfish Lite';
  return 'Stockfish ASM-JS';
}
function tryEngineInitFallback(failedProfile) {
  const nextProfile = nextEngineFallback(failedProfile);
  if (!nextProfile || engineInitFallbacksTried.has(nextProfile)) return false;
  engineInitFallbacksTried.add(nextProfile);
  if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
  const previous = engineWorker;
  engineWorker = null;
  try { previous?.terminate(); } catch {}
  engineReady = false;
  engineUciInitialized = false;
  engineFailed = false;
  engineSearchActive = false;
  const status = $('#engineStatus');
  if (status) {
    const label = fallbackEngineLabel(nextProfile);
    status.innerHTML = `<i></i> Đang thử ${label} dự phòng…`;
    status.classList.remove('ready');
    status.title = `Engine trước không khởi tạo được; đang thử ${label}.`;
  }
  console.warn(`[Chess Bot] Stockfish init fallback: ${failedProfile} -> ${nextProfile}`);
  initEngine({ forceLite: nextProfile === 'lite-single', forceAsm: nextProfile === 'asm', isFallback: true });
  return true;
}
function initEngine({ forceLite = false, forceAsm = false, isFallback = false } = {}) {
  let selectedEngine = 'lite-single';
  try {
    if (!isFallback) engineInitFallbacksTried = new Set();
    selectedEngine = forceAsm ? 'asm' : forceLite ? 'lite-single' : resolveEngineProfile(settings.botEngine, { deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency });
    engineInitFallbacksTried.add(selectedEngine);
    const engineFile = engineAssetFile(selectedEngine);
    const enginePath = new URL(`${import.meta.env.BASE_URL}engine/${engineFile}`, window.location.href).href;
    const worker = new Worker(enginePath);
    engineWorker = worker;
    worker.onmessage = event => {
      // A retired worker may have a queued message task; never let it mutate the
      // state or feed a result to the newly-created worker session.
      if (engineWorker !== worker) return;
      const line = typeof event.data === 'string' ? event.data : String(event.data?.data || event.data || '');
      if (line.includes('uciok') && !engineUciInitialized) {
        engineUciInitialized = true;
        engineReady = false;
        // Configure memory and threads once. Single-thread engines may ignore Threads.
        engineWorker.postMessage('setoption name Threads value 1');
        engineWorker.postMessage(`setoption name Hash value ${preferredHashMb()}`);
        engineWorker.postMessage('setoption name MultiPV value 1');
        engineWorker.postMessage('isready');
      }
      if (line.includes('readyok') && !engineFailed) {
        if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
        engineReady = true;
        const status = $('#engineStatus');
        if (status) {
          const shownName = selectedEngine === 'full-single' ? 'Full' : selectedEngine === 'asm' ? 'ASM-JS dự phòng' : 'Lite';
          status.innerHTML = `<i></i> Stockfish ${shownName} · sẵn sàng`;
          status.classList.add('ready');
          status.title = selectedEngine === 'asm'
            ? 'Stockfish ASM-JS đã sẵn sàng. Bản này tương thích hơn nhưng có thể chậm hơn WASM.'
            : 'Stockfish đang sẵn sàng. Chạm để kiểm tra hoặc tải lại khi gặp lỗi.';
        }
        runEngineQueue();
      }
      if (/\binfo\b/.test(line) && analysisActive) receiveAnalysisInfo(line);
      if (/\binfo\b/.test(line) && reviewSession?.waiting) receiveReviewInfo(line);
      if (/\binfo\b/.test(line) && pendingCoachAnalysis) receiveCoachAnalysisInfo(line);
      const scoreMatch = line.match(/\bscore (cp|mate) (-?\d+)/);
      if (scoreMatch && engineSearchActive && !analysisActive && !reviewSession) {
        const rawScore = Number(scoreMatch[2]);
        const whiteScore = rawScore * (game.turn() === 'b' ? -1 : 1);
        const score = scoreMatch[1] === 'mate'
          ? `${whiteScore < 0 ? '-' : ''}M${Math.abs(whiteScore)}`
          : `${whiteScore > 0 ? '+' : ''}${(whiteScore / 100).toFixed(1)}`;
        const label = $('#evalNumber');
        if (label) label.textContent = score;
        updateEvaluationMeter(scoreMatch[1], rawScore, game.turn());
      }
      const bestMatch = line.match(/\bbestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000)/i);
      if (bestMatch) {
        cancelMainEngineWatchdog();
        const uci = bestMatch[1].toLowerCase();
        if (engineStopPending) {
          // Consume the terminal line for the cancelled search; never treat it as the next request.
          engineStopPending = false;
          engineSearchActive = false;
          if (engineStopTimeout) { clearTimeout(engineStopTimeout); engineStopTimeout = null; }
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          renderAnalysisPanel();
          if (queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && !clockFlagged) {
            queuedMainEngineMove = false;
            scheduleBotMove(0);
          }
          return;
        }
        engineSearchActive = false;
        if (reviewSession?.waiting) { finishReviewPosition(false); return; }
        if (pendingEngineRequest) {
          const pending = pendingEngineRequest;
          pendingEngineRequest = null;
          clearTimeout(pending.timeout);
          if (uci === '0000') pending.reject(new Error('Stockfish không trả về nước đi trong thế cờ này.'));
          else pending.resolve(uci);
          return;
        }
        if (pendingHintRequest) {
          const hint = pendingHintRequest;
          pendingHintRequest = null;
          clearTimeout(hint.timeout);
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          const resumeQueuedMainMove = queuedMainEngineMove;
          queuedMainEngineMove = false;
          if (hint.epoch === gameEpoch && hint.fen === game.fen()) {
            const move = hint.legal.find(candidate => uciForMove(candidate) === uci);
            if (move) setHintSuggestion(move, 'Stockfish');
            toast(move ? `Gợi ý Stockfish: ${move.san} (${uci})` : 'Stockfish chưa trả về được gợi ý hợp lệ.', move ? 'success' : '');
            if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
            if ($('#evalNumber')) $('#evalNumber').textContent = '—';
          }
          if (resumeQueuedMainMove && botThinking && mode === 'stockfish' && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) {
            scheduleBotMove(0);
          }
          return;
        }
        if (pendingCoachAnalysis) {
          const request = pendingCoachAnalysis;
          pendingCoachAnalysis = null;
          clearTimeout(request.timeout);
          engineSearchActive = false;
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
          if (request.epoch !== gameEpoch || request.fen !== game.fen()) request.reject(new Error('Thế cờ đã thay đổi trong khi Stockfish phân tích; hãy gửi lại câu hỏi.'));
          else request.resolve([...request.variants.values()].sort((a, b) => a.multipv - b.multipv));
          return;
        }
        if (analysisActive) {
          const currentSession = isCurrentAnalysisSession({ active: analysisActive, sessionFen: analysisFen, currentFen: game.fen(), sessionEpoch: analysisEpoch, currentEpoch: gameEpoch });
          analysisActive = false;
          if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
          analysisFen = '';
          analysisEpoch = -1;
          if (!currentSession) { analysisVariants = []; analysisVisible = false; }
          try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
          renderAnalysisPanel();
          return;
        }
        const searchedEpoch = mainEngineSearchEpoch;
        const searchedFen = mainEngineSearchFen;
        mainEngineSearchEpoch = -1;
        mainEngineSearchFen = '';
        if (searchedEpoch !== gameEpoch || !searchedFen || searchedFen !== game.fen()) {
          if (queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && game.turn() !== humanColor) {
            queuedMainEngineMove = false;
            scheduleBotMove(0);
          }
          return;
        }
        if (botThinking && mode === 'stockfish' && !game.isGameOver()) {
          botThinking = false;
          applyUciMove(uci);
        }
      }
    };
    worker.onerror = () => {
      if (engineWorker !== worker) return;
      // Only switch engines during startup. Runtime failures go through the normal
      // cleanup path so pending searches cannot leak into a second worker.
      if (!engineReady && tryEngineInitFallback(selectedEngine)) return;
      failEngine(selectedEngine === 'asm'
        ? 'Stockfish ASM-JS cũng không khởi tạo được. Hãy chạy build sạch và kiểm tra tệp engine trong APK.'
        : `Không tải được tệp Stockfish ${selectedEngine === 'full-single' ? 'Full' : 'Lite'}. Đang kiểm tra engine và có thể thử lại.`);
    };
    worker.postMessage('uci');
    // Full can take much longer to load; Lite uses a stricter watchdog. ASM has no WASM.
    engineInitTimeout = setTimeout(() => {
      if (engineWorker !== worker || engineReady || engineFailed) return;
      if (tryEngineInitFallback(selectedEngine)) return;
      failEngine(`Stockfish ${selectedEngine === 'asm' ? 'ASM-JS' : selectedEngine === 'full-single' ? 'Full' : 'Lite'} khởi tạo quá lâu. Kiểm tra tệp JS/WASM và thử tải lại.`);
    }, selectedEngine === 'full-single' ? 45000 : selectedEngine === 'asm' ? 12000 : 20000);
  } catch (error) {
    if (!isFallback && !engineInitFallbacksTried.has(selectedEngine)) engineInitFallbacksTried.add(selectedEngine);
    if (tryEngineInitFallback(selectedEngine)) return;
    failEngine('Không thể khởi tạo Stockfish. Kiểm tra các tệp engine và thử tải lại.');
  }
}
function failEngine(message) {
  const wasThinking = botThinking && mode === 'stockfish' && !game.isGameOver();
  retireStockfishWorker(message);
  addAppNotification({ title: 'Stockfish chưa sẵn sàng', message, type: 'error' });
  if (!wasThinking) toast(message);
  // Do not leave a human waiting forever if the engine fails during their turn.
  if (wasThinking) {
    botThinking = false;
    const move = chooseFallbackMove();
    if (move) applyUciMove(uciForMove(move));
    else renderView();
    toast('Stockfish bị lỗi; đã chuyển sang bot dự phòng với nước đi hợp lệ.');
  }
}

function runEngineQueue() {
  if (!engineWorker || !engineReady || !engineQueue.length) return;
  const next = engineQueue.shift();
  if (next) next();
}
function askStockfishMove() {
  if (mode !== 'stockfish' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const requestedStrength = settings.botStrengthMode === 'elo' ? resolveStockfishStrength(settings.botElo) : null;
  if (settings.openingBookEnabled && game.history().length < 14 && requestedStrength?.mode !== 'beginner-simulated') {
    const bookMove = findOpeningBookMove(game, OPENINGS, { maxPlies: 14, recentChoices: recentOpeningChoices });
    if (bookMove) {
      botThinking = false;
      applyUciMove(uciForMove(bookMove));
      return;
    }
  }
  // Stockfish's weakest native setting is still substantially stronger than beginner Elo.
  // Below its supported UCI_Elo floor, mix in legal heuristic moves to lower practical strength.
  if (requestedStrength?.mode === 'beginner-simulated' && Math.random() < requestedStrength.heuristicMoveProbability) {
    const weakerMove = chooseBeginnerMoveFor(game, requestedStrength);
    if (weakerMove) {
      botThinking = false;
      applyUciMove(uciForMove(weakerMove));
      return;
    }
  }
  if (pendingEngineRequest) { toast('Stockfish đang xử lý một ván khác.'); return; }
  if (engineSearchActive || engineStopPending) { queuedMainEngineMove = true; return; }
  if (!engineWorker || !engineReady || engineFailed) {
    const move = chooseFallbackMove();
    botThinking = false;
    if (move) {
      applyUciMove(uciForMove(move));
      toast('Stockfish chưa sẵn sàng — đang dùng bot dự phòng.', '');
    } else {
      renderView();
    }
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = gameEpoch;
  mainEngineSearchFen = game.fen();
  const skill = Math.max(0, Math.min(20, Number(settings.botSkill ?? 8)));
  const depth = Math.max(5, Math.min(30, Number(settings.botDepth || 18)));
  $('#boardStatus') && ($('#boardStatus').textContent = 'Stockfish đang suy nghĩ…');
  $('#evalNumber') && ($('#evalNumber').textContent = '…');
  engineWorker.postMessage('stop');
  if (settings.botStrengthMode === 'elo') {
    const strength = resolveStockfishStrength(settings.botElo);
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strength.limitStrength ? 'true' : 'false'}`);
    if (strength.uciElo != null) engineWorker.postMessage(`setoption name UCI_Elo value ${strength.uciElo}`);
    engineWorker.postMessage(`setoption name Skill Level value ${strength.skillLevel}`);
  } else {
    engineWorker.postMessage('setoption name UCI_LimitStrength value false');
    engineWorker.postMessage(`setoption name Skill Level value ${skill}`);
  }
  engineWorker.postMessage('setoption name MultiPV value 1');
  engineWorker.postMessage(`position fen ${game.fen()}`);
  const moveTimeMs = Math.max(500, Math.min(5000, Number(settings.botMoveTimeMs) || 1200));
  engineWorker.postMessage(`go movetime ${moveTimeMs} depth ${depth}`);
  if (mainEngineTimer) clearTimeout(mainEngineTimer);
  const watchdogMs = Math.max(12000, Math.min(30000, moveTimeMs * 6));
  mainEngineTimer = setTimeout(() => {
    mainEngineTimer = null;
    if (!botThinking || mode !== 'stockfish' || pendingEngineRequest || !engineSearchActive) return;
    botThinking = false;
    retireStockfishWorker('Stockfish không phản hồi đúng hạn.');
    const fallback = chooseFallbackMove();
    if (fallback) applyUciMove(uciForMove(fallback));
    else renderView();
    toast('Stockfish không phản hồi đúng hạn; đã dùng bot dự phòng. Chạm trạng thái engine để thử tải lại.');
  }, watchdogMs);
}
function chooseFallbackMove() { return chooseFallbackMoveFor(game); }
function chooseBeginnerMoveFor(chess, strength) {
  const legalMoves = chess.moves({ verbose: true });
  if (!legalMoves.length) return null;
  // Very low targets need more than Stockfish Skill Level 0: sometimes deliberately
  // choose a random legal move, but never bypass chess.js legality validation.
  if (Math.random() < Math.max(0, Math.min(1, Number(strength?.randomLegalMoveProbability) || 0))) {
    return legalMoves[Math.floor(Math.random() * legalMoves.length)];
  }
  return chooseFallbackMoveFor(chess);
}
function chooseFallbackMoveFor(chess) {
  const moves = chess.moves({ verbose: true });
  if (!moves.length) return null;
  // A small material/capture/center heuristic keeps the legal-move fallback useful, but it is not Stockfish strength.
  const values = { p: 1, n: 3.1, b: 3.3, r: 5, q: 9, k: 0 };
  const scored = moves.map(move => {
    let score = Math.random() * 1.6;
    if (move.captured) score += 2 + values[move.captured] * 0.9 - values[move.piece] * 0.1;
    if (move.san.includes('+')) score += 1.1;
    if (move.san.includes('#')) score += 500;
    if (move.promotion) score += 8;
    const file = move.to.charCodeAt(0) - 97, rank = Number(move.to[1]) - 1;
    score += (3.5 - Math.abs(3.5 - file)) * 0.07 + (3.5 - Math.abs(3.5 - rank)) * 0.07;
    return { move, score };
  }).sort((a,b) => b.score - a.score);
  return scored[Math.floor(Math.random() * Math.min(4, scored.length))]?.move || scored[0].move;
}
function applyUciMove(uci) {
  if (clockFlagged) { botThinking = false; return; }
  tickClock();
  if (clockFlagged) { botThinking = false; return; }
  const mover = game.turn();
  try {
    const from = uci.slice(0, 2), to = uci.slice(2, 4), promotion = uci[4];
    const made = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!made) throw new Error('Stockfish returned an invalid move.');
    playBoardSound(made, game, settings.soundEnabled);
    lastHintMove = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: made.from, to: made.to };
    currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening;
    botThinking = false;
    if (game.isGameOver() || currentView !== 'play') renderView();
    else renderBoard();
    if (game.isGameOver()) { stopClock(); toast(game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.', 'success'); }
    else if (currentView === 'play') queryOpeningExplorer(false);
  } catch (error) { botThinking = false; toast(`Lỗi nước đi engine: ${error.message}`); renderView(); }
}
function chessUciHistory() { return game.history({ verbose: true }).map(m => `${m.from}${m.to}${m.promotion || ''}`).join(','); }

async function askAiMove() {
  if (mode !== 'ai' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const requestEpoch = gameEpoch;
  const requestedFen = game.fen();
  const legal = game.moves({ verbose: true });
  if (!legal.length) { botThinking = false; renderView(); return; }
  const moveController = new AbortController();
  apiMoveAbortController = moveController;
  const prompt = `Bạn là engine cờ vua. Chỉ chọn đúng MỘT nước trong danh sách nước hợp lệ sau, ở định dạng UCI 4 hoặc 5 ký tự (ví dụ e7e8q). Không giải thích, không Markdown. FEN: ${requestedFen}\nNước hợp lệ: ${legal.map(m => `${m.from}${m.to}${m.promotion || ''}`).join(' ')}\nHãy trả lời chỉ bằng UCI.`;
  const requestAiMove = (retry = false) => apiFetch('/api/ai/chat', {
    method: 'POST', signal: moveController.signal, timeoutMs: retry ? 48_000 : 28_000,
    body: JSON.stringify({
      mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: modelOverride,
      temperature: 0, maxTokens: retry ? 180 : 96, timeoutMs: retry ? 42_000 : 25_000,
      system: retry ? 'Chỉ xuất đúng một mã UCI hợp lệ. Nếu chưa chắc, chọn một nước từ danh sách; tuyệt đối không giải thích, không Markdown.' : 'Chỉ xuất đúng một mã UCI từ danh sách hợp lệ. Không giải thích, không Markdown.',
      messages: [{ role: 'user', content: retry ? `${prompt}\nHãy trả lời một UCI cuối cùng ngay bây giờ; không gửi suy nghĩ hoặc trạng thái trung gian.` : prompt }]
    })
  });
  try {
    let response;
    try { response = await requestAiMove(false); }
    catch (error) {
      if (!/chưa có câu trả lời văn bản|không trả trường văn bản tương thích|không có nội dung văn bản/i.test(String(error?.message || error))) throw error;
      response = await requestAiMove(true);
    }
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    const uci = String(response.text || '').match(/[a-h][1-8][a-h][1-8][qrbn]?/i)?.[0]?.toLowerCase();
    const allowed = legal.some(m => `${m.from}${m.to}${m.promotion || ''}` === uci);
    if (!allowed) throw new Error('AI trả về nước không hợp lệ.');
    botThinking = false; applyUciMove(uci);
  } catch (error) {
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    botThinking = false;
    let fallbackUci = '';
    // Keep the game playable: use the real local engine when available, not a random legal move.
    try {
      if (engineWorker && engineReady && !engineFailed && !pendingEngineRequest && !engineSearchActive) {
        fallbackUci = await requestStockfishUci(requestedFen, { skill: settings.botSkill, depth: 16, moveTimeMs: 900, timeoutMs: 7000 });
      }
    } catch { /* Continue to the legal-move fallback below. */ }
    if (requestEpoch !== gameEpoch || requestedFen !== game.fen() || mode !== 'ai') return;
    toast(`AI API lỗi: ${friendlyApiError(error.message || error)}. ${fallbackUci ? 'Đã chuyển sang Stockfish nội bộ.' : 'Đang dùng nước hợp lệ dự phòng; đây không phải nước Stockfish tính.'}`);
    if (fallbackUci && legal.some(m => `${m.from}${m.to}${m.promotion || ''}` === fallbackUci)) applyUciMove(fallbackUci);
    else { const move = chooseFallbackMove(); if (move) applyUciMove(uciForMove(move)); else renderView(); }
  } finally {
    if (apiMoveAbortController === moveController) apiMoveAbortController = null;
  }
}

// Arena: each configured model plays by proposing one UCI move from the legal-move list.
// chess.js validates every move, while Stockfish remains the tactical engine.
function arenaCandidates() {
  const candidates = [
    { id: 'stockfish', name: 'Stockfish 19 Lite · nội bộ', type: 'stockfish' },
    { id: 'current', name: `AI hiện tại · ${settings.model || 'chưa đặt model'}`, type: 'llm', aiMode: settings.aiMode, endpoint: settings.endpoint, model: settings.model, apiKey: settings.apiKey }
  ];
  for (const profile of (Array.isArray(settings.aiProfiles) ? settings.aiProfiles : []).slice(0, 20)) {
    candidates.push({ ...profile, type: 'llm' });
  }
  return candidates;
}
function arenaPlayer(id) {
  return arenaCandidates().find(player => player.id === id) || null;
}
function renderArenaOptions(selectedId) {
  return arenaCandidates().map(player => `<option value="${esc(player.id)}" ${player.id === selectedId ? 'selected' : ''}>${esc(player.name)}${player.type === 'stockfish' ? ' · engine' : ' · API'}</option>`).join('');
}
function renderArenaProfiles() {
  const profiles = (Array.isArray(settings.aiProfiles) ? settings.aiProfiles : []).slice(0, 20);
  if (!profiles.length) return '<div class="empty-state small-empty">Chưa thêm AI riêng. Hãy thêm endpoint/model bên dưới, hoặc chọn AI hiện tại trong cài đặt.</div>';
  return profiles.map(profile => `<div class="arena-profile-row"><div class="arena-profile-avatar">✦</div><div class="arena-profile-info"><b>${esc(profile.name)}</b><small>${esc(profile.model)} · ${esc(profile.aiMode === 'gemini' ? 'Gemini' : profile.aiMode === 'anthropic' ? 'Anthropic' : 'OpenAI-compatible')}</small><small class="arena-endpoint">${esc(profile.endpoint)}</small></div><button class="mini-primary arena-test-profile" type="button" data-test-profile="${esc(profile.id)}">Kiểm tra</button><button class="tiny-btn arena-delete-profile" type="button" data-delete-profile="${esc(profile.id)}" aria-label="Xóa ${esc(profile.name)}">×</button></div>`).join('');
}
function renderArenaView() {
  const players = arenaCandidates();
  const validLeague = new Set(players.map(p => p.id));
  for (const id of [...arenaSelectedLeague]) if (!validLeague.has(id)) arenaSelectedLeague.delete(id);
  if (!arenaSelectedLeague.size) { arenaSelectedLeague.add('stockfish'); arenaSelectedLeague.add('current'); }
  const leagueChecks = players.map(player => `<label class="arena-check"><input type="checkbox" class="arena-participant-check" value="${esc(player.id)}" ${arenaSelectedLeague.has(player.id) ? 'checked' : ''}/><span><b>${esc(player.name)}</b><small>${player.type === 'stockfish' ? 'Engine cục bộ · không tốn API' : `${esc(player.aiMode === 'gemini' ? 'Gemini' : player.aiMode === 'anthropic' ? 'Anthropic' : 'API tương thích OpenAI')} · gọi API theo từng lượt`}</small></span></label>`).join('');
  return `<section class="content-page arena-page">
    <div class="page-intro"><div class="eyebrow">CHESS BOT ARENA</div><h1>Đấu trường giao lưu AI</h1><p>Cho Stockfish và nhiều mô hình AI đấu với nhau tự động. Mỗi AI nhận FEN cùng danh sách nước hợp lệ; ứng dụng xác thực nước bằng luật cờ trước khi đi. Bạn có thể ghép bất kỳ hai AI đã cấu hình, hoặc chạy một giải vòng tròn giữa các AI đã chọn.</p></div>
    <div class="arena-warning"><span>ⓘ</span><p><b>Minh bạch:</b> Stockfish là engine cờ chuyên dụng; các LLM chỉ chọn nước qua API và có thể yếu hơn, chậm hoặc trả lỗi. Chess Bot sẽ kiểm tra nước đi và dùng nước dự phòng hợp lệ nếu API hỏng. Mỗi lượt LLM có thể tiêu thụ hạn mức API.</p></div>
    <div class="arena-layout">
      <div class="arena-left">
        <section class="panel arena-board-panel"><div class="arena-live-heading"><div><small class="eyebrow">VÁN ĐANG DIỄN RA</small><h2 id="arenaMatchTitle">${esc(arenaCurrentPlayers.w?.name || 'Stockfish')} vs ${esc(arenaCurrentPlayers.b?.name || 'AI hiện tại')}</h2></div><span id="arenaLiveBadge" class="arena-live-badge ${arenaRunning ? 'is-live' : ''}">${arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'}</span></div>
          <div class="arena-board-frame"><div id="arenaBoard" class="arena-board" aria-label="Bàn cờ đấu trường AI"></div></div>
          <div class="arena-status-row"><span id="arenaStatus">${esc(arenaLastResult || positionStatus(arenaGame))}</span><b id="arenaPlyCount">${arenaGame.history().length} nửa nước đi</b></div><div id="arenaFallbackNote" class="arena-fallback-note">${esc(arenaLastNote || 'Nước đi của từng AI sẽ hiển thị tại đây.')}</div>
          <div class="arena-controls"><button id="arenaRunMatch" class="primary-btn" ${arenaRunning ? 'disabled' : ''}>▶ Đấu trận này</button><button id="arenaRunLeague" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>⚔ Giải giao lưu</button><button id="arenaStop" class="danger-btn" ${arenaRunning ? '' : 'disabled'}>■ Dừng</button></div>
          <div class="arena-controls secondary-arena-controls"><button id="arenaSwapRematch" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>⇄ Đổi màu & đấu lại</button><button id="arenaReset" class="secondary-btn" ${arenaRunning ? 'disabled' : ''}>↺ Ván mới</button><button id="arenaDownloadPGN" class="secondary-btn" ${(arenaGame.history().length || arenaPgnArchive.length) ? '' : 'disabled'}>↓ Tải PGN</button></div>
          <div id="arenaLeagueSummary" class="arena-league-summary">${esc(arenaTournamentSummary || 'Chọn các đối thủ bên phải để bắt đầu giải giao lưu.')}</div>
        </section>
        <section class="panel arena-moves-panel"><div class="panel-heading"><div><small class="eyebrow">BIÊN BẢN</small><h2>Nước đi đã xác thực</h2></div><span class="small-counter" id="arenaMoveCounter">0</span></div><div id="arenaMoveList" class="move-list arena-move-list"></div></section>
      </div>
      <div class="arena-right">
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">GHÉP CẶP</small><h2>Chọn hai đối thủ</h2></div><span class="context-icon">⚔</span></div>
          <label class="field-label" for="arenaWhite">Quân Trắng</label><select id="arenaWhite" class="field">${renderArenaOptions('stockfish')}</select>
          <label class="field-label" for="arenaBlack">Quân Đen</label><select id="arenaBlack" class="field">${renderArenaOptions('current')}</select>
          <div class="two-fields"><div><label class="field-label" for="arenaDepth">Độ sâu Stockfish</label><select id="arenaDepth" class="field">${[12,16,18,20,22,24,26,28,30].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}</option>`).join('')}</select></div><div><label class="field-label" for="arenaDelay">Khoảng nghỉ</label><select id="arenaDelay" class="field"><option value="0">Nhanh nhất</option><option value="350" selected>0,35 giây</option><option value="800">0,8 giây</option><option value="1500">1,5 giây</option></select></div></div>
          <div class="two-fields"><div><label class="field-label" for="arenaPlyLimit">Giới hạn nửa nước</label><select id="arenaPlyLimit" class="field"><option value="80">80</option><option value="120" selected>120</option><option value="180">180</option><option value="240">240</option></select></div><div><label class="field-label" for="arenaSkill">Skill Stockfish</label><select id="arenaSkill" class="field">${[10,14,18,20].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}/20</option>`).join('')}</select></div></div>
          <div class="two-fields"><div><label class="field-label" for="arenaEngineMode">Giới hạn sức mạnh</label><select id="arenaEngineMode" class="field"><option value="max" selected>Tối đa</option><option value="elo">Giới hạn Elo</option></select></div><div><label class="field-label" for="arenaEngineElo">Elo mục tiêu</label><select id="arenaEngineElo" class="field">${Array.from({ length: 28 }, (_, i) => 500 + i * 100).map(n=>`<option value="${n}" ${n===2600?'selected':''}>${n}</option>`).join('')}</select></div></div><div class="field-hint">Skill 20 + độ sâu cao sẽ mạnh hơn nhưng chậm hơn trên điện thoại. Chọn Tối đa để Stockfish chơi hết sức; Elo chỉ là mức giới hạn ước lượng, không phải xếp hạng được chứng nhận.</div>
        </section>
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">GIẢI VÒNG TRÒN</small><h2>Chọn những AI tham gia</h2></div><span class="small-counter">${players.length}</span></div><div class="arena-participant-list">${leagueChecks}</div><div class="field-hint">Mỗi cặp chơi hai ván và đổi màu để công bằng hơn. Tối đa 6 AI (tối đa 30 ván cho một giải); mỗi nước LLM có thể tiêu thụ API. Nếu API lỗi, nước dự phòng sẽ được đánh dấu trong kết quả.</div></section>
        <section class="panel"><div class="panel-heading"><div><small class="eyebrow">THÊM NHÀ CUNG CẤP</small><h2>Thêm AI giao lưu</h2></div><span class="context-icon">＋</span></div>
          <label class="field-label" for="arenaProfileName">Tên hiển thị</label><input id="arenaProfileName" class="field" maxlength="40" placeholder="Ví dụ: DeepSeek Chess"/>
          <label class="field-label" for="arenaProviderPreset">Nhà cung cấp nhanh</label><select id="arenaProviderPreset" class="field"><option value="custom">Endpoint tùy chỉnh</option><option value="openrouter">OpenRouter · nhiều model</option><option value="openai">OpenAI API</option><option value="anthropic">Anthropic API</option><option value="gemini">Google Gemini API</option><option value="groq">Groq</option><option value="deepseek">DeepSeek</option><option value="mistral">Mistral AI</option><option value="cerebras">Cerebras</option><option value="xai">xAI</option><option value="ollama">Ollama local</option><option value="together">Together AI</option><option value="fireworks">Fireworks AI</option></select>
          <label class="field-label" for="arenaProfileMode">Kiểu API</label><select id="arenaProfileMode" class="field"><option value="openai-compatible">OpenAI-compatible</option><option value="gemini">Google Gemini</option><option value="anthropic">Anthropic Messages API</option></select>
          <label class="field-label" for="arenaProfileEndpoint">Endpoint / Base URL</label><input id="arenaProfileEndpoint" class="field" placeholder="https://api.openai.com/v1"/>
          <label class="field-label" for="arenaProfileModel">Model ID</label><input id="arenaProfileModel" class="field" placeholder="ID chính xác từ nhà cung cấp"/>
          <label class="field-label" for="arenaProfileKey">API key</label><input id="arenaProfileKey" type="password" autocomplete="off" class="field" placeholder="Key của AI này"/>
          <div class="field-hint">Hồ sơ được lưu trên thiết bị trong localStorage để dễ dùng; đừng dùng trên máy dùng chung. Bảo vệ tốt hơn bằng backend riêng, xác thực và quota.</div>
          <button id="arenaAddProfile" class="primary-btn full-width">＋ Lưu AI vào đấu trường</button><div id="arenaProfileNotice" class="connection-result"></div>
          <div class="arena-profile-list">${renderArenaProfiles()}</div>
        </section>
      </div>
    </div>
  </section>`;
}
function renderArenaPosition() {
  const board = $('#arenaBoard');
  if (!board) return;
  const rows = [8,7,6,5,4,3,2,1], files = ['a','b','c','d','e','f','g','h'];
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = arenaGame.get(sq);
    const last = arenaLastMove && (arenaLastMove.from === sq || arenaLastMove.to === sq);
    html += `<div class="arena-square ${squareColor(sq)} ${last ? 'arena-last-move' : ''}" aria-label="${sq}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</div>`;
  }));
  board.innerHTML = html;
  syncArenaBoardLayout();
  const status = $('#arenaStatus');
  if (status) status.textContent = arenaRunning ? `${arenaCurrentPlayers[arenaGame.turn()]?.name || 'AI'} đang suy nghĩ…` : (arenaLastResult || positionStatus(arenaGame));
  const title = $('#arenaMatchTitle');
  if (title) title.textContent = `${arenaCurrentPlayers.w?.name || 'Stockfish'} vs ${arenaCurrentPlayers.b?.name || 'AI hiện tại'}`;
  const badge = $('#arenaLiveBadge');
  if (badge) { badge.textContent = arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'; badge.classList.toggle('is-live', arenaRunning); }
  const ply = $('#arenaPlyCount'); if (ply) ply.textContent = `${arenaGame.history().length} nửa nước đi`;
  const counter = $('#arenaMoveCounter'); if (counter) counter.textContent = String(arenaGame.history().length);
  const note = $('#arenaFallbackNote'); if (note) note.textContent = arenaLastNote || 'Các nước của AI sẽ hiện tại đây.';
  const moveList = $('#arenaMoveList');
  if (moveList) {
    const history = arenaGame.history();
    if (!history.length) moveList.innerHTML = '<div class="empty-state">Chưa có nước đi. Bắt đầu một trận để hai AI chơi tự động.</div>';
    else {
      let rows = '';
      for (let i = 0; i < history.length; i += 2) rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2)+1}.</span><span class="move-san">${esc(history[i])}</span><span class="move-san">${esc(history[i+1] || '…')}</span></div>`;
      moveList.innerHTML = rows; moveList.scrollTop = moveList.scrollHeight;
    }
  }
  ['arenaRunMatch','arenaRunLeague','arenaSwapRematch','arenaReset','arenaDownloadPGN'].forEach(id => { const button = $(`#${id}`); if (button) button.disabled = arenaRunning || (id === 'arenaDownloadPGN' && !arenaGame.history().length && !arenaPgnArchive.length); });
  const stop = $('#arenaStop'); if (stop) stop.disabled = !arenaRunning;
}
function wireArenaActions() {
  $('#arenaRunMatch')?.addEventListener('click', () => { unlockBoardSound(); startArenaMatch($('#arenaWhite').value, $('#arenaBlack').value); });
  $('#arenaRunLeague')?.addEventListener('click', () => { unlockBoardSound(); runArenaLeague(); });
  $('#arenaStop')?.addEventListener('click', stopArenaMatch);
  $('#arenaReset')?.addEventListener('click', () => { if (arenaRunning) return; arenaGame = new Chess(); arenaLastMove = null; arenaLastResult = ''; arenaLastNote = ''; arenaLastPgnResult = '*'; arenaPgnArchive = []; renderArenaPosition(); });
  $('#arenaSwapRematch')?.addEventListener('click', () => { if (arenaRunning) return; unlockBoardSound(); const w = $('#arenaWhite').value; $('#arenaWhite').value = $('#arenaBlack').value; $('#arenaBlack').value = w; startArenaMatch($('#arenaWhite').value, $('#arenaBlack').value); });
  $('#arenaDownloadPGN')?.addEventListener('click', downloadArenaPgn);
  $$('.arena-participant-check').forEach(input => input.addEventListener('change', () => { if (input.checked) arenaSelectedLeague.add(input.value); else arenaSelectedLeague.delete(input.value); }));
  $$('[data-test-profile]').forEach(button => button.addEventListener('click', () => testArenaProfile(button.dataset.testProfile, button)));
  $$('[data-delete-profile]').forEach(button => button.addEventListener('click', () => {
    if (arenaRunning) return;
    const id = button.dataset.deleteProfile;
    settings.aiProfiles = (settings.aiProfiles || []).filter(profile => profile.id !== id);
    arenaSelectedLeague.delete(id); const saved = saveSettings(); renderView(); toast(saved ? 'Đã xóa hồ sơ AI khỏi đấu trường.' : 'Đã xóa trong phiên hiện tại, nhưng không lưu được vào thiết bị.');
  }));
  const presets = {
    custom: null,
    openai: { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' },
    openrouter: { mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1' },
    anthropic: { mode: 'anthropic', endpoint: 'https://api.anthropic.com' },
    gemini: { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' },
    groq: { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' },
    deepseek: { mode: 'openai-compatible', endpoint: 'https://api.deepseek.com/v1' },
    mistral: { mode: 'openai-compatible', endpoint: 'https://api.mistral.ai/v1' },
    cerebras: { mode: 'openai-compatible', endpoint: 'https://api.cerebras.ai/v1' },
    xai: { mode: 'openai-compatible', endpoint: 'https://api.x.ai/v1' },
    ollama: { mode: 'openai-compatible', endpoint: 'http://localhost:11434/v1' },
    together: { mode: 'openai-compatible', endpoint: 'https://api.together.xyz/v1' },
    fireworks: { mode: 'openai-compatible', endpoint: 'https://api.fireworks.ai/inference/v1' }
  };
  $('#arenaProviderPreset')?.addEventListener('change', event => {
    const preset = presets[event.target.value]; if (!preset) return;
    $('#arenaProfileMode').value = preset.mode; $('#arenaProfileEndpoint').value = preset.endpoint;
    const labels = { openai:'OpenAI', openrouter:'OpenRouter', anthropic:'Anthropic', gemini:'Gemini', groq:'Groq', deepseek:'DeepSeek', mistral:'Mistral', cerebras:'Cerebras', xai:'xAI', ollama:'Ollama', together:'Together AI', fireworks:'Fireworks AI' };
    if (!$('#arenaProfileName').value.trim()) $('#arenaProfileName').value = labels[event.target.value] || '';
  });
  $('#arenaProfileMode')?.addEventListener('change', event => {
    if (event.target.value === 'gemini') $('#arenaProfileEndpoint').value = 'https://generativelanguage.googleapis.com';
    else if (event.target.value === 'anthropic') $('#arenaProfileEndpoint').value = 'https://api.anthropic.com';
    else if (!$('#arenaProfileEndpoint').value.trim() || ['https://generativelanguage.googleapis.com','https://api.anthropic.com'].includes($('#arenaProfileEndpoint').value.trim())) $('#arenaProfileEndpoint').value = 'https://api.openai.com/v1';
  });
  $('#arenaAddProfile')?.addEventListener('click', saveArenaProfile);
}
async function testArenaProfile(id, button) {
  const player = arenaPlayer(id);
  if (!player) return;
  const original = button?.textContent || 'Kiểm tra';
  if (button) { button.disabled = true; button.textContent = 'Đang thử…'; }
  try {
    const response = await apiFetch('/api/ai/chat', { method: 'POST', body: JSON.stringify({ mode: player.aiMode, endpoint: player.endpoint, apiKey: player.apiKey || '', model: player.model, temperature: 0, system: 'Trả lời thật ngắn.', messages: [{ role: 'user', content: 'Reply exactly: CHESS_BOT_OK' }] }) });
    toast(`${player.name}: kết nối được (${String(response.text || '').trim().slice(0, 40)})`, 'success');
  } catch (error) { toast(`${player.name}: ${String(error.message || error).slice(0, 140)}`); }
  finally { if (button) { button.disabled = false; button.textContent = original; } }
}
function saveArenaProfile() {
  if (arenaRunning) { toast('Không thể thay đổi hồ sơ trong lúc đang đấu.'); return; }
  const name = $('#arenaProfileName')?.value.trim();
  const aiMode = $('#arenaProfileMode')?.value || 'openai-compatible';
  const endpoint = $('#arenaProfileEndpoint')?.value.trim();
  const model = $('#arenaProfileModel')?.value.trim();
  const apiKey = $('#arenaProfileKey')?.value.trim() || '';
  const notice = $('#arenaProfileNotice');
  if (!name || !endpoint || !model) { if (notice) notice.textContent = 'Hãy nhập tên, endpoint và model ID.'; return; }
  if (aiMode !== 'openai-compatible' && !apiKey) { if (notice) notice.textContent = 'Nhà cung cấp này cần API key.'; return; }
  if (!isSafeHttpEndpoint(endpoint)) { if (notice) notice.textContent = 'Endpoint phải là URL HTTP(S) hợp lệ, không chứa tên đăng nhập hoặc mật khẩu.'; return; }
  const profiles = Array.isArray(settings.aiProfiles) ? settings.aiProfiles : [];
  if (profiles.length >= 20) { if (notice) notice.textContent = 'Đã đạt giới hạn 20 hồ sơ AI riêng. Hãy xóa hồ sơ không dùng trước.'; return; }
  const id = `profile-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
  settings.aiProfiles = [...profiles, { id, name, aiMode, endpoint: endpoint.replace(/\/$/, ''), model, apiKey }];
  const saved = saveSettings(); arenaSelectedLeague.add(id); renderView(); toast(saved ? `Đã thêm ${name} vào đấu trường.` : `Đã thêm ${name} trong phiên hiện tại nhưng chưa lưu được.`, saved ? 'success' : '');
}
function arenaDelay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function requestStockfishUci(fen, { skill = 20, depth = 18, strengthMode = 'max', elo = 3190, moveTimeMs = null, timeoutMs = null } = {}) {
  const effectiveMoveTimeMs = Math.max(700, Math.min(4000, Number(moveTimeMs) || Math.round(Math.max(5, Math.min(30, Number(depth) || 18)) * 75)));
  const effectiveTimeoutMs = Number(timeoutMs) || Math.max(12000, Math.min(30000, effectiveMoveTimeMs * 6));
  if (!engineWorker || engineFailed) throw new Error('Stockfish chưa sẵn sàng; kiểm tra gói engine sau npm install.');
  const readyStarted = Date.now();
  while (!engineReady && !engineFailed && Date.now() - readyStarted < 20000) await arenaDelay(100);
  if (!engineReady || engineFailed) throw new Error('Chờ Stockfish quá lâu hoặc engine lỗi.');
  if (engineStopPending || pendingEngineRequest || engineSearchActive) throw new Error('Stockfish đang xử lý hoặc đóng một yêu cầu khác. Hãy thử lại sau.');
  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (pendingEngineRequest?.resolve === resolve) {
        pendingEngineRequest = null;
        engineSearchActive = false;
        retireStockfishWorker('Stockfish quá thời gian suy nghĩ.');
        reject(new Error('Stockfish quá thời gian suy nghĩ; engine đã được dừng để tránh nhầm kết quả cũ.'));
      }
    }, effectiveTimeoutMs);
    pendingEngineRequest = { resolve, reject, timeout };
    engineSearchActive = true;
    engineWorker.postMessage('stop');
    const strength = strengthMode === 'elo' ? resolveStockfishStrength(elo) : null;
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strength?.limitStrength ? 'true' : 'false'}`);
    if (strength?.uciElo != null) engineWorker.postMessage(`setoption name UCI_Elo value ${strength.uciElo}`);
    const effectiveSkill = strengthMode === 'elo' ? strength.skillLevel : Math.max(0, Math.min(20, Number(skill) || 20));
    engineWorker.postMessage(`setoption name Skill Level value ${effectiveSkill}`);
    engineWorker.postMessage('setoption name MultiPV value 1');
    engineWorker.postMessage(`position fen ${fen}`);
    engineWorker.postMessage(`go movetime ${effectiveMoveTimeMs}`);
  });
}
function uciForMove(move) { return `${move.from}${move.to}${move.promotion || ''}`; }
async function requestModelUci(player, chess) {
  if (!player.endpoint || !player.model) throw new Error(`${player.name}: cần endpoint và model ID.`);
  if (player.aiMode !== 'openai-compatible' && !player.apiKey) throw new Error(`${player.name}: chưa có API key.`);
  const legal = chess.moves({ verbose: true });
  if (!legal.length) throw new Error('Không còn nước đi hợp lệ.');
  const legalUci = legal.map(uciForMove);
  const history = chess.history({ verbose: true }).slice(-16).map(uciForMove).join(' ');
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    if (arenaStopRequested) throw new DOMException('Đã dừng trận đấu.', 'AbortError');
    const retryHint = attempt ? '\nLần trước trả về sai định dạng. Lần này chỉ được chọn chính xác một chuỗi từ danh sách legal UCI.' : '';
    const prompt = `Bạn đang trực tiếp chơi cờ vua với vai ${chess.turn() === 'w' ? 'Trắng' : 'Đen'}. Chọn nước mạnh nhất bạn có thể tìm được.\nFEN: ${chess.fen()}\nCác nước trước đó (UCI): ${history || '(ván mới)'}\nDANH SÁCH NƯỚC HỢP LỆ UCI: ${legalUci.join(' ')}\nChỉ trả lời MỘT UCI chính xác từ danh sách, không giải thích.${retryHint}`;
    try {
      const response = await apiFetch('/api/ai/chat', {
        method: 'POST',
        signal: arenaAbortController?.signal,
        timeoutMs: attempt ? 48_000 : 28_000,
        body: JSON.stringify({ mode: player.aiMode || 'openai-compatible', endpoint: player.endpoint, apiKey: player.apiKey || '', model: player.model, temperature: 0, maxTokens: attempt ? 180 : 96, timeoutMs: attempt ? 42_000 : 25_000, system: 'Chọn đúng một UCI từ danh sách. Không giải thích, không Markdown.', messages: [{ role: 'user', content: prompt }] })
      });
      const raw = String(response.text || '').replace(/```/g, '').trim().toLowerCase();
      const candidates = raw.match(/[a-h][1-8][a-h][1-8][qrbn]?/g) || [];
      const exact = candidates.find(uci => legalUci.includes(uci));
      if (exact) return exact;
      lastError = new Error(`${player.name} không trả về nước UCI hợp lệ.`);
    } catch (error) {
      if (error?.name === 'AbortError' || arenaStopRequested) throw error;
      // Only retry an explicitly empty successful upstream response; never retry auth/quota/network errors.
      if (attempt === 0 && /chưa có câu trả lời văn bản|không trả trường văn bản tương thích|không có nội dung văn bản/i.test(String(error?.message || error))) {
        lastError = error;
        continue;
      }
      lastError = error;
      throw error;
    }
  }
  throw lastError || new Error(`${player.name} không chọn được nước hợp lệ.`);
}
async function chooseArenaUci(player, chess, depth, skill, options = {}) {
  if (player.type === 'stockfish') {
    const requestedStrength = options.strengthMode === 'elo' ? resolveStockfishStrength(options.elo) : null;
    if (settings.openingBookEnabled && chess.history().length < 14 && requestedStrength?.mode !== 'beginner-simulated') {
      const bookMove = findOpeningBookMove(chess, OPENINGS, { maxPlies: 14, recentChoices: recentOpeningChoices });
      if (bookMove) return uciForMove(bookMove);
    }
    if (requestedStrength?.mode === 'beginner-simulated' && Math.random() < requestedStrength.heuristicMoveProbability) {
      const weakerMove = chooseBeginnerMoveFor(chess, requestedStrength);
      if (weakerMove) return uciForMove(weakerMove);
    }
    return requestStockfishUci(chess.fen(), { skill, depth, moveTimeMs: Math.max(700, Math.min(2200, Number(depth || 18) * 75)), strengthMode: options.strengthMode || 'max', elo: options.elo || 2600 });
  }
  try { return await requestModelUci(player, chess); }
  catch (error) {
    if (error?.name === 'AbortError' || arenaStopRequested) throw error;
    arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
    arenaLastNote = `${player.name} gặp lỗi API (${String(error.message || error).slice(0, 110)}); Chess Bot đang dùng nước dự phòng hợp lệ.`;
    renderArenaPosition();
    if (engineReady && !engineFailed && !pendingEngineRequest && !engineSearchActive) {
      try { return await requestStockfishUci(chess.fen(), { skill: 20, depth: Math.max(18, depth) }); } catch {}
    }
    const fallback = chooseFallbackMoveFor(chess);
    if (!fallback) throw new Error('Không tìm thấy nước dự phòng.');
    return uciForMove(fallback);
  }
}
function getArenaOutcome(chess, plyLimit) {
  if (chess.isCheckmate()) return { winner: chess.turn() === 'w' ? 'b' : 'w', result: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'Chiếu hết' };
  if (chess.isDraw()) return { winner: null, result: '1/2-1/2', reason: chess.isStalemate() ? 'Hòa pat' : 'Ván hòa theo luật cờ' };
  if (chess.history().length >= plyLimit) return { winner: null, result: '1/2-1/2', reason: `Chạm giới hạn ${plyLimit} nửa nước — tạm tính hòa` };
  return null;
}
async function playArenaCore(white, black, options = {}) {
  const depth = options.depth || 20, skill = options.skill ?? 20, delayMs = options.delayMs ?? 350, plyLimit = options.plyLimit || 120;
  arenaGame = new Chess(); arenaLastMove = null; arenaLastNote = ''; arenaLastResult = '';
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  arenaCurrentPlayers = { w: white, b: black };
  renderArenaPosition();
  while (arenaRunning && !arenaStopRequested && !arenaGame.isGameOver() && arenaGame.history().length < plyLimit) {
    const player = arenaCurrentPlayers[arenaGame.turn()];
    arenaLastNote = `${player.name} đang tính nước đi…`; renderArenaPosition();
    let uci;
    try { uci = await chooseArenaUci(player, arenaGame, depth, skill, options); }
    catch (error) {
      if (arenaStopRequested || error?.name === 'AbortError') break;
      if (player.type === 'stockfish') arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
      arenaLastNote = `Lỗi ${player.name}: ${String(error.message || error).slice(0, 150)}`;
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      uci = uciForMove(fallback);
    }
    if (arenaStopRequested || !arenaRunning) break;
    const legal = arenaGame.moves({ verbose: true }).map(uciForMove);
    if (!legal.includes(uci)) {
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      arenaLastNote = `${player.name} trả nước không hợp lệ; đã thay bằng một nước hợp lệ.`;
      uci = uciForMove(fallback);
    }
    try {
      const made = arenaGame.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!made) throw new Error('Nước đi bị luật cờ từ chối.');
      arenaLastMove = { from: made.from, to: made.to };
      playBoardSound(made, arenaGame, settings.soundEnabled);
    } catch (error) {
      arenaLastNote = `Bỏ qua nước không hợp lệ: ${error.message}`;
      continue;
    }
    renderArenaPosition();
    await arenaDelay(delayMs);
  }
  if (arenaGame.isGameOver() || arenaGame.history().length >= plyLimit) {
    const outcome = getArenaOutcome(arenaGame, plyLimit) || { result: '*', reason: positionStatus(arenaGame) };
    arenaLastPgnResult = outcome.result || '*';
    archiveArenaGame(white, black, arenaLastPgnResult, outcome.reason);
    arenaLastResult = `${outcome.reason} · ${outcome.result} · ${white.name} vs ${black.name}`;
    return { ...outcome, white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn() };
  }
  arenaLastPgnResult = '*';
  if (arenaGame.history().length) archiveArenaGame(white, black, '*', 'Đã dừng');
  arenaLastResult = `Đã dừng ván tại ${arenaGame.history().length} nửa nước.`;
  return { winner: null, result: '*', reason: 'Đã dừng', white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn(), stopped: true };
}
async function startArenaMatch(whiteId, blackId) {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish ở bàn Chơi cờ kết thúc rồi mới khởi động đấu trường.'); return; }
  const white = arenaPlayer(whiteId), black = arenaPlayer(blackId);
  if (!white || !black) { toast('Không tìm thấy một trong hai AI.'); return; }
  if (white.type === 'llm' && (!white.endpoint || !white.model || (white.aiMode !== 'openai-compatible' && !white.apiKey))) { toast(`Hãy cấu hình endpoint/model/API key cho ${white.name}.`); return; }
  if (black.type === 'llm' && (!black.endpoint || !black.model || (black.aiMode !== 'openai-compatible' && !black.apiKey))) { toast(`Hãy cấu hình endpoint/model/API key cho ${black.name}.`); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController(); arenaGameCounter++; arenaFallbackMoves = new Map(); arenaPgnArchive = []; arenaLastPgnResult = '*';
  renderArenaPosition();
  try {
    const result = await playArenaCore(white, black, readArenaOptions());
    if (!result.stopped) {
      const fallbackCount = arenaFallbackMoves.get(white.id) || 0;
      const otherFallback = arenaFallbackMoves.get(black.id) || 0;
      const fallbackTag = fallbackCount + otherFallback ? ` · ${fallbackCount + otherFallback} nước dùng dự phòng khi AI lỗi` : '';
      arenaTournamentSummary = `${result.white} ${result.result} ${result.black} · ${result.reason} · ${result.plies} nửa nước${fallbackTag}`;
    }
    else arenaTournamentSummary = result.reason;
    arenaLastResult = result.reason + (result.result && result.result !== '*' ? ` · ${result.result}` : '');
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Trận lỗi: ${String(error.message || error).slice(0, 180)}`; arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function readArenaOptions() {
  return { depth: Number($('#arenaDepth')?.value || 20), skill: Number($('#arenaSkill')?.value || 20), strengthMode: $('#arenaEngineMode')?.value === 'elo' ? 'elo' : 'max', elo: Number($('#arenaEngineElo')?.value || 2600), delayMs: Number($('#arenaDelay')?.value ?? 350), plyLimit: Number($('#arenaPlyLimit')?.value || 120) };
}
function stopArenaMatch() {
  if (!arenaRunning) return;
  arenaStopRequested = true;
  arenaAbortController?.abort();
  if (pendingEngineRequest && engineWorker) { try { engineWorker.postMessage('stop'); } catch {} }
  if ($('#arenaStatus')) $('#arenaStatus').textContent = 'Đang dừng sau khi yêu cầu hiện tại kết thúc…';
}
async function runArenaLeague() {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish hiện tại kết thúc.'); return; }
  const selected = [...arenaSelectedLeague].map(arenaPlayer).filter(Boolean);
  if (selected.length < 2) { toast('Hãy chọn ít nhất hai AI tham gia giải.'); return; }
  if (selected.length > 6) { toast('Để kiểm soát chi phí API, mỗi giải giới hạn tối đa 6 AI. Bỏ chọn bớt model rồi thử lại.'); return; }
  const unconfigured = selected.find(p => p.type === 'llm' && (!p.endpoint || !p.model || (p.aiMode !== 'openai-compatible' && !p.apiKey)));
  if (unconfigured) { toast(`Hãy hoàn thiện cấu hình ${unconfigured.name} trước khi chạy giải.`); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController();
  arenaPgnArchive = []; arenaLastPgnResult = '*';
  const options = readArenaOptions();
  const scores = new Map(selected.map(player => [player.id, { id: player.id, name: player.name, points: 0, wins: 0, draws: 0, losses: 0, games: 0 }]));
  const pairings = [];
  for (let i=0;i<selected.length;i++) for (let j=i+1;j<selected.length;j++) {
    pairings.push({ a:selected[i], b:selected[j], reverse:false });
    pairings.push({ a:selected[i], b:selected[j], reverse:true });
  }
  arenaFallbackMoves = new Map();
  let complete = 0;
  arenaTournamentSummary = `Đang chạy giải: 0/${pairings.length} ván · mỗi cặp đổi màu hai lượt.`;
  renderArenaPosition();
  try {
    for (let i=0;i<pairings.length;i++) {
      if (arenaStopRequested) break;
      const { a, b, reverse } = pairings[i];
      const white = reverse ? b : a, black = reverse ? a : b;
      const result = await playArenaCore(white, black, options);
      if (result.stopped) break;
      if (result.result === '1-0') { scores.get(white.id).points += 1; scores.get(white.id).wins++; scores.get(black.id).losses++; }
      else if (result.result === '0-1') { scores.get(black.id).points += 1; scores.get(black.id).wins++; scores.get(white.id).losses++; }
      else if (result.result === '1/2-1/2') { scores.get(white.id).points += .5; scores.get(black.id).points += .5; scores.get(white.id).draws++; scores.get(black.id).draws++; }
      scores.get(white.id).games++; scores.get(black.id).games++;
      complete++;
      arenaTournamentSummary = `Giải đang chạy: ${complete}/${pairings.length} ván đã xong.`;
      if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = `${arenaTournamentSummary} ${result.white} ${result.result} ${result.black}`;
      renderArenaPosition();
      await arenaDelay(200);
    }
    const table = [...scores.values()].sort((a,b)=>b.points-a.points).map((x,i)=>`${i+1}. ${x.name}: ${x.points.toFixed(1)} điểm · ${x.wins} thắng / ${x.draws} hòa / ${x.losses} thua${arenaFallbackMoves.get(x.id) ? ` · ${arenaFallbackMoves.get(x.id)} nước dự phòng` : ''}`).join('\n');
    arenaTournamentSummary = `${arenaStopRequested ? 'Giải đã dừng' : 'KẾT QUẢ GIẢI VÒNG TRÒN'} (${complete}/${pairings.length} ván)\n${table}`;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    arenaLastResult = arenaStopRequested ? 'Giải đã dừng theo yêu cầu.' : `Giải hoàn tất · ${complete} ván.`;
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Giải gặp lỗi: ${String(error.message || error).slice(0, 180)}`;
    arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function pgnEscape(value) { return String(value || '').replace(/[\\"]+/g, '').slice(0, 120); }
function archiveArenaGame(white, black, result, reason) {
  const outcome = result || '*';
  const moves = (arenaGame.pgn() || '').trim();
  const gamePgn = moves && /(?:1-0|0-1|1\/2-1\/2|\*)$/.test(moves) ? moves : `${moves}${moves ? ' ' : ''}${outcome}`;
  const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(white?.name || 'White')}"]\n[Black "${pgnEscape(black?.name || 'Black')}"]\n[Result "${outcome}"]\n[Annotator "${pgnEscape(reason || 'AI Arena')}"]`;
  arenaPgnArchive.push(`${headers}\n\n${gamePgn}`);
}
function downloadArenaPgn() {
  const pgn = arenaPgnArchive.length ? arenaPgnArchive.join('\n\n') : (() => {
    const headers = `[Event "Chess Bot AI Arena"]\n[Site "Chess Bot"]\n[White "${pgnEscape(arenaCurrentPlayers.w?.name || 'White')}"]\n[Black "${pgnEscape(arenaCurrentPlayers.b?.name || 'Black')}"]\n[Result "${arenaLastPgnResult}"]\n[Annotator "${pgnEscape(arenaLastResult || 'AI Arena')}"]`;
    return `${headers}\n\n${arenaGame.pgn() || '*'}`;
  })();
  downloadTextFile(pgn, 'chess-bot-ai-arena.pgn', 'application/x-chess-pgn;charset=utf-8');
}



function renderLeaderboardView() {
  const profile = readRatingProfile(); const history = readRatingHistory().slice().reverse();
  const rows = history.map((item, index) => `<tr><td>${history.length - index}</td><td>${esc(new Date(item.date).toLocaleDateString())}</td><td>${esc(item.opponent || 'Bot')}</td><td>${esc(item.title || item.result)}</td><td class="rating-change ${item.change > 0 ? 'positive' : item.change < 0 ? 'negative' : ''}">${item.change > 0 ? '+' : ''}${Number(item.change || 0)}</td><td>${Number(item.elo || 1200)}</td></tr>`).join('');
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">HỒ SƠ CỜ VUA</div><h1>Bảng xếp hạng</h1><p>Top 100 trực tuyến lấy từ máy chủ cộng đồng; lịch sử Elo cục bộ vẫn được giữ riêng trên thiết bị.</p></div><section class="panel server-top100-panel"><div class="panel-heading"><div><small class="eyebrow">VILA CHESS COMMUNITY</small><h2>Top 100 người chơi</h2></div><button class="secondary-btn" id="refreshTop100" type="button">↻ Làm mới</button></div><div id="serverTop100Status" class="field-hint">Đang tải bảng xếp hạng từ máy chủ…</div><div id="serverTop100Rows" class="server-top100-list"><div class="empty-state">Đang tải dữ liệu…</div></div></section><div class="rating-summary-grid"><article class="panel rating-hero"><small>ĐIỂM ELO CỦA BẠN</small><strong>${profile.elo}</strong><span>${profile.lastChange > 0 ? '+' : ''}${profile.lastChange} điểm ở ván gần nhất</span></article><article class="panel rating-stat"><small>Ván đã tính</small><strong>${profile.games}</strong></article><article class="panel rating-stat"><small>Thắng / Hòa / Thua</small><strong>${profile.wins} / ${profile.draws} / ${profile.losses}</strong></article><article class="panel rating-stat"><small>Tỉ lệ thắng</small><strong>${profile.games ? Math.round(profile.wins / profile.games * 100) : 0}%</strong></article></div><section class="panel leaderboard-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ XẾP HẠNG</small><h2>Kết quả gần đây</h2></div><span class="context-icon">♜</span></div>${rows ? `<div class="leaderboard-table-wrap"><table class="leaderboard-table"><thead><tr><th>#</th><th>Ngày</th><th>Đối thủ</th><th>Kết quả</th><th>Δ Elo</th><th>Elo</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="empty-state">Chưa có ván nào được tính Elo. Chơi một ván với Stockfish hoặc AI API để bắt đầu bảng xếp hạng.</div>'}<div class="field-hint">Điểm bắt đầu 1200 · K-factor 24 · Elo đối thủ là mức ước lượng theo cấu hình bot. Lịch sử chỉ lưu cục bộ và không đồng bộ giữa các thiết bị.</div></section></section>`;
}

function renderTop100Rows(users = []) {
  if (!users.length) return '<div class="empty-state">Chưa có tài khoản cộng đồng nào. Đăng ký ở mục Bạn bè để xuất hiện trong bảng xếp hạng.</div>';
  return users.map(user => `<article class="top100-row"><span class="top100-rank rank-${Number(user.rank) <= 3 ? Number(user.rank) : 'other'}">${Number(user.rank) <= 3 ? ['🥇','🥈','🥉'][Number(user.rank)-1] : `#${Number(user.rank)}`}</span><span class="top100-avatar">${esc((user.displayName || user.username || '?').slice(0,1).toUpperCase())}</span><span class="top100-player"><b>${esc(user.displayName || user.username)}</b><small>@${esc(user.username)} · ${user.online ? '🟢 Đang hoạt động' : `${Number(user.games || 0)} ván đã ghi nhận`}</small></span><strong class="top100-elo">${Number(user.elo || 1200)} <small>Elo</small></strong></article>`).join('');
}
async function loadTop100() {
  const rows = $('#serverTop100Rows'), status = $('#serverTop100Status');
  if (!rows) return;
  if (status) status.textContent = 'Đang tải dữ liệu từ máy chủ…';
  try {
    const data = await socialApi('/leaderboard?limit=100');
    socialState.leaderboard = Array.isArray(data.users) ? data.users : [];
    if ($('#serverTop100Rows')) $('#serverTop100Rows').innerHTML = renderTop100Rows(socialState.leaderboard);
    if ($('#serverTop100Status')) $('#serverTop100Status').textContent = `${Number(data.totalPlayers || 0)} tài khoản trên máy chủ · Cập nhật ${new Date(data.generatedAt || Date.now()).toLocaleTimeString()}. Elo mới bắt đầu ở 1200; các trận xếp hạng cần được máy chủ xác minh trước khi ghi điểm.`;
  } catch (error) {
    if ($('#serverTop100Rows')) $('#serverTop100Rows').innerHTML = `<div class="empty-state">${esc(error.message || 'Chưa kết nối được máy chủ.')}</div>`;
    if ($('#serverTop100Status')) $('#serverTop100Status').textContent = 'Không thể tải Top 100. Hãy kiểm tra địa chỉ backend trong Cài đặt và bảo đảm server đang chạy.';
  }
}
function wireLeaderboardActions() { $('#refreshTop100')?.addEventListener('click', loadTop100); loadTop100(); }

function renderFriendsView() {
  const user = socialState.user;
  const authPanel = !user ? `<div class="social-auth-grid"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN CỘNG ĐỒNG</small><h2>Đăng nhập</h2></div><span class="context-icon">♙</span></div><form id="socialLoginForm"><label class="field-label" for="socialLoginName">Tên đăng nhập hoặc email</label><input class="field" id="socialLoginName" name="username" autocomplete="username" maxlength="254" required placeholder="Tên tài khoản"/><label class="field-label" for="socialLoginPassword">Mật khẩu</label><input class="field" id="socialLoginPassword" name="password" autocomplete="current-password" type="password" minlength="12" maxlength="256" required placeholder="Tối thiểu 12 ký tự"/><button class="primary-btn full-width social-submit" type="submit">Đăng nhập</button></form><div class="social-oauth-divider"><span>hoặc đăng nhập bằng</span></div><div class="social-oauth-actions"><button class="secondary-btn" type="button" data-social-oauth="google">Google</button><button class="secondary-btn" type="button" data-social-oauth="github">GitHub</button></div><p class="field-hint">Google/GitHub chỉ hoạt động sau khi chủ server khai báo OAuth Client ID, Client Secret và callback URL. Không cần Firebase.</p></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">BẮT ĐẦU CHƠI CÙNG CỘNG ĐỒNG</small><h2>Tạo tài khoản</h2></div><span class="context-icon">✦</span></div><form id="socialRegisterForm"><label class="field-label" for="socialRegisterName">Tên đăng nhập</label><input class="field" id="socialRegisterName" name="username" autocomplete="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_.-]{3,24}" required placeholder="ví dụ: vila_player"/><label class="field-label" for="socialRegisterDisplay">Tên hiển thị</label><input class="field" id="socialRegisterDisplay" name="displayName" minlength="2" maxlength="40" required placeholder="Tên bạn muốn mọi người thấy"/><label class="field-label" for="socialRegisterEmail">Email (không bắt buộc)</label><input class="field" id="socialRegisterEmail" name="email" autocomplete="email" type="email" maxlength="254" placeholder="ban@example.com"/><label class="field-label" for="socialRegisterPassword">Mật khẩu</label><input class="field" id="socialRegisterPassword" name="password" autocomplete="new-password" type="password" minlength="12" maxlength="256" required placeholder="Ít nhất 12 ký tự"/><button class="primary-btn full-width social-submit" type="submit">Tạo tài khoản</button></form><p class="field-hint">Mật khẩu được băm bằng scrypt trên server; không lưu mật khẩu dạng văn bản. Hãy dùng mật khẩu riêng cho VILA Chess.</p></section></div>` : `<section class="panel social-profile-panel"><div class="social-profile-main"><div class="social-big-avatar">${esc((user.displayName || user.username || 'V').slice(0,1).toUpperCase())}</div><div class="social-profile-info"><small class="eyebrow">HỒ SƠ VILA CHESS</small><h2>${esc(user.displayName || user.username)}</h2><p>@${esc(user.username)} · ${user.role === 'admin' ? 'Quản trị viên' : 'Người chơi'} · ${Number(user.elo || 1200)} Elo</p></div><button class="secondary-btn" type="button" id="socialLogout">Đăng xuất</button></div><form id="socialProfileForm" class="social-profile-edit"><div><label class="field-label" for="socialProfileDisplay">Tên hiển thị</label><input class="field" id="socialProfileDisplay" maxlength="40" minlength="2" required value="${esc(user.displayName || user.username)}"/></div><div><label class="field-label" for="socialProfileBio">Giới thiệu</label><input class="field" id="socialProfileBio" maxlength="180" value="${esc(user.bio || '')}" placeholder="Giới thiệu ngắn về bạn"/></div><button class="secondary-btn" type="submit">Lưu hồ sơ</button></form></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI CỘNG ĐỒNG</small><h2>Tìm bạn bè</h2></div><span class="context-icon">⌕</span></div><form id="socialSearchForm" class="social-search-row"><input class="field" id="socialSearchName" minlength="2" maxlength="30" required placeholder="Tìm theo tên hoặc username"/><button class="primary-btn" type="submit">Tìm</button></form><div id="socialSearchResults" class="social-person-list"><div class="empty-state">Nhập tên người chơi để tìm bạn.</div></div></section><div class="social-friends-grid"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">DANH SÁCH CỦA BẠN</small><h2>Bạn bè <span id="socialFriendCount"></span></h2></div><button class="secondary-btn" id="refreshFriends" type="button">↻</button></div><div id="socialFriendsList" class="social-person-list"><div class="empty-state">Đang tải bạn bè…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">LỜI MỜI</small><h2>Lời mời kết bạn</h2></div></div><h3>Đang chờ bạn phản hồi</h3><div id="socialIncomingList" class="social-person-list"></div><h3 class="social-subheading">Đã gửi</h3><div id="socialOutgoingList" class="social-person-list"></div></section></div>`;
  return `<section class="content-page social-page"><div class="page-intro"><div class="eyebrow">VILA CHESS COMMUNITY</div><h1>Bạn bè & tài khoản</h1><p>Đăng nhập để tạo hồ sơ cộng đồng, kết nối người chơi và chuẩn bị cho thi đấu xếp hạng trực tuyến. Tài khoản và quan hệ bạn bè được lưu trên máy chủ.</p></div>${authPanel}<p class="field-hint social-status" id="socialPageStatus">${socialState.token ? 'Đã lưu phiên đăng nhập trên thiết bị này.' : 'Tạo tài khoản để thêm bạn bè và xuất hiện trong Top 100.'}</p></section>`;
}
async function loadFriendsSnapshot() {
  if (!socialState.token || currentView !== 'friends') return;
  try {
    const data = await socialApi('/friends');
    socialState.friends = data.friends || []; socialState.incoming = data.incoming || []; socialState.outgoing = data.outgoing || [];
    captureIncomingFriendNotifications(socialState.incoming);
    const friends = $('#socialFriendsList'), incoming = $('#socialIncomingList'), outgoing = $('#socialOutgoingList');
    if (friends) friends.innerHTML = socialState.friends.length ? socialState.friends.map(u => `<article class="social-person-row"><span class="social-person-avatar">${esc((u.displayName || u.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(u.displayName)}</b><small>@${esc(u.username)} · ${u.online ? '🟢 Online' : 'Ngoại tuyến'} · ${Number(u.elo || 1200)} Elo</small></span><button class="tiny-btn" data-remove-friend="${esc(u.id)}" aria-label="Xóa bạn">×</button></article>`).join('') : '<div class="empty-state">Chưa có bạn bè. Tìm username phía trên để gửi lời mời.</div>';
    if (incoming) incoming.innerHTML = socialState.incoming.length ? socialState.incoming.map(r => `<article class="social-person-row"><span class="social-person-avatar">${esc((r.user.displayName || r.user.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(r.user.displayName)}</b><small>@${esc(r.user.username)} muốn kết bạn</small></span><button class="tiny-btn social-accept" data-accept-friend="${esc(r.id)}" aria-label="Chấp nhận">✓</button></article>`).join('') : '<div class="small-empty">Không có lời mời mới.</div>';
    if (outgoing) outgoing.innerHTML = socialState.outgoing.length ? socialState.outgoing.map(r => `<article class="social-person-row"><span class="social-person-meta"><b>${esc(r.user.displayName)}</b><small>@${esc(r.user.username)} · Đang chờ</small></span><button class="tiny-btn" data-remove-friend="${esc(r.user.id)}" aria-label="Hủy lời mời">×</button></article>`).join('') : '<div class="small-empty">Chưa gửi lời mời nào.</div>';
    if ($('#socialFriendCount')) $('#socialFriendCount').textContent = `(${socialState.friends.length})`;
  } catch (error) { socialHandleError(error); }
}
function renderInboxView() {
  const unread = unreadNotificationCount(appNotifications);
  const rows = [...appNotifications].reverse().map(item => {
    const typeLabel = item.type === 'error' ? 'Lỗi' : item.type === 'warning' ? 'Cảnh báo' : item.type === 'success' ? 'Thành công' : 'Thông tin';
    const date = new Date(item.createdAt);
    const dateLabel = Number.isFinite(date.getTime()) ? date.toLocaleString() : 'Không rõ thời gian';
    return `<article class="inbox-notice ${item.read ? 'is-read' : 'is-unread'} notice-${esc(item.type)}"><span class="inbox-notice-mark" aria-hidden="true">${item.type === 'error' ? '!' : item.type === 'warning' ? '⚠' : item.type === 'success' ? '✓' : '•'}</span><div class="inbox-notice-body"><div class="inbox-notice-head"><b>${esc(item.title)}</b><span>${typeLabel}</span></div><p>${esc(item.message)}</p><time datetime="${esc(item.createdAt)}">${esc(dateLabel)}</time></div>${item.read ? '' : `<button type="button" class="tiny-btn" data-mark-notification="${esc(item.id)}" aria-label="Đánh dấu đã đọc">✓</button>`}</article>`;
  }).join('');
  return `<section class="content-page inbox-page"><div class="page-intro"><div class="eyebrow">THÔNG BÁO TRÊN THIẾT BỊ</div><h1>Hộp thư</h1><p>Hiển thị cảnh báo engine, trạng thái tài khoản và lời mời kết bạn đã được ứng dụng nhận. Đây là hộp thư trong ứng dụng, chưa phải thông báo đẩy Android khi ứng dụng đóng.</p></div><div class="inbox-toolbar panel"><div><b>${unread} chưa đọc</b><small>${appNotifications.length} thông báo được lưu trên thiết bị</small></div><div class="inbox-toolbar-actions"><button type="button" class="secondary-btn" id="markAllNotificationsRead" ${unread ? '' : 'disabled'}>Đánh dấu đã đọc</button><button type="button" class="secondary-btn" id="clearReadNotifications" ${appNotifications.some(item => item.read) ? '' : 'disabled'}>Xóa đã đọc</button></div></div><div class="inbox-list">${rows || '<section class="panel empty-state inbox-empty"><b>Hộp thư đang trống</b><p>Khi engine gặp lỗi, đăng nhập thành công hoặc có lời mời bạn bè mà ứng dụng nhận được, thông báo sẽ xuất hiện ở đây.</p><button type="button" class="secondary-btn" data-home-view="health">Kiểm tra hệ thống</button></section>'}</div></section>`;
}
function wireInboxActions() {
  $$('[data-mark-notification]').forEach(button => button.addEventListener('click', () => {
    appNotifications = markNotificationRead(appNotifications, button.dataset.markNotification);
    persistNotifications(); syncInboxBadge(); renderView();
  }));
  $('#markAllNotificationsRead')?.addEventListener('click', () => {
    appNotifications = markAllNotificationsRead(appNotifications);
    persistNotifications(); syncInboxBadge(); renderView();
  });
  $('#clearReadNotifications')?.addEventListener('click', () => {
    appNotifications = clearReadNotifications(appNotifications);
    persistNotifications(); syncInboxBadge(); renderView();
  });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
}
function localStorageCheck() {
  const key = `${NOTIFICATIONS_KEY}.health-check`;
  try { localStorage.setItem(key, 'ok'); localStorage.removeItem(key); return true; }
  catch { return false; }
}
function renderSystemHealthView() {
  const protocolHasBackend = location.protocol === 'http:' || location.protocol === 'https:';
  const backendConfigured = Boolean(String(settings.backendUrl || '').trim()) || protocolHasBackend;
  const checks = buildSystemChecks({
    engineReady,
    engineFailed,
    workerSupported: typeof Worker === 'function',
    storageAvailable: localStorageCheck(),
    openingCount: OPENINGS.length,
    backendStatus: healthBackendStatus,
    backendConfigured
  });
  const statusText = { ok: 'Đạt', warning: 'Cần cấu hình', pending: 'Đang chờ', error: 'Cần xử lý' };
  const rows = checks.map(check => `<article class="health-check-row health-${check.status}"><span class="health-check-icon" aria-hidden="true">${check.status === 'ok' ? '✓' : check.status === 'warning' ? '!' : check.status === 'pending' ? '…' : '×'}</span><div><div class="health-check-heading"><b>${esc(check.label)}</b><span>${statusText[check.status] || 'Chưa rõ'}</span></div><p>${esc(check.detail)}</p></div></article>`).join('');
  const errors = checks.filter(check => check.status === 'error').length;
  const warnings = checks.filter(check => check.status === 'warning' || check.status === 'pending').length;
  return `<section class="content-page health-page"><div class="page-intro"><div class="eyebrow">CHẨN ĐOÁN THỰC TẾ</div><h1>Kiểm tra hệ thống</h1><p>Trang này kiểm tra trạng thái hiện tại, không tự đánh dấu đạt nếu engine, backend hoặc dữ liệu khai cuộc chưa thực sự sẵn sàng.</p></div><section class="panel health-summary"><div><span class="eyebrow">KẾT QUẢ LẦN KIỂM TRA</span><h2>${errors ? `${errors} mục cần xử lý` : warnings ? `${warnings} mục chưa xác minh` : 'Các mục đã kiểm tra đều đạt'}</h2><p>Engine: ${engineReady ? 'sẵn sàng' : engineFailed ? 'đang lỗi' : 'đang khởi tạo'} · Kho khai cuộc đang nạp: ${OPENINGS.length.toLocaleString()} dòng</p></div><div class="health-actions"><button type="button" class="primary-btn" id="runHealthChecks">↻ Kiểm tra lại</button><button type="button" class="secondary-btn" id="healthRetryEngine">Tải lại engine</button><button type="button" class="secondary-btn" data-health-settings>Cài đặt backend</button></div></section><div class="health-check-list" id="healthCheckList">${rows}</div><p class="field-hint health-disclaimer">Lời mời bạn bè, đăng nhập Google/GitHub và Top 100 cần backend thật. Kho khai cuộc chỉ được báo đủ khi nạp ít nhất ${REQUIRED_OPENING_COUNT.toLocaleString()} dòng dữ liệu; tệp fallback rỗng không được xem là kho đầy đủ.</p></section>`;
}
async function runSystemHealthChecks() {
  healthBackendStatus = 'checking';
  const list = $('#healthCheckList');
  if (list) list.innerHTML = '<div class="panel empty-state">Đang kiểm tra phản hồi backend…</div>';
  if (currentView === 'health') {
    const temp = $('#mainView');
    if (temp) temp.innerHTML = renderSystemHealthView();
    wireSystemHealthActions(false);
  }
  const configured = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  if (!configured && location.protocol !== 'http:' && location.protocol !== 'https:') {
    healthBackendStatus = 'not-configured';
  } else {
    try {
      const response = await fetch(`${configured}/api/health`, { cache: 'no-store', signal: AbortSignal.timeout(8000) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (data?.ok !== true) throw new Error('Health endpoint did not report ok=true');
      healthBackendStatus = 'online';
    } catch (error) {
      healthBackendStatus = String(error?.message || error || 'Không kết nối được');
    }
  }
  if (currentView === 'health') renderView();
}
function wireSystemHealthActions(runOnMount = true) {
  $('#runHealthChecks')?.addEventListener('click', () => { void runSystemHealthChecks(); });
  $('#healthRetryEngine')?.addEventListener('click', retryStockfishEngine);
  $('[data-health-settings]')?.addEventListener('click', () => setView('settings'));
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  if (runOnMount && healthBackendStatus === 'unknown') void runSystemHealthChecks();
}
async function pollSocialInbox() {
  if (!socialState.token || document.visibilityState !== 'visible') return;
  try {
    const token = socialState.token;
    const identity = await socialApi('/auth/me');
    if (socialState.token !== token) return;
    saveSocialSession(token, identity.user);
    const data = await socialApi('/friends');
    if (socialState.token !== token) return;
    captureIncomingFriendNotifications(data.incoming);
    if (currentView === 'friends') await loadFriendsSnapshot();
  } catch (error) {
    const message = String(error?.message || error || '');
    if (/HTTP 401|HTTP 403|Phiên đăng nhập hết hạn|phiên đăng nhập/i.test(message) && socialState.token) {
      saveSocialSession('', null);
      addAppNotification({ title: 'Phiên đăng nhập đã hết hạn', message: 'Hãy đăng nhập lại để dùng bạn bè, hộp thư cộng đồng và Top 100.', type: 'warning', sourceKey: `session-expired:${new Date().toISOString().slice(0, 10)}` });
    } else console.info('[VILA Chess] Background inbox sync skipped:', message);
  }
}

function wireFriendsActions() {
  $('#socialLoginForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true; try { const data = await socialApi('/auth/login', { method: 'POST', body: JSON.stringify({ username: $('#socialLoginName').value, password: $('#socialLoginPassword').value }) }); if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ. Chưa thể xác nhận đăng nhập.'); saveSocialSession(data.token, data.user); addAppNotification({ title: 'Đăng nhập thành công', message: `Xin chào ${data.user?.displayName || data.user?.username || 'bạn'}.`, type: 'success', sourceKey: `login:${data.user?.id || data.user?.username}:${new Date().toISOString().slice(0, 10)}` }); toast('Đăng nhập thành công.'); renderView(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } });
  $('#socialRegisterForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true; try { const data = await socialApi('/auth/register', { method: 'POST', body: JSON.stringify({ username: $('#socialRegisterName').value, displayName: $('#socialRegisterDisplay').value, email: $('#socialRegisterEmail').value, password: $('#socialRegisterPassword').value }) }); if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ. Chưa thể xác nhận đăng ký.'); saveSocialSession(data.token, data.user); addAppNotification({ title: 'Tài khoản đã tạo', message: 'Hồ sơ VILA Chess đã được tạo trên máy chủ.', type: 'success' }); toast('Đã tạo tài khoản VILA Chess.'); renderView(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } });
  $('#socialLogout')?.addEventListener('click', () => { saveSocialSession('', null); socialState.friends = []; socialState.incoming = []; socialState.outgoing = []; toast('Đã đăng xuất.'); renderView(); });
  $('#socialProfileForm')?.addEventListener('submit', async event => { event.preventDefault(); try { const data = await socialApi('/profile', { method: 'PATCH', body: JSON.stringify({ displayName: $('#socialProfileDisplay').value, bio: $('#socialProfileBio').value }) }); saveSocialSession(socialState.token, data.user); toast('Đã lưu hồ sơ.'); renderView(); } catch (error) { socialHandleError(error); } });
  $('#socialSearchForm')?.addEventListener('submit', async event => { event.preventDefault(); const output = $('#socialSearchResults'); if (!output) return; output.innerHTML = '<div class="small-empty">Đang tìm…</div>'; try { const data = await socialApi(`/users/search?q=${encodeURIComponent($('#socialSearchName').value)}`); socialState.searchResults = data.users || []; output.innerHTML = socialState.searchResults.length ? socialState.searchResults.map(u => `<article class="social-person-row"><span class="social-person-avatar">${esc((u.displayName || u.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(u.displayName)}</b><small>@${esc(u.username)} · ${u.online ? '🟢 Online' : `${Number(u.elo || 1200)} Elo`}</small></span><button class="tiny-btn social-add" data-add-friend="${esc(u.username)}" aria-label="Gửi lời mời">+</button></article>`).join('') : '<div class="empty-state">Không tìm thấy người chơi phù hợp.</div>'; } catch (error) { output.innerHTML = `<div class="small-empty">${esc(error.message)}</div>`; } });
  $('#refreshFriends')?.addEventListener('click', loadFriendsSnapshot);
  $$('[data-accept-friend]').forEach(button => button.addEventListener('click', async () => { button.disabled = true; try { await socialApi(`/friends/${encodeURIComponent(button.dataset.acceptFriend)}/accept`, { method: 'POST', body: '{}' }); toast('Đã chấp nhận lời mời.'); await loadFriendsSnapshot(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } }));
  $$('[data-remove-friend]').forEach(button => button.addEventListener('click', async () => { const friendId = button.dataset.removeFriend; if (!confirm('Xóa bạn bè hoặc hủy lời mời này?')) return; try { await socialApi(`/friends/${encodeURIComponent(friendId)}`, { method: 'DELETE' }); await loadFriendsSnapshot(); } catch (error) { socialHandleError(error); } }));
  $$('[data-add-friend]').forEach(button => button.addEventListener('click', async () => { button.disabled = true; try { const data = await socialApi('/friends/request', { method: 'POST', body: JSON.stringify({ username: button.dataset.addFriend }) }); toast(data.message || 'Đã gửi lời mời.'); button.textContent = '✓'; await loadFriendsSnapshot(); } catch (error) { socialHandleError(error); button.disabled = false; } }));
  $$('[data-social-oauth]').forEach(button => button.addEventListener('click', () => { const provider = button.dataset.socialOauth; try { const base = socialBackendBase(); location.href = `${base}/api/social/auth/oauth/${provider}/start`; } catch (error) { socialHandleError(error); } }));
  loadFriendsSnapshot();
}
function renderMissionsView() {
  const state = readDailyProgress();
  const summary = getMissionSummary(state);
  const cards = DAILY_MISSIONS.map(mission => {
    const progress = Math.min(mission.goal, Number(state.missionProgress[mission.id] || 0));
    const completed = progress >= mission.goal;
    const claimed = state.claimed.includes(mission.id);
    return `<article class="mission-card panel"><div class="mission-card-top"><span class="mission-card-icon">${mission.icon}</span><span class="mission-card-category">${esc(mission.category || 'Thử thách')}</span><span class="mission-reward">◈ ${mission.reward} xu</span></div><h2>${esc(mission.title)}</h2><p>${esc(mission.description)}</p><div class="mission-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${mission.goal}" aria-valuenow="${progress}"><span style="width:${Math.round(progress / mission.goal * 100)}%"></span></div><div class="mission-card-bottom"><small>${progress}/${mission.goal} ${completed ? '· Hoàn thành' : '· Chưa hoàn thành'}</small>${claimed ? '<span class="mission-claimed">✓ Đã nhận</span>' : `<button type="button" class="${completed ? 'primary-btn' : 'secondary-btn'}" data-claim-mission="${mission.id}" ${completed ? '' : 'disabled'}>${completed ? 'Nhận thưởng' : 'Chưa xong'}</button>`}</div></article>`;
  }).join('');
  return `<section class="content-page progression-page"><div class="page-intro"><div class="eyebrow">THÓI QUEN NHỎ · TIẾN BỘ MỖI NGÀY</div><h1>Nhiệm vụ hằng ngày</h1><p>Hoàn thành các thử thách để nhận xu trong game, mở khóa giao diện bàn cờ và giữ chuỗi hoạt động. Tiến độ này được lưu trên thiết bị hiện tại.</p></div><div class="progression-summary-grid"><article class="panel progression-summary-main"><small>VÍ XU TRONG GAME</small><strong>◈ ${summary.coins}</strong><span>Không phải tiền thật và không thể rút ra.</span></article><article class="panel progression-summary-item"><small>CHUỖI NGÀY</small><strong>🔥 ${summary.streak}</strong><span>Ngày hoạt động liên tiếp</span></article><article class="panel progression-summary-item"><small>NHIỆM VỤ XONG</small><strong>${summary.completed}/${summary.total}</strong><span>${summary.claimed} phần thưởng đã nhận</span></article></div><div class="mission-cards-grid">${cards}</div><section class="panel progression-next-step"><div><span class="eyebrow">PHẦN THƯỞNG TRANG TRÍ</span><h2>Đổi xu lấy bàn cờ mới</h2><p>Các vật phẩm chỉ thay đổi màu bàn cờ, không tạo lợi thế khi thi đấu.</p></div><button class="primary-btn" type="button" data-open-shop>Mở cửa hàng ↗</button></section></section>`;
}
function renderShopView() {
  const state = readDailyProgress();
  const cards = COSMETICS.map(item => {
    const owned = state.ownedCosmetics.includes(item.id);
    const active = state.activeCosmetic === item.id;
    const preview = `<div class="cosmetic-board-preview" aria-label="Xem trước bàn cờ" style="--preview-light:${item.colors[0]};--preview-dark:${item.colors[1]}">${Array.from({length:16}, (_, i) => `<span class="${((Math.floor(i/4)+i%4)%2) ? 'dark' : 'light'}">${i===2 ? '♞' : ''}</span>`).join('')}</div>`;
    const action = active ? '<button type="button" class="secondary-btn" disabled>Đang sử dụng</button>' : owned ? `<button type="button" class="primary-btn" data-equip-cosmetic="${item.id}">Sử dụng</button>` : `<button type="button" class="secondary-btn" data-buy-cosmetic="${item.id}" ${state.coins < item.cost ? 'disabled' : ''}>Mua · ◈ ${item.cost}</button>`;
    return `<article class="cosmetic-card panel">${preview}<div class="cosmetic-card-copy"><div class="cosmetic-title-row"><h2>${item.icon} ${esc(item.name)}</h2>${owned ? '<span class="cosmetic-owned">Đã mở khóa</span>' : ''}</div><p>${esc(item.description)}</p><div class="cosmetic-card-bottom"><span>${item.cost === 0 ? 'Miễn phí' : `◈ ${item.cost} xu`}</span>${action}</div></div></article>`;
  }).join('');
  return `<section class="content-page progression-page"><div class="page-intro"><div class="eyebrow">CÁ NHÂN HÓA TRẢI NGHIỆM</div><h1>Cửa hàng giao diện</h1><p>Dùng xu nhận từ nhiệm vụ để mở khóa bàn cờ. Những vật phẩm này chỉ mang tính trang trí, không bán lợi thế chơi cờ.</p></div><div class="shop-wallet panel"><div><small>VÍ XU CỦA BẠN</small><strong>◈ ${state.coins}</strong></div><button type="button" class="secondary-btn" data-open-missions>Kiếm xu từ nhiệm vụ</button></div><div class="cosmetic-shop-grid">${cards}</div><section class="panel shop-future-note"><span class="eyebrow">LỘ TRÌNH KIẾM TIỀN THẬT</span><h2>Cửa hàng này hiện chưa thu tiền</h2><p>Muốn có doanh thu thật cần thiết lập quảng cáo nhận thưởng hoặc thanh toán Google Play, chính sách quyền riêng tư, xác minh nhà phát triển và thử nghiệm trên bản Android đã ký. Không nhập thông tin thanh toán người dùng trước khi phần tích hợp và kiểm thử đó hoàn tất.</p></section></section>`;
}
function wireMissionsActions() {
  $$('[data-claim-mission]').forEach(button => button.addEventListener('click', () => {
    const result = claimMissionReward(readDailyProgress(), button.dataset.claimMission, new Date());
    if (!result.ok) { toast(result.reason === 'already_claimed' ? 'Bạn đã nhận phần thưởng này hôm nay.' : 'Hoàn thành nhiệm vụ trước khi nhận thưởng.'); return; }
    persistDailyProgress(result.state);
    toast(`Đã nhận ${result.reward} xu trong game!`);
    renderView();
  }));
  $('[data-open-shop]')?.addEventListener('click', () => setView('shop'));
}
function wireShopActions() {
  $$('[data-buy-cosmetic]').forEach(button => button.addEventListener('click', () => {
    const result = purchaseCosmetic(readDailyProgress(), button.dataset.buyCosmetic, new Date());
    if (!result.ok) { toast(result.reason === 'not_enough_coins' ? 'Chưa đủ xu. Hoàn thành nhiệm vụ để kiếm thêm.' : 'Không thể mở khóa vật phẩm này.'); return; }
    persistDailyProgress(result.state);
    toast('Đã mở khóa giao diện bàn cờ!');
    renderView();
  }));
  $$('[data-equip-cosmetic]').forEach(button => button.addEventListener('click', () => {
    const result = equipCosmetic(readDailyProgress(), button.dataset.equipCosmetic, new Date());
    if (!result.ok) { toast('Bạn cần mở khóa vật phẩm trước.'); return; }
    persistDailyProgress(result.state);
    toast('Đã đổi giao diện bàn cờ.');
    renderView();
  }));
  $('[data-open-missions]')?.addEventListener('click', () => setView('missions'));
}

function renderAdminView() {
  if (socialState.user?.role !== 'admin') return `<section class="content-page"><div class="page-intro"><div class="eyebrow">BẢO MẬT NỀN TẢNG</div><h1>Trung tâm quản trị</h1><p>Khu vực này chỉ dành cho tài khoản admin đã được cấp quyền ở phía máy chủ.</p></div><section class="panel"><div class="empty-state">Bạn chưa đăng nhập bằng tài khoản quản trị. Hãy vào mục Bạn bè để đăng nhập. Admin được tạo qua ADMIN_USERNAME và ADMIN_PASSWORD trong cấu hình bí mật của máy chủ — không có mật khẩu mặc định trong APK.</div><button type="button" class="primary-btn" data-home-view="friends">Mở đăng nhập</button></section></section>`;
  return `<section class="content-page admin-page"><div class="page-intro"><div class="eyebrow">ADMIN CONTROL PLANE</div><h1>Quản trị nền tảng</h1><p>Giám sát tiến trình server, tài khoản và sự kiện bảo mật. Các thao tác khóa tài khoản được kiểm tra quyền ở API server.</p></div><div class="admin-metrics-grid" id="adminMetrics"><div class="panel"><span class="admin-metric-label">Đang tải</span><strong>—</strong></div></div><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Người dùng</h2></div><button class="secondary-btn" id="refreshAdmin" type="button">↻ Làm mới</button></div><form id="adminSearchForm" class="social-search-row"><input class="field" id="adminSearchName" placeholder="Tìm username, tên hiển thị hoặc email" maxlength="80"/><button class="secondary-btn" type="submit">Tìm</button></form><div class="admin-user-list" id="adminUsersList"><div class="empty-state">Đang tải người dùng…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">AUDIT LOG</small><h2>Nhật ký bảo mật</h2></div><span class="context-icon">⌁</span></div><div class="admin-audit-list" id="adminAuditList"><div class="empty-state">Đang tải nhật ký…</div></div></section><p class="field-hint">Bảng quản trị không thay thế các lớp phòng thủ của nhà cung cấp hosting. Cần HTTPS, sao lưu, cập nhật hệ điều hành, giám sát và chống DDoS ở tầng hạ tầng khi server được đưa lên Internet.</p></section>`;
}
async function loadAdminDashboard(query = '') {
  if (socialState.user?.role !== 'admin' || currentView !== 'admin') return;
  const metrics = $('#adminMetrics'), usersNode = $('#adminUsersList'), auditNode = $('#adminAuditList');
  try {
    const [overview, users, auditData] = await Promise.all([socialApi('/admin/overview'), socialApi(`/admin/users?q=${encodeURIComponent(query)}`), socialApi('/admin/audit?limit=40')]);
    socialState.adminOverview = overview; socialState.adminUsers = users.users || []; socialState.auditEvents = auditData.events || [];
    if (metrics) metrics.innerHTML = `<article class="panel"><span class="admin-metric-label">Tổng tài khoản</span><strong>${Number(overview.users)}</strong><small>${Number(overview.activeUsers)} hoạt động gần đây</small></article><article class="panel"><span class="admin-metric-label">Tài khoản bị khóa</span><strong>${Number(overview.bannedUsers)}</strong><small>${Number(overview.admins)} admin đang hoạt động</small></article><article class="panel"><span class="admin-metric-label">Server uptime</span><strong>${Math.floor(Number(overview.uptimeSeconds || 0) / 3600)}h ${Math.floor((Number(overview.uptimeSeconds || 0) % 3600) / 60)}m</strong><small>Node ${esc(overview.node)} · ${esc(overview.platform)}/${esc(overview.arch)}</small></article><article class="panel"><span class="admin-metric-label">Bộ nhớ tiến trình</span><strong>${Number(overview.memory?.rssMb || 0)} MB</strong><small>Heap ${Number(overview.memory?.heapUsedMb || 0)}/${Number(overview.memory?.heapTotalMb || 0)} MB · ${Number(overview.cpus || 0)} CPU</small></article><article class="panel"><span class="admin-metric-label">Bộ nhớ hệ thống trống</span><strong>${Number(overview.memory?.systemFreeMb || 0)} MB</strong><small>Tổng ${Number(overview.memory?.systemTotalMb || 0)} MB</small></article><article class="panel"><span class="admin-metric-label">Tải CPU (1/5/15 phút)</span><strong>${(overview.loadAverage || [0,0,0]).map(n => Number(n).toFixed(2)).join(' / ')}</strong><small>Chỉ số load average của máy chủ</small></article><article class="panel"><span class="admin-metric-label">Lời mời kết bạn</span><strong>${Number(overview.pendingFriendRequests)}</strong><small>${Number(overview.db?.auditEvents || 0)} sự kiện nhật ký</small></article>`;
    if (usersNode) usersNode.innerHTML = socialState.adminUsers.length ? socialState.adminUsers.map(u => `<article class="admin-user-row"><span class="social-person-avatar">${esc((u.displayName || u.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(u.displayName)} <small>@${esc(u.username)}</small></b><small>${esc(u.email || 'Chưa thêm email')} · ${u.banned ? '🔒 Đã khóa' : '🟢 Hoạt động'} · ${Number(u.elo || 1200)} Elo · ${esc(new Date(u.createdAt).toLocaleDateString())}</small></span>${u.role === 'admin' ? '<span class="admin-role-tag">ADMIN</span>' : `<button class="${u.banned ? 'secondary-btn' : 'danger-btn'} admin-ban-button" type="button" data-admin-action="${u.banned ? 'unban' : 'ban'}" data-admin-user="${esc(u.id)}">${u.banned ? 'Mở khóa' : 'Khóa'}</button>`}</article>`).join('') : '<div class="empty-state">Không có người dùng phù hợp.</div>';
    if (auditNode) auditNode.innerHTML = socialState.auditEvents.length ? socialState.auditEvents.map(item => `<article class="admin-audit-row"><span class="admin-audit-dot"></span><div><b>${esc(item.action)}</b><small>${esc(item.detail || '')}</small><span>${esc(new Date(item.at).toLocaleString())} · actor ${esc(String(item.actor || '').slice(0,12))} · target ${esc(String(item.target || '').slice(0,12))}</span></div></article>`).join('') : '<div class="empty-state">Chưa có sự kiện bảo mật.</div>';
    $$('[data-admin-action]').forEach(button => button.addEventListener('click', async () => { const action = button.dataset.adminAction; const id = button.dataset.adminUser; const reason = action === 'ban' ? (prompt('Lý do khóa tài khoản (hiển thị cho quản trị viên):', 'Vi phạm quy định cộng đồng') || '') : ''; if (action === 'ban' && !reason.trim()) return; button.disabled = true; try { await socialApi(`/admin/users/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ action, reason }) }); toast(action === 'ban' ? 'Đã khóa tài khoản.' : 'Đã mở khóa tài khoản.'); await loadAdminDashboard($('#adminSearchName')?.value || ''); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } }));
  } catch (error) { if (metrics) metrics.innerHTML = `<div class="empty-state">${esc(error.message)}. Kiểm tra trạng thái server và phiên admin.</div>`; socialHandleError(error); }
}
function wireAdminActions() {
  $('#refreshAdmin')?.addEventListener('click', () => loadAdminDashboard($('#adminSearchName')?.value || ''));
  $('#adminSearchForm')?.addEventListener('submit', event => { event.preventDefault(); loadAdminDashboard($('#adminSearchName')?.value || ''); });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  loadAdminDashboard();
}

function renderHomeView() {
  const profile = readRatingProfile();
  const progress = readDailyProgress();
  const missionSummary = getMissionSummary(progress);
  const homeMissions = DAILY_MISSIONS.filter(m => m.id !== 'checkin').map(m => {
    const done = (progress.missionProgress[m.id] || 0) >= m.goal;
    const claimed = progress.claimed.includes(m.id);
    return `<div class="home-mission-row"><span class="home-mission-icon">${m.icon}</span><div><b>${esc(m.title)}</b><small>${done ? (claimed ? 'Đã nhận thưởng' : 'Đã hoàn thành') : 'Đang chờ hoàn thành'}</small></div><span class="home-mission-status ${done ? 'is-done' : ''}">${claimed ? '✓' : done ? `+${m.reward}` : '›'}</span></div>`;
  }).join('');
  const completedGames = Number(profile.games || 0);
  const winRate = completedGames ? Math.round(Number(profile.wins || 0) / completedGames * 100) : 0;
  const homeBackRank = ['♜','♞','♝','♛','♚','♝','♞','♜'];
  const squarePattern = Array.from({ length: 64 }, (_, index) => {
    const row = Math.floor(index / 8), col = index % 8;
    const piece = row === 0 ? homeBackRank[col] : row === 1 ? '♟' : row === 6 ? '♟' : row === 7 ? homeBackRank[col] : '';
    const shownPiece = row >= 6 ? ({ '♜':'♖', '♞':'♘', '♝':'♗', '♛':'♕', '♚':'♔' }[piece] || (piece === '♟' ? '♙' : '')) : piece;
    return `<span class="${(row + col) % 2 === 0 ? 'home-sq-light' : 'home-sq-dark'}">${shownPiece}</span>`;
  }).join('');
  return `<section class="home-page content-page">
    <div class="home-hero">
      <div class="home-hero-copy">
        <span class="home-kicker"><i></i> VILA CHESS · AI ARENA</span>
        <h1>Mỗi nước đi<br/><em>là một bước tiến.</em></h1>
        <p>Chơi cùng Stockfish, kiểm tra ý tưởng bằng phân tích nhiều biến và rèn chiến thuật — trong một giao diện tối ưu cho điện thoại.</p>
        <div class="home-hero-actions">
          <button class="primary-btn home-primary" type="button" data-home-action="quickplay">♟ Chơi với Stockfish <span aria-hidden="true">→</span></button>
          <button class="secondary-btn home-secondary" type="button" data-home-view="play">Thiết lập ván đấu</button>
        </div>
        <div class="home-trust-row"><span>✓ Stockfish tích hợp</span><span>✓ Phân tích 3 biến</span><span>✓ Lưu Elo trên máy</span></div>
      </div>
      <div class="home-hero-visual"><div class="home-visual-glow"></div><div class="home-board-art"><div class="home-board-pattern" aria-hidden="true">${squarePattern}</div><div class="home-board-piece">♞</div><span class="home-board-tag">STRATEGY · FOCUS · GROW</span></div><div class="home-floating-chip"><span class="home-chip-dot"></span><span><b>STOCKFISH ENGINE</b><small>Phân tích thế cờ cục bộ</small></span></div></div>
    </div>
    <div class="home-section-head"><div><span class="eyebrow">BẢNG ĐIỀU KHIỂN</span><h2>Hôm nay bạn muốn làm gì?</h2></div><span class="home-section-note">Chọn chế độ để bắt đầu</span></div>
    <div class="home-feature-grid">
      <button class="home-feature home-feature-play" type="button" data-home-action="quickplay"><span class="home-feature-icon">♟</span><span class="home-feature-copy"><b>Chơi cờ</b><small>Đấu với Stockfish hoặc chọn chế độ khác</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="arena"><span class="home-feature-icon">⚔</span><span class="home-feature-copy"><b>Đấu trường AI</b><small>Cho các engine/model thi đấu</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="coach"><span class="home-feature-icon">✦</span><span class="home-feature-copy"><b>AI phân tích</b><small>Hỏi về chiến thuật và kế hoạch</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="openings"><span class="home-feature-icon">⌘</span><span class="home-feature-copy"><b>Khai cuộc</b><small>Học các biến mở đầu phổ biến</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="leaderboard"><span class="home-feature-icon">🏆</span><span class="home-feature-copy"><b>Elo & xếp hạng</b><small>Theo dõi kết quả từng ván</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="friends"><span class="home-feature-icon">♙</span><span class="home-feature-copy"><b>Bạn bè & cộng đồng</b><small>Tìm người chơi và gửi lời mời kết bạn</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="shop"><span class="home-feature-icon">◈</span><span class="home-feature-copy"><b>Cửa hàng vật phẩm</b><small>Đổi xu nhiệm vụ lấy giao diện bàn cờ</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="missions"><span class="home-feature-icon">✦</span><span class="home-feature-copy"><b>Nhiệm vụ hôm nay</b><small>Nhận xu ảo trong game khi hoàn thành</small></span><span class="home-feature-arrow">↗</span></button>
      <button class="home-feature" type="button" data-home-view="lichess"><span class="home-feature-icon">↗</span><span class="home-feature-copy"><b>Lichess trực tuyến</b><small>Kết nối để chơi online</small></span><span class="home-feature-arrow">↗</span></button>
    </div>
    <section class="panel home-missions-panel"><div class="home-panel-title"><span class="home-small-icon">✦</span><div><span class="eyebrow">TIẾN ĐỘ HÔM NAY</span><h2>Nhiệm vụ hằng ngày</h2></div><span class="home-coins">◈ ${missionSummary.coins}</span><button type="button" class="text-btn" data-home-view="missions">Xem tất cả ↗</button></div><div class="home-mission-grid">${homeMissions}</div><div class="home-streak-row"><span>🔥 Chuỗi hoạt động: <b>${missionSummary.streak} ngày</b></span><button type="button" class="secondary-btn" data-home-view="shop">Cửa hàng vật phẩm</button></div><p class="field-hint">Xu và giao diện chỉ là phần thưởng trong game, không quy đổi thành tiền thật.</p></section>
    <div class="home-bottom-grid">
      <section class="panel home-rating-panel"><div class="home-panel-title"><span class="home-small-icon">♜</span><div><span class="eyebrow">HỒ SƠ CỦA BẠN</span><h2>Tiến bộ qua từng ván</h2></div><button type="button" class="text-btn" data-home-view="leaderboard">Chi tiết ↗</button></div><div class="home-rating-stats"><div><small>ELO HIỆN TẠI</small><b>${Number(profile.elo || 1200)}</b><span class="${Number(profile.lastChange) > 0 ? 'positive' : Number(profile.lastChange) < 0 ? 'negative' : ''}">${Number(profile.lastChange) > 0 ? '+' : ''}${Number(profile.lastChange || 0)} điểm gần nhất</span></div><div><small>SỐ VÁN</small><b>${completedGames}</b><span>Đã tính Elo</span></div><div><small>TỈ LỆ THẮNG</small><b>${winRate}%</b><span>${Number(profile.wins || 0)} thắng · ${Number(profile.draws || 0)} hòa · ${Number(profile.losses || 0)} thua</span></div></div></section>
      <section class="panel home-system-panel"><div class="home-panel-title"><span class="home-small-icon">⚙</span><div><span class="eyebrow">TRẠNG THÁI THỰC TẾ</span><h2>${engineReady ? 'Sẵn sàng vào trận' : engineFailed ? 'Engine cần xử lý' : 'Đang kiểm tra engine'}</h2></div></div><div class="home-system-row"><span class="home-system-dot"></span><div><b>Engine Stockfish</b><small>Chạy trong trình duyệt / WebView</small></div><button type="button" class="text-btn" data-home-view="settings">Cài đặt</button></div><div class="home-system-row"><span class="home-system-dot home-system-dot-muted"></span><div><b>AI qua API</b><small>${settings.model ? `Model đã chọn: ${esc(settings.model)}` : 'Cấu hình endpoint và API key khi cần'}</small></div><button type="button" class="text-btn" data-home-view="settings">Thiết lập</button></div><p class="home-disclaimer">Elo và lịch sử được lưu cục bộ trên thiết bị này. Xếp hạng online dùng chung cần máy chủ riêng.</p></section>
    </div>
  </section>`;
}

function wireHomeActions() {
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  $$('[data-home-action="quickplay"]').forEach(button => button.addEventListener('click', () => {
    mode = 'stockfish';
    humanColor = 'w';
    orientation = 'w';
    setView('play');
    startGameFromSetup();
  }));
}

let rankedMatchState = { queued: false, match: null, rating: 1200 };
let rankedChess = new Chess();
let rankedSelected = null;
let rankedTargets = [];
let rankedPollTimer = null;
let rankedClockDisplayTimer = null;
let rankedPollBusy = false;
let rankedLastSignature = '';
let rankedMoveBusy = false;
let puzzleGame = new Chess();
let puzzleState = {
  status: 'idle', rootFen: '', solutionUci: '', selected: null,
  targets: [], attempts: 0, lastMessage: 'Tạo một thế cờ ngẫu nhiên để bắt đầu.',
  showHint: false, lastMove: null, solvedCount: 0, rootPly: 0
};
try { puzzleState.solvedCount = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.solved.v1')) || 0); } catch {}

function rankedRatingOf(user, category = '') {
  const categoryRating = category && Number(user?.ratingsByCategory?.[category]);
  return Math.max(100, Number(categoryRating) || Number(user?.elo) || 1200);
}
function rankedCategoryLabel(category) {
  return ({ bullet: 'Bullet', blitz: 'Blitz', rapid: 'Rapid', casual: 'Không xếp hạng' })[category] || 'Blitz';
}
function rankedClockText(match, color, now = Date.now()) {
  if (!match?.clockEnabled) return '∞';
  let remaining = Math.max(0, Number(match.clockRemainingMs?.[color]) || 0);
  const activeTurn = String(match.fen || '').split(' ')[1] || 'w';
  if (match.status === 'active' && activeTurn === color) {
    const updatedAt = Number(match.clockUpdatedAt) || now;
    remaining = Math.max(0, remaining - Math.max(0, now - updatedAt));
  }
  return formatClockTime(remaining, true);
}
function updateRankedClockDisplay() {
  if (currentView !== 'ranked') return;
  const match = rankedMatchState?.match;
  if (!match || match.status !== 'active') return;
  for (const color of ['w', 'b']) {
    const output = $(`[data-ranked-clock="${color}"]`);
    if (output) output.textContent = rankedClockText(match, color);
  }
}
function rankedClockFaceMarkup(match, color, label) {
  return `<span class="ranked-clock-face" data-clock-color="${color}"><small>${label}</small><strong data-ranked-clock="${color}">${rankedClockText(match, color)}</strong></span>`;
}
function rankedBoardMarkup(match) {
  const snapshot = rankedChess.board();
  const whiteBottom = match?.color !== 'b';
  const ranks = whiteBottom ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = whiteBottom ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const latest = match?.moves?.at(-1) || null;
  const targets = new Map();
  for (const move of rankedTargets) {
    if (!targets.has(move.to)) targets.set(move.to, []);
    targets.get(move.to).push(move);
  }
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const square = `${file}${rank}`;
    const piece = rankedChess.get(square);
    const selected = rankedSelected === square;
    const choices = targets.get(square) || [];
    const isLastFrom = latest?.from === square;
    const isLastTo = latest?.to === square;
    const classes = ['ranked-square', ((file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light'), selected ? 'selected' : '', choices.length ? (piece ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-from' : '', isLastTo ? 'last-to' : ''].filter(Boolean).join(' ');
    const pieceHtml = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : '';
    const tag = isLastTo ? `<span class="ranked-move-tag">${esc(latest.san || '•')}</span>` : '';
    html += `<button type="button" class="${classes}" data-ranked-square="${square}" aria-label="${square}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}" ${match?.status !== 'active' || rankedMoveBusy ? 'disabled' : ''}>${pieceHtml}${tag}${col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}
function rankedMoveListMarkup(match) {
  const moves = match?.moves || [];
  if (!moves.length) return '<div class="empty-state">Nước đi đã được đồng bộ và xác thực trên máy chủ sẽ xuất hiện ở đây.</div>';
  let html = '';
  for (let i = 0; i < moves.length; i += 2) {
    const first = moves[i]; const second = moves[i + 1];
    html += `<div class="ranked-move-row"><b>${Math.floor(i / 2) + 1}.</b><span>${esc(first?.san || '—')}</span><span>${esc(second?.san || '…')}</span></div>`;
  }
  return html;
}
function rankedClockOptionsMarkup() {
  return RANKED_CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${preset.value === selectedRankedTimeControl ? 'selected' : ''}>${esc(preset.label)}</option>`).join('');
}
function renderRankedView() {
  const user = socialState.user;
  if (!socialState.token || !user) return `<section class="content-page ranked-page"><div class="page-intro"><div class="eyebrow">VILA CHESS · RANKED 1V1</div><h1>Đấu xếp hạng</h1><p>Ghép ngẫu nhiên với người chơi thật theo Elo, máy chủ xác thực luật đi và cập nhật điểm.</p></div><section class="panel ranked-queue-card"><div class="ranked-queue-orbit">♟</div><h2>Đăng nhập để tìm đối thủ</h2><p>Đấu xếp hạng cần tài khoản cộng đồng để lưu Elo trên máy chủ, không dùng điểm giả lập cục bộ.</p><button type="button" class="primary-btn" id="rankedOpenAccount">Đăng nhập / tạo tài khoản</button></section></section>`;
  const data = rankedMatchState || {};
  const match = data.match || null;
  if (!match) {
    const waiting = Boolean(data.queued);
    const selectedPreset = RANKED_CLOCK_PRESETS.find(item => item.value === selectedRankedTimeControl) || RANKED_CLOCK_PRESETS.find(item => item.value === '3+2');
    const category = classifyTimeControl(selectedPreset.value);
    const elo = Math.max(100, Number(data.timeCategory === category ? data.rating : 0) || rankedRatingOf(user, category));
    const waitSeconds = Math.floor(Math.max(0, Number(data.waitMs) || 0) / 1000);
    const clockSettings = `<div class="ranked-time-setting"><label class="field-label" for="rankedTimeControl">Thời gian thi đấu · ${rankedCategoryLabel(category)}</label><select id="rankedTimeControl" class="field">${rankedClockOptionsMarkup()}</select><small class="field-hint">Elo Bullet, Blitz và Rapid được tính riêng. Chỉ ghép với người đã chọn cùng mốc thời gian.</small></div>`;
    return `<section class="content-page ranked-page"><div class="ranked-topline"><div class="page-intro"><div class="eyebrow">VILA CHESS · XẾP HẠNG TRỰC TUYẾN</div><h1>Ghép trận ngẫu nhiên</h1><p>Ghép người thật theo Elo của đúng thể loại; đồng hồ và kết quả được xác thực bởi máy chủ.</p></div><div class="puzzle-rating-chip">${rankedCategoryLabel(category)} Elo · ${elo}</div></div>${waiting ? `<section class="panel ranked-queue-card"><div class="ranked-queue-orbit">♞</div><h2>Đang tìm đối thủ…</h2><p>Đang ghép người chơi thật theo ${rankedCategoryLabel(data.timeCategory || category)} · ${esc(data.timeControl || selectedRankedTimeControl)}. Bạn có thể hủy hàng đợi trước khi trận bắt đầu.</p><div class="ranked-stat-grid"><div class="ranked-stat"><small>${rankedCategoryLabel(category)} Elo</small><b>${elo}</b></div><div class="ranked-stat"><small>Thời gian chờ</small><b id="rankedQueueWait">${waitSeconds}s</b></div><div class="ranked-stat"><small>Đối thủ</small><b>Đang tìm</b></div></div><div style="margin-top:16px"><button type="button" class="secondary-btn" id="rankedQueueCancel">Hủy tìm trận</button></div></section>` : `<div class="ranked-layout"><div class="ranked-left"><section class="panel ranked-queue-card"><div class="ranked-queue-orbit">⚔</div><h2>Sẵn sàng đấu với người thật?</h2><p>Mỗi tốc độ có Elo riêng. Nếu chưa xếp hạng, máy chủ bắt đầu ở mức 1200 Elo cho từng thể loại.</p>${clockSettings}<button type="button" class="primary-btn full-width" id="rankedQueueStart">⚔ Tìm đối thủ ngẫu nhiên</button><div class="ranked-stat-grid"><div class="ranked-stat"><small>${rankedCategoryLabel(category)} Elo</small><b>${elo}</b></div><div class="ranked-stat"><small>Đã đấu</small><b>${Number(user.games)||0}</b></div><div class="ranked-stat"><small>Thắng</small><b>${Number(user.wins)||0}</b></div></div></section></div><div class="ranked-right"><section class="panel"><h2>Thể loại và đồng hồ</h2><p class="ranked-note">• UltraBullet 15 giây, HyperBullet 30 giây, Bullet 1–2 phút.
• Blitz thường 3–5 phút; Rapid thường 10–30 phút.
• Các mốc có thêm giây (ví dụ 3+2) được hỗ trợ. Phân loại theo thời gian ước tính cho 40 nước.
• Mỗi loại có Elo riêng. Đầu hàng hoặc bỏ trận bị trừ thêm 15 Elo trong loại đang chơi.</p><p class="ranked-note">Ghép đấu online cần server đang chạy và người chơi khác đang chờ đúng mốc thời gian. Đấu rank không hiện nút hoàn tác, gợi ý hay phân tích.</p></section></div></div>`}</section>`;
  }
  const color = match.color || 'w';
  const own = color === 'w' ? match.players?.w : match.players?.b;
  const opponent = match.opponent || (color === 'w' ? match.players?.b : match.players?.w);
  const category = ['bullet', 'blitz', 'rapid'].includes(match.timeCategory) ? match.timeCategory : classifyTimeControl(match.timeControl || '3+2');
  const categoryLabel = rankedCategoryLabel(category);
  const active = match.status === 'active';
  const yourTurn = active && rankedChess.turn() === color;
  let resultTitle = ''; let resultClass = '';
  if (!active) {
    const won = match.result === (color === 'w' ? '1-0' : '0-1');
    const draw = match.result === '1/2-1/2';
    resultTitle = draw ? 'HÒA' : won ? 'CHIẾN THẮNG' : 'THẤT BẠI';
    resultClass = draw ? 'is-draw' : won ? 'is-win' : 'is-loss';
  }
  const change = match.eloChanges;
  const delta = Number(change?.delta) || 0;
  const eloAfter = Number(change?.after) || rankedRatingOf(own, category);
  const resultBlock = !active ? `<section class="ranked-result-hero ${resultClass}"><small class="eyebrow">KẾT QUẢ TRẬN ${categoryLabel.toUpperCase()}</small><h2>${resultTitle}</h2><p>${match.resultReason === 'resignation' || match.resultReason === 'abandoned' ? 'Một người chơi đã rời hoặc đầu hàng.' : match.resultReason === 'disconnect_timeout' ? 'Một người chơi mất kết nối quá 90 giây và bị xử thua.' : match.resultReason === 'time_forfeit' ? 'Một người chơi hết giờ.' : match.resultReason === 'checkmate' ? 'Ván cờ kết thúc bằng chiếu hết.' : 'Ván cờ kết thúc theo luật cờ vua.'} Kết quả do máy chủ lưu lại.</p><div class="ranked-elo-change"><div><small>${categoryLabel} Elo sau trận</small><strong>${eloAfter}</strong></div><div><small>Biến động</small><strong class="${delta > 0 ? 'up' : delta < 0 ? 'down' : ''}">${delta > 0 ? '+' : ''}${delta}</strong></div></div><button type="button" class="primary-btn full-width" id="rankedQueueAgain" style="margin-top:14px">Tìm trận tiếp theo · ${esc(match.timeControl || selectedRankedTimeControl)}</button></section>` : '';
  const opponentName = esc(opponent?.displayName || opponent?.username || 'Đối thủ');
  const ownName = esc(user.displayName || user.username);
  return `<section class="content-page ranked-page"><div class="ranked-topline"><div class="page-intro"><div class="eyebrow">VILA CHESS · ${categoryLabel.toUpperCase()} RANK</div><h1>${active ? 'Đang thi đấu' : 'Trận đã kết thúc'}</h1><p>${esc(match.timeControl || '3+2')} · ${categoryLabel} · ${active ? 'Đồng hồ server và nước đi hợp lệ được xác thực từ xa.' : 'Bàn cờ và lịch sử nước đi được giữ để xem lại.'}</p></div><span class="puzzle-rating-chip">${active ? (yourTurn ? 'ĐẾN LƯỢT BẠN' : 'ĐANG CHỜ ĐỐI THỦ') : `Kết quả ${esc(match.result || '—')}`}</span></div>${resultBlock}<div class="ranked-layout"><div class="ranked-left"><div class="ranked-player-bar"><span>♟ <b>${opponentName}</b><small>Đối thủ · ${rankedRatingOf(opponent, category)} ${categoryLabel} Elo</small></span>${active ? rankedClockFaceMarkup(match, color === 'w' ? 'b' : 'w', 'ĐỒNG HỒ ĐỐI THỦ') : `<span class="turn-chip">${color === 'w' ? 'Cầm Trắng' : 'Cầm Đen'}</span>`}</div><div class="ranked-board-wrap"><div class="ranked-board" id="rankedBoard" role="grid" aria-label="Bàn cờ xếp hạng">${rankedBoardMarkup(match)}</div></div><div class="ranked-player-bar"><span>♙ <b>${ownName}</b><small>Bạn · ${rankedRatingOf(own, category)} ${categoryLabel} Elo</small></span>${active ? rankedClockFaceMarkup(match, color, 'ĐỒNG HỒ CỦA BẠN') : `<span class="turn-chip">Đã xong · Elo ${eloAfter}</span>`}</div><div class="ranked-stat-grid"><div class="ranked-stat"><small>Thể loại</small><b>${categoryLabel}</b></div><div class="ranked-stat"><small>Số nửa nước</small><b>${match.moves?.length || 0}</b></div><div class="ranked-stat"><small>${categoryLabel} Elo</small><b>${active ? rankedRatingOf(own, category) : eloAfter}</b></div></div>${active ? '<button type="button" class="danger-btn full-width" id="rankedForfeitBtn">Đầu hàng / thoát trận (mất Elo)</button>' : ''}</div><div class="ranked-right"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ NƯỚC ĐI</small><h2>Biên bản trận</h2></div><span class="context-icon">♞</span></div><div class="ranked-move-list" id="rankedMoveList">${rankedMoveListMarkup(match)}</div><p class="ranked-note">Biên bản được nhận từ máy chủ và phát lại bằng luật cờ vua tiêu chuẩn. Chế độ rank không hỗ trợ hoàn tác, gợi ý hoặc phân tích trong ván.</p></section><section class="panel"><h2>Đối thủ</h2><p>${opponentName} · ${rankedRatingOf(opponent, category)} ${categoryLabel} Elo</p><p class="ranked-note">${active ? (yourTurn ? 'Chạm quân để chọn nước hợp lệ rồi chạm ô đích.' : 'Đợi đối thủ đi; bàn cờ tự đồng bộ khi có nước mới.') : `Mọi Elo ${categoryLabel} trong ván đã được cập nhật tại server.`}</p></section></div></div></section>`;
}
function rankedSyncChess(match) {
  if (!match) return;
  let clone;
  try { clone = new Chess(match.startFen || new Chess().fen()); } catch { clone = new Chess(); }
  for (const move of match.moves || []) {
    try { clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); } catch { break; }
  }
  rankedChess = clone; rankedSelected = null; rankedTargets = [];
}
function rankedStateSignature(data) {
  const m = data?.match;
  return m ? `${m.id}|${m.status}|${m.fen}|${(m.moves || []).length}|${m.result || ''}|${m.timeControl || ''}|${m.timeCategory || ''}|${m.eloChanges?.delta ?? ''}` : `${Boolean(data?.queued)}|${data?.rating || ''}|${data?.timeControl || ''}|${data?.timeCategory || ''}`;
}
function setSelectedRankedTimeControl(value) {
  if (!RANKED_CLOCK_PRESETS.some(preset => preset.value === value)) return false;
  selectedRankedTimeControl = value;
  try { localStorage.setItem('vila.chess.ranked-time-control.v1', JSON.stringify(value)); } catch {}
  return true;
}
async function refreshRankedStatus(silent = true) {
  if (rankedPollBusy || !socialState.token || currentView !== 'ranked') return;
  rankedPollBusy = true;
  const old = rankedMatchState;
  const oldMatch = old?.match;
  const oldSignature = rankedStateSignature(old);
  try {
    const next = await socialApi('/ranked/status');
    const nextSignature = rankedStateSignature(next);
    rankedMatchState = next;
    if (next.match?.timeControl) setSelectedRankedTimeControl(next.match.timeControl);
    if (next.match) rankedSyncChess(next.match);
    if (nextSignature !== oldSignature) {
      if (!oldMatch && next.match?.status === 'active') toast('Đã ghép trận! Trận đấu xếp hạng đã bắt đầu.', 'success');
      if (oldMatch?.status === 'active' && next.match?.status === 'finished') toast('Trận đã kết thúc. Elo đã được cập nhật bởi máy chủ.', 'success');
      rankedLastSignature = nextSignature;
      if (currentView === 'ranked') renderView();
    } else {
      const wait = $('#rankedQueueWait');
      if (wait) wait.textContent = `${Math.floor(Math.max(0, Number(next.waitMs) || 0) / 1000)}s`;
    }
  } catch (error) {
    if (!silent) toast(`Không thể cập nhật trận: ${error.message || error}`);
  } finally { rankedPollBusy = false; }
}
function syncRankedTimers() {
  const shouldPoll = currentView === 'ranked' && Boolean(rankedMatchState?.queued || rankedMatchState?.match?.status === 'active');
  if (shouldPoll && !rankedPollTimer) rankedPollTimer = setInterval(() => { void refreshRankedStatus(true); }, 1800);
  else if (!shouldPoll && rankedPollTimer) { clearInterval(rankedPollTimer); rankedPollTimer = null; }
  const shouldTickClock = currentView === 'ranked' && rankedMatchState?.match?.status === 'active';
  if (shouldTickClock && !rankedClockDisplayTimer) rankedClockDisplayTimer = setInterval(updateRankedClockDisplay, 200);
  else if (!shouldTickClock && rankedClockDisplayTimer) { clearInterval(rankedClockDisplayTimer); rankedClockDisplayTimer = null; }
  if (shouldTickClock) updateRankedClockDisplay();
}
function startRankedPolling() { syncRankedTimers(); }
async function startRankedQueue() {
  if (!socialState.token || !socialState.user) { setView('friends'); toast('Đăng nhập trước khi bắt đầu đấu xếp hạng.'); return; }
  const button = $('#rankedQueueStart');
  if (button) { button.disabled = true; button.textContent = 'Đang vào hàng đợi…'; }
  try {
    rankedMatchState = await socialApi('/ranked/queue', { method: 'POST', body: JSON.stringify({ timeControl: selectedRankedTimeControl }) });
    if (rankedMatchState.match?.timeControl) setSelectedRankedTimeControl(rankedMatchState.match.timeControl);
    if (rankedMatchState.match) rankedSyncChess(rankedMatchState.match);
    rankedLastSignature = rankedStateSignature(rankedMatchState);
    renderView(); startRankedPolling();
    if (rankedMatchState.queued) toast('Đã vào hàng đợi ghép trận theo Elo.');
  } catch (error) {
    toast(`Không thể tìm trận: ${error.message || error}`);
    if (button) { button.disabled = false; button.textContent = '⚔ Tìm đối thủ ngẫu nhiên'; }
  }
}
async function quitRankedMatch(navigating = false) {
  const match = rankedMatchState?.match;
  try {
    if (match?.status === 'active') {
      const data = await socialApi(`/ranked/matches/${encodeURIComponent(match.id)}/resign`, { method: 'POST', body: '{}' });
      rankedMatchState = data; if (data.match) rankedSyncChess(data.match);
      if (!navigating) { toast(`Đã đầu hàng. Elo được cập nhật ở máy chủ (${data.match?.eloChanges?.delta > 0 ? '+' : ''}${data.match?.eloChanges?.delta ?? 0}).`); renderView(); }
    } else if (rankedMatchState?.queued) {
      await socialApi('/ranked/cancel-queue', { method: 'POST', body: '{}' });
      rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user) };
      if (!navigating) { toast('Đã hủy hàng đợi. Chưa phát sinh thay đổi Elo.'); renderView(); }
    }
  } catch (error) { if (!navigating) toast(`Không thể kết thúc trận: ${error.message || error}`); }
}
async function submitRankedMove(from, to, promotion = '') {
  const match = rankedMatchState?.match;
  if (!match || match.status !== 'active' || rankedMoveBusy) return;
  if (rankedChess.turn() !== match.color) { toast('Chưa đến lượt của bạn.'); return; }
  const expectedPly = (match.moves || []).length;
  rankedMoveBusy = true;
  const board = $('#rankedBoard'); if (board) board.setAttribute('aria-busy', 'true');
  try {
    const data = await socialApi(`/ranked/matches/${encodeURIComponent(match.id)}/move`, { method: 'POST', body: JSON.stringify({ from, to, promotion, expectedPly }) });
    rankedMatchState = data;
    if (data.match) rankedSyncChess(data.match);
    rankedLastSignature = rankedStateSignature(data);
    rankedMoveBusy = false;
    renderView();
    if (data.match?.status === 'finished') toast('Đã xác nhận kết quả và Elo trên máy chủ.', 'success');
  } catch (error) {
    await refreshRankedStatus(true);
    toast(`Nước đi chưa được chấp nhận: ${error.message || error}`);
  } finally { rankedMoveBusy = false; }
}
function renderPuzzleBoardMarkup() {
  const rows = puzzleGame.board();
  const orient = puzzleState.rootColor || 'w';
  const ranks = orient === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orient === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const targets = new Map();
  for (const move of puzzleState.targets) { if (!targets.has(move.to)) targets.set(move.to, []); targets.get(move.to).push(move); }
  const hintFrom = puzzleState.showHint ? puzzleState.solutionUci.slice(0,2) : '';
  const hintTo = puzzleState.showHint ? puzzleState.solutionUci.slice(2,4) : '';
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const sq = `${file}${rank}`;
    const piece = puzzleGame.get(sq); const choices = targets.get(sq) || [];
    const movedFrom = puzzleState.lastMove?.from === sq; const movedTo = puzzleState.lastMove?.to === sq;
    const classes = ['puzzle-square', ((file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light'), puzzleState.selected === sq ? 'selected' : '', choices.length ? (piece ? 'capture-target' : 'legal-target') : '', hintFrom === sq ? 'solution-from' : movedFrom ? 'solution-from' : '', hintTo === sq ? 'solution-to' : movedTo ? 'solution-to' : ''].filter(Boolean).join(' ');
    const tag = hintTo === sq ? `<span class="puzzle-tag">BEST</span>` : movedTo ? `<span class="puzzle-tag">✓</span>` : '';
    html += `<button type="button" class="${classes}" data-puzzle-square="${sq}" aria-label="${sq}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}" ${puzzleState.status !== 'ready' ? 'disabled' : ''}>${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${tag}${col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}
function renderPuzzleView() {
  const saved = puzzleState.solvedCount;
  const ready = puzzleState.status === 'ready';
  const loading = puzzleState.status === 'loading';
  const feedbackClass = ['solved', 'revealed'].includes(puzzleState.status) ? 'success' : puzzleState.status === 'error' ? 'error' : '';
  return `<section class="content-page puzzle-page"><div class="puzzle-topline"><div class="page-intro"><div class="eyebrow">VILA CHESS · TACTICAL LAB</div><h1>Câu đố cờ vua ngẫu nhiên</h1><p>Mỗi thử thách tạo một thế cờ hợp lệ mới rồi dùng Stockfish để chấm nước đi tốt nhất. Đây là bài luyện vô hạn sinh theo lượt, không phải tuyên bố có hàng tỷ câu đố biên soạn sẵn.</p></div><span class="puzzle-rating-chip">♞ Stockfish · luật cờ chuẩn</span></div><div class="puzzle-layout"><div class="puzzle-left"><div class="puzzle-board-wrap"><div id="puzzleBoard" class="puzzle-board" role="grid" aria-label="Bàn cờ câu đố">${renderPuzzleBoardMarkup()}</div></div><div class="puzzle-preset-row"><button type="button" class="secondary-btn" id="puzzleNew" ${loading ? 'disabled' : ''}>${loading ? 'Đang tạo thế cờ…' : '🧩 Câu đố mới'}</button><button type="button" class="secondary-btn" id="puzzleHint" ${ready ? '' : 'disabled'}>Gợi ý</button><button type="button" class="secondary-btn" id="puzzleAnalyze" ${puzzleState.rootFen ? '' : 'disabled'}>Phân tích bằng Stockfish</button><button type="button" class="secondary-btn" id="puzzleShowAnswer" ${ready ? '' : 'disabled'}>Xem lời giải</button></div><div id="puzzleFeedback" class="puzzle-feedback ${feedbackClass}" aria-live="polite">${esc(puzzleState.lastMessage)}</div></div><div class="puzzle-right"><section class="panel puzzle-status-card"><div class="puzzle-progress-row"><div><small class="eyebrow">TIẾN BỘ CỦA BẠN</small><div><strong>${saved}</strong> câu đã giải</div></div><span class="puzzle-rating-chip">${ready ? `${puzzleState.rootPly} nửa nước ngẫu nhiên` : loading ? 'Đang chuẩn bị' : puzzleState.status === 'solved' ? 'Đã giải' : puzzleState.status === 'revealed' ? 'Đã xem lời giải' : 'Sẵn sàng'}</span></div><div class="ranked-stat-grid"><div class="ranked-stat"><small>Lượt thử</small><b>${puzzleState.attempts}</b></div><div class="ranked-stat"><small>Nước đi</small><b>${puzzleState.solutionUci ? esc(puzzleState.solutionUci.toUpperCase()) : '—'}</b></div><div class="ranked-stat"><small>Điểm Elo</small><b>Không đổi</b></div></div><p class="puzzle-note">Câu đố không làm thay đổi Elo thi đấu. Khi giải đúng, tiến độ nhiệm vụ được cập nhật. Vì vị trí khởi đầu được tạo ngẫu nhiên, một số bài có thể tập trung vào nước phòng thủ/đơn giản chứ không phải đòn chiến thuật ép buộc.</p></section><section class="panel"><h2>Phân tích thế cờ</h2><div id="puzzleAnalysisResult" class="puzzle-feedback">${ready ? 'Chọn nước đi trên bàn cờ; gợi ý và lời giải sẽ được đánh dấu trực tiếp trên ô cờ.' : 'Tạo câu đố mới để bắt đầu.'}</div><p class="puzzle-note">Nước đi được kiểm tra bằng cùng thư viện luật cờ vua; nước tốt nhất được tính bằng Stockfish đang tích hợp trong ứng dụng. Khi engine bận hoặc chưa tải xong, hãy chờ rồi thử lại.</p></section><button type="button" class="secondary-btn full-width" id="puzzleBackToPlay">Quay lại bàn chơi ↗</button></div></div></section>`;
}
function generateRandomLegalPuzzlePosition() {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const clone = new Chess();
    const wantedPlies = 10 + Math.floor(Math.random() * 23);
    for (let ply = 0; ply < wantedPlies; ply += 1) {
      const legal = clone.moves({ verbose: true });
      if (!legal.length) break;
      const move = legal[Math.floor(Math.random() * legal.length)];
      try { clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); } catch { break; }
      if (clone.isGameOver()) break;
    }
    if (!clone.isGameOver() && clone.moves().length) return { fen: clone.fen(), plies: clone.history().length };
  }
  return { fen: new Chess().fen(), plies: 0 };
}
async function startRandomPuzzle() {
  puzzleState.status = 'loading'; puzzleState.lastMessage = 'Đang tạo thế cờ hợp lệ và tìm một nước đi chiến thuật bằng Stockfish…';
  puzzleState.showHint = false; puzzleState.selected = null; puzzleState.targets = []; puzzleState.solutionUci = '';
  if (currentView === 'puzzles') renderView();
  const button = $('#puzzleNew'); if (button) { button.disabled = true; button.textContent = 'Stockfish đang tính…'; }
  try {
    let chosen = null;
    // Try several legal random positions to prefer a tactical best move (capture,
    // promotion, check, or mate). A fallback keeps the feature usable on a position
    // where the engine's best move is positional instead of forcing.
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const position = generateRandomLegalPuzzlePosition();
      const best = await requestStockfishUci(position.fen, { skill: 20, depth: 14, moveTimeMs: 850, timeoutMs: 9000 });
      if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(best)) throw new Error('Stockfish không trả về nước đi hợp lệ cho thế cờ mới.');
      const clone = new Chess(position.fen);
      const answer = clone.move({ from: best.slice(0,2), to: best.slice(2,4), ...(best[4] ? { promotion: best[4] } : {}) });
      if (!answer) throw new Error('Không thể kiểm tra nước trả lời của Stockfish.');
      const tactical = Boolean(answer.captured || answer.promotion || /[+#]/.test(answer.san));
      chosen = { position, best, tactical };
      if (tactical || attempt === 3) break;
    }
    if (!chosen) throw new Error('Không tìm được thế cờ để chấm.');
    puzzleState.rootFen = chosen.position.fen; puzzleState.rootPly = chosen.position.plies;
    puzzleState.rootColor = new Chess(chosen.position.fen).turn(); puzzleGame = new Chess(chosen.position.fen);
    puzzleState.solutionUci = chosen.best; puzzleState.status = 'ready'; puzzleState.attempts = 0;
    puzzleState.lastMove = null; puzzleState.showHint = false;
    puzzleState.lastMessage = chosen.tactical
      ? `Tìm nước chiến thuật tốt nhất cho ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi. Chọn quân rồi chạm ô đích.`
      : `Tìm nước tốt nhất cho ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi. Thế cờ này thiên về nước chiến lược/phòng thủ.`;
  } catch (error) {
    puzzleState.status = 'error'; puzzleState.lastMessage = `Không tạo được câu đố: ${String(error.message || error)}. Kiểm tra trạng thái Stockfish rồi bấm “Câu đố mới” để thử lại.`;
  }
  if (currentView === 'puzzles') renderView();
}
function selectPuzzleSquare(square) {
  if (puzzleState.status !== 'ready') return;
  const piece = puzzleGame.get(square);
  if (puzzleState.selected && puzzleState.targets.some(move => move.to === square)) {
    const move = puzzleState.targets.find(candidate => candidate.to === square);
    void submitPuzzleAnswer(move);
    return;
  }
  if (piece && piece.color === puzzleGame.turn()) {
    puzzleState.selected = square; puzzleState.targets = puzzleGame.moves({ square, verbose: true });
  } else { puzzleState.selected = null; puzzleState.targets = []; }
  const board = $('#puzzleBoard'); if (board) board.innerHTML = renderPuzzleBoardMarkup();
}
function showPuzzleHint(reveal = false) {
  if (!puzzleState.solutionUci) { toast('Tạo câu đố trước khi xin gợi ý.'); return; }
  puzzleState.showHint = true;
  const moveInput = { from: puzzleState.solutionUci.slice(0,2), to: puzzleState.solutionUci.slice(2,4), ...(puzzleState.solutionUci[4] ? { promotion: puzzleState.solutionUci[4] } : {}) };
  let san = puzzleState.solutionUci.toUpperCase();
  try { san = new Chess(puzzleState.rootFen).move(moveInput)?.san || san; } catch {}
  const output = $('#puzzleAnalysisResult'); if (output) output.textContent = `${reveal ? 'Lời giải tốt nhất' : 'Gợi ý'}: ${san} (${puzzleState.solutionUci}). Ô đi và ô đến đã được đánh dấu.`;
  if (reveal && puzzleState.status === 'ready') {
    // Apply the answer to a fresh copy; SAN calculation above must not consume the move.
    const answerBoard = new Chess(puzzleState.rootFen);
    const answer = answerBoard.move(moveInput);
    if (answer) { puzzleState.status = 'revealed'; puzzleState.lastMessage = `Lời giải: ${answer.san}. Thế cờ được hiển thị sau nước mạnh nhất; lần xem lời giải không tính là tự giải đúng.`; puzzleState.lastMove = answer; puzzleGame = answerBoard; puzzleState.selected = null; puzzleState.targets = []; }
  }
  if (currentView === 'puzzles') renderView();
}
async function submitPuzzleAnswer(candidate) {
  if (puzzleState.status !== 'ready') return;
  const uci = `${candidate.from}${candidate.to}${candidate.promotion || ''}`;
  puzzleState.attempts += 1;
  if (uci !== puzzleState.solutionUci) {
    puzzleState.selected = null; puzzleState.targets = []; puzzleState.showHint = false; puzzleGame = new Chess(puzzleState.rootFen);
    puzzleState.lastMessage = 'Chưa phải nước Stockfish đánh giá tốt nhất. Vị trí đã được đặt lại; thử nước khác hoặc xem gợi ý.';
    puzzleState.status = 'ready'; renderView(); return;
  }
  try {
    const move = puzzleGame.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) });
    puzzleState.lastMove = move; puzzleState.status = 'solved'; puzzleState.selected = null; puzzleState.targets = [];
    puzzleState.lastMessage = `Chính xác: ${move.san}. Đã tìm ra nước Stockfish chọn ở thế cờ này.`;
    puzzleState.solvedCount += 1;
    try { localStorage.setItem('vila.chess.puzzles.solved.v1', String(puzzleState.solvedCount)); } catch {}
    recordDailyEvent('solve_puzzle');
    if (currentView === 'puzzles') renderView();
  } catch (error) { puzzleState.lastMessage = `Không thể áp dụng nước: ${error.message || error}`; renderView(); }
}
function wireRankedActions() {
  $('#rankedOpenAccount')?.addEventListener('click', () => setView('friends'));
  $('#rankedTimeControl')?.addEventListener('change', event => {
    const value = event.currentTarget.value;
    if (!setSelectedRankedTimeControl(value)) return;
    const category = classifyTimeControl(value);
    rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, category), timeControl: value, timeCategory: category };
    renderView();
  });
  $('#rankedQueueStart')?.addEventListener('click', startRankedQueue);
  $('#rankedQueueCancel')?.addEventListener('click', async () => { try { await socialApi('/ranked/cancel-queue', { method: 'POST', body: '{}' }); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user) }; renderView(); toast('Đã hủy hàng đợi.'); } catch (error) { toast(`Không thể hủy hàng đợi: ${error.message || error}`); } });
  $('#rankedQueueAgain')?.addEventListener('click', async () => { setSelectedRankedTimeControl(rankedMatchState?.match?.timeControl || selectedRankedTimeControl); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, classifyTimeControl(selectedRankedTimeControl)) }; await startRankedQueue(); });
  $('#rankedForfeitBtn')?.addEventListener('click', async () => { if (confirm('Đầu hàng/thoát trận sẽ tính là thua và có thể bị trừ thêm 15 Elo. Tiếp tục?')) await quitRankedMatch(false); });
  $('#rankedBoard')?.addEventListener('click', event => {
    const button = event.target.closest('[data-ranked-square]'); if (!button || rankedMoveBusy) return;
    const match = rankedMatchState?.match; if (!match || match.status !== 'active' || rankedChess.turn() !== match.color) return;
    const square = button.dataset.rankedSquare; const piece = rankedChess.get(square);
    if (rankedSelected && rankedTargets.some(move => move.to === square)) {
      const options = rankedTargets.filter(move => move.to === square);
      const promotion = options.find(move => move.promotion)?.promotion;
      if (promotion) void choosePromotion(rankedChess.turn()).then(type => type && submitRankedMove(rankedSelected, square, type));
      else void submitRankedMove(rankedSelected, square);
      rankedSelected = null; rankedTargets = []; return;
    }
    if (piece && piece.color === match.color) { rankedSelected = square; rankedTargets = rankedChess.moves({ square, verbose: true }); }
    else { rankedSelected = null; rankedTargets = []; }
    const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(match);
  });
  if (rankedMatchState?.queued || rankedMatchState?.match?.status === 'active') startRankedPolling();
  if (rankedMatchState?.match) { const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(rankedMatchState.match); }
}
function wirePuzzleActions() {
  $('#puzzleNew')?.addEventListener('click', startRandomPuzzle);
  $('#puzzleHint')?.addEventListener('click', () => showPuzzleHint(false));
  $('#puzzleShowAnswer')?.addEventListener('click', () => showPuzzleHint(true));
  $('#puzzleAnalyze')?.addEventListener('click', async () => {
    if (!puzzleState.rootFen) return;
    const output = $('#puzzleAnalysisResult'); if (output) output.textContent = 'Stockfish đang phân tích thế cờ…';
    try {
      const best = await requestStockfishUci(puzzleState.rootFen, { skill: 20, depth: 20, moveTimeMs: 1800, timeoutMs: 18000 });
      const clone = new Chess(puzzleState.rootFen); const move = clone.move({ from: best.slice(0,2), to: best.slice(2,4), ...(best[4] ? { promotion: best[4] } : {}) });
      puzzleState.solutionUci = best; puzzleState.showHint = true;
      if (output) output.textContent = move ? `Nước tốt nhất theo Stockfish: ${move.san} (${best}). Mũi chỉ dẫn đánh dấu trên bàn cờ.` : `Engine trả về ${best}.`;
      const board = $('#puzzleBoard'); if (board) board.innerHTML = renderPuzzleBoardMarkup();
    } catch (error) { if (output) output.textContent = `Không thể phân tích: ${error.message || error}`; }
  });
  $('#puzzleBackToPlay')?.addEventListener('click', () => setView('play'));
  $('#puzzleBoard')?.addEventListener('click', event => { const button = event.target.closest('[data-puzzle-square]'); if (button) selectPuzzleSquare(button.dataset.puzzleSquare); });
}

function renderView() {
  readDailyProgress();
  maybeRecordRatedGame();
  maybeArchiveCompletedGame();
  document.body.classList.toggle('play-screen-active', currentView === 'play');
  const root = $('#mainView');
  if (!root) return;
  if (currentView === 'home') root.innerHTML = renderHomeView();
  else if (currentView === 'play') root.innerHTML = renderPlayView();
  else if (currentView === 'ranked') root.innerHTML = renderRankedView();
  else if (currentView === 'puzzles') root.innerHTML = renderPuzzleView();
  else if (currentView === 'openings') root.innerHTML = renderOpeningsView();
  else if (currentView === 'coach') root.innerHTML = renderCoachView();
  else if (currentView === 'arena') root.innerHTML = renderArenaView();
  else if (currentView === 'lichess') root.innerHTML = renderLichessView();
  else if (currentView === 'leaderboard') root.innerHTML = renderLeaderboardView();
  else if (currentView === 'friends') root.innerHTML = renderFriendsView();
  else if (currentView === 'inbox') root.innerHTML = renderInboxView();
  else if (currentView === 'health') root.innerHTML = renderSystemHealthView();
  else if (currentView === 'missions') root.innerHTML = renderMissionsView();
  else if (currentView === 'shop') root.innerHTML = renderShopView();
  else if (currentView === 'admin') root.innerHTML = renderAdminView();
  else if (currentView === 'history') root.innerHTML = renderHistoryView();
  else root.innerHTML = renderSettingsView();
  wireCommonActions();
  if (currentView === 'home') wireHomeActions();
  if (currentView === 'ranked') wireRankedActions();
  if (currentView === 'puzzles') wirePuzzleActions();
  if (currentView === 'friends') wireFriendsActions();
  if (currentView === 'inbox') wireInboxActions();
  if (currentView === 'health') wireSystemHealthActions();
  if (currentView === 'missions') wireMissionsActions();
  if (currentView === 'shop') wireShopActions();
  if (currentView === 'leaderboard') wireLeaderboardActions();
  if (currentView === 'admin') wireAdminActions();
  if (currentView === 'play') {
    renderBoard();
    watchBoardLayout();
    wirePlayActions();
    renderAnalysisPanel(); // Re-sync hidden/busy state after returning from another view.
  } else {
    boardResizeObserver?.disconnect();
    boardResizeObserver = null;
  }
  if (currentView === 'openings') wireOpeningActions();
  if (currentView === 'coach') wireCoachActions();
  if (currentView === 'arena') { renderArenaPosition(); wireArenaActions(); }
  if (currentView === 'lichess') wireLichessActions();
  if (currentView === 'settings') wireSettingsActions();
  if (currentView === 'history') wireHistoryActions();
  syncRankedTimers();
}
function renderExperienceChoiceMarkup() {
  if (experienceLevel === 'beginner') return '<small class="experience-selected-label">Đang chọn: người mới chơi</small>';
  if (experienceLevel === 'experienced') return '<small class="experience-selected-label">Đang chọn: đã hiểu luật</small>';
  return '<div class="experience-choice"><button type="button" class="secondary-btn" data-experience-choice="beginner">Mới chơi</button><button type="button" class="secondary-btn" data-experience-choice="experienced">Đã hiểu luật</button></div>';
}
function renderPlayView() {
  const setupOpen = !gameStarted && (typeof window.matchMedia !== 'function' || window.matchMedia('(min-width: 681px)').matches);
  const modeLabel = mode === 'stockfish' ? 'Stockfish' : mode === 'ai' ? 'AI qua API' : mode === 'lichess' ? 'Lichess trực tuyến' : 'Hai người chơi';
  const clockFace = color => `<div class="clock-face ${color === humanColor ? 'user-clock' : 'opponent-clock'}"><span id="clock${color === 'w' ? 'White' : 'Black'}Name">${esc(clockPlayerName(color))}</span><strong id="clock${color === 'w' ? 'White' : 'Black'}">${clockState.enabled ? formatClockTime(clockState.remaining[color]) : (mode === 'lichess' ? 'Lichess' : '∞')}</strong></div>`;
  const topClockColor = humanColor === 'w' ? 'b' : 'w';
  const bottomClockColor = humanColor === 'w' ? 'w' : 'b';
  return `<section class="play-view-shell">
    <header class="play-room-heading"><div class="play-room-title"><div class="play-breadcrumb">VILA CHESS <span>/</span> CHƠI CỜ</div><h1>Chơi cờ</h1><p>Đấu với Stockfish, thử AI qua API hoặc mở ván trực tuyến.</p></div><div class="play-room-actions"><span class="play-book-chip"><b id="playOpeningCount">${OPENINGS.length.toLocaleString()}</b><small>khai cuộc</small></span><button type="button" class="secondary-btn" data-play-view="openings">⌘ Khai cuộc</button><button type="button" class="secondary-btn" data-play-view="coach">✦ AI phân tích</button><button type="button" class="secondary-btn" data-play-view="history">↶ Lịch sử</button></div></header>
    <section class="play-layout">
    <div class="board-column">
      <div class="opponent-line"><div class="avatar">${mode === 'local' ? '♙' : mode === 'ai' ? '✦' : mode === 'lichess' ? '↗' : '♞'}</div><div class="opponent-meta"><b>${mode === 'local' ? 'Người chơi Đen / Trắng' : mode === 'ai' ? 'VILA Chess AI' : mode === 'lichess' ? `Lichess · ${esc(activeOnlineGame?.opponent || 'đối thủ trực tuyến')}` : 'Stockfish'}</b><small>${modeLabel} · ${mode === 'stockfish' ? `Skill ${settings.botSkill}/20` : mode === 'ai' ? esc(settings.model) : mode === 'lichess' ? `Ván ${esc(activeOnlineGame?.id || '')}` : 'Cùng thiết bị'}</small></div><span id="turnChip" class="turn-chip">Lượt Trắng</span></div>
      <div class="clock-face-row">${clockFace(topClockColor)}<label class="clock-setting-inline" for="clockPreset">Thời gian<select id="clockPreset" class="field">${CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${settings.clockPreset === preset.value ? 'selected' : ''}>${preset.label}</option>`).join('')}</select></label></div>
      <div class="board-frame ${!gameStarted ? 'is-prestart' : ''}"><div class="board-surface"><div id="board" class="chessboard" role="grid" aria-label="Bàn cờ vua"></div><svg id="boardArrows" class="board-arrows" viewBox="0 0 8 8" preserveAspectRatio="none" aria-hidden="true"><defs><marker id="hintArrowHead" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadGreen" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadRed" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadYellow" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker></defs><g id="manualAnnotationLines"></g><g id="hintArrowLine"></g></svg><div id="boardAnnotationWidget" class="board-annotation-widget ${annotationCollapsed ? 'is-collapsed' : ''}" ${!gameStarted || !['stockfish','ai'].includes(mode) ? 'hidden' : ''} aria-label="Công cụ vẽ phân tích"><button type="button" id="annotationWidgetGrip" class="annotation-widget-grip" title="Giữ để di chuyển" aria-label="Di chuyển thanh công cụ">⠿</button><button type="button" id="annotationWidgetToggle" class="annotation-widget-toggle" title="Thu gọn / mở công cụ" aria-expanded="${!annotationCollapsed}">✎</button><div id="boardAnnotationTools" class="board-annotation-tools" ${annotationCollapsed ? 'hidden' : ''}><button type="button" data-annotation-tool="arrow" title="Kéo để vẽ mũi tên" aria-label="Vẽ mũi tên" aria-pressed="${annotationTool === 'arrow'}">↗</button><button type="button" data-annotation-tool="circle" title="Khoanh ô" aria-label="Khoanh ô" aria-pressed="${annotationTool === 'circle'}">◯</button><button type="button" id="annotationColorCycle" class="annotation-color-cycle color-green" title="Đổi màu nét" aria-label="Màu nét: xanh lá">●</button><button type="button" id="annotationClear" title="Xóa dấu vẽ" aria-label="Xóa dấu vẽ">⌫</button></div></div>${!gameStarted ? `<div class="board-start-overlay"><span class="start-icon">♟</span><b>Sẵn sàng vào trận?</b><small>Chọn chế độ và màu quân, sau đó bắt đầu ván mới.</small>${renderExperienceChoiceMarkup()}<button id="startGameOverlay" type="button" class="primary-btn">▶ Bắt đầu chơi</button></div>` : ''}</div></div><div class="evaluation-meter-row" aria-label="Thanh đánh giá thế cờ"><span>TRẮNG</span><div id="evaluationMeter" class="evaluation-meter" role="img" aria-label="Lợi thế ước tính của Trắng"><span id="evaluationMeterWhite"></span></div><span>ĐEN</span></div><div class="opening-recognition" id="openingRecognition">${(recognizeOpening(game.history(), OPENINGS, { minPlies: 5 }) || (currentOpening && game.history().length >= 4 ? { name: currentOpening } : null)) ? `Khai cuộc nhận diện: ${esc((recognizeOpening(game.history(), OPENINGS, { minPlies: 5 }) || { name: currentOpening }).name)}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước')}</div>
      <div class="clock-face-row clock-bottom-row">${clockFace(bottomClockColor)}<small id="clockHint" class="clock-hint">${clockState.enabled ? `Thời gian + ${Math.round(clockState.incrementMs / 1000)} giây cộng mỗi nước` : 'Đồng hồ không giới hạn'}</small></div>
      <div class="board-bottom"><span id="boardStatus">Trắng đang đi</span><div class="board-bottom-actions"><button id="flipBoard" class="text-btn">⇅ Đảo bàn</button><button id="toggleChessMusic" class="text-btn" type="button" title="Gymnopédie No. 1 (Kevin MacLeod); cần internet, có nhạc tổng hợp dự phòng khi offline">♫ Nhạc nền: Tắt</button><button id="resignBtn" class="text-btn resign-btn" type="button" ${!gameStarted || game.isGameOver() || clockFlagged || manualGameResult ? 'disabled' : ''}>⚑ Đầu hàng</button></div></div>
      <div class="analysis-action-row"><button id="analyzePosition" class="secondary-btn">♙ Phân tích 3 biến</button><small>Stockfish · PV × 3</small></div>
      <section id="analysisPanel" class="analysis-panel" ${analysisVisible || analysisActive || analysisVariants.length ? '' : 'hidden'} aria-live="polite"><div class="analysis-panel-heading"><b>Phân tích Stockfish</b><span>MultiPV 3 · điểm theo Trắng</span></div><div id="analysisLines" class="analysis-lines"><div class="analysis-empty">Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.</div></div></section>
      <section class="hint-card" aria-live="polite"><div class="hint-card-heading"><b>Gợi ý nước đi</b><small>Stockfish nội bộ</small></div><p id="hintSuggestionText">${lastHintMove && lastHintMove.fen === game.fen() ? `${esc(lastHintMove.source)}: ${esc(lastHintMove.san)} · ${esc(lastHintMove.from)} → ${esc(lastHintMove.to)}` : 'Nhấn “Gợi ý” để tính nước hợp lệ cho thế cờ hiện tại.'}</p><div class="hint-card-actions"><button type="button" id="speakHint" class="tiny-action-btn" ${lastHintMove && lastHintMove.fen === game.fen() ? '' : 'disabled'}>🔊 Phát chỉ dẫn</button><button type="button" id="useHint" class="tiny-action-btn" ${lastHintMove && lastHintMove.fen === game.fen() ? '' : 'disabled'}>Dùng nước này</button></div></section>
      <div class="mobile-action-row"><button class="primary-btn" id="newGame">＋ Ván mới</button><button class="secondary-btn" id="undoMove">↶ Hoàn tác</button><button class="secondary-btn" id="hintMove">✦ Gợi ý</button></div>
    </div>
    <aside class="side-column">
      <details class="panel game-setup" id="gameSetupPanel" ${setupOpen ? 'open' : ''}><summary class="game-setup-summary"><span><small class="eyebrow">VÁN CỜ</small><strong>Thiết lập trận</strong><small class="game-setup-subtitle">Chế độ · màu quân · sức mạnh bot</small></span><span class="setup-chevron" aria-hidden="true">⌄</span></summary><div class="game-setup-body">
        <div class="experience-banner"><span>♟</span><div><b>${experienceLevel === 'beginner' ? 'Lộ trình người mới' : experienceLevel === 'experienced' ? 'Chế độ người đã biết luật' : 'Chọn mức kinh nghiệm'}</b><small>${experienceLevel === 'beginner' ? 'Ưu tiên Rapid, bot dễ và gợi ý trong chế độ solo.' : experienceLevel === 'experienced' ? 'Tự chọn thời gian, sức mạnh bot và luyện phân tích.' : 'Mới chơi hoặc đã quen luật cờ vua?'}</small></div><button type="button" id="changeExperience" class="tiny-btn">Đổi</button></div><label class="field-label" for="modeSelect">Chế độ chơi / đối thủ</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish — chơi với máy</option><option value="ai" ${mode === 'ai' ? 'selected' : ''}>AI qua API — thử nghiệm</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người trên cùng máy</option></select><p class="field-hint engine-choice-note">Stockfish: engine cờ vua chạy offline. AI qua API: mô hình đã cấu hình chọn nước hợp lệ, chất lượng phụ thuộc model và endpoint. Lichess: đối thủ/đấu qua dịch vụ bên ngoài. Rank người thật nằm ở mục Đấu xếp hạng riêng.</p>
        <div class="two-fields"><div><label class="field-label" for="colorSelect">Bạn cầm quân</label><select id="colorSelect" class="field" ${mode === 'lichess' ? 'disabled' : ''}><option value="w" ${humanColor === 'w' ? 'selected' : ''}>Trắng</option><option value="b" ${humanColor === 'b' ? 'selected' : ''}>Đen</option></select></div><div><label class="field-label" for="skillSelect">Sức mạnh bot (Elo 500–3200)</label><select id="skillSelect" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất · không giới hạn Elo</option>${[...new Set([...Array.from({ length: 28 }, (_, i) => 500 + i * 100), 3200, ...(Number(settings.botElo) % 100 === 0 ? [] : [Number(settings.botElo)])])].sort((a,b)=>a-b).map(n => `<option value="${n}" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === n ? 'selected' : ''}>Elo ${n}${n === 3200 ? ' · mức cao nhất' : ''}</option>`).join('')}</select><button type="button" id="randomBotElo" class="text-btn random-elo-btn" aria-pressed="${randomBotEloEnabled}">🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}</button></div></div>
        <button id="newGameSetup" class="primary-btn full-width">Bắt đầu ván mới <span>→</span></button>
        <div class="stats-row"><div><small>Đánh giá</small><b id="evalNumber">—</b></div><div><small>Số nước</small><b id="gameMoveCount">${game.history().length}</b></div><div><small>Trạng thái</small><b id="gameStatusText" class="status-text">${!gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged) ? 'Kết thúc' : 'Đang chơi'}</b></div></div>
      </div></details>
      <section class="panel moves-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ</small><h2>Nước đi</h2></div><div class="panel-icons"><button class="tiny-btn" id="copyPGN" title="Sao chép PGN">⧉</button><button class="tiny-btn" id="downloadPGN" title="Tải PGN">↓</button></div></div><div id="moveList" class="move-list"></div></section>
      ${(gameStarted && (game.isGameOver() || clockFlagged || manualGameResult)) ? renderFullGameResultPanel() : ''}
      <section class="panel quick-tools"><h3>Phân tích nhanh</h3><div class="tool-grid"><button id="explainPosition" class="tool-btn"><span>✦</span><b>Giải thích</b><small>Hỏi AI về thế cờ</small></button><button id="queryExplorer" class="tool-btn"><span>⌘</span><b>Khai cuộc</b><small>Dữ liệu Lichess</small></button></div><div id="explorerResult" class="explorer-result"></div></section>
    </aside>
    </section>
  </section>`;
}
function renderOpeningsView() {
  return `<section class="content-page openings-page"><div class="page-intro openings-intro"><div class="eyebrow">VILA CHESS · OPENING EXPLORER</div><h1>Thư viện khai cuộc</h1><p>Tìm theo tên, mã ECO hoặc nước đi; phát lại cả biến khai cuộc trên bàn cờ. Khi build có mạng, VILA đóng gói thêm cơ sở dữ liệu ECO mở rộng, còn kho mẫu vẫn hoạt động khi ngoại tuyến.</p><div class="opening-library-stats"><strong id="openingCount">${OPENINGS.length} đường khai cuộc</strong><span>Đã lọc theo biến hợp lệ</span><span class="opening-source-chip">ECO · Lichess CC0</span></div></div>
    <div class="opening-toolbar"><label class="opening-search-wrap"><span aria-hidden="true">⌕</span><input id="openingSearch" class="field search-field" placeholder="Tìm tên khai cuộc, mã ECO…" aria-label="Tìm khai cuộc"/></label><select id="openingFilter" class="field" aria-label="Lọc hệ thống"><option value="all">Tất cả hệ thống</option><option value="Mở e4">Khai cuộc 1.e4</option><option value="Mở d4">Khai cuộc 1.d4</option><option value="Phòng thủ">Phòng thủ</option><option value="Tấn công">Tấn công</option><option value="Mở c4">Khai cuộc 1.c4 / linh hoạt</option></select></div>
    <div id="openingGrid" class="opening-grid">${renderOpeningCards()}</div>
    <div class="note-banner opening-note"><span>✦</span><div><b>Kho mẫu + ECO mở rộng</b><p>Chọn “Xem biến” để kiểm tra toàn bộ nước trên bàn tạm trước khi thay ván hiện tại. AI chọn nước trong các nhánh có tiền tố khớp lịch sử ván; hết kho hoặc rời biến thì Stockfish tiếp quản. Dữ liệu khai cuộc là tài liệu tham khảo, không cam kết mọi biến đều là lựa chọn chiến thuật tốt nhất.</p></div></div>
  </section>`;
}
function renderOpeningCards(filter = '', family = 'all', limit = openingPageLimit) {
  const query = String(filter || '').trim().toLocaleLowerCase();
  const filtered = OPENINGS.filter(o => (family === 'all' || o.family === family) && `${o.name} ${o.eco} ${o.note} ${o.line}`.toLocaleLowerCase().includes(query));
  const visible = filtered.slice(0, Math.max(1, Number(limit) || 48));
  const cards = visible.map(o => `<article class="opening-card"><div class="opening-card-top"><span class="eco-tag">${esc(o.eco)}</span><span class="family-tag">${esc(o.family)}</span></div><h3>${esc(o.name)}</h3><p>${esc(o.note)}</p><div class="opening-line">${esc(o.line)}</div><div class="opening-card-bottom"><span>${o.san.length} nửa nước đi</span><button class="mini-primary" data-load-opening="${OPENINGS.indexOf(o)}">Xem biến ↗</button></div></article>`).join('');
  const more = filtered.length > visible.length ? `<div class="opening-load-more-wrap"><span>Đang hiện ${visible.length} / ${filtered.length} khai cuộc</span><button id="loadMoreOpenings" type="button" class="secondary-btn">Tải thêm 48 biến ↓</button></div>` : `<div class="opening-load-more-wrap"><span>Hiển thị ${visible.length} / ${filtered.length} khai cuộc</span></div>`;
  return `${cards || '<div class="empty-state">Không tìm thấy khai cuộc phù hợp.</div>'}${more}`;
}
function renderCoachView() {
  return `<section class="content-page coach-page"><div class="page-intro"><div class="eyebrow">TRỢ LÝ CỜ VUA</div><h1>AI phân tích & huấn luyện</h1><p>Hỏi về vị trí hiện tại, ý tưởng chiến thuật, khai cuộc hoặc gửi một đoạn PGN. Chọn Stockfish nội bộ để phân tích không cần Internet/API, hoặc chọn model API để được giải thích bằng ngôn ngữ tự nhiên.</p></div>
    <div class="coach-source-row"><label class="field-label" for="coachEngineMode">Nguồn phân tích / trả lời</label><select id="coachEngineMode" class="field"><option value="api" ${settings.coachEngineMode === 'api' ? 'selected' : ''}>AI qua API · dùng endpoint/model/API key</option><option value="stockfish" ${settings.coachEngineMode === 'stockfish' ? 'selected' : ''}>Stockfish nội bộ · phân tích cờ, không chat tự do</option></select><small>${settings.coachEngineMode === 'stockfish' ? 'Stockfish tính điểm và biến thể nước cờ cục bộ; muốn giải thích bằng tiếng Việt hoặc hỏi kiến thức chung hãy chọn API.' : `Đang chọn ${esc(settings.model)}. Tốc độ tùy mạng, nhà cung cấp và hạn mức API.`}</small></div>
    <div class="coach-layout"><section class="panel coach-context"><div class="panel-heading"><div><small class="eyebrow">THẾ CỜ HIỆN TẠI</small><h2>Thông tin bàn cờ</h2></div><span class="context-icon">♞</span></div><div class="context-stat"><span>FEN</span><code>${esc(game.fen())}</code><button id="copyFen" class="tiny-btn">⧉</button></div><div class="context-stat"><span>PGN</span><code class="truncate-code">${esc(game.pgn() || 'Chưa có nước đi')}</code><button id="copyPgnCoach" class="tiny-btn">⧉</button></div><div class="coach-suggestions"><button data-prompt="Giải thích kế hoạch tốt nhất cho bên đang tới lượt trong thế cờ hiện tại.">Ý tưởng tốt nhất?</button><button data-prompt="Hãy chỉ ra các quân bị treo và các đòn chiến thuật trong thế cờ hiện tại.">Quân bị treo?</button><button data-prompt="Phân tích khai cuộc hiện tại, nêu nguyên tắc phát triển quân cho người mới học.">Phân tích khai cuộc</button><button data-prompt="Đưa ra kế hoạch phòng thủ an toàn cho bên đang tới lượt.">Kế hoạch phòng thủ</button></div></section>
      <section class="panel chat-panel"><div class="chat-header"><div class="avatar ai-avatar">✦</div><div><b>VILA Chess Coach</b><small>${settings.coachEngineMode === 'stockfish' ? 'Stockfish nội bộ · không gọi API' : `Đang dùng ${esc(settings.model)} · ${settings.aiMode === 'gemini' ? 'Gemini' : settings.aiMode === 'anthropic' ? 'Anthropic' : 'OpenAI-compatible'}`}</small></div><button id="clearChat" class="tiny-btn" title="Cuộc trò chuyện mới">＋</button></div><div id="chatTranscript" class="chat-transcript">${chatMessages.length ? renderChatMessages() : '<div class="welcome-chat"><div class="welcome-spark">✦</div><h3>Cùng phân tích ván cờ</h3><p>Mình sẽ giải thích bằng tiếng Việt, từng bước dễ hiểu.</p><div class="starter-prompts"><button data-prompt="Tôi mới chơi cờ. Hãy chỉ tôi 3 nguyên tắc quan trọng nhất ở khai cuộc.">Tôi mới học cờ ♟</button><button data-prompt="Dựa trên FEN hiện tại, giải thích các nước ứng viên dễ hiểu.">Giải thích vị trí này ✦</button></div></div>'}</div><form id="coachForm" class="chat-composer"><textarea id="coachInput" rows="2" placeholder="Hỏi về nước đi, chiến thuật, khai cuộc…"></textarea><button id="sendCoach" class="send-btn" type="submit" aria-label="Gửi tin nhắn" ${coachRequestActive ? 'disabled' : ''}>${coachRequestActive ? '…' : '↑'}</button></form><div class="chat-footnote">AI có thể sai; hãy kiểm tra nước đi bằng luật cờ và Stockfish.</div></section></div>
  </section>`;
}
function renderChatMessages() {
  return chatMessages.map(m => `<div class="chat-message ${m.role === 'user' ? 'user-message' : 'assistant-message'}" data-message-id="${esc(m.id)}"><div class="message-role">${m.role === 'user' ? 'Bạn' : 'VILA Chess AI'}</div><div class="message-content">${esc(m.content).replace(/\n/g, '<br>')}</div><button class="copy-message" data-copy-message="${m.id}">Sao chép</button></div>`).join('');
}
function renderLichessView() {
  const token = activeLichessToken || safeSessionGet(lichessTokenKey) || '';
  const activeLichessUrl = activeOnlineGame ? safeLichessUrl(activeOnlineGame.url, activeOnlineGame.id) : 'https://lichess.org/';
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">CHƠI TRỰC TUYẾN</div><h1>Kết nối Lichess</h1><p>Kết nối tài khoản bằng Personal Access Token. Token chỉ giữ trong phiên trình duyệt và được gửi tới backend đã cấu hình; không đưa token lên GitHub. Bot API cần tài khoản đã được nâng cấp thành Bot và đúng scope.</p></div>
    <div class="lichess-layout"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Kết nối Lichess.org</h2></div><div class="lichess-logo">♞</div></div><label class="field-label" for="lichessToken">Personal Access Token</label><input id="lichessToken" type="password" autocomplete="off" class="field" placeholder="Dán token có quyền phù hợp" value="${esc(token)}"/><div class="field-hint">Dùng quyền cần thiết cho cách chơi bạn muốn: đọc tài khoản và chơi ván cờ. Không dán token vào nơi công khai.</div><label class="field-label" for="lichessApiMode">Kiểu API chơi ván</label><select id="lichessApiMode" class="field"><option value="board">Tài khoản thông thường (Board API)</option><option value="bot">Tài khoản Lichess Bot (Bot API)</option></select><div class="field-hint">Chọn Bot API chỉ khi tài khoản đã được nâng cấp thành bot; tài khoản thường dùng Board API.</div><div class="button-row"><button id="connectLichess" class="primary-btn">Kiểm tra kết nối</button><button id="forgetLichess" class="secondary-btn">Xóa token</button></div><div id="lichessAccountResult" class="connection-result">${token ? 'Token đang lưu tạm trong phiên này; hãy kiểm tra kết nối.' : 'Chưa kết nối tài khoản.'}</div><div class="form-divider"></div><h3>Thử đấu AI của Lichess</h3><div class="two-fields"><div><label class="field-label" for="lichessLevel">Độ khó AI (1–8)</label><select id="lichessLevel" class="field">${[1,2,3,4,5,6,7,8].map(n=>`<option value="${n}" ${n===3?'selected':''}>Cấp ${n}</option>`).join('')}</select></div><div><label class="field-label" for="lichessClock">Thời gian (giây)</label><select id="lichessClock" class="field"><option value="60">1 phút</option><option value="180">3 phút</option><option value="300" selected>5 phút</option><option value="600">10 phút</option><option value="0">Không giới hạn</option></select></div></div><button id="challengeLichessAI" class="primary-btn full-width">Tạo ván với AI Lichess ↗</button><div class="form-divider"></div><h3>Thách đấu người chơi</h3><label class="field-label" for="lichessUsername">Tên người chơi Lichess</label><input id="lichessUsername" class="field" placeholder="Ví dụ: username"/><button id="challengeLichessUser" class="secondary-btn full-width">Gửi lời mời đấu ↗</button><div id="lichessChallengeResult" class="connection-result"></div></section>
    <section class="panel lichess-info"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI THỰC TẾ</small><h2>Trạng thái & hướng dẫn</h2></div><span class="online-indicator"></span></div><div class="info-row"><span class="info-icon">✓</span><div><b>Dữ liệu khai cuộc</b><p>Tra thống kê nước đi trong tab Khai cuộc qua Lichess Opening Explorer; không cần token cho truy vấn công khai.</p></div></div><div class="info-row"><span class="info-icon">↗</span><div><b>Ván trực tuyến</b><p>Sau khi gửi thử thách, mở trang ván trên Lichess để chấp nhận/chơi. Đồng bộ nước đi trong ứng dụng cần token, đúng API scope và backend có thể truy cập Lichess.</p></div></div><div class="info-row"><span class="info-icon">!</span><div><b>Bot Lichess không giống AI Stockfish nội bộ</b><p>API Bot chỉ hoạt động với tài khoản bot đủ điều kiện. Không dùng tài khoản thường để tự động hóa qua Bot API.</p></div></div><a class="external-link" href="https://lichess.org/account/oauth/token" target="_blank" rel="noopener noreferrer">Mở trang quản lý token ↗</a><a class="external-link" href="https://lichess-org.github.io/api/" target="_blank" rel="noopener noreferrer">Tài liệu API chính thức ↗</a><div id="lichessActiveGame" class="active-game-card">${activeOnlineGame ? `Ván vừa tạo: <b>${esc(activeOnlineGame.id || '')}</b><br><a href="${esc(activeLichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a><br><button id="playLichessHere" class="mini-primary">Kết nối ván trong Chess Bot</button>` : 'Chưa tạo ván nào trong phiên này.'}</div></section></div>
    </section>
  </section>`;
}
function renderSettingsView() {
  return `<section class="content-page settings-page"><div class="page-intro"><div class="eyebrow">CẤU HÌNH ỨNG DỤNG</div><h1>AI, engine & máy chủ</h1><p>Không có một endpoint chung cho mọi AI. Hãy chọn API tương thích OpenAI, Google Gemini hoặc Anthropic và nhập endpoint/model theo nhà cung cấp. API key được lưu trên thiết bị này; không đưa vào kho mã nguồn. Google AI Studio, Groq và một số model OpenRouter có thể có hạn mức miễn phí tùy gói/tài khoản. Ứng dụng chỉ gắn nhãn Free khi API trả tín hiệu miễn phí rõ ràng; hãy kiểm tra giá và giới hạn trước khi dùng.</p></div>
    <div class="settings-layout"><section class="panel settings-panel"><div class="panel-heading"><div><small class="eyebrow">AI PROVIDER</small><h2>Kết nối mô hình ngôn ngữ</h2></div><span class="context-icon">✦</span></div><label class="field-label" for="freeModelPreset">Model miễn phí chọn sẵn (không cần tải danh sách)</label><select id="freeModelPreset" class="field"><option value="">Chọn model free tier tích hợp sẵn…</option>${BUILTIN_FREE_MODEL_PRESETS.map(item => `<option value="${esc(item.key)}">${esc(item.label)}</option>`).join('')}</select><div class="field-hint">Danh sách gọn đã được đóng gói trong ứng dụng, không cần tải catalog trước. Cần tự nhập API key của nhà cung cấp; ứng dụng không chứa key miễn phí dùng chung.</div><label class="field-label" for="providerPreset">Chọn nhanh nhà cung cấp</label><select id="providerPreset" class="field"><option value="custom">Custom endpoint</option><option value="openai">OpenAI API</option><option value="openrouter">OpenRouter · nhiều model</option><option value="anthropic">Anthropic API</option><option value="groq">Groq</option><option value="deepseek">DeepSeek</option><option value="together">Together AI</option><option value="mistral">Mistral AI</option><option value="fireworks">Fireworks AI</option><option value="cerebras">Cerebras</option><option value="xai">xAI</option><option value="ollama">Ollama local</option><option value="gemini">Google Gemini API</option></select><div class="field-hint">Chọn nhanh URL nền. Tên model và quyền truy cập vẫn phải đúng theo tài khoản/nhà cung cấp.</div><label class="field-label" for="aiMode">Kiểu API</label><select id="aiMode" class="field"><option value="openai-compatible" ${settings.aiMode === 'openai-compatible' ? 'selected' : ''}>OpenAI-compatible (OpenAI, OpenRouter, Groq, DeepSeek, Together, Cerebras, xAI, Ollama…)</option><option value="gemini" ${settings.aiMode === 'gemini' ? 'selected' : ''}>Google Gemini API</option><option value="anthropic" ${settings.aiMode === 'anthropic' ? 'selected' : ''}>Anthropic Messages API</option></select><label class="field-label" for="apiEndpoint">Endpoint / Base URL</label><input id="apiEndpoint" class="field" value="${esc(settings.endpoint)}" placeholder="https://api.openai.com/v1"/><div class="field-hint">Ví dụ Ollama: http://localhost:11434/v1. API cần được nhà cung cấp cho phép gọi từ máy chủ đã cài đặt.</div><label class="field-label" for="apiModel">Model ID</label><div class="model-picker-row"><input id="apiModel" class="field" list="apiModelSuggestions" value="${esc(settings.model)}" placeholder="Bấm tải danh sách hoặc nhập Model ID"/><datalist id="apiModelSuggestions"></datalist><button id="loadModels" type="button" class="secondary-btn">Tải model</button></div><select id="apiModelList" class="field model-list-select" aria-label="Danh sách model từ nhà cung cấp"><option value="">Model chọn nhanh và model đã tải sẽ xuất hiện ở đây</option></select><label class="free-model-filter"><input id="freeModelsOnly" type="checkbox"/> Chỉ hiện model có Free Tier/giá 0 được công bố</label><div class="field-hint">Huy hiệu FREE TIER dựa trên ID :free/giá 0 trong catalog hoặc danh sách Free Tier chính thức cho một số model Gemini/Groq. Hạn mức và điều kiện áp dụng phụ thuộc tài khoản, khu vực và billing; xác minh tại trang chính thức: <a href="https://openrouter.ai/models" target="_blank" rel="noopener noreferrer">OpenRouter catalog</a> · <a href="https://console.groq.com/docs/rate-limits" target="_blank" rel="noopener noreferrer">Groq Free Plan limits</a> · <a href="https://ai.google.dev/gemini-api/docs/pricing" target="_blank" rel="noopener noreferrer">Gemini pricing/free tier</a>.</div><label class="field-label" for="apiKey">API key</label><div class="secret-input"><input id="apiKey" type="password" class="field" autocomplete="off" value="${esc(settings.apiKey)}" placeholder="Dán API key tại đây"/><button id="toggleApiKey" type="button" class="tiny-btn">Hiện</button></div><div class="field-hint">Không chia sẻ ảnh chụp màn hình có API key. Nếu từng lộ key, hãy thu hồi và tạo key mới.</div><div class="form-divider"></div><label class="field-label" for="botEngineSetting">Engine Stockfish</label><select id="botEngineSetting" class="field"><option value="auto" ${!['lite-single','full-single'].includes(settings.botEngine) ? 'selected' : ''}>Tự động · Stockfish Lite ổn định</option><option value="lite-single" ${settings.botEngine === 'lite-single' ? 'selected' : ''}>Lite Single · nhẹ, phù hợp điện thoại</option><option value="full-single" ${settings.botEngine === 'full-single' ? 'selected' : ''}>Full Single · tùy chọn lớn ~94 MB, chỉ dùng khi được đóng gói</option></select><div class="field-hint">Tự động luôn dùng Lite để tải nhanh và tránh thiếu tệp trên APK. Full là tuỳ chọn lớn khoảng 94 MB; nếu Full lỗi sẽ thử Lite; nếu Lite/WASM vẫn lỗi, ứng dụng thử ASM-JS không cần WASM (có thể chậm hơn). Bản Single dùng 1 luồng UCI; Lite phù hợp điện thoại và mạng yếu.</div><div class="two-fields"><div><label class="field-label" for="botSkillSetting">Stockfish Skill (0–20)</label><input id="botSkillSetting" type="number" class="field" min="0" max="20" value="${Number(settings.botSkill)}"/></div><div><label class="field-label" for="botDepthSetting">Độ sâu tối đa (5–30)</label><input id="botDepthSetting" type="number" class="field" min="5" max="30" value="${Number(settings.botDepth)}"/></div></div><div class="two-fields"><div><label class="field-label" for="botMoveTimeSetting">Thời gian mỗi nước (ms)</label><input id="botMoveTimeSetting" type="number" class="field" min="500" max="5000" step="100" value="${Number(settings.botMoveTimeMs)}"/></div><div><label class="field-label" for="analysisMoveTimeSetting">Phân tích 3 biến (ms)</label><input id="analysisMoveTimeSetting" type="number" class="field" min="1000" max="8000" step="100" value="${Number(settings.analysisMoveTimeMs)}"/></div></div><div class="field-hint">Thời gian mỗi nước là giới hạn thực tế để tránh chờ depth cố định lâu trên điện thoại; tăng thời gian để tìm nước mạnh hơn nhưng máy sẽ phân tích lâu hơn.</div><div class="preference-grid"><label class="preference-toggle"><input id="openingBookEnabledSetting" type="checkbox" ${settings.openingBookEnabled ? 'checked' : ''}/><span><b>Đa dạng khai cuộc</b><small>Chọn ngẫu nhiên có trọng số trong kho khai cuộc hợp lệ; Stockfish sẽ tiếp quản khi hết nhánh.</small></span></label><label class="preference-toggle"><input id="soundEnabledSetting" type="checkbox" ${settings.soundEnabled ? 'checked' : ''}/><span><b>Âm thanh bàn cờ</b><small>Tiếng quân cờ; nhạc piano Gymnopédie No. 1 khi có internet, nhạc nền tổng hợp dự phòng khi offline.</small></span></label></div><div class="two-fields"><div><label class="field-label" for="botStrengthModeSetting">Chế độ sức mạnh</label><select id="botStrengthModeSetting" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Tối đa (không giới hạn Elo)</option><option value="elo" ${settings.botStrengthMode === 'elo' ? 'selected' : ''}>Giới hạn Elo</option></select></div><div><label class="field-label" for="botEloSetting">Elo mục tiêu (500–3200)</label><input id="botEloSetting" type="number" class="field" min="500" max="3200" step="10" value="${Number(settings.botElo || 2600)}"/><div class="field-hint">500–1310 mô phỏng Elo thấp bằng Skill Level 0 và một tỷ lệ nước heuristic hợp lệ; từ 1320 dùng UCI_Elo (mức hỗ trợ 1320–3190). Elo là mục tiêu ước lượng, không phải xếp hạng được chứng nhận. Đây không phải Elo FIDE/Chess.com được chứng nhận.</div></div></div><label class="field-label" for="backendUrl">API backend URL (để trống khi chạy cùng máy)</label><input id="backendUrl" class="field" value="${esc(settings.backendUrl)}" placeholder="https://api-cua-ban.example"/><label class="field-label" for="backendAccessToken">Mã truy cập backend (nếu máy chủ yêu cầu)</label><input id="backendAccessToken" type="password" autocomplete="off" class="field" value="${esc(settings.backendAccessToken)}" placeholder="Không bắt buộc khi backend chạy cục bộ"/><div class="field-hint">Khi đóng gói APK, AI/Lichess cần backend được triển khai có HTTPS. Chơi cờ và engine được đóng gói có thể chạy cục bộ.</div><div class="button-row"><button id="saveSettings" class="primary-btn">Lưu cấu hình</button><button id="testAI" class="secondary-btn">Kiểm tra AI</button></div><div id="settingsTestResult" class="connection-result"></div></section>
    <aside class="panel settings-about"><div class="panel-heading"><div><small class="eyebrow">VILA CHESS ENGINE</small><h2>Thông tin hệ thống</h2></div></div><div class="brand-showcase"><img src="./chess-bot-logo.webp" alt="Logo VILA Chess" loading="lazy" decoding="async" /></div><div class="info-row"><span class="info-icon">♞</span><div><b>Stockfish 19 · tự chọn Lite/Full</b><p>Engine UCI chạy trong Web Worker. Chế độ tự động dùng Full khi navigator báo ít nhất 6 GB RAM và 6 luồng CPU; nếu không, chọn Lite. Có thể chọn thủ công trong cài đặt. Độ sâu đến 30 có thể tốn thời gian và pin; engine cần các tệp JS/WASM được copy khi cài dependencies.</p></div></div><div class="info-row"><span class="info-icon">♟</span><div><b>Luật cờ tiêu chuẩn</b><p>Được kiểm tra bởi chess.js: nước hợp lệ, nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hòa và lặp thế cờ.</p></div></div><div class="info-row"><span class="info-icon">⌘</span><div><b>Kho khai cuộc</b><p>${OPENINGS.length} đường khai cuộc mẫu kèm mã ECO tham khảo và tích hợp Opening Explorer.</p></div></div><div class="info-row"><span class="info-icon">🔐</span><div><b>Bảo vệ khóa</b><p>Khóa không được đóng cứng vào mã. Trình duyệt lưu cài đặt cục bộ; khi triển khai công khai cần cấu hình xác thực, giới hạn truy cập và HTTPS cho backend.</p></div></div><div class="license-note"><b>Giấy phép thư viện</b><p>chess.js theo BSD-2-Clause. Stockfish theo GPL-3.0; xem giấy phép và thông báo bản quyền đi kèm bản phân phối Stockfish trước khi phát hành.</p></div><button id="resetSettings" class="danger-btn full-width">Đặt lại cài đặt AI</button></aside></div>
  </section>`;
}

function wireCommonActions() {
  // Global navigation listeners are attached once during boot; the views below are re-rendered.
}
function startGameFromSetup() {
  unlockBoardSound();
  const selectedMode = $('#modeSelect')?.value || mode;
  if (selectedMode === 'ai' && !aiRequestConfigured()) {
    toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt trước.');
    setView('settings');
    return;
  }
  if (selectedMode === 'lichess') {
    if (!activeOnlineGame?.id) {
      toast('Hãy kết nối Lichess và tạo ván trực tuyến trước.');
      setView('lichess');
      return;
    }
    mode = 'lichess';
    startOnlinePlay();
    return;
  }
  mode = selectedMode;
  humanColor = $('#colorSelect')?.value === 'b' ? 'b' : 'w';
  orientation = humanColor;
  freshGame();
}

function wirePlayActions() {
  wireAnnotationWidget();
  $$('[data-experience-choice]').forEach(button => button.addEventListener('click', () => {
    const next = button.dataset.experienceChoice;
    if (!['beginner', 'experienced'].includes(next)) return;
    experienceLevel = next;
    try { localStorage.setItem('vila.chess.experience.v1', JSON.stringify(next)); } catch {}
    if (next === 'beginner') {
      settings.botStrengthMode = 'elo'; settings.botElo = 800; settings.clockPreset = '10+0';
      saveSettings();
    }
    renderView();
    toast(next === 'beginner' ? 'Đã bật lộ trình người mới: bot khoảng Elo 800, Rapid 10+0. Gợi ý chỉ dùng ở chế độ solo.' : 'Đã chọn chế độ người chơi đã biết luật. Bạn có thể tự đổi thời gian và sức mạnh bot.');
  }));
  $('#changeExperience')?.addEventListener('click', () => {
    experienceLevel = '';
    try { localStorage.removeItem('vila.chess.experience.v1'); } catch {}
    renderView();
  });
  $('#randomBotElo')?.addEventListener('click', () => {
    randomBotEloEnabled = !randomBotEloEnabled;
    const button = $('#randomBotElo');
    if (button) { button.setAttribute('aria-pressed', String(randomBotEloEnabled)); button.textContent = `🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}`; }
    toast(randomBotEloEnabled ? 'Mỗi ván solo Stockfish sẽ chọn Elo ngẫu nhiên từ 500–3200. Đây không phải Elo rank.' : 'Đã tắt Elo ngẫu nhiên; dùng mức bot đã chọn.');
  });
  $$('[data-play-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.playView)));
  const modeSelect = $('#modeSelect');
  modeSelect?.addEventListener('change', () => {
    const chosen = modeSelect.value;
    if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi đổi chế độ bàn cờ.'); modeSelect.value = mode; return; }
    if (chosen === 'ai' && !aiRequestConfigured()) {
      modeSelect.value = mode;
      toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt trước khi chọn AI qua API.');
      setView('settings');
      return;
    }
    if ((mode === 'lichess' && chosen !== 'lichess') || (chosen === 'lichess' && !activeOnlineGame?.id)) stopOnlineStream();
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    if (chosen === 'lichess' && !activeOnlineGame?.id) {
      toast('Kết nối Lichess và tạo ván trước.'); mode = 'stockfish'; modeSelect.value = mode;
    } else {
      const previousMode = mode;
      mode = chosen;
      if (mode === 'lichess') {
        gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
        resetClock('untimed');
        startOnlinePlay(); return;
      }
      if (previousMode === 'lichess') resetClock(settings.clockPreset);
    }
    gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
    if (mode === 'ai' && !aiRequestConfigured()) toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt.');
    renderView();
    if (gameStarted && ['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor && !(mode === 'ai' && !aiRequestConfigured())) {
      botThinking = true; renderView();
      scheduleBotMove(220);
    }
  });
  $('#colorSelect')?.addEventListener('change', event => {
    if (mode === 'lichess') { toast('Màu quân trong ván Lichess do Lichess quyết định.'); renderView(); return; }
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    humanColor = event.target.value;
    orientation = humanColor;
    gameEpoch += 1; // Invalidate any engine result calculated for the old player-to-move setup.
    queuedMainEngineMove = false;
    botThinking = false;
    renderView();
    if (gameStarted && ['stockfish', 'ai'].includes(mode) && game.turn() !== humanColor && !game.isGameOver()) {
      if (mode === 'ai' && !aiRequestConfigured()) {
        toast('Hãy cấu hình endpoint, model và API key cần thiết trong Cài đặt trước khi bot đi.')
        return;
      }
      botThinking = true;
      renderView();
      scheduleBotMove(220);
    }
  });
  $('#skillSelect')?.addEventListener('change', event => {
    randomBotEloEnabled = false;
    const value = event.target.value;
    if (value === 'max') { settings.botStrengthMode = 'max'; settings.botSkill = 20; }
    else { settings.botStrengthMode = 'elo'; settings.botElo = Math.max(500, Math.min(3200, Number(value) || 2600)); settings.botSkill = 20; }
    const saved = saveSettings(); toast(saved ? (settings.botStrengthMode === 'max' ? 'Stockfish đang ở sức mạnh tối đa.' : `Đã giới hạn Stockfish ở khoảng Elo ${settings.botElo}.`) : 'Cấu hình có hiệu lực trong phiên này nhưng chưa lưu được.');
  });
  $('#newGame')?.addEventListener('click', () => freshGame());
  $('#resignBtn')?.addEventListener('click', resignCurrentGame);
  $('#startGameOverlay')?.addEventListener('click', startGameFromSetup);
  $('#reviewGameBtn')?.addEventListener('click', startFullGameReview);
  $('#stopReviewBtn')?.addEventListener('click', () => stopFullGameReview(true));
  $('#clockPreset')?.addEventListener('change', event => {
    const nextPreset = parseClockPreset(event.target.value).preset;
    settings.clockPreset = nextPreset;
    saveSettings();
    toast(`Đã chọn ${CLOCK_PRESETS.find(item => item.value === nextPreset)?.label || nextPreset}. Đồng hồ áp dụng từ ván mới.`);
  });
  $('#newGameSetup')?.addEventListener('click', startGameFromSetup);
  $('#undoMove')?.addEventListener('click', undoMove);
  $('#analyzePosition')?.addEventListener('click', toggleAnalysis);
  $('#flipBoard')?.addEventListener('click', () => { orientation = orientation === 'w' ? 'b' : 'w'; renderBoard(); });
  const musicButton = $('#toggleChessMusic');
  if (musicButton) { musicButton.textContent = `♫ Nhạc nền: ${isChessMusicPlaying() ? 'Đang phát' : 'Tắt'}`; musicButton.setAttribute('aria-pressed', String(isChessMusicPlaying())); musicButton.addEventListener('click', () => { const enabled = setChessMusicPlaying(!isChessMusicPlaying()); musicButton.textContent = `♫ Nhạc nền: ${enabled ? 'Đang phát' : 'Tắt'}`; musicButton.setAttribute('aria-pressed', String(enabled)); if (!enabled) toast('Đã tắt nhạc nền.'); }); }
  $$('[data-review-step]').forEach(button => button.addEventListener('click', () => {
    const action = button.dataset.reviewStep;
    setReviewReplayPly((ply, last) => action === 'first' ? 0 : action === 'prev' ? ply - 1 : action === 'next' ? ply + 1 : action === 'last' ? last : ply);
  }));
  $('#reviewMoveAnalysis')?.addEventListener('click', event => {
    const row = event.target.closest('[data-review-ply]');
    if (row) setReviewReplayPly(Number(row.dataset.reviewPly));
  });
  updateReviewReplay();
  $('#hintMove')?.addEventListener('click', requestHint);
  $('#speakHint')?.addEventListener('click', speakCurrentHint);
  $('#useHint')?.addEventListener('click', applyCurrentHint);
  $('#copyPGN')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
  $('#downloadPGN')?.addEventListener('click', downloadPgn);
  $('#reviewDownloadPGN')?.addEventListener('click', downloadPgn);
  $('#explainGameBtn')?.addEventListener('click', explainCompletedGame);
  $('#explainPosition')?.addEventListener('click', () => { setView('coach'); setTimeout(() => { $('#coachInput') && ($('#coachInput').value = 'Phân tích thế cờ hiện tại của tôi: điểm mạnh, điểm yếu và kế hoạch đơn giản nhất.'); $('#coachInput')?.focus(); }, 0); });
  $('#queryExplorer')?.addEventListener('click', () => queryOpeningExplorer(true));
}
function wireOpeningActions() {
  const update = () => {
    openingPageLimit = 48;
    const filtered = OPENINGS.filter(o => ($('#openingFilter')?.value || 'all') === 'all' || o.family === $('#openingFilter')?.value)
      .filter(o => `${o.name} ${o.eco} ${o.note} ${o.line}`.toLocaleLowerCase().includes(String($('#openingSearch')?.value || '').trim().toLocaleLowerCase()));
    if ($('#openingCount')) $('#openingCount').textContent = `${filtered.length.toLocaleString()} đường khai cuộc`;
    if ($('#openingGrid')) $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', $('#openingFilter')?.value || 'all');
    wireOpeningButtons();
  };
  $('#openingSearch')?.addEventListener('input', update);
  $('#openingFilter')?.addEventListener('change', update);
  wireOpeningButtons();
}
function wireOpeningButtons() {
  $$('[data-load-opening]').forEach(button => button.addEventListener('click', () => loadOpening(Number(button.dataset.loadOpening))));
  $('#loadMoreOpenings')?.addEventListener('click', () => {
    openingPageLimit += 48;
    if ($('#openingGrid')) $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', $('#openingFilter')?.value || 'all');
    wireOpeningButtons();
  });
}
function loadOpening(index) {
  const opening = OPENINGS[index];
  if (!opening) return;
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi nạp khai cuộc.'); return; }
  if (!Array.isArray(opening.san) || opening.san.length === 0) {
    toast(`Biến ${opening.name || 'khai cuộc'} chưa có danh sách nước đi hợp lệ. Ván hiện tại vẫn được giữ nguyên.`);
    return;
  }

  // Validate the whole line on a temporary board before touching the active game.
  // A malformed catalogue item must never leave the player with a partial opening.
  const candidateGame = new Chess();
  for (let ply = 0; ply < opening.san.length; ply += 1) {
    const san = opening.san[ply];
    try {
      candidateGame.move(san);
    } catch (error) {
      console.error('Rejected invalid opening line:', opening.name, `ply ${ply + 1}`, san, error);
      toast(`Biến ${opening.name} có nước không hợp lệ (${san}). Ván hiện tại vẫn được giữ nguyên.`);
      return;
    }
  }

  historyRestoreSignature = ''; reviewReplayState = null;
  if (mode === 'lichess') stopOnlineStream();
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  game = candidateGame;
  gameStartFen = new Chess().fen();
  manualGameResult = null;
  completedReviewRows = []; reviewStatus = '';
  currentOpening = opening.name;
  lastHintMove = null;
  mode = 'local';
  selected = null; selectedTargets = []; lastMove = null; humanColor = 'w'; orientation = 'w'; botThinking = false;
  resetClock(settings.clockPreset);
  setView('play');
  toast(`Đã nạp biến mẫu: ${opening.name}. Bạn có thể tiếp tục nước đi từ thế cờ này.`, 'success');
}
function wireCoachActions() {
  $('#coachEngineMode')?.addEventListener('change', event => {
    settings.coachEngineMode = event.target.value === 'stockfish' ? 'stockfish' : 'api';
    saveSettings();
    const info = $('.coach-source-row small');
    if (info) info.textContent = settings.coachEngineMode === 'stockfish' ? 'Chạy phân tích cục bộ, hiển thị điểm số và ba biến thể tốt nhất.' : `Đang chọn ${settings.model}. Tốc độ tùy mạng, nhà cung cấp và hạn mức API.`;
  });
  $('#coachForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const input = $('#coachInput');
    const content = input.value.trim();
    if (!content) return;
    if (coachRequestActive) {
      toast('Đang chờ Chess Bot trả lời. Tin nhắn mới vẫn được giữ trong ô nhập.');
      return;
    }
    input.value = '';
    await sendCoachMessage(content);
  });
  $('#clearChat')?.addEventListener('click', () => { coachRequestId += 1; coachAbortController?.abort(); coachAbortController = null; coachRequestActive = false; chatMessages = []; renderView(); });
  $$('[data-prompt]').forEach(button => button.addEventListener('click', () => { const input = $('#coachInput'); input.value = button.dataset.prompt; input.focus(); }));
  $$('[data-copy-message]').forEach(button => button.addEventListener('click', () => { const m = chatMessages.find(x => x.id === button.dataset.copyMessage); if (m) copyText(m.content); }));
  $('#copyFen')?.addEventListener('click', () => copyText(game.fen()));
  $('#copyPgnCoach')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
}
function wireSettingsActions() {
  const presetForEndpoint = {
    'https://api.openai.com/v1': 'openai',
    'https://api.anthropic.com': 'anthropic',
    'https://api.cerebras.ai/v1': 'cerebras',
    'https://api.x.ai/v1': 'xai',
    'https://openrouter.ai/api/v1': 'openrouter',
    'https://api.groq.com/openai/v1': 'groq',
    'https://api.deepseek.com/v1': 'deepseek',
    'https://api.together.xyz/v1': 'together',
    'https://api.mistral.ai/v1': 'mistral',
    'https://api.fireworks.ai/inference/v1': 'fireworks',
    'http://localhost:11434/v1': 'ollama',
    'https://generativelanguage.googleapis.com': 'gemini'
  };
  const currentPreset = settings.aiMode === 'gemini' ? 'gemini' : (presetForEndpoint[settings.endpoint.replace(/\/$/, '')] || 'custom');
  if ($('#providerPreset')) $('#providerPreset').value = currentPreset;
  const clearProviderModelList = () => { loadedApiModels = []; loadedModelContext = ''; };
  const applyProvider = (preset, chooseFreeModel = true) => {
    if (!preset) { clearProviderModelList(); renderApiModelList(); return; }
    const oldHost = (() => { try { return new URL($('#apiEndpoint')?.value || settings.endpoint).hostname; } catch { return ''; } })();
    const newHost = (() => { try { return new URL(preset.endpoint).hostname; } catch { return ''; } })();
    $('#aiMode').value = preset.mode;
    $('#apiEndpoint').value = preset.endpoint;
    if (oldHost && newHost && oldHost !== newHost) {
      $('#apiKey').value = '';
      const result = $('#settingsTestResult');
      if (result) { result.textContent = 'Đã đổi nhà cung cấp nên đã xóa API key trên biểu mẫu để tránh gửi nhầm khóa. Hãy nhập key của nhà cung cấp mới.'; result.className = 'connection-result'; }
    }
    clearProviderModelList();
    const candidates = freePresetsForProvider(preset);
    const currentModel = String($('#apiModel')?.value || '').trim();
    const validCurrent = candidates.some(item => item.model === currentModel);
    if (chooseFreeModel && candidates.length && !validCurrent && $('#apiModel')) $('#apiModel').value = candidates[0].model;
    else if (preset.mode === 'gemini' && !$('#apiModel').value) $('#apiModel').value = 'gemini-3.8-flash';
    else if (preset.mode === 'anthropic' && !$('#apiModel').value) $('#apiModel').value = 'claude-sonnet-latest';
    else if (preset.mode === 'openai-compatible' && !$('#apiModel').value) $('#apiModel').value = 'gpt-4o-mini';
    const result = $('#settingsTestResult');
    if (result) { result.textContent = candidates.length ? `Đã nạp sẵn ${candidates.length} lựa chọn Free Tier cho ${preset.endpoint}; không cần tải catalog để chọn model. Vẫn cần API key hợp lệ.` : 'Nhà cung cấp này chưa có preset free được xác nhận trong ứng dụng. Hãy kiểm tra bảng giá và tải catalog nếu cần.'; result.className = 'connection-result'; }
    renderApiModelList();
  };
  const providerEndpoints = {
    custom: null,
    openai: { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' },
    anthropic: { mode: 'anthropic', endpoint: 'https://api.anthropic.com' },
    cerebras: { mode: 'openai-compatible', endpoint: 'https://api.cerebras.ai/v1' },
    xai: { mode: 'openai-compatible', endpoint: 'https://api.x.ai/v1' },
    openrouter: { mode: 'openai-compatible', endpoint: 'https://openrouter.ai/api/v1' },
    groq: { mode: 'openai-compatible', endpoint: 'https://api.groq.com/openai/v1' },
    deepseek: { mode: 'openai-compatible', endpoint: 'https://api.deepseek.com/v1' },
    together: { mode: 'openai-compatible', endpoint: 'https://api.together.xyz/v1' },
    mistral: { mode: 'openai-compatible', endpoint: 'https://api.mistral.ai/v1' },
    fireworks: { mode: 'openai-compatible', endpoint: 'https://api.fireworks.ai/inference/v1' },
    ollama: { mode: 'openai-compatible', endpoint: 'http://localhost:11434/v1' },
    gemini: { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' }
  };
  $('#providerPreset')?.addEventListener('change', event => {
    const preset = providerEndpoints[event.target.value];
    if (!preset) { clearProviderModelList(); renderApiModelList(); return; }
    applyProvider(preset, true);
  });
  $('#freeModelPreset')?.addEventListener('change', event => {
    const preset = BUILTIN_FREE_MODEL_PRESETS.find(item => item.key === event.target.value);
    if (!preset) return;
    const oldHost = (() => { try { return new URL($('#apiEndpoint')?.value || settings.endpoint).hostname; } catch { return ''; } })();
    const newHost = (() => { try { return new URL(preset.endpoint).hostname; } catch { return ''; } })();
    if (oldHost && newHost && oldHost !== newHost) $('#apiKey').value = '';
    $('#aiMode').value = preset.mode;
    $('#apiEndpoint').value = preset.endpoint;
    $('#apiModel').value = preset.model;
    if ($('#providerPreset')) $('#providerPreset').value = preset.provider;
    clearProviderModelList();
    renderApiModelList();
    const result = $('#settingsTestResult');
    if (result) { result.textContent = `${preset.label}. ${preset.note} Hãy nhập API key riêng của bạn rồi bấm “Lưu cấu hình” hoặc “Kiểm tra AI”.`; result.className = 'connection-result'; }
  });
  $('#aiMode')?.addEventListener('change', event => {
    const currentEndpoint = $('#apiEndpoint').value.trim();
    const oldHost = (() => { try { return new URL(currentEndpoint).hostname; } catch { return ''; } })();
    let preset;
    if (event.target.value === 'gemini') preset = { mode: 'gemini', endpoint: 'https://generativelanguage.googleapis.com' };
    else if (event.target.value === 'anthropic') preset = { mode: 'anthropic', endpoint: 'https://api.anthropic.com' };
    else preset = { mode: 'openai-compatible', endpoint: 'https://api.openai.com/v1' };
    const newHost = new URL(preset.endpoint).hostname;
    if (oldHost && newHost && oldHost !== newHost) $('#apiKey').value = '';
    $('#apiEndpoint').value = preset.endpoint;
    const firstPreset = freePresetsForProvider(preset)[0];
    if (firstPreset) $('#apiModel').value = firstPreset.model;
    else if (preset.mode === 'gemini') $('#apiModel').value = 'gemini-3.8-flash';
    else if (preset.mode === 'anthropic') $('#apiModel').value = 'claude-sonnet-latest';
    else $('#apiModel').value = 'gpt-4o-mini';
    clearProviderModelList();
    renderApiModelList();
  });
  $('#apiEndpoint')?.addEventListener('change', () => { clearProviderModelList(); renderApiModelList(); });
  $('#apiModelList')?.addEventListener('change', event => {
    if (event.target.value && $('#apiModel')) $('#apiModel').value = event.target.value;
  });
  $('#apiModel')?.addEventListener('input', event => {
    const list = $('#apiModelList');
    if (list && ![...list.options].some(option => option.value === event.target.value)) list.value = '';
    else if (list) list.value = event.target.value;
  });
  $('#toggleApiKey')?.addEventListener('click', () => { const input = $('#apiKey'); input.type = input.type === 'password' ? 'text' : 'password'; $('#toggleApiKey').textContent = input.type === 'password' ? 'Hiện' : 'Ẩn'; });
  $('#loadModels')?.addEventListener('click', event => loadProviderModels(event.currentTarget));
  $('#freeModelsOnly')?.addEventListener('change', renderApiModelList);
  $('#saveSettings')?.addEventListener('click', saveSettingsForm);
  $('#testAI')?.addEventListener('click', async () => {
    if (!saveSettingsForm(false)) return;
    const result = $('#settingsTestResult');
    result.textContent = 'Đang kiểm tra kết nối AI…';
    try {
      const data = await apiFetch('/api/ai/chat', { method: 'POST', timeoutMs: 35000, body: JSON.stringify({ mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: modelOverride, messages: [{ role: 'user', content: 'Trả lời đúng một từ: OK' }], system: 'Trả lời thật ngắn.', timeoutMs: 30000, maxTokens: 32 }) });
      const testText = typeof data.text === 'string' ? data.text.trim() : Array.isArray(data.text) ? data.text.map(part => String(part?.text || part || '')).join(' ').trim() : '';
      if (!testText) throw new Error(`API phản hồi thành công nhưng trường nội dung rỗng (model=${settings.model}). Thử model chat khác hoặc kiểm tra quyền generate/chat.`);
      result.textContent = `Kết nối thành công · ${settings.model}: ${testText.slice(0, 180)}`;
      result.className = 'connection-result success-result';
    } catch (error) { result.textContent = `Chưa kết nối được: ${friendlyApiError(error.message)}`; result.className = 'connection-result error-result'; }
  });
  $('#resetSettings')?.addEventListener('click', () => {
    settings = normalizeSettings(DEFAULTS); const saved = saveSettings(); if (saved) toast('Đã đặt lại cấu hình AI.', 'success'); renderView();
  });
  renderApiModelList();
}
function renderApiModelList() {
  const list = $('#apiModelList');
  const suggestions = $('#apiModelSuggestions');
  if (!list) return;
  const oldValue = String($('#apiModel')?.value || list.value || '');
  const mode = $('#aiMode')?.value || settings.aiMode;
  const endpoint = $('#apiEndpoint')?.value.trim() || settings.endpoint;
  const context = `${mode}|${endpoint.replace(/\/$/, '')}`;
  const bundled = freePresetsForProvider({ mode, endpoint }).map(item => ({
    id: item.model, name: item.label, description: item.note, free: true, presetKey: item.key
  }));
  const downloaded = loadedModelContext === context ? loadedApiModels : [];
  const byId = new Map();
  for (const item of bundled) byId.set(item.id, item);
  for (const item of downloaded) {
    const previous = byId.get(item.id);
    byId.set(item.id, { ...previous, ...item, free: previous?.free === true || item.free === true ? true : item.free });
  }
  const models = [...byId.values()];
  const freeOnly = Boolean($('#freeModelsOnly')?.checked);
  const shown = freeOnly ? models.filter(item => item.free === true) : models;
  if (suggestions) suggestions.innerHTML = shown.map(item => `<option value="${esc(item.id)}" label="${esc(item.name || item.id)}${item.free === true ? ' · FREE TIER*' : ''}"></option>`).join('');
  list.innerHTML = shown.length
    ? `<option value="">Model tích hợp sẵn / catalog (${shown.length})</option>` + shown.map(item => `<option value="${esc(item.id)}">${esc(item.name || item.id)} · ${esc(item.id)}${item.free === true ? ' · FREE TIER*' : ''}</option>`).join('')
    : `<option value="">${freeOnly ? 'Không có model free được xác nhận trong danh sách này' : 'Chưa có model — nhập ID hoặc chọn nhà cung cấp'}</option>`;
  if (shown.some(item => item.id === oldValue)) list.value = oldValue;
  const quick = $('#freeModelPreset');
  if (quick && !quick.value) {
    const selected = BUILTIN_FREE_MODEL_PRESETS.find(item => item.mode === mode && item.model === oldValue && (() => { try { return new URL(item.endpoint).hostname === new URL(endpoint).hostname; } catch { return false; } })());
    quick.value = selected?.key || '';
  }
  if (freeOnly && !shown.length) {
    const result = $('#settingsTestResult');
    if (result) { result.textContent = 'Không có model Free Tier cho endpoint hiện tại trong catalog đã xác minh. Không tự gắn nhãn miễn phí; hãy chọn Gemini/Groq/OpenRouter trong Model chọn sẵn hoặc kiểm tra bảng giá.'; result.className = 'connection-result'; }
  }
}
async function loadProviderModels(button) {
  const mode = $('#aiMode')?.value || 'openai-compatible';
  const endpoint = $('#apiEndpoint')?.value.trim() || '';
  const apiKey = $('#apiKey')?.value.trim() || '';
  const backendUrl = $('#backendUrl')?.value.trim().replace(/\/$/, '') || '';
  const backendAccessToken = $('#backendAccessToken')?.value.trim() || '';
  const result = $('#settingsTestResult');
  if (!isSafeHttpEndpoint(endpoint)) {
    if (result) { result.textContent = 'Endpoint chưa hợp lệ. Hãy kiểm tra URL rồi tải model lại.'; result.className = 'connection-result error-result'; }
    return;
  }
  if (providerNeedsKey(mode, endpoint) && !apiKey) {
    if (result) { result.textContent = 'Hãy nhập API key riêng của endpoint này trước khi lấy danh sách model. Các preset chỉ có sẵn tên model, không chứa key.'; result.className = 'connection-result error-result'; }
    return;
  }
  if (backendUrl && !isSafeHttpEndpoint(backendUrl)) {
    if (result) { result.textContent = 'Backend URL chưa hợp lệ.'; result.className = 'connection-result error-result'; }
    return;
  }
  const oldSettings = settings;
  if (button) { button.disabled = true; button.textContent = 'Đang tải…'; }
  if (result) { result.textContent = 'Đang lấy model trực tiếp từ nhà cung cấp…'; result.className = 'connection-result'; }
  try {
    settings = { ...oldSettings, backendUrl, backendAccessToken };
    const data = await apiFetch('/api/ai/models', { method: 'POST', body: JSON.stringify({ mode, endpoint, apiKey }) });
    const models = Array.isArray(data?.models) ? data.models.filter(item => item && typeof item.id === 'string' && item.id.trim()) : [];
    if (!models.length) throw new Error('API chưa trả về model khả dụng.');
    loadedApiModels = models;
    loadedModelContext = `${mode}|${endpoint.replace(/\/$/, '')}`;
    renderApiModelList();
    const modelInput = $('#apiModel');
    const current = String(modelInput?.value || '').trim();
    const available = $('#freeModelsOnly')?.checked ? models.filter(item => item.free === true) : models;
    if (modelInput && available.length && !available.some(item => item.id === current)) {
      const textModel = available.find(item => !/(image|audio|tts|embedding|transcri|live|robotics|video|speech)/i.test(item.id));
      modelInput.value = (textModel || available[0]).id;
    }
    const modelList = $('#apiModelList');
    if (modelList && modelInput && [...modelList.options].some(option => option.value === modelInput.value)) modelList.value = modelInput.value;
    if (result) {
      const extra = data.truncated ? ' · catalog còn trang sau chưa tải hết.' : '';
      if ($('#freeModelsOnly')?.checked && !available.length) {
        result.textContent = `Đã lấy ${data.count || models.length} model nhưng không model nào được xác nhận Free Tier. Không thể suy ra miễn phí chỉ từ tên model.`;
        result.className = 'connection-result';
      } else {
        result.textContent = `Đã lấy ${data.count || models.length} model từ nhà cung cấp.${extra} Các preset tích hợp vẫn có thể chọn ngay mà không tải catalog.`;
        result.className = 'connection-result success-result';
      }
    }
  } catch (error) {
    if (result) { result.textContent = `Không tải được model: ${friendlyApiError(String(error.message || error).slice(0, 350))}`; result.className = 'connection-result error-result'; }
  } finally {
    settings = oldSettings;
    if (button) { button.disabled = false; button.textContent = 'Tải model'; }
  }
}

function saveSettingsForm(showToast = true) {
  const endpointInput = $('#apiEndpoint')?.value.trim() || '';
  const backendInput = $('#backendUrl')?.value.trim().replace(/\/$/, '') || '';
  const result = $('#settingsTestResult');
  if (!isSafeHttpEndpoint(endpointInput)) {
    const message = 'Endpoint AI không hợp lệ. Hãy dùng URL bắt đầu bằng http:// hoặc https://, không nhúng thông tin đăng nhập.';
    toast(message);
    if (result) { result.textContent = message; result.className = 'connection-result error-result'; }
    return false;
  }
  if (backendInput && !isSafeHttpEndpoint(backendInput)) {
    const message = 'Backend URL không hợp lệ. Hãy dùng URL HTTP(S) hợp lệ hoặc để trống khi chạy cùng máy.';
    toast(message);
    if (result) { result.textContent = message; result.className = 'connection-result error-result'; }
    return false;
  }
  settings.aiMode = $('#aiMode').value;
  settings.endpoint = endpointInput;
  settings.model = $('#apiModel').value.trim();
  settings.apiKey = $('#apiKey').value.trim();
  settings.backendUrl = backendInput;
  settings.backendAccessToken = $('#backendAccessToken').value.trim();
  const previousEngine = settings.botEngine || 'auto';
  const requestedEngine = $('#botEngineSetting')?.value || 'auto';
  settings.botEngine = ['auto', 'lite-single', 'full-single'].includes(requestedEngine) ? requestedEngine : 'auto';
  settings.botEnginePreferenceSet = true;
  settings.botSkill = Math.max(0, Math.min(20, Number($('#botSkillSetting').value || 20)));
  settings.botStrengthMode = $('#botStrengthModeSetting')?.value === 'elo' ? 'elo' : 'max';
  settings.botElo = Math.max(500, Math.min(3200, Number($('#botEloSetting').value || 2600)));
  settings.botDepth = Math.max(5, Math.min(30, Number($('#botDepthSetting').value || 18)));
  settings.botMoveTimeMs = Math.max(500, Math.min(5000, Number($('#botMoveTimeSetting').value || 1200)));
  settings.analysisMoveTimeMs = Math.max(1000, Math.min(8000, Number($('#analysisMoveTimeSetting').value || 2600)));
  settings.openingBookEnabled = Boolean($('#openingBookEnabledSetting')?.checked);
  settings.soundEnabled = Boolean($('#soundEnabledSetting')?.checked);
  const saved = saveSettings();
  if (showToast && saved) toast(settings.botEngine !== previousEngine ? 'Đã lưu. Tải lại ứng dụng để áp dụng cấu hình engine mới.' : 'Đã lưu cấu hình trên thiết bị.', 'success');
  if (currentView === 'settings') {
    const status = $('#settingsTestResult');
    if (status) {
      status.textContent = saved
        ? 'Đã lưu cấu hình. Nhấn “Kiểm tra AI” để thử kết nối.'
        : 'Cấu hình đang dùng trong phiên này nhưng không lưu được vào thiết bị.';
      status.className = saved ? 'connection-result' : 'connection-result error-result';
    }
  }
  return true;
}
function wireLichessActions() {
  $('#connectLichess')?.addEventListener('click', connectLichess);
  $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
  $('#forgetLichess')?.addEventListener('click', () => {
    // Revoke the app's local session immediately: abort any stream using the
    // token and invalidate the active game before clearing the stored values.
    stopOnlineStream();
    activeLichessToken = '';
    activeLichessUsername = '';
    activeOnlineGame = null;
    safeSessionRemove(lichessTokenKey);
    safeSessionRemove('tubor.chess.lichessUsername');
    if (mode === 'lichess') {
      mode = 'stockfish';
      gameEpoch += 1;
      botThinking = false;
      cancelScheduledBotMove();
      cancelPendingHint();
      cancelMainEngineSearch();
    }
    if ($('#lichessToken')) $('#lichessToken').value = '';
    const result = $('#lichessAccountResult');
    if (result) result.textContent = 'Đã xóa token và ngắt kết nối Lichess khỏi phiên hiện tại.';
    if (currentView === 'play') renderView();
  });
  $('#challengeLichessAI')?.addEventListener('click', challengeLichessAI);
  $('#challengeLichessUser')?.addEventListener('click', challengeLichessUser);
}
async function connectLichess() {
  const token = getLichessToken();
  if (!token) { toast('Hãy nhập Lichess personal access token.'); return; }
  activeLichessToken = token;
  const persisted = safeSessionSet(lichessTokenKey, token);
  const result = $('#lichessAccountResult'); result.textContent = 'Đang xác thực token…';
  try {
    const account = await apiFetch('/api/lichess/account', { method: 'POST', body: JSON.stringify({ token }) });
    activeLichessUsername = account.username || '';
    safeSessionSet('tubor.chess.lichessUsername', activeLichessUsername);
    result.textContent = `Đã kết nối: ${account.username}${account.title ? ` (${account.title})` : ''}${persisted ? '' : ' · token chỉ được giữ trong phiên hiện tại'}`;
    result.className = 'connection-result success-result';
  } catch (error) { result.textContent = `Kết nối thất bại: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessAI() {
  const token = getLichessToken();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang tạo thử thách AI…';
  try {
    const data = await apiFetch('/api/lichess/challenge-ai', { method: 'POST', body: JSON.stringify({ token, level: Number($('#lichessLevel').value), clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã tạo thử thách. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a> <button id="playLichessChallenge" class="mini-primary">Chơi trong Chess Bot</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Ván vừa tạo: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không tạo được thử thách: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessUser() {
  const token = getLichessToken();
  const username = $('#lichessUsername').value.trim();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  if (!username) { result.textContent = 'Hãy nhập tên người chơi muốn thách đấu.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang gửi lời mời…';
  try {
    const data = await apiFetch('/api/lichess/challenge-user', { method: 'POST', body: JSON.stringify({ token, username, clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', opponent: username, username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã gửi lời mời. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở lời mời ↗</a> <button id="playLichessChallenge" class="mini-primary">Kết nối ván trong Chess Bot</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Lời mời: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không gửi được lời mời: ${error.message}`; result.className = 'connection-result error-result'; }
}

async function sendCoachMessage(content, { forceApi = false } = {}) {
  const cleanContent = String(content || '').trim();
  if (!cleanContent) return;
  if (coachRequestActive) { toast('Đang chờ Chess Bot trả lời tin nhắn trước.'); return; }

  coachRequestActive = true;
  const requestId = ++coachRequestId;
  coachAbortController = new AbortController();
  const inputMessages = chatMessages.filter(m => m.role === 'user' || m.role === 'assistant').slice(-6).map(m => ({ role: m.role, content: m.content }));
  chatMessages.push({ id: makeMessageId(), role: 'user', content: cleanContent });
  chatMessages.push({ id: 'waiting', role: 'assistant', content: 'Đang phân tích thế cờ…' });
  if (currentView === 'coach') renderView();

  try {
    if (settings.coachEngineMode === 'stockfish' && !forceApi) {
      const variants = await analyzeLocallyForCoach();
      if (requestId !== coachRequestId) return;
      chatMessages = chatMessages.filter(m => m.id !== 'waiting');
      const lines = variants.slice(0, 3).map((variant, index) => {
        const san = uciPvToSan(variant.fen, variant.pv).slice(0, 8).join(' ');
        return `${index + 1}. ${formatUciScore(variant)} · độ sâu ${variant.depth} · ${san || 'đang tính'}`;
      });
      const answer = lines.length ? `Phân tích Stockfish nội bộ (không gọi API):\nVị trí FEN: ${game.fen()}\n${lines.join('\n')}\n\nĐiểm số là đánh giá engine, không phải phần trăm thắng. Các biến thể là phương án ứng viên, cần xem toàn bộ ván để quyết định.\n\nLưu ý: Stockfish tính nước cờ, không phải mô hình hội thoại. Chọn AI qua API nếu muốn giải thích bằng ngôn ngữ tự nhiên hoặc hỏi kiến thức chung.` : 'Stockfish chưa trả được biến thể. Hãy thử lại sau.';
      chatMessages.push({ id: makeMessageId(), role: 'assistant', content: answer });
      return;
    }
    const gameContext = `Thế cờ hiện tại (FEN): ${game.fen()}\nPGN gần nhất: ${(game.pgn() || '(ván chưa có nước đi)').slice(-1800)}\nBên tới lượt: ${game.turn() === 'w' ? 'Trắng' : 'Đen'}\nTrạng thái: ${positionStatus()}.\nHãy trả lời bằng tiếng Việt đơn giản, không bịa nước đi. Nếu đưa ra nước đi hãy dùng ký hiệu SAN và nói đó là gợi ý cần xác minh.`;
    const conversation = [...inputMessages, { role: 'user', content: cleanContent }];
    const coachSystem = `Bạn là huấn luyện viên cờ vua thân thiện cho người mới. Trả lời bằng văn bản tiếng Việt, có nội dung rõ ràng, ưu tiên 3–6 gạch đầu dòng khi phù hợp. Không được để câu trả lời trống. Nếu không chắc về nước cờ, hãy nói rõ điều đó. ${gameContext}`;
    const requestCoach = (retry = false, modelOverride = settings.model) => apiFetch('/api/ai/chat', {
      method: 'POST', timeoutMs: retry ? 45_000 : 38_000, signal: coachAbortController.signal,
      body: JSON.stringify({
        mode: settings.aiMode, endpoint: settings.endpoint, apiKey: settings.apiKey, model: modelOverride,
        temperature: retry ? 0.2 : Math.min(Number(settings.temperature) || 0.3, 0.5),
        maxTokens: retry ? 900 : 700, timeoutMs: retry ? 42_000 : 35_000,
        system: retry ? `${coachSystem} Hãy xuất câu trả lời cuối cùng dạng văn bản thuần, không chỉ gửi trạng thái suy nghĩ hoặc lời gọi công cụ.` : coachSystem,
        messages: retry ? [...conversation, { role: 'user', content: 'Hãy trả lời trực tiếp câu hỏi bằng văn bản hoàn chỉnh trong câu trả lời cuối cùng.' }] : conversation
      })
    });
    let data;
    try {
      data = await requestCoach(false);
    } catch (error) {
      if (requestId !== coachRequestId) return;
      // Retry only when the provider reported HTTP success but returned no textual output.
      // Authentication/quota/network errors are not retried to avoid duplicate calls and cost.
      if (!/phản hồi thành công nhưng chưa có câu trả lời văn bản|không có nội dung văn bản|không trả trường văn bản tương thích/i.test(String(error?.message || error))) throw error;
      const waitingMessage = $('#chatTranscript [data-message-id="waiting"] .message-content');
      if (waitingMessage) waitingMessage.textContent = 'Model chưa trả nội dung văn bản; đang thử lại một lần…';
      data = await requestCoach(true);
    }
    if (requestId !== coachRequestId) return;
    let replyText = typeof data.text === 'string' ? data.text.trim() : Array.isArray(data.text) ? data.text.map(part => typeof part === 'string' ? part : String(part?.text || '')).join('\n').trim() : '';
    let answeredByModel = data.model || settings.model;
    // Some gateways return HTTP 200 with an empty text field even after retry.
    // For Gemini only, make one bounded fallback attempt with another documented chat model.
    if (!replyText && settings.aiMode === 'gemini' && settings.model !== 'gemini-3.6-flash') {
      const waitingMessage = $('#chatTranscript [data-message-id="waiting"] .message-content');
      if (waitingMessage) waitingMessage.textContent = 'Model chính chưa trả văn bản; đang thử Gemini 3.6 Flash một lần…';
      try {
        const fallbackData = await requestCoach(true, 'gemini-3.6-flash');
        const fallbackText = typeof fallbackData.text === 'string' ? fallbackData.text.trim() : Array.isArray(fallbackData.text) ? fallbackData.text.map(part => typeof part === 'string' ? part : String(part?.text || '')).join('\n').trim() : '';
        if (fallbackText) { data = fallbackData; replyText = fallbackText; answeredByModel = fallbackData.model || 'gemini-3.6-flash'; }
      } catch (fallbackError) {
        console.warn('[VILA Coach] Gemini fallback failed:', String(fallbackError?.message || fallbackError).slice(0, 240));
      }
    }
    chatMessages = chatMessages.filter(m => m.id !== 'waiting');
    if (!replyText) throw new Error(`Model ${settings.model} không trả văn bản cuối cùng, kể cả sau khi thử lại${settings.aiMode === 'gemini' ? ' và thử Gemini 3.6 Flash dự phòng' : ''}. Hãy mở Cài đặt → Kiểm tra API để xem lỗi HTTP, quyền model, quota và endpoint.`);
    chatMessages.push({ id: makeMessageId(), role: 'assistant', content: replyText + (answeredByModel !== settings.model ? `\n\n_(Phản hồi dự phòng từ ${answeredByModel}; model ưu tiên trong Cài đặt vẫn là ${settings.model}.)_` : '') });
  } catch (error) {
    if (requestId !== coachRequestId || error?.name === 'AbortError') return;
    chatMessages = chatMessages.filter(m => m.id !== 'waiting');
    chatMessages.push({ id: makeMessageId(), role: 'assistant', content: settings.coachEngineMode === 'stockfish' ? `Stockfish chưa phân tích được: ${error.message}\n\nHãy đợi engine sẵn sàng hoặc đóng phân tích đang chạy rồi thử lại.` : `Mình chưa gọi được API: ${error.message}\n\nBạn kiểm tra endpoint, tên model và API key trong Cài đặt nhé. Nếu chỉ muốn luyện cờ, Stockfish nội bộ vẫn dùng độc lập.` });
  } finally {
    if (requestId === coachRequestId) {
      coachRequestActive = false;
      coachAbortController = null;
      if (currentView === 'coach') {
        renderView();
        const transcript = $('#chatTranscript');
        if (transcript) transcript.scrollTop = transcript.scrollHeight;
      }
    }
  }
}

async function requestHint() {
  if (!gameStarted) { toast('Bắt đầu ván trước khi yêu cầu gợi ý.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi dùng gợi ý.'); return; }
  if (botThinking) { toast('Đợi bot đi xong rồi hãy xin gợi ý.'); return; }
  if (game.isGameOver()) { toast('Ván cờ đã kết thúc.'); return; }
  if (engineWorker && engineReady && !engineFailed) {
    if (engineStopPending || engineSearchActive || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive) {
      toast('Stockfish đang xử lý yêu cầu khác; chờ xong rồi thử lại.');
      return;
    }
    const legal = game.moves({ verbose: true });
    if (!legal.length) return;
    cancelMainEngineWatchdog();
    const request = { fen: game.fen(), epoch: gameEpoch, legal, timeout: null };
    request.timeout = setTimeout(() => {
      if (pendingHintRequest !== request) return;
      pendingHintRequest = null;
      engineSearchActive = false;
      const shouldResumeBot = queuedMainEngineMove && botThinking && mode === 'stockfish' && !game.isGameOver() && game.turn() !== humanColor;
      retireStockfishWorker('Stockfish không phản hồi gợi ý kịp thời.');
      if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
      toast('Stockfish chưa phản hồi gợi ý kịp thời; đã dừng engine để tránh kết quả cũ. Chạm trạng thái engine để thử lại.');
      if (shouldResumeBot) { queuedMainEngineMove = false; scheduleBotMove(0); }
    }, 30000);
    pendingHintRequest = request;
    engineSearchActive = true;
    engineWorker.postMessage('stop');
    engineWorker.postMessage(`position fen ${request.fen}`);
    engineWorker.postMessage(`go movetime ${Math.max(700, Math.min(5000, Number(settings.botMoveTimeMs) || 1200))}`);
    return;
  }
  const move = chooseFallbackMove();
  if (move) setHintSuggestion(move, 'Dự phòng nhanh');
  toast(move ? `Gợi ý nhanh: ${move.san}. Đây là gợi ý dự phòng, không phải phân tích Stockfish.` : 'Không có nước đi hợp lệ.');
}

async function queryOpeningExplorer(showToast = true) {
  const requestId = ++explorerRequestId;
  const expectedFen = game.fen();
  const box = $('#explorerResult');
  if (box) box.innerHTML = '<div class="explorer-loading">Đang tra Opening Explorer…</div>';
  try {
    const moves = chessUciHistory();
    const data = await apiFetch(`/api/openings/explorer?moves=${encodeURIComponent(moves)}`);
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    lastExplorerData = data;
    const topMoves = Array.isArray(data?.moves) ? data.moves.slice(0, 4) : [];
    if (box) {
      const rows = topMoves.filter(m => m && typeof m === 'object').map(m => {
        const white = Math.max(0, Number(m.white) || 0);
        const draws = Math.max(0, Number(m.draws) || 0);
        const black = Math.max(0, Number(m.black) || 0);
        const total = white + draws + black;
        const pct = total ? Math.round(100 * white / total) : 0;
        const label = typeof m.san === 'string' ? m.san : typeof m.uci === 'string' ? m.uci : '';
        if (!label) return '';
        return `<div class="explorer-move"><b>${esc(label)}</b><span>${total.toLocaleString('vi-VN')} ván</span><small>Trắng thắng ${pct}%</small></div>`;
      }).filter(Boolean);
      box.innerHTML = rows.length ? `<div class="explorer-title">Nước phổ biến ở thế này</div>${rows.join('')}` : '<div class="empty-state small-empty">Chưa có thống kê cho thế cờ này.</div>';
    }
    if (showToast) toast(topMoves.length ? 'Đã tải dữ liệu khai cuộc từ Lichess.' : 'Không có dữ liệu khai cuộc ở thế này.');
  } catch (error) {
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    if (box) box.innerHTML = `<div class="empty-state small-empty">Chưa tra được: ${esc(error.message)}. Kiểm tra backend hoặc internet.</div>`;
    if (showToast) toast(`Không tra được khai cuộc: ${error.message}`);
  }
}
async function startOnlinePlay() {
  const token = getLichessToken();
  if (!activeOnlineGame?.id || !token) { toast('Cần có ván Lichess và token đã kết nối.'); setView('lichess'); return; }
  historyRestoreSignature = ''; reviewReplayState = null;
  activeLichessToken = token;
  activeOnlineGame.apiMode = $('#lichessApiMode')?.value || activeOnlineGame.apiMode || 'board';
  activeOnlineGame.username = activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '';
  mode = 'lichess';
  humanColor = activeOnlineGame.color === 'black' ? 'b' : activeOnlineGame.color === 'white' ? 'w' : 'w';
  orientation = humanColor;
  game = new Chess(); gameStartFen = game.fen(); gameStarted = true; selected = null; selectedTargets = []; lastMove = null; botThinking = false;
  setView('play');
  toast('Đang kết nối luồng ván Lichess…');
  listenOnlineGame();
}
async function submitLichessMove(uci) {
  if (!activeOnlineGame?.id) { toast('Chưa có mã ván Lichess.'); return; }
  const token = getLichessToken();
  try {
    await apiFetch('/api/lichess/move', { method: 'POST', body: JSON.stringify({ token, gameId: activeOnlineGame.id, move: uci, apiMode: activeOnlineGame.apiMode || 'board' }) });
  } catch (error) {
    toast(`Lichess từ chối nước ${uci}: ${error.message}`);
    listenOnlineGame();
  }
}
async function listenOnlineGame() {
  stopOnlineStream();
  const token = getLichessToken();
  const streamGameId = String(activeOnlineGame?.id || '');
  if (!streamGameId || !token) return;
  const controller = new AbortController();
  onlineStreamController = controller;
  const isCurrentStream = () => !controller.signal.aborted && activeOnlineGame?.id === streamGameId && onlineStreamController === controller;
  try {
    const response = await fetch(apiUrl('/api/lichess/stream'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}) },
      body: JSON.stringify({ token, gameId: streamGameId, apiMode: activeOnlineGame.apiMode || 'board' }),
      signal: controller.signal
    });
    if (!isCurrentStream()) return;
    if (!response.ok || !response.body) {
      const message = await response.text().catch(() => 'Không mở được luồng ván.');
      throw new Error(message.slice(0, 300));
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = '';
    const handleStreamLine = line => {
      const trimmed = line.trim();
      if (!trimmed || !isCurrentStream()) return;
      try { processLichessEvent(JSON.parse(trimmed)); }
      catch (error) { console.warn('Lichess event parse:', error); }
    };
    while (isCurrentStream()) {
      const { value, done } = await reader.read();
      if (!isCurrentStream()) break;
      if (done) {
        pending += decoder.decode();
        if (pending.trim()) handleStreamLine(pending);
        pending = '';
        break;
      }
      pending += decoder.decode(value, { stream: true });
      const lines = pending.split('\n');
      pending = lines.pop() || '';
      for (const line of lines) {
        if (!isCurrentStream()) break;
        handleStreamLine(line);
      }
    }
  } catch (error) {
    if (isCurrentStream() && error?.name !== 'AbortError') toast(`Luồng Lichess bị ngắt: ${error.message}`);
  } finally {
    if (onlineStreamController === controller) onlineStreamController = null;
  }
}
function processLichessEvent(event) {
  if (!event || typeof event !== 'object') return;
  if (event.type === 'gameFull') {
    activeOnlineGame.initialFen = event.initialFen && event.initialFen !== 'startpos' ? event.initialFen : null;
    const whiteName = event.white?.name || event.white?.id || '';
    const blackName = event.black?.name || event.black?.id || '';
    if (activeOnlineGame.username && whiteName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'w';
    else if (activeOnlineGame.username && blackName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'b';
    else if (event.color === 'black' || event.color === 'white') humanColor = event.color === 'black' ? 'b' : 'w';
    orientation = humanColor;
    syncLichessMoveList(event.state?.moves || '');
    if (currentView === 'play') renderView();
  } else if (event.type === 'gameState') {
    syncLichessMoveList(event.moves || '');
    if (event.status && event.status !== 'started') toast(`Ván Lichess kết thúc: ${event.status}.`, 'success');
    if (currentView === 'play') renderView();
  } else if (event.type === 'chatLine') {
    console.info('[Lichess chat]', event.username, event.text);
  }
}
function syncLichessMoveList(movesText) {
  const replay = activeOnlineGame?.initialFen ? new Chess(activeOnlineGame.initialFen) : new Chess();
  for (const uci of String(movesText || '').split(/\s+/).filter(Boolean)) {
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) continue;
    try { replay.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) }); }
    catch { break; }
  }
  game = replay;
  gameEpoch += 1;
  const history = game.history({ verbose: true });
  const last = history[history.length - 1];
  lastMove = last ? { from: last.from, to: last.to } : null;
  selected = null; selectedTargets = [];
}

async function copyText(value) {
  const text = String(value ?? '');
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      toast('Đã sao chép.', 'success');
      return true;
    }
  } catch { /* Try the legacy selection API below for older WebViews. */ }
  let textarea;
  try {
    textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const ok = Boolean(document.execCommand?.('copy'));
    toast(ok ? 'Đã sao chép.' : 'Không sao chép được trên trình duyệt này.');
    return ok;
  } catch {
    toast('Không sao chép được trên trình duyệt này.');
    return false;
  } finally {
    textarea?.remove();
  }
}
function downloadTextFile(contents, filename, mimeType) {
  let url;
  let link;
  try {
    url = URL.createObjectURL(new Blob([contents], { type: mimeType }));
    link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    return true;
  } catch (error) {
    toast(`Không tạo được tệp tải xuống: ${error.message || error}`);
    return false;
  } finally {
    link?.remove();
    if (url) setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
}
function gamePgnWithResult() {
  const result = getGameResult().token;
  const raw = (game.pgn() || '').trim();
  // chess.js may return a complete PGN after a saved game has been loaded.
  // Strip its prior header block, then write one canonical, current header set.
  let moveText = raw;
  const hasPgnHeaders = /^\[[A-Za-z0-9_]+\s+\"/.test(raw);
  const blankLine = hasPgnHeaders ? raw.indexOf('\n\n') : -1;
  if (blankLine >= 0) moveText = raw.slice(blankLine + 2).trim();
  else moveText = raw.replace(/^(?:\s*\[[^\]\r\n]*\]\s*)+/, '').trim();
  moveText = moveText.replace(/(?:1-0|0-1|1\/2-1\/2|\*)\s*$/, '').trim();

  const whiteName = mode === 'local' ? 'White' : (humanColor === 'w' ? 'Player' : (mode === 'ai' ? settings.model : 'Stockfish'));
  const blackName = mode === 'local' ? 'Black' : (humanColor === 'b' ? 'Player' : (mode === 'ai' ? settings.model : 'Stockfish'));
  const defaultFen = new Chess().fen();
  const setupHeaders = gameStartFen && gameStartFen !== defaultFen
    ? `\n[SetUp "1"]\n[FEN "${pgnEscape(gameStartFen)}"]`
    : '';
  const terminationHeader = manualGameResult?.reason
    ? `\n[Termination "${pgnEscape(manualGameResult.reason)}"]`
    : '';
  const headers = `[Event "VILA Chess"]\n[Site "VILA Chess"]\n[White "${pgnEscape(whiteName)}"]\n[Black "${pgnEscape(blackName)}"]\n[Result "${result}"]${setupHeaders}${terminationHeader}`;
  return `${headers}\n\n${moveText || result}${moveText ? ` ${result}` : ''}`;
}
function downloadPgn() {
  downloadTextFile(gamePgnWithResult(), 'chess-bot-game.pgn', 'application/x-chess-pgn;charset=utf-8');
}

function stopOnlineStream() {
  if (onlineStreamController) { onlineStreamController.abort(); onlineStreamController = null; }
}

// Re-measure against the actual WebView viewport on rotation, split-screen, or inset changes.
window.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });
window.addEventListener('orientationchange', scheduleBoardLayoutSync, { passive: true });
window.visualViewport?.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });

async function loadExternalOpeningCatalog() {
  if (openingCatalogLoadPromise) return openingCatalogLoadPromise;
  openingCatalogLoadPromise = (async () => {
    try {
      const response = await fetch('./openings-eco.json', { cache: 'force-cache' });
      if (!response.ok) throw new Error(`HTTP ${response.status} loading openings-eco.json`);
      const payload = await response.json();
      const entries = Array.isArray(payload) ? payload : payload?.openings;
      if (!Array.isArray(entries) || !entries.length) {
        if (OPENINGS.length < REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Kho khai cuộc chưa đầy đủ', message: `Ứng dụng đang có ${OPENINGS.length.toLocaleString()} biến mẫu, chưa đạt yêu cầu ${REQUIRED_OPENING_COUNT.toLocaleString()}. Cần build lại với dữ liệu ECO hợp lệ; không xóa kho đang có.`, type: 'error', sourceKey: 'opening-catalog:missing-full-data' });
        if (currentView === 'health') renderView();
        return 0;
      }
      const additions = mergeOpeningEntries(OPENINGS, entries, 5000);
      if (!additions.length) return 0;
      OPENINGS.push(...additions);
      console.info(`[VILA Chess] Loaded ${additions.length} additional ECO openings; total ${OPENINGS.length}.`);
      if (OPENINGS.length >= REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Thư viện khai cuộc đã nạp', message: `Đã nạp ${OPENINGS.length.toLocaleString()} biến khai cuộc hợp lệ.`, type: 'success', sourceKey: `opening-catalog:loaded:${OPENINGS.length}` });
      else addAppNotification({ title: 'Kho khai cuộc chưa đủ dữ liệu', message: `Đã nạp ${OPENINGS.length.toLocaleString()} biến, chưa đạt ngưỡng ${REQUIRED_OPENING_COUNT.toLocaleString()}.`, type: 'warning', sourceKey: `opening-catalog:below-threshold:${OPENINGS.length}` });
      const playCount = $('#playOpeningCount');
      if (playCount) playCount.textContent = OPENINGS.length.toLocaleString();
      if (currentView === 'openings' && $('#openingGrid')) {
        openingPageLimit = 48;
        const query = String($('#openingSearch')?.value || '').trim().toLocaleLowerCase();
        const family = $('#openingFilter')?.value || 'all';
        const filteredCount = OPENINGS.filter(item => (family === 'all' || item.family === family) && `${item.name} ${item.eco} ${item.note} ${item.line}`.toLocaleLowerCase().includes(query)).length;
        if ($('#openingCount')) $('#openingCount').textContent = `${filteredCount.toLocaleString()} đường khai cuộc`;
        $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', family);
        wireOpeningButtons();
      }
      const label = $('#openingRecognition');
      if (label && currentView === 'play') {
        const found = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
        label.textContent = found ? `Khai cuộc nhận diện: ${found.name}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước');
      }
      if (currentView === 'health') renderView();
      return additions.length;
    } catch (error) {
      console.info('[VILA Chess] Expanded opening catalog unavailable; curated offline book remains active.', error?.message || error);
      if (OPENINGS.length < REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Không tải được kho khai cuộc mở rộng', message: `Chỉ còn ${OPENINGS.length.toLocaleString()} biến mẫu trên thiết bị. Lỗi nạp dữ liệu: ${String(error?.message || error).slice(0, 220)}`, type: 'error', sourceKey: 'opening-catalog:load-failed' });
      if (currentView === 'health') renderView();
      return 0;
    }
  })();
  return openingCatalogLoadPromise;
}

// Boot
syncSocialNav();
syncInboxBadge();
adoptSocialCallback();
setInterval(() => { void pollSocialInbox(); }, 60_000);
if (socialState.token) setTimeout(() => { void pollSocialInbox(); }, 1500);
$$('.tab').forEach(tab => tab.addEventListener('click', () => { if (tab.hidden) return; setView(tab.dataset.view); }));
$('.brand')?.addEventListener('click', event => { event.preventDefault(); setView('home'); });
$('#accountShortcut')?.addEventListener('click', () => setView('friends'));
$('#openInbox')?.addEventListener('click', () => setView('inbox'));
const brandLogo = $('.brand-logo');
brandLogo?.addEventListener('error', () => { brandLogo.hidden = true; const fallback = $('#brandLogoFallback'); if (fallback) fallback.hidden = false; }, { once: true });
if (brandLogo?.complete && brandLogo.naturalWidth === 0) brandLogo.dispatchEvent(new Event('error'));
$('#openMenu')?.addEventListener('click', () => { const menu = $('#mainMenu'); const open = menu?.classList.toggle('menu-open') ?? false; $('#openMenu')?.setAttribute('aria-expanded', String(open)); });
$('#openSettings')?.addEventListener('click', () => setView('settings'));
$('#engineStatus')?.addEventListener('click', retryStockfishEngine);
window.addEventListener('pagehide', () => {
  const match = rankedMatchState?.match;
  if (currentView !== 'ranked' || !socialState.token || match?.status !== 'active') return;
  try {
    const base = socialBackendBase();
    void fetch(`${base}/api/social/ranked/matches/${encodeURIComponent(match.id)}/abandon`, {
      method: 'POST', keepalive: true,
      headers: { Authorization: `Bearer ${socialState.token}`, 'Content-Type': 'application/json' },
      body: '{}'
    }).catch(() => {});
  } catch { /* Server-side presence timeout remains the fallback when pagehide cannot reach the backend. */ }
});
resetClock(settings.clockPreset);
ensureClockTicker();
renderView();
initEngine();
void loadExternalOpeningCatalog();

