import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const pieceStart = main.indexOf('function pieceGlyph(piece) {');
const pieceEnd = main.indexOf('\nfunction squareColor(square)', pieceStart);
const renderer = main.slice(pieceStart, pieceEnd);

test('All six chess types use local, distinct Staunton-style SVG silhouettes', () => {
  assert.ok(pieceStart >= 0 && pieceEnd > pieceStart, 'piece renderer must exist');
  for (const type of ['k', 'q', 'r', 'b', 'n', 'p']) {
    assert.match(renderer, new RegExp(`\\n\\s+${type}: \\{`), `missing SVG silhouette for ${type}`);
  }
  assert.match(renderer, /piece-svg-\$\{piece\.type\}/);
  assert.match(renderer, /fill="currentColor"/);
  assert.match(renderer, /shape\.body/);
  assert.match(renderer, /shape\.detail/);
  assert.doesNotMatch(renderer, /[♔♕♖♗♘♙♚♛♜♝♞♟]/, 'pieces must not depend on platform chess glyph fonts');
});

test('Annotation toolbar dragging is frame-coalesced and uses compositor transforms', () => {
  const start = main.indexOf('function wireAnnotationWidget()');
  const end = main.indexOf('\nfunction canStartBoardDrag', start);
  const fn = main.slice(start, end);
  assert.match(fn, /if \(!annotationWidgetRaf\) annotationWidgetRaf = requestAnimationFrame/);
  assert.match(fn, /translate3d\(/);
  assert.match(fn, /Commit the final position once when the gesture ends/);
  assert.match(fn, /localStorage\.setItem\('vila\.chess\.annotation-widget-position\.v1'/);
  assert.equal((fn.match(/getBoundingClientRect\(\)/g) || []).length, 2,
    'geometry reads should happen only at pointer-down, not on every move/end event');
});

test('Manual annotation color classes match the styles for all three colors', () => {
  assert.match(main, /manual-\$\{mark\.type\}-\$\{mark\.color \|\| 'green'\}/);
  for (const type of ['arrow', 'circle']) {
    for (const color of ['green', 'red', 'yellow']) {
      assert.match(css, new RegExp(`\\.manual-${type}-${color}\\s*\\{`), `missing ${type} ${color} style`);
    }
  }
});

test('Android drawing toolbar avoids background blur and SVG filter shadows', () => {
  const widgetRule = css.match(/\.board-annotation-widget\{[^}]*\}/)?.[0] || '';
  const arrowRule = css.match(/\.manual-arrow\{[^}]*\}/)?.[0] || '';
  const circleRule = css.match(/\.manual-circle\{[^}]*\}/)?.[0] || '';
  const svgRule = css.match(/\.piece-svg\{[^}]*\}/)?.[0] || '';
  assert.ok(widgetRule);
  assert.doesNotMatch(widgetRule, /backdrop-filter/);
  assert.match(arrowRule, /filter:none/);
  assert.match(circleRule, /filter:none/);
  assert.match(svgRule, /filter:none/);
  assert.match(css, /\.board-annotation-widget\.is-moving\{will-change:transform/);
  assert.equal(pkg.version, '3.14.0');
});
