VILA AI SERVER V16

1) Cài Node.js >= 18.
2) Đặt GEMINI_API_KEY trong biến môi trường. Trên Windows có thể dùng start-vila-server.bat và file .env.
3) Mở terminal tại thư mục server:
   npm install
   GEMINI_API_KEY=YOUR_KEY npm start
4) Mở http://127.0.0.1:8787/api/health để kiểm tra.

API key được giữ ở server, không cần nhúng vào HTML. Server lắng nghe 0.0.0.0 để có thể truy cập từ thiết bị khác trong cùng mạng LAN.

V16 hỗ trợ chat multimodal (văn bản + ảnh), Google Search grounding, giới hạn payload và tự fallback model khi model/quota lỗi.

Lưu ý: server không thể vượt quota Gemini. Nếu toàn bộ model trong cùng project đều bị giới hạn, API sẽ trả lỗi 429 rõ ràng.
