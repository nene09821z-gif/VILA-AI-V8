import { Chess } from 'chess.js';
import { resolveEngineProfile, nextEngineFallback, engineAssetFile } from './engine-profile.js';
import { createEngineHealthState, observeEngineLine, failEngineHealth, describeEngineHealth, engineStartupDurationMs, splitUciOutput } from './engine-health.js';
import { sealLocalGameRecoverySnapshot, validateLocalGameRecoverySnapshot } from './game-recovery.js';
import { LegacyUciEngine } from './legacy-uci-engine.js';
import { formatUciScore, parseUciInfoLine } from './analysis-utils.js';
import { isCurrentAnalysisSession, mergeAnalysisVariation } from './analysis-session.js';
import { calculateBoardFrameMaxWidth, calculateChessSquareSize } from './board-layout.js';
import { CLOCK_PRESETS, RANKED_CLOCK_PRESETS, classifyTimeControl, formatClockTime, parseClockPreset, consumeClockTick } from './clock.js';
import { OPENINGS } from './openings.js';
import { mergeOpeningEntries } from './opening-catalog.js';
import { findOpeningBookMove } from './opening-book.js';
import { generateOfflinePuzzleInWorker as generateOfflinePuzzle, generateDailyPuzzleInWorker, isPuzzleAnswerLegal } from './puzzle-worker-client.js';
import { loadPuzzleHistory, rememberPuzzle } from './puzzle-history.js';
import { prepareLichessDailyPuzzle, validateCachedPuzzleLine, uciToMove, lichessDifficultyForProgress, lichessPuzzleUrlForDifficulty, lichessDailyPuzzleUrl } from './lichess-puzzle.js';
import { LICHESS_PUZZLE_POOL_LIMIT, normalizePuzzlePool, upsertPuzzlePool, chooseUnusedPuzzle, puzzlePoolKey } from './puzzle-pool.js';
import { summarizeCapturedMaterial } from './material-tracker.js';
import { getPremoveLegalMoves, appendPremove, buildPremovePosition, takeNextPremove, premoveSquares, isPremoveSquare, describePremoveQueue } from './premove.js';
import { pickPersonaBookMove } from './bot-personas.js';
import { recognizeOpening } from './opening-recognition.js';
import { classifyMoveQuality, winChance } from './game-review.js';
import { detectSacrifice } from './review-brilliance.js';
import { buildOpeningBookPrefixes, classifyReviewedMove, estimateMoveLoss, scoreSideToWhiteCentipawns, reviewSymbolForJudgement, reviewSymbolDescription } from './game-review.js';
import { groupReviewedMoves, summarizeReviewSide } from './review-list.js';
import { resolveStockfishStrength } from './elo-strength.js';
import { resolveOfflineSearchBudget, resolveReviewMoveTimeMs } from './engine-budgets.js';
import { DEFAULT_VISUAL_SETTINGS, normalizeVisualSettings } from './visual-settings.js';
import { captureClockSnapshot, recordClockSnapshot, restoreClockSnapshot, cloneClockHistoryRange } from './move-clock-history.js';
import { isMoveContextCurrent } from './move-input.js';
import { chooseAlternateMoveAsync, getLastOfflineEngineStats, OFFLINE_ENGINE_CATALOG, OFFLINE_ENGINE_IDS, offlineEngineShortName } from './alternate-engine.js';
import { pieceSvgMarkup, ensurePieceSprite, PIECE_STYLES, getPieceStyle, setPieceStyle } from './pieces.js';
import { playBoardSound, playGameSound, unlockBoardSound, isChessMusicPlaying, setChessMusicPlaying, setChessMusicYoutube, getChessMusicYoutube, getChessMusicTrack, setChessMusicTrack, listChessMusicTracks } from './sound.js';
import { parseYoutubeUrl, YOUTUBE_PRESETS } from './youtube-music.js';
import { applyEloResult } from './elo.js';
import { DEFAULTS, normalizeSettings } from './settings-schema.js';
import { DAILY_MISSIONS, COSMETICS, normalizeDailyState, recordMissionEvent, claimMissionReward, purchaseCosmetic, equipCosmetic, getMissionSummary } from './daily-progress.js';
import { addNotification, clearReadNotifications, markAllNotificationsRead, markNotificationRead, normalizeNotifications, unreadNotificationCount } from './notifications.js';
import { buildSystemChecks, REQUIRED_OPENING_COUNT } from './system-health.js';
import {
  createSolvedRubikCube, applyRubikMove, invertRubikMove, scrambleRubikMoves,
  getRubikFaceStickers, isRubikSolved, create2048Board, move2048, has2048Moves,
  createScrambledSlidingPuzzle, moveSlidingPuzzleTile, isSlidingPuzzleSolved,
} from './mini-games.js';
import { chooseTicTacToeMove, ticTacToeOutcome } from './tic-tac-toe.js';
import './style.css';
import './vila-atelier.css';
import './mobile-upgrade.css';
import './vila-polish.css';
import {
  getFirebaseConfig,
  saveFirebaseConfig,
  isFirebaseConfigured,
  getSyncMeta,
  saveSyncMeta,
  authenticateWithFirebase,
  syncHistoryToCloud
} from './firebase-sync.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const STORAGE_KEY = 'tubor.chess.settings.v1';
const lichessTokenKey = 'tubor.chess.lichessToken.session';
const RATING_KEY = 'chessbot.local.rating.v1';
const RATING_HISTORY_KEY = 'chessbot.local.rating.history.v1';
const GAME_HISTORY_KEY = 'vila.chess.saved-games.v1';
const SOCIAL_SESSION_KEY = 'vila.chess.social.session.v1';
const SOCIAL_USER_KEY = 'vila.chess.social.user.v1';
const DAILY_PROGRESS_KEY = 'vila.chess.daily-progress.v1';
const NOTIFICATIONS_KEY = 'vila.chess.notifications.v1';
const MUSIC_AUTOSTART_KEY = 'vila.chess.music-autostart.v1';
const BOARD_THEME_KEY = 'vila.chess.board-theme.v1';
const VISUAL_SETTINGS_KEY = 'vila.chess.visual-settings.v1';

export const BOT_DIFFICULTY_LEVELS = Object.freeze([
  { level: 1, name: 'Người mới (Dễ)', elo: 600, badge: 'Dễ', depth: 8, timeMs: 800, desc: 'Nước đi cơ bản, ít bẫy chiến thuật' },
  { level: 2, name: 'Tập sự (Căn bản)', elo: 1000, badge: 'Tập sự', depth: 10, timeMs: 1200, desc: 'Phát triển quân đều, phù hợp luyện tập' },
  { level: 3, name: 'Kỳ thủ (Khá)', elo: 1500, badge: 'Khá', depth: 14, timeMs: 1600, desc: 'Chiến thuật nhạy bén, kiểm soát trung tâm' },
  { level: 4, name: 'Kiện tướng (Nâng cao)', elo: 2000, badge: 'Kiện tướng', depth: 18, timeMs: 2200, desc: 'Đòn phối hợp sâu, tấn công chính xác' },
  { level: 5, name: 'Đại kiện tướng (Bậc thầy)', elo: 2600, badge: 'Bậc thầy', depth: 24, timeMs: 3000, desc: 'Thế cờ đỉnh cao, tính toán đa tầng' },
  { level: 6, name: 'Stockfish Tối đa (Vô địch)', elo: 3200, badge: 'Vô địch', depth: 30, timeMs: 4000, desc: 'Sức mạnh tối đa không giới hạn' }
]);

function getBotDifficultyBadge(elo = 2600, mode = 'elo') {
  if (mode !== 'elo') return 'Vô địch · 3200+';
  const val = Number(elo) || 2600;
  if (val <= 700) return 'Dễ · Elo 600';
  if (val <= 1200) return 'Tập sự · Elo 1000';
  if (val <= 1700) return 'Khá · Elo 1500';
  if (val <= 2200) return 'Kiện tướng · Elo 2000';
  if (val <= 2800) return 'Bậc thầy · Elo 2600';
  return 'Vô địch · Elo 3200';
}

function getCurrentBotLevel() {
  if (settings.botStrengthMode !== 'elo') return BOT_DIFFICULTY_LEVELS[5];
  const elo = Number(settings.botElo) || 2600;
  if (elo <= 700) return BOT_DIFFICULTY_LEVELS[0];
  if (elo <= 1200) return BOT_DIFFICULTY_LEVELS[1];
  if (elo <= 1700) return BOT_DIFFICULTY_LEVELS[2];
  if (elo <= 2200) return BOT_DIFFICULTY_LEVELS[3];
  if (elo <= 2800) return BOT_DIFFICULTY_LEVELS[4];
  return BOT_DIFFICULTY_LEVELS[5];
}

function applyBotDifficultyLevel(lvlNum) {
  const target = BOT_DIFFICULTY_LEVELS[lvlNum - 1] || BOT_DIFFICULTY_LEVELS[4];
  if (target.level === 6) {
    settings.botStrengthMode = 'max';
    settings.botSkill = 20;
    settings.botDepth = target.depth;
    settings.botMoveTimeMs = target.timeMs;
  } else {
    settings.botStrengthMode = 'elo';
    settings.botElo = target.elo;
    settings.botSkill = Math.max(1, Math.min(20, Math.round(target.elo / 160)));
    settings.botDepth = target.depth;
    settings.botMoveTimeMs = target.timeMs;
  }
  saveSettings();
  renderView();
  toast(`Đã chọn cấp độ bot: ${target.name} (Elo ${target.level === 6 ? '3200+' : target.elo})`, 'success');
}
let musicAutostart = (() => { try { return localStorage.getItem(MUSIC_AUTOSTART_KEY) === 'true'; } catch { return false; } })();
let musicAutostartHandled = false;
function readSocialCache(key, fallback = null) { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; } }
function syncMusicControls() {
  const active = isChessMusicPlaying();
  const appToggle = $('#appMusicToggle');
  const homeToggle = $('#homeToggleChessMusic');
  const playToggle = $('#toggleChessMusic');
  for (const button of [appToggle, homeToggle]) {
    if (!button) continue;
    button.setAttribute('aria-pressed', String(active));
    button.setAttribute('aria-label', active ? 'Tắt nhạc nền' : 'Bật nhạc nền');
    button.title = active ? 'Nhạc nền đang phát · chạm để tắt' : 'Bật/tắt nhạc nền cờ vua';
    button.classList.toggle('music-is-playing', active);
  }
  if (appToggle) appToggle.textContent = '🎧';
  if (homeToggle) homeToggle.textContent = active ? '🎧 Đang phát · Tắt nhạc' : '🎧 Bật nhạc cờ vua';
  if (playToggle) {
    playToggle.textContent = active ? '🎧 Nhạc · Đang phát' : '🎧 Nhạc';
    playToggle.setAttribute('aria-pressed', String(active));
  }
}
const YOUTUBE_MUSIC_KEY = 'vila.chess.music-youtube.v1';
function savedYoutubeMusicUrl() { try { return localStorage.getItem(YOUTUBE_MUSIC_KEY) || ''; } catch { return ''; } }
function youtubeMusicFormMarkup() {
  const saved = savedYoutubeMusicUrl();
  return `<div class="yt-music-form"><label class="field-label" for="ytMusicUrl">Phát nhạc từ YouTube (video, livestream hoặc playlist)</label><div class="yt-music-row"><input id="ytMusicUrl" class="field" inputmode="url" autocomplete="off" placeholder="Dán link YouTube vào đây…" value="${esc(saved)}"/><button id="ytMusicPlay" type="button" class="primary-btn">▶ Phát</button></div><div class="yt-music-presets">${YOUTUBE_PRESETS.map(item => `<button type="button" class="chip-btn" data-yt-preset="${esc(item.url)}">${esc(item.label)}</button>`).join('')}<button type="button" id="ytMusicPiano" class="chip-btn">↺ Nhạc tích hợp</button></div><small class="field-hint">Cần internet. Một số video chặn phát nhúng; nếu lỗi, app tự quay về nhạc tích hợp.</small></div>`;
}
function playYoutubeMusicFromUi(rawUrl) {
  const parsed = parseYoutubeUrl(rawUrl);
  if (!parsed) { toast('Link YouTube không hợp lệ. Hãy dán link video hoặc playlist.'); return; }
  try { localStorage.setItem(YOUTUBE_MUSIC_KEY, String(rawUrl).trim()); } catch {}
  musicAutostartHandled = true;
  setChessMusicYoutube(parsed, { onFailure: error => { toast(`${error?.message || 'YouTube không phát được.'} Đã quay về nhạc cờ vua tích hợp.`); syncMusicControls(); } });
  if (!isChessMusicPlaying()) setChessMusicPlaying(true);
  syncMusicControls();
  toast('Đang mở nhạc từ YouTube…');
}
function wireYoutubeMusicControls() {
  const input = $('#ytMusicUrl');
  $('#ytMusicPlay')?.addEventListener('click', () => playYoutubeMusicFromUi(input?.value || ''));
  input?.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); playYoutubeMusicFromUi(input.value); } });
  $$('[data-yt-preset]').forEach(button => button.addEventListener('click', () => { if (input) input.value = button.dataset.ytPreset; playYoutubeMusicFromUi(button.dataset.ytPreset); }));
  $('#ytMusicPiano')?.addEventListener('click', () => { setChessMusicYoutube(null); try { localStorage.removeItem(YOUTUBE_MUSIC_KEY); } catch {} if (input) input.value = ''; toast('Đã quay về nhạc nhạc cờ vua tích hợp.'); });
  $('#homeToggleChessMusic')?.addEventListener('click', toggleChessMusicFromUi);
}
function toggleChessMusicFromUi() {
  musicAutostartHandled = true;
  const enabled = setChessMusicPlaying(!isChessMusicPlaying());
  syncMusicControls();
  if (!enabled) toast('Đã tắt nhạc nền.');
}
function handleMusicAutostartGesture(event) {
  if (!musicAutostart || musicAutostartHandled || isChessMusicPlaying()) return;
  const target = event?.target;
  if (target?.closest?.('#appMusicToggle, #toggleChessMusic, #homeToggleChessMusic, #musicAutostartSetting, .yt-music-form, #vilaYtCard, #musicYoutubeSearch, #musicRhyderSearch, #musicMckSearch')) return;
  musicAutostartHandled = true;
  setChessMusicPlaying(true);
  syncMusicControls();
}
function readDailyProgress() {
  let raw = null;
  try { raw = localStorage.getItem(DAILY_PROGRESS_KEY); } catch {}
  const stored = raw ? (() => { try { return JSON.parse(raw); } catch { return null; } })() : null;
  const state = normalizeDailyState(stored, new Date());
  const normalized = JSON.stringify(state);
  if (raw !== normalized) { try { localStorage.setItem(DAILY_PROGRESS_KEY, normalized); } catch { /* Progress remains best-effort when storage is disabled. */ } }
  applyBoardCosmetic(state.activeCosmetic);
  return state;
}
function persistDailyProgress(state) {
  try { localStorage.setItem(DAILY_PROGRESS_KEY, JSON.stringify(state)); } catch { /* Local progression is optional; chess stays playable if storage is unavailable. */ }
  applyBoardCosmetic(state?.activeCosmetic || 'classic');
}
function getSelectedBoardTheme(fallback = 'classic') {
  let saved = '';
  try { saved = localStorage.getItem(BOARD_THEME_KEY) || ''; } catch {}
  if (COSMETICS.some(item => item.id === saved)) return saved;
  return COSMETICS.some(item => item.id === fallback) ? fallback : 'classic';
}
function applyBoardCosmetic(id) {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.boardTheme = getSelectedBoardTheme(id);
}
function selectBoardTheme(id) {
  if (!COSMETICS.some(item => item.id === id)) return false;
  try { localStorage.setItem(BOARD_THEME_KEY, id); } catch {}
  applyBoardCosmetic(id);
  return true;
}
function recordDailyEvent(event) {
  const state = recordMissionEvent(readDailyProgress(), event, new Date());
  persistDailyProgress(state);
  return state;
}
const persistedSocialToken = (() => { try { return localStorage.getItem(SOCIAL_SESSION_KEY) || ''; } catch { return ''; } })();
let socialState = { token: persistedSocialToken, user: persistedSocialToken ? readSocialCache(SOCIAL_USER_KEY) : null, friends: [], incoming: [], outgoing: [], searchResults: [], leaderboard: [], adminOverview: null, adminUsers: [], auditEvents: [], error: '', loading: false };
let appNotifications = (() => { try { return normalizeNotifications(JSON.parse(localStorage.getItem(NOTIFICATIONS_KEY) || '[]')); } catch { return []; } })();
let healthBackendStatus = 'unknown';
function saveSocialSession(token, user) {
  const nextToken = String(token || '').trim();
  socialState.token = nextToken;
  socialState.user = user && typeof user === 'object' ? user : null;
  let saved = true;
  try {
    if (nextToken) localStorage.setItem(SOCIAL_SESSION_KEY, nextToken);
    else localStorage.removeItem(SOCIAL_SESSION_KEY);
    if (socialState.user) localStorage.setItem(SOCIAL_USER_KEY, JSON.stringify(socialState.user));
    else localStorage.removeItem(SOCIAL_USER_KEY);
  } catch (error) {
    saved = false;
    console.warn('[Cờ Vua ViLa] Account session could not be persisted on this device:', error?.message || error);
  }
  if (!nextToken) {
    socialState.friends = [];
    socialState.incoming = [];
    socialState.outgoing = [];
    socialState.searchResults = [];
    socialState.leaderboard = [];
    socialState.adminOverview = null;
    socialState.adminUsers = [];
    socialState.auditEvents = [];
  }
  syncSocialNav();
  return saved;
}
function persistNotifications() {
  try { localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(appNotifications)); return true; }
  catch (error) { console.warn('[Cờ Vua ViLa] Notification inbox could not be saved:', error?.message || error); return false; }
}
function syncInboxBadge() {
  const badge = $('#inboxBadge');
  if (!badge) return;
  const count = unreadNotificationCount(appNotifications);
  badge.textContent = count > 99 ? '99+' : String(count);
  badge.hidden = count < 1;
  $('#openInbox')?.setAttribute('aria-label', count ? `Hộp thư, ${count} thông báo chưa đọc` : 'Mở hộp thư');
}
function addAppNotification(payload) {
  const result = addNotification(appNotifications, payload);
  if (!result.added) return result.notification;
  appNotifications = result.items;
  persistNotifications();
  syncInboxBadge();
  return result.notification;
}
function syncSocialNav() {
  const adminTab = $('[data-view="admin"]');
  if (adminTab) adminTab.hidden = socialState.user?.role !== 'admin';
  const user = socialState.user;
  const avatar = $('#accountAvatar');
  const label = $('#accountShortcutLabel');
  const shortcut = $('#accountShortcut');
  if (avatar) avatar.textContent = String((user?.displayName || user?.username || '♙').trim()).slice(0, 1).toUpperCase();
  if (label) label.textContent = user ? String(user.displayName || user.username || 'Tài khoản').slice(0, 14) : 'Tài khoản';
  if (shortcut) {
    shortcut.title = user ? `${user.displayName || user.username} · mở hồ sơ` : 'Đăng nhập hoặc tạo tài khoản';
    shortcut.setAttribute('aria-label', shortcut.title);
  }
  syncInboxBadge();
}
function socialBackendBase() {
  const configured = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  if (configured) return configured;
  if (location.protocol === 'http:' || location.protocol === 'https:') return '';
  throw new Error('Chưa cấu hình URL backend. Mở Cài đặt → Máy chủ cộng đồng, nhập URL HTTPS của server Cờ Vua ViLa rồi lưu. Đăng nhập Google/GitHub không thể hoạt động nếu chưa có backend thật.');
}
async function socialApi(path, options = {}) {
  const base = socialBackendBase();
  const headers = { ...(options.headers || {}) };
  if (socialState.token) headers.Authorization = `Bearer ${socialState.token}`;
  if (options.body && typeof options.body === 'string') headers['Content-Type'] = 'application/json';
  const response = await fetch(`${base}/api/social${path}`, { ...options, headers, signal: options.signal || AbortSignal.timeout(15000) });
  const type = response.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
  if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
  return data;
}
function captureIncomingFriendNotifications(incoming) {
  if (!Array.isArray(incoming)) return;
  for (const request of incoming) {
    const name = request?.user?.displayName || request?.user?.username;
    if (!request?.id || !name) continue;
    addAppNotification({
      title: 'Lời mời kết bạn mới',
      message: `@${request.user.username || name} muốn kết bạn với bạn. Mở mục Bạn bè để phản hồi.`,
      type: 'info',
      sourceKey: `friend-request:${request.id}`
    });
  }
}
function socialHandleError(error, fallback = 'Không thể kết nối máy chủ cộng đồng.') {
  const message = String(error?.message || error || fallback);
  if (/Phiên đăng nhập hết hạn|phiên đăng nhập|không hợp lệ|HTTP 401|HTTP 403/i.test(message)) saveSocialSession('', null);
  toast(message);
  return message;
}
function adoptSocialCallback() { try { const hash = new URLSearchParams(location.hash.replace(/^#/, '')); const token = hash.get('social_token'); const error = hash.get('social_error'); if (token) { saveSocialSession(token, null); history.replaceState(null, '', location.pathname + location.search); socialApi('/auth/me').then(data => { saveSocialSession(token, data.user); toast('Đăng nhập thành công.'); if (currentView === 'friends' || currentView === 'admin') renderView(); }).catch(socialHandleError); } else if (error) { history.replaceState(null, '', location.pathname + location.search); toast(error); } } catch {} }
let ratedGameSignature = '';
function readRatingProfile() { try { const p = JSON.parse(localStorage.getItem(RATING_KEY) || '{}'); return { elo: Number(p.elo) || 1200, games: Number(p.games) || 0, wins: Number(p.wins) || 0, draws: Number(p.draws) || 0, losses: Number(p.losses) || 0, lastChange: Number(p.lastChange) || 0, processedGameIds: Array.isArray(p.processedGameIds) ? p.processedGameIds.filter(id => typeof id === 'string').slice(-200) : [] }; } catch { return { elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, lastChange: 0, processedGameIds: [] }; } }
function readRatingHistory() { try { const h = JSON.parse(localStorage.getItem(RATING_HISTORY_KEY) || '[]'); return Array.isArray(h) ? h.slice(-100) : []; } catch { return []; } }
function maybeRecordRatedGame() {
  if (!gameStarted || !['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) || (!game.isGameOver() && !clockFlagged && !manualGameResult)) return;
  const result = getGameResult(); if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const signature = String(currentGameId || '');
  if (!signature || signature === ratedGameSignature) return;
  const before = readRatingProfile();
  // The profile write is the idempotency record. A separate history-write failure must never award Elo twice.
  if (before.processedGameIds.includes(signature)) { ratedGameSignature = signature; return; }
  const humanScore = result.token === '1/2-1/2' ? 0.5 : ((result.token === '1-0') === (humanColor === 'w') ? 1 : 0);
  const opponentElo = settings.botStrengthMode === 'elo' ? Number(settings.botElo || 1800) : 2200;
  const after = applyEloResult(before, opponentElo, humanScore);
  after.processedGameIds = [...before.processedGameIds, signature].slice(-200);
  try {
    localStorage.setItem(RATING_KEY, JSON.stringify(after));
    ratedGameSignature = signature;
    const history = readRatingHistory();
    history.push({ signature, date: new Date().toISOString(), result: result.token, title: result.title, ratingSource: 'local', ratingScope: 'local-only', opponent: mode === 'vila' ? 'ViLa Classic · heuristic' : mode === 'enginehub' ? `Bot phong cách · ${settings.alternativeEngine}` : `Stockfish · ${opponentElo} Elo ước lượng`, opponentElo, score: humanScore, change: after.lastChange, elo: after.elo, plies: game.history().length });
    try { localStorage.setItem(RATING_HISTORY_KEY, JSON.stringify(history.slice(-100))); } catch { /* Elo is already committed; history remains best-effort. */ }
    recordDailyEvent('complete_game'); recordDailyEvent(humanScore === 1 ? 'win_game' : humanScore === 0.5 ? 'draw_game' : 'lose_game');
  } catch { /* Storage may be disabled; do not mutate in-memory rating state. */ }
}
function safeSessionGet(key) {
  try { return sessionStorage.getItem(key) || ''; } catch { return ''; }
}
function safeSessionSet(key, value) {
  try { sessionStorage.setItem(key, String(value ?? '')); return true; } catch { return false; }
}
function safeSessionRemove(key) {
  try { sessionStorage.removeItem(key); return true; } catch { return false; }
}
function getLichessToken() {
  return String($('#lichessToken')?.value?.trim() || activeLichessToken || safeSessionGet(lichessTokenKey) || '').trim();
}

let settings = loadSettings();
let visualSettings = loadVisualSettings();
applyVisualSettings(visualSettings);
let currentView = 'home';
let game = new Chess();
let gameStartFen = game.fen();
let currentGameId = '';
let reviewStatus = '';
let gameStarted = false; // New launches always wait for explicit Start.
let manualGameResult = null; // Resign/agree-draw result; does not falsify chess.js move history.
let reviewSession = null;
let completedReviewRows = [];
let reviewReplayState = null;
let historyRestoreSignature = '';
let dragState = null;
let dragGhost = null;
let dragMoveFrame = 0;
let dragLatestPoint = null;
let boardSquareMap = new Map();
// Only revisit squares whose selection/legal-target state changed; this keeps taps responsive on low-end WebViews.
let boardHighlightedSquares = new Set();
let suppressSquareClick = null;
let mode = 'stockfish'; // stockfish, vila, enginehub, local
let humanColor = 'w';
let arenaRandomSides = true;
let colorChoice = 'random'; // default: random side each game (Trắng/Đen)
let orientation = 'w';
let selected = null;
let selectedTargets = [];
let premoveQueue = []; // Chess.com-style premoves: an unlimited ordered queue entered while the opponent is thinking.
let premoveViewCache = { key: '', chess: null };
let botThinking = false;
let currentOpening = null;
let openingPageLimit = 48;
let openingCatalogLoadPromise = null;
let lastHintMove = null;
let boardAnnotations = [];
let annotationPreview = null;
let annotationPreviewRaf = 0;
const ANNOTATION_COLORS = ['green', 'red', 'yellow', 'blue'];
let annotationTool = null; // null = normal chess movement; 'arrow'/'circle' = touch drawing mode.
let annotationColor = 'green';
let annotationCollapsed = true;
let annotationPointer = null;
let randomBotEloEnabled = false;
let experienceLevel = readSocialCache('vila.chess.experience.v1', '');
if (!['beginner', 'experienced'].includes(experienceLevel)) experienceLevel = '';
let selectedRankedTimeControl = readSocialCache('vila.chess.ranked-time-control.v1', '3+2');
if (!RANKED_CLOCK_PRESETS.some(item => item.value === selectedRankedTimeControl)) selectedRankedTimeControl = '3+2';
const recentOpeningChoices = new Map();
let pendingCoachAnalysis = null;
let lastMove = null;
let engineWorker = null;
let engineInitTimeout = null;
let engineHealthState = createEngineHealthState('unknown');
let stockfishWarmupTimer = null;
let waitingForStockfishMove = null;
let engineInitFallbacksTried = new Set();
let engineReady = false;
let engineUciInitialized = false;
let engineFailed = false;
let boardResizeObserver = null;
let boardResizeRaf = 0;
let engineQueue = [];
let engineSearchActive = false;
let pendingEngineRequest = null;
let pendingHintRequest = null;
let apiMoveAbortController = null;
let mainEngineTimer = null;
let mainBotKickTimer = null;
let gameEpoch = 0;
let mainEngineSearchEpoch = -1;
let mainEngineSearchFen = '';
let queuedMainEngineMove = false;
let clockState = { enabled: false, running: false, remaining: { w: 0, b: 0 }, incrementMs: 0, lastTickAt: 0 };
// One pre-ply clock snapshot per real move makes undo/redo restore time rather than reinitialize it.
let moveClockSnapshots = [];
let redoStack = [];
let clockFlagged = null;
let clockInterval = null;
let analysisActive = false;
let analysisVisible = false;
let analysisFen = '';
let analysisEpoch = -1;
let analysisVariants = [];
let analysisTimeout = null;
let engineStopTimeout = null;
let engineStopPending = false;
let analysisLastPaintAt = 0;
let arenaGame = new Chess();
let legacyArenaEngine = null;
let arenaRunning = false;
let arenaStopRequested = false;
let arenaAbortController = null;
let arenaLastMove = null;
let arenaPgnHeaders = {};
let arenaLastPgnResult = '*';
let arenaPgnArchive = [];
let arenaLastResult = '';
let arenaCurrentPlayers = { w: null, b: null };
let arenaGameCounter = 0;
let gamesMode = 'rubik';
let ticTacToeBoard = Array(9).fill('');
let ticTacToeResult = '';
let ticTacToeThinking = false;
let arenaCupStandings = readSocialCache('vila.chess.arena-cup-standings.v1', []);
if (!Array.isArray(arenaCupStandings)) arenaCupStandings = [];
arenaCupStandings = arenaCupStandings.filter(item => item && typeof item.name === 'string').slice(0, 6);
let rubikCube = createSolvedRubikCube();
let rubikMoveHistory = [];
let rubikMoveCount = 0;
let rubikViewMode = 'turn';
let rubikRotationX = -22;
let rubikRotationY = -32;
let game2048Board = create2048Board();
let game2048Score = 0;
let game2048Best = 0;
let slidingPuzzleBoard = createScrambledSlidingPuzzle(100);
let slidingPuzzleMoves = 0;
let gamesKeyHandler = null;
let memoryDeck = [];
let memorySelected = [];
let memoryMatched = new Set();
let memoryMoves = 0;
let memoryLock = false;
let arenaLastNote = '';
let arenaEngineWarning = '';
let arenaTournamentSummary = '';
let arenaSelectedLeague = new Set(['stockfish', 'offline-rookie']);
let arenaFallbackMoves = new Map();
let activeOnlineGame = null;
let activeLichessUsername = safeSessionGet('tubor.chess.lichessUsername');
let activeLichessToken = safeSessionGet(lichessTokenKey);
let onlineStreamController = null;
let lastExplorerData = null;
let explorerRequestId = 0;
let toastTimer = null;

function loadSettings() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    const normalized = normalizeSettings(raw);
    // The whitelist migration removes legacy provider keys/endpoints/profiles from this record.
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    return normalized;
  } catch {
    return normalizeSettings(DEFAULTS);
  }
}
function saveSettings() {
  try {
    const normalized = normalizeSettings(settings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    settings = normalized;
    return true;
  } catch (error) {
    console.warn('[Cờ Vua ViLa] Settings could not be stored:', error);
    toast('Không lưu được cài đặt trên thiết bị này. Hãy kiểm tra dung lượng hoặc quyền lưu trữ.');
    return false;
  }
}
function loadVisualSettings() {
  try { return normalizeVisualSettings(JSON.parse(localStorage.getItem(VISUAL_SETTINGS_KEY) || '{}')); }
  catch { return { ...DEFAULT_VISUAL_SETTINGS }; }
}
function applyVisualSettings(next) {
  visualSettings = normalizeVisualSettings(next);
  if (typeof document !== 'undefined') {
    document.documentElement.dataset.boardMotion = visualSettings.smoothAnimations ? 'on' : 'off';
  }
  return visualSettings;
}
function saveVisualSettings(next) {
  const normalized = applyVisualSettings(next);
  try { localStorage.setItem(VISUAL_SETTINGS_KEY, JSON.stringify(normalized)); }
  catch { toast('Không lưu được tùy chọn giao diện; thiết lập chỉ có hiệu lực trong phiên này.'); }
  if (currentView === 'play') renderBoard();
  return normalized;
}
function apiUrl(path) {
  const base = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  return `${base}${path}`;
}
function isSafeHttpEndpoint(value) {
  try {
    const parsed = new URL(String(value || '').trim());
    return ['http:', 'https:'].includes(parsed.protocol) && Boolean(parsed.hostname) &&
      !parsed.username && !parsed.password && !parsed.search && !parsed.hash;
  } catch {
    return false;
  }
}
function safeLichessUrl(value, gameId) {
  const cleanId = String(gameId || '').trim();
  const fallback = cleanId ? `https://lichess.org/${encodeURIComponent(cleanId)}` : 'https://lichess.org/';
  try {
    const parsed = new URL(String(value || fallback));
    return parsed.protocol === 'https:' && parsed.hostname === 'lichess.org' && !parsed.username && !parsed.password && !parsed.port ? parsed.href : fallback;
  } catch {
    return fallback;
  }
}
async function apiFetch(path, options = {}) {
  // Bound ordinary API requests so a broken backend/network cannot leave chat,
  // settings or arena controls in a permanent loading state.
  const controller = new AbortController();
  const callerSignal = options.signal;
  let timedOut = false;
  const abortFromCaller = () => controller.abort();
  if (callerSignal?.aborted) controller.abort();
  else callerSignal?.addEventListener('abort', abortFromCaller, { once: true });
  const timeoutMs = Math.max(1000, Math.min(90_000, Number(options.timeoutMs) || 90_000));
  const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
  try {
    const { signal: _callerSignal, timeoutMs: _timeoutMs, ...fetchOptions } = options;
    let response;
    try {
      response = await fetch(apiUrl(path), {
        ...fetchOptions,
        signal: controller.signal,
        headers: {
          ...(options.headers || {}),
          ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}),
          ...(options.body && typeof options.body === 'string' ? { 'Content-Type': 'application/json' } : {})
        }
      });
    } catch (fetchError) {
      if (fetchError instanceof TypeError || /failed to fetch|networkerror|load failed|invalid url/i.test(String(fetchError?.message || ''))) {
        const target = String(settings.backendUrl || '').trim().replace(/\/$/, '') || ((location.protocol === 'http:' || location.protocol === 'https:') ? location.origin : 'chưa cấu hình');
        throw new Error(`Không kết nối được backend API tại ${target}. Kiểm tra server đang chạy, URL HTTPS, mã truy cập backend và CORS_ORIGIN. APK/GitHub Pages không tự chạy server Node.js; hãy triển khai backend rồi nhập URL vào Cài đặt.`);
      }
      throw fetchError;
    }
    const type = response.headers.get('content-type') || '';
    const raw = await response.text().catch(() => '');
    let data = raw;
    if (/application\/(?:[\w.+-]*\+)?json/i.test(type)) {
      try { data = raw ? JSON.parse(raw) : {}; } catch { data = { error: 'Backend trả JSON không hợp lệ.' }; }
    }
    const looksLikeHtml = /text\/html/i.test(type) || /^\s*(?:<!doctype html|<html[\s>])/i.test(raw);
    if (looksLikeHtml) {
      throw new Error('Địa chỉ Backend URL đang trả về trang web HTML, không phải API Cờ Vua ViLa. Hãy triển khai server Node.js của dự án và nhập URL HTTPS của server vào Cài đặt → máy chủ cộng đồng. GitHub Pages chỉ host giao diện tĩnh, không chạy được máy chủ Node.js.');
    }
    if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (timedOut) throw new Error(`Yêu cầu quá thời gian chờ ${Math.round(timeoutMs / 1000)} giây. Hãy kiểm tra mạng/model rồi thử lại.`);
    throw error;
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener('abort', abortFromCaller);
  }
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function makeMessageId() {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch { /* Some embedded WebViews restrict crypto APIs outside secure contexts. */ }
  return `message-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function toast(message, type = '') {
  const element = $('#toast');
  if (!element) return;
  element.textContent = message;
  element.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.className = 'toast'; }, 3300);
}
function setHintSuggestion(move, source = 'Stockfish') {
  if (!move) return;
  lastHintMove = { fen: game.fen(), from: move.from, to: move.to, promotion: move.promotion || null, san: move.san, source };
  renderHintArrow();
  toast(`Gợi ý: ${move.san} · ${move.from} → ${move.to}. Mũi tên đã đánh dấu trên bàn cờ.`);
}
function speakTextVietnamese(text) {
  const clean = String(text || '').trim();
  if (!clean) return;
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    toast('Thiết bị/WebView chưa hỗ trợ đọc chỉ dẫn bằng giọng nói.'); return;
  }
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = 'vi-VN'; utterance.rate = 0.94; utterance.pitch = 1;
    const voice = window.speechSynthesis.getVoices().find(item => /^vi(-|_)/i.test(item.lang));
    if (voice) utterance.voice = voice;
    utterance.onerror = () => toast('Không thể phát giọng đọc trên thiết bị này.');
    window.speechSynthesis.speak(utterance);
  } catch { toast('Không thể khởi chạy giọng đọc trên WebView này.'); }
}
function speakCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Hãy lấy gợi ý mới cho thế cờ hiện tại trước.'); return; }
  speakTextVietnamese(`Gợi ý ${lastHintMove.source}. Đi nước ${lastHintMove.san}. Di chuyển quân từ ô ${lastHintMove.from} đến ô ${lastHintMove.to}.`);
}
function applyCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Gợi ý đã cũ. Hãy tính lại ở thế cờ hiện tại.'); return; }
  if (arenaRunning || game.isGameOver() || botThinking || clockFlagged) { toast('Chưa thể áp dụng gợi ý trong trạng thái hiện tại.'); return; }
  if (mode !== 'local' && game.turn() !== humanColor) { toast('Chỉ áp dụng gợi ý khi đến lượt của bạn.'); return; }
  const move = game.moves({ verbose: true }).find(candidate => candidate.from === lastHintMove.from && candidate.to === lastHintMove.to && (candidate.promotion || null) === (lastHintMove.promotion || null));
  if (!move) { toast('Nước gợi ý không còn hợp lệ ở vị trí hiện tại.'); return; }
  playMove(move.from, move.to, move.promotion);
}
function clockPlayerName(color) {
  if (mode === 'lichess') return color === humanColor ? 'Bạn' : 'Đối thủ';
  if (mode === 'local') return color === 'w' ? 'Trắng' : 'Đen';
  return color === humanColor ? 'Bạn' : (mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : 'Stockfish');
}
function resetClock(preset = settings.clockPreset) {
  const parsed = parseClockPreset(preset);
  const enabled = parsed.enabled && mode !== 'lichess';
  clockFlagged = null;
  clockState = {
    enabled,
    running: enabled && gameStarted && !game.isGameOver() && !manualGameResult,
    remaining: { w: parsed.baseMs, b: parsed.baseMs },
    incrementMs: parsed.incrementMs,
    lastTickAt: typeof performance !== 'undefined' ? performance.now() : Date.now()
  };
  renderClockDisplay();
}
function captureMoveClockSnapshot() {
  return captureClockSnapshot(clockState, clockFlagged);
}
function restoreMoveClockSnapshot(snapshot) {
  if (!snapshot) return false;
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const restored = restoreClockSnapshot(snapshot, now);
  if (!restored) return false;
  clockFlagged = restored.clockFlagged;
  delete restored.clockFlagged;
  clockState = restored;
  // Do not revive a stopped clock after a terminal chess/result state.
  if (!gameStarted || game.isGameOver() || manualGameResult || clockFlagged) clockState.running = false;
  else if (clockState.enabled) clockState.running = Boolean(snapshot.running);
  clockState.lastTickAt = now;
  renderClockDisplay();
  return true;
}
function rebaseClockAfterUndoWithoutSnapshot() {
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  clockFlagged = null;
  clockState.running = Boolean(clockState.enabled && gameStarted && !game.isGameOver() && !manualGameResult);
  clockState.lastTickAt = now;
  renderClockDisplay();
}
function stopClock() {
  clockState.running = false;
  renderClockDisplay();
}
function renderClockDisplay() {
  const white = $('#clockWhite');
  const black = $('#clockBlack');
  if (!white || !black) return;
  for (const [color, element] of [['w', white], ['b', black]]) {
    const value = clockState.enabled ? formatClockTime(clockState.remaining[color], true) : (mode === 'lichess' ? 'Lichess' : '∞');
    element.textContent = value;
    element.classList.toggle('is-active', clockState.enabled && clockState.running && game.turn() === color && !clockFlagged);
    element.classList.toggle('is-flagged', clockFlagged === color);
    element.setAttribute('aria-label', `${clockPlayerName(color)}: ${value}`);
  }
  const whiteName = $('#clockWhiteName');
  const blackName = $('#clockBlackName');
  if (whiteName) whiteName.textContent = clockPlayerName('w');
  if (blackName) blackName.textContent = clockPlayerName('b');
  const hint = $('#clockHint');
  if (hint) hint.textContent = clockFlagged ? `${clockPlayerName(clockFlagged)} đã hết giờ` : clockState.enabled ? `Thời gian + ${Math.round(clockState.incrementMs / 1000)} giây cộng mỗi nước` : (mode === 'lichess' ? 'Đồng hồ do Lichess quản lý' : 'Đồng hồ không giới hạn');
}
let lastLowTimeSecond = -1;
function tickClock() {
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (arenaRunning) { clockState.lastTickAt = now; return; }
  if (!clockState.enabled || !clockState.running || clockFlagged || mode === 'lichess') return;
  // A restored or externally-ended game must never leave an active clock running.
  if (!gameStarted || game.isGameOver() || manualGameResult) {
    clockState.running = false;
    clockState.lastTickAt = now;
    renderClockDisplay();
    return;
  }
  const side = game.turn();
  const tick = consumeClockTick(clockState, side, now);
  if (!tick.valid) return;
  clockState.remaining[side] = tick.remainingMs;
  clockState.lastTickAt = now;
  if (tick.flagged) {
    clockFlagged = side;
    clockState.running = false;
    botThinking = false;
    premoveQueue = []; selected = null; selectedTargets = [];
    cancelScheduledBotMove();
    cancelPendingHint();
    stopAnalysis(true);
    cancelMainEngineSearch();
    if (currentView === 'play') renderView();
    playGameSound('flag', settings.soundEnabled);
    toast(`${clockPlayerName(side)} hết giờ. Ván cờ kết thúc.`, 'success');
    return;
  }
  if (side === humanColor && clockState.remaining[side] <= 10000 && mode !== 'local') {
    const second = Math.ceil(clockState.remaining[side] / 1000);
    if (second !== lastLowTimeSecond) { lastLowTimeSecond = second; playGameSound('lowtime', settings.soundEnabled); }
  } else lastLowTimeSecond = -1;
  renderClockDisplay();
}
function creditClockForMove(mover) {
  if (!clockState.enabled || clockFlagged) return;
  clockState.remaining[mover] += clockState.incrementMs;
  clockState.lastTickAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
  renderClockDisplay();
}
function requestEngineStop() {
  if (engineStopPending) return;
  // Do not wait for a terminal line when the previous search has already ended.
  if (!engineWorker || engineFailed || !engineSearchActive) { engineSearchActive = false; return; }
  // UCI does not tag `bestmove` with a request ID. Lock the shared worker until
  // the cancelled job emits its terminal line; all new searches stay queued.
  engineStopPending = true;
  engineSearchActive = true;
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 1');
  } catch {
    retireStockfishWorker('Không thể gửi lệnh dừng Stockfish an toàn.');
    return;
  }
  if (engineStopTimeout) clearTimeout(engineStopTimeout);
  engineStopTimeout = setTimeout(() => {
    if (!engineStopPending) return;
    const resumeBot = queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged;
    queuedMainEngineMove = false;
    engineStopTimeout = null;
    retireStockfishWorker('Stockfish không xác nhận dừng tác vụ đúng hạn.');
    if (resumeBot) scheduleBotMove(0);
  }, 2500);
}
function stopAnalysis(clearResults = true) {
  const wasActive = analysisActive;
  analysisActive = false;
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  if (wasActive) requestEngineStop();
  if (clearResults) analysisVisible = false;
  analysisFen = '';
  analysisEpoch = -1;
  if (clearResults) analysisVariants = [];
  renderAnalysisPanel();
}
function uciPvToSan(fen, pv) {
  const clone = new Chess(fen);
  const san = [];
  for (const uci of pv) {
    try {
      const move = clone.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!move) break;
      san.push(move.san);
    } catch { break; }
  }
  return san;
}
function renderAnalysisPanel() {
  const panel = $('#analysisPanel');
  const lines = $('#analysisLines');
  const button = $('#analyzePosition');
  if (!panel || !lines) return;
  panel.hidden = !(analysisVisible || analysisActive || analysisVariants.length);
  if (button) {
    button.disabled = engineStopPending;
    button.textContent = analysisActive ? '■ Dừng phân tích' : engineStopPending ? 'Đang dừng…' : '♙ Phân tích 3 biến';
    button.setAttribute('aria-busy', String(analysisActive || engineStopPending));
  }
  if (!analysisVariants.length) {
    const emptyText = analysisActive
      ? 'Stockfish đang phân tích nhiều phương án…'
      : engineStopPending
        ? 'Đang yêu cầu Stockfish kết thúc lượt phân tích an toàn…'
        : analysisVisible
          ? 'Chưa nhận được biến thể hợp lệ từ Stockfish. Kiểm tra trạng thái engine rồi thử phân tích lại.'
          : 'Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.';
    lines.innerHTML = `<div class="analysis-empty">${emptyText}</div>`;
    renderHintArrow();
    return;
  }
  const expectedFen = analysisVariants[0]?.fen || game.fen();
  lines.innerHTML = analysisVariants.sort((a, b) => a.multipv - b.multipv).map(variation => {
    const san = uciPvToSan(expectedFen, variation.pv).slice(0, 8).join(' ');
    return `<div class="analysis-line"><b>${variation.multipv}</b><strong>${esc(formatUciScore(variation))}</strong><span>Độ sâu ${variation.depth}</span><small>${esc(san || 'Đang tìm biến…')}</small></div>`;
  }).join('');
  renderHintArrow();
}
function receiveAnalysisInfo(line) {
  if (!analysisActive) return;
  if (!isCurrentAnalysisSession({ active: analysisActive, sessionFen: analysisFen, currentFen: game.fen(), sessionEpoch: analysisEpoch, currentEpoch: gameEpoch })) {
    stopAnalysis(true);
    return;
  }
  const parsed = parseUciInfoLine(line);
  if (!parsed) return;
  analysisVariants = mergeAnalysisVariation(analysisVariants, parsed, analysisFen);
  const now = Date.now();
  if (now - analysisLastPaintAt >= 180) {
    analysisLastPaintAt = now;
    renderAnalysisPanel();
  }
}
/** Always give training analysis the engine's full available strength, independent of the bot Elo chosen for the current game. */
function configureStockfishForAnalysis(multiPv = 1) {
  if (!engineWorker || engineFailed) return false;
  const lanes = Math.max(1, Math.min(5, Math.round(Number(multiPv) || 1)));
  engineWorker.postMessage('setoption name UCI_LimitStrength value false');
  engineWorker.postMessage('setoption name Skill Level value 20');
  engineWorker.postMessage(`setoption name MultiPV value ${lanes}`);
  return true;
}

function toggleAnalysis() {
  if (!gameStarted) { toast('Bắt đầu ván trước khi phân tích.'); return; }
  if (analysisActive) { stopAnalysis(false); toast('Đã dừng phân tích.'); return; }
  if (engineStopPending) { toast('Stockfish đang kết thúc lượt phân tích trước; thử lại sau giây lát.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi phân tích bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged) { toast('Ván cờ đã kết thúc; hãy bắt đầu ván mới để phân tích tiếp.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng. Kiểm tra engine rồi thử lại.'); return; }
  if (botThinking || engineSearchActive || pendingEngineRequest || pendingHintRequest) { toast('Đợi Stockfish hoàn tất nước đi hoặc gợi ý trước khi phân tích.'); return; }
  analysisActive = true;
  analysisVisible = true;
  analysisFen = game.fen();
  analysisEpoch = gameEpoch;
  analysisVariants = [];
  analysisLastPaintAt = 0;
  engineSearchActive = true;
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  renderAnalysisPanel();
  try {
    configureStockfishForAnalysis(3);
    engineWorker.postMessage(`position fen ${analysisFen}`);
    const budget = Math.max(1000, Math.min(8000, Number(settings.analysisMoveTimeMs) || 2600));
    engineWorker.postMessage(`go movetime ${budget}`);
    analysisTimeout = setTimeout(() => {
      if (!analysisActive) return;
      stopAnalysis(false);
      retireStockfishWorker('Stockfish không hoàn tất phân tích đúng hạn.');
      reviewStatus = 'Đã dừng phân tích vì Stockfish quá thời gian.';
      updateReviewPanel();
      toast('Stockfish quá thời gian phân tích; chạm trạng thái engine ở đầu trang để thử tải lại.');
    }, budget + 3500);
  } catch (error) {
    stopAnalysis(true);
    toast(`Không thể khởi chạy phân tích: ${error.message || error}`);
  }
}
function analyzeLocallyForCoach() {
  return new Promise((resolve, reject) => {
    if (!engineWorker || !engineReady || engineFailed) return reject(new Error('Stockfish chưa sẵn sàng. Hãy chờ trạng thái engine sẵn sàng rồi thử lại.'));
    if (botThinking || engineStopPending || engineSearchActive || pendingEngineRequest || pendingHintRequest || analysisActive || pendingCoachAnalysis) {
      return reject(new Error('Engine đang bận. Đợi nước đi hoặc phân tích hiện tại kết thúc rồi thử lại.'));
    }
    const request = { fen: game.fen(), epoch: gameEpoch, variants: new Map(), resolve, reject, timeout: null };
    pendingCoachAnalysis = request;
    engineSearchActive = true;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    const budget = Math.max(1200, Math.min(5000, Number(settings.analysisMoveTimeMs) || 2600));
    request.timeout = setTimeout(() => {
      if (pendingCoachAnalysis !== request) return;
      pendingCoachAnalysis = null;
      engineSearchActive = false;
      retireStockfishWorker('Stockfish quá thời gian phân tích.');
      reject(new Error('Stockfish quá thời gian phân tích. Engine đã dừng để bỏ qua kết quả cũ; hãy chạm trạng thái engine để thử lại.'));
    }, budget + 3000);
    try {
      configureStockfishForAnalysis(3);
      engineWorker.postMessage(`position fen ${request.fen}`);
      engineWorker.postMessage(`go movetime ${budget}`);
    } catch (error) {
      clearTimeout(request.timeout); pendingCoachAnalysis = null; engineSearchActive = false;
      try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
      reject(error);
    }
  });
}
function receiveCoachAnalysisInfo(line) {
  const request = pendingCoachAnalysis;
  if (!request || request.epoch !== gameEpoch || request.fen !== game.fen()) return;
  const parsed = parseUciInfoLine(line);
  if (!parsed || !parsed.pv?.length) return;
  const old = request.variants.get(parsed.multipv);
  if (!old || parsed.depth >= old.depth) request.variants.set(parsed.multipv, { ...parsed, fen: request.fen });
}
function ensureClockTicker() {
  if (clockInterval) return;
  clockInterval = setInterval(tickClock, 100);
}
function preferredHashMb() {
  const memory = Number(navigator?.deviceMemory || 0);
  // Unknown WebView memory should take the safer allocation on low-RAM phones.
  return memory >= 4 ? 32 : 16;
}
function cancelScheduledBotMove() {
  if (mainBotKickTimer) {
    clearTimeout(mainBotKickTimer);
    mainBotKickTimer = null;
  }
}
function cancelApiMoveRequest() {
  if (!apiMoveAbortController) return;
  const controller = apiMoveAbortController;
  apiMoveAbortController = null;
  try { controller.abort(); } catch {}
}
function cancelMainEngineWatchdog() {
  if (mainEngineTimer) {
    clearTimeout(mainEngineTimer);
    mainEngineTimer = null;
  }
}
function scheduleBotMove(delay = 220) {
  cancelScheduledBotMove();
  const expectedEpoch = gameEpoch;
  const expectedFen = game.fen();
  const expectedMode = mode;
  mainBotKickTimer = setTimeout(() => {
    mainBotKickTimer = null;
    if (expectedEpoch !== gameEpoch || expectedFen !== game.fen() || expectedMode !== mode ||
        !botThinking || game.isGameOver() || game.turn() === humanColor) return;
    if (expectedMode === 'stockfish') askStockfishMove();
    else if (expectedMode === 'vila') askVilaMove();
    else if (expectedMode === 'enginehub') void askEngineHubMove();
  }, Math.max(0, Math.min(5000, Number(delay) || 0)));
}
function cancelPendingHint() {
  if (!pendingHintRequest) return false;
  clearTimeout(pendingHintRequest.timeout);
  pendingHintRequest = null;
  if (engineSearchActive && !pendingEngineRequest) requestEngineStop();
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  return true;
}
function cancelMainEngineSearch() {
  cancelMainEngineWatchdog();
  // A new game may start while the current worker is cancelling; keep it locked
  // until the terminal line arrives, then resume only a still-current bot turn.
  if (engineStopPending) {
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    queuedMainEngineMove = false;
    engineSearchActive = true;
    return;
  }
  if (engineSearchActive && !pendingEngineRequest) requestEngineStop();
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
}
document.addEventListener('visibilitychange', () => { if (document.hidden) pausePuzzleRushTimer(); else if (currentView === 'puzzles') resumePuzzleRushTimer(); });

function setView(view) {
  const previousView = currentView;
  if (currentView === 'puzzles' && view !== 'puzzles') pausePuzzleRushTimer();
  closeResultModal();
  if (currentView === 'ranked' && view !== 'ranked') void quitRankedMatch(true);
  if (view === 'openings') recordDailyEvent('visit_openings');
  if (view === 'coach') recordDailyEvent('visit_coach');
  if (view === 'history') recordDailyEvent('open_history');
  if (view === 'puzzles') recordDailyEvent('visit_puzzles');
  if (view === 'arena') recordDailyEvent('visit_arena');
  if (view === 'games') recordDailyEvent('visit_games');
  currentView = view;
  $$('.tab').forEach(tab => {
    const active = tab.dataset.view === view;
    tab.classList.toggle('active', active);
    if (active) tab.setAttribute('aria-current', 'page');
    else tab.removeAttribute('aria-current');
  });
  $('#mainMenu')?.classList.remove('menu-open');
  $('#openMenu')?.setAttribute('aria-expanded', 'false');
  $('#bottomMore')?.setAttribute('aria-expanded', 'false');
  renderView();
  // A sticky header can cover the top card when the previous screen was scrolled.
  // Navigation should always show the new view from its true top on mobile WebView.
  if (view !== previousView) window.scrollTo(0, 0);
  if (view === 'puzzles') resumePuzzleRushTimer();
}

// ---- Engine speed chip: depth, nodes/second and search time for the engine that just moved ----
let engineSpeed = null;
let engineSpeedInfoAt = 0;
function formatNps(nps) {
  const value = Number(nps) || 0;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(value >= 1e5 ? 0 : 1)}k`;
  return String(Math.round(value));
}
function engineSpeedText() {
  if (!engineSpeed) return '⚡ Tốc độ engine: chờ nước đầu tiên';
  const parts = [`⚡ ${engineSpeed.name}`];
  if (engineSpeed.depth) parts.push(`d${engineSpeed.depth}`);
  if (engineSpeed.nps) parts.push(`${formatNps(engineSpeed.nps)} nút/giây`);
  if (engineSpeed.ms) parts.push(`${(engineSpeed.ms / 1000).toFixed(engineSpeed.ms >= 10000 ? 0 : 1)}s`);
  return parts.join(' · ');
}
function updateEngineSpeedChip() {
  const text = engineSpeedText();
  document.querySelectorAll('[data-engine-speed]').forEach(node => { if (node.textContent !== text) node.textContent = text; });
}
function recordEngineSpeed(name, stats) {
  if (!stats) return;
  engineSpeed = {
    name,
    depth: Number(stats.depth) || 0,
    nps: Number(stats.nps) || (stats.nodes && stats.elapsedMs ? Math.round(stats.nodes * 1000 / stats.elapsedMs) : 0),
    ms: Number(stats.elapsedMs) || 0
  };
  updateEngineSpeedChip();
}
function recordStockfishSpeed(line) {
  // Throttled: Stockfish can print dozens of info lines per second.
  const now = Date.now();
  if (now - engineSpeedInfoAt < 250) return;
  const depth = Number(line.match(/\bdepth (\d+)/)?.[1]);
  const nps = Number(line.match(/\bnps (\d+)/)?.[1]);
  const time = Number(line.match(/\btime (\d+)/)?.[1]);
  if (!depth && !nps) return;
  engineSpeedInfoAt = now;
  engineSpeed = { name: 'Stockfish', depth: depth || engineSpeed?.depth || 0, nps: nps || engineSpeed?.nps || 0, ms: time || engineSpeed?.ms || 0 };
  updateEngineSpeedChip();
}
function engineSpeedChipMarkup() {
  return `<span class="engine-speed-chip" data-engine-speed aria-live="off">${esc(engineSpeedText())}</span>`;
}

function pieceGlyph(piece) {
  // VILA "Royal" set (src/pieces.js): one renderer shared by every board, drag ghost and dialog.
  return pieceSvgMarkup(piece);
}
function squareColor(square) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 1 ? 'dark' : 'light';
}
function syncBoardLayout() {
  const board = $('#board');
  const frame = board?.closest('.board-frame');
  const column = board?.closest('.board-column');
  if (!board || !frame || !column) return;

  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: column.getBoundingClientRect().width,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';

  // Derive piece scale from the actual inner board width rather than vw/DPI
  // heuristics; this survives Android WebView inset and split-screen changes.
  const boardWidth = board.getBoundingClientRect().width;
  const squareSize = calculateChessSquareSize(boardWidth);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function syncArenaBoardLayout() {
  const board = $('#arenaBoard');
  const frame = board?.closest('.arena-board-frame');
  const container = frame?.parentElement;
  if (!board || !frame || !container) return;
  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: container.clientWidth,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';
  const squareSize = calculateChessSquareSize(board.getBoundingClientRect().width);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function scheduleBoardLayoutSync() {
  if (boardResizeRaf) cancelAnimationFrame(boardResizeRaf);
  boardResizeRaf = requestAnimationFrame(() => { boardResizeRaf = 0; syncBoardLayout(); syncArenaBoardLayout(); });
}
function watchBoardLayout() {
  boardResizeObserver?.disconnect();
  boardResizeObserver = null;
  const column = $('.board-column');
  if (column && typeof ResizeObserver !== 'undefined') {
    boardResizeObserver = new ResizeObserver(scheduleBoardLayoutSync);
    boardResizeObserver.observe(column);
  }
  scheduleBoardLayoutSync();
}

function squareToOverlayPoint(square) {
  if (!/^[a-h][1-8]$/.test(String(square || ''))) return null;
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const x = files.indexOf(square[0]); const y = ranks.indexOf(Number(square[1]));
  return x < 0 || y < 0 ? null : { x: x + .5, y: y + .5 };
}
// Chess.com-style arrows: thin shaft, wide triangular head, knight moves drawn as an L,
// one translucent layer per arrow so overlaps never double the opacity.
function arrowMarkup(fromSquare, toSquare, cls) {
  const a = squareToOverlayPoint(fromSquare);
  const b = squareToOverlayPoint(toSquare);
  if (!a || !b || fromSquare === toSquare) return '';
  const adx = Math.abs(b.x - a.x), ady = Math.abs(b.y - a.y);
  const knight = (Math.round(adx) === 1 && Math.round(ady) === 2) || (Math.round(adx) === 2 && Math.round(ady) === 1);
  const waypoints = knight
    ? [a, Math.round(adx) === 2 ? { x: b.x, y: a.y } : { x: a.x, y: b.y }, b]
    : [a, b];
  const headLength = .38, headWidth = .44, startGap = .1, tipGap = .05;
  const last = waypoints[waypoints.length - 1], prev = waypoints[waypoints.length - 2];
  const len = Math.hypot(last.x - prev.x, last.y - prev.y) || 1;
  const ux = (last.x - prev.x) / len, uy = (last.y - prev.y) / len;
  const tip = { x: last.x - ux * tipGap, y: last.y - uy * tipGap };
  const base = { x: tip.x - ux * headLength, y: tip.y - uy * headLength };
  const nx = -uy, ny = ux;
  const first = waypoints[0], second = waypoints[1];
  const firstLen = Math.hypot(second.x - first.x, second.y - first.y) || 1;
  const start = { x: first.x + (second.x - first.x) / firstLen * startGap, y: first.y + (second.y - first.y) / firstLen * startGap };
  const path = [start, ...waypoints.slice(1, -1), base].map(point => `${point.x.toFixed(3)},${point.y.toFixed(3)}`).join(' ');
  const head = [
    tip,
    { x: base.x + nx * headWidth / 2, y: base.y + ny * headWidth / 2 },
    { x: base.x - nx * headWidth / 2, y: base.y - ny * headWidth / 2 }
  ].map(point => `${point.x.toFixed(3)},${point.y.toFixed(3)}`).join(' ');
  return `<g class="${cls}"><polyline class="arrow-shaft" points="${path}"/><polygon class="arrow-head" points="${head}"/></g>`;
}
function renderHintArrow() {
  const svg = $('#boardArrows');
  const hintGroup = $('#hintArrowLine');
  const manualGroup = $('#manualAnnotationLines');
  if (!svg || !hintGroup || !manualGroup) return;
  let hintHtml = '';
  if (lastHintMove && lastHintMove.fen === game.fen()) {
    hintHtml = arrowMarkup(lastHintMove.from, lastHintMove.to, 'board-arrow hint-arrow-line');
  } else if (analysisVariants.length && analysisVariants[0]?.fen === game.fen()) {
    // Show up to three engine lines; the best one is the strongest arrow.
    hintHtml = [...analysisVariants].sort((x, y) => x.multipv - y.multipv).slice(0, 3).map((variant, index) => {
      const uci = variant?.pv?.[0];
      if (variant.fen !== game.fen() || !uci || !/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) return '';
      return arrowMarkup(uci.slice(0, 2), uci.slice(2, 4), `board-arrow hint-arrow-line analysis-arrow analysis-arrow-${index + 1}`);
    }).join('');
  }
  const markFor = (mark, extra = '') => {
    const from = squareToOverlayPoint(mark.from);
    const to = squareToOverlayPoint(mark.to || mark.from);
    if (!from || !to) return '';
    const cls = `manual-${mark.type} manual-${mark.type}-${mark.color || 'green'}${extra}`;
    if (mark.type === 'square') return `<rect class="manual-square manual-square-${mark.color || 'green'}" x="${(to.x - .5).toFixed(3)}" y="${(to.y - .5).toFixed(3)}" width="1" height="1"/>`;
    if (mark.type === 'circle' || mark.from === mark.to) return `<circle class="${cls}" cx="${to.x}" cy="${to.y}" r=".45"/>`;
    return arrowMarkup(mark.from, mark.to, `board-arrow ${cls}`);
  };
  const items = [...boardAnnotations.slice(-48)].sort((x, y) => (y.type === 'square') - (x.type === 'square')).map(mark => markFor(mark)).join('');
  const preview = annotationPreview ? markFor({ type: annotationPreview.from === annotationPreview.to ? (annotationPointer?.rightButton ? 'square' : 'circle') : 'arrow', ...annotationPreview }, ' is-preview') : '';
  hintGroup.innerHTML = hintHtml;
  manualGroup.innerHTML = items + preview;
  svg.hidden = !hintHtml && boardAnnotations.length === 0 && !preview;
}
function toggleBoardAnnotation(mark) {
  // Same arrow/circle again removes it (as on Chess.com); a different colour replaces it.
  const index = boardAnnotations.findIndex(item => item.type === mark.type && item.from === mark.from && item.to === mark.to);
  if (index >= 0) {
    const same = boardAnnotations[index].color === mark.color;
    boardAnnotations.splice(index, 1);
    if (same) return;
  }
  boardAnnotations.push(mark);
}
function annotationColorFromEvent(event) {
  if (event.shiftKey) return 'red';
  if (event.ctrlKey || event.metaKey) return 'yellow';
  if (event.altKey) return 'blue';
  return annotationColor;
}
function scheduleAnnotationPreview() {
  if (annotationPreviewRaf) return;
  annotationPreviewRaf = requestAnimationFrame(() => { annotationPreviewRaf = 0; renderHintArrow(); });
}
function canAnnotateBoard() {
  return Boolean(['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && !arenaRunning); // analysis marks stay available before, during and after a game
}
function syncAnnotationWidget() {
  const widget = $('#boardAnnotationWidget');
  if (!widget) return;
  const allowed = canAnnotateBoard();
  widget.hidden = !allowed;
  const toolbarRow = widget.closest('.board-annotation-toolbar-row');
  if (toolbarRow) toolbarRow.hidden = !allowed;
  widget.classList.toggle('is-collapsed', annotationCollapsed);
  const tools = $('#boardAnnotationTools');
  if (tools) tools.hidden = annotationCollapsed;
  const toggle = $('#annotationWidgetToggle');
  if (toggle) {
    toggle.setAttribute('aria-expanded', String(!annotationCollapsed));
    toggle.setAttribute('aria-label', annotationCollapsed ? 'Mở công cụ vẽ phân tích' : 'Thu gọn công cụ vẽ phân tích');
  }
  const colorButton = $('#annotationColorCycle', widget);
  if (colorButton) {
    colorButton.classList.remove('color-green', 'color-red', 'color-yellow', 'color-blue');
    colorButton.classList.add(`color-${annotationColor}`);
    const labels = { green: 'xanh lá', red: 'đỏ', yellow: 'vàng', blue: 'xanh dương' };
    colorButton.setAttribute('aria-label', `Màu nét: ${labels[annotationColor] || labels.green}`);
    colorButton.title = `Đổi màu nét (hiện tại: ${labels[annotationColor] || labels.green})`;
  }
  $$('[data-annotation-tool]', widget).forEach(button => {
    const active = button.dataset.annotationTool === annotationTool;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}
function squareAtBoardPoint(clientX, clientY, rect) {
  if (!rect?.width || !rect?.height || clientX < rect.left || clientY < rect.top || clientX >= rect.right || clientY >= rect.bottom) return '';
  const col = Math.max(0, Math.min(7, Math.floor((clientX - rect.left) / rect.width * 8)));
  const row = Math.max(0, Math.min(7, Math.floor((clientY - rect.top) / rect.height * 8)));
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  return `${files[col]}${ranks[row]}`;
}
function finishAnnotationPointer(event, board, cancelled = false) {
  const state = annotationPointer;
  if (!state || state.pointerId !== event.pointerId) return false;
  annotationPointer = null;
  annotationPreview = null;
  if (!cancelled && canAnnotateBoard() && state.epoch === gameEpoch && state.fen === game.fen()) {
    const to = squareAtBoardPoint(event.clientX, event.clientY, state.rect) || state.from;
    const color = state.color || annotationColor;
    // Right-button drags work like Chess.com: drag = arrow, click one square = circle.
    const tool = state.rightButton ? (to === state.from ? 'square' : 'arrow') : annotationTool;
    if (tool === 'arrow' && to !== state.from) toggleBoardAnnotation({ type: 'arrow', color, from: state.from, to });
    else if (tool === 'circle') toggleBoardAnnotation({ type: 'circle', color, from: to, to });
    else if (tool === 'square') toggleBoardAnnotation({ type: 'square', color, from: state.from, to: state.from });
    boardAnnotations = boardAnnotations.slice(-48);
  }
  try { board.releasePointerCapture(event.pointerId); } catch {}
  event.preventDefault?.();
  renderHintArrow();
  return true;
}
function wireAnnotationWidget() {
  const widget = $('#boardAnnotationWidget');
  if (!widget || widget.dataset.wired === 'true') return;
  widget.dataset.wired = 'true';
  syncAnnotationWidget();
  $('#annotationWidgetToggle', widget)?.addEventListener('click', () => {
    annotationCollapsed = !annotationCollapsed;
    syncAnnotationWidget();
  });
  $$('[data-annotation-tool]', widget).forEach(button => button.addEventListener('click', () => {
    const requested = button.dataset.annotationTool;
    annotationTool = annotationTool === requested ? null : requested;
    syncAnnotationWidget();
    toast(annotationTool ? (annotationTool === 'arrow' ? 'Kéo từ ô xuất phát đến ô đích để vẽ mũi tên. Chạm biểu tượng lần nữa để chơi quân.' : 'Chạm hoặc kéo tới ô cần khoanh. Chạm biểu tượng lần nữa để chơi quân.') : 'Đã tắt chế độ vẽ; bàn cờ nhận nước đi như bình thường.');
  }));
  $('#annotationClear', widget)?.addEventListener('click', () => {
    boardAnnotations = [];
    annotationTool = null;
    renderHintArrow();
    syncAnnotationWidget();
  });
  $('#annotationColorCycle', widget)?.addEventListener('click', () => {
    annotationColor = ANNOTATION_COLORS[(ANNOTATION_COLORS.indexOf(annotationColor) + 1) % ANNOTATION_COLORS.length];
    syncAnnotationWidget();
  });
  // Fixed in-flow toolbar: prevents stale drag coordinates from stretching or shifting it on phones.
}
function canStartBoardDrag(piece) {
  if (!gameStarted || manualGameResult || !piece || arenaRunning || game.isGameOver() || clockFlagged) return false;
  if (isPremoveWindow()) return piece.color === humanColor;
  return Boolean(!botThinking && (mode === 'local' ? piece.color === game.turn() : game.turn() === humanColor && piece.color === humanColor) && piece.color === game.turn());
}
function clearDragGhost() {
  for (const cell of boardSquareMap.values()) cell.classList.remove('drag-over');
  if (dragMoveFrame) cancelAnimationFrame(dragMoveFrame);
  dragMoveFrame = 0;
  dragLatestPoint = null;
  dragGhost?.remove(); dragGhost = null;
  document.body.classList.remove('board-dragging');
}
function updateDragSelection(board, from, legal) {
  selected = from;
  selectedTargets = legal;
  const targetsBySquare = new Map();
  const nextHighlightedSquares = new Set();
  if (from) nextHighlightedSquares.add(from);
  for (const move of legal) {
    if (!targetsBySquare.has(move.to)) targetsBySquare.set(move.to, []);
    targetsBySquare.get(move.to).push(move);
    if (visualSettings.showLegalMoves) nextHighlightedSquares.add(move.to);
  }
  // Do not query and mutate all 64 squares on every tap. Only touch cells which
  // were previously highlighted or are highlighted in the new selection.
  const affectedSquares = new Set([...boardHighlightedSquares, ...nextHighlightedSquares]);
  for (const squareName of affectedSquares) {
    const cell = boardSquareMap.get(squareName);
    if (!cell) continue;
    const targetMoves = targetsBySquare.get(squareName) || [];
    const occupied = Boolean(game.get(squareName));
    cell.classList.toggle('selected', squareName === from);
    const showTargets = visualSettings.showLegalMoves && targetMoves.length > 0;
    cell.classList.toggle('legal-target', showTargets && !occupied);
    cell.classList.toggle('capture-target', showTargets && occupied);
    const dot = cell.querySelector('.move-dot');
    if (showTargets && !occupied && !dot) cell.insertAdjacentHTML('beforeend', '<span class="move-dot"></span>');
    else if ((!showTargets || occupied) && dot) dot.remove();
  }
  boardHighlightedSquares = nextHighlightedSquares;
}
function wireBoardSquareClicks(board) {
  if (!board || board.dataset.clickWired === 'true') return;
  board.dataset.clickWired = 'true';
  // One delegated listener survives board redraws; do not allocate 64 listeners after every move.
  board.addEventListener('click', event => {
    if (annotationTool && canAnnotateBoard()) { event.preventDefault(); return; }
    const square = event.target?.closest?.('.square[data-square]');
    if (!square || !board.contains(square)) return;
    const suppress = suppressSquareClick;
    if (suppress && Date.now() <= suppress.until && square.dataset.square === suppress.square) {
      suppressSquareClick = null; event.preventDefault(); return;
    }
    if (suppress && Date.now() > suppress.until) suppressSquareClick = null;
    handleSquareClick(square.dataset.square);
  });
}
function wireBoardPointerDrag(board) {
  if (!board || board.dataset.dragWired === 'true') return;
  board.dataset.dragWired = 'true';
  board.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button === 2 && premoveQueue.length && isPremoveWindow()) {
      // Like chess.com: a right click cancels every queued premove.
      clearPendingPremove({ repaint: true, silent: false });
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const rightDraw = event.pointerType === 'mouse' && event.button === 2 && canAnnotateBoard();
    if ((annotationTool && canAnnotateBoard()) || rightDraw) {
      const square = event.target?.closest?.('.square[data-square]');
      if (!square || !board.contains(square)) return;
      const rect = board.getBoundingClientRect();
      annotationPointer = { pointerId: event.pointerId, from: square.dataset.square, rect, epoch: gameEpoch, fen: game.fen(), rightButton: rightDraw, color: rightDraw ? annotationColorFromEvent(event) : annotationColor };
      try { board.setPointerCapture(event.pointerId); } catch {}
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (event.pointerType === 'mouse' && boardAnnotations.length && !annotationTool) { boardAnnotations = []; renderHintArrow(); }
    const square = event.target?.closest?.('.square[data-square]');
    if (!square || !board.contains(square)) return;
    const from = square.dataset.square;
    const piece = boardPositionForInput().get(from);
    if (!canStartBoardDrag(piece)) return;
    const isPremove = isPremoveWindow();
    const surface = board.closest('.board-surface') || board;
    const rect = surface.getBoundingClientRect();
    dragState = {
      from, pointerId: event.pointerId, x: event.clientX, y: event.clientY,
      epoch: gameEpoch, fen: game.fen(), moved: false, legal: null, piece, isPremove, sourcePiece: square.querySelector('.piece'),
      surface, rect: { left: rect.left, top: rect.top },
      boardRect: board.getBoundingClientRect(), hoverSquare: ''
    };
    // Pointer capture preserves drop/up events when the finger briefly leaves the board.
    // Legal moves are still deferred until drag intent is confirmed.
    try { board.setPointerCapture(event.pointerId); } catch {}
  }, { passive: false });

  board.addEventListener('pointermove', event => {
    if (annotationPointer && annotationPointer.pointerId === event.pointerId) {
      event.preventDefault();
      const target = squareAtBoardPoint(event.clientX, event.clientY, annotationPointer.rect);
      if (target && (annotationTool === 'arrow' || annotationPointer.rightButton || annotationTool === 'circle')) {
        const next = { color: annotationPointer.color || annotationColor, from: annotationPointer.from, to: target };
        if (!annotationPreview || annotationPreview.to !== next.to) { annotationPreview = next; scheduleAnnotationPreview(); }
      }
      return;
    }
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (!state.moved && Math.hypot(event.clientX - state.x, event.clientY - state.y) < 4) return;
    if (!state.moved) {
      // Generate legal targets only after crossing the drag threshold, not on every tap.
      state.legal = state.isPremove ? getPremoveLegalMoves(game, humanColor, Chess, state.from, premoveQueue) : game.moves({ square: state.from, verbose: true });
      if (!state.legal.length) return;
      state.moved = true;
      try { board.setPointerCapture(event.pointerId); } catch {}
      event.preventDefault?.();
      updateDragSelection(board, state.from, state.legal);
      if (state.piece) {
        dragGhost = document.createElement('span');
        dragGhost.className = `drag-ghost piece ${state.piece.color === 'w' ? 'white-piece' : 'black-piece'}`;
        dragGhost.innerHTML = pieceGlyph(state.piece);
        // One square wide, measured once at pointer-down, so the piece never changes size mid-drag.
        dragGhost.style.setProperty('--drag-size', `${(state.boardRect.width / 8).toFixed(2)}px`);
        // Place it under the finger before the first paint to avoid a one-frame jump from the corner.
        dragGhost.style.transform = `translate3d(${event.clientX - state.rect.left}px, ${event.clientY - state.rect.top}px, 0) translate(-50%, -62%) scale(1.08)`;
        state.surface.appendChild(dragGhost);
        document.body.classList.add('board-dragging');
      }
      if (state.sourcePiece) state.sourcePiece.style.opacity = '.22';
    }
    // Pointer events can fire faster than the display refresh. Coalesce DOM writes to one RAF
    // and use a cached board rectangle, avoiding a forced layout read on every touch event.
    if (!state.moved) return;
    event.preventDefault?.();
    dragLatestPoint = { x: event.clientX, y: event.clientY };
    if (!dragMoveFrame) dragMoveFrame = requestAnimationFrame(() => {
      dragMoveFrame = 0;
      const current = dragState;
      const point = dragLatestPoint;
      if (!current || !current.moved || !dragGhost || !point) return;
      // On touch screens lift the piece a little above the fingertip so it stays visible.
      dragGhost.style.transform = `translate3d(${point.x - current.rect.left}px, ${point.y - current.rect.top}px, 0) translate(-50%, -62%) scale(1.08)`;
      const hover = squareAtBoardPoint(point.x, point.y, current.boardRect);
      if (hover !== current.hoverSquare) {
        boardSquareMap.get(current.hoverSquare)?.classList.remove('drag-over');
        current.hoverSquare = hover;
        if (hover && current.legal.some(move => move.to === hover)) boardSquareMap.get(hover)?.classList.add('drag-over');
      }
    });
  }, { passive: false });

  const finish = async event => {
    if (finishAnnotationPointer(event, board)) return;
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    dragState = null;
    if (state.sourcePiece) state.sourcePiece.style.opacity = '';
    clearDragGhost();
    if (!state.moved) {
      // Pointer capture on Android WebView may retarget the following click to the board itself.
      // Handle taps explicitly, then suppress the synthetic click to prevent double moves.
      suppressSquareClick = { square: state.from, until: Date.now() + 160 };
      handleSquareClick(state.from);
      return;
    }
    event.preventDefault?.();
    // Resolve the drop from the cached board rectangle. elementFromPoint() can
    // return the drag ghost / overlay in Android WebView and adds another DOM hit-test.
    const to = squareAtBoardPoint(event.clientX, event.clientY, state.boardRect);
    // Suppress only a synthetic click for this exact drop square; never block the next real tap.
    suppressSquareClick = { square: to || state.from, until: Date.now() + 160 };
    const choices = to ? state.legal.filter(move => move.to === to) : [];
    if (!choices.length) { updateDragSelection(board, state.from, state.legal); return; }
    let promotion = choices.find(move => move.promotion === 'q')?.promotion || choices.find(move => move.promotion)?.promotion || null;
    if (choices.some(move => move.promotion)) promotion = visualSettings.autoQueen ? 'q' : await choosePromotion(state.isPremove ? humanColor : game.turn());
    if (choices.some(move => move.promotion) && !promotion) { updateDragSelection(board, state.from, state.legal); return; }
    // A promotion chooser can stay open while the player starts a new game or the position changes.
    // Do not apply a drag originating from a stale board state.
    if (state.epoch !== gameEpoch || state.fen !== game.fen()) return;
    if (state.isPremove) queuePremove(state.from, to, promotion);
    else if (promotion || !choices.some(move => move.promotion)) playMove(state.from, to, promotion, { slide: false });
  };
  board.addEventListener('contextmenu', event => { if (canAnnotateBoard()) event.preventDefault(); });
  board.addEventListener('pointerup', finish, { passive: false });
  const cancelDrag = event => {
    if (finishAnnotationPointer(event, board, true)) return;
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (state.sourcePiece) state.sourcePiece.style.opacity = '';
    dragState = null; clearDragGhost();
    if (boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets); else renderBoard();
  };
  board.addEventListener('pointercancel', cancelDrag, { passive: true });
  board.addEventListener('lostpointercapture', cancelDrag, { passive: true });
}

function getGameResult() {
  if (!gameStarted) return { token: '*', title: 'Chưa bắt đầu', detail: 'Bắt đầu ván để chơi và ghi lại kết quả.' };
  if (manualGameResult) return { ...manualGameResult };
  if (clockFlagged) {
    const winner = clockFlagged === 'w' ? 'Đen' : 'Trắng';
    const token = clockFlagged === 'w' ? '0-1' : '1-0';
    return { token, title: `${winner} thắng do hết giờ`, detail: `${clockPlayerName(clockFlagged)} đã hết thời gian.` };
  }
  if (game.isCheckmate()) {
    const winner = game.turn() === 'w' ? 'Đen' : 'Trắng';
    return { token: winner === 'Trắng' ? '1-0' : '0-1', title: `Chiếu hết — ${winner} thắng`, detail: 'Vua bên thua không còn nước đi hợp lệ để thoát chiếu.' };
  }
  if (game.isStalemate()) return { token: '1/2-1/2', title: 'Hòa do hết nước đi', detail: 'Bên tới lượt không bị chiếu nhưng không có nước đi hợp lệ.' };
  if (game.isThreefoldRepetition()) return { token: '1/2-1/2', title: 'Hòa do lặp thế cờ', detail: 'Thế cờ đã lặp lại ba lần.' };
  if (game.isInsufficientMaterial()) return { token: '1/2-1/2', title: 'Hòa do không đủ quân chiếu hết', detail: 'Không còn đủ lực lượng để chiếu hết theo luật cờ.' };
  if (game.isDraw()) return { token: '1/2-1/2', title: 'Ván cờ hòa', detail: 'Ván đấu kết thúc theo luật cờ vua.' };
  return { token: '*', title: 'Ván cờ đang diễn ra', detail: '' };
}
function reviewMoveLabel(row) {
  const number = Math.max(1, Number(row?.moveNumber) || Math.ceil(Number(row?.ply || 1) / 2));
  return row?.mover === 'w' ? `${number}. ${row?.san || '—'}` : `${number}... ${row?.san || '—'}`;
}
function reviewMoveNotationLabel(row) {
  const notation = reviewMoveLabel(row);
  const symbol = reviewSymbolForJudgement(row?.judgement);
  return symbol ? `${notation} ${symbol}` : notation;
}
function readSavedGames() {
  try {
    const stored = JSON.parse(localStorage.getItem(GAME_HISTORY_KEY) || '[]');
    return Array.isArray(stored) ? stored.filter(item => item && item.id && item.pgn && item.signature).slice(0, 100) : [];
  } catch { return []; }
}
function writeSavedGames(items) {
  try { localStorage.setItem(GAME_HISTORY_KEY, JSON.stringify(items.slice(0, 100))); return true; }
  catch { return false; }
}
function currentGameHistorySignature(result = getGameResult()) {
  return `${currentGameId || 'legacy'}|${mode}|${gameStartFen}|${game.pgn()}|${result.token}|${manualGameResult?.reason || ''}|${clockFlagged || ''}`;
}
function maybeArchiveCompletedGame() {
  if (!gameStarted || mode === 'lichess' || (!game.isGameOver() && !clockFlagged && !manualGameResult)) return;
  const result = getGameResult();
  if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const signature = historyRestoreSignature || currentGameHistorySignature(result);
  const games = readSavedGames();
  const existing = games.findIndex(item => item.signature === signature);
  const reviewRows = completedReviewRows.filter(row => row.ply > 0);
  if (existing >= 0) {
    if (reviewRows.length && reviewRows.length >= (games[existing].reviewRows?.length || 0)) {
      games[existing] = { ...games[existing], reviewRows, reviewStatus: reviewStatus || `Đã phân tích ${reviewRows.length} nửa nước.` };
      writeSavedGames(games);
    }
    return;
  }
  const pgn = gamePgnWithResult();
  const record = {
    id: `g${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
    signature, date: new Date().toISOString(), resultToken: result.token, title: result.title,
    detail: result.detail || '', mode, plies: game.history().length,
    opening: recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định',
    opponent: mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? `VILA Offline AI · ${settings.alternativeEngine}` : ['stockfish', 'stockfish-beginner'].includes(mode) ? 'Stockfish' : 'Hai người chơi',
    pgn, startFen: gameStartFen, reviewRows, reviewStatus: reviewStatus || ''
  };
  games.unshift(record);
  writeSavedGames(games.slice(0, 100));
}
function syncArchivedGameReview() {
  const signature = historyRestoreSignature || currentGameHistorySignature(getGameResult());
  const games = readSavedGames();
  const index = games.findIndex(item => item.signature === signature);
  if (index < 0) return;
  games[index] = { ...games[index], reviewRows: completedReviewRows.filter(row => row.ply > 0), reviewStatus: reviewStatus || '' };
  writeSavedGames(games);
}
function getReviewReplayState() {
  const signature = `${gameStartFen}|${game.pgn()}`;
  if (reviewReplayState?.signature === signature) return reviewReplayState;
  const replay = new Chess(gameStartFen);
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '' }];
  const history = game.history({ verbose: true });
  for (let index = 0; index < history.length; index += 1) {
    const move = history[index];
    let made;
    try { made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); }
    catch { made = null; }
    if (!made) break;
    positions.push({ fen: replay.fen(), ply: index + 1, san: made.san, mover: made.color });
  }
  reviewReplayState = { signature, positions, ply: positions.length - 1 };
  return reviewReplayState;
}
function renderReplayBoardMarkup(fen, lastMove = null, judgement = null) {
  let snapshot;
  try { snapshot = new Chess(fen).board(); } catch { snapshot = new Chess().board(); }
  const html = [];
  const symbol = reviewSymbolForJudgement(judgement);
  const tone = judgement?.key || 'neutral';
  const label = judgement?.label || '';
  // Keep the white-at-bottom orientation while pinning the judgement to the moved piece's destination.
  for (let row = 0; row < 8; row += 1) {
    const rank = 8 - row;
    for (let file = 0; file < 8; file += 1) {
      const piece = snapshot[row][file];
      const square = `${String.fromCharCode(97 + file)}${rank}`;
      const light = (row + file) % 2 === 0;
      const fromClass = lastMove?.from === square ? ' review-last-from' : '';
      const toClass = lastMove?.to === square ? ' review-last-to' : '';
      const annotation = lastMove?.to === square && symbol ? `<span class="review-piece-annotation annotation-${esc(tone)}" title="${esc(label)}" aria-label="${esc(label)}">${esc(symbol)}</span>` : '';
      html.push(`<div class="review-replay-square ${light ? 'review-light' : 'review-dark'}${fromClass}${toClass}" role="gridcell" aria-label="${square}${lastMove?.to === square && label ? `, ${esc(label)}` : ''}">${piece ? `<span class="review-replay-piece ${piece.color === 'w' ? 'piece-white' : 'piece-black'}">${pieceGlyph(piece)}</span>` : ''}${annotation}</div>`);
    }
  }
  return html.join('');
}
function updateReviewReplay() {
  const board = $('#reviewReplayBoard');
  if (!board) return;
  const state = getReviewReplayState();
  state.ply = Math.max(0, Math.min(state.positions.length - 1, Number(state.ply) || 0));
  const position = state.positions[state.ply] || state.positions[0];
  const replayMoves = game.history({ verbose: true });
  const lastMove = state.ply > 0 ? replayMoves[state.ply - 1] : null;
  const judgedPosition = completedReviewRows.find(row => row.ply === state.ply);
  board.innerHTML = renderReplayBoardMarkup(position.fen, lastMove, judgedPosition?.judgement);
  const label = $('#reviewReplayPosition');
  if (label) {
    const shownMove = judgedPosition ? reviewMoveNotationLabel(judgedPosition) : reviewMoveLabel(position);
    label.textContent = state.ply === 0 ? 'Vị trí bắt đầu' : `Sau ${shownMove} · ${state.ply}/${state.positions.length - 1}`;
  }
  $$('[data-review-step]').forEach(button => {
    const step = button.dataset.reviewStep;
    button.disabled = (step === 'first' || step === 'prev') ? state.ply === 0 : (step === 'next' || step === 'last') ? state.ply >= state.positions.length - 1 : false;
  });
  $$('[data-review-ply]').forEach(button => {
    const active = Number(button.dataset.reviewPly) === state.ply;
    button.classList.toggle('review-move-active', active);
    if (active) button.setAttribute('aria-current', 'step'); else button.removeAttribute('aria-current');
  });
  updateReviewMoveDetail();
}
function setReviewReplayPly(value) {
  const state = getReviewReplayState();
  const next = typeof value === 'function' ? value(state.ply, state.positions.length - 1) : value;
  state.ply = Math.max(0, Math.min(state.positions.length - 1, Number(next) || 0));
  updateReviewReplay();
}
function restoreSavedGame(record, analyze = false) {
  if (!record) return;
  try {
    cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopFullGameReview(false); stopAnalysis(true); cancelMainEngineSearch(); stopClock();
    const restored = new Chess();
    let archivedPgn = String(record.pgn || '');
    const archivedStartFen = record.startFen || new Chess().fen();
    if (archivedStartFen !== new Chess().fen() && !/\[FEN\s+"/i.test(archivedPgn)) {
      // Backward-compatibility for records saved before custom-FEN PGN headers
      // were added; reconstruct them from the separate archive field.
      const headerEnd = archivedPgn.indexOf('\n\n');
      const fenTags = `[SetUp "1"]\n[FEN "${pgnEscape(archivedStartFen)}"]`;
      archivedPgn = headerEnd >= 0
        ? `${archivedPgn.slice(0, headerEnd)}\n${fenTags}${archivedPgn.slice(headerEnd)}`
        : `${fenTags}\n\n${archivedPgn}`;
    }
    restored.loadPgn(archivedPgn);
    game = restored;
    moveClockSnapshots = []; redoStack = [];
    gameStartFen = archivedStartFen;
    mode = 'local'; humanColor = 'w'; orientation = 'w'; gameStarted = true;
    clockFlagged = null;
    manualGameResult = { token: record.resultToken || '*', title: record.title || 'Ván đã lưu', detail: record.detail || 'Đang xem lại ván đã lưu.', reason: 'saved-replay' };
    completedReviewRows = Array.isArray(record.reviewRows) ? record.reviewRows : [];
    reviewStatus = record.reviewStatus || (completedReviewRows.length ? `Đã tải ${completedReviewRows.length} đánh giá đã lưu.` : 'Ván đã lưu. Có thể phân tích lại bằng Stockfish.');
    historyRestoreSignature = record.signature;
    reviewReplayState = null; selected = null; selectedTargets = []; premoveQueue = []; lastMove = null; botThinking = false;
    resetClock('untimed');
    setView('review');
    if (analyze) setTimeout(() => startFullGameReview(), 120);
  } catch (error) { toast(`Không mở được PGN đã lưu: ${error.message || error}`); }
}
function renderHistoryView() {
  const games = readSavedGames();
  const items = games.map(record => {
    const date = Number.isFinite(Date.parse(record.date)) ? new Date(record.date).toLocaleString('vi-VN') : 'Ngày không rõ';
    const reviewed = record.reviewRows?.length || 0;
    return `<article class="saved-game-card"><div class="saved-game-top"><span class="saved-result ${record.resultToken === '1/2-1/2' ? 'draw' : ''}">${esc(record.resultToken)}</span><div><h3>${esc(record.title || 'Ván đã lưu')}</h3><small>${esc(date)} · ${Number(record.plies) || 0} nửa nước</small></div></div><p>${esc(record.opponent || 'Đối thủ') } · Khai cuộc: ${esc(record.opening || 'Chưa xác định')}</p><div class="saved-game-meta"><span>${reviewed ? `${reviewed} nước đã phân tích` : 'Chưa có phân tích'}</span><span>${esc(record.mode || 'local')}</span></div><div class="saved-game-actions"><button class="primary-btn" type="button" data-history-review="${esc(record.id)}">↶ Xem lại</button><button class="secondary-btn" type="button" data-history-analyze="${esc(record.id)}">♞ Phân tích</button><button class="secondary-btn" type="button" data-history-pgn="${esc(record.id)}">Tải PGN</button><button class="text-btn" type="button" data-history-delete="${esc(record.id)}">Xóa</button></div></article>`;
  }).join('');
  return `<section class="history-view"><header class="page-heading"><div><small class="eyebrow">VÁN ĐẤU CỦA BẠN</small><h1>Lịch sử & xem lại</h1><p>Các ván kết thúc được lưu cục bộ trên thiết bị này. Chọn xem lại, phân tích bằng Stockfish hoặc xuất PGN.</p></div><div class="history-header-actions"><button type="button" class="secondary-btn" id="historyCloudSyncBtn">☁ Đồng bộ đám mây</button><span class="history-count">${games.length}/100 ván</span></div></header><div class="saved-games-list">${items || '<div class="panel empty-state"><b>Chưa có ván đã lưu</b><p>Chơi và kết thúc một ván để nó tự xuất hiện ở đây.</p><button class="primary-btn" type="button" data-history-start>♟ Chơi ván mới</button></div>'}</div><p class="field-hint history-privacy-note">Lịch sử chỉ lưu trong bộ nhớ cục bộ của trình duyệt/WebView này; xóa dữ liệu ứng dụng có thể xóa lịch sử.</p></section>`;
}
function wireHistoryActions() {
  const find = id => readSavedGames().find(record => record.id === id);
  $('#historyCloudSyncBtn')?.addEventListener('click', async () => {
    toast('Đang đồng bộ lịch sử ván cờ với đám mây...');
    const result = await syncHistoryToCloud(settings.backendUrl || '', socialState.token || '', readSavedGames());
    toast(result.message, result.ok ? 'success' : 'info');
  });
  $$('[data-history-review]').forEach(button => button.addEventListener('click', () => restoreSavedGame(find(button.dataset.historyReview), false)));
  $$('[data-history-analyze]').forEach(button => button.addEventListener('click', () => restoreSavedGame(find(button.dataset.historyAnalyze), true)));
  $$('[data-history-pgn]').forEach(button => button.addEventListener('click', () => {
    const record = find(button.dataset.historyPgn);
    if (record) downloadTextFile(record.pgn, `vila-chess-${String(record.date || '').slice(0, 10) || 'game'}.pgn`, 'application/x-chess-pgn;charset=utf-8');
  }));
  $$('[data-history-delete]').forEach(button => button.addEventListener('click', () => {
    const record = find(button.dataset.historyDelete);
    if (!record || (typeof window.confirm === 'function' && !window.confirm('Xóa ván đã lưu này khỏi thiết bị?'))) return;
    writeSavedGames(readSavedGames().filter(item => item.id !== record.id)); renderView();
  }));
  $('[data-history-start]')?.addEventListener('click', () => { mode = 'stockfish'; historyRestoreSignature = ''; openMatchSetup(); });
}
function renderEvaluationGraphMarkup() {
  const rows = completedReviewRows.filter(row => row.ply > 0 && Number.isFinite(row.scoreWhiteCp)).sort((a, b) => a.ply - b.ply);
  if (rows.length < 2) return '<div class="evaluation-graph-empty">Biểu đồ sẽ xuất hiện sau khi Stockfish phân tích ít nhất hai thế cờ.</div>';
  const width = 600, height = 150, padX = 8, padY = 12;
  const points = rows.map((row, index) => {
    const x = padX + (width - padX * 2) * index / (rows.length - 1);
    const cp = Math.max(-1000, Math.min(1000, row.scoreWhiteCp));
    const y = padY + (1000 - cp) / 2000 * (height - padY * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const centerY = height / 2;
  return `<svg class="evaluation-graph-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Biểu đồ lợi thế theo từng thế cờ, góc nhìn Trắng"><line class="evaluation-graph-zero" x1="0" y1="${centerY}" x2="${width}" y2="${centerY}"/><polyline class="evaluation-graph-line" points="${points}"/><text x="8" y="10" class="evaluation-graph-label">Trắng +10</text><text x="8" y="${height - 3}" class="evaluation-graph-label">Đen −10</text></svg><div class="evaluation-graph-caption">${rows.length} thế cờ đã phân tích · điểm quy về góc nhìn Trắng, giới hạn hiển thị ±10 tốt (1000 centipawn).</div>`;
}
function updateEvaluationGraph() {
  const graph = $('#evaluationGraph');
  if (graph) graph.innerHTML = renderEvaluationGraphMarkup();
}
function formatReviewEval(row) {
  if (!row || !Number.isFinite(row.scoreWhiteCp)) return '—';
  if (row.scoreType === 'mate' || Math.abs(row.scoreWhiteCp) >= 9900) {
    const sign = row.scoreWhiteCp < 0 ? '−' : '+';
    const mateIn = Number.isFinite(row.mateWhite) ? Math.abs(row.mateWhite) : 0;
    return `${sign}M${mateIn}`;
  }
  return `${row.scoreWhiteCp >= 0 ? '+' : '−'}${(Math.abs(row.scoreWhiteCp) / 100).toFixed(1)}`;
}
function renderReviewMoveButtonMarkup(row) {
  if (!row) return '<span class="review-empty-move" aria-hidden="true">—</span>';
  const tone = row.judgement?.key || 'neutral';
  const symbol = reviewSymbolForJudgement(row.judgement);
  const description = reviewSymbolDescription(row.judgement);
  const evalText = formatReviewEval(row);
  const lossText = Number.isFinite(row.lossCp) ? `−${(row.lossCp / 100).toFixed(1)}` : '—';
  const spoken = `${reviewMoveLabel(row)} · ${description} · đánh giá ${evalText} · mất ${lossText} tốt`;
  return `<button type="button" class="review-ply-move ${row.mover === 'b' ? 'review-black-move' : 'review-white-move'}" data-review-ply="${Number(row.ply)}" title="${esc(spoken)}" aria-label="${esc(spoken)}"><span class="review-ply-san">${esc(row.san || '—')}</span>${symbol ? `<span class="review-move-symbol symbol-${esc(tone)}" aria-hidden="true">${esc(symbol)}</span>` : ''}<small class="review-ply-eval">${esc(evalText)} · ${esc(lossText)}</small></button>`;
}
function renderReviewMoveListMarkup(rows) {
  const groups = groupReviewedMoves(rows);
  if (!groups.length) return '<div class="empty-state small-empty">Khi phân tích xong, nước đi và nhãn đánh giá sẽ xuất hiện theo cặp Trắng/Đen.</div>';
  return `<div class="review-move-header"><span>#</span><span>Trắng</span><span>Đen</span></div><div class="review-move-pairs">${groups.map(group => `<div class="review-move-pair"><span class="review-move-number">${group.moveNumber}.</span>${renderReviewMoveButtonMarkup(group.white)}${renderReviewMoveButtonMarkup(group.black)}</div>`).join('')}</div>`;
}
function renderReviewSideStatsMarkup(rows) {
  const categoryMeta = [
    ['brilliant', '!!', 'Thiên tài'], ['great', '!', 'Tuyệt vời'], ['book', 'BK', 'Khai cuộc'], ['best', '★', 'Tốt nhất'], ['excellent', '✓', 'Xuất sắc'], ['good', '·', 'Tốt'],
    ['inaccuracy', '?!', 'Thiếu chính xác'], ['mistake', '?', 'Sai lầm'], ['blunder', '??', 'Sai lầm nghiêm trọng'],
    ['missed-win', '⊘', 'Bỏ lỡ']
  ];
  return `<div class="review-side-stats-grid">${[['w', 'Trắng', '♙'], ['b', 'Đen', '♟']].map(([side, label, glyph]) => {
    const summary = summarizeReviewSide(rows, side);
    const chips = categoryMeta.map(([key, symbol, title]) => summary.counts[key]
      ? `<span class="review-count-chip symbol-${key}" title="${esc(title)}"><b>${esc(symbol)}</b>${summary.counts[key]}</span>` : '').join('');
    return `<article class="review-side-stat-card review-side-${side}"><div class="review-side-stat-head"><span class="review-side-glyph" aria-hidden="true">${glyph}</span><div><b>${label}</b><small>${summary.rated}/${summary.total} nước đã đánh giá</small></div></div><div class="review-count-chips">${chips || '<small>Chưa có nhãn đánh giá</small>'}</div></article>`;
  }).join('')}</div>`;
}
function renderReviewMoveDetailMarkup(ply) {
  const safePly = Math.max(0, Number(ply) || 0);
  if (!safePly) return '<div class="review-move-detail-empty">Chọn một nước đi để xem điểm engine, mức mất điểm, biến chính và nước thay thế Stockfish đề xuất.</div>'; 
  const row = completedReviewRows.find(item => item.ply === safePly);
  if (!row) return `<div class="review-move-detail-empty">Nước ${safePly} chưa được phân tích. Chạy “Phân tích toàn ván” để lấy đánh giá và nước gợi ý.</div>`;
  const played = `${esc(reviewMoveLabel(row))}`;
  const best = row.bestMoveSan ? esc(row.bestMoveSan) : '';
  const bestLine = Array.isArray(row.bestLineSan) ? row.bestLineSan.filter(Boolean).slice(0, 8).map(esc).join(' ') : '';
  const isBest = row.moveWasBest === true;
  const suggestion = best
    ? `<span>${isBest ? 'Bạn đã đi nước đầu tiên của biến chính.' : `Nước thay thế: <strong>${best}</strong>`}${Number(row.bestMoveDepth) ? ` <small>(độ sâu ${Number(row.bestMoveDepth)})</small>` : ''}</span>${bestLine ? `<div class="review-best-line"><small>BIẾN ENGINE</small><b>${bestLine}</b></div>` : ''}`
    : 'Engine chưa lưu được biến chính cho thế trước; hãy phân tích lại để có gợi ý nước thay thế.';
  const evalText = formatReviewEval(row);
  const lossText = Number.isFinite(row.lossCp) ? `${(row.lossCp / 100).toFixed(2)} tốt` : 'chưa đủ dữ liệu';
  return `<div class="review-move-detail-top"><div><small>PHÂN TÍCH NƯỚC ĐI</small><b>${played}</b></div><span class="review-detail-eval">${esc(evalText)}</span></div><div class="review-move-detail-grid"><div><small>Đánh giá</small><b class="verdict-${esc(row.judgement?.key || 'neutral')}">${esc(row.judgement?.label || 'Chưa đánh giá')}</b></div><div><small>Điểm đã mất</small><b>${esc(lossText)}</b></div><div><small>Độ sâu</small><b>${Number(row.engineDepth) || '—'}</b></div></div><div class="review-move-suggestion">${suggestion}</div>`;
}
function updateReviewMoveDetail() {
  const detail = $('#reviewMoveDetail');
  if (!detail) return;
  detail.innerHTML = renderReviewMoveDetailMarkup(getReviewReplayState().ply);
}

function renderFullGameResultPanel() {
  const result = getGameResult();
  const reviewRows = completedReviewRows.slice(-160);
  const done = reviewRows.filter(row => row.ply > 0).length;
  const blunders = reviewRows.filter(row => row.judgement?.key === 'blunder').length;
  const mistakes = reviewRows.filter(row => row.judgement?.key === 'mistake').length;
  const rowHtml = renderReviewMoveListMarkup(reviewRows);
  const reviewing = Boolean(reviewSession);
  const reviewSummary = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish…`
    : reviewStatus || (done ? `Đã phân tích ${done} nửa nước · ${mistakes} sai lầm · ${blunders} blunder.` : 'Chưa phân tích ván. Bấm “Phân tích toàn ván” để đánh giá từng nửa nước bằng Stockfish nội bộ.');
  const ratingProfile = readRatingProfile();
  const ratingStrip = ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && ['1-0', '0-1', '1/2-1/2'].includes(result.token)
    ? `<div class="rating-result-strip"><span>Elo hiện tại <b>${ratingProfile.elo}</b></span><span>Biến động gần nhất <b class="${ratingProfile.lastChange > 0 ? 'positive' : ratingProfile.lastChange < 0 ? 'negative' : ''}">${ratingProfile.lastChange > 0 ? '+' : ''}${ratingProfile.lastChange}</b></span><small>Điểm Elo ước lượng lưu trên thiết bị</small></div>` : '';
  const replayNow = getReviewReplayState();
  const replayMoveNow = replayNow.ply > 0 ? game.history({ verbose: true })[replayNow.ply - 1] : null;
  const replayJudgementNow = completedReviewRows.find(row => row.ply === replayNow.ply)?.judgement;
  return `<section class="panel full-game-result" id="fullGameResult">
    <div class="panel-heading"><div><small class="eyebrow">KẾT QUẢ & ĐÁNH GIÁ</small><h2>${esc(result.title)}</h2></div><span class="result-token">${esc(result.token)}</span></div>
    <p class="result-detail">${esc(result.detail)}</p>${ratingStrip}
    <div class="result-stats"><span><small>Số nửa nước</small><b>${game.history().length}</b></span><span><small>Khai cuộc</small><b>${esc(recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định')}</b></span><span><small>Engine</small><b>Stockfish 19 / 10</b></span></div>
    <div class="review-upper-grid">
      <div class="review-upper-left">
        <section class="evaluation-graph-panel"><div class="review-replay-head"><b>Biểu đồ lợi thế</b><span>Trắng ↔ Đen</span></div><div id="evaluationGraph">${renderEvaluationGraphMarkup()}</div></section>
        <section class="review-side-stats" id="reviewSideStats" aria-label="Tổng hợp chất lượng nước đi theo bên">${renderReviewSideStatsMarkup(reviewRows)}</section>
        <div class="review-symbol-legend" aria-label="Chú giải ký hiệu đánh giá"><span><b class="symbol-brilliant">!!</b> Thiên tài</span><span><b class="symbol-great">!</b> Tuyệt vời</span><span><b class="symbol-best">★</b> Tốt nhất</span><span><b class="symbol-excellent">✓</b> Xuất sắc</span><span><b class="symbol-good">·</b> Tốt</span><span><b class="symbol-book">BK</b> Khai cuộc</span><span><b class="symbol-inaccuracy">?!</b> Thiếu chính xác</span><span><b class="symbol-mistake">?</b> Sai lầm</span><span><b class="symbol-missed-win">⊘</b> Bỏ lỡ</span><span><b class="symbol-blunder">??</b> Sai lầm nghiêm trọng</span></div>
        <p class="review-classification-note">★, ✓ và · là nhãn giao diện cho Tốt nhất/Xuất sắc/Tốt; ?!, ? và ?? là dấu chú giải quen thuộc cho Chưa chuẩn/Sai lầm/Blunder. Phân loại do VILA ước lượng bằng mức mất centipawn, phụ thuộc phiên bản Stockfish, độ sâu và thời gian tìm kiếm; không phải điểm CAPS2 hay thuật toán nội bộ của Chess.com, và không tự chèn các huy hiệu giao diện vào PGN.</p>
        <div class="review-move-list" id="reviewMoveAnalysis">${rowHtml || '<div class="empty-state small-empty">Khi phân tích xong, đánh giá từng nước sẽ hiện ở đây.</div>'}</div>
      </div>
      <div class="review-upper-right">
        <section class="review-replay-panel"><div class="review-replay-head"><b>♟ Xem lại từng nước</b><span id="reviewReplayPosition">Đang ở nước cuối</span></div><div id="reviewReplayBoard" class="review-replay-board" role="grid" aria-label="Bàn cờ xem lại">${renderReplayBoardMarkup(replayNow.positions[replayNow.ply]?.fen || game.fen(), replayMoveNow, replayJudgementNow)}</div><div class="review-replay-controls"><button type="button" class="secondary-btn" data-review-step="first" aria-label="Về đầu">|◀</button><button type="button" class="secondary-btn" data-review-step="prev" aria-label="Nước trước">‹ Trước</button><button type="button" class="secondary-btn" data-review-step="next" aria-label="Nước sau">Sau ›</button><button type="button" class="secondary-btn" data-review-step="last" aria-label="Đến cuối">▶|</button></div><p class="review-replay-caption">Chạm một nước trong biên bản để nhảy nhanh tới thế cờ đó.</p></section>
        <section id="reviewMoveDetail" class="review-move-detail" aria-live="polite">${renderReviewMoveDetailMarkup(replayNow.ply)}</section>
        <div class="review-progress" id="reviewProgress">${esc(reviewSummary)}</div>
      </div>
    </div>
    <div class="review-actions"><button id="resultPlayAgain" type="button" class="primary-btn">↻ Chơi lại</button><button id="reviewGameBtn" type="button" class="primary-btn" ${reviewing ? 'disabled' : ''}>♞ Phân tích toàn ván</button><button id="stopReviewBtn" type="button" class="secondary-btn" ${reviewing ? '' : 'disabled'}>Dừng</button><button id="reviewDownloadPGN" type="button" class="secondary-btn">Tải PGN</button></div>
  </section>`;
}
function renderReviewView() {
  const result = getGameResult();
  const opponent = manualGameResult?.reason === 'saved-replay' ? (manualGameResult?.title || 'Ván đã lưu') : mode === 'stockfish' ? 'Stockfish 19' : mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : mode === 'local' ? 'Hai người chơi' : 'Ván đã lưu';
  const currentReviewCount = completedReviewRows.filter(row => row.ply > 0).length;
  return `<section class="content-page game-review-page">
    <header class="game-review-header"><div class="game-review-heading-copy"><span class="eyebrow">CỜ VUA VILA · GAME REVIEW</span><h1>Xem lại ván đấu</h1><p>Phân tích nước đi, lợi thế và các phương án thay thế bằng Stockfish. Đây là đánh giá của engine, không phải điểm CAPS2 của Chess.com.</p></div><div class="game-review-header-actions"><button id="reviewBackHome" type="button" class="secondary-btn">← Trang chủ</button><button id="reviewPlayAgainTop" type="button" class="primary-btn">↻ Ván mới</button></div></header>
    <section class="game-review-summary panel"><div class="game-review-result-badge ${result.token === '1/2-1/2' ? 'is-draw' : 'is-result'}">${esc(result.token)}</div><div class="game-review-summary-main"><small>KẾT QUẢ · ${esc(opponent)}</small><h2>${esc(result.title)}</h2><p>${esc(result.detail || 'Ván đấu đã kết thúc. Có thể phân tích lại từng nửa nước.')}</p></div><div class="game-review-summary-stats"><span><small>Nửa nước</small><b>${game.history().length}</b></span><span><small>Đã đánh giá</small><b id="reviewSummaryAnalyzed">${currentReviewCount}</b></span><span><small>Engine</small><b>${engineReady && !engineFailed ? 'Sẵn sàng' : 'Chưa sẵn sàng'}</b></span></div></section>
    <div class="game-review-workspace">${renderFullGameResultPanel()}</div>
    <p class="game-review-footnote">Lưu ý: nhãn chất lượng phụ thuộc phiên bản engine, độ sâu, thời gian tìm kiếm và bộ quy tắc VILA. Mức độ chính xác không được quảng bá là thuật toán nội bộ của Chess.com.</p>
  </section>`;
}
function wireReviewActions() {
  $('#reviewBackHome')?.addEventListener('click', () => setView('home'));
  $('#reviewPlayAgainTop')?.addEventListener('click', () => freshGame());
  $('#resultPlayAgain')?.addEventListener('click', openMatchSetup);
  $('#reviewGameBtn')?.addEventListener('click', startFullGameReview);
  $('#stopReviewBtn')?.addEventListener('click', () => stopFullGameReview(true));
  $$('[data-review-step]').forEach(button => button.addEventListener('click', () => {
    const action = button.dataset.reviewStep;
    setReviewReplayPly((ply, last) => action === 'first' ? 0 : action === 'prev' ? ply - 1 : action === 'next' ? ply + 1 : action === 'last' ? last : ply);
  }));
  $('#reviewMoveAnalysis')?.addEventListener('click', event => {
    const row = event.target.closest('[data-review-ply]');
    if (row) setReviewReplayPly(Number(row.dataset.reviewPly));
  });
  $('#reviewDownloadPGN')?.addEventListener('click', downloadPgn);
  updateReviewReplay();
}

function updateReviewPanel() {
  const progress = $('#reviewProgress');
  const list = $('#reviewMoveAnalysis');
  if (!progress || !list) { if (currentView === 'review') renderView(); return; }
  const rows = completedReviewRows.filter(row => row.ply > 0);
  const reviewedCount = $('#reviewSummaryAnalyzed');
  if (reviewedCount) reviewedCount.textContent = String(rows.length);
  const reviewing = Boolean(reviewSession);
  progress.textContent = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish…`
    : reviewStatus || `Đã phân tích ${rows.length} nửa nước.`;
  list.innerHTML = renderReviewMoveListMarkup(rows);
  const sideStats = $('#reviewSideStats');
  if (sideStats) sideStats.innerHTML = renderReviewSideStatsMarkup(rows);
  updateEvaluationGraph();
  updateReviewReplay();
}
function stopFullGameReview(announce = false) {
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  const wasReviewing = Boolean(reviewSession);
  reviewSession = null;
  if (wasReviewing) {
    requestEngineStop();
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
  }
  if (announce && wasReviewing) { reviewStatus = 'Đã dừng phân tích theo yêu cầu.'; updateReviewPanel(); }
}
/** Stockfish lines used in a review: MultiPV 2 lets us recognise only-moves (Tuyệt vời). */
function reviewLaneCount() { return settings.reviewQuality === 'standard' ? 1 : 2; }
function beginReviewPosition() {
  if (!reviewSession) return;
  if (reviewSession.index >= reviewSession.positions.length) {
    reviewStatus = `Hoàn tất phân tích ${completedReviewRows.filter(row => row.ply > 0).length} nửa nước.`;
    reviewSession = null;
    engineSearchActive = false;
    try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
    syncArchivedGameReview();
    updateReviewPanel();
    return;
  }
  if (!engineWorker || !engineReady || engineFailed) {
    reviewStatus = 'Không thể tiếp tục: Stockfish chưa sẵn sàng.';
    reviewSession = null; engineSearchActive = false; updateReviewPanel(); return;
  }
  const position = reviewSession.positions[reviewSession.index];
  reviewSession.currentScoreWhite = Number.isFinite(position.terminalScoreWhiteCp) ? position.terminalScoreWhiteCp : null;
  reviewSession.currentDepth = 0;
  reviewSession.currentSecondWhite = null;
  reviewSession.currentSecondDepth = 0;
  reviewSession.currentScoreType = position.terminalScoreWhiteCp != null && Math.abs(position.terminalScoreWhiteCp) >= 9900 ? 'mate' : 'cp';
  reviewSession.currentMateWhite = position.terminalScoreWhiteCp != null && Math.abs(position.terminalScoreWhiteCp) >= 9900 ? (position.terminalScoreWhiteCp < 0 ? -0 : 0) : null;
  reviewSession.currentBestUci = null;
  reviewSession.currentPvUci = [];
  reviewSession.waiting = true;
  if (position.terminalScoreWhiteCp != null) {
    // Terminal checkmate/draw positions are known exactly; Stockfish may return no PV for them.
    engineSearchActive = false;
    finishReviewPosition(false, null);
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = -3;
  mainEngineSearchFen = position.fen;
  try {
    configureStockfishForAnalysis(reviewLaneCount());
    engineWorker.postMessage('setoption name Hash value 64');
    engineWorker.postMessage(`position fen ${position.fen}`);
    const reviewMoveTimeMs = resolveReviewMoveTimeMs(settings);
    engineWorker.postMessage(`go movetime ${reviewMoveTimeMs}`);
    reviewSession.timeout = setTimeout(() => finishReviewPosition(true), reviewMoveTimeMs + 4500);
    updateReviewPanel();
  } catch {
    finishReviewPosition(true);
  }
}
function receiveReviewInfo(line) {
  if (!reviewSession?.waiting) return;
  const match = line.match(/\bscore\s+(cp|mate)\s+(-?\d+)/);
  if (!match) return;
  const depth = Number(line.match(/\bdepth\s+(\d+)/)?.[1] || 0);
  const lane = Number(line.match(/\bmultipv\s+(\d+)/)?.[1] || 1);
  const position = reviewSession.positions[reviewSession.index];
  const turn = String(position.fen).split(/\s+/)[1] || 'w';
  if (lane === 2) {
    // Second-best line: used only to detect "only moves" for the Tuyệt vời label.
    if (depth >= (reviewSession.currentSecondDepth || 0)) {
      reviewSession.currentSecondDepth = depth;
      reviewSession.currentSecondWhite = scoreSideToWhiteCentipawns(Number(match[2]), turn, match[1]);
    }
    return;
  }
  if (lane !== 1) return;
  if (depth < reviewSession.currentDepth) return;
  const rawScore = Number(match[2]);
  reviewSession.currentDepth = depth;
  reviewSession.currentScoreType = match[1];
  reviewSession.currentMateWhite = match[1] === 'mate'
    ? (rawScore === 0 ? (turn === 'w' ? -0 : 0) : rawScore * (turn === 'b' ? -1 : 1))
    : null;
  reviewSession.currentScoreWhite = scoreSideToWhiteCentipawns(rawScore, turn, match[1]);
  const pv = line.match(/\bpv\s+((?:[a-h][1-8][a-h][1-8][qrbn]?\s*)+)/i);
  if (pv) {
    const moves = pv[1].trim().toLowerCase().split(/\s+/).filter(move => /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(move)).slice(0, 8);
    if (moves.length) { reviewSession.currentPvUci = moves; reviewSession.currentBestUci = moves[0]; }
  }
}
function finishReviewPosition(timedOut = false, engineBestUci = null) {
  if (!reviewSession?.waiting) return;
  const session = reviewSession;
  if (session.timeout) clearTimeout(session.timeout);
  session.timeout = null;
  session.waiting = false;
  const position = session.positions[session.index];
  const scoreWhiteCp = Number.isFinite(session.currentScoreWhite) ? session.currentScoreWhite : null;
  const bestUciPattern = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;
  const currentBestUci = bestUciPattern.test(String(engineBestUci || ''))
    ? String(engineBestUci).toLowerCase()
    : bestUciPattern.test(String(session.currentBestUci || '')) ? session.currentBestUci : null;
  const currentBestPvUci = currentBestUci
    ? (session.currentPvUci?.[0] === currentBestUci ? session.currentPvUci.slice(0, 8) : [currentBestUci, ...(session.currentPvUci || []).filter(move => move !== currentBestUci).slice(0, 7)])
    : [];
  if (timedOut) {
    reviewStatus = `Đã dừng tại ${session.index}/${session.positions.length}: Stockfish không phản hồi kịp. Các kết quả đã có vẫn được giữ; kiểm tra engine rồi chạy lại phần còn thiếu.`;
    reviewSession = null;
    engineSearchActive = false;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    waitingForStockfishMove = null;
    retireStockfishWorker(reviewStatus);
    updateReviewPanel();
    return;
  }
  if (session.index === 0) {
    completedReviewRows = [{
      ply: 0, san: '', mover: '', scoreWhiteCp, scoreType: session.currentScoreType || (position.terminalScoreWhiteCp != null ? 'mate' : 'cp'),
      mateWhite: session.currentMateWhite, lossCp: null, judgement: null,
      bestMoveUci: currentBestUci, bestMoveSan: currentBestUci ? (uciPvToSan(position.fen, [currentBestUci])[0] || null) : null,
      bestLineUci: currentBestPvUci,
      bestLineSan: uciPvToSan(position.fen, currentBestPvUci),
      engineDepth: session.currentDepth || 0
    }];
  } else {
    const beforePosition = session.positions[session.index - 1];
    const bestMoveUci = session.lastBestUci;
    const bestMoveSan = bestMoveUci ? (uciPvToSan(beforePosition.fen, [bestMoveUci])[0] || null) : null;
    const bestLineUci = (session.lastBestPvUci?.length ? session.lastBestPvUci : bestMoveUci ? [bestMoveUci] : []).slice(0, 8);
    const bestLineSan = uciPvToSan(beforePosition.fen, bestLineUci);
    const lossCp = estimateMoveLoss(session.lastScoreWhite, scoreWhiteCp, position.mover);
    const moverBeforeCp = session.lastScoreWhite == null ? null : (position.mover === 'w' ? session.lastScoreWhite : -session.lastScoreWhite);
    const moverAfterCp = scoreWhiteCp == null ? null : (position.mover === 'w' ? scoreWhiteCp : -scoreWhiteCp);
    const moveWasBest = Boolean(bestMoveUci && position.uci && bestMoveUci === position.uci);
    const moverSign = position.mover === 'w' ? 1 : -1;
    const secondGapPct = (Number.isFinite(session.lastSecondWhite) && Number.isFinite(session.lastScoreWhite))
      ? Math.max(0, winChance(moverSign * session.lastScoreWhite) - winChance(moverSign * session.lastSecondWhite)) : null;
    const sacrifice = lossCp != null && lossCp <= 80 && detectSacrifice({ fenBefore: beforePosition.fen, playedUci: position.uci, pvAfterUci: currentBestPvUci, mover: position.mover, ChessConstructor: Chess });
    const judgement = lossCp == null ? null : classifyMoveQuality({ moverBeforeCp, moverAfterCp, isBest: moveWasBest, bookMove: position.bookMove, sacrifice, secondGapPct });
    completedReviewRows.push({
      ply: position.ply, moveNumber: position.moveNumber || Math.ceil(position.ply / 2), san: position.san, mover: position.mover,
      scoreWhiteCp, scoreBeforeWhiteCp: session.lastScoreWhite,
      scoreType: session.currentScoreType || (position.terminalScoreWhiteCp != null ? 'mate' : 'cp'),
      mateWhite: session.currentMateWhite, lossCp, judgement, bookMove: Boolean(position.bookMove),
      bestMoveUci: bestMoveUci || null, bestMoveSan, bestLineUci, bestLineSan, playedUci: position.uci || null,
      moveWasBest: Boolean(bestMoveUci && position.uci && bestMoveUci === position.uci),
      engineDepth: session.currentDepth || 0, bestMoveDepth: session.lastBestDepth || 0
    });
    syncArchivedGameReview();
  }
  if (scoreWhiteCp != null) session.lastScoreWhite = scoreWhiteCp;
  session.lastSecondWhite = Number.isFinite(session.currentSecondWhite) ? session.currentSecondWhite : null;
  if (currentBestUci) session.lastBestUci = currentBestUci;
  session.lastBestPvUci = currentBestPvUci;
  session.lastBestDepth = session.currentDepth || session.lastBestDepth || 0;
  session.lastScoreType = session.currentScoreType || 'cp';
  session.index += 1;
  mainEngineSearchEpoch = -1; mainEngineSearchFen = '';
  engineSearchActive = false;
  try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
  updateReviewPanel();
  setTimeout(beginReviewPosition, 20);
}
function startFullGameReview() {
  if (!gameStarted || game.history().length < 1) { toast('Chơi ít nhất một nước rồi mới có thể phân tích toàn ván.'); return; }
  if (!game.isGameOver() && !clockFlagged && !manualGameResult) { toast('Phân tích toàn ván khả dụng sau khi trận kết thúc. Bạn vẫn có thể dùng “Phân tích 3 biến” giữa ván.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng; hãy kiểm tra tệp engine và thử lại.'); return; }
  if (arenaRunning || botThinking || engineStopPending || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || engineSearchActive) { toast('Đợi tác vụ Stockfish hiện tại kết thúc rồi mới phân tích ván.'); return; }
  recordDailyEvent('analyze_game');
  stopFullGameReview(false);
  completedReviewRows = [];
  reviewStatus = settings.reviewQuality === 'standard' ? 'Đang chuẩn bị phân tích…' : `Đang chuẩn bị phân tích Stockfish 19 · mức ${settings.reviewQuality === 'max' ? 'cao nhất' : 'sâu'}…`;
  const replay = new Chess(gameStartFen);
  const history = game.history({ verbose: true });
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '', bookMove: false, uci: '', terminalScoreWhiteCp: replay.isCheckmate() ? (replay.turn() === 'w' ? -10000 : 10000) : replay.isDraw() ? 0 : null }];
  const openingPrefixes = buildOpeningBookPrefixes(OPENINGS);
  const sanPath = [];
  const maxPlies = Math.min(history.length, 160);
  for (let i = 0; i < maxPlies; i += 1) {
    const move = history[i];
    const moveNumber = Number(replay.fen().split(/\s+/)[5]) || Math.ceil((i + 1) / 2);
    const made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    if (!made) { toast(`Không thể dựng lại lịch sử ở nửa nước ${i + 1}; phân tích đã hủy.`); return; }
    sanPath.push(made.san);
    const bookMove = openingPrefixes.has(sanPath.join(' '));
    positions.push({ fen: replay.fen(), ply: i + 1, moveNumber, san: made.san, mover: made.color, from: made.from, to: made.to, uci: `${made.from}${made.to}${made.promotion || ''}`, bookMove, terminalScoreWhiteCp: replay.isCheckmate() ? (replay.turn() === 'w' ? -10000 : 10000) : replay.isDraw() ? 0 : null });
  }
  reviewSession = { positions, index: 0, lastScoreWhite: null, lastBestUci: null, lastBestPvUci: [], lastBestDepth: 0, currentScoreWhite: null, currentScoreType: 'cp', currentMateWhite: null, currentBestUci: null, currentPvUci: [], currentDepth: 0, waiting: false, timeout: null };
  if (history.length > maxPlies) reviewStatus = 'Giới hạn phân tích ở 160 nửa nước để giữ ổn định trên điện thoại.';
  updateReviewPanel();
  beginReviewPosition();
}
function persistLocalGameRecovery() {
  try {
    if (!gameStarted || !game || !['local', 'stockfish', 'vila', 'enginehub'].includes(mode)) return false;
    const result = getGameResult();
    // Completed games are archived by the normal history path, not offered as recoverable games.
    if (result.token !== '*') { clearLocalGameRecovery(); return true; }
    const snapshot = {
      savedAt: Date.now(), gameId: currentGameId, mode, fen: game.fen(),
      moves: game.history({ verbose: true }).map(move => ({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) })),
      startFen: gameStartFen, orientation, humanColor, gameStarted,
      clockHistory: moveClockSnapshots.slice(0, 1000).map(item => item ? captureClockSnapshot(item, item.clockFlagged ?? null) : null),
      clockState: clockState ? { enabled: !!clockState.enabled, remaining: { w: Number(clockState.remaining?.w) || 0, b: Number(clockState.remaining?.b) || 0 }, incrementMs: Number(clockState.incrementMs) || 0 } : null,
      result: null
    };
    localStorage.setItem(LOCAL_GAME_RECOVERY_KEY, JSON.stringify(sealLocalGameRecoverySnapshot(snapshot)));
    return true;
  } catch { return false; /* Storage may be unavailable or full; gameplay must continue. */ }
}
function clearLocalGameRecovery() {
  try { localStorage.removeItem(LOCAL_GAME_RECOVERY_KEY); } catch {}
}
function restoreLocalGameRecovery(snapshot) {
  try {
    const validation = validateLocalGameRecoverySnapshot(snapshot);
    if (!validation.ok) return false;
    const startFen = typeof snapshot.startFen === 'string' ? snapshot.startFen : new Chess().fen();
    const restored = new Chess(startFen);
    for (const item of snapshot.moves) {
      if (!item || !/^[a-h][1-8]$/.test(item.from) || !/^[a-h][1-8]$/.test(item.to) || (item.promotion && !/^[qrbn]$/.test(item.promotion))) return false;
      const move = restored.move({ from: item.from, to: item.to, ...(item.promotion ? { promotion: item.promotion } : {}) });
      if (!move) return false;
    }
    if (restored.fen() !== snapshot.fen || restored.isGameOver()) return false;
    premoveQueue = [];
    game = restored;
    moveClockSnapshots = Array.isArray(snapshot.clockHistory) ? snapshot.clockHistory.slice(0, snapshot.moves.length).map(item => item && item.remaining ? captureClockSnapshot(item, item.clockFlagged ?? null) : null) : [];
    redoStack = []; gameStartFen = startFen; mode = snapshot.mode; currentGameId = typeof snapshot.gameId === 'string' && snapshot.gameId ? snapshot.gameId : `recovered-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`; ratedGameSignature = ''; 
    orientation = snapshot.orientation === 'b' ? 'b' : 'w'; humanColor = snapshot.humanColor === 'b' ? 'b' : 'w';
    gameStarted = true; manualGameResult = null; clockFlagged = null;
    lastMove = restored.history({ verbose: true }).slice(-1).map(move => ({ from: move.from, to: move.to }))[0] || null;
    selected = null; selectedTargets = []; boardAnnotations = []; annotationTool = null;
    historyRestoreSignature = ''; completedReviewRows = []; reviewStatus = '';
    resetClock(settings.clockPreset);
    if (snapshot.clockState && clockState.enabled && snapshot.clockState.enabled && snapshot.clockState.remaining) {
      for (const color of ['w', 'b']) clockState.remaining[color] = Math.max(0, Math.min(24 * 60 * 60 * 1000, Number(snapshot.clockState.remaining[color]) || 0));
      clockState.incrementMs = Math.max(0, Math.min(60_000, Number(snapshot.clockState.incrementMs) || 0));
      clockState.running = !restored.isGameOver();
    }
    persistLocalGameRecovery();
    return true;
  } catch { return false; }
}
function offerLocalGameRecovery() {
  let snapshot;
  try { snapshot = JSON.parse(localStorage.getItem(LOCAL_GAME_RECOVERY_KEY) || 'null'); } catch { clearLocalGameRecovery(); return false; }
  if (!snapshot) return false;
  const validation = validateLocalGameRecoverySnapshot(snapshot);
  if (!validation.ok) { clearLocalGameRecovery(); toast('Bản khôi phục đã hỏng hoặc quá hạn; đã bỏ qua để tránh nạp sai ván cờ.'); return false; }
  if (typeof window.confirm !== 'function' || !window.confirm('Phát hiện ván cờ chưa kết thúc đã lưu trên thiết bị. Bạn có muốn khôi phục ván này không?')) { clearLocalGameRecovery(); return false; }
  if (!restoreLocalGameRecovery(snapshot)) { clearLocalGameRecovery(); toast('Không thể khôi phục ván cờ vì dữ liệu lưu không hợp lệ.'); return false; }
  toast('Đã khôi phục ván cờ từ thiết bị.', 'success');
  return true;
}
const CAPTURED_LABELS = Object.freeze({ p: 'Tốt', n: 'Mã', b: 'Tượng', r: 'Xe', q: 'Hậu' });
function renderCapturedMaterial(color) {
  const summary = summarizeCapturedMaterial(game.history({ verbose: true }));
  const victimColor = color === 'w' ? 'b' : 'w';
  const captured = summary.captured[color];
  const pieces = captured.map((type, index) => `<span class="captured-piece-icon captured-${type} ${victimColor === 'w' ? 'captured-white-piece' : 'captured-black-piece'}" title="${CAPTURED_LABELS[type]} bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn" aria-label="${CAPTURED_LABELS[type]} bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn" data-capture-index="${index}">${pieceSvgMarkup({ type, color: victimColor })}</span>`).join('');
  const advantage = summary.advantage[color];
  return `<div id="captured${color === 'w' ? 'White' : 'Black'}" class="captured-material-row" aria-label="Quân bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn"><span class="captured-piece-list">${pieces}</span>${advantage > 0 ? `<span class="captured-material-advantage" aria-label="Lợi thế vật chất ${advantage}">+${advantage}</span>` : ''}</div>`;
}
function updateCapturedMaterialDisplays() {
  const white = $('#capturedWhite');
  const black = $('#capturedBlack');
  if (white) white.outerHTML = renderCapturedMaterial('w');
  if (black) black.outerHTML = renderCapturedMaterial('b');
}


// ---- Screen-reader announcements, smooth piece slide, premove chip -------------------------
const PIECE_NAMES_VI = Object.freeze({ k: 'Vua', q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã', p: 'Tốt' });
function announceToScreenReader(message) {
  if (!message || visualSettings.announceMoves === false) return;
  let region = document.getElementById('srAnnouncer');
  if (!region) {
    region = document.createElement('div');
    region.id = 'srAnnouncer'; region.className = 'sr-only';
    region.setAttribute('role', 'status'); region.setAttribute('aria-live', 'polite'); region.setAttribute('aria-atomic', 'true');
    document.body.appendChild(region);
  }
  // Clearing first makes screen readers repeat identical consecutive messages.
  region.textContent = '';
  window.setTimeout(() => { region.textContent = message; }, 30);
}
/** Vietnamese description of a move, e.g. "Trắng nhập thành cánh Vua (O-O)". */
function describeMoveVi(move, mover) {
  if (!move) return '';
  const side = (mover || move.color) === 'w' ? 'Trắng' : 'Đen';
  const flags = String(move.flags || '');
  let text;
  if (flags.includes('k')) text = `${side} nhập thành cánh Vua (O-O)`;
  else if (flags.includes('q')) text = `${side} nhập thành cánh Hậu (O-O-O)`;
  else {
    text = `${side} đi ${PIECE_NAMES_VI[move.piece] || 'quân'} từ ${move.from} đến ${move.to}`;
    if (move.captured) text += `, ăn ${PIECE_NAMES_VI[move.captured] || 'quân'}`;
    if (move.promotion) text += `, phong thành ${PIECE_NAMES_VI[move.promotion] || 'quân'}`;
  }
  if (/#/.test(move.san || '')) text += ', chiếu hết';
  else if (/\+/.test(move.san || '')) text += ', chiếu';
  return text;
}
function announceMove(move, mover) { announceToScreenReader(describeMoveVi(move, mover)); }

let moveSlide = null;
function queueMoveSlide(move) {
  if (!move || !visualSettings.smoothAnimations) { moveSlide = null; return; }
  const slide = { from: move.from, to: move.to, fen: game.fen(), extra: null };
  const flags = String(move.flags || '');
  if (/[kq]/.test(flags)) {
    const kingSide = flags.includes('k');
    const rank = move.to[1];
    slide.extra = { from: `${kingSide ? 'h' : 'a'}${rank}`, to: `${kingSide ? 'f' : 'd'}${rank}` };
  }
  moveSlide = slide;
}
/** One-shot FLIP slide of the piece(s) that just moved. Uses the independent `translate` property. */
function runPendingMoveSlide() {
  const slide = moveSlide;
  moveSlide = null;
  if (!slide || slide.fen !== game.fen() || !visualSettings.smoothAnimations) return;
  if (window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches) return;
  for (const part of [slide, slide.extra]) {
    if (!part) continue;
    const fromCell = boardSquareMap.get(part.from);
    const toCell = boardSquareMap.get(part.to);
    const piece = toCell?.querySelector('.piece');
    if (!fromCell || !toCell || !piece || typeof piece.animate !== 'function') continue;
    const a = fromCell.getBoundingClientRect();
    const b = toCell.getBoundingClientRect();
    const dx = a.left - b.left, dy = a.top - b.top;
    if (!dx && !dy) continue;
    toCell.classList.add('sliding');
    const animation = piece.animate(
      [{ translate: `${dx}px ${dy}px` }, { translate: '0px 0px' }],
      { duration: part === slide ? 170 : 220, easing: 'cubic-bezier(.22,.8,.24,1)' }
    );
    const done = () => toCell.classList.remove('sliding');
    animation.addEventListener('finish', done); animation.addEventListener('cancel', done);
  }
}
function syncPremoveChip() {
  const status = $('#boardStatus');
  const anchor = status?.closest('.board-bottom');
  let chip = $('#premoveChip');
  const show = Boolean(anchor && premoveQueue.length && botThinking && isPremoveWindow());
  if (!show) { chip?.remove(); return; }
  if (!chip) {
    chip = document.createElement('button');
    chip.type = 'button'; chip.id = 'premoveChip'; chip.className = 'premove-chip';
    chip.addEventListener('click', () => clearPendingPremove({ repaint: true, silent: false }));
    anchor.insertAdjacentElement('afterend', chip);
  }
  chip.textContent = `✕ Hủy ${premoveQueue.length} nước đi trước`;
  chip.setAttribute('aria-label', `Hủy ${premoveQueue.length} nước đi trước`);
}

function renderBoard() {
  const board = $('#board');
  if (!board) return;
  const rows = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const targetMovesBySquare = new Map();
  for (const move of selectedTargets) {
    if (!targetMovesBySquare.has(move.to)) targetMovesBySquare.set(move.to, []);
    targetMovesBySquare.get(move.to).push(move);
  }
  const legalTargetSet = new Set(targetMovesBySquare.keys());
  const premoveActive = isPremoveWindow() && premoveQueue.length > 0;
  const boardGame = (premoveActive && getPremoveView()) || game;
  const premoveMarks = premoveActive ? premoveSquares(premoveQueue) : { from: new Set(), to: new Set() };
  const inCheck = boardGame === game && game.isCheck();
  const sideToMove = game.turn();
  // Visual effects for the move that was just played: capture ring, castling glow.
  const fxMove = game.history({ verbose: true }).slice(-1)[0] || null;
  const fxCaptureSq = fxMove && fxMove.captured ? fxMove.to : '';
  const fxCastle = new Map();
  if (fxMove && /[kq]/.test(String(fxMove.flags || ''))) {
    const kingSide = String(fxMove.flags).includes('k');
    const rank = fxMove.to[1];
    fxCastle.set(fxMove.to, kingSide ? 'fx-castle fx-castle-king' : 'fx-castle fx-castle-queen');
    fxCastle.set(`${kingSide ? 'f' : 'd'}${rank}`, 'fx-castle');
  }
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = boardGame.get(sq);
    const isLastFrom = visualSettings.highlightLastMove && lastMove && (lastMove.from === sq || lastMove.to === sq);
    // Blue ring for the move you made, red ring for the opponent's move (white = blue in two-player mode).
    const lastOwner = isLastFrom && fxMove ? ((mode === 'local' ? fxMove.color === 'w' : fxMove.color === humanColor) ? 'last-mine' : 'last-opp') : '';
    const lastLanding = isLastFrom && lastMove.to === sq ? 'last-landing' : '';
    const checkKing = inCheck && piece?.type === 'k' && piece.color === sideToMove;
    const isSelected = selected === sq;
    const isPremoveFrom = premoveMarks.from.has(sq);
    const isPremoveTo = premoveMarks.to.has(sq);
    const targetMoves = targetMovesBySquare.get(sq) || [];
    const capture = targetMoves.length && piece;
    const showTarget = visualSettings.showLegalMoves && legalTargetSet.has(sq);
    const classes = ['square', squareColor(sq), isSelected ? 'selected' : '', showTarget ? (capture ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-move' : '', lastOwner, lastLanding, checkKing ? 'in-check' : '', visualSettings.smoothAnimations && fxCaptureSq === sq ? 'fx-capture' : '', visualSettings.smoothAnimations ? (fxCastle.get(sq) || '') : '', isPremoveFrom ? 'premove-from' : '', isPremoveTo ? 'premove-to' : ''].filter(Boolean).join(' ');
    const pieceName = piece ? ({ k: 'vua', q: 'hậu', r: 'xe', b: 'tượng', n: 'mã', p: 'tốt' }[piece.type] || 'quân') : '';
    const glyph = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}" aria-hidden="true">${pieceGlyph(piece)}</span>` : '';
    const accessibleSquareLabel = `Ô ${sq}${piece ? `, ${piece.color === 'w' ? 'quân Trắng' : 'quân Đen'} ${pieceName}` : ''}${isSelected ? ', đang chọn' : ''}${legalTargetSet.has(sq) ? ', nước đi hợp lệ' : ''}`;
    // Rank labels stay on the left; every square on the bottom row gets its
    // file label. `files` is already reversed when the board is flipped.
    const coord = (colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : '') + (rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : '');
    html += `<button type="button" class="${classes}" data-square="${sq}" aria-label="${accessibleSquareLabel}">${glyph}${showTarget && targetMoves.length && !capture ? '<span class="move-dot"></span>' : ''}${coord}</button>`;
  }));
  board.innerHTML = html;
  updateCapturedMaterialDisplays();
  boardSquareMap = new Map($$('.square[data-square]', board).map(square => [square.dataset.square, square]));
  boardHighlightedSquares = new Set([...(selected ? [selected] : []), ...(visualSettings.showLegalMoves ? selectedTargets.map(move => move.to) : [])]);
  syncBoardLayout();
  wireBoardSquareClicks(board);
  wireBoardPointerDrag(board);
  renderHintArrow();
  syncAnnotationWidget();
  $('#boardStatus')?.replaceChildren(document.createTextNode(premoveQueue.length && botThinking ? `${describePremoveQueue(premoveQueue)}. Tự đi lần lượt khi tới lượt bạn; ${window.matchMedia?.('(pointer: coarse)')?.matches ? 'bấm nút Hủy bên dưới để xóa' : 'chuột phải, Esc hoặc nút Hủy để xóa'}.` : gameStarted ? positionStatus() : 'Sẵn sàng — nhấn Bắt đầu ván mới để chơi.'));
  syncPremoveChip();
  runPendingMoveSlide();
  const moveList = $('#moveList');
  if (moveList) renderMoveList(moveList);
  const fenBox = $('#fenText');
  if (fenBox) fenBox.textContent = game.fen();
  const pgnBox = $('#pgnText');
  if (pgnBox) pgnBox.textContent = game.pgn();
  const evalBox = $('#evalNumber');
  if (evalBox && !engineSearchActive) evalBox.textContent = '—';
  $('#turnChip')?.replaceChildren(document.createTextNode(game.turn() === 'w' ? 'Lượt Trắng' : 'Lượt Đen'));
  $('#resignBtn')?.toggleAttribute('disabled', !gameStarted || game.isGameOver() || Boolean(clockFlagged) || Boolean(manualGameResult));
  $('#offerDrawBtn')?.toggleAttribute('disabled', !gameStarted || game.isGameOver() || Boolean(clockFlagged) || Boolean(manualGameResult));
  const moveCount = $('#gameMoveCount');
  if (moveCount) moveCount.textContent = String(game.history().length);
  const statusText = $('#gameStatusText');
  if (statusText) statusText.textContent = !gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged || manualGameResult) ? 'Kết thúc' : premoveQueue.length && botThinking ? `Đã xếp ${premoveQueue.length} nước đi trước` : botThinking ? 'Bot đang tính' : 'Đang chơi';
  const openingLabel = $('#openingRecognition');
  if (openingLabel) {
    const recognized = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
    openingLabel.textContent = recognized ? `Khai cuộc nhận diện: ${recognized.name}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước');
  }
  renderClockDisplay();
  updateUndoRedoControls();
  renderAnalysisPanel();
  maybeShowPlayResultModal();
}
function updateUndoRedoControls() {
  const undo = $('#undoMove');
  const redo = $('#redoMove');
  if (undo) undo.disabled = !gameStarted || !game.history().length || botThinking || mode === 'lichess' || arenaRunning;
  if (redo) redo.disabled = !redoStack.length || botThinking || mode === 'lichess' || arenaRunning;
}
function positionStatus(chess = game) {
  if (chess === game && clockFlagged) return `Hết giờ — ${clockPlayerName(clockFlagged)} thua`;
  if (chess.isCheckmate()) return `Chiếu hết — ${chess.turn() === 'w' ? 'Đen' : 'Trắng'} thắng`;
  if (chess.isStalemate()) return 'Hòa do hết nước đi';
  if (chess.isThreefoldRepetition()) return 'Hòa do lặp lại thế cờ';
  if (chess.isInsufficientMaterial()) return 'Hòa do không đủ quân chiếu hết';
  if (chess.isDraw()) return 'Ván cờ hòa';
  return `${chess.turn() === 'w' ? 'Trắng' : 'Đen'} đang đi${chess.isCheck() ? ' — đang bị chiếu!' : ''}`;
}
/** One notation cell. Castling (O-O / O-O-O) is monospaced and never wraps; the latest ply is marked. */
function moveSanCell(san, isLast = false) {
  const text = String(san ?? '');
  const classes = ['move-san', /^O-O(-O)?[+#]?$/.test(text) ? 'is-castle' : '', isLast ? 'is-last' : ''].filter(Boolean).join(' ');
  return `<span class="${classes}"${isLast ? ' aria-current="true"' : ''}>${esc(text)}</span>`;
}
function renderMoveList(element) {
  const history = game.history();
  if (!history.length) { element.innerHTML = '<div class="empty-state">Nước đi của bạn sẽ xuất hiện ở đây.</div>'; return; }
  let rows = '';
  for (let i = 0; i < history.length; i += 2) {
    rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2) + 1}.</span>${moveSanCell(history[i], i === history.length - 1)}${moveSanCell(history[i + 1] || '…', i + 1 === history.length - 1)}</div>`;
  }
  element.innerHTML = rows;
  element.scrollTop = element.scrollHeight;
}
function isPremoveWindow() {
  return Boolean(gameStarted && botThinking && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) &&
    !manualGameResult && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor);
}
/** Virtual board with every queued premove already played (cached per position + queue). */
function getPremoveView() {
  if (!premoveQueue.length || !isPremoveWindow()) return null;
  const key = `${game.fen()}|${premoveQueue.map(item => `${item.from}${item.to}${item.promotion || ''}`).join(',')}`;
  if (premoveViewCache.key !== key) premoveViewCache = { key, chess: buildPremovePosition(game, humanColor, premoveQueue, Chess) };
  return premoveViewCache.chess;
}
/** The position the player is looking at: the virtual premove board while premoving, else the real game. */
function boardPositionForInput() {
  return (isPremoveWindow() && getPremoveView()) || game;
}
function clearPendingPremove({ repaint = false, silent = true } = {}) {
  const count = premoveQueue.length;
  premoveQueue = [];
  premoveViewCache = { key: '', chess: null };
  if (count) {
    if (!silent) toast(count === 1 ? 'Đã hủy nước đi trước.' : `Đã hủy ${count} nước đi trước.`);
    announceToScreenReader(count === 1 ? 'Đã hủy nước đi trước.' : `Đã hủy ${count} nước đi trước.`);
  }
  if (repaint && count && currentView === 'play') renderBoard();
  return count > 0;
}
function queuePremove(from, to, promotion = null) {
  if (!isPremoveWindow()) return false;
  const next = appendPremove(game, humanColor, Chess, premoveQueue, from, to, promotion);
  if (!next) return false;
  premoveQueue = next;
  premoveViewCache = { key: '', chess: null };
  selected = null; selectedTargets = [];
  if (currentView === 'play') renderBoard();
  announceToScreenReader(`Đã xếp nước đi trước ${from} đến ${to}. Tổng ${premoveQueue.length} nước.`);
  return true;
}
/**
 * Play the first queued premove on the real board. A queued move that is no longer legal (the
 * opponent captured or blocked it) cancels the whole queue, like chess.com. Returns true if played.
 */
function executeNextPremove() {
  const queue = premoveQueue;
  premoveQueue = [];
  premoveViewCache = { key: '', chess: null };
  selected = null; selectedTargets = [];
  if (!queue.length || !gameStarted || game.isGameOver() || clockFlagged || manualGameResult || game.turn() !== humanColor) return false;
  const { move, rest, cancelled } = takeNextPremove(game, queue, humanColor);
  if (!move) {
    const first = cancelled[0];
    toast(`Đối thủ đi khác nên nước đi trước ${first.from} → ${first.to}${cancelled.length > 1 ? ` và ${cancelled.length - 1} nước kế tiếp` : ''} đã bị hủy.`);
    announceToScreenReader('Các nước đi trước đã bị hủy vì đối thủ đi khác.');
    return false;
  }
  premoveQueue = rest; // keep the remaining premoves armed for the opponent's next reply
  playMove(move.from, move.to, move.promotion, { slide: false });
  return true;
}
function handlePremoveSquareClick(square) {
  const view = boardPositionForInput();
  if (selected && selectedTargets.some(move => move.to === square)) {
    const choices = selectedTargets.filter(move => move.to === square);
    const needsChoice = choices.some(move => move.promotion);
    const from = selected;
    if (needsChoice && !visualSettings.autoQueen) {
      choosePromotion(humanColor).then(type => { if (type && isPremoveWindow()) queuePremove(from, square, type); });
      return;
    }
    const promotion = needsChoice ? 'q' : null;
    if (queuePremove(from, square, promotion)) return;
  }
  const piece = view.get(square);
  if (piece && piece.color === humanColor) {
    selected = square;
    selectedTargets = getPremoveLegalMoves(game, humanColor, Chess, square, premoveQueue);
  } else if (!selected && isPremoveSquare(premoveQueue, square)) {
    clearPendingPremove({ silent: false }); selected = null; selectedTargets = []; renderBoard(); return;
  } else {
    selected = null; selectedTargets = [];
  }
  renderBoard();
}
function handleSquareClick(square) {
  if (!gameStarted) { toast('Nhấn “Bắt đầu ván mới” để bắt đầu trận.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (arenaRunning) { toast('Đấu trường AI đang dùng Stockfish; hãy dừng trận trước khi chơi bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged) return;
  if (isPremoveWindow()) { handlePremoveSquareClick(square); return; }
  if (botThinking) return;
  if (mode !== 'local' && game.turn() !== humanColor) { toast(mode === 'lichess' ? 'Đang chờ đối thủ đi.' : 'Đang đến lượt bot.'); return; }
  const piece = game.get(square);
  if (selected && selectedTargets.some(m => m.to === square)) {
    const choices = selectedTargets.filter(m => m.to === square);
    const promotion = choices.find(m => m.promotion)?.promotion;
    if (promotion && visualSettings.autoQueen) {
      playMove(selected, square, 'q');
    } else if (promotion) {
      // Capture the origin and position before opening the async chooser. Never read the
      // mutable `selected` variable when the modal resolves.
      const request = { from: selected, to: square, epoch: gameEpoch, fen: game.fen() };
      const mover = game.turn();
      choosePromotion(mover).then(type => {
        if (!type) return;
        if (!isMoveContextCurrent(request, { epoch: gameEpoch, fen: game.fen() })) {
          toast('Thế cờ đã thay đổi; nước phong cấp cũ đã bị hủy.');
          return;
        }
        playMove(request.from, request.to, type);
      });
    } else playMove(selected, square);
    return;
  }
  if (piece && (mode === 'local' || piece.color === game.turn())) {
    selected = square;
    selectedTargets = game.moves({ square, verbose: true });
  } else {
    selected = null;
    selectedTargets = [];
  }
  const board = $('#board');
  if (board && boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets);
  else renderBoard();
}
function choosePromotion(color) {
  return new Promise(resolve => {
    const root = $('#modalRoot');
    root.innerHTML = `<div class="modal-backdrop"><div class="modal-card"><h3>Phong cấp tốt</h3><p>Chọn quân muốn phong cấp.</p><div class="promotion-options">${['q','r','b','n'].map(type => `<button data-promotion="${type}" class="promotion-choice ${color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph({ color, type })}<small>${({ q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã' })[type]}</small></button>`).join('')}</div><button id="cancelPromotion" class="secondary-btn full-width">Hủy</button></div></div>`;
    $$('[data-promotion]', root).forEach(button => button.addEventListener('click', () => { root.innerHTML = ''; resolve(button.dataset.promotion); }));
    $('#cancelPromotion', root).addEventListener('click', () => { root.innerHTML = ''; resolve(null); });
  });
}
function playMove(from, to, promotion, options = {}) {
  if (!gameStarted) { toast('Bắt đầu ván mới trước khi đi quân.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (clockFlagged) { toast('Ván cờ đã kết thúc do hết giờ.'); return; }
  tickClock();
  if (clockFlagged) return;
  stopAnalysis(true);
  const mover = game.turn();
  const plyBeforeMove = game.history().length;
  const clockBeforeMove = captureMoveClockSnapshot();
  try {
    const move = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!move) return;
    recordClockSnapshot(moveClockSnapshots, plyBeforeMove, clockBeforeMove);
    redoStack = [];
    playBoardSound(move, game, settings.soundEnabled);
    recordDailyEvent('make_move');
    if (move.captured) recordDailyEvent('capture_piece');
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) recordDailyEvent('castle');
    if (move.promotion) recordDailyEvent('promote');
    if (game.isCheck()) recordDailyEvent('check_king');
    lastHintMove = null;
    boardAnnotations = []; annotationTool = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: move.from, to: move.to };
    if (options.slide !== false) queueMoveSlide(move);
    announceMove(move, mover);
    selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null;
    if (mode === 'lichess') submitLichessMove(`${move.from}${move.to}${move.promotion || ''}`);
    persistLocalGameRecovery();
    onMoveComplete();
  } catch (error) { playGameSound('illegal', settings.soundEnabled); toast(`Nước đi không hợp lệ: ${error.message}`); }
}
function onMoveComplete() {
  const isOver = game.isGameOver();
  const needsBot = !isOver && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor;
  // Set this before rendering so a move only rebuilds the view once rather than twice.
  botThinking = needsBot;
  if (isOver || currentView !== 'play') renderView();
  else renderBoard();
  if (isOver) {
    botThinking = false;
    stopClock();
    const outcome = game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.';
    // Checkmate already plays its own board sound; add the win/lose/draw jingle after it.
    const humanWon = game.isCheckmate() && game.turn() !== humanColor;
    const jingle = !game.isCheckmate() ? 'draw' : (mode === 'local' || humanWon) ? 'win' : 'lose';
    setTimeout(() => playGameSound(jingle, settings.soundEnabled), 520);
    toast(outcome, 'success');
    return;
  }
  if (needsBot) {
    scheduleBotMove(220);
  }
  if (currentView === 'play') queryOpeningExplorer(false);
}
function resignCurrentGame() {
  if (!gameStarted || game.isGameOver() || clockFlagged || manualGameResult) return;
  if (mode === 'lichess') { toast('Đầu hàng trong ván Lichess phải thực hiện trên dịch vụ Lichess.'); return; }
  const resigning = mode === 'local' ? game.turn() : humanColor;
  const winner = resigning === 'w' ? 'Đen' : 'Trắng';
  if (typeof window.confirm === 'function' && !window.confirm(`Đầu hàng? ${winner} sẽ thắng ván này.`)) return;
  cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
  premoveQueue = []; selected = null; selectedTargets = [];
  gameEpoch += 1; botThinking = false; queuedMainEngineMove = false;
  manualGameResult = {
    token: resigning === 'w' ? '0-1' : '1-0',
    title: `Đầu hàng — ${winner} thắng`,
    detail: `${resigning === 'w' ? 'Trắng' : 'Đen'} đã đầu hàng. Lịch sử nước đi được giữ nguyên để xem lại.`,
    reason: 'resignation'
  };
  stopClock(); persistLocalGameRecovery(); renderView();
}

function offerDrawCurrentGame() {
  if (!gameStarted || game.isGameOver() || clockFlagged || manualGameResult) {
    toast('Ván cờ chưa bắt đầu hoặc đã kết thúc.');
    return;
  }
  if (mode === 'lichess') {
    toast('Xin hòa trong ván Lichess phải thực hiện trên giao diện Lichess.');
    return;
  }
  if (['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode)) {
    if (botThinking) {
      toast('Hãy đợi đối thủ đi nước xong trước khi xin hòa.');
      return;
    }
    const isMaterialDrawn = game.isInsufficientMaterial();
    let botAccepts = false;
    let reasonMsg = '';
    
    if (isMaterialDrawn || game.isThreefoldRepetition() || game.isStalemate()) {
      botAccepts = true;
      reasonMsg = 'Thế cờ hòa theo luật cờ vua.';
    } else if (analysisVariants.length && Number.isFinite(analysisVariants[0]?.scoreWhiteCp)) {
      const cp = analysisVariants[0].scoreWhiteCp;
      const userAdvantage = humanColor === 'w' ? cp : -cp;
      if (userAdvantage >= 180) {
        botAccepts = true;
        reasonMsg = 'Đối thủ nhận thấy bạn đang có ưu thế và đồng ý hòa.';
      } else if (userAdvantage <= -160) {
        botAccepts = false;
        reasonMsg = 'Bot từ chối hòa: Thế cờ đang có ưu thế nghiêng về bot!';
      } else {
        botAccepts = true;
        reasonMsg = 'Thế cờ cân bằng, bot chấp nhận lời đề nghị hòa!';
      }
    } else {
      const mat = summarizeCapturedMaterial(game);
      const diff = Math.abs((mat.whiteCount || 0) - (mat.blackCount || 0));
      if (diff <= 2) {
        botAccepts = true;
        reasonMsg = 'Thế cờ cân bằng, bot đồng ý chia điểm hòa!';
      } else {
        botAccepts = false;
        reasonMsg = 'Đối thủ từ chối: Lực lượng chưa cho phép thỏa thuận hòa.';
      }
    }

    if (botAccepts) {
      cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
      premoveQueue = []; selected = null; selectedTargets = [];
      gameEpoch += 1; botThinking = false; queuedMainEngineMove = false;
      manualGameResult = {
        token: '1/2-1/2',
        title: 'Hòa cờ — Thỏa thuận',
        detail: `Hai bên thỏa thuận hòa ván đấu (${reasonMsg}).`,
        reason: 'draw-agreement'
      };
      stopClock();
      playGameSound('game-end', settings.soundEnabled);
      maybeArchiveCompletedGame();
      toast(`Đối thủ đồng ý: ${reasonMsg}`, 'success');
      persistLocalGameRecovery();
      renderView();
      maybeShowPlayResultModal();
    } else {
      toast(reasonMsg, 'warning');
    }
  } else if (mode === 'local') {
    const agreed = (typeof window.confirm === 'function') ? window.confirm('Bên đối thủ có chấp nhận hòa cờ không?') : true;
    if (agreed) {
      stopClock();
      playGameSound('game-end', settings.soundEnabled);
      manualGameResult = {
        token: '1/2-1/2',
        title: 'Hòa cờ — Thỏa thuận',
        detail: 'Hai người chơi thỏa thuận chia điểm hòa ván đấu.',
        reason: 'draw-agreement'
      };
      maybeArchiveCompletedGame();
      toast('Ván đấu kết thúc hòa do hai bên đồng ý.', 'success');
      persistLocalGameRecovery();
      renderView();
      maybeShowPlayResultModal();
    } else {
      toast('Đối thủ từ chối đề nghị hòa.', '');
    }
  } else {
    toast('Chế độ này không hỗ trợ xin hòa trực tiếp.', '');
  }
}

function freshGame({ startFen = null } = {}) {
  closeResultModal();
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi tạo ván khác.'); return; }
  moveClockSnapshots = []; redoStack = [];
  historyRestoreSignature = ''; reviewReplayState = null;
  if (colorChoice === 'random' && mode !== 'local' && mode !== 'lichess') {
    humanColor = Math.random() < 0.5 ? 'w' : 'b'; orientation = humanColor;
    toast(`🎲 Ngẫu nhiên: bạn cầm quân ${humanColor === 'w' ? 'Trắng — đi trước' : 'Đen — bot đi trước'}.`);
  }
    cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  premoveQueue = [];
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  currentGameId = `g-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  ratedGameSignature = '';
  manualGameResult = null;
  if (mode === 'stockfish' && randomBotEloEnabled) {
    settings.botStrengthMode = 'elo'; settings.botElo = 500 + Math.floor(Math.random() * 28) * 100; settings.botSkill = 20; saveSettings();
  }
  if (mode === 'lichess') mode = 'stockfish';
  stopOnlineStream();
  game = startFen ? new Chess(startFen) : new Chess();
  gameStartFen = game.fen();
  completedReviewRows = []; reviewStatus = '';
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  selected = null; selectedTargets = []; premoveQueue = []; lastMove = null; lastHintMove = null; boardAnnotations = []; annotationTool = null; botThinking = false; currentOpening = null;
  resetClock(settings.clockPreset);
  const returningToPlay = currentView !== 'play';
  currentView = 'play';
  persistLocalGameRecovery();
  renderView();
  if (returningToPlay) window.scrollTo(0, 0);
  if (['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true;
    scheduleBotMove(250);
  }
}
function undoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi hoàn tác.'); return; }
  if (mode === 'lichess') { toast('Không thể tự hoàn tác ván Lichess; hãy dùng chức năng takeback trên Lichess.'); return; }
  if (!game.history().length || botThinking) return;
  // Apply elapsed time before taking a snapshot. Never call resetClock from undo.
  tickClock();
  const priorPlyCount = game.history().length;
  const clockAtUndo = captureMoveClockSnapshot();
  const manualResultAtUndo = manualGameResult ? { ...manualGameResult } : null;
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  const removedMoves = [];
  const first = game.undo();
  if (first) removedMoves.unshift({ from: first.from, to: first.to, promotion: first.promotion || null, san: first.san });
  if (mode !== 'local' && game.history().length && game.turn() !== humanColor) {
    const second = game.undo();
    if (second) removedMoves.unshift({ from: second.from, to: second.to, promotion: second.promotion || null, san: second.san });
  }
  if (!removedMoves.length) return;
  const targetPlyCount = game.history().length;
  const savedClockHistory = cloneClockHistoryRange(moveClockSnapshots, targetPlyCount, priorPlyCount);
  redoStack.push({
    moves: removedMoves,
    clockSnapshot: clockAtUndo,
    clockHistory: savedClockHistory,
    manualGameResult: manualResultAtUndo,
    lastMove: lastMove ? { ...lastMove } : null,
    currentOpening
  });
  moveClockSnapshots.length = targetPlyCount;
  manualGameResult = null;
  premoveQueue = [];
  gameEpoch += 1;
  completedReviewRows = []; reviewStatus = '';
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null; lastHintMove = null;
  if (!restoreMoveClockSnapshot(moveClockSnapshots[targetPlyCount])) rebaseClockAfterUndoWithoutSnapshot();
  persistLocalGameRecovery();
  renderView();
  toast(`Đã hoàn tác ${removedMoves.length === 1 ? '1 nửa nước đi' : '1 lượt của bạn và bot'}. Đồng hồ đã được khôi phục.`, 'success');
}
function redoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi làm lại.'); return; }
  if (mode === 'lichess') { toast('Không thể làm lại nước trong ván trực tuyến.'); return; }
  if (botThinking) { toast('Đợi bot hoàn tất nước hiện tại rồi hãy làm lại.'); return; }
  const record = redoStack[redoStack.length - 1];
  if (!record || !record.moves?.length) { toast('Không còn nước đi nào để làm lại.'); return; }
  // Validate the complete redo branch on a clone before changing the active game.
  let candidate;
  try {
    candidate = new Chess(game.fen());
    for (const move of record.moves) { if (!candidate.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) })) throw new Error('Redo move is no longer legal.'); }
  } catch {
    toast('Không thể làm lại nhánh nước đi này trong thế cờ hiện tại.');
    return;
  }
  redoStack.pop();
  cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
  const startPly = game.history().length;
  for (let i = 0; i < record.moves.length; i += 1) {
    const move = record.moves[i];
    game.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const snapshot = record.clockHistory?.[i];
    if (snapshot) recordClockSnapshot(moveClockSnapshots, startPly + i, snapshot);
  }
  moveClockSnapshots.length = startPly + record.moves.length;
  gameEpoch += 1; premoveQueue = []; botThinking = false; queuedMainEngineMove = false;
  manualGameResult = record.manualGameResult ? { ...record.manualGameResult } : null;
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; lastHintMove = null; boardAnnotations = []; annotationTool = null;
  currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || record.currentOpening || null;
  if (!restoreMoveClockSnapshot(record.clockSnapshot)) rebaseClockAfterUndoWithoutSnapshot();
  if (game.isGameOver() || clockFlagged || manualGameResult) clockState.running = false;
  persistLocalGameRecovery();
  renderView();
  toast('Đã làm lại nước đi và khôi phục đồng hồ.', 'success');
  if (!game.isGameOver() && !clockFlagged && !manualGameResult && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true; renderView(); scheduleBotMove(220);
  }
}

function updateEvaluationMeter(scoreType, scoreValue, sideToMove) {
  const fill = $('#evaluationMeterWhite');
  const meter = $('#evaluationMeter');
  if (!fill || !meter) return;
  const whiteCp = scoreSideToWhiteCentipawns(Number(scoreValue), sideToMove, scoreType);
  if (!Number.isFinite(whiteCp)) return;
  // Smoothly map centipawns to a bounded share. This is a visual cue, not win probability.
  const share = Math.max(4, Math.min(96, 50 + 46 * Math.tanh(whiteCp / 500)));
  fill.style.width = `${share.toFixed(1)}%`;
  meter.setAttribute('aria-label', `Thanh đánh giá: ${whiteCp > 0 ? 'Trắng hơn' : whiteCp < 0 ? 'Đen hơn' : 'cân bằng'}`);
}

function setEngineStatusLabel(message, state = 'loading', title = '') {
  const status = $('#engineStatus');
  if (!status) return;
  const safeMessage = String(message || 'Stockfish');
  status.innerHTML = `<span class="engine-status-knight" aria-hidden="true">♞</span><i aria-hidden="true"></i><span class="engine-status-copy">${esc(safeMessage)}</span>`;
  status.classList.toggle('ready', state === 'ready');
  status.classList.toggle('failed', state === 'failed');
  status.classList.toggle('loading', state === 'loading');
  status.dataset.engineState = state;
  status.title = title || `${safeMessage}. Chạm để kiểm tra hoặc tải lại Stockfish.`;
  status.setAttribute('aria-label', `Stockfish: ${safeMessage}. Chạm để kiểm tra hoặc tải lại engine.`);
}

function retireStockfishWorker(message = 'Stockfish không khả dụng.') {
  if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
  if (stockfishWarmupTimer) { clearTimeout(stockfishWarmupTimer); stockfishWarmupTimer = null; }
  waitingForStockfishMove = null;
  // Terminate rather than only sending `stop`: a late bestmove from a timed-out
  // search must never be mistaken for the next request's result.
  const retired = engineWorker;
  engineWorker = null;
  try { retired?.terminate(); } catch {}
  engineReady = false;
  engineFailed = true;
  engineHealthState = failEngineHealth(engineHealthState, message);
  engineUciInitialized = false;
  engineSearchActive = false;
  engineStopPending = false;
  if (engineStopTimeout) { clearTimeout(engineStopTimeout); engineStopTimeout = null; }
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  cancelMainEngineWatchdog();
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  analysisActive = false;
  if (pendingHintRequest) { clearTimeout(pendingHintRequest.timeout); pendingHintRequest = null; }
  if (pendingEngineRequest) {
    const pending = pendingEngineRequest;
    pendingEngineRequest = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (pendingCoachAnalysis) {
    const pending = pendingCoachAnalysis;
    pendingCoachAnalysis = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  if (reviewSession) {
    reviewSession = null;
    reviewStatus = message;
    updateReviewPanel();
  }
  setEngineStatusLabel('Engine lỗi · chạm để tải lại', 'failed', message);
  renderAnalysisPanel();
  console.warn('[Cờ Vua ViLa] Stockfish worker retired:', message);
}

function retryStockfishEngine() {
  if (engineStopPending || engineSearchActive || botThinking || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || reviewSession) {
    toast('Đợi tác vụ cờ hiện tại kết thúc rồi mới tải lại engine.');
    return;
  }
  if (engineWorker && engineReady && !engineFailed) {
    toast(describeEngineHealth(engineHealthState));
    return;
  }
  if (engineWorker && !engineReady && !engineFailed) {
    toast('Stockfish đang khởi tạo; chờ thêm một chút trước khi thử lại.');
    return;
  }
  retireStockfishWorker('Đang tải lại Stockfish…');
  engineFailed = false;
  setEngineStatusLabel('Đang tải Stockfish…', 'loading', 'Đang khởi tạo engine; tài nguyên engine phải có trong bản build.');
  engineInitFallbacksTried = new Set();
  initEngine();
  toast('Đang thử khởi tạo lại Stockfish…');
}

function fallbackEngineLabel(profile) {
  if (profile === 'full-single') return 'Stockfish Full';
  if (profile === 'lite-single') return 'Stockfish Lite';
  if (profile === 'sf10') return 'Stockfish 10';
  return 'Stockfish ASM-JS';
}
function tryEngineInitFallback(failedProfile) {
  const nextProfile = nextEngineFallback(failedProfile);
  if (!nextProfile || engineInitFallbacksTried.has(nextProfile)) return false;
  engineInitFallbacksTried.add(nextProfile);
  if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
  const previous = engineWorker;
  engineWorker = null;
  try { previous?.terminate(); } catch {}
  engineReady = false;
  engineUciInitialized = false;
  engineFailed = false;
  engineSearchActive = false;
  const label = fallbackEngineLabel(nextProfile);
  setEngineStatusLabel(`Thử ${label} dự phòng…`, 'loading', `Engine trước không khởi tạo được; đang thử ${label}.`);
  console.warn(`[Cờ Vua ViLa] Stockfish init fallback: ${failedProfile} -> ${nextProfile}`);
  initEngine({ forceLite: nextProfile === 'lite-single', forceAsm: nextProfile === 'asm', isFallback: true });
  return true;
}
function initEngine({ forceLite = false, forceAsm = false, isFallback = false } = {}) {
  let selectedEngine = 'lite-single';
  try {
    if (!isFallback) engineInitFallbacksTried = new Set();
    selectedEngine = forceAsm ? 'asm' : forceLite ? 'lite-single' : resolveEngineProfile(settings.botEngine, { deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency });
    engineInitFallbacksTried.add(selectedEngine);
    const priorAttempt = engineHealthState?.profile === 'unknown' ? 0 : Math.max(0, Number(engineHealthState?.attempt) || 0);
    engineHealthState = createEngineHealthState(selectedEngine, Date.now(), priorAttempt + 1);
    const engineFile = engineAssetFile(selectedEngine);
    const enginePath = new URL(`${import.meta.env.BASE_URL}engine/${engineFile}`, window.location.href).href;
    const worker = new Worker(enginePath);
    engineWorker = worker;
    worker.onmessage = event => {
      // A retired worker may have a queued message task; never let it mutate the
      // state or feed a result to the newly-created worker session.
      if (engineWorker !== worker) return;
      const output = typeof event.data === 'string' ? event.data : String(event.data?.data || event.data || '');
      // Stockfish 10/older asm.js ports may bundle several UCI lines into one
      // MessageEvent. Process every line separately or uciok/readyok can be missed.
      for (const line of splitUciOutput(output)) {
        engineHealthState = observeEngineLine(engineHealthState, line);
        if (/^uciok\s*$/i.test(line) && !engineUciInitialized) {
          engineUciInitialized = true;
          engineReady = false;
          // Configure memory and threads once. Single-thread engines may ignore Threads.
          engineWorker.postMessage('setoption name Threads value 1');
          // Stockfish 10 is a pure asm.js build with a small heap; keep its hash table modest.
          engineWorker.postMessage(`setoption name Hash value ${selectedEngine === 'sf10' ? Math.min(16, preferredHashMb()) : preferredHashMb()}`);
          engineWorker.postMessage('setoption name MultiPV value 1');
          engineWorker.postMessage('isready');
        }
        if (/^readyok\s*$/i.test(line) && engineHealthState?.status === 'ready' && engineUciInitialized && !engineFailed) {
          if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
          engineReady = true;
          const shownName = selectedEngine === 'full-single' ? '19 Full' : selectedEngine === 'asm' ? '19 ASM-JS dự phòng' : selectedEngine === 'sf10' ? '10' : '19 Lite';
          const startupMs = engineStartupDurationMs(engineHealthState);
          const healthDetail = describeEngineHealth(engineHealthState);
          setEngineStatusLabel(`Stockfish ${shownName} · sẵn sàng`, 'ready', `${healthDetail}${startupMs != null ? ` Thời gian khởi động: ${(startupMs / 1000).toFixed(1)} giây.` : ''} ${selectedEngine === 'asm' ? 'ASM-JS tương thích hơn nhưng có thể chậm hơn WASM.' : ''} Chạm để xem trạng thái hoặc tải lại khi gặp lỗi.`);
          runEngineQueue();
          if (waitingForStockfishMove) {
            const waiting = waitingForStockfishMove;
            waitingForStockfishMove = null;
            if (stockfishWarmupTimer) { clearTimeout(stockfishWarmupTimer); stockfishWarmupTimer = null; }
            if (waiting.epoch === gameEpoch && waiting.fen === game.fen() && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) scheduleBotMove(0);
          }
        }
        if (/\binfo\b/.test(line) && analysisActive) receiveAnalysisInfo(line);
        if (/\binfo\b/.test(line) && reviewSession?.waiting) receiveReviewInfo(line);
        if (/\binfo\b/.test(line) && pendingCoachAnalysis) receiveCoachAnalysisInfo(line);
        if (/^info\b.*\bnps\b/.test(line)) recordStockfishSpeed(line);
        // Arena style profiles choose only among legal candidate first moves reported by Stockfish MultiPV.
        // Scores are from the side-to-move perspective; the latest/deepest line replaces older data.
        const arenaPvMatch = line.match(/^info\b.*?\bdepth\s+(\d+)\b.*?\bmultipv\s+(\d+)\b.*?\bscore\s+(cp|mate)\s+(-?\d+).*?\bpv\s+([a-h][1-8][a-h][1-8][qrbn]?)/i);
        if (arenaPvMatch && pendingEngineRequest?.multiPv > 1) {
          const depthValue = Number(arenaPvMatch[1]);
          const pvIndex = Number(arenaPvMatch[2]);
          if (pvIndex >= 1 && pvIndex <= pendingEngineRequest.multiPv) {
            const rawScore = Number(arenaPvMatch[4]);
            const score = arenaPvMatch[3] === 'mate' ? Math.sign(rawScore || 1) * (30000 - Math.min(999, Math.abs(rawScore))) : rawScore;
            const old = pendingEngineRequest.candidates.get(pvIndex);
            if (!old || depthValue >= old.depth) pendingEngineRequest.candidates.set(pvIndex, { multipv: pvIndex, uci: arenaPvMatch[5].toLowerCase(), score, depth: depthValue });
          }
        }
        const scoreMatch = line.match(/\bscore (cp|mate) (-?\d+)/);
        if (scoreMatch && engineSearchActive && !analysisActive && !reviewSession) {
          const rawScore = Number(scoreMatch[2]);
          const whiteScore = rawScore * (game.turn() === 'b' ? -1 : 1);
          const score = scoreMatch[1] === 'mate'
            ? `${whiteScore < 0 ? '-' : ''}M${Math.abs(whiteScore)}`
            : `${whiteScore > 0 ? '+' : ''}${(whiteScore / 100).toFixed(1)}`;
          const label = $('#evalNumber');
          if (label) label.textContent = score;
          updateEvaluationMeter(scoreMatch[1], rawScore, game.turn());
        }
        const bestMatch = line.match(/\bbestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000)/i);
        if (bestMatch) {
          cancelMainEngineWatchdog();
          const uci = bestMatch[1].toLowerCase();
          if (engineStopPending) {
            // Consume the terminal line for the cancelled search; never treat it as the next request.
            engineStopPending = false;
            engineSearchActive = false;
            if (engineStopTimeout) { clearTimeout(engineStopTimeout); engineStopTimeout = null; }
            mainEngineSearchEpoch = -1;
            mainEngineSearchFen = '';
            renderAnalysisPanel();
            if (queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged) {
              queuedMainEngineMove = false;
              scheduleBotMove(0);
            }
            return;
          }
          engineSearchActive = false;
          if (reviewSession?.waiting) { finishReviewPosition(false, uci === '0000' ? null : uci); return; }
          if (pendingEngineRequest) {
            const pending = pendingEngineRequest;
            pendingEngineRequest = null;
            clearTimeout(pending.timeout);
            try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
            if (uci === '0000') {
              pending.reject(new Error('Stockfish không trả về nước đi trong thế cờ này.'));
            } else if (pending.multiPv > 1) {
              const candidates = [...pending.candidates.values()].sort((a, b) => a.multipv - b.multipv);
              if (!candidates.some(item => item.uci === uci)) candidates.unshift({ multipv: 1, uci, score: candidates[0]?.score ?? 0, depth: 0 });
              pending.resolve(candidates.slice(0, pending.multiPv));
            } else pending.resolve(uci);
            return;
          }
          if (pendingHintRequest) {
            const hint = pendingHintRequest;
            pendingHintRequest = null;
            clearTimeout(hint.timeout);
            mainEngineSearchEpoch = -1;
            mainEngineSearchFen = '';
            const resumeQueuedMainMove = queuedMainEngineMove;
            queuedMainEngineMove = false;
            if (hint.epoch === gameEpoch && hint.fen === game.fen()) {
              const move = hint.legal.find(candidate => uciForMove(candidate) === uci);
              if (move) setHintSuggestion(move, 'Stockfish');
              toast(move ? `Gợi ý Stockfish: ${move.san} (${uci})` : 'Stockfish chưa trả về được gợi ý hợp lệ.', move ? 'success' : '');
              if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
              if ($('#evalNumber')) $('#evalNumber').textContent = '—';
            }
            if (resumeQueuedMainMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) {
              scheduleBotMove(0);
            }
            return;
          }
          if (pendingCoachAnalysis) {
            const request = pendingCoachAnalysis;
            pendingCoachAnalysis = null;
            clearTimeout(request.timeout);
            engineSearchActive = false;
            mainEngineSearchEpoch = -1;
            mainEngineSearchFen = '';
            try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
            if (request.epoch !== gameEpoch || request.fen !== game.fen()) request.reject(new Error('Thế cờ đã thay đổi trong khi Stockfish phân tích; hãy gửi lại câu hỏi.'));
            else request.resolve([...request.variants.values()].sort((a, b) => a.multipv - b.multipv));
            return;
          }
          if (analysisActive) {
            const currentSession = isCurrentAnalysisSession({ active: analysisActive, sessionFen: analysisFen, currentFen: game.fen(), sessionEpoch: analysisEpoch, currentEpoch: gameEpoch });
            analysisActive = false;
            if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
            analysisFen = '';
            analysisEpoch = -1;
            if (!currentSession) { analysisVariants = []; analysisVisible = false; }
            try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
            renderAnalysisPanel();
            return;
          }
          const searchedEpoch = mainEngineSearchEpoch;
          const searchedFen = mainEngineSearchFen;
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          if (searchedEpoch !== gameEpoch || !searchedFen || searchedFen !== game.fen()) {
            if (queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && game.turn() !== humanColor) {
              queuedMainEngineMove = false;
              scheduleBotMove(0);
            }
            return;
          }
          if (botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver()) {
            botThinking = false;
            applyUciMove(uci);
          }
        }
      }
    };
    worker.onerror = event => {
      if (engineWorker !== worker) return;
      // Only switch engines during startup. Runtime failures go through the normal
      // cleanup path so pending searches cannot leak into a second worker.
      if (!engineReady && tryEngineInitFallback(selectedEngine)) return;
      failEngine(selectedEngine === 'asm'
        ? `Stockfish ASM-JS cũng không khởi tạo được. Hãy chạy build sạch và kiểm tra tệp engine trong APK. ${String(event?.message || '').slice(0, 120)}`
        : `Không tải được tệp Stockfish ${selectedEngine === 'full-single' ? 'Full' : selectedEngine === 'sf10' ? '10' : 'Lite'}. ${String(event?.message || '').slice(0, 120)} Đang kiểm tra engine và có thể thử lại.`);
    };
    worker.postMessage('uci');
    // Full can take much longer to load; Lite uses a stricter watchdog. ASM has no WASM.
    engineInitTimeout = setTimeout(() => {
      if (engineWorker !== worker || engineReady || engineFailed) return;
      engineHealthState = failEngineHealth(engineHealthState, 'Hết thời gian chờ bắt tay UCI.');
      if (tryEngineInitFallback(selectedEngine)) return;
      failEngine(`Stockfish ${selectedEngine === 'asm' ? 'ASM-JS' : selectedEngine === 'full-single' ? 'Full' : selectedEngine === 'sf10' ? '10' : 'Lite'} khởi tạo quá lâu. Kiểm tra tệp JS/WASM và thử tải lại.`);
    }, selectedEngine === 'full-single' ? 45000 : selectedEngine === 'sf10' ? 30000 : selectedEngine === 'asm' ? 12000 : 20000);
  } catch (error) {
    if (!isFallback && !engineInitFallbacksTried.has(selectedEngine)) engineInitFallbacksTried.add(selectedEngine);
    if (tryEngineInitFallback(selectedEngine)) return;
    failEngine('Không thể khởi tạo Stockfish. Kiểm tra các tệp engine và thử tải lại.');
  }
}
function failEngine(message) {
  const wasThinking = botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver();
  retireStockfishWorker(message);
  addAppNotification({ title: 'Stockfish chưa sẵn sàng', message, type: 'error' });
  if (!wasThinking) toast(message);
  // Preserve the ticking bot clock and premove window while a stronger VILA offline search runs.
  if (wasThinking) requestOfflineRescueMove('Stockfish bị lỗi');
}

function runEngineQueue() {
  if (!engineWorker || !engineReady || !engineQueue.length) return;
  const next = engineQueue.shift();
  if (next) next();
}
async function chooseStockfishBackedOfflineUci(chess, profile = 'classic', fen = chess.fen()) {
  // Reuse the main UCI worker when idle so the normal offline bots are not weaker than
  // the custom search core solely because they never consult Stockfish. The custom
  // alpha-beta core remains the offline-safe fallback whenever the worker is busy/missing.
  if (!engineWorker || !engineReady || engineFailed || engineStopPending || pendingEngineRequest || pendingHintRequest ||
      pendingCoachAnalysis || analysisActive || reviewSession || engineSearchActive || arenaRunning) return null;
  const isClassic = profile === 'classic';
  const depth = Math.max(14, Math.min(28, Number(settings.botDepth) || 20));
  const moveTimeMs = Math.max(900, Math.min(2800, Number(settings.botMoveTimeMs) || 1800));
  let result;
  try {
    result = await requestStockfishUci(fen, {
      skill: 20, depth, strengthMode: 'max', moveTimeMs,
      multiPv: isClassic ? 1 : 4,
      timeoutMs: Math.max(12000, moveTimeMs * 5)
    });
  } catch { return null; }
  const candidates = (Array.isArray(result) ? result : [{ uci: result, score: 0, depth }])
    .filter(item => /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(item?.uci || '')))
    .filter(item => chess.moves({ verbose: true }).some(move => uciForMove(move) === String(item.uci).toLowerCase()));
  if (!candidates.length) return null;
  if (isClassic) return String(candidates[0].uci).toLowerCase();
  const bestScore = Math.max(...candidates.map(item => Number(item.score) || 0));
  const ranked = candidates.map(item => ({
    ...item,
    personalityScore: personaCandidateScore(chess, item, profile, bestScore)
  })).sort((a, b) => b.personalityScore - a.personalityScore || String(a.uci).localeCompare(String(b.uci)));
  // Keep style differences without letting beginner profiles choose catastrophically bad lines.
  const tolerance = profile === 'rookie' ? 320 : profile === 'mentor' ? 210 :
    ['berserk', 'gambit', 'trickster', 'chaos'].includes(profile) ? 95 : 55;
  const acceptable = ranked.filter(item => bestScore - (Number(item.score) || 0) <= tolerance);
  return String((acceptable[0] || ranked[0]).uci).toLowerCase();
}

async function askVilaMove() {
  if (mode !== 'vila' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const fen = game.fen();
  const epoch = gameEpoch;
  $('#boardStatus') && ($('#boardStatus').textContent = 'ViLa Classic đang tính nước…');
  try {
    const vilaBook = settings.openingBookEnabled ? pickPersonaBookMove(game, 'classic', OPENINGS, { recentChoices: recentOpeningChoices }) : null;
    if (vilaBook) { botThinking = false; applyUciMove(uciForMove(vilaBook)); return; }
    const stockfishUci = await chooseStockfishBackedOfflineUci(game, 'classic', fen);
    if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'vila' || !botThinking) return;
    const budget = resolveOfflineSearchBudget('classic', settings);
    const uci = stockfishUci || await chooseAlternateMoveAsync(fen, { ...budget, seen: repetitionContext(game) });
    if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'vila' || !botThinking) return;
    if (!uci) throw new Error('Không tìm thấy nước đi hợp lệ.');
    if (!stockfishUci) recordEngineSpeed('ViLa Classic · alpha-beta ngoại tuyến', getLastOfflineEngineStats());
    applyUciMove(uci);
  } catch (error) {
    if (epoch !== gameEpoch || mode !== 'vila') return;
    botThinking = false;
    toast(`ViLa Classic gặp lỗi: ${error.message}`);
    renderView();
  }
}
function askEngineHubMove() {
  if (mode !== 'enginehub' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const fen = game.fen();
  const epoch = gameEpoch;
  const profile = OFFLINE_ENGINE_IDS.includes(settings.alternativeEngine) ? settings.alternativeEngine : 'ethereal';
  $('#boardStatus') && ($('#boardStatus').textContent = `${offlineEngineShortName(profile)} · offline đang suy nghĩ…`);
  // Let the status paint, then search in a module worker so the board stays responsive.
  setTimeout(async () => {
    if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub' || !botThinking) return;
    try {
      const bookMove = settings.openingBookEnabled ? pickPersonaBookMove(game, profile, OPENINGS, { recentChoices: recentOpeningChoices }) : null;
      if (bookMove) { botThinking = false; applyUciMove(uciForMove(bookMove)); return; }
      const stockfishUci = await chooseStockfishBackedOfflineUci(game, profile, fen);
      if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub' || !botThinking) return;
      const budget = resolveOfflineSearchBudget(profile, settings);
      const uci = stockfishUci || await chooseAlternateMoveAsync(fen, { ...budget, seen: repetitionContext(game) });
      if (!stockfishUci) recordEngineSpeed(offlineEngineShortName(profile), getLastOfflineEngineStats());
      if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub' || !botThinking) return;
      if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(uci || ''))) throw new Error('Không tìm thấy nước đi hợp lệ.');
      applyUciMove(uci);
    } catch (error) {
      if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub') return;
      botThinking = false;
      toast(`AI cục bộ gặp lỗi: ${error.message}`);
      renderView();
    }
  }, 30);
}

function askStockfishMove() {
  if (!['stockfish', 'stockfish-beginner'].includes(mode) || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const requestedStrength = settings.botStrengthMode === 'elo' ? resolveStockfishStrength(mode === 'stockfish-beginner' ? 500 : settings.botElo) : null;
  if (settings.openingBookEnabled && game.history().length < 14 && requestedStrength?.mode !== 'skill-level-floor') {
    const bookMove = findOpeningBookMove(game, OPENINGS, { maxPlies: 20, recentChoices: recentOpeningChoices });
    if (bookMove) {
      botThinking = false;
      applyUciMove(uciForMove(bookMove));
      return;
    }
  }
  // Never bypass Stockfish with random/heuristic moves just to simulate a low rating.
  // Below the UCI_Elo floor, progressively mapped native Skill Level 0–7 is handled by Stockfish itself.
  if (pendingEngineRequest) { toast('Stockfish đang xử lý một ván khác.'); return; }
  if (engineSearchActive || engineStopPending) { queuedMainEngineMove = true; return; }
  if (!engineWorker || engineFailed) {
    requestOfflineRescueMove('Stockfish không khả dụng');
    return;
  }
  if (!engineReady) {
    const waiting = { epoch: gameEpoch, fen: game.fen() };
    waitingForStockfishMove = waiting;
    $('#boardStatus') && ($('#boardStatus').textContent = `${fallbackEngineLabel(engineHealthState?.profile || (settings.botEngine === 'sf10' ? 'sf10' : 'lite-single'))} đang khởi tạo…`);
    if (stockfishWarmupTimer) clearTimeout(stockfishWarmupTimer);
    stockfishWarmupTimer = setTimeout(() => {
      stockfishWarmupTimer = null;
      if (waitingForStockfishMove !== waiting) return;
      waitingForStockfishMove = null;
      if (waiting.epoch === gameEpoch && waiting.fen === game.fen() && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) requestOfflineRescueMove('Stockfish khởi tạo chậm');
    }, 8000);
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = gameEpoch;
  mainEngineSearchFen = game.fen();
  const skill = Math.max(0, Math.min(20, Number(settings.botSkill ?? 20)));
  const depth = Math.max(5, Math.min(30, Number(settings.botDepth || 30)));
  $('#boardStatus') && ($('#boardStatus').textContent = 'Stockfish đang suy nghĩ…');
  $('#evalNumber') && ($('#evalNumber').textContent = '…');
  if (settings.botStrengthMode === 'elo') {
    const strength = resolveStockfishStrength(settings.botElo);
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strength.limitStrength ? 'true' : 'false'}`);
    if (strength.uciElo != null) engineWorker.postMessage(`setoption name UCI_Elo value ${strength.uciElo}`);
    engineWorker.postMessage(`setoption name Skill Level value ${strength.skillLevel}`);
  } else {
    engineWorker.postMessage('setoption name UCI_LimitStrength value false');
    engineWorker.postMessage(`setoption name Skill Level value ${skill}`);
  }
  engineWorker.postMessage('setoption name MultiPV value 1');
  engineWorker.postMessage(`position fen ${game.fen()}`);
  const configuredMoveTimeMs = Math.max(500, Math.min(5000, Number(settings.botMoveTimeMs) || 2600));
  // The legacy asm.js build is much slower than the bundled Stockfish 19 WASM build.
  // Cap it separately for human-vs-bot too; a failed legacy engine falls back to a newer profile.
  const isLegacySf10 = engineHealthState?.profile === 'sf10';
  const moveTimeMs = isLegacySf10
    ? Math.max(200, Math.min(500, Math.round(configuredMoveTimeMs * 0.2)))
    : configuredMoveTimeMs;
  engineWorker.postMessage(`go movetime ${moveTimeMs} depth ${depth}`);
  if (mainEngineTimer) clearTimeout(mainEngineTimer);
  const watchdogMs = isLegacySf10 ? Math.max(3500, Math.min(7000, moveTimeMs * 6)) : Math.max(12000, Math.min(30000, moveTimeMs * 6));
  mainEngineTimer = setTimeout(() => {
    mainEngineTimer = null;
    if (!botThinking || mode !== 'stockfish' || pendingEngineRequest || !engineSearchActive) return;
    retireStockfishWorker('Stockfish không phản hồi đúng hạn.');
    requestOfflineRescueMove('Stockfish không phản hồi đúng hạn');
  }, watchdogMs);
}
function requestOfflineRescueMove(reason = 'Stockfish chưa sẵn sàng') {
  if (!['stockfish', 'stockfish-beginner'].includes(mode) || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return false;
  const fen = game.fen();
  const epoch = gameEpoch;
  const profile = OFFLINE_ENGINE_IDS.includes(settings.alternativeEngine) ? settings.alternativeEngine : 'ethereal';
  $('#boardStatus') && ($('#boardStatus').textContent = `${offlineEngineShortName(profile)} · offline đang suy nghĩ…`);
  const isCurrentSearch = () => epoch === gameEpoch && fen === game.fen() && mode === 'stockfish' && botThinking && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor;
  // A bounded search gives a legal, stronger fallback without requiring network access.
  const rescueBudget = resolveOfflineSearchBudget(profile, { ...settings, botMoveTimeMs: Math.min(2600, Number(settings.botMoveTimeMs) || 2600), botDepth: Math.max(30, Number(settings.botDepth) || 30) });
  void chooseAlternateMoveAsync(fen, { ...rescueBudget, seen: repetitionContext(game) }).then(uci => {
    if (!isCurrentSearch()) return;
    // Catch up the active side's clock before accepting a move in case a slow WebView
    // delayed interval callbacks while the offline worker fallback was searching.
    tickClock();
    if (!isCurrentSearch()) return;
    const legalUci = new Set(game.moves({ verbose: true }).map(uciForMove));
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(uci || '')) || !legalUci.has(String(uci).toLowerCase())) {
      throw new Error('Engine ngoại tuyến không trả về nước đi hợp lệ.');
    }
    recordEngineSpeed(offlineEngineShortName(profile), getLastOfflineEngineStats());
    applyUciMove(String(uci).toLowerCase());
    toast(`${reason}; đã dùng ${offlineEngineShortName(profile)} ngoại tuyến.`, '');
  }).catch(error => {
    if (!isCurrentSearch()) return;
    const fallback = chooseFallbackMove();
    botThinking = false;
    if (fallback) applyUciMove(uciForMove(fallback));
    else renderView();
    toast(`${reason}; engine ngoại tuyến cũng lỗi, đã dùng nước dự phòng cơ bản (${error?.message || 'không rõ lỗi'}).`);
  });
  return true;
}
function chooseFallbackMove() { return chooseFallbackMoveFor(game); }
function chooseFallbackMoveFor(chess) {
  const moves = chess.moves({ verbose: true });
  if (!moves.length) return null;
  // Last-resort only: deterministic ordering and tactical priorities avoid a random blunder
  // when both Stockfish and the alpha-beta worker have failed. This is not advertised as engine strength.
  const values = { p: 1, n: 3.1, b: 3.3, r: 5, q: 9, k: 0 };
  const scored = moves.map(move => {
    let score = 0;
    if (move.captured) score += 2 + values[move.captured] * 0.9 - values[move.piece] * 0.15;
    if (move.san.includes('+')) score += 1.1;
    if (move.san.includes('#')) score += 500;
    if (move.promotion) score += 8 + values[move.promotion] * 0.2;
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) score += 0.15;
    const file = move.to.charCodeAt(0) - 97, rank = Number(move.to[1]) - 1;
    score += ((3.5 - Math.abs(3.5 - file)) + (3.5 - Math.abs(3.5 - rank))) * 0.08;
    // Develop minor pieces toward the center early instead of wasting a move on the rim.
    if (chess.history().length < 20 && ['n', 'b'].includes(move.piece)) {
      if (move.from[1] === (move.color === 'w' ? '1' : '8')) score += 0.35;
      if (['d4', 'e4', 'd5', 'e5'].includes(move.to)) score += 0.18;
    }
    return { move, score, uci: uciForMove(move) };
  }).sort((a, b) => b.score - a.score || a.uci.localeCompare(b.uci));
  return scored[0]?.move || null;
}
function applyUciMove(uci) {
  if (clockFlagged) { premoveQueue = []; botThinking = false; return; }
  tickClock();
  if (clockFlagged) { premoveQueue = []; botThinking = false; return; }
  const mover = game.turn();
  const plyBeforeMove = game.history().length;
  const clockBeforeMove = captureMoveClockSnapshot();
  try {
    const from = uci.slice(0, 2), to = uci.slice(2, 4), promotion = uci[4];
    const made = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!made) throw new Error('Stockfish returned an invalid move.');
    recordClockSnapshot(moveClockSnapshots, plyBeforeMove, clockBeforeMove);
    redoStack = [];
    playBoardSound(made, game, settings.soundEnabled);
    lastHintMove = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: made.from, to: made.to };
    queueMoveSlide(made);
    announceMove(made, mover);
    currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening;
    botThinking = false;
    if (game.isGameOver()) {
      premoveQueue = [];
      renderView();
      stopClock(); toast(game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.', 'success');
    } else if (premoveQueue.length) {
      // The queued intent is resolved against the actual position after the bot move.
      // Calling playMove() here makes the premove instant and restarts the bot's clock next turn.
      const premovePlayed = executeNextPremove();
      if (!premovePlayed) {
        if (currentView === 'play') renderBoard(); else renderView();
        if (currentView === 'play') queryOpeningExplorer(false);
      }
    } else {
      if (currentView !== 'play') renderView(); else renderBoard();
      if (currentView === 'play') queryOpeningExplorer(false);
    }
  } catch (error) { premoveQueue = []; botThinking = false; toast(`Lỗi nước đi engine: ${error.message}`); renderView(); }
}
function chessUciHistory() { return game.history({ verbose: true }).map(m => `${m.from}${m.to}${m.promotion || ''}`).join(','); }

// Arena: each configured model plays by proposing one UCI move from the legal-move list.
// chess.js validates every move, while Stockfish remains the tactical engine.
function arenaCandidates() {
  return [
    { id: 'stockfish', name: 'Stockfish 19 · bản Lite đang đóng gói', type: 'stockfish', hint: 'Stockfish 19 Lite WASM; bản Full chưa được đóng gói trong manifest hiện tại' },
    { id: 'stockfish-10', name: 'Stockfish 10 · cổ điển (0,2–0,6 giây/nước)', type: 'stockfish-legacy', hint: 'Engine cũ được giới hạn thời gian tìm nước để phản hồi nhanh hơn' },
    ...OFFLINE_ENGINE_CATALOG.map(item => ({
      id: `offline-${item.id}`,
      name: `${item.label} · bot phong cách`,
      type: 'offline',
      profile: item.id,
      hint: item.hint || ''
    }))
  ];
}
function arenaPlayer(id) {
  return arenaCandidates().find(player => player.id === id) || null;
}
function renderArenaOptions(selectedId) {
  return arenaCandidates().map(player => `<option value="${esc(player.id)}" ${player.id === selectedId ? 'selected' : ''}>${esc(player.name)}</option>`).join('');
}
function renderArenaCupPodiumMarkup() {
  if (!arenaCupStandings.length) return '<div class="arena-cup-empty">🥇 Chưa có kết quả giải</div>';
  const medals = ['🥇', '🥈', '🥉'];
  return arenaCupStandings.slice(0, 3).map((entry, index) => `<article class="arena-cup-rank rank-${index + 1}"><span>${medals[index] || `${index + 1}.`}</span><b>${esc(entry.name)}</b><strong>${Number(entry.points || 0).toFixed(1)}</strong><small>${Number(entry.wins || 0)} thắng · ${Number(entry.draws || 0)} hòa · ${Number(entry.losses || 0)} thua</small></article>`).join('');
}
function syncArenaCupPodium() {
  const podium = $('#arenaCupPodium');
  if (podium) podium.innerHTML = renderArenaCupPodiumMarkup();
  const copy = $('.arena-cup-copy p');
  if (copy) copy.textContent = arenaCupStandings.length ? `Nhà vô địch gần nhất: ${arenaCupStandings[0].name} · ${Number(arenaCupStandings[0].points || 0).toFixed(1)} điểm` : 'Chạy giải vòng tròn để xác định nhà vô địch và bảng xếp hạng bot.';
}

function renderArenaView() {
  const players = arenaCandidates();
  const validLeague = new Set(players.map(p => p.id));
  for (const id of [...arenaSelectedLeague]) if (!validLeague.has(id)) arenaSelectedLeague.delete(id);
  if (!arenaSelectedLeague.size) { arenaSelectedLeague.add('stockfish'); arenaSelectedLeague.add('offline-rookie'); }
  const leagueChecks = players.map(player => `<label class="arena-check"><input type="checkbox" class="arena-participant-check" value="${esc(player.id)}" ${arenaSelectedLeague.has(player.id) ? 'checked' : ''}/><span><b>${esc(player.name)}</b><small>${player.type === 'stockfish' ? 'Stockfish 19 Lite · WASM (bản Full chưa có trong gói)' : player.type === 'stockfish-legacy' ? 'Stockfish 10 · UCI cổ điển' : `Phong cách VILA · ${esc(player.hint || player.profile)}`}</small></span></label>`).join('');
  const defaultBlack = players.some(p => p.id === 'offline-rookie') ? 'offline-rookie' : players[1]?.id || 'stockfish';
  const whiteName = arenaCurrentPlayers.w?.name || 'Stockfish 19';
  const blackName = arenaCurrentPlayers.b?.name || 'VILA · Bot chiến thuật';
  return `<section class="content-page arena-page arena-redesign">
    <div class="arena-page-heading"><div><span class="eyebrow">CỜ VUA VILA · AI ARENA</span><h1>Đấu trường AI</h1><p>Cho hai bot thi đấu tự động, theo dõi từng nước và lưu biên bản PGN.</p><p class="arena-truth-note">Các nhãn phong cách không phải xếp hạng Elo đã benchmark và không phải các engine thương hiệu bên ngoài; Stockfish được dùng để tìm nước khi sẵn sàng.</p></div><span class="arena-header-status ${arenaRunning ? 'is-live' : ''}"><i></i>${arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'}</span></div>
    <section class="panel arena-match-card">
      <div class="arena-player-strip arena-player-top"><div class="arena-profile-avatar avatar-stockfish">♟</div><div class="arena-player-meta"><b id="arenaWhiteName">${esc(whiteName)}</b><small>QUÂN TRẮNG · ${arenaCurrentPlayers.w ? 'AI ĐANG CHƠI' : 'CHỜ GHÉP CẶP'}</small></div><span class="arena-player-type">BOT</span></div>
      <div class="arena-board-frame"><div id="arenaBoard" class="arena-board" role="grid" aria-label="Bàn cờ đấu trường AI"></div></div>
      <div class="arena-board-meta"><span id="arenaStatus">${esc(arenaLastResult || positionStatus(arenaGame))}</span><b id="arenaPlyCount">${arenaGame.history().length} nửa nước</b></div>
      <div class="engine-speed-row">${engineSpeedChipMarkup()}</div><div id="arenaFallbackNote" class="arena-fallback-note">${esc(arenaLastNote || 'Nước đi được kiểm tra bởi chess.js; engine chạy cục bộ khi tài nguyên sẵn sàng.')}</div>
      <div class="arena-player-strip arena-player-bottom"><div class="arena-profile-avatar avatar-vila">♞</div><div class="arena-player-meta"><b id="arenaBlackName">${esc(blackName)}</b><small>QUÂN ĐEN · BOT PHONG CÁCH</small></div><span class="arena-player-type">AI</span></div>
      <div class="arena-primary-controls"><button id="arenaRunMatch" class="primary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>▶ Đấu trận</button><button id="arenaRunLeague" class="secondary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>♜ Giải vòng tròn</button><button id="arenaStop" class="danger-btn" type="button" ${arenaRunning ? '' : 'disabled'}>■ Dừng</button></div>
      <div class="arena-secondary-controls"><button id="arenaSwapRematch" class="secondary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>⇄ Đổi màu</button><button id="arenaReset" class="secondary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>↺ Ván mới</button><button id="arenaDownloadPGN" class="secondary-btn" type="button" ${(arenaGame.history().length || arenaPgnArchive.length) ? '' : 'disabled'}>↓ Tải PGN</button></div>
      <section class="arena-cup-panel" aria-label="Cúp đấu trường ViLa"><div class="arena-cup-emblem" aria-hidden="true">🏆</div><div class="arena-cup-copy"><small class="eyebrow">VILA AI · CUP</small><h2>Cúp đấu trường</h2><p>${arenaCupStandings.length ? `Nhà vô địch gần nhất: ${esc(arenaCupStandings[0].name)} · ${Number(arenaCupStandings[0].points || 0).toFixed(1)} điểm` : 'Chạy giải vòng tròn để xác định nhà vô địch và bảng xếp hạng bot.'}</p></div><div id="arenaCupPodium" class="arena-cup-podium">${renderArenaCupPodiumMarkup()}</div></section>
      <div id="arenaLeagueSummary" class="arena-league-summary">${esc(arenaTournamentSummary || 'Chọn bot và bấm Đấu trận để bắt đầu.')}</div>
    </section>
    <section class="panel arena-moves-panel"><div class="panel-heading"><div><small class="eyebrow">BIÊN BẢN VÁN ĐẤU</small><h2>Nước đi</h2></div><span class="small-counter" id="arenaMoveCounter">${arenaGame.history().length}</span></div><div id="arenaMoveList" class="move-list arena-move-list"></div></section>
    <details class="panel arena-advanced-settings"><summary><span><small class="eyebrow">TÙY CHỈNH</small><b>Đối thủ, sức mạnh và giải đấu</b></span><span class="setup-chevron">⌄</span></summary><div class="arena-settings-grid"><section class="arena-setting-section"><div class="panel-heading"><h2>Chọn đối thủ</h2><span class="context-icon">⚔</span></div><label class="field-label" for="arenaWhite">Quân Trắng</label><select id="arenaWhite" class="field">${renderArenaOptions('stockfish')}</select><label class="field-label" for="arenaBlack">Quân Đen</label><select id="arenaBlack" class="field">${renderArenaOptions(defaultBlack)}</select><label class="preference-toggle arena-random-sides"><input id="arenaRandomSides" type="checkbox" ${arenaRandomSides ? 'checked' : ''}/><span><b>🎲 Đảo màu ngẫu nhiên</b><small>Giải vòng tròn tự đổi màu hai lượt mỗi cặp.</small></span></label>
      <div class="two-fields"><div><label class="field-label" for="arenaDepth">Độ sâu tìm kiếm</label><select id="arenaDepth" class="field">${[12,16,18,20,22,24,26,28,30].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}</option>`).join('')}</select></div><div><label class="field-label" for="arenaDelay">Nghỉ mỗi nước</label><select id="arenaDelay" class="field"><option value="0">Nhanh nhất</option><option value="150" selected>0,15 giây</option><option value="800">0,8 giây</option><option value="1500">1,5 giây</option></select></div></div>
      <div class="two-fields"><div><label class="field-label" for="arenaPlyLimit">Giới hạn nửa nước</label><select id="arenaPlyLimit" class="field">${[80,120,180,240].map(n=>`<option value="${n}" ${n===120?'selected':''}>${n}</option>`).join('')}</select></div><div><label class="field-label" for="arenaSkill">Skill Stockfish</label><select id="arenaSkill" class="field">${[10,14,18,20].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}/20</option>`).join('')}</select></div></div>
      <div class="two-fields"><div><label class="field-label" for="arenaEngineMode">Sức mạnh</label><select id="arenaEngineMode" class="field"><option value="max" selected>Tối đa</option><option value="elo">Giới hạn mô phỏng</option></select></div><div><label class="field-label" for="arenaEngineElo">Elo mô phỏng</label><select id="arenaEngineElo" class="field">${Array.from({ length: 28 }, (_, i) => 500 + i * 100).map(n=>`<option value="${n}" ${n===2600?'selected':''}>${n}</option>`).join('')}</select></div></div><p class="field-hint">Độ sâu và Elo mô phỏng là cài đặt tìm kiếm, không phải mức Elo đã benchmark. Trên điện thoại cấu hình cao có thể tăng thời gian tìm kiếm nhưng sẽ tiêu thụ pin hơn.</p></section>
      <section class="arena-setting-section"><div class="panel-heading"><div><small class="eyebrow">GIẢI NỘI BỘ</small><h2>Bot tham gia</h2></div><span class="small-counter">${players.length}</span></div><div class="arena-participant-list">${leagueChecks}</div><p class="field-hint">Chọn 2–6 bot. Các phong cách là profile VILA dùng chung engine tìm kiếm cục bộ, không phải engine neural độc lập.</p></section></div></details>
  </section>`;
}
function renderArenaPosition() {
  const board = $('#arenaBoard');
  if (!board) return;
  const rows = [8,7,6,5,4,3,2,1], files = ['a','b','c','d','e','f','g','h'];
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = arenaGame.get(sq);
    const last = arenaLastMove && (arenaLastMove.from === sq || arenaLastMove.to === sq);
    html += `<div class="arena-square ${squareColor(sq)} ${last ? 'arena-last-move' : ''}" aria-label="${sq}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</div>`;
  }));
  board.innerHTML = html;
  syncArenaBoardLayout();
  const status = $('#arenaStatus');
  if (status) status.textContent = arenaRunning ? `${arenaCurrentPlayers[arenaGame.turn()]?.name || 'AI'} đang suy nghĩ…` : (arenaLastResult || positionStatus(arenaGame));
  const title = $('#arenaMatchTitle');
  if (title) title.textContent = `${arenaCurrentPlayers.w?.name || 'Stockfish'} vs ${arenaCurrentPlayers.b?.name || 'AI hiện tại'}`;
  const whiteName = $('#arenaWhiteName'); if (whiteName) whiteName.textContent = arenaCurrentPlayers.w?.name || 'Stockfish 19';
  const blackName = $('#arenaBlackName'); if (blackName) blackName.textContent = arenaCurrentPlayers.b?.name || 'VILA · Bot chiến thuật';
  const badge = $('#arenaLiveBadge');
  if (badge) { badge.textContent = arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'; badge.classList.toggle('is-live', arenaRunning); }
  const ply = $('#arenaPlyCount'); if (ply) ply.textContent = `${arenaGame.history().length} nửa nước đi`;
  const counter = $('#arenaMoveCounter'); if (counter) counter.textContent = String(arenaGame.history().length);
  const note = $('#arenaFallbackNote'); if (note) note.textContent = arenaEngineWarning || arenaLastNote || 'Các nước của AI sẽ hiện tại đây.';
  const moveList = $('#arenaMoveList');
  if (moveList) {
    const history = arenaGame.history();
    if (!history.length) moveList.innerHTML = '<div class="empty-state">Chưa có nước đi. Bắt đầu một trận để hai AI chơi tự động.</div>';
    else {
      let rows = '';
      for (let i = 0; i < history.length; i += 2) rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2)+1}.</span>${moveSanCell(history[i])}${moveSanCell(history[i+1] || '…')}</div>`;
      moveList.innerHTML = rows; moveList.scrollTop = moveList.scrollHeight;
    }
  }
  ['arenaRunMatch','arenaRunLeague','arenaSwapRematch','arenaReset','arenaDownloadPGN'].forEach(id => { const button = $(`#${id}`); if (button) button.disabled = arenaRunning || (id === 'arenaDownloadPGN' && !arenaGame.history().length && !arenaPgnArchive.length); });
  const stop = $('#arenaStop'); if (stop) stop.disabled = !arenaRunning;
}
function wireArenaActions() {
  $('#arenaRandomSides')?.addEventListener('change', event => { arenaRandomSides = Boolean(event.target.checked); });
  $('#arenaRunMatch')?.addEventListener('click', () => { drawArenaSides(); unlockBoardSound(); startArenaMatch($('#arenaWhite')?.value || 'stockfish', $('#arenaBlack')?.value || 'offline-rookie'); });
  $('#arenaRunLeague')?.addEventListener('click', () => { unlockBoardSound(); runArenaLeague(); });
  $('#arenaStop')?.addEventListener('click', stopArenaMatch);
  $('#arenaReset')?.addEventListener('click', () => { if (arenaRunning) return; arenaGame = new Chess(); arenaLastMove = null; arenaLastResult = ''; arenaLastNote = ''; arenaEngineWarning = ''; arenaLastPgnResult = '*'; arenaPgnArchive = []; renderArenaPosition(); });
  $('#arenaSwapRematch')?.addEventListener('click', () => { if (arenaRunning) return; unlockBoardSound(); const w = $('#arenaWhite')?.value || 'stockfish'; if ($('#arenaWhite')) $('#arenaWhite').value = $('#arenaBlack')?.value || 'offline-rookie'; if ($('#arenaBlack')) $('#arenaBlack').value = w; startArenaMatch($('#arenaWhite')?.value || 'stockfish', $('#arenaBlack')?.value || 'offline-rookie'); });
  $('#arenaDownloadPGN')?.addEventListener('click', downloadArenaPgn);
  $$('.arena-participant-check').forEach(input => input.addEventListener('change', () => { if (input.checked) arenaSelectedLeague.add(input.value); else arenaSelectedLeague.delete(input.value); }));
}
function arenaDelay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
/** Count how often each position (first 4 FEN fields) has occurred, so offline engines avoid repeating moves. */
function repetitionContext(chess) {
  const key = c => c.fen().split(' ').slice(0, 4).join(' ');
  const counts = {};
  try {
    const replay = new Chess();
    counts[key(replay)] = 1;
    for (const san of chess.history()) { replay.move(san); const k = key(replay); counts[k] = (counts[k] || 0) + 1; }
  } catch {}
  return counts;
}
async function requestStockfishUci(fen, { skill = 20, depth = 18, strengthMode = 'max', elo = 3190, moveTimeMs = null, timeoutMs = null, multiPv = 1 } = {}) {
  const effectiveMoveTimeMs = Math.max(700, Math.min(4000, Number(moveTimeMs) || Math.round(Math.max(5, Math.min(30, Number(depth) || 18)) * 75)));
  const effectiveTimeoutMs = Number(timeoutMs) || Math.max(12000, Math.min(30000, effectiveMoveTimeMs * 6));
  if (!engineWorker || engineFailed) throw new Error('Stockfish chưa sẵn sàng; kiểm tra gói engine sau npm install.');
  const readyStarted = Date.now();
  while (!engineReady && !engineFailed && Date.now() - readyStarted < 20000) await arenaDelay(100);
  if (!engineReady || engineFailed) throw new Error('Chờ Stockfish quá lâu hoặc engine lỗi.');
  if (engineStopPending || pendingEngineRequest || engineSearchActive) throw new Error('Stockfish đang xử lý hoặc đóng một yêu cầu khác. Hãy thử lại sau.');
  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (pendingEngineRequest?.resolve === resolve) {
        pendingEngineRequest = null;
        engineSearchActive = false;
        retireStockfishWorker('Stockfish quá thời gian suy nghĩ.');
        reject(new Error('Stockfish quá thời gian suy nghĩ; engine đã được dừng để tránh nhầm kết quả cũ.'));
      }
    }, effectiveTimeoutMs);
    const requestedMultiPv = Math.max(1, Math.min(5, Math.round(Number(multiPv) || 1)));
    pendingEngineRequest = { resolve, reject, timeout, multiPv: requestedMultiPv, candidates: new Map() };
    engineSearchActive = true;
    const strength = strengthMode === 'elo' ? resolveStockfishStrength(elo) : null;
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strength?.limitStrength ? 'true' : 'false'}`);
    if (strength?.uciElo != null) engineWorker.postMessage(`setoption name UCI_Elo value ${strength.uciElo}`);
    const requestedSkill = Number(skill);
    const effectiveSkill = strengthMode === 'elo' ? strength.skillLevel : Math.max(0, Math.min(20, Number.isFinite(requestedSkill) ? requestedSkill : 20));
    engineWorker.postMessage(`setoption name Skill Level value ${effectiveSkill}`);
    engineWorker.postMessage(`setoption name MultiPV value ${requestedMultiPv}`);
    engineWorker.postMessage(`position fen ${fen}`);
    engineWorker.postMessage(`go movetime ${effectiveMoveTimeMs}`);
  });
}
function uciForMove(move) { return `${move.from}${move.to}${move.promotion || ''}`; }
function stableMoveNoise(seed, maximum = 12) {
  const text = String(seed || 'vila');
  let hash = 2166136261;
  for (let i = 0; i < text.length; i += 1) { hash ^= text.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return ((hash >>> 0) % 10007) / 10007 * Math.max(0, Number(maximum) || 0);
}
function personaCandidateScore(chess, candidate, profile, bestScore) {
  const loss = Math.max(0, bestScore - Number(candidate.score || 0));
  const uci = String(candidate.uci || '');
  const moveData = { from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) };
  let move = null; let next = null;
  try { next = new Chess(chess.fen()); move = next.move(moveData); } catch {}
  if (!move) return -1e9;

  const mover = chess.turn();
  const aggressive = ['berserk', 'gambit', 'trickster', 'dynamic', 'hunter', 'chaos'].includes(profile);
  const cautious = ['fortress', 'strangler', 'endgame', 'sentinel', 'strategist', 'longgame'].includes(profile);
  const centerSquares = ['d4', 'e4', 'd5', 'e5'];
  const centerControl = centerSquares.reduce((score, square) => {
    const piece = next.get(square);
    return score + (piece?.color === mover ? 1 : piece ? -0.2 : 0);
  }, 0);
  const replies = next.moves({ verbose: true });
  let style = 0;

  // Each persona gets a real move-selection bias on top of legal UCI candidate moves.
  // The profile names are styles, not separate trained networks or measured Elo ratings.
  if (aggressive) {
    if (next.isCheck()) style += profile === 'berserk' ? 42 : 28;
    if (move.captured) style += (profile === 'gambit' || profile === 'berserk') ? 24 : 14;
    if (move.promotion) style += 80;
  }
  if (profile === 'lc0') style += centerControl * 22 + (move.piece === 'n' || move.piece === 'b' ? 4 : 0);
  if (profile === 'ethereal') style -= loss * 0.12; // very low-variance, prioritizes evaluation stability
  if (profile === 'fortress') {
    if (move.captured === 'q' || move.captured === 'r') style += 18;
    if (move.piece === 'p' && Math.abs(Number(move.to[1]) - Number(move.from[1])) === 1) style += 2;
    if (next.isCheck()) style += 4; // only when the defensive move also creates a forcing reply
  }
  if (['endgame', 'longgame'].includes(profile)) {
    const boardPieces = next.board().flat().filter(Boolean);
    const nonPawnMaterial = boardPieces.filter(piece => !['p', 'k'].includes(piece.type)).length;
    if (nonPawnMaterial <= 6) {
      const king = boardPieces.find(piece => piece.type === 'k' && piece.color === mover);
      if (king?.square) {
        const file = king.square.charCodeAt(0) - 97;
        const rank = Number(king.square[1]) - 1;
        const distance = Math.min(...[[3,3],[4,3],[3,4],[4,4]].map(([f,r]) => Math.abs(file-f) + Math.abs(rank-r)));
        style += (7 - distance) * 4;
      }
    }
  }
  if (profile === 'dynamic') style += centerControl * 10;
  if (profile === 'blitz') style += stableMoveNoise(`${chess.fen()}|${move.from}${move.to}|blitz`, 12);
  if (profile === 'gambit' && move.piece === 'p' && chess.history().length < 16) style += 12;
  if (profile === 'hyper' && chess.history().length < 18) {
    if ((move.piece === 'n' || move.piece === 'b') && move.from[1] === (mover === 'w' ? '1' : '8')) style += 22;
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) style += 20;
    style += centerControl * 8;
  }
  if (profile === 'strangler') style += Math.max(-12, Math.min(18, (30 - replies.length) * 0.8)) + centerControl * 8;
  if (profile === 'trickster' || profile === 'chaos') style += stableMoveNoise(`${chess.fen()}|${move.from}${move.to}|${profile}`, 18) + (move.san.includes('+') ? 9 : 0);
  if (profile === 'hunter') style += (move.captured ? 22 : 0) + (next.isCheck() ? 16 : 0) + (move.promotion ? 90 : 0);
  if (profile === 'sentinel') style -= loss * 0.22;
  if (profile === 'strategist') style += centerControl * 12 + Math.max(-8, Math.min(14, (28 - replies.length) * 0.55));
  if (profile === 'mentor' || profile === 'rookie') style += loss * 0.7 + stableMoveNoise(`${chess.fen()}|${move.from}${move.to}|${profile}`, 18); // controlled sub-best bias, deterministic for repeatable testing

  const lossPenalty = ['rookie', 'mentor'].includes(profile) ? 0.35 : profile === 'ethereal' ? 1.25 : aggressive ? 0.55 : cautious ? 1.2 : 0.8;
  return Number(candidate.score || 0) - loss * lossPenalty + style;
}
function getLegacyArenaEngine() {
  if (legacyArenaEngine) return legacyArenaEngine;
  legacyArenaEngine = new LegacyUciEngine(() => {
    const asset = new URL(`${import.meta.env.BASE_URL}engine/stockfish-10.js`, window.location.href).href;
    return new Worker(asset);
  }, { initTimeoutMs: 8_000, defaultSearchTimeoutMs: 4_500 });
  return legacyArenaEngine;
}
async function requestLegacyArenaUci(chess, depth, skill, options = {}) {
  const legacySkill = options.strengthMode === 'elo' ? resolveStockfishStrength(options.elo).skillLevel : skill;
  const moveTimeMs = Math.max(180, Math.min(600, Math.round(Math.max(8, Number(depth) || 18) * 20)));
  const result = await getLegacyArenaEngine().bestMove(chess.fen(), {
    skill: legacySkill,
    moveTimeMs,
    timeoutMs: Math.max(3500, moveTimeMs * 5)
  });
  if (!result?.uci) throw new Error('Stockfish 10 không trả về nước đi hợp lệ.');
  const legal = new Set(chess.moves({ verbose: true }).map(uciForMove));
  if (!legal.has(result.uci)) throw new Error(`Stockfish 10 trả về nước không hợp lệ: ${result.uci}`);
  if (result.depth) engineSpeed = { depth: result.depth, nps: 0, label: 'Stockfish 10 · JavaScript' };
  arenaEngineWarning = '';
  return result.uci;
}

async function chooseArenaUci(player, chess, depth, skill, options = {}) {
  const profile = ['stockfish', 'stockfish-legacy'].includes(player.type) ? 'classic' : (player.profile || 'classic');
  const requestedStrength = options.strengthMode === 'elo' ? resolveStockfishStrength(options.elo) : null;
  if (player.type === 'offline' && settings.openingBookEnabled) {
    const bookMove = pickPersonaBookMove(chess, profile, OPENINGS, { recentChoices: recentOpeningChoices });
    if (bookMove) return uciForMove(bookMove);
  }
  // Use the same opening book for the new and legacy engine so the comparison begins fairly.
  if (['stockfish', 'stockfish-legacy'].includes(player.type) && settings.openingBookEnabled && chess.history().length < 14 && requestedStrength?.mode !== 'skill-level-floor') {
    const bookMove = findOpeningBookMove(chess, OPENINGS, { maxPlies: 20, recentChoices: recentOpeningChoices });
    if (bookMove) return uciForMove(bookMove);
  }
  if (player.type === 'stockfish-legacy') {
    try {
      const uci = await requestLegacyArenaUci(chess, depth, skill, options);
      arenaLastNote = 'Stockfish 10 · engine cổ điển riêng biệt, đã kiểm tra nước đi hợp lệ.';
      return uci;
    } catch (legacyError) {
      // Never strand a bot-versus-bot match when a legacy asm.js Worker fails to load.
      // Try the installed Stockfish 19 worker first, then the in-app alpha-beta engine.
      const legal = new Set(chess.moves({ verbose: true }).map(uciForMove));
      try {
        const recovered = await requestStockfishUci(chess.fen(), {
          skill: Math.min(20, Math.max(0, skill)), depth: Math.max(8, Number(depth) || 16),
          strengthMode: 'max', moveTimeMs: Math.max(650, Math.min(2200, Math.round(Math.max(8, Number(depth) || 16) * 70))), multiPv: 1
        });
        const uci = Array.isArray(recovered) ? recovered[0]?.uci : recovered;
        if (uci && legal.has(uci)) {
          arenaLastNote = `Stockfish 10 không khởi chạy; đã chuyển sang Stockfish 19. (${String(legacyError?.message || legacyError).slice(0, 100)})`;
          return uci;
        }
      } catch (recoveryError) { console.warn('[VILA Arena] Stockfish 19 fallback failed:', recoveryError?.message || recoveryError); }
      const offlineUci = await chooseAlternateMoveAsync(chess.fen(), { profile: 'classic', seen: repetitionContext(chess), maxTimeMs: 1600 });
      if (offlineUci && legal.has(offlineUci)) {
        recordEngineSpeed('VILA offline fallback', getLastOfflineEngineStats());
        arenaLastNote = 'Stockfish 10 không khả dụng; trận vẫn chạy bằng bộ tìm kiếm offline VILA.';
        return offlineUci;
      }
      throw new Error(`Stockfish 10 và các engine dự phòng đều không hoạt động: ${String(legacyError?.message || legacyError)}`);
    }
  }
  if (player.type === 'offline' && ['rookie', 'mentor'].includes(profile)) {
    // Rookie intentionally plays a gentler game while still using legal Stockfish candidates.
    const strength = { strengthMode: 'elo', elo: profile === 'mentor' ? 1050 : 1450, skill: profile === 'mentor' ? Math.min(5, skill) : Math.min(10, skill), depth: profile === 'mentor' ? Math.min(10, depth) : depth, moveTimeMs: profile === 'mentor' ? 380 : 900, multiPv: profile === 'mentor' ? 4 : 2 };
    try {
      const result = await requestStockfishUci(chess.fen(), strength);
      if (Array.isArray(result) && result.length) return [...result].sort((a, b) => Number(b.score || 0) - Number(a.score || 0))[Math.min(result.length - 1, profile === 'mentor' ? result.length - 1 : 0)]?.uci || result[0]?.uci;
      return result;
    } catch {}
  }
  try {
    const moveTimeMs = Math.max(700, Math.min(1500, Math.round(Math.max(8, Number(depth) || 18) * 45)));
    const result = await requestStockfishUci(chess.fen(), {
      skill: player.type === 'stockfish' ? skill : 20,
      depth,
      strengthMode: player.type === 'stockfish' ? (options.strengthMode || 'max') : 'max',
      elo: options.elo || 2600,
      moveTimeMs,
      multiPv: player.type === 'stockfish' ? 1 : 4,
    });
    if (player.type === 'stockfish') return Array.isArray(result) ? result[0]?.uci : result;
    const candidates = Array.isArray(result) ? result : [{ uci: result, score: 0 }];
    const bestScore = Math.max(...candidates.map(item => Number(item.score || 0)));
    const ranked = candidates.map(item => ({ ...item, personalityScore: personaCandidateScore(chess, item, profile, bestScore) })).sort((a, b) => b.personalityScore - a.personalityScore);
    // Preserve tactical quality: personas choose only among searched candidate lines, with a tight score window.
    const tolerance = ['berserk', 'gambit', 'trickster', 'chaos'].includes(profile) ? 95 : ['rookie', 'mentor'].includes(profile) ? 450 : 45;
    const acceptable = ranked.filter(item => bestScore - Number(item.score || 0) <= tolerance);
    const pool = acceptable.length ? acceptable.slice(0, Math.min(3, acceptable.length)) : ranked.slice(0, 1);
    const chosen = [...pool].sort((a, b) => Number(b.personalityScore || 0) - Number(a.personalityScore || 0) || String(a.uci).localeCompare(String(b.uci)))[0] || candidates[0];
    return chosen?.uci || candidates[0]?.uci || '';
  } catch (error) {
    if (player.type === 'stockfish') throw error;
    // The home-grown alpha-beta core remains a functional, legal offline fallback if Stockfish isn't available.
    const fallbackUci = await chooseAlternateMoveAsync(chess.fen(), { profile, seen: repetitionContext(chess), maxTimeMs: 1300 });
    recordEngineSpeed(player.name.replace(' · bot phong cách', ''), getLastOfflineEngineStats());
    if (fallbackUci) { arenaLastNote = `Stockfish chưa sẵn sàng; ${player.name} đã dùng engine offline dự phòng.`; return fallbackUci; }
    throw error;
  }
}
function getArenaOutcome(chess, plyLimit) {
  if (chess.isCheckmate()) return { winner: chess.turn() === 'w' ? 'b' : 'w', result: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'Chiếu hết' };
  if (chess.isDraw()) return { winner: null, result: '1/2-1/2', reason: chess.isStalemate() ? 'Hòa pat' : 'Ván hòa theo luật cờ' };
  if (chess.history().length >= plyLimit) return { winner: null, result: '1/2-1/2', reason: `Chạm giới hạn ${plyLimit} nửa nước — tạm tính hòa` };
  return null;
}
async function playArenaCore(white, black, options = {}) {
  const depth = options.depth || 20, skill = options.skill ?? 20, delayMs = options.delayMs ?? 150, plyLimit = options.plyLimit || 120;
  arenaGame = new Chess(); arenaLastMove = null; arenaLastNote = ''; arenaLastResult = '';
  arenaEngineWarning = '';
  if ([white, black].some(player => player?.type === 'stockfish-legacy')) {
    // Reset the legacy engine exactly once per match. Resetting it every ply
    // discards its hash table and slows down the old JavaScript engine.
    getLegacyArenaEngine().newGame();
  }
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  arenaCurrentPlayers = { w: white, b: black };
  renderArenaPosition();
  while (arenaRunning && !arenaStopRequested && !arenaGame.isGameOver() && arenaGame.history().length < plyLimit) {
    const player = arenaCurrentPlayers[arenaGame.turn()];
    arenaLastNote = `${player.name} đang tính nước đi…`; renderArenaPosition();
    let uci;
    try { uci = await chooseArenaUci(player, arenaGame, depth, skill, options); }
    catch (error) {
      if (arenaStopRequested || error?.name === 'AbortError') break;
      if (['stockfish', 'stockfish-legacy', 'offline'].includes(player.type)) arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
      const errorText = String(error?.message || error || 'lỗi không rõ').slice(0, 150);
      if (player.type === 'stockfish-legacy') {
        console.warn('[VILA Arena] Stockfish 10 search failed; using a legal fallback and retrying next turn.', error);
        arenaEngineWarning = `Stockfish 10 gặp lỗi: ${errorText}. Nước này dùng dự phòng; engine sẽ tự thử lại ở lượt sau.`;
        arenaLastNote = arenaEngineWarning;
      } else {
        arenaLastNote = `Lỗi ${player.name}: ${errorText}`;
      }
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      uci = uciForMove(fallback);
    }
    if (arenaStopRequested || !arenaRunning) break;
    const legal = arenaGame.moves({ verbose: true }).map(uciForMove);
    if (!legal.includes(uci)) {
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      arenaLastNote = `${player.name} trả nước không hợp lệ; đã thay bằng một nước hợp lệ.`;
      uci = uciForMove(fallback);
    }
    try {
      const made = arenaGame.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!made) throw new Error('Nước đi bị luật cờ từ chối.');
      arenaLastMove = { from: made.from, to: made.to };
      playBoardSound(made, arenaGame, settings.soundEnabled);
    } catch (error) {
      arenaLastNote = `Bỏ qua nước không hợp lệ: ${error.message}`;
      continue;
    }
    renderArenaPosition();
    await arenaDelay(delayMs);
  }
  if (arenaGame.isGameOver() || arenaGame.history().length >= plyLimit) {
    const outcome = getArenaOutcome(arenaGame, plyLimit) || { result: '*', reason: positionStatus(arenaGame) };
    arenaLastPgnResult = outcome.result || '*';
    archiveArenaGame(white, black, arenaLastPgnResult, outcome.reason);
    arenaLastResult = `${outcome.reason} · ${outcome.result} · ${white.name} vs ${black.name}`;
    return { ...outcome, white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn() };
  }
  arenaLastPgnResult = '*';
  if (arenaGame.history().length) archiveArenaGame(white, black, '*', 'Đã dừng');
  arenaLastResult = `Đã dừng ván tại ${arenaGame.history().length} nửa nước.`;
  return { winner: null, result: '*', reason: 'Đã dừng', white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn(), stopped: true };
}
async function startArenaMatch(whiteId, blackId) {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish ở bàn Chơi cờ kết thúc rồi mới khởi động đấu trường.'); return; }
  const white = arenaPlayer(whiteId), black = arenaPlayer(blackId);
  if (!white || !black) { toast('Không tìm thấy một trong hai AI.'); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController(); arenaGameCounter++; arenaFallbackMoves = new Map(); arenaPgnArchive = []; arenaLastPgnResult = '*'; arenaEngineWarning = '';
  renderArenaPosition();
  try {
    const result = await playArenaCore(white, black, readArenaOptions());
    if (!result.stopped) {
      const fallbackCount = arenaFallbackMoves.get(white.id) || 0;
      const otherFallback = arenaFallbackMoves.get(black.id) || 0;
      const fallbackTag = fallbackCount + otherFallback ? ` · ${fallbackCount + otherFallback} nước dùng dự phòng khi AI lỗi` : '';
      arenaTournamentSummary = `${result.white} ${result.result} ${result.black} · ${result.reason} · ${result.plies} nửa nước${fallbackTag}`;
    }
    else arenaTournamentSummary = result.reason;
    arenaLastResult = result.reason + (result.result && result.result !== '*' ? ` · ${result.result}` : '');
    renderArenaPosition();
    showArenaResultModal(white, black, result);
  } catch (error) {
    arenaLastResult = `Trận lỗi: ${String(error.message || error).slice(0, 180)}`; arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function readArenaOptions() {
  return { depth: Number($('#arenaDepth')?.value || 20), skill: Number($('#arenaSkill')?.value || 20), strengthMode: $('#arenaEngineMode')?.value === 'elo' ? 'elo' : 'max', elo: Number($('#arenaEngineElo')?.value || 2600), delayMs: Number($('#arenaDelay')?.value ?? 150), plyLimit: Number($('#arenaPlyLimit')?.value || 120) };
}
function stopArenaMatch() {
  if (!arenaRunning) return;
  arenaStopRequested = true;
  arenaAbortController?.abort();
  if (pendingEngineRequest && engineWorker) { try { engineWorker.postMessage('stop'); } catch {} }
  legacyArenaEngine?.stop();
  if ($('#arenaStatus')) $('#arenaStatus').textContent = 'Đang dừng sau khi yêu cầu hiện tại kết thúc…';
}
async function runArenaLeague() {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish hiện tại kết thúc.'); return; }
  const selected = [...arenaSelectedLeague].map(arenaPlayer).filter(Boolean);
  if (selected.length < 2) { toast('Hãy chọn ít nhất hai AI tham gia giải.'); return; }
  if (selected.length > 6) { toast('Để giảm tải thiết bị, mỗi giải giới hạn tối đa 6 bot. Bỏ chọn bớt model rồi thử lại.'); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController();
  arenaPgnArchive = []; arenaLastPgnResult = '*';
  const options = readArenaOptions();
  const scores = new Map(selected.map(player => [player.id, { id: player.id, name: player.name, points: 0, wins: 0, draws: 0, losses: 0, games: 0 }]));
  const pairings = [];
  for (let i=0;i<selected.length;i++) for (let j=i+1;j<selected.length;j++) {
    pairings.push({ a:selected[i], b:selected[j], reverse:false });
    pairings.push({ a:selected[i], b:selected[j], reverse:true });
  }
  arenaFallbackMoves = new Map();
  let complete = 0;
  arenaTournamentSummary = `Đang chạy giải: 0/${pairings.length} ván · mỗi cặp đổi màu hai lượt.`;
  renderArenaPosition();
  try {
    for (let i=0;i<pairings.length;i++) {
      if (arenaStopRequested) break;
      const { a, b, reverse } = pairings[i];
      const white = reverse ? b : a, black = reverse ? a : b;
      const result = await playArenaCore(white, black, options);
      if (result.stopped) break;
      if (result.result === '1-0') { scores.get(white.id).points += 1; scores.get(white.id).wins++; scores.get(black.id).losses++; }
      else if (result.result === '0-1') { scores.get(black.id).points += 1; scores.get(black.id).wins++; scores.get(white.id).losses++; }
      else if (result.result === '1/2-1/2') { scores.get(white.id).points += .5; scores.get(black.id).points += .5; scores.get(white.id).draws++; scores.get(black.id).draws++; }
      scores.get(white.id).games++; scores.get(black.id).games++;
      complete++;
      arenaTournamentSummary = `Giải đang chạy: ${complete}/${pairings.length} ván đã xong.`;
      if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = `${arenaTournamentSummary} ${result.white} ${result.result} ${result.black}`;
      renderArenaPosition();
      await arenaDelay(200);
    }
    const finalStandings = [...scores.values()].sort((a,b)=>b.points-a.points || b.wins-a.wins || a.losses-b.losses || a.name.localeCompare(b.name));
    if (complete > 0) {
      arenaCupStandings = finalStandings.map((entry, index) => ({ ...entry, rank: index + 1, playedAt: Date.now() }));
      try { localStorage.setItem('vila.chess.arena-cup-standings.v1', JSON.stringify(arenaCupStandings)); } catch {}
      recordDailyEvent('complete_arena');
      syncArenaCupPodium();
    }
    const table = finalStandings.map((x,i)=>`${['🥇','🥈','🥉'][i] || `${i+1}.`} ${x.name}: ${x.points.toFixed(1)} điểm · ${x.wins} thắng / ${x.draws} hòa / ${x.losses} thua${arenaFallbackMoves.get(x.id) ? ` · ${arenaFallbackMoves.get(x.id)} nước dự phòng` : ''}`).join('\n');
    const champion = finalStandings[0];
    arenaTournamentSummary = `${arenaStopRequested ? 'GIẢI ĐÃ DỪNG' : '🏆 NHÀ VÔ ĐỊCH CÚP VILA'} (${complete}/${pairings.length} ván)${complete && champion ? `\n🥇 ${champion.name} · ${champion.points.toFixed(1)} điểm` : ''}\n${table}`;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    arenaLastResult = arenaStopRequested ? 'Giải đã dừng theo yêu cầu.' : `Giải hoàn tất · ${complete} ván.`;
    renderArenaPosition();
  } catch (error) {
    arenaLastResult = `Giải gặp lỗi: ${String(error.message || error).slice(0, 180)}`;
    arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function pgnEscape(value) { return String(value || '').replace(/[\\"]+/g, '').slice(0, 120); }
function archiveArenaGame(white, black, result, reason) {
  const outcome = result || '*';
  const moves = (arenaGame.pgn() || '').trim();
  const gamePgn = moves && /(?:1-0|0-1|1\/2-1\/2|\*)$/.test(moves) ? moves : `${moves}${moves ? ' ' : ''}${outcome}`;
  const headers = `[Event "Cờ Vua ViLa AI Arena"]\n[Site "Cờ Vua ViLa"]\n[White "${pgnEscape(white?.name || 'White')}"]\n[Black "${pgnEscape(black?.name || 'Black')}"]\n[Result "${outcome}"]\n[Annotator "${pgnEscape(reason || 'AI Arena')}"]`;
  arenaPgnArchive.push(`${headers}\n\n${gamePgn}`);
}
function downloadArenaPgn() {
  const pgn = arenaPgnArchive.length ? arenaPgnArchive.join('\n\n') : (() => {
    const headers = `[Event "Cờ Vua ViLa AI Arena"]\n[Site "Cờ Vua ViLa"]\n[White "${pgnEscape(arenaCurrentPlayers.w?.name || 'White')}"]\n[Black "${pgnEscape(arenaCurrentPlayers.b?.name || 'Black')}"]\n[Result "${arenaLastPgnResult}"]\n[Annotator "${pgnEscape(arenaLastResult || 'AI Arena')}"]`;
    return `${headers}\n\n${arenaGame.pgn() || '*'}`;
  })();
  downloadTextFile(pgn, 'covua-vila-ai-arena.pgn', 'application/x-chess-pgn;charset=utf-8');
}



function renderLeaderboardView() {
  const profile = readRatingProfile(); const history = readRatingHistory().slice().reverse();
  const rows = history.map((item, index) => `<tr><td>${history.length - index}</td><td>${esc(new Date(item.date).toLocaleDateString())}</td><td>${esc(item.opponent || 'Bot')}</td><td>${esc(item.title || item.result)}</td><td class="rating-change ${item.change > 0 ? 'positive' : item.change < 0 ? 'negative' : ''}">${item.change > 0 ? '+' : ''}${Number(item.change || 0)}</td><td>${Number(item.elo || 1200)}</td></tr>`).join('');
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">HỒ SƠ CỜ VUA</div><h1>Bảng xếp hạng</h1><p>Top 100 trực tuyến lấy từ máy chủ cộng đồng; lịch sử Elo cục bộ vẫn được giữ riêng trên thiết bị.</p></div><section class="panel server-top100-panel"><div class="panel-heading"><div><small class="eyebrow">CỜ VUA VILA COMMUNITY</small><h2>Top 100 người chơi</h2></div><button class="secondary-btn" id="refreshTop100" type="button">↻ Làm mới</button></div><div id="serverTop100Status" class="field-hint">Đang tải bảng xếp hạng từ máy chủ…</div><div id="serverTop100Rows" class="server-top100-list"><div class="empty-state">Đang tải dữ liệu…</div></div></section><div class="rating-summary-grid"><article class="panel rating-hero"><small>ĐIỂM ELO CỦA BẠN</small><strong>${profile.elo}</strong><span>${profile.lastChange > 0 ? '+' : ''}${profile.lastChange} điểm ở ván gần nhất</span></article><article class="panel rating-stat"><small>Ván đã tính</small><strong>${profile.games}</strong></article><article class="panel rating-stat"><small>Thắng / Hòa / Thua</small><strong>${profile.wins} / ${profile.draws} / ${profile.losses}</strong></article><article class="panel rating-stat"><small>Tỉ lệ thắng</small><strong>${profile.games ? Math.round(profile.wins / profile.games * 100) : 0}%</strong></article></div><section class="panel leaderboard-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ XẾP HẠNG</small><h2>Kết quả gần đây</h2></div><span class="context-icon">♜</span></div>${rows ? `<div class="leaderboard-table-wrap"><table class="leaderboard-table"><thead><tr><th>#</th><th>Ngày</th><th>Đối thủ</th><th>Kết quả</th><th>Δ Elo</th><th>Elo</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="empty-state">Chưa có ván nào được tính Elo. Chơi một ván với Stockfish hoặc bot cục bộ để bắt đầu bảng xếp hạng.</div>'}<div class="field-hint">Tài khoản thường bắt đầu 1200 Elo · admin bootstrap có mức khởi tạo riêng · K-factor 24 · Elo bot là ước lượng. Lịch sử chỉ lưu cục bộ và không đồng bộ giữa các thiết bị.</div></section></section>`;
}

function renderTop100Rows(users = []) {
  if (!users.length) return '<div class="empty-state">Chưa có tài khoản cộng đồng nào. Đăng ký ở mục Bạn bè để xuất hiện trong bảng xếp hạng.</div>';
  return users.map(user => `<article class="top100-row"><span class="top100-rank rank-${Number(user.rank) <= 3 ? Number(user.rank) : 'other'}">${Number(user.rank) <= 3 ? ['🥇','🥈','🥉'][Number(user.rank)-1] : `#${Number(user.rank)}`}</span><span class="top100-avatar">${esc((user.displayName || user.username || '?').slice(0,1).toUpperCase())}</span><span class="top100-player"><b>${esc(user.displayName || user.username)}</b><small>@${esc(user.username)} · ${user.role === 'admin' ? '🛡 Admin · Elo khởi tạo' : (user.online ? '🟢 Đang hoạt động' : `${Number(user.games || 0)} ván đã ghi nhận`)}</small></span><strong class="top100-elo">${Number(user.elo || 1200)} <small>Elo</small></strong></article>`).join('');
}
async function loadTop100() {
  const rows = $('#serverTop100Rows'), status = $('#serverTop100Status');
  if (!rows) return;
  if (status) status.textContent = 'Đang tải dữ liệu từ máy chủ…';
  try {
    const data = await socialApi('/leaderboard?limit=100');
    socialState.leaderboard = Array.isArray(data.users) ? data.users : [];
    if ($('#serverTop100Rows')) $('#serverTop100Rows').innerHTML = renderTop100Rows(socialState.leaderboard);
    if ($('#serverTop100Status')) $('#serverTop100Status').textContent = `${Number(data.totalPlayers || 0)} tài khoản trên máy chủ · Cập nhật ${new Date(data.generatedAt || Date.now()).toLocaleTimeString()}. Tài khoản thường bắt đầu ở 1200 Elo; admin bootstrap có Elo khởi tạo cấu hình riêng. Các trận xếp hạng cần được máy chủ xác minh trước khi ghi điểm.`;
  } catch (error) {
    if ($('#serverTop100Rows')) $('#serverTop100Rows').innerHTML = `<div class="empty-state">${esc(error.message || 'Chưa kết nối được máy chủ.')}</div>`;
    if ($('#serverTop100Status')) $('#serverTop100Status').textContent = 'Không thể tải Top 100. Hãy kiểm tra địa chỉ backend trong Cài đặt và bảo đảm server đang chạy.';
  }
}
function wireLeaderboardActions() { $('#refreshTop100')?.addEventListener('click', loadTop100); loadTop100(); }

function renderFriendsView() {
  const user = socialState.user;
  const authPanel = !user ? `<div class="social-auth-grid"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN CỘNG ĐỒNG</small><h2>Đăng nhập</h2></div><span class="context-icon">♙</span></div><form id="socialLoginForm"><label class="field-label" for="socialLoginName">Tên đăng nhập hoặc email</label><input class="field" id="socialLoginName" name="username" autocomplete="username" maxlength="254" required placeholder="Tên tài khoản"/><label class="field-label" for="socialLoginPassword">Mật khẩu</label><input class="field" id="socialLoginPassword" name="password" autocomplete="current-password" type="password" minlength="12" maxlength="256" required placeholder="Tối thiểu 12 ký tự"/><button class="primary-btn full-width social-submit" type="submit">Đăng nhập</button></form><div class="social-oauth-divider"><span>hoặc đăng nhập bằng</span></div><div class="social-oauth-actions"><button class="secondary-btn" type="button" data-social-oauth="google"><b>G</b> Google</button><button class="secondary-btn" type="button" data-social-oauth="facebook"><b>f</b> Facebook</button><button class="secondary-btn" type="button" data-social-oauth="github">GitHub</button></div><p class="field-hint">Google/GitHub chỉ hoạt động sau khi chủ server khai báo OAuth Client ID, Client Secret và callback URL. Không cần Firebase.</p><div class="firebase-quick-sync-card"><div class="firebase-sync-badge"><span class="firebase-icon">🔥</span><b>Firebase Cloud Sync & Auth</b><span class="sync-state-pill ${isFirebaseConfigured() ? 'is-active' : ''}">${isFirebaseConfigured() ? 'Đã kích hoạt' : 'Ngoại tuyến'}</span></div><p class="field-hint">Không bắt buộc đăng nhập để chơi ngoại tuyến. Mọi ván đấu và điểm số được lưu an toàn trên máy.</p><div class="button-row"><button type="button" class="secondary-btn" id="openFirebaseModalBtn">⚙ Cấu hình Firebase</button><button type="button" class="primary-btn" id="triggerCloudSyncBtn">☁ Đồng bộ lịch sử</button></div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">BẮT ĐẦU CHƠI CÙNG CỘNG ĐỒNG</small><h2>Tạo tài khoản</h2></div><span class="context-icon">✦</span></div><form id="socialRegisterForm"><label class="field-label" for="socialRegisterName">Tên đăng nhập</label><input class="field" id="socialRegisterName" name="username" autocomplete="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_.-]{3,24}" required placeholder="ví dụ: vila_player"/><label class="field-label" for="socialRegisterDisplay">Tên hiển thị</label><input class="field" id="socialRegisterDisplay" name="displayName" minlength="2" maxlength="40" required placeholder="Tên bạn muốn mọi người thấy"/><label class="field-label" for="socialRegisterEmail">Email (không bắt buộc)</label><input class="field" id="socialRegisterEmail" name="email" autocomplete="email" type="email" maxlength="254" placeholder="ban@example.com"/><label class="field-label" for="socialRegisterPassword">Mật khẩu</label><input class="field" id="socialRegisterPassword" name="password" autocomplete="new-password" type="password" minlength="12" maxlength="256" required placeholder="Ít nhất 12 ký tự"/><button class="primary-btn full-width social-submit" type="submit">Tạo tài khoản</button></form><p class="field-hint">Mật khẩu được băm bằng scrypt trên server; không lưu mật khẩu dạng văn bản. Hãy dùng mật khẩu riêng cho Cờ Vua ViLa.</p></section></div>` : `<section class="panel social-profile-panel"><div class="social-profile-main"><div class="social-big-avatar">${esc((user.displayName || user.username || 'V').slice(0,1).toUpperCase())}</div><div class="social-profile-info"><small class="eyebrow">HỒ SƠ CỜ VUA VILA</small><h2>${esc(user.displayName || user.username)}</h2><p>@${esc(user.username)} · ${user.role === 'admin' ? 'Quản trị viên' : 'Người chơi'} · ${Number(user.elo || 1200)} Elo</p></div><button class="secondary-btn" type="button" id="socialLogout">Đăng xuất</button></div><div class="profile-sync-row"><button type="button" class="primary-btn" id="triggerCloudSyncBtn">☁ Đồng bộ đám mây (${readSavedGames().length} ván)</button><button type="button" class="secondary-btn" id="openFirebaseModalBtn">⚙ Cài đặt Firebase</button></div><form id="socialProfileForm" class="social-profile-edit"><div><label class="field-label" for="socialProfileDisplay">Tên hiển thị</label><input class="field" id="socialProfileDisplay" maxlength="40" minlength="2" required value="${esc(user.displayName || user.username)}"/></div><div><label class="field-label" for="socialProfileBio">Giới thiệu</label><input class="field" id="socialProfileBio" maxlength="180" value="${esc(user.bio || '')}" placeholder="Giới thiệu ngắn về bạn"/></div><button class="secondary-btn" type="submit">Lưu hồ sơ</button></form></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI CỘNG ĐỒNG</small><h2>Tìm bạn bè</h2></div><span class="context-icon">⌕</span></div><form id="socialSearchForm" class="social-search-row"><input class="field" id="socialSearchName" minlength="2" maxlength="30" required placeholder="Tìm theo tên hoặc username"/><button class="primary-btn" type="submit">Tìm</button></form><div id="socialSearchResults" class="social-person-list"><div class="empty-state">Nhập tên người chơi để tìm bạn.</div></div></section><div class="social-friends-grid"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">DANH SÁCH CỦA BẠN</small><h2>Bạn bè <span id="socialFriendCount"></span></h2></div><button class="secondary-btn" id="refreshFriends" type="button">↻</button></div><div id="socialFriendsList" class="social-person-list"><div class="empty-state">Đang tải bạn bè…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">LỜI MỜI</small><h2>Lời mời kết bạn</h2></div></div><h3>Đang chờ bạn phản hồi</h3><div id="socialIncomingList" class="social-person-list"></div><h3 class="social-subheading">Đã gửi</h3><div id="socialOutgoingList" class="social-person-list"></div></section></div>`;
  return `<section class="content-page social-page"><div class="page-intro"><div class="eyebrow">CỜ VUA VILA COMMUNITY</div><h1>Bạn bè & tài khoản</h1><p>Đăng nhập để tạo hồ sơ cộng đồng, kết nối người chơi và chuẩn bị cho thi đấu xếp hạng trực tuyến. Tài khoản và quan hệ bạn bè được lưu trên máy chủ.</p></div>${authPanel}<p class="field-hint social-status" id="socialPageStatus">${socialState.token ? 'Đã lưu phiên đăng nhập trên thiết bị này.' : 'Tạo tài khoản để thêm bạn bè và xuất hiện trong Top 100.'}</p></section>`;
}
async function loadFriendsSnapshot() {
  if (!socialState.token || currentView !== 'friends') return;
  try {
    const data = await socialApi('/friends');
    socialState.friends = data.friends || []; socialState.incoming = data.incoming || []; socialState.outgoing = data.outgoing || [];
    captureIncomingFriendNotifications(socialState.incoming);
    const friends = $('#socialFriendsList'), incoming = $('#socialIncomingList'), outgoing = $('#socialOutgoingList');
    if (friends) friends.innerHTML = socialState.friends.length ? socialState.friends.map(u => `<article class="social-person-row"><span class="social-person-avatar">${esc((u.displayName || u.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(u.displayName)}</b><small>@${esc(u.username)} · ${u.online ? '🟢 Online' : 'Ngoại tuyến'} · ${Number(u.elo || 1200)} Elo</small></span><button class="tiny-btn" data-remove-friend="${esc(u.id)}" aria-label="Xóa bạn">×</button></article>`).join('') : '<div class="empty-state">Chưa có bạn bè. Tìm username phía trên để gửi lời mời.</div>';
    if (incoming) incoming.innerHTML = socialState.incoming.length ? socialState.incoming.map(r => `<article class="social-person-row"><span class="social-person-avatar">${esc((r.user.displayName || r.user.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(r.user.displayName)}</b><small>@${esc(r.user.username)} muốn kết bạn</small></span><button class="tiny-btn social-accept" data-accept-friend="${esc(r.id)}" aria-label="Chấp nhận">✓</button></article>`).join('') : '<div class="small-empty">Không có lời mời mới.</div>';
    if (outgoing) outgoing.innerHTML = socialState.outgoing.length ? socialState.outgoing.map(r => `<article class="social-person-row"><span class="social-person-meta"><b>${esc(r.user.displayName)}</b><small>@${esc(r.user.username)} · Đang chờ</small></span><button class="tiny-btn" data-remove-friend="${esc(r.user.id)}" aria-label="Hủy lời mời">×</button></article>`).join('') : '<div class="small-empty">Chưa gửi lời mời nào.</div>';
    if ($('#socialFriendCount')) $('#socialFriendCount').textContent = `(${socialState.friends.length})`;
  } catch (error) { socialHandleError(error); }
}
function renderInboxView() {
  const unread = unreadNotificationCount(appNotifications);
  const rows = [...appNotifications].reverse().map(item => {
    const typeLabel = item.type === 'error' ? 'Lỗi' : item.type === 'warning' ? 'Cảnh báo' : item.type === 'success' ? 'Thành công' : 'Thông tin';
    const date = new Date(item.createdAt);
    const dateLabel = Number.isFinite(date.getTime()) ? date.toLocaleString() : 'Không rõ thời gian';
    return `<article class="inbox-notice ${item.read ? 'is-read' : 'is-unread'} notice-${esc(item.type)}"><span class="inbox-notice-mark" aria-hidden="true">${item.type === 'error' ? '!' : item.type === 'warning' ? '⚠' : item.type === 'success' ? '✓' : '•'}</span><div class="inbox-notice-body"><div class="inbox-notice-head"><b>${esc(item.title)}</b><span>${typeLabel}</span></div><p>${esc(item.message)}</p><time datetime="${esc(item.createdAt)}">${esc(dateLabel)}</time></div>${item.read ? '' : `<button type="button" class="tiny-btn" data-mark-notification="${esc(item.id)}" aria-label="Đánh dấu đã đọc">✓</button>`}</article>`;
  }).join('');
  return `<section class="content-page inbox-page"><div class="page-intro"><div class="eyebrow">THÔNG BÁO TRÊN THIẾT BỊ</div><h1>Hộp thư</h1><p>Hiển thị cảnh báo engine, trạng thái tài khoản và lời mời kết bạn đã được ứng dụng nhận. Đây là hộp thư trong ứng dụng, chưa phải thông báo đẩy Android khi ứng dụng đóng.</p></div><div class="inbox-toolbar panel"><div><b>${unread} chưa đọc</b><small>${appNotifications.length} thông báo được lưu trên thiết bị</small></div><div class="inbox-toolbar-actions"><button type="button" class="secondary-btn" id="markAllNotificationsRead" ${unread ? '' : 'disabled'}>Đánh dấu đã đọc</button><button type="button" class="secondary-btn" id="clearReadNotifications" ${appNotifications.some(item => item.read) ? '' : 'disabled'}>Xóa đã đọc</button></div></div><div class="inbox-list">${rows || '<section class="panel empty-state inbox-empty"><b>Hộp thư đang trống</b><p>Khi engine gặp lỗi, đăng nhập thành công hoặc có lời mời bạn bè mà ứng dụng nhận được, thông báo sẽ xuất hiện ở đây.</p><button type="button" class="secondary-btn" data-home-view="health">Kiểm tra hệ thống</button></section>'}</div></section>`;
}
function wireInboxActions() {
  $$('[data-mark-notification]').forEach(button => button.addEventListener('click', () => {
    appNotifications = markNotificationRead(appNotifications, button.dataset.markNotification);
    persistNotifications(); syncInboxBadge(); renderView();
  }));
  $('#markAllNotificationsRead')?.addEventListener('click', () => {
    appNotifications = markAllNotificationsRead(appNotifications);
    persistNotifications(); syncInboxBadge(); renderView();
  });
  $('#clearReadNotifications')?.addEventListener('click', () => {
    appNotifications = clearReadNotifications(appNotifications);
    persistNotifications(); syncInboxBadge(); renderView();
  });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
}
function localStorageCheck() {
  const key = `${NOTIFICATIONS_KEY}.health-check`;
  try { localStorage.setItem(key, 'ok'); localStorage.removeItem(key); return true; }
  catch { return false; }
}
function renderSystemHealthView() {
  const protocolHasBackend = location.protocol === 'http:' || location.protocol === 'https:';
  const backendConfigured = Boolean(String(settings.backendUrl || '').trim()) || protocolHasBackend;
  const checks = buildSystemChecks({
    engineReady,
    engineFailed,
    workerSupported: typeof Worker === 'function',
    storageAvailable: localStorageCheck(),
    openingCount: OPENINGS.length,
    backendStatus: healthBackendStatus,
    backendConfigured
  });
  const statusText = { ok: 'Đạt', warning: 'Cần cấu hình', pending: 'Đang chờ', error: 'Cần xử lý' };
  const rows = checks.map(check => `<article class="health-check-row health-${check.status}"><span class="health-check-icon" aria-hidden="true">${check.status === 'ok' ? '✓' : check.status === 'warning' ? '!' : check.status === 'pending' ? '…' : '×'}</span><div><div class="health-check-heading"><b>${esc(check.label)}</b><span>${statusText[check.status] || 'Chưa rõ'}</span></div><p>${esc(check.detail)}</p></div></article>`).join('');
  const errors = checks.filter(check => check.status === 'error').length;
  const warnings = checks.filter(check => check.status === 'warning' || check.status === 'pending').length;
  return `<section class="content-page health-page"><div class="page-intro"><div class="eyebrow">CHẨN ĐOÁN THỰC TẾ</div><h1>Kiểm tra hệ thống</h1><p>Trang này kiểm tra trạng thái hiện tại, không tự đánh dấu đạt nếu engine, backend hoặc dữ liệu khai cuộc chưa thực sự sẵn sàng.</p></div><section class="panel health-summary"><div><span class="eyebrow">KẾT QUẢ LẦN KIỂM TRA</span><h2>${errors ? `${errors} mục cần xử lý` : warnings ? `${warnings} mục chưa xác minh` : 'Các mục đã kiểm tra đều đạt'}</h2><p>Engine: ${engineReady ? 'sẵn sàng' : engineFailed ? 'đang lỗi' : 'đang khởi tạo'} · Kho khai cuộc đang nạp: ${OPENINGS.length.toLocaleString()} dòng</p></div><div class="health-actions"><button type="button" class="primary-btn" id="runHealthChecks">↻ Kiểm tra lại</button><button type="button" class="secondary-btn" id="healthRetryEngine">Tải lại engine</button><button type="button" class="secondary-btn" data-health-settings>Cài đặt backend</button></div></section><div class="health-check-list" id="healthCheckList">${rows}</div><p class="field-hint health-disclaimer">Lời mời bạn bè, đăng nhập Google/GitHub và Top 100 cần backend thật. Kho khai cuộc chỉ được báo đủ khi nạp ít nhất ${REQUIRED_OPENING_COUNT.toLocaleString()} dòng dữ liệu; tệp fallback rỗng không được xem là kho đầy đủ.</p></section>`;
}
async function runSystemHealthChecks() {
  healthBackendStatus = 'checking';
  const list = $('#healthCheckList');
  if (list) list.innerHTML = '<div class="panel empty-state">Đang kiểm tra phản hồi backend…</div>';
  if (currentView === 'health') {
    const temp = $('#mainView');
    if (temp) temp.innerHTML = renderSystemHealthView();
    wireSystemHealthActions(false);
  }
  const configured = String(settings.backendUrl || '').trim().replace(/\/$/, '');
  if (!configured && location.protocol !== 'http:' && location.protocol !== 'https:') {
    healthBackendStatus = 'not-configured';
  } else {
    try {
      const response = await fetch(`${configured}/api/health`, { cache: 'no-store', signal: AbortSignal.timeout(8000) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (data?.ok !== true) throw new Error('Health endpoint did not report ok=true');
      healthBackendStatus = 'online';
    } catch (error) {
      healthBackendStatus = String(error?.message || error || 'Không kết nối được');
    }
  }
  if (currentView === 'health') renderView();
}
function wireSystemHealthActions(runOnMount = true) {
  $('#runHealthChecks')?.addEventListener('click', () => { void runSystemHealthChecks(); });
  $('#healthRetryEngine')?.addEventListener('click', retryStockfishEngine);
  $('[data-health-settings]')?.addEventListener('click', () => setView('settings'));
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  if (runOnMount && healthBackendStatus === 'unknown') void runSystemHealthChecks();
}
async function pollSocialInbox() {
  if (!socialState.token || document.visibilityState !== 'visible') return;
  try {
    const token = socialState.token;
    const identity = await socialApi('/auth/me');
    if (socialState.token !== token) return;
    saveSocialSession(token, identity.user);
    const data = await socialApi('/friends');
    if (socialState.token !== token) return;
    captureIncomingFriendNotifications(data.incoming);
    if (currentView === 'friends') await loadFriendsSnapshot();
  } catch (error) {
    const message = String(error?.message || error || '');
    if (/HTTP 401|HTTP 403|Phiên đăng nhập hết hạn|phiên đăng nhập/i.test(message) && socialState.token) {
      saveSocialSession('', null);
      addAppNotification({ title: 'Phiên đăng nhập đã hết hạn', message: 'Hãy đăng nhập lại để dùng bạn bè, hộp thư cộng đồng và Top 100.', type: 'warning', sourceKey: `session-expired:${new Date().toISOString().slice(0, 10)}` });
    } else console.info('[Cờ Vua ViLa] Background inbox sync skipped:', message);
  }
}

function wireFriendsActions() {
  $('#socialLoginForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true; try { const data = await socialApi('/auth/login', { method: 'POST', body: JSON.stringify({ username: $('#socialLoginName').value, password: $('#socialLoginPassword').value }) }); if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ. Chưa thể xác nhận đăng nhập.'); saveSocialSession(data.token, data.user); addAppNotification({ title: 'Đăng nhập thành công', message: `Xin chào ${data.user?.displayName || data.user?.username || 'bạn'}.`, type: 'success', sourceKey: `login:${data.user?.id || data.user?.username}:${new Date().toISOString().slice(0, 10)}` }); toast('Đăng nhập thành công.'); renderView(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } });
  $('#socialRegisterForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true; try { const data = await socialApi('/auth/register', { method: 'POST', body: JSON.stringify({ username: $('#socialRegisterName').value, displayName: $('#socialRegisterDisplay').value, email: $('#socialRegisterEmail').value, password: $('#socialRegisterPassword').value }) }); if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ. Chưa thể xác nhận đăng ký.'); saveSocialSession(data.token, data.user); addAppNotification({ title: 'Tài khoản đã tạo', message: 'Hồ sơ Cờ Vua ViLa đã được tạo trên máy chủ.', type: 'success' }); toast('Đã tạo tài khoản Cờ Vua ViLa.'); renderView(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } });
  $('#socialLogout')?.addEventListener('click', () => { saveSocialSession('', null); socialState.friends = []; socialState.incoming = []; socialState.outgoing = []; toast('Đã đăng xuất.'); renderView(); });
  $('#socialProfileForm')?.addEventListener('submit', async event => { event.preventDefault(); try { const data = await socialApi('/profile', { method: 'PATCH', body: JSON.stringify({ displayName: $('#socialProfileDisplay').value, bio: $('#socialProfileBio').value }) }); saveSocialSession(socialState.token, data.user); toast('Đã lưu hồ sơ.'); renderView(); } catch (error) { socialHandleError(error); } });
  $('#socialSearchForm')?.addEventListener('submit', async event => { event.preventDefault(); const output = $('#socialSearchResults'); if (!output) return; output.innerHTML = '<div class="small-empty">Đang tìm…</div>'; try { const data = await socialApi(`/users/search?q=${encodeURIComponent($('#socialSearchName').value)}`); socialState.searchResults = data.users || []; output.innerHTML = socialState.searchResults.length ? socialState.searchResults.map(u => `<article class="social-person-row"><span class="social-person-avatar">${esc((u.displayName || u.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(u.displayName)}</b><small>@${esc(u.username)} · ${u.online ? '🟢 Online' : `${Number(u.elo || 1200)} Elo`}</small></span><button class="tiny-btn social-add" data-add-friend="${esc(u.username)}" aria-label="Gửi lời mời">+</button></article>`).join('') : '<div class="empty-state">Không tìm thấy người chơi phù hợp.</div>'; } catch (error) { output.innerHTML = `<div class="small-empty">${esc(error.message)}</div>`; } });
  $('#refreshFriends')?.addEventListener('click', loadFriendsSnapshot);
  $$('[data-accept-friend]').forEach(button => button.addEventListener('click', async () => { button.disabled = true; try { await socialApi(`/friends/${encodeURIComponent(button.dataset.acceptFriend)}/accept`, { method: 'POST', body: '{}' }); toast('Đã chấp nhận lời mời.'); await loadFriendsSnapshot(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } }));
  $$('[data-remove-friend]').forEach(button => button.addEventListener('click', async () => { const friendId = button.dataset.removeFriend; if (!confirm('Xóa bạn bè hoặc hủy lời mời này?')) return; try { await socialApi(`/friends/${encodeURIComponent(friendId)}`, { method: 'DELETE' }); await loadFriendsSnapshot(); } catch (error) { socialHandleError(error); } }));
  $$('[data-social-oauth]').forEach(button => button.addEventListener('click', async () => {
    const provider = button.dataset.socialOauth;
    if (isFirebaseConfigured() && (provider === 'google' || provider === 'facebook')) {
      try {
        toast(`Đang kết nối ${provider === 'google' ? 'Google' : 'Facebook'} qua Firebase...`);
        const user = await authenticateWithFirebase(provider);
        saveSocialSession(user.idToken, user);
        toast(`Đăng nhập ${user.displayName} thành công!`, 'success');
        renderView();
        return;
      } catch (err) {
        toast(err.message, 'warning');
      }
    }
    try { const base = socialBackendBase(); location.href = `${base}/api/social/auth/oauth/${provider}/start`; } catch (error) { socialHandleError(error); }
  }));
  $('#openFirebaseModalBtn')?.addEventListener('click', () => {
    setView('settings');
    setTimeout(() => { $('#firebaseConfigSection')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 150);
  });
  $('#triggerCloudSyncBtn')?.addEventListener('click', async () => {
    toast('Đang đồng bộ dữ liệu ván đấu lên đám mây...');
    const result = await syncHistoryToCloud(settings.backendUrl || '', socialState.token || '', readSavedGames());
    toast(result.message, result.ok ? 'success' : 'info');
  });
  $$('[data-add-friend]').forEach(button => button.addEventListener('click', async () => { button.disabled = true; try { const data = await socialApi('/friends/request', { method: 'POST', body: JSON.stringify({ username: button.dataset.addFriend }) }); toast(data.message || 'Đã gửi lời mời.'); button.textContent = '✓'; await loadFriendsSnapshot(); } catch (error) { socialHandleError(error); button.disabled = false; } }));
  loadFriendsSnapshot();
}
function renderMissionsView() {
  const state = readDailyProgress();
  const summary = getMissionSummary(state);
  const cards = DAILY_MISSIONS.map(mission => {
    const progress = Math.min(mission.goal, Number(state.missionProgress[mission.id] || 0));
    const completed = progress >= mission.goal;
    const claimed = state.claimed.includes(mission.id);
    return `<article class="mission-card panel"><div class="mission-card-top"><span class="mission-card-icon">${mission.icon}</span><span class="mission-card-category">${esc(mission.category || 'Thử thách')}</span><span class="mission-reward">◈ ${mission.reward} xu</span></div><h2>${esc(mission.title)}</h2><p>${esc(mission.description)}</p><div class="mission-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${mission.goal}" aria-valuenow="${progress}"><span style="width:${Math.round(progress / mission.goal * 100)}%"></span></div><div class="mission-card-bottom"><small>${progress}/${mission.goal} ${completed ? '· Hoàn thành' : '· Chưa hoàn thành'}</small>${claimed ? '<span class="mission-claimed">✓ Đã nhận</span>' : `<button type="button" class="${completed ? 'primary-btn' : 'secondary-btn'}" data-claim-mission="${mission.id}" ${completed ? '' : 'disabled'}>${completed ? 'Nhận thưởng' : 'Chưa xong'}</button>`}</div></article>`;
  }).join('');
  return `<section class="content-page progression-page"><div class="page-intro"><div class="eyebrow">THÓI QUEN NHỎ · TIẾN BỘ MỖI NGÀY</div><h1>Nhiệm vụ hằng ngày</h1><p>Hoàn thành các thử thách để nhận xu trong game, mở khóa giao diện bàn cờ và giữ chuỗi hoạt động. Tiến độ này được lưu trên thiết bị hiện tại.</p></div><div class="progression-summary-grid"><article class="panel progression-summary-main"><small>VÍ XU TRONG GAME</small><strong>◈ ${summary.coins}</strong><span>Không phải tiền thật và không thể rút ra.</span></article><article class="panel progression-summary-item"><small>CHUỖI NGÀY</small><strong>🔥 ${summary.streak}</strong><span>Ngày hoạt động liên tiếp</span></article><article class="panel progression-summary-item"><small>NHIỆM VỤ XONG</small><strong>${summary.completed}/${summary.total}</strong><span>${summary.claimed} phần thưởng đã nhận</span></article></div><div class="mission-cards-grid">${cards}</div><section class="panel progression-next-step"><div><span class="eyebrow">PHẦN THƯỞNG TRANG TRÍ</span><h2>Đổi xu lấy bàn cờ mới</h2><p>Các vật phẩm chỉ thay đổi màu bàn cờ, không tạo lợi thế khi thi đấu.</p></div><button class="primary-btn" type="button" data-open-shop>Mở cửa hàng ↗</button></section></section>`;
}
function renderShopView() {
  const state = readDailyProgress();
  const cards = COSMETICS.map(item => {
    const owned = state.ownedCosmetics.includes(item.id);
    const active = state.activeCosmetic === item.id;
    const preview = `<div class="cosmetic-board-preview" aria-label="Xem trước bàn cờ" style="--preview-light:${item.colors[0]};--preview-dark:${item.colors[1]}">${Array.from({length:16}, (_, i) => `<span class="${((Math.floor(i/4)+i%4)%2) ? 'dark' : 'light'}">${i===2 ? '♞' : ''}</span>`).join('')}</div>`;
    const action = active ? '<button type="button" class="secondary-btn" disabled>Đang sử dụng</button>' : owned ? `<button type="button" class="primary-btn" data-equip-cosmetic="${item.id}">Sử dụng</button>` : `<button type="button" class="secondary-btn" data-buy-cosmetic="${item.id}" ${state.coins < item.cost ? 'disabled' : ''}>Mua · ◈ ${item.cost}</button>`;
    return `<article class="cosmetic-card panel">${preview}<div class="cosmetic-card-copy"><div class="cosmetic-title-row"><h2>${item.icon} ${esc(item.name)}</h2>${owned ? '<span class="cosmetic-owned">Đã mở khóa</span>' : ''}</div><p>${esc(item.description)}</p><div class="cosmetic-card-bottom"><span>${item.cost === 0 ? 'Miễn phí' : `◈ ${item.cost} xu`}</span>${action}</div></div></article>`;
  }).join('');
  return `<section class="content-page progression-page"><div class="page-intro"><div class="eyebrow">CÁ NHÂN HÓA TRẢI NGHIỆM</div><h1>Cửa hàng giao diện</h1><p>Dùng xu nhận từ nhiệm vụ để mở khóa bàn cờ. Những vật phẩm này chỉ mang tính trang trí, không bán lợi thế chơi cờ.</p></div><div class="shop-wallet panel"><div><small>VÍ XU CỦA BẠN</small><strong>◈ ${state.coins}</strong></div><button type="button" class="secondary-btn" data-open-missions>Kiếm xu từ nhiệm vụ</button></div><div class="cosmetic-shop-grid">${cards}</div><section class="panel shop-future-note"><span class="eyebrow">LỘ TRÌNH KIẾM TIỀN THẬT</span><h2>Cửa hàng này hiện chưa thu tiền</h2><p>Muốn có doanh thu thật cần thiết lập quảng cáo nhận thưởng hoặc thanh toán Google Play, chính sách quyền riêng tư, xác minh nhà phát triển và thử nghiệm trên bản Android đã ký. Không nhập thông tin thanh toán người dùng trước khi phần tích hợp và kiểm thử đó hoàn tất.</p></section></section>`;
}
function wireMissionsActions() {
  $$('[data-claim-mission]').forEach(button => button.addEventListener('click', () => {
    const result = claimMissionReward(readDailyProgress(), button.dataset.claimMission, new Date());
    if (!result.ok) { toast(result.reason === 'already_claimed' ? 'Bạn đã nhận phần thưởng này hôm nay.' : 'Hoàn thành nhiệm vụ trước khi nhận thưởng.'); return; }
    persistDailyProgress(result.state);
    toast(`Đã nhận ${result.reward} xu trong game!`);
    renderView();
  }));
  $('[data-open-shop]')?.addEventListener('click', () => setView('shop'));
}
function wireShopActions() {
  $$('[data-buy-cosmetic]').forEach(button => button.addEventListener('click', () => {
    const result = purchaseCosmetic(readDailyProgress(), button.dataset.buyCosmetic, new Date());
    if (!result.ok) { toast(result.reason === 'not_enough_coins' ? 'Chưa đủ xu. Hoàn thành nhiệm vụ để kiếm thêm.' : 'Không thể mở khóa vật phẩm này.'); return; }
    persistDailyProgress(result.state);
    toast('Đã mở khóa giao diện bàn cờ!');
    renderView();
  }));
  $$('[data-equip-cosmetic]').forEach(button => button.addEventListener('click', () => {
    const result = equipCosmetic(readDailyProgress(), button.dataset.equipCosmetic, new Date());
    if (!result.ok) { toast('Bạn cần mở khóa vật phẩm trước.'); return; }
    persistDailyProgress(result.state);
    toast('Đã đổi giao diện bàn cờ.');
    renderView();
  }));
  $('[data-open-missions]')?.addEventListener('click', () => setView('missions'));
}

function renderAdminView() {
  if (socialState.user?.role !== 'admin') return `<section class="content-page"><div class="page-intro"><div class="eyebrow">BẢO MẬT NỀN TẢNG</div><h1>Trung tâm quản trị</h1><p>Khu vực này chỉ dành cho tài khoản admin đã được cấp quyền ở phía máy chủ.</p></div><section class="panel"><div class="empty-state">Bạn chưa đăng nhập bằng tài khoản quản trị. Hãy vào mục Bạn bè để đăng nhập. Admin được tạo qua ADMIN_USERNAME và ADMIN_PASSWORD trong cấu hình bí mật của máy chủ — không có mật khẩu mặc định trong APK.</div><button type="button" class="primary-btn" data-home-view="friends">Mở đăng nhập</button></section></section>`;
  return `<section class="content-page admin-page"><div class="page-intro"><div class="eyebrow">ADMIN CONTROL PLANE</div><h1>Quản trị nền tảng</h1><p>Giám sát tiến trình server, tài khoản và sự kiện bảo mật. Các thao tác khóa tài khoản được kiểm tra quyền ở API server.</p></div><div class="admin-metrics-grid" id="adminMetrics"><div class="panel"><span class="admin-metric-label">Đang tải</span><strong>—</strong></div></div><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Người dùng</h2></div><button class="secondary-btn" id="refreshAdmin" type="button">↻ Làm mới</button></div><form id="adminSearchForm" class="social-search-row"><input class="field" id="adminSearchName" placeholder="Tìm username, tên hiển thị hoặc email" maxlength="80"/><button class="secondary-btn" type="submit">Tìm</button></form><div class="admin-user-list" id="adminUsersList"><div class="empty-state">Đang tải người dùng…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">AUDIT LOG</small><h2>Nhật ký bảo mật</h2></div><span class="context-icon">⌁</span></div><div class="admin-audit-list" id="adminAuditList"><div class="empty-state">Đang tải nhật ký…</div></div></section><p class="field-hint">Bảng quản trị không thay thế các lớp phòng thủ của nhà cung cấp hosting. Cần HTTPS, sao lưu, cập nhật hệ điều hành, giám sát và chống DDoS ở tầng hạ tầng khi server được đưa lên Internet.</p></section>`;
}
async function loadAdminDashboard(query = '') {
  if (socialState.user?.role !== 'admin' || currentView !== 'admin') return;
  const metrics = $('#adminMetrics'), usersNode = $('#adminUsersList'), auditNode = $('#adminAuditList');
  try {
    const [overview, users, auditData] = await Promise.all([socialApi('/admin/overview'), socialApi(`/admin/users?q=${encodeURIComponent(query)}`), socialApi('/admin/audit?limit=40')]);
    socialState.adminOverview = overview; socialState.adminUsers = users.users || []; socialState.auditEvents = auditData.events || [];
    if (metrics) metrics.innerHTML = `<article class="panel"><span class="admin-metric-label">Tổng tài khoản</span><strong>${Number(overview.users)}</strong><small>${Number(overview.activeUsers)} hoạt động gần đây</small></article><article class="panel"><span class="admin-metric-label">Tài khoản bị khóa</span><strong>${Number(overview.bannedUsers)}</strong><small>${Number(overview.admins)} admin đang hoạt động</small></article><article class="panel"><span class="admin-metric-label">Server uptime</span><strong>${Math.floor(Number(overview.uptimeSeconds || 0) / 3600)}h ${Math.floor((Number(overview.uptimeSeconds || 0) % 3600) / 60)}m</strong><small>Node ${esc(overview.node)} · ${esc(overview.platform)}/${esc(overview.arch)}</small></article><article class="panel"><span class="admin-metric-label">Bộ nhớ tiến trình</span><strong>${Number(overview.memory?.rssMb || 0)} MB</strong><small>Heap ${Number(overview.memory?.heapUsedMb || 0)}/${Number(overview.memory?.heapTotalMb || 0)} MB · ${Number(overview.cpus || 0)} CPU</small></article><article class="panel"><span class="admin-metric-label">Bộ nhớ hệ thống trống</span><strong>${Number(overview.memory?.systemFreeMb || 0)} MB</strong><small>Tổng ${Number(overview.memory?.systemTotalMb || 0)} MB</small></article><article class="panel"><span class="admin-metric-label">Tải CPU (1/5/15 phút)</span><strong>${(overview.loadAverage || [0,0,0]).map(n => Number(n).toFixed(2)).join(' / ')}</strong><small>Chỉ số load average của máy chủ</small></article><article class="panel"><span class="admin-metric-label">Lời mời kết bạn</span><strong>${Number(overview.pendingFriendRequests)}</strong><small>${Number(overview.db?.auditEvents || 0)} sự kiện nhật ký</small></article>`;
    if (usersNode) usersNode.innerHTML = socialState.adminUsers.length ? socialState.adminUsers.map(u => `<article class="admin-user-row"><span class="social-person-avatar">${esc((u.displayName || u.username).slice(0,1).toUpperCase())}</span><span class="social-person-meta"><b>${esc(u.displayName)} <small>@${esc(u.username)}</small></b><small>${esc(u.email || 'Chưa thêm email')} · ${u.banned ? '🔒 Đã khóa' : '🟢 Hoạt động'} · ${Number(u.elo || 1200)} Elo · ${esc(new Date(u.createdAt).toLocaleDateString())}</small></span>${u.role === 'admin' ? '<span class="admin-role-tag">ADMIN</span>' : `<button class="${u.banned ? 'secondary-btn' : 'danger-btn'} admin-ban-button" type="button" data-admin-action="${u.banned ? 'unban' : 'ban'}" data-admin-user="${esc(u.id)}">${u.banned ? 'Mở khóa' : 'Khóa'}</button>`}</article>`).join('') : '<div class="empty-state">Không có người dùng phù hợp.</div>';
    if (auditNode) auditNode.innerHTML = socialState.auditEvents.length ? socialState.auditEvents.map(item => `<article class="admin-audit-row"><span class="admin-audit-dot"></span><div><b>${esc(item.action)}</b><small>${esc(item.detail || '')}</small><span>${esc(new Date(item.at).toLocaleString())} · actor ${esc(String(item.actor || '').slice(0,12))} · target ${esc(String(item.target || '').slice(0,12))}</span></div></article>`).join('') : '<div class="empty-state">Chưa có sự kiện bảo mật.</div>';
    $$('[data-admin-action]').forEach(button => button.addEventListener('click', async () => { const action = button.dataset.adminAction; const id = button.dataset.adminUser; const reason = action === 'ban' ? (prompt('Lý do khóa tài khoản (hiển thị cho quản trị viên):', 'Vi phạm quy định cộng đồng') || '') : ''; if (action === 'ban' && !reason.trim()) return; button.disabled = true; try { await socialApi(`/admin/users/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ action, reason }) }); toast(action === 'ban' ? 'Đã khóa tài khoản.' : 'Đã mở khóa tài khoản.'); await loadAdminDashboard($('#adminSearchName')?.value || ''); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } }));
  } catch (error) { if (metrics) metrics.innerHTML = `<div class="empty-state">${esc(error.message)}. Kiểm tra trạng thái server và phiên admin.</div>`; socialHandleError(error); }
}
function wireAdminActions() {
  $('#refreshAdmin')?.addEventListener('click', () => loadAdminDashboard($('#adminSearchName')?.value || ''));
  $('#adminSearchForm')?.addEventListener('submit', event => { event.preventDefault(); loadAdminDashboard($('#adminSearchName')?.value || ''); });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  loadAdminDashboard();
}

function renderHomeMiniBoard() {
  const rows = [
    ['♜','♞','♝','♛','♚','♝','♞','♜'],
    ['♟','♟','♟','♟','♟','♟','♟','♟'],
    ['','','','','','','',''], ['','','','','','','',''],
    ['','','','','','','',''], ['','','','','','','',''],
    ['♙','♙','♙','♙','♙','♙','♙','♙'],
    ['♖','♘','♗','♕','♔','♗','♘','♖'],
  ];
  return `<div class="home-mini-board" aria-hidden="true">${rows.map((row, r) => row.map((piece, c) => `<span class="home-mini-square ${((r + c) % 2) ? 'is-dark' : 'is-light'} ${r < 2 ? 'is-black' : 'is-white'}">${piece}</span>`).join('')).join('')}</div>`;
}

function renderHomeView() {
  const profile = readRatingProfile();
  const gamesPlayed = Math.max(0, Number(profile.games || 0));
  const winRate = gamesPlayed ? Math.round(Number(profile.wins || 0) / gamesPlayed * 100) : 0;
  const puzzleSolved = Math.max(0, Number(puzzleState?.solvedCount || 0));
  const puzzleBest = Math.max(0, Number(puzzleState?.bestStreak || 0));
  const isOnline = typeof navigator !== 'undefined' && navigator.onLine;
  return `<section class="home-hub content-page" aria-label="Trang chủ Cờ Vua VILA">
    <header class="home-welcome">
      <div class="home-welcome-copy">
        <span class="home-greeting-eyebrow">CHÀO MỪNG TRỞ LẠI · VILA CHESS CLUB</span>
        <h1>Mỗi ngày tiến bộ<br><em>một nước cờ.</em></h1>
        <p>Chơi, luyện chiến thuật và khám phá các biến khai cuộc trong một không gian gọn gàng — chơi cục bộ ngay cả khi mất mạng.</p>
        <span class="home-connection"><i class="${isOnline ? 'is-online' : ''}"></i>${isOnline ? 'Đã kết nối mạng' : 'Chế độ ngoại tuyến sẵn sàng'} <span>·</span> Stockfish cục bộ</span>
      </div>
      <div class="home-profile-card"><div class="home-avatar-3d home-avatar-image"><img src="./covua-vila-brand-icon.png?v=350" alt="Biểu tượng Cờ Vua ViLa" width="76" height="76" loading="eager" decoding="async"></div><small>ĐIỂM CÁ NHÂN</small><b>${Number(profile.elo || 1200)}</b><span>Hồ sơ trên thiết bị</span><button type="button" class="home-profile-link" data-home-view="leaderboard">Xem hồ sơ <span>↗</span></button></div>
    </header>

    <nav class="home-quick-modes" aria-label="Lối tắt chế độ chính">
      <button type="button" class="home-quick-mode is-selected" data-home-action="quickplay"><span>⚔</span><b>Chơi cờ</b></button>
      <button type="button" class="home-quick-mode" data-home-view="arena"><span>🤖</span><b>Đấu bot</b></button>
      <button type="button" class="home-quick-mode" data-home-view="coach"><span>📊</span><b>Phân tích</b></button>
      <button type="button" class="home-quick-mode" data-home-view="history"><span>↶</span><b>Lịch sử</b></button>
      <button type="button" class="home-quick-mode" data-home-view="settings"><span>⚙</span><b>Cài đặt</b></button>
    </nav>

    <section class="home-feature-grid" aria-label="Bắt đầu chơi">
      <article class="home-play-feature">
        <div class="home-play-copy"><span class="home-kicker"><i></i> GỢI Ý CHO BẠN</span><h2>Sẵn sàng cho<br>một ván mới?</h2><p>Thách đấu Stockfish, chọn thời gian và bước vào bàn cờ khi bạn đã sẵn sàng.</p><button type="button" class="home-cta-primary" data-home-action="quickplay"><span>▶</span> Chơi ngay <b>→</b></button><button type="button" class="home-cta-secondary" data-home-view="play">Tùy chỉnh ván đấu</button></div>
        <div class="home-play-art">${renderHomeMiniBoard()}<span class="home-piece-float home-float-queen">♛</span><span class="home-piece-float home-float-knight">♘</span></div>
      </article>
      <button type="button" class="home-daily-feature" data-home-view="puzzles"><span class="home-daily-icon">✦</span><span class="home-kicker">THỬ THÁCH HÔM NAY</span><b>Giải một thế cờ</b><small>Từ dễ đến khó, liên tục luyện tập</small><span class="home-daily-progress"><span style="width:${Math.min(100, puzzleSolved * 10)}%"></span></span><span class="home-daily-foot"><span>${puzzleSolved} câu đã giải</span><strong>Vào luyện tập ↗</strong></span></button>
    </section>

    <div class="home-section-heading"><div><span class="home-kicker">CHỌN CHẾ ĐỘ</span><h2>Chơi theo cách của bạn</h2></div><span class="home-heading-note">9 chế độ</span></div>
    <section class="home-mode-grid" aria-label="Các chế độ cờ vua">
      <button type="button" class="home-mode-card mode-play" data-home-action="quickplay"><span class="home-mode-icon icon-crossed">⚔</span><span class="home-mode-text"><b>Chơi cờ</b><small>Vào ván mới với Stockfish</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-bot" data-home-view="arena"><span class="home-mode-icon icon-bot">🤖</span><span class="home-mode-text"><b>Đấu bot</b><small>AI đa phong cách</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-analysis" data-home-view="coach"><span class="home-mode-icon icon-analysis">📊</span><span class="home-mode-text"><b>Phân tích ván</b><small>Xem lại từng nước & thế cờ</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-history" data-home-view="history"><span class="home-mode-icon icon-history">↶</span><span class="home-mode-text"><b>Lịch sử ván</b><small>Xem lại từng nước & đồng bộ</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-settings" data-home-view="settings"><span class="home-mode-icon icon-settings">⚙</span><span class="home-mode-text"><b>Cài đặt</b><small>Âm thanh, nhạc, độ khó & Firebase</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-puzzle" data-home-view="puzzles"><span class="home-mode-icon icon-puzzle">🧩</span><span class="home-mode-text"><b>Câu đố</b><small>Rèn chiến thuật cờ vua</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-lessons" data-home-view="openings"><span class="home-mode-icon icon-lessons">🎓</span><span class="home-mode-text"><b>Bài học & khai cuộc</b><small>${OPENINGS.length.toLocaleString()} biến mẫu ECO</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-ranked" data-home-view="ranked"><span class="home-mode-icon icon-online">🏆</span><span class="home-mode-text"><b>Ghép trận người thật</b><small>Elo Bullet, Blitz, Rapid</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-online" data-home-view="lichess"><span class="home-mode-icon icon-online">◎</span><span class="home-mode-text"><b>Chơi qua Lichess</b><small>Kết nối tài khoản Lichess</small></span><span class="home-mode-arrow">↗</span></button>
    </section>

    <section class="home-arena-promo">
      <div class="home-arena-copy"><span class="home-kicker">VILA AI ARENA</span><h2>Hai bot. Một bàn cờ.</h2><p>Chọn phong cách và cấp tìm kiếm, xem cả trận đấu và mở phân tích sau khi kết thúc.</p><button type="button" class="home-cta-secondary" data-home-view="arena">Khám phá đấu trường <b>→</b></button></div>
      <div class="home-bot-duel" aria-hidden="true"><span class="home-bot-avatar stockfish-avatar">♜</span><span class="home-versus">VS</span><span class="home-bot-avatar vila-avatar">♞</span><div class="home-bot-labels"><span>STOCKFISH</span><span>VILA BOT</span></div></div>
    </section>

    <div class="home-section-heading"><div><span class="home-kicker">LUYỆN TẬP HẰNG NGÀY</span><h2>Thêm một chút thử thách</h2></div><button type="button" class="home-text-link" data-home-view="openings">Xem tất cả ↗</button></div>
    <section class="home-training-grid">
      <button type="button" class="home-training-card training-openings" data-home-view="openings"><span class="training-art">♕</span><span><b>Khám phá khai cuộc</b><small>Tìm tên, ECO và các nước đi</small></span><strong>→</strong></button>
      <button type="button" class="home-training-card training-analysis" data-home-view="coach"><span class="training-art">⌁</span><span><b>Xem lại ván cờ</b><small>Đánh giá nước hay, sai lầm, bỏ lỡ</small></span><strong>→</strong></button>
      <button type="button" class="home-training-card training-games" data-home-view="games"><span class="training-art">▦</span><span><b>Góc giải trí</b><small>Rubik 3D, 2048, trượt số và lật thẻ</small></span><strong>→</strong></button>
    </section>

    <section class="home-progress-panel"><div class="home-progress-heading"><div><span class="home-kicker">TIẾN BỘ CỦA BẠN</span><h2>Thành tích trên thiết bị</h2></div><span class="home-progress-icon">♛</span></div><div class="home-progress-stats"><div><small>ELO CỤC BỘ</small><b>${Number(profile.elo || 1200)}</b></div><div><small>VÁN ĐẤU</small><b>${gamesPlayed}</b></div><div><small>TỈ LỆ THẮNG</small><b>${winRate}%</b></div><div><small>CHUỖI CÂU ĐỐ</small><b>${puzzleBest}</b></div></div><p class="home-footnote">Điểm Elo và lịch sử cờ cục bộ được lưu trên máy. Ghép trận xếp hạng trực tuyến cần server cộng đồng được cấu hình; không có máy chủ thì vẫn chơi offline bình thường.</p></section>
    <section class="vila-flower-stage" aria-label="Hoa tỏa sắc màu hoạt họa">
      <div class="vila-flower-visual" aria-hidden="true"><span class="petal p1"></span><span class="petal p2"></span><span class="petal p3"></span><span class="petal p4"></span><span class="petal p5"></span><span class="petal p6"></span><span class="flower-core"></span></div>
      <div class="vila-flower-copy"><span class="home-kicker">VILA COLOR GARDEN</span><h2>Hoa nở — sắc màu chuyển động</h2><p>Hoạt họa nhẹ, không tải video nặng; tối ưu cho WebView và tôn trọng cài đặt giảm chuyển động.</p></div>
    </section>
    <div class="home-ambient-actions"><button id="homeToggleChessMusic" type="button" class="dashboard-music-btn" aria-pressed="false">🎧 Bật nhạc cờ vua</button><button id="musicYoutubeSearch" type="button" class="dashboard-music-btn">⌕ Tìm nhạc cờ vua trên YouTube</button></div>
  </section>`;
}
const RUBIK_FACES = [
  { id: 'U', label: 'Trên', transform: 'rotateX(90deg) translateZ(var(--cube-half))' },
  { id: 'D', label: 'Dưới', transform: 'rotateX(-90deg) translateZ(var(--cube-half))' },
  { id: 'F', label: 'Trước', transform: 'translateZ(var(--cube-half))' },
  { id: 'B', label: 'Sau', transform: 'rotateY(180deg) translateZ(var(--cube-half))' },
  { id: 'R', label: 'Phải', transform: 'rotateY(90deg) translateZ(var(--cube-half))' },
  { id: 'L', label: 'Trái', transform: 'rotateY(-90deg) translateZ(var(--cube-half))' },
];
function renderRubikFaceMarkup(face) {
  const colors = getRubikFaceStickers(rubikCube, face);
  return `<div class="rubik-face rubik-face-${face}" data-rubik-face="${face}" style="transform:${RUBIK_FACES.find(item => item.id === face)?.transform || ''}" aria-label="Mặt ${RUBIK_FACES.find(item => item.id === face)?.label || face}">${colors.map((color, index) => `<span class="rubik-sticker rubik-color-${color}" data-sticker-index="${index}"></span>`).join('')}</div>`;
}
function renderRubikGame() {
  const solved = isRubikSolved(rubikCube);
  return `<section class="games-layout rubik-game-layout">
    <article class="panel rubik-play-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Rubik 3×3</h2><p>Xoay mặt bằng cách vuốt trên khối, hoặc chọn ký hiệu bên dưới. Chế độ “Xoay góc nhìn” để xoay cả khối.</p></div><span class="game-emblem rubik-emblem">▦</span></div>
      <div class="rubik-stage ${rubikViewMode === 'view' ? 'rubik-view-mode' : 'rubik-turn-mode'}" id="rubikStage" role="application" aria-label="Khối Rubik tương tác" style="--cube-size:min(54vw, 230px);--cube-half:calc(var(--cube-size) / 2)"><div class="rubik-cube" id="rubikCube" style="transform:rotateX(${rubikRotationX}deg) rotateY(${rubikRotationY}deg)">${RUBIK_FACES.map(face => renderRubikFaceMarkup(face.id)).join('')}</div><span class="rubik-stage-hint">${rubikViewMode === 'view' ? 'Vuốt để xoay góc nhìn' : 'Vuốt lên/xuống hoặc trái/phải để xoay mặt'}</span></div>
      <div class="rubik-status-row"><span class="rubik-status-dot ${solved ? 'is-solved' : ''}"></span><b>${solved ? 'Đã giải hoàn chỉnh' : 'Đang xáo trộn'}</b><span>${rubikMoveCount} lượt xoay</span></div>
      <div class="rubik-main-actions"><button type="button" class="primary-btn" id="rubikScramble">⤨ Xáo trộn tự động</button><button type="button" class="secondary-btn" id="rubikViewToggle">${rubikViewMode === 'view' ? '↻ Đang xoay góc nhìn' : '◉ Xoay góc nhìn'}</button><button type="button" class="secondary-btn" id="rubikUndo" ${rubikMoveHistory.length ? '' : 'disabled'}>↶ Hoàn tác</button><button type="button" class="secondary-btn" id="rubikReset">↺ Làm mới</button></div>
      <div class="rubik-turn-pad"><div class="rubik-turn-heading"><b>Xoay từng mặt</b><small>Ký hiệu quốc tế · chạm hoặc vuốt</small></div><div class="rubik-turn-grid">${['U','U\'','D','D\'','L','L\'','R','R\'','F','F\'','B','B\''].map(move => `<button type="button" class="rubik-turn-btn" data-rubik-move="${move}" aria-label="Xoay mặt ${move}">${move}</button>`).join('')}</div></div>
      <div class="rubik-history"><span>Chuỗi hiện tại</span><code>${rubikMoveHistory.length ? esc(rubikMoveHistory.slice(-16).join(' ')) : 'Chưa có nước xoay'}</code></div>
    </article>
    <aside class="games-side-column"><section class="panel games-help-card"><span class="game-emblem">✦</span><h3>Cách chơi</h3><p>Chạm <b>Xáo trộn tự động</b> để tạo một bài mới. Trong chế độ xoay mặt, vuốt trực tiếp trên một mặt hoặc dùng nút U/D/L/R/F/B. Dấu nháy (') là xoay ngược chiều.</p><p>Khối và quy tắc xoay chạy ngay trên máy, không cần tài khoản hay kết nối mạng.</p></section><section class="panel games-help-card"><span class="game-emblem">🏁</span><h3>Mục tiêu</h3><p>Đưa 9 ô của mỗi mặt về cùng màu. Khi cả 6 mặt đồng màu, VILA xác nhận đã giải xong.</p><button type="button" class="secondary-btn full-width" data-games-mode="2048">Thử 2048 →</button><button type="button" class="secondary-btn full-width" data-games-mode="memory">Thử ghi nhớ →</button></section></aside>
  </section>`;
}

function render2048Game() {
  try { game2048Best = Math.max(game2048Best, Number(localStorage.getItem('vila.mini2048.best') || 0)); } catch {}
  const over = !has2048Moves(game2048Board);
  return `<section class="games-layout simple-game-layout"><article class="panel game2048-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>2048</h2><p>Vuốt hoặc dùng phím mũi tên để gộp các ô số giống nhau.</p></div><span class="game-emblem game2048-emblem">2048</span></div><div class="score-row"><div><small>ĐIỂM</small><b>${game2048Score}</b></div><div><small>KỶ LỤC TRÊN MÁY</small><b>${game2048Best}</b></div><button type="button" id="game2048Restart" class="secondary-btn">Ván mới ↺</button></div><div id="game2048Grid" class="game2048-grid" role="grid" aria-label="Bàn 2048">${game2048Board.map((value, index) => `<div class="game2048-tile tile-${value || 0}" role="gridcell" aria-label="${value || 'trống'}">${value || ''}</div>`).join('')}${over ? '<div class="game2048-overlay"><b>Hết nước đi</b><button type="button" id="game2048RestartOverlay" class="primary-btn">Thử lại</button></div>' : ''}</div><div class="game2048-controls"><button type="button" data-2048-dir="up">↑</button><div><button type="button" data-2048-dir="left">←</button><button type="button" data-2048-dir="down">↓</button><button type="button" data-2048-dir="right">→</button></div></div></article><aside class="panel games-help-card"><span class="game-emblem">✦</span><h3>Luật chơi</h3><p>Gộp hai ô cùng số để tạo ô có giá trị gấp đôi. Mỗi lượt có thay đổi sẽ thêm một ô mới. Đạt 2048 để thắng; có thể tiếp tục chơi sau đó.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">← Quay lại Rubik</button><button class="secondary-btn full-width" type="button" data-games-mode="memory">Lật thẻ ghi nhớ →</button></aside></section>`;
}
function ensureMemoryDeck() {
  if (memoryDeck.length) return;
  const symbols = ['♞','♝','♜','♛','♚','♟','★','◆'];
  memoryDeck = [...symbols, ...symbols].map((symbol, index) => ({ id: `${symbol}-${index}`, symbol, pair: symbol }));
  for (let i = memoryDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [memoryDeck[i], memoryDeck[j]] = [memoryDeck[j], memoryDeck[i]];
  }
}
function renderMemoryGame() {
  ensureMemoryDeck();
  const won = memoryMatched.size === memoryDeck.length;
  return `<section class="games-layout simple-game-layout"><article class="panel memory-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Lật thẻ ghi nhớ</h2><p>Tìm các cặp giống nhau với ít lượt lật nhất.</p></div><span class="game-emblem">◆</span></div><div class="score-row"><div><small>LƯỢT LẬT</small><b>${memoryMoves}</b></div><div><small>ĐÃ TÌM</small><b>${memoryMatched.size / 2}/8 cặp</b></div><button type="button" class="secondary-btn" id="memoryRestart">Ván mới ↺</button></div><div class="memory-grid" aria-label="Bộ thẻ ghi nhớ">${memoryDeck.map(card => { const revealed = memorySelected.includes(card.id) || memoryMatched.has(card.id); return `<button type="button" class="memory-card ${revealed ? 'is-revealed' : ''} ${memoryMatched.has(card.id) ? 'is-matched' : ''}" data-memory-card="${card.id}" aria-label="${revealed ? `Thẻ ${card.symbol}` : 'Thẻ úp'}" ${revealed || memoryLock ? 'disabled' : ''}>${revealed ? card.symbol : '✦'}</button>`; }).join('')}</div>${won ? '<div class="game-win-message">Tuyệt vời! Bạn đã tìm đủ 8 cặp.</div>' : ''}</article><aside class="panel games-help-card"><span class="game-emblem">✦</span><h3>Rèn trí nhớ</h3><p>Lật hai thẻ mỗi lượt. Nếu giống nhau, cặp đó sẽ được giữ mở; nếu khác nhau, thẻ sẽ úp lại sau một nhịp ngắn.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">← Rubik 3×3</button><button class="secondary-btn full-width" type="button" data-games-mode="2048">Chơi 2048 →</button></aside></section>`;
}
function renderSlidingPuzzleGame() {
  const solved = isSlidingPuzzleSolved(slidingPuzzleBoard);
  return `<section class="games-layout simple-game-layout"><article class="panel sliding-puzzle-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Trượt số 15</h2><p>Chạm ô nằm cạnh khoảng trống để di chuyển. Bảng được xáo trộn bằng nước hợp lệ nên luôn giải được.</p></div><span class="game-emblem">▦</span></div><div class="score-row"><div><small>SỐ NƯỚC</small><b>${slidingPuzzleMoves}</b></div><div><small>TRẠNG THÁI</small><b>${solved ? 'Hoàn thành' : 'Đang chơi'}</b></div><button type="button" class="secondary-btn" id="slidingPuzzleRestart">Xáo trộn ↺</button></div><div class="sliding-puzzle-grid" role="grid" aria-label="Trò trượt số 15">${slidingPuzzleBoard.map((value, index) => value ? `<button type="button" role="gridcell" class="sliding-puzzle-tile" data-sliding-tile="${index}" aria-label="Ô số ${value}">${value}</button>` : `<span role="gridcell" class="sliding-puzzle-empty" aria-label="Ô trống"></span>`).join('')}</div>${solved ? '<div class="game-win-message">Xuất sắc! Bạn đã sắp xếp toàn bộ số.</div>' : ''}</article><aside class="panel games-help-card"><span class="game-emblem">15</span><h3>Trò xếp số</h3><p>Đưa các ô 1 đến 15 về đúng thứ tự, ô trống ở góc dưới bên phải. Mỗi lần chạm chỉ di chuyển một ô hợp lệ.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">Rubik 3×3</button><button class="secondary-btn full-width" type="button" data-games-mode="2048">2048</button></aside></section>`;
}
function renderTicTacToeGame() {
  const outcome = ticTacToeResult || ticTacToeOutcome(ticTacToeBoard);
  const outcomeText = outcome === 'X' ? 'Bạn thắng!' : outcome === 'O' ? 'Bot thắng ván này.' : outcome === 'draw' ? 'Hòa cờ.' : ticTacToeThinking ? 'Bot đang tính nước…' : 'Bạn đi trước bằng dấu X.';
  return `<section class="games-layout simple-game-layout"><article class="panel tictactoe-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Cờ ca-rô 3×3</h2><p>Đấu với bot cục bộ có tìm kiếm minimax; bot không mắc lỗi chiến thuật cơ bản.</p></div><span class="game-emblem">✕○</span></div><div class="tictactoe-score-row"><span class="tictactoe-status" aria-live="polite">${esc(outcomeText)}</span><button type="button" id="ticTacToeRestart" class="secondary-btn">Ván mới ↺</button></div><div class="tictactoe-grid" role="grid" aria-label="Bàn cờ ca-rô 3 nhân 3">${ticTacToeBoard.map((mark, index) => `<button type="button" role="gridcell" class="tictactoe-square ${mark ? `mark-${mark.toLowerCase()}` : ''}" data-ttt-square="${index}" aria-label="Ô ${index + 1}${mark ? `: ${mark}` : ': trống'}" ${mark || outcome || ticTacToeThinking ? 'disabled' : ''}>${mark || ''}</button>`).join('')}</div><p class="tictactoe-note">Lưu ý: bot ca-rô là trò chơi giải trí riêng, không liên quan Elo cờ vua hay Stockfish.</p></article><aside class="panel games-help-card"><span class="game-emblem">♟</span><h3>Đấu trí nhanh</h3><p>Đặt ba dấu liền hàng, cột hoặc chéo để thắng. Bot sử dụng tìm kiếm toàn bộ trạng thái 3×3 nên chơi tối ưu.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">Rubik 3×3</button><button class="secondary-btn full-width" type="button" data-games-mode="2048">Chơi 2048</button></aside></section>`;
}
function handleTicTacToeMove(index) {
  if (!Number.isInteger(index) || index < 0 || index > 8 || ticTacToeBoard[index] || ticTacToeResult || ticTacToeThinking) return;
  ticTacToeBoard[index] = 'X';
  recordDailyEvent('play_mini_game');
  ticTacToeResult = ticTacToeOutcome(ticTacToeBoard) || '';
  if (ticTacToeResult) { renderView(); return; }
  ticTacToeThinking = true;
  renderView();
  setTimeout(() => {
    if (currentView !== 'games' || gamesMode !== 'tictactoe') { ticTacToeThinking = false; return; }
    const move = chooseTicTacToeMove(ticTacToeBoard);
    if (move >= 0 && !ticTacToeBoard[move]) ticTacToeBoard[move] = 'O';
    ticTacToeResult = ticTacToeOutcome(ticTacToeBoard) || '';
    ticTacToeThinking = false;
    if (ticTacToeResult) recordDailyEvent('play_mini_game');
    renderView();
  }, 120);
}
function resetTicTacToe() { ticTacToeBoard = Array(9).fill(''); ticTacToeResult = ''; ticTacToeThinking = false; renderView(); }

function renderGamesView() {
  const modes = [{ id: 'rubik', icon: '▦', label: 'Rubik 3×3' }, { id: '2048', icon: '2048', label: '2048' }, { id: 'memory', icon: '◆', label: 'Ghi nhớ' }, { id: 'sliding', icon: '15', label: 'Trượt số' }, { id: 'tictactoe', icon: '✕○', label: 'Cờ ca-rô' }];
  const body = gamesMode === '2048' ? render2048Game() : gamesMode === 'memory' ? renderMemoryGame() : gamesMode === 'sliding' ? renderSlidingPuzzleGame() : gamesMode === 'tictactoe' ? renderTicTacToeGame() : renderRubikGame();
  return `<section class="content-page vila-games-page"><div class="games-page-heading"><div><span class="eyebrow">KHU GIẢI TRÍ · CHƠI NGOẠI TUYẾN</span><h1>Mini-game</h1><p>Trò chơi gọn nhẹ, tối ưu chạm trên Android.</p></div><span class="games-status-pill"><i></i> Chạy cục bộ</span></div><nav class="games-mode-tabs" aria-label="Chọn mini-game">${modes.map(item => `<button type="button" class="games-mode-tab ${gamesMode === item.id ? 'active' : ''}" data-games-mode="${item.id}"><span>${item.icon}</span>${item.label}</button>`).join('')}</nav>${body}</section>`;
}
function applyGamesMove2048(direction) {
  const result = move2048(game2048Board, direction);
  if (!result.changed) return;
  recordDailyEvent('play_mini_game');
  game2048Board = result.board;
  game2048Score += result.score;
  if (result.won) toast('Đạt ô 2048! Bạn có thể tiếp tục chơi.', 'success');
  game2048Best = Math.max(game2048Best, game2048Score);
  try { localStorage.setItem('vila.mini2048.best', String(game2048Best)); } catch {}
  if (currentView === 'games' && gamesMode === '2048') renderView();
}
function reset2048Game() { game2048Board = create2048Board(); game2048Score = 0; if (currentView === 'games') renderView(); }
function makeRubikMove(move) {
  try {
    recordDailyEvent('play_mini_game');
    rubikCube = applyRubikMove(rubikCube, move);
    rubikMoveHistory.push(move); rubikMoveCount++;
    if (isRubikSolved(rubikCube)) toast('Rubik đã giải hoàn chỉnh!', 'success');
    if (currentView === 'games' && gamesMode === 'rubik') renderView();
  } catch (error) { console.warn('[VILA] Rubik move rejected:', error); }
}
function wireGamesActions() {
  if (gamesKeyHandler) window.removeEventListener('keydown', gamesKeyHandler);
  $$('[data-games-mode]').forEach(button => button.addEventListener('click', () => { gamesMode = button.dataset.gamesMode; renderView(); }));
  $$('[data-rubik-move]').forEach(button => button.addEventListener('click', () => makeRubikMove(button.dataset.rubikMove)));
  $('#rubikScramble')?.addEventListener('click', () => {
    recordDailyEvent('play_mini_game');
    const moves = scrambleRubikMoves(25);
    for (const move of moves) rubikCube = applyRubikMove(rubikCube, move);
    rubikMoveHistory.push(...moves); rubikMoveCount += moves.length;
    renderView(); toast('Đã xáo trộn Rubik 25 lượt.', 'success');
  });
  $('#rubikReset')?.addEventListener('click', () => { rubikCube = createSolvedRubikCube(); rubikMoveHistory = []; rubikMoveCount = 0; renderView(); });
  $('#rubikUndo')?.addEventListener('click', () => { const move = rubikMoveHistory.pop(); if (move) { rubikCube = applyRubikMove(rubikCube, invertRubikMove(move)); rubikMoveCount = Math.max(0, rubikMoveCount - 1); renderView(); } });
  $('#rubikViewToggle')?.addEventListener('click', () => { rubikViewMode = rubikViewMode === 'view' ? 'turn' : 'view'; renderView(); });
  const stage = $('#rubikStage');
  if (stage) {
    let start = null;
    stage.addEventListener('pointerdown', event => {
      if (event.isPrimary === false) return;
      const face = event.target.closest('[data-rubik-face]')?.dataset.rubikFace || null;
      start = { x: event.clientX, y: event.clientY, face, id: event.pointerId };
      try { stage.setPointerCapture(event.pointerId); } catch {}
    });
    stage.addEventListener('pointerup', event => {
      if (!start || start.id !== event.pointerId) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      const moved = Math.hypot(dx, dy) > 20;
      if (moved && rubikViewMode === 'view') {
        rubikRotationY += dx * .75; rubikRotationX = Math.max(-72, Math.min(72, rubikRotationX - dy * .65));
        const cube = $('#rubikCube'); if (cube) cube.style.transform = `rotateX(${rubikRotationX}deg) rotateY(${rubikRotationY}deg)`;
      } else if (moved && start.face && rubikViewMode === 'turn') {
        const reverse = Math.abs(dx) >= Math.abs(dy) ? dx < 0 : dy < 0;
        makeRubikMove(`${start.face}${reverse ? "'" : ''}`);
      }
      start = null;
    });
    stage.addEventListener('pointercancel', () => { start = null; });
  }
  $('#game2048Restart')?.addEventListener('click', reset2048Game);
  $('#game2048RestartOverlay')?.addEventListener('click', reset2048Game);
  $$('[data-2048-dir]').forEach(button => button.addEventListener('click', () => applyGamesMove2048(button.dataset['2048Dir'])));
  const grid2048 = $('#game2048Grid');
  if (grid2048) {
    let start = null;
    grid2048.addEventListener('pointerdown', event => { start = { x: event.clientX, y: event.clientY }; });
    grid2048.addEventListener('pointerup', event => {
      if (!start) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      if (Math.max(Math.abs(dx), Math.abs(dy)) > 28) applyGamesMove2048(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
      start = null;
    });
  }
  gamesKeyHandler = event => {
    if (currentView !== 'games' || gamesMode !== '2048' || event.altKey || event.ctrlKey || event.metaKey) return;
    const map = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
    if (map[event.key]) { event.preventDefault(); applyGamesMove2048(map[event.key]); }
  };
  window.addEventListener('keydown', gamesKeyHandler);
  $$('[data-sliding-tile]').forEach(button => button.addEventListener('click', () => {
    const result = moveSlidingPuzzleTile(slidingPuzzleBoard, Number(button.dataset.slidingTile));
    if (!result.changed) return;
    recordDailyEvent('play_mini_game');
    slidingPuzzleBoard = result.board; slidingPuzzleMoves += 1;
    if (result.solved) toast(`Giải xong Trượt số trong ${slidingPuzzleMoves} nước!`, 'success');
    renderView();
  }));
  $('#slidingPuzzleRestart')?.addEventListener('click', () => { slidingPuzzleBoard = createScrambledSlidingPuzzle(100); slidingPuzzleMoves = 0; renderView(); });
  $('#memoryRestart')?.addEventListener('click', () => { memoryDeck = []; memorySelected = []; memoryMatched = new Set(); memoryMoves = 0; memoryLock = false; renderView(); });
  $$('[data-memory-card]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.memoryCard;
    if (memoryLock || memoryMatched.has(id) || memorySelected.includes(id) || memorySelected.length >= 2) return;
    recordDailyEvent('play_mini_game');
    memorySelected.push(id); renderView();
    if (memorySelected.length === 2) {
      memoryMoves++;
      const first = memoryDeck.find(card => card.id === memorySelected[0]);
      const second = memoryDeck.find(card => card.id === memorySelected[1]);
      if (first?.pair === second?.pair) {
        memoryMatched.add(first.id); memoryMatched.add(second.id); memorySelected = [];
        setTimeout(() => { if (currentView === 'games' && gamesMode === 'memory') renderView(); }, 80);
      } else {
        memoryLock = true;
        setTimeout(() => { memorySelected = []; memoryLock = false; if (currentView === 'games' && gamesMode === 'memory') renderView(); }, 800);
      }
    }
  }));
  $$('[data-ttt-square]').forEach(button => button.addEventListener('click', () => handleTicTacToeMove(Number(button.dataset.tttSquare))));
  $('#ticTacToeRestart')?.addEventListener('click', resetTicTacToe);
}

function wireHomeActions() {
  wireYoutubeMusicControls();
  $('#musicYoutubeSearch')?.addEventListener('click', () => { const query = 'chess soundtrack background music'; const href = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`; window.open(href, '_blank', 'noopener,noreferrer'); });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  $$('[data-home-action="quickplay"]').forEach(button => button.addEventListener('click', () => {
    if (gameStarted) { openMatchSetup(); return; }
    mode = 'stockfish';
    colorChoice = 'random';
    humanColor = 'w';
    orientation = 'w';
    setView('play');
  }));
}

let rankedMatchState = { queued: false, match: null, rating: 1200 };
let rankedChess = new Chess();
let rankedSelected = null;
let rankedTargets = [];
let rankedPollTimer = null;
let rankedClockDisplayTimer = null;
let rankedPollBusy = false;
let rankedLastSignature = '';
let rankedMoveBusy = false;
let puzzleGame = new Chess();
let puzzleState = {
  status: 'idle', rootFen: '', solutionUci: '', selected: null,
  targets: [], attempts: 0, lastMessage: 'Tạo một thế cờ ngẫu nhiên để bắt đầu.',
  showHint: false, lastMove: null, solvedCount: 0, rootPly: 0, streak: 0,
  bestStreak: 0, puzzleStartedAt: 0, lastSolveMs: 0, source: 'offline', mateOnly: false, theme: '', level: '', historyCount: 0,
  solutionLine: [], solutionIndex: 0, sourceUrl: '', sourceRating: null, sourceThemes: [],
  playMode: 'classic', runLives: 3, runSolved: 0, rushRemainingMs: 180000, rushDeadlineAt: 0, rushActive: false, rushBest: 0, dailyDate: '', dailyAlreadySolved: false
};
let puzzleRushTimer = null;
let puzzleGenerationEpoch = 0;
const PUZZLE_DAILY_SOLVED_KEY = 'vila.chess.puzzles.daily-solved-date.v1';
const PUZZLE_RUSH_BEST_KEY = 'vila.chess.puzzles.rush-best.v1';
const PUZZLE_LICHESS_CACHE_KEY = 'vila.chess.puzzles.lichess-daily-cache.v1';
const PUZZLE_LICHESS_TRAINING_CACHE_KEY = 'vila.chess.puzzles.lichess-training-cache.v1';
const PUZZLE_LICHESS_POOL_KEY = 'vila.chess.puzzles.lichess-training-pool.v1';
const PUZZLE_DOWNLOAD_BATCH_SIZE = 20;
try { puzzleState.historyCount = loadPuzzleHistory().length; } catch {}
const puzzleSessionSeen = new Set();
try { for (const fen of loadPuzzleHistory()) puzzleSessionSeen.add(fen); } catch {}
try { puzzleState.solvedCount = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.solved.v1')) || 0); puzzleState.rushBest = Math.max(0, Number(localStorage.getItem(PUZZLE_RUSH_BEST_KEY)) || 0); } catch {}
try {
  puzzleState.streak = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.streak.v1')) || 0);
  puzzleState.bestStreak = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.bestStreak.v1')) || 0);
} catch {}


function rankedRatingOf(user, category = '') {
  const categoryRating = category && Number(user?.ratingsByCategory?.[category]);
  return Math.max(100, Number(categoryRating) || Number(user?.elo) || 1200);
}
function rankedCategoryLabel(category) {
  return ({ bullet: 'Bullet', blitz: 'Blitz', rapid: 'Rapid', daily: 'Cờ ngày', casual: 'Không xếp hạng' })[category] || 'Blitz';
}
function rankedClockText(match, color, now = Date.now()) {
  if (!match?.clockEnabled) return '∞';
  let remaining = Math.max(0, Number(match.clockRemainingMs?.[color]) || 0);
  const activeTurn = String(match.fen || '').split(' ')[1] || 'w';
  if (match.status === 'active' && activeTurn === color) {
    const updatedAt = Number(match.clockUpdatedAt) || now;
    remaining = Math.max(0, remaining - Math.max(0, now - updatedAt));
  }
  return formatClockTime(remaining, true);
}
function updateRankedClockDisplay() {
  if (currentView !== 'ranked') return;
  const match = rankedMatchState?.match;
  if (!match || match.status !== 'active') return;
  for (const color of ['w', 'b']) {
    const output = $(`[data-ranked-clock="${color}"]`);
    if (output) output.textContent = rankedClockText(match, color);
  }
}
function rankedClockFaceMarkup(match, color, label) {
  return `<span class="ranked-clock-face" data-clock-color="${color}"><small>${label}</small><strong data-ranked-clock="${color}">${rankedClockText(match, color)}</strong></span>`;
}
function rankedBoardMarkup(match) {
  const snapshot = rankedChess.board();
  const whiteBottom = match?.color !== 'b';
  const ranks = whiteBottom ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = whiteBottom ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const latest = match?.moves?.at(-1) || null;
  const targets = new Map();
  for (const move of rankedTargets) {
    if (!targets.has(move.to)) targets.set(move.to, []);
    targets.get(move.to).push(move);
  }
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const square = `${file}${rank}`;
    const piece = rankedChess.get(square);
    const selected = rankedSelected === square;
    const choices = targets.get(square) || [];
    const isLastFrom = latest?.from === square;
    const isLastTo = latest?.to === square;
    const classes = ['ranked-square', ((file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light'), selected ? 'selected' : '', choices.length ? (piece ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-from' : '', isLastTo ? 'last-to' : ''].filter(Boolean).join(' ');
    const pieceHtml = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : '';
    const tag = isLastTo ? `<span class="ranked-move-tag">${esc(latest.san || '•')}</span>` : '';
    html += `<button type="button" class="${classes}" data-ranked-square="${square}" aria-label="${square}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}" ${match?.status !== 'active' || rankedMoveBusy ? 'disabled' : ''}>${pieceHtml}${tag}${col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}
function rankedMoveListMarkup(match) {
  const moves = match?.moves || [];
  if (!moves.length) return '<div class="empty-state">Nước đi đã được đồng bộ và xác thực trên máy chủ sẽ xuất hiện ở đây.</div>';
  let html = '';
  for (let i = 0; i < moves.length; i += 2) {
    const first = moves[i]; const second = moves[i + 1];
    html += `<div class="ranked-move-row"><b>${Math.floor(i / 2) + 1}.</b><span>${esc(first?.san || '—')}</span><span>${esc(second?.san || '…')}</span></div>`;
  }
  return html;
}
function rankedClockOptionsMarkup() {
  return RANKED_CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${preset.value === selectedRankedTimeControl ? 'selected' : ''}>${esc(preset.label)}</option>`).join('');
}
function renderRankedView() {
  const user = socialState.user;
  if (!socialState.token || !user) return `<section class="content-page ranked-page"><div class="page-intro"><div class="eyebrow">CỜ VUA VILA · RANKED 1V1</div><h1>Đấu xếp hạng</h1><p>Ghép ngẫu nhiên với người chơi thật theo Elo, máy chủ xác thực luật đi và cập nhật điểm.</p></div><section class="panel ranked-queue-card"><div class="ranked-queue-orbit">♟</div><h2>Đăng nhập để tìm đối thủ</h2><p>Đấu xếp hạng cần tài khoản cộng đồng để lưu Elo trên máy chủ, không dùng điểm giả lập cục bộ.</p><button type="button" class="primary-btn" id="rankedOpenAccount">Đăng nhập / tạo tài khoản</button></section></section>`;
  const data = rankedMatchState || {};
  const match = data.match || null;
  if (!match) {
    const waiting = Boolean(data.queued);
    const selectedPreset = RANKED_CLOCK_PRESETS.find(item => item.value === selectedRankedTimeControl) || RANKED_CLOCK_PRESETS.find(item => item.value === '3+2');
    const category = classifyTimeControl(selectedPreset.value);
    const elo = Math.max(100, Number(data.timeCategory === category ? data.rating : 0) || rankedRatingOf(user, category));
    const waitSeconds = Math.floor(Math.max(0, Number(data.waitMs) || 0) / 1000);
    const clockSettings = `<div class="ranked-time-setting"><label class="field-label" for="rankedTimeControl">Thời gian thi đấu · ${rankedCategoryLabel(category)}</label><select id="rankedTimeControl" class="field">${rankedClockOptionsMarkup()}</select><small class="field-hint">Elo Bullet, Blitz và Rapid được tính riêng. Chỉ ghép với người đã chọn cùng mốc thời gian. Cờ ngày (1d/2d) chỉ dành cho đấu trực tuyến.</small></div>`;
    return `<section class="content-page ranked-page"><div class="ranked-topline"><div class="page-intro"><div class="eyebrow">CỜ VUA VILA · XẾP HẠNG TRỰC TUYẾN</div><h1>Ghép trận ngẫu nhiên</h1><p>Ghép người thật theo Elo của đúng thể loại; đồng hồ và kết quả được xác thực bởi máy chủ.</p></div><div class="puzzle-rating-chip">${rankedCategoryLabel(category)} Elo · ${elo}</div></div>${waiting ? `<section class="panel ranked-queue-card"><div class="ranked-queue-orbit">♞</div><h2>Đang tìm đối thủ…</h2><p>Đang ghép người chơi thật theo ${rankedCategoryLabel(data.timeCategory || category)} · ${esc(data.timeControl || selectedRankedTimeControl)}. Bạn có thể hủy hàng đợi trước khi trận bắt đầu.</p><div class="ranked-stat-grid"><div class="ranked-stat"><small>${rankedCategoryLabel(category)} Elo</small><b>${elo}</b></div><div class="ranked-stat"><small>Thời gian chờ</small><b id="rankedQueueWait">${waitSeconds}s</b></div><div class="ranked-stat"><small>Đối thủ</small><b>Đang tìm</b></div></div><div style="margin-top:16px"><button type="button" class="secondary-btn" id="rankedQueueCancel">Hủy tìm trận</button></div></section>` : `<div class="ranked-layout"><div class="ranked-left"><section class="panel ranked-queue-card"><div class="ranked-queue-orbit">⚔</div><h2>Sẵn sàng đấu với người thật?</h2><p>Mỗi tốc độ có Elo riêng. Nếu chưa xếp hạng, máy chủ bắt đầu ở mức 1200 Elo cho từng thể loại.</p>${clockSettings}<button type="button" class="primary-btn full-width" id="rankedQueueStart">⚔ Tìm đối thủ ngẫu nhiên</button><div class="ranked-stat-grid"><div class="ranked-stat"><small>${rankedCategoryLabel(category)} Elo</small><b>${elo}</b></div><div class="ranked-stat"><small>Đã đấu</small><b>${Number(user.games)||0}</b></div><div class="ranked-stat"><small>Thắng</small><b>${Number(user.wins)||0}</b></div></div></section></div><div class="ranked-right"><section class="panel"><h2>Thể loại và đồng hồ</h2><p class="ranked-note">• UltraBullet 15 giây, HyperBullet 30 giây, Bullet 1–2 phút.
• Blitz thường 3–5 phút; Rapid thường 10–30 phút.
• Các mốc có thêm giây (ví dụ 3+2) được hỗ trợ. Phân loại theo thời gian ước tính cho 40 nước.
• Cờ ngày (1d/2d) dành riêng cho đấu trực tuyến; đồng hồ tính theo ngày.
• Mỗi loại có Elo riêng. Đầu hàng hoặc bỏ trận bị trừ thêm 15 Elo trong loại đang chơi.</p><p class="ranked-note">Ghép đấu online cần server đang chạy và người chơi khác đang chờ đúng mốc thời gian. Đấu rank không hiện nút hoàn tác, gợi ý hay phân tích.</p></section></div></div>`}</section>`;
  }
  const color = match.color || 'w';
  const own = color === 'w' ? match.players?.w : match.players?.b;
  const opponent = match.opponent || (color === 'w' ? match.players?.b : match.players?.w);
  const category = ['bullet', 'blitz', 'rapid'].includes(match.timeCategory) ? match.timeCategory : classifyTimeControl(match.timeControl || '3+2');
  const categoryLabel = rankedCategoryLabel(category);
  const active = match.status === 'active';
  const yourTurn = active && rankedChess.turn() === color;
  let resultTitle = ''; let resultClass = '';
  if (!active) {
    const won = match.result === (color === 'w' ? '1-0' : '0-1');
    const draw = match.result === '1/2-1/2';
    resultTitle = draw ? 'HÒA' : won ? 'CHIẾN THẮNG' : 'THẤT BẠI';
    resultClass = draw ? 'is-draw' : won ? 'is-win' : 'is-loss';
  }
  const change = match.eloChanges;
  const delta = Number(change?.delta) || 0;
  const eloAfter = Number(change?.after) || rankedRatingOf(own, category);
  const resultBlock = !active ? `<section class="ranked-result-hero ${resultClass}"><small class="eyebrow">KẾT QUẢ TRẬN ${categoryLabel.toUpperCase()}</small><h2>${resultTitle}</h2><p>${match.resultReason === 'resignation' || match.resultReason === 'abandoned' ? 'Một người chơi đã rời hoặc đầu hàng.' : match.resultReason === 'disconnect_timeout' ? 'Một người chơi mất kết nối quá 90 giây và bị xử thua.' : match.resultReason === 'time_forfeit' ? 'Một người chơi hết giờ.' : match.resultReason === 'checkmate' ? 'Ván cờ kết thúc bằng chiếu hết.' : 'Ván cờ kết thúc theo luật cờ vua.'} Kết quả do máy chủ lưu lại.</p><div class="ranked-elo-change"><div><small>${categoryLabel} Elo sau trận</small><strong>${eloAfter}</strong></div><div><small>Biến động</small><strong class="${delta > 0 ? 'up' : delta < 0 ? 'down' : ''}">${delta > 0 ? '+' : ''}${delta}</strong></div></div><button type="button" class="primary-btn full-width" id="rankedQueueAgain" style="margin-top:14px">Tìm trận tiếp theo · ${esc(match.timeControl || selectedRankedTimeControl)}</button></section>` : '';
  const opponentName = esc(opponent?.displayName || opponent?.username || 'Đối thủ');
  const ownName = esc(user.displayName || user.username);
  return `<section class="content-page ranked-page"><div class="ranked-topline"><div class="page-intro"><div class="eyebrow">CỜ VUA VILA · ${categoryLabel.toUpperCase()} RANK</div><h1>${active ? 'Đang thi đấu' : 'Trận đã kết thúc'}</h1><p>${esc(match.timeControl || '3+2')} · ${categoryLabel} · ${active ? 'Đồng hồ server và nước đi hợp lệ được xác thực từ xa.' : 'Bàn cờ và lịch sử nước đi được giữ để xem lại.'}</p></div><span class="puzzle-rating-chip">${active ? (yourTurn ? 'ĐẾN LƯỢT BẠN' : 'ĐANG CHỜ ĐỐI THỦ') : `Kết quả ${esc(match.result || '—')}`}</span></div>${resultBlock}<div class="ranked-layout"><div class="ranked-left"><div class="ranked-player-bar"><span>♟ <b>${opponentName}</b><small>Đối thủ · ${rankedRatingOf(opponent, category)} ${categoryLabel} Elo</small></span>${active ? rankedClockFaceMarkup(match, color === 'w' ? 'b' : 'w', 'ĐỒNG HỒ ĐỐI THỦ') : `<span class="turn-chip">${color === 'w' ? 'Cầm Trắng' : 'Cầm Đen'}</span>`}</div><div class="ranked-board-wrap"><div class="ranked-board" id="rankedBoard" role="grid" aria-label="Bàn cờ xếp hạng">${rankedBoardMarkup(match)}</div></div><div class="ranked-player-bar"><span>♙ <b>${ownName}</b><small>Bạn · ${rankedRatingOf(own, category)} ${categoryLabel} Elo</small></span>${active ? rankedClockFaceMarkup(match, color, 'ĐỒNG HỒ CỦA BẠN') : `<span class="turn-chip">Đã xong · Elo ${eloAfter}</span>`}</div><div class="ranked-stat-grid"><div class="ranked-stat"><small>Thể loại</small><b>${categoryLabel}</b></div><div class="ranked-stat"><small>Số nửa nước</small><b>${match.moves?.length || 0}</b></div><div class="ranked-stat"><small>${categoryLabel} Elo</small><b>${active ? rankedRatingOf(own, category) : eloAfter}</b></div></div>${active ? '<button type="button" class="danger-btn full-width" id="rankedForfeitBtn">Đầu hàng / thoát trận (mất Elo)</button>' : ''}</div><div class="ranked-right"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ NƯỚC ĐI</small><h2>Biên bản trận</h2></div><span class="context-icon">♞</span></div><div class="ranked-move-list" id="rankedMoveList">${rankedMoveListMarkup(match)}</div><p class="ranked-note">Biên bản được nhận từ máy chủ và phát lại bằng luật cờ vua tiêu chuẩn. Chế độ rank không hỗ trợ hoàn tác, gợi ý hoặc phân tích trong ván.</p></section><section class="panel"><h2>Đối thủ</h2><p>${opponentName} · ${rankedRatingOf(opponent, category)} ${categoryLabel} Elo</p><p class="ranked-note">${active ? (yourTurn ? 'Chạm quân để chọn nước hợp lệ rồi chạm ô đích.' : 'Đợi đối thủ đi; bàn cờ tự đồng bộ khi có nước mới.') : `Mọi Elo ${categoryLabel} trong ván đã được cập nhật tại server.`}</p></section></div></div></section>`;
}
function rankedSyncChess(match) {
  if (!match) return;
  let clone;
  try { clone = new Chess(match.startFen || new Chess().fen()); } catch { clone = new Chess(); }
  for (const move of match.moves || []) {
    try { clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); } catch { break; }
  }
  rankedChess = clone; rankedSelected = null; rankedTargets = [];
}
function rankedStateSignature(data) {
  const m = data?.match;
  return m ? `${m.id}|${m.status}|${m.fen}|${(m.moves || []).length}|${m.result || ''}|${m.timeControl || ''}|${m.timeCategory || ''}|${m.eloChanges?.delta ?? ''}` : `${Boolean(data?.queued)}|${data?.rating || ''}|${data?.timeControl || ''}|${data?.timeCategory || ''}`;
}
function setSelectedRankedTimeControl(value) {
  if (!RANKED_CLOCK_PRESETS.some(preset => preset.value === value)) return false;
  selectedRankedTimeControl = value;
  try { localStorage.setItem('vila.chess.ranked-time-control.v1', JSON.stringify(value)); } catch {}
  return true;
}
async function refreshRankedStatus(silent = true) {
  if (rankedPollBusy || !socialState.token || currentView !== 'ranked') return;
  rankedPollBusy = true;
  const old = rankedMatchState;
  const oldMatch = old?.match;
  const oldSignature = rankedStateSignature(old);
  try {
    const next = await socialApi('/ranked/status');
    const nextSignature = rankedStateSignature(next);
    rankedMatchState = next;
    if (next.match?.timeControl) setSelectedRankedTimeControl(next.match.timeControl);
    if (next.match) rankedSyncChess(next.match);
    if (nextSignature !== oldSignature) {
      if (!oldMatch && next.match?.status === 'active') toast('Đã ghép trận! Trận đấu xếp hạng đã bắt đầu.', 'success');
      if (oldMatch?.status === 'active' && next.match?.status === 'finished') toast('Trận đã kết thúc. Elo đã được cập nhật bởi máy chủ.', 'success');
      rankedLastSignature = nextSignature;
      if (currentView === 'ranked') renderView();
    } else {
      const wait = $('#rankedQueueWait');
      if (wait) wait.textContent = `${Math.floor(Math.max(0, Number(next.waitMs) || 0) / 1000)}s`;
    }
  } catch (error) {
    if (!silent) toast(`Không thể cập nhật trận: ${error.message || error}`);
  } finally { rankedPollBusy = false; }
}
function syncRankedTimers() {
  const shouldPoll = currentView === 'ranked' && Boolean(rankedMatchState?.queued || rankedMatchState?.match?.status === 'active');
  if (shouldPoll && !rankedPollTimer) rankedPollTimer = setInterval(() => { void refreshRankedStatus(true); }, 1800);
  else if (!shouldPoll && rankedPollTimer) { clearInterval(rankedPollTimer); rankedPollTimer = null; }
  const shouldTickClock = currentView === 'ranked' && rankedMatchState?.match?.status === 'active';
  if (shouldTickClock && !rankedClockDisplayTimer) rankedClockDisplayTimer = setInterval(updateRankedClockDisplay, 200);
  else if (!shouldTickClock && rankedClockDisplayTimer) { clearInterval(rankedClockDisplayTimer); rankedClockDisplayTimer = null; }
  if (shouldTickClock) updateRankedClockDisplay();
}
function startRankedPolling() { syncRankedTimers(); }
async function startRankedQueue() {
  if (!socialState.token || !socialState.user) { setView('friends'); toast('Đăng nhập trước khi bắt đầu đấu xếp hạng.'); return; }
  const button = $('#rankedQueueStart');
  if (button) { button.disabled = true; button.textContent = 'Đang vào hàng đợi…'; }
  try {
    rankedMatchState = await socialApi('/ranked/queue', { method: 'POST', body: JSON.stringify({ timeControl: selectedRankedTimeControl }) });
    if (rankedMatchState.match?.timeControl) setSelectedRankedTimeControl(rankedMatchState.match.timeControl);
    if (rankedMatchState.match) rankedSyncChess(rankedMatchState.match);
    rankedLastSignature = rankedStateSignature(rankedMatchState);
    renderView(); startRankedPolling();
    if (rankedMatchState.queued) toast('Đã vào hàng đợi ghép trận theo Elo.');
  } catch (error) {
    toast(`Không thể tìm trận: ${error.message || error}`);
    if (button) { button.disabled = false; button.textContent = '⚔ Tìm đối thủ ngẫu nhiên'; }
  }
}
async function quitRankedMatch(navigating = false) {
  const match = rankedMatchState?.match;
  try {
    if (match?.status === 'active') {
      const data = await socialApi(`/ranked/matches/${encodeURIComponent(match.id)}/resign`, { method: 'POST', body: '{}' });
      rankedMatchState = data; if (data.match) rankedSyncChess(data.match);
      if (!navigating) { toast(`Đã đầu hàng. Elo được cập nhật ở máy chủ (${data.match?.eloChanges?.delta > 0 ? '+' : ''}${data.match?.eloChanges?.delta ?? 0}).`); renderView(); }
    } else if (rankedMatchState?.queued) {
      await socialApi('/ranked/cancel-queue', { method: 'POST', body: '{}' });
      rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user) };
      if (!navigating) { toast('Đã hủy hàng đợi. Chưa phát sinh thay đổi Elo.'); renderView(); }
    }
  } catch (error) { if (!navigating) toast(`Không thể kết thúc trận: ${error.message || error}`); }
}
async function submitRankedMove(from, to, promotion = '') {
  const match = rankedMatchState?.match;
  if (!match || match.status !== 'active' || rankedMoveBusy) return;
  if (rankedChess.turn() !== match.color) { toast('Chưa đến lượt của bạn.'); return; }
  const expectedPly = (match.moves || []).length;
  rankedMoveBusy = true;
  const board = $('#rankedBoard'); if (board) board.setAttribute('aria-busy', 'true');
  try {
    const data = await socialApi(`/ranked/matches/${encodeURIComponent(match.id)}/move`, { method: 'POST', body: JSON.stringify({ from, to, promotion, expectedPly }) });
    rankedMatchState = data;
    if (data.match) rankedSyncChess(data.match);
    rankedLastSignature = rankedStateSignature(data);
    rankedMoveBusy = false;
    renderView();
    if (data.match?.status === 'finished') toast('Đã xác nhận kết quả và Elo trên máy chủ.', 'success');
  } catch (error) {
    await refreshRankedStatus(true);
    toast(`Nước đi chưa được chấp nhận: ${error.message || error}`);
  } finally { rankedMoveBusy = false; }
}
function renderPuzzleBoardMarkup() {
  const rows = puzzleGame.board();
  const orient = puzzleState.rootColor || 'w';
  const ranks = orient === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orient === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const targets = new Map();
  for (const move of puzzleState.targets) { if (!targets.has(move.to)) targets.set(move.to, []); targets.get(move.to).push(move); }
  const hintFrom = puzzleState.showHint ? puzzleState.solutionUci.slice(0,2) : '';
  const hintTo = puzzleState.showHint ? puzzleState.solutionUci.slice(2,4) : '';
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const sq = `${file}${rank}`;
    const piece = puzzleGame.get(sq); const choices = targets.get(sq) || [];
    const movedFrom = puzzleState.lastMove?.from === sq; const movedTo = puzzleState.lastMove?.to === sq;
    const classes = ['puzzle-square', ((file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light'), puzzleState.selected === sq ? 'selected' : '', choices.length ? (piece ? 'capture-target' : 'legal-target') : '', hintFrom === sq ? 'solution-from' : movedFrom ? 'solution-from' : '', hintTo === sq ? 'solution-to' : movedTo ? 'solution-to' : ''].filter(Boolean).join(' ');
    const tag = hintTo === sq ? `<span class="puzzle-tag">BEST</span>` : movedTo ? `<span class="puzzle-tag">✓</span>` : '';
    html += `<button type="button" class="${classes}" data-puzzle-square="${sq}" aria-label="${sq}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}" ${puzzleState.status !== 'ready' ? 'disabled' : ''}>${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${tag}${col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}
function localPuzzleDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
function stopPuzzleRushTimer() {
  if (puzzleRushTimer) clearInterval(puzzleRushTimer);
  puzzleRushTimer = null;
}
function puzzleModeStatusText() {
  if (puzzleState.playMode === 'daily') return `Đề ${puzzleState.dailyDate || localPuzzleDateKey()} · ${puzzleState.dailyAlreadySolved ? 'đã hoàn thành' : '1 thử thách/ngày'}`;
  if (puzzleState.playMode === 'rush') {
    const ms = puzzleState.rushActive && puzzleState.rushDeadlineAt ? Math.max(0, puzzleState.rushDeadlineAt - Date.now()) : puzzleState.rushRemainingMs;
    return `⏱ ${formatClockTime(ms)} · ${puzzleState.runSolved} đúng · kỷ lục ${puzzleState.rushBest}`;
  }
  if (puzzleState.playMode === 'survival') return `♥ ${puzzleState.runLives} mạng · ${puzzleState.runSolved} câu đúng`;
  return `Luyện tự do · ${puzzleState.solvedCount} câu đã giải · tránh lặp trong phiên`;
}
function updatePuzzleModeStatus() {
  const node = $('#puzzleModeStatus');
  if (node) node.textContent = puzzleModeStatusText();
}
function pausePuzzleRushTimer() {
  if (puzzleState.playMode !== 'rush' || !puzzleState.rushActive) { stopPuzzleRushTimer(); return; }
  if (puzzleState.rushDeadlineAt) puzzleState.rushRemainingMs = Math.max(0, puzzleState.rushDeadlineAt - Date.now());
  stopPuzzleRushTimer();
  puzzleState.rushDeadlineAt = 0;
}
function resumePuzzleRushTimer() {
  if (puzzleState.playMode !== 'rush' || !puzzleState.rushActive || currentView !== 'puzzles' || puzzleRushTimer) return;
  if (puzzleState.rushRemainingMs <= 0) {
    finishPuzzleRush();
    return;
  }
  puzzleState.rushDeadlineAt = Date.now() + puzzleState.rushRemainingMs;
  puzzleRushTimer = setInterval(() => {
    puzzleState.rushRemainingMs = Math.max(0, puzzleState.rushDeadlineAt - Date.now());
    updatePuzzleModeStatus();
    if (puzzleState.rushRemainingMs <= 0) finishPuzzleRush();
  }, 250);
  updatePuzzleModeStatus();
}
function finishPuzzleRush() {
  stopPuzzleRushTimer();
  puzzleState.rushRemainingMs = 0;
  puzzleState.rushDeadlineAt = 0;
  puzzleState.rushActive = false;
  puzzleGenerationEpoch += 1;
  puzzleState.status = 'finished';
  puzzleState.lastMessage = `Hết giờ! Bạn giải đúng ${puzzleState.runSolved} câu trong Puzzle Rush. Kỷ lục của bạn: ${puzzleState.rushBest}.`;
  if (currentView === 'puzzles') renderView();
}
function readLichessDailyCache(dateKey) {
  try {
    const cached = JSON.parse(localStorage.getItem(PUZZLE_LICHESS_CACHE_KEY) || 'null');
    if (!cached || cached.dateKey !== dateKey || !validateCachedPuzzleLine(cached, Chess)) return null;
    return cached;
  } catch { return null; }
}
function readLichessPuzzlePool() {
  try {
    const saved = JSON.parse(localStorage.getItem(PUZZLE_LICHESS_POOL_KEY) || '[]');
    return normalizePuzzlePool(saved, item => validateCachedPuzzleLine(item, Chess), LICHESS_PUZZLE_POOL_LIMIT);
  } catch { return []; }
}
function saveLichessPuzzleToPool(item) {
  if (!item || !validateCachedPuzzleLine(item, Chess)) return readLichessPuzzlePool();
  const pool = upsertPuzzlePool(readLichessPuzzlePool(), { ...item, cachedAt: Number(item.cachedAt) || Date.now() }, candidate => validateCachedPuzzleLine(candidate, Chess), LICHESS_PUZZLE_POOL_LIMIT);
  try { localStorage.setItem(PUZZLE_LICHESS_POOL_KEY, JSON.stringify(pool)); } catch (error) { console.warn('[VILA] Could not persist the offline puzzle pool:', error?.message || error); }
  return pool;
}
function pickUnusedCachedLichessPuzzle() {
  return chooseUnusedPuzzle(readLichessPuzzlePool(), puzzleSessionSeen, item => validateCachedPuzzleLine(item, Chess));
}
async function fetchPuzzlePayload({ kind = 'next', difficulty = 'normal', signal, token = '' } = {}) {
  const endpoint = kind === 'daily' ? 'daily' : `next?difficulty=${encodeURIComponent(['easiest','easier','normal','harder','hardest'].includes(difficulty) ? difficulty : 'normal')}`;
  const backend = String(settings.backendUrl || '').trim().replace(/\/+$/, '');
  const backendToken = String(settings.backendAccessToken || '').trim();
  const headers = { Accept: 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  // Prefer the user's own VILA server, which keeps a bounded recent-ID cache; direct Lichess remains a safe fallback.
  if (backend) {
    try {
      const response = await fetch(`${backend}/api/puzzles/${endpoint}`, {
        method: 'GET', cache: 'no-store', headers: { ...headers, ...(backendToken ? { 'X-VILA-Access': backendToken } : {}) },
        ...(signal ? { signal } : {})
      });
      if (response.ok) return await response.json();
      console.info('[VILA] Puzzle server not ready; trying Lichess directly:', response.status);
    } catch (error) {
      if (signal?.aborted) throw error;
      console.info('[VILA] Puzzle server unreachable; trying Lichess directly:', error?.message || error);
    }
  }
  const url = kind === 'daily' ? lichessDailyPuzzleUrl() : lichessPuzzleUrlForDifficulty(difficulty);
  const response = await fetch(url, { method: 'GET', cache: 'no-store', headers, ...(signal ? { signal } : {}) });
  if (!response.ok) throw new Error(`Lichess puzzle endpoint returned HTTP ${response.status}`);
  return response.json();
}
let puzzlePackDownloadBusy = false;
let puzzlePackDownloadStatus = '';
async function downloadLichessPuzzlePack() {
  if (puzzlePackDownloadBusy) return;
  if (typeof navigator === 'undefined' || !navigator.onLine || typeof fetch !== 'function') {
    puzzlePackDownloadStatus = 'Ngoại tuyến: dùng kho đã lưu.';
    const status = $('#puzzlePackStatus'); if (status) status.textContent = puzzlePackDownloadStatus;
    toast('Cần có mạng để tải câu đố Lichess. Các câu đã lưu vẫn dùng được ngoại tuyến.');
    return;
  }
  puzzlePackDownloadBusy = true;
  const button = $('#puzzleDownloadPack');
  const status = $('#puzzlePackStatus');
  if (button) { button.disabled = true; button.textContent = 'Đang tải câu đố…'; }
  let added = 0;
  let checked = 0;
  try {
    const difficultyBands = ['easiest', 'easier', 'normal', 'harder', 'hardest'];
    for (let i = 0; i < PUZZLE_DOWNLOAD_BATCH_SIZE; i += 1) {
      if (i > 0) await new Promise(resolve => setTimeout(resolve, 1050));
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timeout = controller ? setTimeout(() => controller.abort(), 7000) : null;
      try {
        const payload = await fetchPuzzlePayload({ kind: 'next', difficulty: difficultyBands[i % difficultyBands.length], ...(controller ? { signal: controller.signal } : {}) });
        const prepared = { ...prepareLichessDailyPuzzle(payload, Chess), cachedAt: Date.now() };
        checked += 1;
        const before = new Set(readLichessPuzzlePool().map(puzzlePoolKey));
        saveLichessPuzzleToPool(prepared);
        if (!before.has(puzzlePoolKey(prepared))) added += 1;
      } catch (error) {
        console.info('[VILA] Puzzle batch item skipped:', error?.message || error);
      } finally { if (timeout !== null) clearTimeout(timeout); }
      if (status) status.textContent = `Đã kiểm tra ${i + 1}/${PUZZLE_DOWNLOAD_BATCH_SIZE} · thêm ${added} câu`;
      if (currentView === 'puzzles') {
        const count = $('#puzzlePoolCount');
        if (count) count.textContent = String(readLichessPuzzlePool().length);
      }
    }
    const count = readLichessPuzzlePool().length;
    puzzlePackDownloadStatus = `Đã lưu ${count} câu hợp lệ (${added} câu mới trong lượt này).`;
    if (status) status.textContent = puzzlePackDownloadStatus;
    if (added > 0) recordDailyEvent('download_puzzle_pack');
    toast(added ? `Đã thêm ${added} câu đố hợp lệ. Tổng kho ngoại tuyến: ${count}.` : `Không có câu mới được thêm. Kho hiện có ${count} câu hợp lệ; đã thử ${checked} phản hồi.`, added ? 'success' : '');
  } finally {
    puzzlePackDownloadBusy = false;
    const currentButton = $('#puzzleDownloadPack');
    if (currentButton) { currentButton.disabled = false; currentButton.textContent = '⇩ Tải 20 câu về máy'; }
  }
}

function readLichessTrainingCache() {
  try {
    const cached = JSON.parse(localStorage.getItem(PUZZLE_LICHESS_TRAINING_CACHE_KEY) || 'null');
    if (!cached || !validateCachedPuzzleLine(cached, Chess)) return null;
    const key = String(cached.fen).trim().split(/\s+/).slice(0, 4).join(' ');
    if (puzzleSessionSeen.has(key)) return null;
    return cached;
  } catch { return null; }
}
async function loadLichessTrainingPuzzle(difficulty, generationToken) {
  const cached = readLichessTrainingCache() || pickUnusedCachedLichessPuzzle();
  if (typeof navigator !== 'undefined' && navigator.onLine && typeof fetch === 'function') {
    try {
      const token = activeLichessToken || safeSessionGet(lichessTokenKey) || '';
      let prepared = null;
      // Lichess can occasionally hand back a just-seen puzzle. Retry a few bounded times before using the larger local pool.
      for (let attempt = 0; attempt < 3; attempt += 1) {
        const requestController = typeof AbortController === 'function' ? new AbortController() : null;
        const requestTimeout = requestController ? setTimeout(() => requestController.abort(), 4000) : null;
        try {
          const payload = await fetchPuzzlePayload({ kind: 'next', difficulty, token, ...(requestController ? { signal: requestController.signal } : {}) });
          const candidate = prepareLichessDailyPuzzle(payload, Chess);
          if (generationToken !== puzzleGenerationEpoch) return null;
          const key = candidate.fen.trim().split(/\s+/).slice(0, 4).join(' ');
          if (!puzzleSessionSeen.has(key)) { prepared = candidate; break; }
        } catch (requestError) {
          if (generationToken !== puzzleGenerationEpoch) return null;
          console.info(`[VILA] Puzzle request ${attempt + 1}/3 failed; retrying if possible:`, requestError?.message || requestError);
        } finally { if (requestTimeout !== null) clearTimeout(requestTimeout); }
        if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 250));
      }
      if (!prepared) return pickUnusedCachedLichessPuzzle() || cached;
      const item = { ...prepared, difficulty, cachedAt: Date.now() };
      saveLichessPuzzleToPool(item);
      try { localStorage.setItem(PUZZLE_LICHESS_TRAINING_CACHE_KEY, JSON.stringify(item)); } catch {}
      return item;
    } catch (error) {
      if (generationToken !== puzzleGenerationEpoch) return null;
      if (!cached) console.info('[VILA] Online Lichess training puzzle unavailable; using verified offline fallback.', error?.message || error);
    }
  }
  return pickUnusedCachedLichessPuzzle() || cached;
}
async function loadLichessDailyPuzzle(dateKey, generationToken) {
  const cached = readLichessDailyCache(dateKey);
  if (typeof navigator !== 'undefined' && navigator.onLine && typeof fetch === 'function') {
    const controller = typeof AbortController === 'function' ? new AbortController() : null;
    const timeout = controller ? setTimeout(() => controller.abort(), 7000) : null;
    try {
      const payload = await fetchPuzzlePayload({ kind: 'daily', ...(controller ? { signal: controller.signal } : {}) });
      if (generationToken !== puzzleGenerationEpoch) return null;
      const prepared = prepareLichessDailyPuzzle(payload, Chess);
      const item = { ...prepared, dateKey, cachedAt: Date.now() };
      saveLichessPuzzleToPool(item);
      try { localStorage.setItem(PUZZLE_LICHESS_CACHE_KEY, JSON.stringify(item)); } catch {}
      return item;
    } catch (error) {
      // Offline cache is deliberately preferred over blocking puzzle play when Lichess is unreachable.
      if (generationToken !== puzzleGenerationEpoch) return null;
      if (!cached) console.info('[VILA] Lichess Daily Puzzle unavailable; falling back to offline puzzle.', error?.message || error);
    } finally {
      if (timeout !== null) clearTimeout(timeout);
    }
  }
  return cached;
}
function installLichessPuzzle(puzzle) {
  const fen = String(puzzle?.fen || '');
  const line = Array.isArray(puzzle?.moves) ? puzzle.moves : [];
  if (!fen || !line.length || !validateCachedPuzzleLine(puzzle, Chess)) return false;
  puzzleState.rootFen = fen;
  puzzleState.rootPly = Math.max(0, Number(puzzle.initialPly) || 0);
  puzzleState.historyCount = rememberPuzzle(fen).length;
  puzzleSessionSeen.add(fen.trim().split(/\s+/).slice(0, 4).join(' '));
  puzzleGame = new Chess(fen);
  puzzleState.rootColor = puzzleGame.turn();
  puzzleState.solutionLine = [...line];
  puzzleState.solutionIndex = 0;
  puzzleState.solutionUci = line[0];
  puzzleState.status = 'ready';
  puzzleState.attempts = 0;
  puzzleState.puzzleStartedAt = Date.now();
  puzzleState.lastMove = null;
  puzzleState.showHint = false;
  puzzleState.source = 'lichess';
  puzzleState.sourceUrl = /^https:\/\/lichess\.org\/training\/[a-zA-Z0-9_-]{3,32}$/.test(String(puzzle.gameUrl || '')) ? String(puzzle.gameUrl) : 'https://lichess.org/training';
  puzzleState.sourceRating = Number.isFinite(Number(puzzle.rating)) ? Number(puzzle.rating) : null;
  puzzleState.sourceThemes = Array.isArray(puzzle.themes) ? puzzle.themes.slice(0, 8) : [];
  puzzleState.mateOnly = false;
  puzzleState.theme = puzzleState.sourceThemes[0] || 'Lichess Daily';
  puzzleState.level = puzzleState.sourceRating ? `Elo đề ${puzzleState.sourceRating}` : (puzzle.difficulty ? `Lichess · ${puzzle.difficulty}` : 'Lichess Daily');
  puzzleState.lastMessage = `Đề tuyển chọn từ Lichess${puzzleState.sourceRating ? ` · mức ${puzzleState.sourceRating}` : ''}${puzzle.difficulty ? ` · độ khó ${puzzle.difficulty}` : ''}. Tìm toàn bộ dòng chiến thuật; nước đáp của đối thủ sẽ tự chạy. ${puzzleState.sourceThemes.length ? `Chủ đề: ${puzzleState.sourceThemes.join(', ')}.` : ''}`;
  return true;
}

function startPuzzleMode(mode) {
  const allowed = new Set(['classic', 'daily', 'rush', 'survival']);
  if (!allowed.has(mode)) mode = 'classic';
  stopPuzzleRushTimer();
  puzzleGenerationEpoch += 1;
  puzzleState.playMode = mode;
  puzzleState.runSolved = 0;
  puzzleState.runLives = 3;
  puzzleState.rushRemainingMs = 180000;
  puzzleState.rushDeadlineAt = 0;
  puzzleState.rushActive = mode === 'rush';
  puzzleState.dailyDate = localPuzzleDateKey();
  try { puzzleState.dailyAlreadySolved = localStorage.getItem(PUZZLE_DAILY_SOLVED_KEY) === puzzleState.dailyDate; } catch { puzzleState.dailyAlreadySolved = false; }
  puzzleState.status = 'idle';
  puzzleState.lastMessage = mode === 'daily' ? `Đang mở thử thách ngày ${puzzleState.dailyDate}…` : mode === 'rush' ? 'Puzzle Rush bắt đầu: giải càng nhiều càng tốt trước khi hết 3 phút.' : mode === 'survival' ? 'Sinh tồn: bạn có 3 mạng. Mỗi nước giải sai mất một mạng.' : 'Luyện tự do: giải câu đố theo độ khó tăng dần.';
  renderView();
  if (mode === 'rush') resumePuzzleRushTimer();
  void startRandomPuzzle();
}

function renderPuzzleView() {
  const saved = puzzleState.solvedCount;
  const puzzleStage = Math.min(4, Math.floor(saved / 5));
  const puzzleStageLabel = ['Mới bắt đầu', 'Dễ', 'Trung bình', 'Khó', 'Chuyên sâu'][puzzleStage];
  const ready = puzzleState.status === 'ready';
  const loading = puzzleState.status === 'loading';
  const feedbackClass = ['solved', 'revealed'].includes(puzzleState.status) ? 'success' : ['error', 'finished'].includes(puzzleState.status) && (puzzleState.playMode === 'survival' || puzzleState.status === 'error') ? 'error' : puzzleState.status === 'finished' ? 'success' : '';
  return `<section class="content-page puzzle-page"><div class="puzzle-topline"><div class="page-intro"><div class="eyebrow">CỜ VUA VILA · TACTICAL LAB</div><h1>Phòng luyện chiến thuật</h1><p>Chọn luyện tự do, thử thách hằng ngày, Puzzle Rush 3 phút hoặc sinh tồn 3 mạng. Khi có mạng, luyện tập lần lượt lấy câu mới từ Lichess theo 5 mức khó; mỗi dòng lời giải được xác minh bằng luật cờ trước khi dùng. Sau khi giải đúng, bài kế tiếp tự mở; khi API không khả dụng, ứng dụng dùng cache hợp lệ hoặc tự sinh đề ngoại tuyến.</p></div><span class="puzzle-rating-chip">♞ ${puzzleStageLabel} · cấp ${puzzleStage + 1}/5</span></div><div class="puzzle-mode-row" role="group" aria-label="Chế độ luyện câu đố"><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'classic' ? 'active' : ''}" data-puzzle-mode="classic">Luyện tự do</button><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'daily' ? 'active' : ''}" data-puzzle-mode="daily">Đề hôm nay</button><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'rush' ? 'active' : ''}" data-puzzle-mode="rush">Puzzle Rush · 3 phút</button><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'survival' ? 'active' : ''}" data-puzzle-mode="survival">Sinh tồn · 3 mạng</button><span id="puzzleModeStatus" class="puzzle-mode-status">${esc(puzzleModeStatusText())}</span></div><div class="puzzle-pack-row"><div class="puzzle-pack-copy"><b>Kho câu đố ngoại tuyến</b><small><strong id="puzzlePoolCount">${readLichessPuzzlePool().length}</strong> / ${LICHESS_PUZZLE_POOL_LIMIT} câu đã lưu trên máy</small></div><button type="button" id="puzzleDownloadPack" class="secondary-btn" ${puzzlePackDownloadBusy ? 'disabled' : ''}>${puzzlePackDownloadBusy ? 'Đang tải câu đố…' : '⇩ Tải 20 câu về máy'}</button><span id="puzzlePackStatus" role="status">${esc(puzzlePackDownloadStatus || 'Tải qua API Lichess; câu hợp lệ sẽ được lưu để dùng ngoại tuyến.')}</span></div><div class="puzzle-layout"><div class="puzzle-left"><div class="puzzle-board-wrap"><div id="puzzleBoard" class="puzzle-board" role="grid" aria-label="Bàn cờ câu đố">${renderPuzzleBoardMarkup()}</div></div><div class="puzzle-preset-row"><button type="button" class="secondary-btn" id="puzzleNew" ${loading ? 'disabled' : ''}>${loading ? 'Đang tạo thế cờ…' : (puzzleState.status === 'finished' ? 'Chơi lại chế độ' : '🧩 Câu đố mới')}</button><button type="button" class="secondary-btn" id="puzzleHint" ${ready ? '' : 'disabled'}>Gợi ý</button><button type="button" class="secondary-btn" id="puzzleAnalyze" ${puzzleState.rootFen ? '' : 'disabled'}>Phân tích bằng Stockfish</button><button type="button" class="secondary-btn" id="puzzleShowAnswer" ${ready ? '' : 'disabled'}>Xem lời giải</button></div><div id="puzzleFeedback" class="puzzle-feedback ${feedbackClass}" aria-live="polite">${esc(puzzleState.lastMessage)}</div></div><div class="puzzle-right"><section class="panel puzzle-status-card"><div class="puzzle-progress-row"><div><small class="eyebrow">TIẾN BỘ CỦA BẠN</small><div><strong>${saved}</strong> câu đã giải</div></div><span class="puzzle-rating-chip">${ready ? (puzzleState.rootPly === 0 && puzzleState.mateOnly ? 'Chiếu hết trong 1' : `${puzzleState.rootPly} nửa nước ngẫu nhiên`) : loading ? 'Đang chuẩn bị' : puzzleState.status === 'solved' ? 'Đã giải' : puzzleState.status === 'revealed' ? 'Đã xem lời giải' : 'Sẵn sàng'}</span></div><div class="ranked-stat-grid"><div class="ranked-stat"><small>Lượt thử</small><b>${puzzleState.attempts}</b></div><div class="ranked-stat"><small>Nước đi</small><b>${puzzleState.solutionUci ? esc(puzzleState.solutionUci.toUpperCase()) : '—'}</b></div><div class="ranked-stat"><small>Lịch sử đã lưu</small><b>${puzzleState.historyCount}</b></div></div><p class="puzzle-note">Câu đố không làm thay đổi Elo thi đấu. Nguồn hiện tại: ${puzzleState.source === 'lichess' ? `Lichess · mức ${puzzleState.sourceRating ?? '—'}${puzzleState.sourceThemes?.length ? ` · ${esc(puzzleState.sourceThemes.join(', '))}` : ''} · <a href="${esc(puzzleState.sourceUrl || 'https://lichess.org/training')}" target="_blank" rel="noopener noreferrer">mở nguồn ↗</a>` : 'VILA ngoại tuyến · đáp án được kiểm tra bằng luật cờ cục bộ'}. Khi giải đúng, tiến độ nhiệm vụ được cập nhật.</p></section><section class="panel"><h2>Phân tích thế cờ</h2><div id="puzzleAnalysisResult" class="puzzle-feedback">${ready ? 'Chọn nước đi trên bàn cờ; gợi ý và lời giải sẽ được đánh dấu trực tiếp trên ô cờ.' : 'Tạo câu đố mới để bắt đầu.'}</div><p class="puzzle-note">Nước đi được kiểm tra bằng thư viện luật cờ vua. Câu đố có thể dùng tìm kiếm VILA hoặc thế chiếu hết trong 1 đã kiểm chứng; Stockfish dùng để phân tích thêm. Nếu engine chưa sẵn sàng, bạn vẫn có thể giải câu đố ngoại tuyến.</p></section><button type="button" class="secondary-btn full-width" id="puzzleBackToPlay">Quay lại bàn chơi ↗</button></div></div></section>`;
}
function generateRandomLegalPuzzlePosition() {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const clone = new Chess();
    const wantedPlies = 14 + Math.floor(Math.random() * 45);
    for (let ply = 0; ply < wantedPlies; ply += 1) {
      const legal = clone.moves({ verbose: true });
      if (!legal.length) break;
      const move = legal[Math.floor(Math.random() * legal.length)];
      try { clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); } catch { break; }
      if (clone.isGameOver()) break;
    }
    if (!clone.isGameOver() && clone.moves().length) return { fen: clone.fen(), plies: clone.history().length };
  }
  return { fen: new Chess().fen(), plies: 0 };
}
async function startRandomPuzzle() {
  const generationToken = ++puzzleGenerationEpoch;
  if (puzzleState.playMode === 'rush' && !puzzleState.rushActive) { puzzleState.lastMessage = 'Thời gian đã hết. Chọn Puzzle Rush để bắt đầu lượt mới.'; renderView(); return; }
  if (puzzleState.playMode === 'survival' && puzzleState.runLives <= 0) { puzzleState.status = 'finished'; renderView(); return; }
  puzzleState.status = 'loading'; puzzleState.puzzleStartedAt = Date.now(); puzzleState.lastMessage = puzzleState.playMode === 'daily' ? 'Đang tải thử thách hằng ngày; nếu mất mạng sẽ dùng bộ đề ngoại tuyến…' : 'Đang chuẩn bị câu đố mới (có thể chơi ngoại tuyến)…';
  puzzleState.showHint = false; puzzleState.selected = null; puzzleState.targets = []; puzzleState.solutionUci = '';
  puzzleState.solutionLine = []; puzzleState.solutionIndex = 0; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.sourceThemes = []; puzzleState.source = 'offline';
  if (currentView === 'puzzles') renderView();
  const button = $('#puzzleNew'); if (button) { button.disabled = true; button.textContent = 'Đang sinh câu đố…'; }
  try {
    // v3.25: infinite offline puzzles first (no network / Stockfish needed); Stockfish stays as a fallback.
    const history = [...new Set([...loadPuzzleHistory(), ...puzzleSessionSeen])];
    let offline = null;
    if (puzzleState.playMode === 'daily') {
      const dailyPuzzle = await loadLichessDailyPuzzle(puzzleState.dailyDate || localPuzzleDateKey(), generationToken);
      if (generationToken !== puzzleGenerationEpoch) return;
      if (dailyPuzzle && installLichessPuzzle(dailyPuzzle)) {
        try { puzzleState.dailyAlreadySolved = localStorage.getItem(PUZZLE_DAILY_SOLVED_KEY) === puzzleState.dailyDate; } catch { puzzleState.dailyAlreadySolved = false; }
        if (puzzleState.dailyAlreadySolved) puzzleState.lastMessage += ' Bạn đã hoàn thành đề hôm nay; luyện lại không cộng điểm lần nữa.';
        if (currentView === 'puzzles') renderView();
        return;
      }
      offline = await generateDailyPuzzleInWorker(puzzleState.dailyDate || localPuzzleDateKey());
      if (generationToken !== puzzleGenerationEpoch) return;
    } else {
      // Prefer a unique live Lichess puzzle; the bounded validated cache supplies a rotating offline queue.
      const requestedDifficulty = lichessDifficultyForProgress(puzzleState.solvedCount);
      const onlinePuzzle = await loadLichessTrainingPuzzle(requestedDifficulty, generationToken);
      if (generationToken !== puzzleGenerationEpoch) return;
      if (onlinePuzzle && installLichessPuzzle({ ...onlinePuzzle, difficulty: requestedDifficulty })) {
        if (currentView === 'puzzles') renderView();
        return;
      }
      // Fallback still works completely offline and raises the local generator tier as progress grows.
      const localTier = Math.min(3, Math.floor(puzzleState.solvedCount / 5));
      for (let attempt = 0; attempt < 4 && !offline; attempt += 1) {
        offline = await generateOfflinePuzzle({ budgetMs: 6000, excludeFens: history, difficulty: localTier });
        if (generationToken !== puzzleGenerationEpoch) return;
        if (offline && history.includes(offline.fen.trim().split(/\s+/).slice(0, 4).join(' '))) offline = null;
      }
    }
    if (generationToken !== puzzleGenerationEpoch) return;
    if (puzzleState.playMode === 'daily' && (!offline || !isPuzzleAnswerLegal(offline))) {
      throw new Error('Không tạo được đề hằng ngày đã xác minh; thử lại sau hoặc dùng Luyện tự do.');
    }
    if (offline && isPuzzleAnswerLegal(offline)) {
      puzzleState.rootFen = offline.fen;
      puzzleSessionSeen.add(offline.fen.trim().split(/\s+/).slice(0, 4).join(' '));
      puzzleState.historyCount = rememberPuzzle(offline.fen).length; puzzleState.rootPly = offline.plies;
      if (puzzleState.playMode === 'daily') { puzzleState.dailyDate = offline.dailyDate || puzzleState.dailyDate; try { puzzleState.dailyAlreadySolved = localStorage.getItem(PUZZLE_DAILY_SOLVED_KEY) === puzzleState.dailyDate; } catch {} }
      puzzleState.rootColor = new Chess(offline.fen).turn(); puzzleGame = new Chess(offline.fen);
      puzzleState.solutionUci = offline.best; puzzleState.solutionLine = [offline.best]; puzzleState.solutionIndex = 0; puzzleState.status = 'ready'; puzzleState.attempts = 0; puzzleState.puzzleStartedAt = Date.now();
      puzzleState.lastMove = null; puzzleState.showHint = false; puzzleState.source = 'offline'; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.sourceThemes = []; puzzleState.mateOnly = offline.mateOnly;
      puzzleState.theme = offline.theme; puzzleState.level = offline.level;
      puzzleState.lastMessage = puzzleState.playMode === 'daily' ? `[Thử thách ngày ${puzzleState.dailyDate}] Chiếu hết trong 1 — tìm nước duy nhất. ${puzzleState.dailyAlreadySolved ? 'Bạn đã hoàn thành đề hôm nay; lần luyện lại không cộng điểm lần nữa.' : 'Lời giải được kiểm tra có đúng một nước chiếu hết.'}` : `[${offline.theme} · ${offline.level}] ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi — tìm nước tốt nhất. Chọn quân rồi chạm ô đích.`;
      if (currentView === 'puzzles') renderView();
      return;
    }
    puzzleState.source = 'stockfish'; puzzleState.mateOnly = false;
    let chosen = null;
    // Try several legal random positions to prefer a tactical best move (capture,
    // promotion, check, or mate). A fallback keeps the feature usable on a position
    // where the engine's best move is positional instead of forcing.
    for (let attempt = 0; attempt < 7; attempt += 1) {
      const position = generateRandomLegalPuzzlePosition();
      const positionKey = position.fen.trim().split(/\s+/).slice(0, 4).join(' ');
      if (history.includes(positionKey)) continue;
      const best = await requestStockfishUci(position.fen, { skill: 20, depth: 16, moveTimeMs: 1050, timeoutMs: 11000 });
      if (generationToken !== puzzleGenerationEpoch) return;
      if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(best)) throw new Error('Stockfish không trả về nước đi hợp lệ cho thế cờ mới.');
      const clone = new Chess(position.fen);
      const answer = clone.move({ from: best.slice(0,2), to: best.slice(2,4), ...(best[4] ? { promotion: best[4] } : {}) });
      if (!answer) throw new Error('Không thể kiểm tra nước trả lời của Stockfish.');
      const tactical = Boolean(answer.captured || answer.promotion || /[+#]/.test(answer.san));
      if (!tactical) continue;
      chosen = { position, best, tactical };
      break;
    }
    if (!chosen) throw new Error('Không tìm được thế cờ để chấm.');
    const stockfishPuzzle = { fen: chosen.position.fen, best: chosen.best };
    if (!isPuzzleAnswerLegal(stockfishPuzzle)) throw new Error('Nước giải không vượt qua bước kiểm tra hợp lệ.');
    puzzleSessionSeen.add(chosen.position.fen.trim().split(/\s+/).slice(0, 4).join(' '));
    puzzleState.rootFen = chosen.position.fen; puzzleState.historyCount = rememberPuzzle(chosen.position.fen).length; puzzleState.rootPly = chosen.position.plies;
    puzzleState.rootColor = new Chess(chosen.position.fen).turn(); puzzleGame = new Chess(chosen.position.fen);
    puzzleState.solutionUci = chosen.best; puzzleState.solutionLine = [chosen.best]; puzzleState.solutionIndex = 0; puzzleState.status = 'ready'; puzzleState.attempts = 0; puzzleState.puzzleStartedAt = Date.now();
    puzzleState.lastMove = null; puzzleState.showHint = false; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.sourceThemes = [];
    puzzleState.lastMessage = chosen.tactical
      ? `Tìm nước chiến thuật tốt nhất cho ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi. Chọn quân rồi chạm ô đích.`
      : `Tìm nước tốt nhất cho ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi. Thế cờ này thiên về nước chiến lược/phòng thủ.`;
  } catch (error) {
    if (generationToken !== puzzleGenerationEpoch) return;
    puzzleState.status = 'error'; puzzleState.lastMessage = `Không tạo được câu đố: ${String(error.message || error)}. Bấm “Câu đố mới” để thử lại hoặc đổi sang Đề hôm nay.`;
  }
  if (currentView === 'puzzles') renderView();
}
function selectPuzzleSquare(square) {
  if (puzzleState.status !== 'ready') return;
  const piece = puzzleGame.get(square);
  if (puzzleState.selected && puzzleState.targets.some(move => move.to === square)) {
    const move = puzzleState.targets.find(candidate => candidate.to === square);
    void submitPuzzleAnswer(move);
    return;
  }
  if (piece && piece.color === puzzleGame.turn()) {
    puzzleState.selected = square; puzzleState.targets = puzzleGame.moves({ square, verbose: true });
  } else { puzzleState.selected = null; puzzleState.targets = []; }
  const board = $('#puzzleBoard'); if (board) board.innerHTML = renderPuzzleBoardMarkup();
}
function showPuzzleHint(reveal = false) {
  const line = Array.isArray(puzzleState.solutionLine) && puzzleState.solutionLine.length ? puzzleState.solutionLine : [puzzleState.solutionUci];
  const remaining = line.slice(Math.max(0, puzzleState.solutionIndex || 0));
  if (!remaining[0]) { toast('Tạo câu đố trước khi xin gợi ý.'); return; }
  puzzleState.showHint = true;
  const answerBoard = new Chess(puzzleGame.fen());
  const sanLine = [];
  try {
    const next = answerBoard.move(uciToMove(remaining[0]));
    if (!next) throw new Error('Nước kế tiếp không hợp lệ.');
    sanLine.push(next.san);
    if (reveal) {
      for (const uci of remaining.slice(1)) {
        const move = answerBoard.move(uciToMove(uci));
        if (!move) throw new Error('Dòng lời giải không hợp lệ.');
        sanLine.push(move.san);
      }
    }
  } catch (error) { toast(`Không thể xác minh lời giải: ${error.message || error}`); return; }
  const currentUci = remaining[0];
  const output = $('#puzzleAnalysisResult');
  if (output) output.textContent = `${reveal ? 'Lời giải còn lại' : 'Gợi ý'}: ${sanLine.join(' · ')}. ${!reveal ? `Nước kế tiếp: ${currentUci}. Ô đi và ô đến đã được đánh dấu.` : ''}`;
  if (reveal && puzzleState.status === 'ready') {
    puzzleState.status = 'revealed';
    puzzleState.lastMessage = `Dòng lời giải: ${sanLine.join(' · ')}. Đây chỉ là xem lời giải, không tính là tự giải đúng.`;
    puzzleState.lastMove = answerBoard.history({ verbose: true }).at(-1) || null;
    puzzleGame = answerBoard; puzzleState.solutionIndex = line.length;
    puzzleState.selected = null; puzzleState.targets = [];
  }
  if (currentView === 'puzzles') renderView();
}
async function submitPuzzleAnswer(candidate) {
  if (puzzleState.status !== 'ready') return;
  const uci = `${candidate.from}${candidate.to}${candidate.promotion || ''}`;
  puzzleState.attempts += 1;
  const line = Array.isArray(puzzleState.solutionLine) && puzzleState.solutionLine.length ? puzzleState.solutionLine : [puzzleState.solutionUci];
  const expectedIndex = Math.max(0, Number(puzzleState.solutionIndex) || 0);
  const expectedUci = line[expectedIndex] || puzzleState.solutionUci;
  let acceptable = uci === expectedUci;
  if (!acceptable && puzzleState.mateOnly) {
    const probe = new Chess(puzzleGame.fen());
    try { probe.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) }); acceptable = probe.isCheckmate(); } catch {}
  }
  if (!acceptable) {
    puzzleState.selected = null; puzzleState.targets = []; puzzleState.showHint = false;
    // The board is not mutated until an answer is accepted, so preserve the current multi-move position.
    puzzleState.streak = 0;
    try { localStorage.setItem('vila.chess.puzzles.streak.v1', '0'); } catch {}
    if (puzzleState.playMode === 'survival') {
      puzzleState.runLives = Math.max(0, puzzleState.runLives - 1);
      if (puzzleState.runLives <= 0) {
        puzzleState.status = 'finished';
        puzzleState.lastMessage = `Hết mạng! Bạn giải đúng ${puzzleState.runSolved} câu sinh tồn. Chọn Sinh tồn để bắt đầu lượt mới.`;
      } else {
        puzzleState.status = 'ready';
        puzzleState.lastMessage = `Chưa đúng — mất 1 mạng, còn ${puzzleState.runLives}. Vị trí hiện tại được giữ nguyên để bạn thử tiếp.`;
      }
    } else {
      puzzleState.lastMessage = 'Chưa phải nước được xác minh tốt nhất. Vị trí hiện tại được giữ nguyên; thử nước khác hoặc xem gợi ý.';
      puzzleState.status = 'ready';
    }
    renderView(); return;
  }
  try {
    const move = puzzleGame.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) });
    if (!move) throw new Error('Nước đi không còn hợp lệ ở vị trí hiện tại.');
    const playedSan = [move.san];
    let lastMove = move;
    let nextIndex = expectedIndex + 1;
    let opponentSan = '';
    // For curated multi-ply puzzles, play the forced opponent reply automatically,
    // then wait for the next move from the player. Offline generated puzzles use a one-move line.
    if (nextIndex < line.length && !puzzleGame.isGameOver()) {
      const reply = puzzleGame.move(uciToMove(line[nextIndex]));
      if (!reply) throw new Error('Nước đáp của lời giải không hợp lệ.');
      opponentSan = reply.san; playedSan.push(reply.san); lastMove = reply; nextIndex += 1;
    }
    puzzleState.lastMove = lastMove; puzzleState.selected = null; puzzleState.targets = []; puzzleState.showHint = false;
    puzzleState.solutionIndex = nextIndex;
    const completed = nextIndex >= line.length || puzzleGame.isGameOver();
    if (!completed) {
      puzzleState.solutionUci = line[nextIndex];
      puzzleState.status = 'ready';
      puzzleState.lastMessage = `Đúng: ${move.san}.${opponentSan ? ` Đối thủ đáp ${opponentSan}.` : ''} Tiếp tục tìm nước tiếp theo trong dòng chiến thuật.`;
      renderView();
      return;
    }
    puzzleState.status = 'solved';
    const dailyAlreadyCredited = puzzleState.playMode === 'daily' && puzzleState.dailyAlreadySolved;
    const sourceLabel = puzzleState.source === 'lichess' ? 'Câu đố tuyển chọn Lichess đã xác minh luật' : puzzleState.source === 'offline' ? 'Thế cờ được kiểm tra ngoại tuyến' : 'Nước đi được Stockfish đề xuất';
    puzzleState.lastMessage = `Chính xác: ${playedSan.join(' · ')}. ${sourceLabel}. ${dailyAlreadyCredited ? 'Bạn đã nhận thành tích đề hôm nay trước đó; lần luyện lại không cộng thêm.' : ''}`;
    if (!dailyAlreadyCredited) puzzleState.solvedCount += 1;
    if (['rush', 'survival'].includes(puzzleState.playMode)) { puzzleState.runSolved += 1; if (puzzleState.playMode === 'rush' && puzzleState.runSolved > puzzleState.rushBest) { puzzleState.rushBest = puzzleState.runSolved; try { localStorage.setItem(PUZZLE_RUSH_BEST_KEY, String(puzzleState.rushBest)); } catch {} } }
    if (puzzleState.playMode === 'daily' && !dailyAlreadyCredited) { puzzleState.dailyAlreadySolved = true; try { localStorage.setItem(PUZZLE_DAILY_SOLVED_KEY, puzzleState.dailyDate); } catch {} }
    puzzleState.lastSolveMs = Math.max(0, Date.now() - (puzzleState.puzzleStartedAt || Date.now()));
    if (!dailyAlreadyCredited) { puzzleState.streak += 1; puzzleState.bestStreak = Math.max(puzzleState.bestStreak, puzzleState.streak); }
    try {
      localStorage.setItem('vila.chess.puzzles.streak.v1', String(puzzleState.streak));
      localStorage.setItem('vila.chess.puzzles.bestStreak.v1', String(puzzleState.bestStreak));
      localStorage.setItem('vila.chess.puzzles.solved.v1', String(puzzleState.solvedCount));
    } catch {}
    if (!dailyAlreadyCredited) recordDailyEvent('solve_puzzle');
    if (currentView === 'puzzles') renderView();
    if (['classic', 'rush', 'survival', 'daily'].includes(puzzleState.playMode)) setTimeout(() => {
      if (currentView !== 'puzzles' || puzzleState.status !== 'solved' || (puzzleState.playMode === 'rush' && !puzzleState.rushActive) || (puzzleState.playMode === 'survival' && puzzleState.runLives <= 0)) return;
      // Daily is one credited challenge per day; after it, keep practice flowing with progressive offline puzzles.
      if (puzzleState.playMode === 'daily') puzzleState.playMode = 'classic';
      void startRandomPuzzle();
    }, 800);
  } catch (error) { puzzleState.lastMessage = `Không thể áp dụng nước: ${error.message || error}`; renderView(); }
}
function wireRankedActions() {
  $('#rankedOpenAccount')?.addEventListener('click', () => setView('friends'));
  $('#rankedTimeControl')?.addEventListener('change', event => {
    const value = event.currentTarget.value;
    if (!setSelectedRankedTimeControl(value)) return;
    const category = classifyTimeControl(value);
    rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, category), timeControl: value, timeCategory: category };
    renderView();
  });
  $('#rankedQueueStart')?.addEventListener('click', startRankedQueue);
  $('#rankedQueueCancel')?.addEventListener('click', async () => { try { await socialApi('/ranked/cancel-queue', { method: 'POST', body: '{}' }); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user) }; renderView(); toast('Đã hủy hàng đợi.'); } catch (error) { toast(`Không thể hủy hàng đợi: ${error.message || error}`); } });
  $('#rankedQueueAgain')?.addEventListener('click', async () => { setSelectedRankedTimeControl(rankedMatchState?.match?.timeControl || selectedRankedTimeControl); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, classifyTimeControl(selectedRankedTimeControl)) }; await startRankedQueue(); });
  $('#rankedForfeitBtn')?.addEventListener('click', async () => { if (confirm('Đầu hàng/thoát trận sẽ tính là thua và có thể bị trừ thêm 15 Elo. Tiếp tục?')) await quitRankedMatch(false); });
  $('#rankedBoard')?.addEventListener('click', event => {
    const button = event.target.closest('[data-ranked-square]'); if (!button || rankedMoveBusy) return;
    const match = rankedMatchState?.match; if (!match || match.status !== 'active' || rankedChess.turn() !== match.color) return;
    const square = button.dataset.rankedSquare; const piece = rankedChess.get(square);
    if (rankedSelected && rankedTargets.some(move => move.to === square)) {
      const options = rankedTargets.filter(move => move.to === square);
      const promotion = options.find(move => move.promotion)?.promotion;
      if (promotion) void choosePromotion(rankedChess.turn()).then(type => type && submitRankedMove(rankedSelected, square, type));
      else void submitRankedMove(rankedSelected, square);
      rankedSelected = null; rankedTargets = []; return;
    }
    if (piece && piece.color === match.color) { rankedSelected = square; rankedTargets = rankedChess.moves({ square, verbose: true }); }
    else { rankedSelected = null; rankedTargets = []; }
    const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(match);
  });
  if (rankedMatchState?.queued || rankedMatchState?.match?.status === 'active') startRankedPolling();
  if (rankedMatchState?.match) { const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(rankedMatchState.match); }
}
let puzzlePointerState = null;
let puzzleSuppressClick = null;
function wirePuzzleBoardPointer(board) {
  if (!board || board.dataset.puzzlePointerWired === 'true') return;
  board.dataset.puzzlePointerWired = 'true';
  board.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    const square = event.target?.closest?.('[data-puzzle-square]');
    if (!square || !board.contains(square) || puzzleState.status !== 'ready') return;
    const from = square.dataset.puzzleSquare;
    const piece = puzzleGame.get(from);
    if (!piece || piece.color !== puzzleGame.turn()) return;
    // Cache legal moves once at pointer-down; never regenerate move lists on every drag event.
    const legalMoves = puzzleGame.moves({ square: from, verbose: true });
    if (!legalMoves.length) return;
    puzzlePointerState = { pointerId: event.pointerId, from, startX: event.clientX, startY: event.clientY, moved: false, fen: puzzleGame.fen(), legalMoves, legalTargets: new Set(legalMoves.map(move => move.to)) };
    try { board.setPointerCapture(event.pointerId); } catch {}
    event.preventDefault?.();
  }, { passive: false });
  board.addEventListener('pointermove', event => {
    const state = puzzlePointerState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (!state.moved && Math.hypot(event.clientX - state.startX, event.clientY - state.startY) >= 6) {
      state.moved = true;
      board.querySelector(`[data-puzzle-square="${state.from}"]`)?.classList.add('puzzle-dragging-source');
    }
    if (!state.moved) return;
    event.preventDefault?.();
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest?.('[data-puzzle-square]');
    const old = board.querySelector('.puzzle-drag-over');
    if (old && old !== target) old.classList.remove('puzzle-drag-over');
    if (target && board.contains(target) && state.legalTargets.has(target.dataset.puzzleSquare)) target.classList.add('puzzle-drag-over');
    else target?.classList.remove('puzzle-drag-over');
  }, { passive: false });
  const finish = event => {
    const state = puzzlePointerState;
    if (!state || state.pointerId !== event.pointerId) return;
    puzzlePointerState = null;
    board.querySelectorAll('.puzzle-dragging-source,.puzzle-drag-over').forEach(node => node.classList.remove('puzzle-dragging-source','puzzle-drag-over'));
    const target = state.moved ? document.elementFromPoint(event.clientX, event.clientY)?.closest?.('[data-puzzle-square]') : null;
    const targetSquare = target && board.contains(target) ? target.dataset.puzzleSquare : '';
    puzzleSuppressClick = { square: targetSquare || state.from, until: Date.now() + 180 };
    if (state.fen !== puzzleGame.fen()) return;
    if (!state.moved) {
      selectPuzzleSquare(state.from);
      return;
    }
    event.preventDefault?.();
    const candidate = state.legalMoves.find(move => move.to === targetSquare);
    if (candidate) void submitPuzzleAnswer(candidate);
    else selectPuzzleSquare(state.from);
  };
  board.addEventListener('pointerup', finish, { passive: false });
  const cancel = event => {
    if (!puzzlePointerState || puzzlePointerState.pointerId !== event.pointerId) return;
    puzzlePointerState = null;
    board.querySelectorAll('.puzzle-dragging-source,.puzzle-drag-over').forEach(node => node.classList.remove('puzzle-dragging-source','puzzle-drag-over'));
  };
  board.addEventListener('pointercancel', cancel, { passive: true });
  board.addEventListener('lostpointercapture', cancel, { passive: true });
}
function wirePuzzleActions() {
  wirePuzzleBoardPointer($('#puzzleBoard'));
  $$('[data-puzzle-mode]').forEach(button => button.addEventListener('click', () => startPuzzleMode(button.dataset.puzzleMode)));
  $('#puzzleNew')?.addEventListener('click', () => { if (puzzleState.status === 'finished') startPuzzleMode(puzzleState.playMode); else void startRandomPuzzle(); });
  $('#puzzleDownloadPack')?.addEventListener('click', () => { void downloadLichessPuzzlePack(); });
  $('#puzzleHint')?.addEventListener('click', () => showPuzzleHint(false));
  $('#puzzleShowAnswer')?.addEventListener('click', () => showPuzzleHint(true));
  $('#puzzleAnalyze')?.addEventListener('click', async () => {
    if (!puzzleState.rootFen) return;
    const output = $('#puzzleAnalysisResult'); if (output) output.textContent = 'Stockfish đang phân tích thế cờ…';
    try {
      const best = await requestStockfishUci(puzzleState.rootFen, { skill: 20, depth: 20, moveTimeMs: 1800, timeoutMs: 18000 });
      const clone = new Chess(puzzleState.rootFen); const move = clone.move({ from: best.slice(0,2), to: best.slice(2,4), ...(best[4] ? { promotion: best[4] } : {}) });
      puzzleState.solutionUci = best; puzzleState.showHint = true;
      if (output) output.textContent = move ? `Nước tốt nhất theo Stockfish: ${move.san} (${best}). Mũi chỉ dẫn đánh dấu trên bàn cờ.` : `Engine trả về ${best}.`;
      const board = $('#puzzleBoard'); if (board) board.innerHTML = renderPuzzleBoardMarkup();
    } catch (error) { if (output) output.textContent = `Không thể phân tích: ${error.message || error}`; }
  });
  $('#puzzleBackToPlay')?.addEventListener('click', () => setView('play'));
  $('#puzzleBoard')?.addEventListener('click', event => {
    const button = event.target.closest('[data-puzzle-square]'); if (!button) return;
    if (puzzleSuppressClick && Date.now() <= puzzleSuppressClick.until && button.dataset.puzzleSquare === puzzleSuppressClick.square) {
      puzzleSuppressClick = null; event.preventDefault(); return;
    }
    if (puzzleSuppressClick && Date.now() > puzzleSuppressClick.until) puzzleSuppressClick = null;
    selectPuzzleSquare(button.dataset.puzzleSquare);
  });
}

// ---- Chess.com-style end-of-game dialog: result, Elo, rematch / new match, analysis ----
let resultModalKey = '';
let resultModalPrevFocus = null;
function closeResultModal() {
  const node = document.getElementById('resultModal');
  if (!node) return;
  node.remove();
  document.removeEventListener('keydown', resultModalKeydown, true);
  try { resultModalPrevFocus?.focus?.({ preventScroll: true }); } catch {}
  resultModalPrevFocus = null;
}
function resultModalKeydown(event) {
  if (event.key === 'Escape') { event.stopPropagation(); closeResultModal(); }
}
function showResultModal({ key, tone = 'draw', icon = '½', title, subtitle = '', players = '', stats = [], actions = [] }) {
  if (!key || resultModalKey === key) return;
  resultModalKey = key;
  document.getElementById('resultModal')?.remove();
  const statHtml = stats.filter(Boolean).map(item => `<div><small>${esc(item.label)}</small><b class="${esc(item.tone || '')}">${esc(item.value)}</b></div>`).join('');
  const actionHtml = actions.map((action, index) => `<button type="button" class="${action.primary ? 'primary-btn' : 'secondary-btn'} result-modal-action" data-result-action="${index}">${esc(action.label)}</button>`).join('');
  const wrap = document.createElement('div');
  wrap.id = 'resultModal';
  wrap.className = 'result-modal-backdrop';
  wrap.innerHTML = `<div class="result-modal tone-${esc(tone)}" role="dialog" aria-modal="true" aria-labelledby="resultModalTitle"><button type="button" class="result-modal-close" aria-label="Đóng bảng kết quả">×</button><div class="result-modal-badge" aria-hidden="true">${esc(icon)}</div><h2 id="resultModalTitle">${esc(title)}</h2>${subtitle ? `<p class="result-modal-sub">${esc(subtitle)}</p>` : ''}${players ? `<div class="result-modal-players">${esc(players)}</div>` : ''}${statHtml ? `<div class="result-modal-stats">${statHtml}</div>` : ''}<div class="result-modal-actions">${actionHtml}</div></div>`;
  wrap.addEventListener('click', event => { if (event.target === wrap) closeResultModal(); });
  wrap.querySelector('.result-modal-close')?.addEventListener('click', closeResultModal);
  wrap.querySelectorAll('[data-result-action]').forEach(button => button.addEventListener('click', () => {
    const action = actions[Number(button.dataset.resultAction)];
    closeResultModal();
    try { action?.run?.(); } catch (error) { toast(`Không thực hiện được: ${error.message || error}`); }
  }));
  resultModalPrevFocus = document.activeElement;
  document.body.appendChild(wrap);
  document.addEventListener('keydown', resultModalKeydown, true);
  wrap.querySelector('.result-modal-action')?.focus({ preventScroll: true });
}
function resultToneFor(token, perspective) {
  if (token === '1/2-1/2') return { tone: 'draw', icon: '½', title: 'Hòa cờ' };
  if (!perspective) return { tone: 'win', icon: '♚', title: token === '1-0' ? 'Trắng thắng' : 'Đen thắng' };
  const won = (token === '1-0' && perspective === 'w') || (token === '0-1' && perspective === 'b');
  return won ? { tone: 'win', icon: '♛', title: 'Bạn thắng!' } : { tone: 'loss', icon: '♟', title: 'Bạn thua' };
}
function syntheticRecord(pgn, token, title, detail, signature) {
  return { id: signature, signature, pgn, startFen: new Chess().fen(), resultToken: token, title, detail, reviewRows: [] };
}
function maybeShowPlayResultModal() {
  if (currentView !== 'play' || !gameStarted || mode === 'lichess') return;
  if (!(game.isGameOver() || clockFlagged || manualGameResult)) return;
  if (manualGameResult?.reason === 'saved-replay') return;
  const result = getGameResult();
  if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const solo = mode !== 'local';
  const look = resultToneFor(result.token, solo ? humanColor : null);
  const rated = ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode);
  const profile = rated ? readRatingProfile() : null;
  const opponent = mode === 'stockfish' ? 'Stockfish 19' : mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : ''; 
  showResultModal({
    key: `play:${currentGameId}:${result.token}`,
    ...look,
    subtitle: `${result.title}${result.detail ? ' — ' + result.detail : ''}`,
    players: opponent ? `${humanColor === 'w' ? 'Bạn' : opponent} (Trắng) · ${humanColor === 'b' ? 'Bạn' : opponent} (Đen)` : 'Trắng · Đen',
    stats: [
      { label: 'Số nước', value: String(Math.ceil(game.history().length / 2)) },
      profile ? { label: 'Elo', value: String(profile.elo) } : null,
      profile && profile.lastChange ? { label: 'Biến động', value: `${profile.lastChange > 0 ? '+' : ''}${profile.lastChange}`, tone: profile.lastChange > 0 ? 'up' : 'down' } : null,
      engineSpeed && (mode === 'stockfish' || mode === 'enginehub' || mode === 'vila') ? { label: 'Tốc độ engine', value: engineSpeed.nps ? `${formatNps(engineSpeed.nps)} nút/giây` : `d${engineSpeed.depth}` } : null
    ],
    actions: [
      { label: '↻ Chơi lại', primary: true, run: () => freshGame() },
      { label: '♞ Phân tích ván', run: () => { setView('review'); setTimeout(() => startFullGameReview(), 100); } },
      { label: '⚔ Ghép trận xếp hạng', run: () => setView('ranked') }
    ]
  });
}
function maybeShowRankedResultModal() {
  const match = rankedMatchState?.match;
  if (currentView !== 'ranked' || !match || match.status === 'active') return;
  const color = match.color || 'w';
  const category = ['bullet', 'blitz', 'rapid'].includes(match.timeCategory) ? match.timeCategory : classifyTimeControl(match.timeControl || '3+2');
  const look = resultToneFor(match.result, color);
  const change = match.eloChanges;
  const delta = Number(change?.delta) || 0;
  const opponent = match.opponent || (color === 'w' ? match.players?.b : match.players?.w);
  showResultModal({
    key: `ranked:${match.id}`,
    ...look,
    subtitle: `${rankedCategoryLabel(category)} · ${match.timeControl || ''}`,
    players: `Đối thủ: ${opponent?.displayName || opponent?.username || 'Người chơi'}`,
    stats: [
      Number.isFinite(Number(change?.after)) ? { label: 'Elo mới', value: String(Number(change.after)) } : null,
      { label: 'Biến động', value: `${delta > 0 ? '+' : ''}${delta}`, tone: delta > 0 ? 'up' : delta < 0 ? 'down' : '' },
      { label: 'Số nước', value: String(Math.ceil(rankedChess.history().length / 2)) }
    ],
    actions: [
      { label: '⚔ Ghép trận mới', primary: true, run: async () => { setSelectedRankedTimeControl(match.timeControl || selectedRankedTimeControl); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, category) }; await startRankedQueue(); } },
      { label: '♞ Phân tích ván', run: () => restoreSavedGame(syntheticRecord(rankedChess.pgn(), match.result, look.title, `Trận xếp hạng ${match.timeControl || ''}`, `ranked-${match.id}`), true) }
    ]
  });
}
function showArenaResultModal(white, black, result) {
  if (!result || result.stopped || !result.pgn) return;
  const winnerName = result.result === '1-0' ? result.white : result.result === '0-1' ? result.black : '';
  showResultModal({
    key: `arena:${arenaGameCounter}:${result.result}`,
    tone: winnerName ? 'win' : 'draw',
    icon: winnerName ? '♚' : '½',
    title: winnerName ? `${winnerName} thắng` : 'Hòa cờ',
    subtitle: `${result.reason} · ${result.plies} nửa nước`,
    players: `${result.white} (Trắng) vs ${result.black} (Đen)`,
    stats: [engineSpeed ? { label: 'Tốc độ engine', value: engineSpeed.nps ? `${formatNps(engineSpeed.nps)} nút/giây` : `d${engineSpeed.depth}` } : null],
    actions: [
      { label: '↻ Đấu lại', primary: true, run: () => startArenaMatch(white.id, black.id) },
      { label: '♞ Phân tích ván', run: () => restoreSavedGame(syntheticRecord(result.pgn, result.result, `${result.white} vs ${result.black}`, result.reason, `arena-${arenaGameCounter}-${Date.now()}`), true) }
    ]
  });
}

function renderView() {
  readDailyProgress();
  maybeRecordRatedGame();
  maybeArchiveCompletedGame();
  document.body.classList.toggle('play-screen-active', currentView === 'play');
  document.body.classList.toggle('match-setup-active', currentView === 'play' && !gameStarted);
  document.body.classList.toggle('home-screen-active', currentView === 'home');
  document.body.classList.toggle('review-screen-active', currentView === 'review');
  $$('.tab').forEach(tab => tab.classList.toggle('active', tab.dataset.view === currentView));
  const root = $('#mainView');
  if (!root) return;
  if (currentView === 'home') root.innerHTML = renderHomeView();
  else if (currentView === 'play') root.innerHTML = renderPlayView();
  else if (currentView === 'ranked') root.innerHTML = renderRankedView();
  else if (currentView === 'puzzles') root.innerHTML = renderPuzzleView();
  else if (currentView === 'openings') root.innerHTML = renderOpeningsView();
  else if (currentView === 'coach') root.innerHTML = renderCoachView();
  else if (currentView === 'arena') root.innerHTML = renderArenaView();
  else if (currentView === 'games') root.innerHTML = renderGamesView();
  else if (currentView === 'lichess') root.innerHTML = renderLichessView();
  else if (currentView === 'leaderboard') root.innerHTML = renderLeaderboardView();
  else if (currentView === 'friends') root.innerHTML = renderFriendsView();
  else if (currentView === 'inbox') root.innerHTML = renderInboxView();
  else if (currentView === 'health') root.innerHTML = renderSystemHealthView();
  else if (currentView === 'missions') root.innerHTML = renderMissionsView();
  else if (currentView === 'shop') root.innerHTML = renderShopView();
  else if (currentView === 'admin') root.innerHTML = renderAdminView();
  else if (currentView === 'history') root.innerHTML = renderHistoryView();
  else if (currentView === 'review') root.innerHTML = renderReviewView();
  else root.innerHTML = renderSettingsView();
  wireCommonActions();
  if (currentView === 'home') wireHomeActions();
  if (currentView === 'ranked') wireRankedActions();
  if (currentView === 'puzzles') wirePuzzleActions();
  if (currentView === 'friends') wireFriendsActions();
  if (currentView === 'inbox') wireInboxActions();
  if (currentView === 'health') wireSystemHealthActions();
  if (currentView === 'missions') wireMissionsActions();
  if (currentView === 'shop') wireShopActions();
  if (currentView === 'leaderboard') wireLeaderboardActions();
  if (currentView === 'admin') wireAdminActions();
  if (currentView === 'play') {
    renderBoard();
    watchBoardLayout();
    wirePlayActions();
    renderAnalysisPanel(); // Re-sync hidden/busy state after returning from another view.
  } else {
    boardResizeObserver?.disconnect();
    boardResizeObserver = null;
  }
  if (currentView === 'openings') wireOpeningActions();
  if (currentView === 'review') wireReviewActions();
  if (currentView === 'coach') wireCoachActions();
  if (currentView === 'arena') { renderArenaPosition(); wireArenaActions(); syncArenaCupPodium(); }
  if (currentView === 'games') wireGamesActions();
  if (currentView === 'lichess') wireLichessActions();
  if (currentView === 'settings') wireSettingsActions();
  if (currentView === 'history') wireHistoryActions();
  syncRankedTimers();
  maybeShowPlayResultModal();
  maybeShowRankedResultModal();
}
function renderExperienceChoiceMarkup() {
  if (experienceLevel === 'beginner') return '<small class="experience-selected-label">Đang chọn: người mới chơi</small>';
  if (experienceLevel === 'experienced') return '<small class="experience-selected-label">Đang chọn: đã hiểu luật</small>';
  return '<div class="experience-choice"><button type="button" class="secondary-btn" data-experience-choice="beginner">Mới chơi</button><button type="button" class="secondary-btn" data-experience-choice="experienced">Đã hiểu luật</button></div>';
}
function renderPrestartExperiencePanel() {
  if (gameStarted) return '';
  const title = experienceLevel === 'beginner' ? 'Lộ trình người mới' : experienceLevel === 'experienced' ? 'Đã hiểu luật cờ vua' : 'Bạn mới chơi hay đã biết luật?';
  const description = experienceLevel === 'beginner'
    ? 'Bot khởi đầu nhẹ hơn, thời gian Rapid 10 phút và có gợi ý khi cần.'
    : experienceLevel === 'experienced'
      ? 'Bạn có thể tùy chỉnh thời gian, màu quân, sức mạnh bot và phân tích.'
      : 'Chọn lộ trình phù hợp để ViLa đặt sẵn trải nghiệm ban đầu.';
  return `<section class="prestart-experience-card" aria-label="Chọn kinh nghiệm cờ vua"><div class="prestart-experience-icon" aria-hidden="true">♟</div><div class="prestart-experience-copy"><b>${title}</b><small>${description}</small>${renderExperienceChoiceMarkup()}</div>${experienceLevel ? '<button type="button" id="changeExperience" class="tiny-btn prestart-experience-change">Đổi</button>' : ''}</section>`;
}
function renderMatchSetupView() {
  const selectedProfile = OFFLINE_ENGINE_CATALOG.find(item => item.id === settings.alternativeEngine) || OFFLINE_ENGINE_CATALOG[0];
  const eloOptions = [...new Set([...Array.from({ length: 28 }, (_, i) => 500 + i * 100), 3200, ...(Number(settings.botElo) % 100 === 0 ? [] : [Number(settings.botElo)])])].sort((a, b) => a - b);
  return `<section class="play-setup-screen" aria-labelledby="matchSetupTitle">
    <header class="match-setup-heading"><span class="match-setup-emblem" aria-hidden="true">♟</span><div><small class="eyebrow">VILA CHESS · NEW MATCH</small><h1 id="matchSetupTitle">Thiết lập trận đấu</h1><p>Chọn đối thủ, màu quân và thời gian. Bàn cờ sẽ xuất hiện khi bạn bắt đầu.</p></div></header>
    <section class="panel match-setup-card">
      <div class="panel-heading"><div><small class="eyebrow">TRẬN ĐẤU MỚI</small><h2>Thiết lập của bạn</h2></div><span class="match-setup-ready"><i></i> Chưa bắt đầu</span></div>
      <div class="match-setup-grid">
        <div class="match-setup-field match-setup-wide"><label class="field-label" for="modeSelect">1 · Chọn chế độ chơi</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish 19 Lite — đối thủ mạnh</option><option value="stockfish-beginner" ${mode === 'stockfish-beginner' ? 'selected' : ''}>Stockfish — luyện người mới (500 Elo mục tiêu)</option><option value="vila" ${mode === 'vila' ? 'selected' : ''}>ViLa Classic — bot ngoại tuyến</option><option value="enginehub" ${mode === 'enginehub' ? 'selected' : ''}>AI đa phong cách — ngoại tuyến</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess — chơi trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người chơi trên cùng máy</option></select></div>
        <div class="match-setup-field"><label class="field-label" for="gameBotProfile">2 · Phong cách bot</label><select id="gameBotProfile" class="field" ${mode === 'local' || mode === 'lichess' ? 'disabled' : ''}>${OFFLINE_ENGINE_CATALOG.map(item => `<option value="${item.id}" ${settings.alternativeEngine === item.id ? 'selected' : ''}>${esc(item.label)}</option>`).join('')}</select><small class="field-hint">${esc(selectedProfile.hint)}.</small></div>
        <div class="match-setup-field"><label class="field-label" for="colorSelect">3 · Bạn cầm quân</label><select id="colorSelect" class="field" ${mode === 'lichess' ? 'disabled' : ''}><option value="random" ${colorChoice === 'random' ? 'selected' : ''}>🎲 Ngẫu nhiên</option><option value="w" ${colorChoice === 'w' ? 'selected' : ''}>Trắng — đi trước</option><option value="b" ${colorChoice === 'b' ? 'selected' : ''}>Đen — bot đi trước</option></select></div>
        <div class="match-setup-field"><label class="field-label" for="skillSelect">4 · Sức mạnh bot</label><select id="skillSelect" class="field" ${mode === 'local' || mode === 'lichess' ? 'disabled' : ''}><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất — không giới hạn</option>${eloOptions.map(n => `<option value="${n}" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === n ? 'selected' : ''}>Elo ${n}${n === 3200 ? ' · mức cao nhất' : ''}</option>`).join('')}</select><button type="button" id="randomBotElo" class="text-btn random-elo-btn" aria-pressed="${randomBotEloEnabled}">🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}</button></div>
        <div class="match-setup-field"><label class="field-label" for="clockPreset">5 · Thời gian mỗi bên</label><select id="clockPreset" class="field">${CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${settings.clockPreset === preset.value ? 'selected' : ''}>${preset.label}</option>`).join('')}</select></div>
      </div>
      <div class="match-setup-time-shortcuts" role="group" aria-label="Chọn nhanh thời gian"><span>CHỌN NHANH</span>${[['1+0','Bullet'],['3+2','Blitz'],['10+0','Rapid'],['15+10','Classical']].map(([value,label]) => `<button type="button" data-time-preset="${value}" class="time-preset-chip ${settings.clockPreset === value ? 'is-active' : ''}"><b>${value}</b><small>${label}</small></button>`).join('')}</div>
      <div class="match-setup-note"><span aria-hidden="true">ℹ</span><p>Chế độ bot chạy trên thiết bị. Mức Elo là giới hạn luyện tập ước lượng, không phải xếp hạng đã đo.</p></div>
      <button id="startGameOverlay" type="button" class="primary-btn full-width match-start-button"><span aria-hidden="true">♟</span> Bắt đầu trận <span aria-hidden="true">→</span></button>
      <p class="match-setup-footnote">Chỉ sau khi bấm bắt đầu, bàn cờ và các nút trong trận mới hiện ra.</p>
    </section>
  </section>`;
}
function renderPlayView() {
  if (!gameStarted) return renderMatchSetupView();
  const setupOpen = false;
  const modeLabel = ['stockfish', 'stockfish-beginner'].includes(mode) ? 'Stockfish' : mode === 'vila' ? 'ViLa Classic · ngoại tuyến' : mode === 'enginehub' ? 'AI nhiều phong cách · ngoại tuyến' : mode === 'lichess' ? 'Lichess trực tuyến' : 'Hai người chơi';
  const clockFace = color => `<div class="clock-player-block"><div class="clock-face ${color === humanColor ? 'user-clock' : 'opponent-clock'}"><span id="clock${color === 'w' ? 'White' : 'Black'}Name">${esc(clockPlayerName(color))}</span><strong id="clock${color === 'w' ? 'White' : 'Black'}">${clockState.enabled ? formatClockTime(clockState.remaining[color]) : (mode === 'lichess' ? 'Lichess' : '∞')}</strong></div>${renderCapturedMaterial(color)}</div>`;
  const topClockColor = humanColor === 'w' ? 'b' : 'w';
  const bottomClockColor = humanColor === 'w' ? 'w' : 'b';
  return `<section class="play-view-shell">
    <header class="play-room-heading"><div class="play-room-title"><div class="play-breadcrumb">CỜ VUA VILA <span>/</span> PHÒNG ĐẤU</div><h1>Phòng đấu</h1><p>Bàn cờ, đồng hồ, nước đi và công cụ phân tích được gom trong cùng màn hình.</p></div><div class="play-room-actions"><span class="play-book-chip"><b id="playOpeningCount">${OPENINGS.length.toLocaleString()}</b><small>khai cuộc</small></span><details class="play-tools-menu"><summary aria-label="Mở công cụ phòng đấu">☷ Công cụ</summary><div class="play-tools-menu-panel"><button type="button" class="secondary-btn" id="gameShowSetup">⚙ Thiết lập trận</button><button type="button" class="secondary-btn" id="gameShowMoves">↶ Danh sách nước</button><button type="button" class="secondary-btn" id="gameShowAnalysis">✦ Phân tích</button><button type="button" class="secondary-btn" id="gameShowOpening">⌘ Khai cuộc</button></div></details></div></header>
    ${renderPrestartExperiencePanel()}
    <div class="mobile-time-presets" role="group" aria-label="Chọn nhanh thời gian cho ván mới"><span class="time-preset-heading">THỜI GIAN</span><button type="button" data-time-preset="0.5+0" class="time-preset-chip ${settings.clockPreset === '0.5+0' ? 'is-active' : ''}"><b>30 giây</b><small>Siêu chớp</small></button><button type="button" data-time-preset="1+0" class="time-preset-chip ${settings.clockPreset === '1+0' ? 'is-active' : ''}"><b>1+0</b><small>Bullet</small></button><button type="button" data-time-preset="3+2" class="time-preset-chip ${settings.clockPreset === '3+2' ? 'is-active' : ''}"><b>3+2</b><small>Blitz</small></button><button type="button" data-time-preset="10+0" class="time-preset-chip ${settings.clockPreset === '10+0' ? 'is-active' : ''}"><b>10+0</b><small>Rapid</small></button></div>
    <nav class="play-tool-rail" aria-label="Chức năng cờ vua">
      <button type="button" class="play-tool-button is-active" data-play-rail-view="play" aria-current="page"><span aria-hidden="true">♟</span><small>Chơi</small></button>
      <button type="button" class="play-tool-button" data-play-rail-view="arena"><span aria-hidden="true">♟♟</span><small>Bot</small></button>
      <button type="button" class="play-tool-button" data-play-rail-view="puzzles"><span aria-hidden="true">✦</span><small>Câu đố</small></button>
      <button type="button" class="play-tool-button" data-play-rail-view="history"><span aria-hidden="true">◷</span><small>Lịch sử</small></button>
      <button type="button" class="play-tool-button" data-play-rail-view="coach"><span aria-hidden="true">⌁</span><small>Phân tích</small></button>
      <button type="button" class="play-tool-button" data-play-rail-view="openings"><span aria-hidden="true">▤</span><small>Mở đầu</small></button>
      <button type="button" class="play-tool-button" data-play-rail-view="settings"><span aria-hidden="true">•••</span><small>Thêm</small></button>
    </nav>
    <section class="play-layout">
    <div class="board-column">
      <section class="player-card player-card-opponent"><div class="opponent-line"><div class="avatar">${mode === 'local' ? '♙' : mode === 'vila' ? '♞' : mode === 'enginehub' ? '⚙' : mode === 'lichess' ? '↗' : '♞'}</div><div class="opponent-meta"><b>${mode === 'local' ? 'Người chơi Đen / Trắng' : mode === 'vila' ? 'ViLa Classic · AI cục bộ' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : mode === 'lichess' ? `Lichess · ${esc(activeOnlineGame?.opponent || 'đối thủ trực tuyến')}` : 'Stockfish'}</b><small>${modeLabel} · ${mode === 'stockfish' ? `Skill ${settings.botSkill}/20` : mode === 'enginehub' ? `AI cục bộ · ${esc(settings.alternativeEngine)} · không cần backend` : mode === 'vila' ? 'Chạy trên điện thoại · không cần backend' : mode === 'lichess' ? `Ván ${esc(activeOnlineGame?.id || '')}` : 'Cùng thiết bị'}</small></div>${!gameStarted ? `<button id="startGameOverlay" type="button" class="primary-btn prestart-top-cta">▶ Bắt đầu</button>` : '<span id="turnChip" class="turn-chip">Lượt Trắng</span>'}</div>
      <div class="clock-face-row">${clockFace(topClockColor)}<label class="clock-setting-inline" for="clockPreset">Thời gian<select id="clockPreset" class="field">${CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${settings.clockPreset === preset.value ? 'selected' : ''}>${preset.label}</option>`).join('')}</select></label></div></section>
      <div class="board-frame"><div class="board-surface"><div id="board" class="chessboard" role="grid" aria-label="Bàn cờ vua"></div><svg id="boardArrows" class="board-arrows" viewBox="0 0 8 8" preserveAspectRatio="none" aria-hidden="true"><defs><marker id="hintArrowHead" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadGreen" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadRed" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadYellow" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker></defs><g id="manualAnnotationLines"></g><g id="hintArrowLine"></g></svg></div></div><div class="board-annotation-toolbar-row"><div id="boardAnnotationWidget" class="board-annotation-widget ${annotationCollapsed ? 'is-collapsed' : ''}" ${!gameStarted || !['stockfish','vila','enginehub'].includes(mode) ? 'hidden' : ''} aria-label="Công cụ vẽ phân tích"><button type="button" id="annotationWidgetToggle" class="annotation-widget-toggle" title="Thu gọn / mở công cụ" aria-expanded="${!annotationCollapsed}">✎</button><div id="boardAnnotationTools" class="board-annotation-tools" ${annotationCollapsed ? 'hidden' : ''}><button type="button" data-annotation-tool="arrow" title="Kéo để vẽ mũi tên" aria-label="Vẽ mũi tên" aria-pressed="${annotationTool === 'arrow'}">↗</button><button type="button" data-annotation-tool="circle" title="Khoanh ô" aria-label="Khoanh ô" aria-pressed="${annotationTool === 'circle'}">◯</button><button type="button" id="annotationColorCycle" class="annotation-color-cycle color-green" title="Đổi màu nét" aria-label="Màu nét: xanh lá">●</button><button type="button" id="annotationClear" title="Xóa dấu vẽ" aria-label="Xóa dấu vẽ">⌫</button></div></div></div><div class="evaluation-meter-row" aria-label="Thanh đánh giá thế cờ"><span>TRẮNG</span><div id="evaluationMeter" class="evaluation-meter" role="img" aria-label="Lợi thế ước tính của Trắng"><span id="evaluationMeterWhite"></span></div><span>ĐEN</span></div>
      <section class="player-card player-card-self"><div class="opponent-line self-opponent-line"><div class="avatar">♙</div><div class="opponent-meta"><b>Bạn</b><small>Người chơi · ${Number(readRatingProfile().elo || 1200)} Elo</small></div><span class="player-online-dot" aria-label="Trên thiết bị"></span></div><div class="clock-face-row clock-bottom-row">${clockFace(bottomClockColor)}<small id="clockHint" class="clock-hint">${clockState.enabled ? `+${Math.round(clockState.incrementMs / 1000)} giây/nước` : 'Không giới hạn'}</small></div></section>
      <div class="engine-speed-row">${engineSpeedChipMarkup()}</div><div class="board-bottom"><span id="boardStatus">Trắng đang đi</span><div class="board-bottom-actions"><button id="flipBoard" class="text-btn">⇅ Đảo bàn</button><button id="toggleChessMusic" class="text-btn" type="button" title="Bật/tắt nhạc cờ vua">🎧 Nhạc</button><button id="offerDrawBtn" class="text-btn draw-btn" type="button" title="Xin hòa ván đấu" ${!gameStarted || game.isGameOver() || clockFlagged || manualGameResult ? 'disabled' : ''}>½ Xin hòa</button><button id="resignBtn" class="text-btn resign-btn" type="button" ${!gameStarted || game.isGameOver() || clockFlagged || manualGameResult ? 'disabled' : ''}>⚑ Đầu hàng</button><button id="restartGameBtn" class="text-btn restart-btn" type="button" title="Chơi lại ván đấu">↺ Chơi lại</button></div></div>
      <div class="analysis-action-row"><button id="analyzePosition" class="secondary-btn">♙ Phân tích 3 biến</button><small>Stockfish · PV × 3</small></div>
      <section id="analysisPanel" class="analysis-panel" ${analysisVisible || analysisActive || analysisVariants.length ? '' : 'hidden'} aria-live="polite"><div class="analysis-panel-heading"><b>Phân tích Stockfish</b><span>MultiPV 3 · điểm theo Trắng</span></div><div id="analysisLines" class="analysis-lines"><div class="analysis-empty">Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.</div></div></section>

      <div class="mobile-action-row match-action-bar" aria-label="Thao tác ván cờ"><button class="secondary-btn" id="undoMove" aria-label="Hoàn tác nước đi" title="Hoàn tác"><span aria-hidden="true">↶</span><small>Hoàn tác</small></button><button class="secondary-btn" id="redoMove" aria-label="Làm lại nước đi" title="Làm lại" ${redoStack.length ? '' : 'disabled'}><span aria-hidden="true">↷</span><small>Làm lại</small></button><button class="secondary-btn" id="hintMove" aria-label="Gợi ý nước đi"><span aria-hidden="true">✦</span><small>Gợi ý</small></button><button class="secondary-btn" id="clearBoardSelection" aria-label="Hủy nước đi đang chọn"><span aria-hidden="true">×</span><small>Hủy chọn</small></button><button class="primary-btn" id="newGame" aria-label="Bắt đầu ván mới"><span aria-hidden="true">▶</span><small>Ván mới</small></button></div>
    </div>
    <aside class="side-column">
      <details class="panel game-setup" id="gameSetupPanel" ${setupOpen ? 'open' : ''}><summary class="game-setup-summary"><span><small class="eyebrow">VÁN CỜ</small><strong>Thiết lập trận</strong><small class="game-setup-subtitle">Chế độ · màu quân · sức mạnh bot</small></span><span class="setup-chevron" aria-hidden="true">⌄</span></summary><div class="game-setup-body">
<label class="field-label" for="modeSelect">Chế độ chơi / đối thủ</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish — chơi với máy</option><option value="vila" ${mode === 'vila' ? 'selected' : ''}>ViLa Classic — AI ngoại tuyến, không phải Stockfish</option><option value="enginehub" ${mode === 'enginehub' ? 'selected' : ''}>AI đa phong cách — offline, không cần backend</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người trên cùng máy</option></select><p class="field-hint engine-choice-note">Stockfish 19: engine chuyên dụng chạy trong app. Bot phong cách có kho khai cuộc riêng; khi Stockfish sẵn sàng, chúng dùng tìm kiếm Stockfish và chọn biến thể theo cá tính. Đây là profile VILA, không phải binary gốc Lc0/Ethereal/Berserk. Lichess là chế độ online tùy chọn.</p>
        <label class="field-label" for="gameBotProfile">Chọn đối thủ / phong cách bot</label><select id="gameBotProfile" class="field">${OFFLINE_ENGINE_CATALOG.map(item => `<option value="${item.id}" ${settings.alternativeEngine === item.id ? 'selected' : ''}>${esc(item.label)} · ${esc(item.hint)}</option>`).join('')}</select><p class="field-hint">Các phong cách là profile huấn luyện VILA trên engine tìm kiếm cục bộ; không phải 18 mạng neural độc lập hay Elo đã đo.</p>
        <div class="two-fields"><div><label class="field-label" for="colorSelect">Bạn cầm quân</label><select id="colorSelect" class="field" ${mode === 'lichess' ? 'disabled' : ''}><option value="random" ${colorChoice === 'random' ? 'selected' : ''}>🎲 Ngẫu nhiên Trắng / Đen (mặc định)</option><option value="w" ${colorChoice === 'w' ? 'selected' : ''}>Trắng</option><option value="b" ${colorChoice === 'b' ? 'selected' : ''}>Đen</option></select></div><div><label class="field-label" for="skillSelect">Sức mạnh bot (Elo 500–3200)</label><select id="skillSelect" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất · không giới hạn Elo</option>${[...new Set([...Array.from({ length: 28 }, (_, i) => 500 + i * 100), 3200, ...(Number(settings.botElo) % 100 === 0 ? [] : [Number(settings.botElo)])])].sort((a,b)=>a-b).map(n => `<option value="${n}" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === n ? 'selected' : ''}>Elo ${n}${n === 3200 ? ' · mức cao nhất' : ''}</option>`).join('')}</select><button type="button" id="randomBotElo" class="text-btn random-elo-btn" aria-pressed="${randomBotEloEnabled}">🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}</button></div></div>
        <button id="newGameSetup" class="primary-btn full-width">Bắt đầu ván mới <span>→</span></button>
        <div class="stats-row"><div><small>Đánh giá</small><b id="evalNumber">—</b></div><div><small>Số nước</small><b id="gameMoveCount">${game.history().length}</b></div><div><small>Trạng thái</small><b id="gameStatusText" class="status-text">${!gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged) ? 'Kết thúc' : 'Đang chơi'}</b></div></div>
      </div></details>
      <section class="panel moves-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ</small><h2>Nước đi</h2></div><div class="panel-icons"><button class="tiny-btn" id="copyPGN" title="Sao chép PGN">⧉</button><button class="tiny-btn" id="downloadPGN" title="Tải PGN">↓</button></div></div><div id="moveList" class="move-list"></div></section>
      <section class="panel quick-tools"><h3>Phân tích nhanh</h3><div class="tool-grid"><button id="explainPosition" class="tool-btn"><span>✦</span><b>Phân tích thế cờ</b><small>Stockfish · biến thể thật</small></button><button id="queryExplorer" class="tool-btn"><span>⌘</span><b>Khai cuộc</b><small>Dữ liệu Lichess</small></button></div><div id="explorerResult" class="explorer-result"></div></section>
    </aside>
    </section>
  </section>`;
}
function renderOpeningsView() {
  return `<section class="content-page openings-page"><div class="page-intro openings-intro"><div class="eyebrow">CỜ VUA VILA · OPENING EXPLORER</div><h1>Thư viện khai cuộc</h1><p>Tìm theo tên, mã ECO hoặc nước đi; phát lại cả biến khai cuộc trên bàn cờ. Khi build có mạng, VILA đóng gói thêm cơ sở dữ liệu ECO mở rộng, còn kho mẫu vẫn hoạt động khi ngoại tuyến.</p><div class="opening-library-stats"><strong id="openingCount">${OPENINGS.length} đường khai cuộc</strong><span>Đã lọc theo biến hợp lệ</span><span class="opening-source-chip">ECO · Lichess CC0</span></div></div>
    <div class="opening-toolbar"><label class="opening-search-wrap"><span aria-hidden="true">⌕</span><input id="openingSearch" class="field search-field" placeholder="Tìm tên khai cuộc, mã ECO…" aria-label="Tìm khai cuộc"/></label><select id="openingFilter" class="field" aria-label="Lọc hệ thống"><option value="all">Tất cả hệ thống</option><option value="Mở e4">Khai cuộc 1.e4</option><option value="Mở d4">Khai cuộc 1.d4</option><option value="Phòng thủ">Phòng thủ</option><option value="Tấn công">Tấn công</option><option value="Mở c4">Khai cuộc 1.c4 / linh hoạt</option></select></div>
    <div id="openingGrid" class="opening-grid">${renderOpeningCards()}</div>
    <div class="note-banner opening-note"><span>✦</span><div><b>Kho mẫu + ECO mở rộng</b><p>Chọn “Xem biến” để kiểm tra toàn bộ nước trên bàn tạm trước khi thay ván hiện tại. AI chọn nước trong các nhánh có tiền tố khớp lịch sử ván; hết kho hoặc rời biến thì Stockfish tiếp quản. Dữ liệu khai cuộc là tài liệu tham khảo, không cam kết mọi biến đều là lựa chọn chiến thuật tốt nhất.</p></div></div>
  </section>`;
}
function renderOpeningCards(filter = '', family = 'all', limit = openingPageLimit) {
  const query = String(filter || '').trim().toLocaleLowerCase();
  const filtered = OPENINGS.filter(o => (family === 'all' || o.family === family) && `${o.name} ${o.eco} ${o.note} ${o.line}`.toLocaleLowerCase().includes(query));
  const visible = filtered.slice(0, Math.max(1, Number(limit) || 48));
  const cards = visible.map(o => `<article class="opening-card"><div class="opening-card-top"><span class="eco-tag">${esc(o.eco)}</span><span class="family-tag">${esc(o.family)}</span></div><h3>${esc(o.name)}</h3><p>${esc(o.note)}</p><div class="opening-line">${esc(o.line)}</div><div class="opening-card-bottom"><span>${o.san.length} nửa nước đi</span><button class="mini-primary" data-load-opening="${OPENINGS.indexOf(o)}">Xem biến ↗</button></div></article>`).join('');
  const more = filtered.length > visible.length ? `<div class="opening-load-more-wrap"><span>Đang hiện ${visible.length} / ${filtered.length} khai cuộc</span><button id="loadMoreOpenings" type="button" class="secondary-btn">Tải thêm 48 biến ↓</button></div>` : `<div class="opening-load-more-wrap"><span>Hiển thị ${visible.length} / ${filtered.length} khai cuộc</span></div>`;
  return `${cards || '<div class="empty-state">Không tìm thấy khai cuộc phù hợp.</div>'}${more}`;
}
function renderCoachView() {
  const moveCount = game.history().length;
  const opening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
  return `<section class="content-page coach-page offline-coach-page">
    <div class="page-intro"><div class="eyebrow">OFFLINE ANALYSIS LAB</div><h1>Phân tích & huấn luyện</h1><p>Công cụ cờ vua chạy cục bộ: Stockfish tính biến thể, bộ xem lại chấm từng nước, kho khai cuộc và câu đố theo tiến trình. Không cần API key hoặc chatbot ngoài.</p></div>
    <div class="coach-layout offline-tools-grid">
      <section class="panel coach-context"><div class="panel-heading"><div><small class="eyebrow">THẾ CỜ HIỆN TẠI</small><h2>Vị trí đang chơi</h2></div><span class="context-icon">♞</span></div>
        <div class="context-stat"><span>FEN</span><code>${esc(game.fen())}</code><button id="copyFen" class="tiny-btn" type="button" aria-label="Sao chép FEN">⧉</button></div>
        <div class="context-stat"><span>PGN</span><code class="truncate-code">${esc(game.pgn() || 'Chưa có nước đi')}</code><button id="copyPgnCoach" class="tiny-btn" type="button" aria-label="Sao chép PGN">⧉</button></div>
        <div class="ranked-stat-grid"><div class="ranked-stat"><small>Số nửa nước</small><b>${moveCount}</b></div><div class="ranked-stat"><small>Khai cuộc</small><b>${esc(opening?.eco || '—')}</b></div><div class="ranked-stat"><small>Engine</small><b>${engineReady && !engineFailed ? 'Sẵn sàng' : 'Đang tải'}</b></div></div>
        <p class="field-hint">${esc(opening?.name || (moveCount < 5 ? 'Khai cuộc sẽ được nhận diện sau vài nước.' : 'Chưa nhận diện được biến khai cuộc trong kho hiện có.'))}</p>
      </section>
      <section class="panel offline-analysis-actions"><div class="panel-heading"><div><small class="eyebrow">CÔNG CỤ THỰC CHIẾN</small><h2>Phân tích nước đi</h2></div><span class="context-icon">⌘</span></div>
        <button id="coachAnalyzePosition" class="primary-btn full-width" type="button">♙ Phân tích 3 biến bằng Stockfish</button>
        <button id="coachReviewGame" class="secondary-btn full-width" type="button">↶ Xem lại & đánh giá toàn ván</button>
        <button id="coachOpenPuzzles" class="secondary-btn full-width" type="button">🧩 Luyện câu đố từ dễ đến khó</button>
        <button id="coachOpenOpenings" class="secondary-btn full-width" type="button">⌘ Học kho khai cuộc</button>
        <p class="field-hint">Phân tích dùng engine cờ; phần nhận xét dựa trên đánh giá nước đi và biến UCI, không giả vờ là lời giải của chatbot.</p>
      </section>
    </div>
  </section>`;
}
function renderLichessView() {
  const token = activeLichessToken || safeSessionGet(lichessTokenKey) || '';
  const activeLichessUrl = activeOnlineGame ? safeLichessUrl(activeOnlineGame.url, activeOnlineGame.id) : 'https://lichess.org/';
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">CHƠI TRỰC TUYẾN</div><h1>Kết nối Lichess</h1><p>Kết nối tài khoản bằng Personal Access Token. Token chỉ giữ trong phiên trình duyệt và được gửi tới backend đã cấu hình; không đưa token lên GitHub. Bot API cần tài khoản đã được nâng cấp thành Bot và đúng scope.</p></div>
    <div class="lichess-layout"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Kết nối Lichess.org</h2></div><div class="lichess-logo">♞</div></div><label class="field-label" for="lichessToken">Personal Access Token</label><input id="lichessToken" type="password" autocomplete="off" class="field" placeholder="Dán token có quyền phù hợp" value="${esc(token)}"/><div class="field-hint">Dùng quyền cần thiết cho cách chơi bạn muốn: đọc tài khoản và chơi ván cờ. Không dán token vào nơi công khai.</div><label class="field-label" for="lichessApiMode">Kiểu API chơi ván</label><select id="lichessApiMode" class="field"><option value="board">Tài khoản thông thường (Board API)</option><option value="bot">Tài khoản Lichess Bot (Bot API)</option></select><div class="field-hint">Chọn Bot API chỉ khi tài khoản đã được nâng cấp thành bot; tài khoản thường dùng Board API.</div><div class="button-row"><button id="connectLichess" class="primary-btn">Kiểm tra kết nối</button><button id="forgetLichess" class="secondary-btn">Xóa token</button></div><div id="lichessAccountResult" class="connection-result">${token ? 'Token đang lưu tạm trong phiên này; hãy kiểm tra kết nối.' : 'Chưa kết nối tài khoản.'}</div><div class="form-divider"></div><h3>Thử đấu AI của Lichess</h3><div class="two-fields"><div><label class="field-label" for="lichessLevel">Độ khó AI (1–8)</label><select id="lichessLevel" class="field">${[1,2,3,4,5,6,7,8].map(n=>`<option value="${n}" ${n===3?'selected':''}>Cấp ${n}</option>`).join('')}</select></div><div><label class="field-label" for="lichessClock">Thời gian (giây)</label><select id="lichessClock" class="field"><option value="60">1 phút</option><option value="180">3 phút</option><option value="300" selected>5 phút</option><option value="600">10 phút</option><option value="0">Không giới hạn</option></select></div></div><button id="challengeLichessAI" class="primary-btn full-width">Tạo ván với AI Lichess ↗</button><div class="form-divider"></div><h3>Thách đấu người chơi</h3><label class="field-label" for="lichessUsername">Tên người chơi Lichess</label><input id="lichessUsername" class="field" placeholder="Ví dụ: username"/><button id="challengeLichessUser" class="secondary-btn full-width">Gửi lời mời đấu ↗</button><div id="lichessChallengeResult" class="connection-result"></div></section>
    <section class="panel lichess-info"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI THỰC TẾ</small><h2>Trạng thái & hướng dẫn</h2></div><span class="online-indicator"></span></div><div class="info-row"><span class="info-icon">✓</span><div><b>Dữ liệu khai cuộc</b><p>Tra thống kê nước đi trong tab Khai cuộc qua Lichess Opening Explorer; không cần token cho truy vấn công khai.</p></div></div><div class="info-row"><span class="info-icon">↗</span><div><b>Ván trực tuyến</b><p>Sau khi gửi thử thách, mở trang ván trên Lichess để chấp nhận/chơi. Đồng bộ nước đi trong ứng dụng cần token, đúng API scope và backend có thể truy cập Lichess.</p></div></div><div class="info-row"><span class="info-icon">!</span><div><b>Bot Lichess không giống AI Stockfish nội bộ</b><p>API Bot chỉ hoạt động với tài khoản bot đủ điều kiện. Không dùng tài khoản thường để tự động hóa qua Bot API.</p></div></div><a class="external-link" href="https://lichess.org/account/oauth/token" target="_blank" rel="noopener noreferrer">Mở trang quản lý token ↗</a><a class="external-link" href="https://lichess-org.github.io/api/" target="_blank" rel="noopener noreferrer">Tài liệu API chính thức ↗</a><div id="lichessActiveGame" class="active-game-card">${activeOnlineGame ? `Ván vừa tạo: <b>${esc(activeOnlineGame.id || '')}</b><br><a href="${esc(activeLichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a><br><button id="playLichessHere" class="mini-primary">Kết nối ván trong Cờ Vua ViLa</button>` : 'Chưa tạo ván nào trong phiên này.'}</div></section></div>
    </section>
  </section>`;
}
function renderSettingsView() {
  return `<section class="content-page settings-page offline-settings-page">
    <div class="page-intro"><div class="eyebrow">CỜ VUA VILA · THIẾT LẬP CỤC BỘ</div><h1>Engine & giao diện</h1><p>Thiết lập engine cờ, thời gian suy nghĩ, kho khai cuộc và giao diện. Chỉ có engine cờ và tùy chọn giao diện. Bot, khai cuộc, câu đố và xem lại ván chạy cục bộ khi đã tải đủ tài nguyên.</p></div>
    <div class="settings-layout">
      <section class="panel settings-panel"><div class="panel-heading"><div><small class="eyebrow">STOCKFISH ENGINE</small><h2>Sức mạnh & hiệu năng</h2></div><span class="context-icon">♞</span></div>
        <label class="field-label" for="botEngineSetting">Bản Stockfish</label><select id="botEngineSetting" class="field"><option value="auto" ${!['lite-single','full-single','sf10'].includes(settings.botEngine) ? 'selected' : ''}>Tự động · ưu tiên tương thích Android</option><option value="lite-single" ${settings.botEngine === 'lite-single' ? 'selected' : ''}>Stockfish 19 Lite · nhẹ cho máy yếu</option><option value="full-single" ${settings.botEngine === 'full-single' ? 'selected' : ''}>Stockfish 19 Full NNUE · mạnh hơn, cần thêm bộ nhớ</option><option value="sf10" ${settings.botEngine === 'sf10' ? 'selected' : ''}>Stockfish 10 · cổ điển (tối đa 0,5 giây/nước)</option></select>
        <div class="two-fields"><div><label class="field-label" for="botSkillSetting">Skill (0–20)</label><input id="botSkillSetting" type="number" class="field" min="0" max="20" value="${Number(settings.botSkill)}"/></div><div><label class="field-label" for="botDepthSetting">Độ sâu tối đa</label><input id="botDepthSetting" type="number" class="field" min="5" max="30" value="${Number(settings.botDepth)}"/></div></div>
        <div class="two-fields"><div><label class="field-label" for="botMoveTimeSetting">Thời gian/nước (ms)</label><input id="botMoveTimeSetting" type="number" class="field" min="500" max="5000" step="100" value="${Number(settings.botMoveTimeMs)}"/></div><div><label class="field-label" for="analysisMoveTimeSetting">Phân tích/nước (ms)</label><input id="analysisMoveTimeSetting" type="number" class="field" min="1000" max="8000" step="100" value="${Number(settings.analysisMoveTimeMs)}"/></div></div>
        <label class="field-label" for="reviewQualitySetting">Mức phân tích ván (Stockfish 19)</label><select id="reviewQualitySetting" class="field"><option value="max" ${settings.reviewQuality === 'max' ? 'selected' : ''}>Cao nhất — 8 giây/nước, 2 biến, nhận diện Thiên tài/Tuyệt vời</option><option value="deep" ${settings.reviewQuality === 'deep' ? 'selected' : ''}>Sâu — 3–6 giây/nước</option><option value="standard" ${settings.reviewQuality === 'standard' ? 'selected' : ''}>Chuẩn — nhanh hơn, ít nhãn đặc biệt</option></select><div class="field-hint">Mức cao nhất mất vài phút cho một ván dài; có thể dừng bất cứ lúc nào, kết quả đã có vẫn giữ.</div>
        <div class="two-fields"><div><label class="field-label" for="botStrengthModeSetting">Sức mạnh</label><select id="botStrengthModeSetting" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Tối đa</option><option value="elo" ${settings.botStrengthMode === 'elo' ? 'selected' : ''}>Giới hạn ước lượng</option></select></div><div><label class="field-label" for="botEloSetting">Mức Elo luyện tập (ước lượng)</label><input id="botEloSetting" type="number" class="field" min="500" max="3200" step="10" value="${Number(settings.botElo || 2600)}"/></div></div>
        <p class="field-hint">Mức Elo ở đây chỉ giới hạn sức mạnh theo tùy chọn UCI của Stockfish hoặc mô phỏng mức thấp; đây không phải Elo được benchmark hay chứng nhận. Muốn tăng lực tìm kiếm, tăng thời gian/nước nhưng Android sẽ tốn pin và nóng hơn.</p>
        <label class="field-label" for="alternativeEngineSetting">Phong cách bot mặc định</label><select id="alternativeEngineSetting" class="field">${OFFLINE_ENGINE_CATALOG.map(item => `<option value="${item.id}" ${settings.alternativeEngine === item.id ? 'selected' : ''}>${esc(item.label)} · ${esc(item.hint)}</option>`).join('')}</select>
        <label class="field-label" for="pieceStyleSetting">Bộ quân cờ</label><select id="pieceStyleSetting" class="field">${PIECE_STYLES.map(item => `<option value="${item.id}" ${getPieceStyle() === item.id ? 'selected' : ''}>${esc(item.label)}</option>`).join('')}</select>
        <label class="field-label" for="boardThemeSetting">Phong cách bàn cờ</label><select id="boardThemeSetting" class="field">${COSMETICS.map(item => `<option value="${item.id}" ${getSelectedBoardTheme(document.documentElement.dataset.boardTheme || 'classic') === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select><small class="field-hint">Áp dụng đồng bộ cho bàn chơi, câu đố, đấu trường và xem lại ván.</small>
        <div class="appearance-preview" aria-label="Xem trước bàn cờ và bộ quân"><div class="appearance-preview-board" aria-hidden="true">${Array.from({length:16}, (_, index) => `<span class="${((Math.floor(index / 4) + index % 4) % 2) ? 'dark' : 'light'}">${index === 5 ? pieceSvgMarkup({type:'k',color:'w'}, getPieceStyle()) : index === 10 ? pieceSvgMarkup({type:'q',color:'b'}, getPieceStyle()) : ''}</span>`).join('')}</div><div class="appearance-preview-pieces">${['k','q','r','b','n','p'].map(type => `<span title="${({k:'Vua',q:'Hậu',r:'Xe',b:'Tượng',n:'Mã',p:'Tốt'})[type]}">${pieceSvgMarkup({type,color:'w'}, getPieceStyle())}</span>`).join('')}</div><small>Xem trước tự cập nhật khi đổi bộ quân hoặc màu bàn.</small></div>
        <div class="preference-grid visual-preference-grid"><label class="preference-toggle"><input id="showLegalMovesSetting" type="checkbox" ${visualSettings.showLegalMoves ? 'checked' : ''}/><span><b>Hiện nước đi hợp lệ</b><small>Ẩn/chọn chấm nước đi mà không thay đổi luật chơi.</small></span></label><label class="preference-toggle"><input id="highlightLastMoveSetting" type="checkbox" ${visualSettings.highlightLastMove ? 'checked' : ''}/><span><b>Tô nước đi gần nhất</b><small>Dễ theo dõi diễn biến trong ván.</small></span></label><label class="preference-toggle"><input id="smoothAnimationsSetting" type="checkbox" ${visualSettings.smoothAnimations ? 'checked' : ''}/><span><b>Hiệu ứng nhẹ</b><small>Tắt để ưu tiên độ mượt trên điện thoại yếu.</small></span></label><label class="preference-toggle"><input id="autoQueenSetting" type="checkbox" ${visualSettings.autoQueen ? 'checked' : ''}/><span><b>Tự động phong Hậu</b><small>Không hỏi chọn quân khi tốt lên hàng cuối; hữu ích khi đi trước (premove).</small></span></label><label class="preference-toggle"><input id="announceMovesSetting" type="checkbox" ${visualSettings.announceMoves ? 'checked' : ''}/><span><b>Đọc nước đi cho trình đọc màn hình</b><small>Thông báo nước đi, chiếu, nhập thành và hủy nước đi trước bằng vùng aria-live.</small></span></label></div>
        <div class="preference-grid"><label class="preference-toggle"><input id="openingBookEnabledSetting" type="checkbox" ${settings.openingBookEnabled ? 'checked' : ''}/><span><b>Đa dạng khai cuộc</b><small>Chọn nước từ repertoire riêng và kho khai cuộc đã đóng gói.</small></span></label><label class="preference-toggle"><input id="soundEnabledSetting" type="checkbox" ${settings.soundEnabled ? 'checked' : ''}/><span><b>Âm thanh</b><small>Hiệu ứng nước đi và âm thanh trong game.</small></span></label><label class="preference-toggle"><input id="musicAutostartSetting" type="checkbox" ${musicAutostart ? 'checked' : ''}/><span><b>Tự bật nhạc nền</b><small>Chỉ bắt đầu sau thao tác của người dùng do giới hạn trình duyệt.</small></span></label></div>
        <label class="field-label" for="musicTrackSetting">Nhạc nền</label><select id="musicTrackSetting" class="field">${listChessMusicTracks().map(track => `<option value="${esc(track.id)}" ${getChessMusicTrack() === track.id ? 'selected' : ''}>${esc(track.name)}${track.external ? ' · cần mạng' : ' · ngoại tuyến'}</option>`).join('')}</select><small class="field-hint">Các chủ đề nhạc cờ vua tổng hợp chạy trực tiếp trên máy, hoạt động khi offline. Nhạc YouTube là nội dung bên ngoài và chỉ phát khi bạn tự chọn.</small>
        <div class="button-row"><button id="saveSettings" class="primary-btn" type="button">Lưu thiết lập</button><button id="resetSettings" class="secondary-btn" type="button">Khôi phục mặc định</button></div><div id="settingsTestResult" class="connection-result" aria-live="polite"></div>
      </section>
      <aside class="panel settings-about"><div class="panel-heading"><div><small class="eyebrow">ENGINE STATUS</small><h2>Thành phần thật</h2></div></div><div class="brand-showcase"><img src="./covua-vila-logo.webp" alt="Logo thương hiệu Cờ Vua ViLa" loading="lazy" decoding="async" /></div>
        <section class="memory-keepsake" aria-labelledby="memoryKeepsakeTitle"><div class="memory-keepsake-heading"><span class="memory-keepsake-icon" aria-hidden="true">♜</span><div><small class="eyebrow">KỶ VẬT HÀNH TRÌNH</small><h3 id="memoryKeepsakeTitle">Dấu mốc Cờ Vua ViLa</h3></div></div><img class="memory-keepsake-image" src="./vila-memory-monument.webp" alt="Tượng đài kỷ niệm hành trình xây dựng Cờ Vua ViLa" width="1254" height="1254" loading="lazy" decoding="async" /><p>Một kỷ vật lưu lại những ý tưởng, sự kiên trì và niềm vui khi cùng xây dựng dự án.</p></section>
        <div class="info-row"><span class="info-icon">♞</span><div><b>Stockfish 19 + Stockfish 10 (tùy chọn cũ)</b><p>Stockfish 19 là engine UCI chính; Stockfish 10 cổ điển có thể được chọn riêng trong Đấu trường để so sánh hai thế hệ. Engine UCI được nạp qua Web Worker từ gói npm và script copy-engine. Bản Full NNUE được đóng gói trong bản Android build này và mạnh hơn; chế độ tự động chọn Full trên thiết bị có bộ nhớ phù hợp, còn máy yếu giữ Lite để ổn định. Nếu Full không khởi tạo được, app tự thử Lite rồi ASM-JS.</p></div></div>
        <div class="info-row"><span class="info-icon">♟</span><div><b>Bot có phong cách</b><p>Mỗi profile có kho khai cuộc riêng và điều chỉnh lựa chọn biến thể khi Stockfish tìm được nhiều nước gần điểm số tốt nhất. Đây không phải các binary gốc Lc0/Ethereal/Berserk.</p></div></div>
        <div class="info-row"><span class="info-icon">↶</span><div><b>Xem lại trận</b><p>Chấm sai số theo đánh giá engine trong thời gian cấu hình; nhãn nước đi là nhận xét heuristic trên dữ liệu phân tích, không phải chứng chỉ Elo.</p></div></div>
        <div class="license-note"><b>Giấy phép</b><p>chess.js theo BSD-2-Clause. Stockfish theo GPL-3.0; giữ thông báo bản quyền và giấy phép engine khi phân phối.</p></div>
      </aside>
    </div>
    <section class="panel community-backend-settings"><div class="panel-heading"><div><small class="eyebrow">TÙY CHỌN TRỰC TUYẾN</small><h2>Máy chủ cộng đồng</h2></div><span class="context-icon">↗</span></div>
      <p class="field-hint">Mục này chỉ dùng cho đăng nhập, bạn bè, bảng xếp hạng và luồng Lichess qua backend bạn tự triển khai. Không phải endpoint AI; bot Stockfish, phong cách và câu đố vẫn chạy ngoại tuyến khi không cấu hình máy chủ.</p>
      <label class="field-label" for="communityBackendUrl">Địa chỉ máy chủ HTTPS</label><input id="communityBackendUrl" class="field" type="url" inputmode="url" autocomplete="url" placeholder="https://server-cua-ban.example" value="${esc(settings.backendUrl || '')}" />
      <label class="field-label" for="communityBackendToken">Mã truy cập backend (nếu server yêu cầu)</label><input id="communityBackendToken" class="field" type="password" autocomplete="off" placeholder="Không phải API key của mô hình AI" value="${esc(settings.backendAccessToken || '')}" />
      <div class="button-row"><button id="saveCommunityBackend" class="secondary-btn" type="button">Lưu kết nối cộng đồng</button></div><div id="communityBackendResult" class="connection-result" aria-live="polite"></div>
    </section>
    <section class="panel firebase-backend-settings" id="firebaseConfigSection"><div class="panel-heading"><div><small class="eyebrow">FIREBASE & ĐỒNG BỘ</small><h2>Đồng bộ đám mây Firebase</h2></div><span class="context-icon">🔥</span></div>
      <p class="field-hint">Cấu hình Firebase để bật đồng bộ lịch sử ván cờ và đăng nhập Google / Facebook. Không bắt buộc cấu hình — cờ vua, câu đố và Stockfish vẫn hoạt động 100% khi ngoại tuyến.</p>
      <label class="field-label" for="fbApiKeyInput">Firebase Web API Key</label><input id="fbApiKeyInput" class="field" type="text" placeholder="AIzaSy..." value="${esc(getFirebaseConfig().apiKey || '')}" />
      <label class="field-label" for="fbProjectIdInput">Firebase Project ID</label><input id="fbProjectIdInput" class="field" type="text" placeholder="ma-du-an-firebase" value="${esc(getFirebaseConfig().projectId || '')}" />
      <label class="field-label" for="fbAuthDomainInput">Auth Domain (tùy chọn)</label><input id="fbAuthDomainInput" class="field" type="text" placeholder="du-an.firebaseapp.com" value="${esc(getFirebaseConfig().authDomain || '')}" />
      <div class="button-row"><button id="saveFirebaseConfigBtn" class="primary-btn" type="button">Lưu cấu hình Firebase</button><button id="testFirebaseConfigBtn" class="secondary-btn" type="button">Kiểm tra kết nối</button></div><div id="firebaseConfigResult" class="connection-result" aria-live="polite"></div>
    </section>
  </section>`;
}

function wireCommonActions() {
  // Global navigation listeners are attached once during boot; the views below are re-rendered.
}
function openMatchSetup() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi thiết lập trận mới.'); return; }
  const liveGame = gameStarted && !game.isGameOver() && !clockFlagged && !manualGameResult;
  if (liveGame && game.history().length && typeof window.confirm === 'function' && !window.confirm('Thiết lập trận mới sẽ kết thúc ván hiện tại. Bạn muốn tiếp tục?')) return;
  closeResultModal();
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  queuedMainEngineMove = false;
  botThinking = false;
  premoveQueue = [];
  selected = null;
  selectedTargets = [];
  if (mode === 'lichess') stopOnlineStream();
  stopClock();
  gameStarted = false;
  setView('play');
  window.scrollTo(0, 0);
}

function startGameFromSetup() {
  unlockBoardSound();
  const selectedMode = $('#modeSelect')?.value || mode;
    if (selectedMode === 'lichess') {
    if (!activeOnlineGame?.id) {
      toast('Hãy kết nối Lichess và tạo ván trực tuyến trước.');
      setView('lichess');
      return;
    }
    mode = 'lichess';
    startOnlinePlay();
    return;
  }
  playGameSound('start', settings.soundEnabled);
  mode = selectedMode;
  colorChoice = $('#colorSelect')?.value || 'w';
  humanColor = colorChoice === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : colorChoice === 'b' ? 'b' : 'w';
  orientation = humanColor;
  freshGame();
}

function wirePlayActions() {
  wireAnnotationWidget();
  $$('[data-experience-choice]').forEach(button => button.addEventListener('click', () => {
    const next = button.dataset.experienceChoice;
    if (!['beginner', 'experienced'].includes(next)) return;
    experienceLevel = next;
    try { localStorage.setItem('vila.chess.experience.v1', JSON.stringify(next)); } catch {}
    if (next === 'beginner') {
      settings.botStrengthMode = 'elo'; settings.botElo = 800; settings.clockPreset = '10+0';
      saveSettings();
    }
    renderView();
    toast(next === 'beginner' ? 'Đã bật lộ trình người mới: bot khoảng Elo 800, Rapid 10+0. Gợi ý chỉ dùng ở chế độ solo.' : 'Đã chọn chế độ người chơi đã biết luật. Bạn có thể tự đổi thời gian và sức mạnh bot.');
  }));
  $('#changeExperience')?.addEventListener('click', () => {
    experienceLevel = '';
    try { localStorage.removeItem('vila.chess.experience.v1'); } catch {}
    renderView();
  });
  $('#randomBotElo')?.addEventListener('click', () => {
    randomBotEloEnabled = !randomBotEloEnabled;
    const button = $('#randomBotElo');
    if (button) { button.setAttribute('aria-pressed', String(randomBotEloEnabled)); button.textContent = `🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}`; }
    toast(randomBotEloEnabled ? 'Mỗi ván solo Stockfish sẽ chọn Elo ngẫu nhiên từ 500–3200. Đây không phải Elo rank.' : 'Đã tắt Elo ngẫu nhiên; dùng mức bot đã chọn.');
  });
  $$('[data-play-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.playView)));
  $$('[data-play-rail-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.playRailView)));
  $('#clearBoardSelection')?.addEventListener('click', () => {
    const hadSelection = Boolean(selected || premoveQueue.length);
    selected = null; selectedTargets = [];
    if (premoveQueue.length) clearPendingPremove();
    if (currentView === 'play') renderBoard();
    if (hadSelection) toast('Đã hủy lựa chọn nước đi.');
  });
  $('#gameBotProfile')?.addEventListener('change', event => {
    if (botThinking) { event.target.value = settings.alternativeEngine; toast('Đợi bot hoàn tất nước đi trước khi đổi phong cách.'); return; }
    const selectedProfile = OFFLINE_ENGINE_IDS.includes(event.target.value) ? event.target.value : 'ethereal';
    settings.alternativeEngine = selectedProfile;
    saveSettings();
    const turn = game.turn();
    renderView();
    toast(`Đã chọn ${offlineEngineShortName(selectedProfile)} cho các lượt bot tiếp theo.`, 'success');
    if (gameStarted && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && turn !== humanColor && !game.isGameOver()) { botThinking = true; renderView(); scheduleBotMove(220); }
  });
  const modeSelect = $('#modeSelect');
  modeSelect?.addEventListener('change', () => {
    const chosen = modeSelect.value;
    if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi đổi chế độ bàn cờ.'); modeSelect.value = mode; return; }
    if ((mode === 'lichess' && chosen !== 'lichess') || (chosen === 'lichess' && !activeOnlineGame?.id)) stopOnlineStream();
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    if (chosen === 'lichess' && !activeOnlineGame?.id) {
      toast('Kết nối Lichess và tạo ván trước.'); mode = 'stockfish'; modeSelect.value = mode;
    } else {
      const previousMode = mode;
      mode = chosen;
      if (mode === 'stockfish-beginner') { settings.botStrengthMode = 'elo'; settings.botElo = 500; settings.botSkill = 0; saveSettings(); }
      if (mode === 'lichess') {
        gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
        resetClock('untimed');
        startOnlinePlay(); return;
      }
      if (previousMode === 'lichess') resetClock(settings.clockPreset);
    }
    gameEpoch += 1; queuedMainEngineMove = false; botThinking = false; premoveQueue = []; selected = null; selectedTargets = [];
    renderView();
    if (gameStarted && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor && !game.isGameOver()) {
      botThinking = true; renderView();
      scheduleBotMove(220);
    }
  });
  $('#colorSelect')?.addEventListener('change', event => {
    if (mode === 'lichess') { toast('Màu quân trong ván Lichess do Lichess quyết định.'); renderView(); return; }
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    colorChoice = event.target.value;
    humanColor = colorChoice === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : colorChoice === 'b' ? 'b' : 'w';
    orientation = humanColor;
    gameEpoch += 1; // Invalidate any engine result calculated for the old player-to-move setup.
    queuedMainEngineMove = false;
    botThinking = false; premoveQueue = []; selected = null; selectedTargets = [];
    renderView();
    if (gameStarted && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor && !game.isGameOver()) {
      botThinking = true;
      renderView();
      scheduleBotMove(220);
    }
  });
  $('#skillSelect')?.addEventListener('change', event => {
    randomBotEloEnabled = false;
    const value = event.target.value;
    if (value === 'max') { settings.botStrengthMode = 'max'; settings.botSkill = 20; }
    else { settings.botStrengthMode = 'elo'; settings.botElo = Math.max(500, Math.min(3200, Number(value) || 2600)); settings.botSkill = 20; }
    const saved = saveSettings(); toast(saved ? (settings.botStrengthMode === 'max' ? 'Stockfish đang ở sức mạnh tối đa.' : `Đã giới hạn Stockfish ở khoảng Elo luyện tập ${settings.botElo} (mức dưới 1320 dùng Skill Level 0–7 của Stockfish, không phải Elo benchmark).`) : 'Cấu hình có hiệu lực trong phiên này nhưng chưa lưu được.');
  });
  $('#newGame')?.addEventListener('click', openMatchSetup);
  $('#redoMove')?.addEventListener('click', redoMove);
  $('#gameShowAnalysis')?.addEventListener('click', () => { toggleAnalysis(); $('#analysisPanel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#gameShowMoves')?.addEventListener('click', () => { $('#moveList')?.closest('.moves-panel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#gameShowSetup')?.addEventListener('click', openMatchSetup);
  $('#gameShowOpening')?.addEventListener('click', () => { $('#queryExplorer')?.click(); $('#explorerResult')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#resultPlayAgain')?.addEventListener('click', openMatchSetup);
  $('#resignBtn')?.addEventListener('click', resignCurrentGame);
  $('#offerDrawBtn')?.addEventListener('click', offerDrawCurrentGame);
  $('#restartGameBtn')?.addEventListener('click', openMatchSetup);
  $('#startGameOverlay')?.addEventListener('click', startGameFromSetup);
  $('#reviewGameBtn')?.addEventListener('click', startFullGameReview);
  $('#stopReviewBtn')?.addEventListener('click', () => stopFullGameReview(true));
  $('#clockPreset')?.addEventListener('change', event => {
    const nextPreset = parseClockPreset(event.target.value).preset;
    settings.clockPreset = nextPreset;
    saveSettings();
    $$('[data-time-preset]').forEach(button => button.classList.toggle('is-active', button.dataset.timePreset === nextPreset));
    toast(`Đã chọn ${CLOCK_PRESETS.find(item => item.value === nextPreset)?.label || nextPreset}. Đồng hồ áp dụng từ ván mới.`);
  });
  $$('[data-time-preset]').forEach(button => button.addEventListener('click', () => {
    const select = $('#clockPreset');
    if (!select) return;
    const next = parseClockPreset(button.dataset.timePreset).preset;
    select.value = next;
    select.dispatchEvent(new Event('change', { bubbles: true }));
  }));
  $('#newGameSetup')?.addEventListener('click', openMatchSetup);
  $('#undoMove')?.addEventListener('click', undoMove);
  $('#analyzePosition')?.addEventListener('click', toggleAnalysis);
  $('#flipBoard')?.addEventListener('click', () => { orientation = orientation === 'w' ? 'b' : 'w'; renderBoard(); });
  const musicButton = $('#toggleChessMusic');
  if (musicButton) { syncMusicControls(); musicButton.addEventListener('click', toggleChessMusicFromUi); }
  $$('[data-review-step]').forEach(button => button.addEventListener('click', () => {
    const action = button.dataset.reviewStep;
    setReviewReplayPly((ply, last) => action === 'first' ? 0 : action === 'prev' ? ply - 1 : action === 'next' ? ply + 1 : action === 'last' ? last : ply);
  }));
  $('#reviewMoveAnalysis')?.addEventListener('click', event => {
    const row = event.target.closest('[data-review-ply]');
    if (row) setReviewReplayPly(Number(row.dataset.reviewPly));
  });
  updateReviewReplay();
  $('#hintMove')?.addEventListener('click', requestHint);
  $('#speakHint')?.addEventListener('click', speakCurrentHint);
  $('#useHint')?.addEventListener('click', applyCurrentHint);
  $('#copyPGN')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
  $('#downloadPGN')?.addEventListener('click', downloadPgn);
  $('#reviewDownloadPGN')?.addEventListener('click', downloadPgn);
  $('#explainPosition')?.addEventListener('click', () => { setView('coach'); });
  $('#queryExplorer')?.addEventListener('click', () => queryOpeningExplorer(true));
}
function wireOpeningActions() {
  const update = () => {
    openingPageLimit = 48;
    const filtered = OPENINGS.filter(o => ($('#openingFilter')?.value || 'all') === 'all' || o.family === $('#openingFilter')?.value)
      .filter(o => `${o.name} ${o.eco} ${o.note} ${o.line}`.toLocaleLowerCase().includes(String($('#openingSearch')?.value || '').trim().toLocaleLowerCase()));
    if ($('#openingCount')) $('#openingCount').textContent = `${filtered.length.toLocaleString()} đường khai cuộc`;
    if ($('#openingGrid')) $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', $('#openingFilter')?.value || 'all');
    wireOpeningButtons();
  };
  $('#openingSearch')?.addEventListener('input', update);
  $('#openingFilter')?.addEventListener('change', update);
  wireOpeningButtons();
}
function wireOpeningButtons() {
  $$('[data-load-opening]').forEach(button => button.addEventListener('click', () => loadOpening(Number(button.dataset.loadOpening))));
  $('#loadMoreOpenings')?.addEventListener('click', () => {
    openingPageLimit += 48;
    if ($('#openingGrid')) $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', $('#openingFilter')?.value || 'all');
    wireOpeningButtons();
  });
}
function loadOpening(index) {
  const opening = OPENINGS[index];
  if (!opening) return;
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi nạp khai cuộc.'); return; }
  if (!Array.isArray(opening.san) || opening.san.length === 0) {
    toast(`Biến ${opening.name || 'khai cuộc'} chưa có danh sách nước đi hợp lệ. Ván hiện tại vẫn được giữ nguyên.`);
    return;
  }

  // Validate the whole line on a temporary board before touching the active game.
  // A malformed catalogue item must never leave the player with a partial opening.
  const candidateGame = new Chess();
  for (let ply = 0; ply < opening.san.length; ply += 1) {
    const san = opening.san[ply];
    try {
      candidateGame.move(san);
    } catch (error) {
      console.error('Rejected invalid opening line:', opening.name, `ply ${ply + 1}`, san, error);
      toast(`Biến ${opening.name} có nước không hợp lệ (${san}). Ván hiện tại vẫn được giữ nguyên.`);
      return;
    }
  }

  historyRestoreSignature = ''; reviewReplayState = null;
  if (mode === 'lichess') stopOnlineStream();
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  game = candidateGame;
  moveClockSnapshots = []; redoStack = [];
  gameStartFen = new Chess().fen();
  manualGameResult = null;
  completedReviewRows = []; reviewStatus = '';
  currentOpening = opening.name;
  lastHintMove = null;
  mode = 'local';
  selected = null; selectedTargets = []; lastMove = null; humanColor = 'w'; orientation = 'w'; botThinking = false;
  resetClock(settings.clockPreset);
  setView('play');
  toast(`Đã nạp biến mẫu: ${opening.name}. Bạn có thể tiếp tục nước đi từ thế cờ này.`, 'success');
}
function wireCoachActions() {
  $('#copyFen')?.addEventListener('click', () => copyText(game.fen()));
  $('#copyPgnCoach')?.addEventListener('click', () => copyText(game.pgn() || ''));
  $('#coachAnalyzePosition')?.addEventListener('click', () => { setView('play'); toggleAnalysis(); });
  $('#coachReviewGame')?.addEventListener('click', () => {
    if (gameStarted && (game.isGameOver() || clockFlagged || manualGameResult)) { setView('review'); setTimeout(() => startFullGameReview(), 100); }
    else { setView('play'); startFullGameReview(); }
  });
  $('#coachOpenPuzzles')?.addEventListener('click', () => setView('puzzles'));
  $('#coachOpenOpenings')?.addEventListener('click', () => setView('openings'));
}
function wireSettingsActions() {
  $('#pieceStyleSetting')?.addEventListener('change', event => { setPieceStyle(event.target.value); renderView(); });
  $('#boardThemeSetting')?.addEventListener('change', event => { if (selectBoardTheme(event.target.value)) toast('Đã áp dụng bàn cờ mới cho mọi chế độ.', 'success'); });
  for (const [id, key] of [['showLegalMovesSetting','showLegalMoves'], ['highlightLastMoveSetting','highlightLastMove'], ['smoothAnimationsSetting','smoothAnimations'], ['autoQueenSetting','autoQueen'], ['announceMovesSetting','announceMoves']]) {
    $(`#${id}`)?.addEventListener('change', event => { visualSettings = saveVisualSettings({ ...visualSettings, [key]: Boolean(event.target.checked) }); });
  }
  $('#musicTrackSetting')?.addEventListener('change', event => {
    const track = setChessMusicTrack(event.target.value);
    if (isChessMusicPlaying()) syncMusicControls();
    toast(`Đã chọn nhạc nền: ${listChessMusicTracks().find(item => item.id === track)?.name || track}.`, 'success');
  });
  $('#musicAutostartSetting')?.addEventListener('change', event => {
    musicAutostart = Boolean(event.target.checked);
    try { localStorage.setItem(MUSIC_AUTOSTART_KEY, String(musicAutostart)); } catch {}
    musicAutostartHandled = false;
    toast(musicAutostart ? 'Nhạc sẽ bắt đầu sau thao tác tiếp theo.' : 'Đã tắt tự phát nhạc nền.');
  });
  $('#saveSettings')?.addEventListener('click', () => saveSettingsForm(true));
  $('#saveCommunityBackend')?.addEventListener('click', saveCommunityBackendForm);
  $('#saveFirebaseConfigBtn')?.addEventListener('click', () => {
    const apiKey = $('#fbApiKeyInput')?.value || '';
    const projectId = $('#fbProjectIdInput')?.value || '';
    const authDomain = $('#fbAuthDomainInput')?.value || '';
    const saved = saveFirebaseConfig({ apiKey, projectId, authDomain });
    const result = $('#firebaseConfigResult');
    if (result) {
      if (saved?.apiKey && saved?.projectId) {
        result.textContent = 'Đã lưu cấu hình Firebase thành công. Sẵn sàng đồng bộ và đăng nhập.';
        result.className = 'connection-result success-result';
      } else {
        result.textContent = 'Đã lưu cấu hình. (Để kết nối đám mây, cần nhập API Key và Project ID).';
        result.className = 'connection-result';
      }
    }
    toast('Đã lưu cấu hình Firebase.', 'success');
  });
  $('#testFirebaseConfigBtn')?.addEventListener('click', async () => {
    const result = $('#firebaseConfigResult');
    if (!result) return;
    if (!isFirebaseConfigured()) {
      result.textContent = 'Chưa cấu hình Firebase API Key và Project ID hợp lệ.';
      result.className = 'connection-result error-result';
      return;
    }
    result.textContent = 'Đang kiểm tra kết nối Firebase...';
    result.className = 'connection-result';
    try {
      const cfg = getFirebaseConfig();
      const res = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=${encodeURIComponent(cfg.apiKey)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: 'test@example.com', continueUri: location.href }),
        signal: AbortSignal.timeout(6000)
      });
      const data = await res.json();
      if (res.ok || (data?.error && data?.error?.message !== 'API_KEY_INVALID')) {
        result.textContent = `Kết nối Firebase hợp lệ! Project: ${cfg.projectId} · API Key xác thực tốt.`;
        result.className = 'connection-result success-result';
        toast('Kết nối Firebase thành công!', 'success');
      } else {
        result.textContent = `Lỗi kết nối Firebase: ${data?.error?.message || 'API Key không hợp lệ'}`;
        result.className = 'connection-result error-result';
        toast('Firebase API Key không hợp lệ.', 'warning');
      }
    } catch (err) {
      result.textContent = `Đã lưu cấu hình cục bộ (${err.message}). Có thể do mạng hoặc CORS offline.`;
      result.className = 'connection-result warning-result';
    }
  });
  $('#resetSettings')?.addEventListener('click', () => { settings = normalizeSettings(DEFAULTS); const saved = saveSettings(); if (saved) toast('Đã khôi phục thiết lập engine mặc định.', 'success'); renderView(); });
}
function saveCommunityBackendForm() {
  const url = String($('#communityBackendUrl')?.value || '').trim().replace(/\/+$/, '');
  const token = String($('#communityBackendToken')?.value || '').trim();
  const result = $('#communityBackendResult');
  if (url && !isSafeHttpEndpoint(url)) {
    if (result) { result.textContent = 'Địa chỉ phải là HTTP/HTTPS hợp lệ, không kèm thông tin đăng nhập, query hoặc fragment.'; result.className = 'connection-result error-result'; }
    return false;
  }
  settings.backendUrl = url;
  settings.backendAccessToken = token.slice(0, 4000);
  const saved = saveSettings();
  if (result) {
    result.textContent = saved ? (url ? 'Đã lưu máy chủ cộng đồng. Các tính năng online sẽ kiểm tra kết nối khi được mở.' : 'Đã xóa máy chủ cộng đồng; bot cờ ngoại tuyến vẫn dùng bình thường.') : 'Không thể lưu thiết lập trên thiết bị.';
    result.className = `connection-result ${saved ? 'success-result' : 'error-result'}`;
  }
  if (saved) toast('Đã lưu cấu hình máy chủ cộng đồng.', 'success');
  return saved;
}

function saveSettingsForm(showToast = true) {
  const previousEngine = settings.botEngine || 'auto';
  const requestedEngine = $('#botEngineSetting')?.value || 'auto';
  settings.botEngine = ['auto', 'lite-single', 'full-single', 'sf10'].includes(requestedEngine) ? requestedEngine : 'auto';
  settings.alternativeEngine = OFFLINE_ENGINE_IDS.includes($('#alternativeEngineSetting')?.value) ? $('#alternativeEngineSetting').value : (settings.alternativeEngine || 'ethereal');
  settings.alternativeEnginePreferenceSet = true;
  settings.botEnginePreferenceSet = true;
  settings.botSkill = Math.max(0, Math.min(20, Number($('#botSkillSetting')?.value || 20)));
  settings.botStrengthMode = $('#botStrengthModeSetting')?.value === 'elo' ? 'elo' : 'max';
  settings.botElo = Math.max(500, Math.min(3200, Number($('#botEloSetting')?.value || 2600)));
  settings.botDepth = Math.max(5, Math.min(30, Number($('#botDepthSetting')?.value || 22)));
  settings.botMoveTimeMs = Math.max(500, Math.min(5000, Number($('#botMoveTimeSetting')?.value || 1600)));
  settings.botSearchSettingsPreferenceSet = true;
  settings.analysisMoveTimeMs = Math.max(1000, Math.min(8000, Number($('#analysisMoveTimeSetting')?.value || 2600)));
  settings.reviewQuality = ['standard', 'deep', 'max'].includes($('#reviewQualitySetting')?.value) ? $('#reviewQualitySetting').value : settings.reviewQuality;
  settings.openingBookEnabled = Boolean($('#openingBookEnabledSetting')?.checked);
  settings.soundEnabled = Boolean($('#soundEnabledSetting')?.checked);
  const saved = saveSettings();
  const status = $('#settingsTestResult');
  if (status) {
    status.textContent = saved ? 'Đã lưu thiết lập trên thiết bị. Engine có thể cần tải lại để áp dụng thay đổi bản Stockfish.' : 'Thiết lập đang dùng trong phiên này nhưng chưa lưu được vào thiết bị.';
    status.className = saved ? 'connection-result success-result' : 'connection-result error-result';
  }
  if (showToast && saved) toast(settings.botEngine !== previousEngine ? 'Đã lưu. Tải lại app để áp dụng bản engine mới.' : 'Đã lưu thiết lập cục bộ.', 'success');
  return saved;
}
function wireLichessActions() {
  $('#connectLichess')?.addEventListener('click', connectLichess);
  $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
  $('#forgetLichess')?.addEventListener('click', () => {
    // Revoke the app's local session immediately: abort any stream using the
    // token and invalidate the active game before clearing the stored values.
    stopOnlineStream();
    activeLichessToken = '';
    activeLichessUsername = '';
    activeOnlineGame = null;
    safeSessionRemove(lichessTokenKey);
    safeSessionRemove('tubor.chess.lichessUsername');
    if (mode === 'lichess') {
      mode = 'stockfish';
      gameEpoch += 1;
      botThinking = false;
      cancelScheduledBotMove();
      cancelPendingHint();
      cancelMainEngineSearch();
    }
    if ($('#lichessToken')) $('#lichessToken').value = '';
    const result = $('#lichessAccountResult');
    if (result) result.textContent = 'Đã xóa token và ngắt kết nối Lichess khỏi phiên hiện tại.';
    if (currentView === 'play') renderView();
  });
  $('#challengeLichessAI')?.addEventListener('click', challengeLichessAI);
  $('#challengeLichessUser')?.addEventListener('click', challengeLichessUser);
}
async function connectLichess() {
  const token = getLichessToken();
  if (!token) { toast('Hãy nhập Lichess personal access token.'); return; }
  activeLichessToken = token;
  const persisted = safeSessionSet(lichessTokenKey, token);
  const result = $('#lichessAccountResult'); result.textContent = 'Đang xác thực token…';
  try {
    const account = await apiFetch('/api/lichess/account', { method: 'POST', body: JSON.stringify({ token }) });
    activeLichessUsername = account.username || '';
    safeSessionSet('tubor.chess.lichessUsername', activeLichessUsername);
    result.textContent = `Đã kết nối: ${account.username}${account.title ? ` (${account.title})` : ''}${persisted ? '' : ' · token chỉ được giữ trong phiên hiện tại'}`;
    result.className = 'connection-result success-result';
  } catch (error) { result.textContent = `Kết nối thất bại: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessAI() {
  const token = getLichessToken();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang tạo thử thách AI…';
  try {
    const data = await apiFetch('/api/lichess/challenge-ai', { method: 'POST', body: JSON.stringify({ token, level: Number($('#lichessLevel').value), clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã tạo thử thách. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a> <button id="playLichessChallenge" class="mini-primary">Chơi trong Cờ Vua ViLa</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Ván vừa tạo: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không tạo được thử thách: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessUser() {
  const token = getLichessToken();
  const username = $('#lichessUsername').value.trim();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  if (!username) { result.textContent = 'Hãy nhập tên người chơi muốn thách đấu.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang gửi lời mời…';
  try {
    const data = await apiFetch('/api/lichess/challenge-user', { method: 'POST', body: JSON.stringify({ token, username, clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', opponent: username, username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã gửi lời mời. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở lời mời ↗</a> <button id="playLichessChallenge" class="mini-primary">Kết nối ván trong Cờ Vua ViLa</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Lời mời: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không gửi được lời mời: ${error.message}`; result.className = 'connection-result error-result'; }
}

async function requestHint() {
  if (!gameStarted) { toast('Bắt đầu ván trước khi yêu cầu gợi ý.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi dùng gợi ý.'); return; }
  if (botThinking) { toast('Đợi bot đi xong rồi hãy xin gợi ý.'); return; }
  if (game.isGameOver()) { toast('Ván cờ đã kết thúc.'); return; }
  if (engineWorker && engineReady && !engineFailed) {
    if (engineStopPending || engineSearchActive || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive) {
      toast('Stockfish đang xử lý yêu cầu khác; chờ xong rồi thử lại.');
      return;
    }
    const legal = game.moves({ verbose: true });
    if (!legal.length) return;
    cancelMainEngineWatchdog();
    const request = { fen: game.fen(), epoch: gameEpoch, legal, timeout: null };
    request.timeout = setTimeout(() => {
      if (pendingHintRequest !== request) return;
      pendingHintRequest = null;
      engineSearchActive = false;
      const shouldResumeBot = queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && game.turn() !== humanColor;
      retireStockfishWorker('Stockfish không phản hồi gợi ý kịp thời.');
      if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
      toast('Stockfish chưa phản hồi gợi ý kịp thời; đã dừng engine để tránh kết quả cũ. Chạm trạng thái engine để thử lại.');
      if (shouldResumeBot) { queuedMainEngineMove = false; scheduleBotMove(0); }
    }, 30000);
    pendingHintRequest = request;
    engineSearchActive = true;
    configureStockfishForAnalysis(1);
    engineWorker.postMessage(`position fen ${request.fen}`);
    engineWorker.postMessage(`go movetime ${Math.max(700, Math.min(5000, Number(settings.analysisMoveTimeMs) || 2600))}`);
    return;
  }
  const move = chooseFallbackMove();
  if (move) setHintSuggestion(move, 'Dự phòng nhanh');
  toast(move ? `Gợi ý nhanh: ${move.san}. Đây là gợi ý dự phòng, không phải phân tích Stockfish.` : 'Không có nước đi hợp lệ.');
}

async function queryOpeningExplorer(showToast = true) {
  const requestId = ++explorerRequestId;
  const expectedFen = game.fen();
  const box = $('#explorerResult');
  if (box) box.innerHTML = '<div class="explorer-loading">Đang tra Opening Explorer…</div>';
  try {
    const moves = chessUciHistory();
    const data = await apiFetch(`/api/openings/explorer?moves=${encodeURIComponent(moves)}`);
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    lastExplorerData = data;
    const topMoves = Array.isArray(data?.moves) ? data.moves.slice(0, 4) : [];
    if (box) {
      const rows = topMoves.filter(m => m && typeof m === 'object').map(m => {
        const white = Math.max(0, Number(m.white) || 0);
        const draws = Math.max(0, Number(m.draws) || 0);
        const black = Math.max(0, Number(m.black) || 0);
        const total = white + draws + black;
        const pct = total ? Math.round(100 * white / total) : 0;
        const label = typeof m.san === 'string' ? m.san : typeof m.uci === 'string' ? m.uci : '';
        if (!label) return '';
        return `<div class="explorer-move"><b>${esc(label)}</b><span>${total.toLocaleString('vi-VN')} ván</span><small>Trắng thắng ${pct}%</small></div>`;
      }).filter(Boolean);
      box.innerHTML = rows.length ? `<div class="explorer-title">Nước phổ biến ở thế này</div>${rows.join('')}` : '<div class="empty-state small-empty">Chưa có thống kê cho thế cờ này.</div>';
    }
    if (showToast) toast(topMoves.length ? 'Đã tải dữ liệu khai cuộc từ Lichess.' : 'Không có dữ liệu khai cuộc ở thế này.');
  } catch (error) {
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    if (box) box.innerHTML = `<div class="empty-state small-empty">Chưa tra được: ${esc(error.message)}. Kiểm tra backend hoặc internet.</div>`;
    if (showToast) toast(`Không tra được khai cuộc: ${error.message}`);
  }
}
async function startOnlinePlay() {
  const token = getLichessToken();
  if (!activeOnlineGame?.id || !token) { toast('Cần có ván Lichess và token đã kết nối.'); setView('lichess'); return; }
  historyRestoreSignature = ''; reviewReplayState = null;
  activeLichessToken = token;
  activeOnlineGame.apiMode = $('#lichessApiMode')?.value || activeOnlineGame.apiMode || 'board';
  activeOnlineGame.username = activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '';
  mode = 'lichess';
  humanColor = activeOnlineGame.color === 'black' ? 'b' : activeOnlineGame.color === 'white' ? 'w' : 'w';
  orientation = humanColor;
  game = new Chess(); moveClockSnapshots = []; redoStack = []; gameStartFen = game.fen(); gameStarted = true; selected = null; selectedTargets = []; lastMove = null; botThinking = false;
  setView('play');
  toast('Đang kết nối luồng ván Lichess…');
  listenOnlineGame();
}
async function submitLichessMove(uci) {
  if (!activeOnlineGame?.id) { toast('Chưa có mã ván Lichess.'); return; }
  const token = getLichessToken();
  try {
    await apiFetch('/api/lichess/move', { method: 'POST', body: JSON.stringify({ token, gameId: activeOnlineGame.id, move: uci, apiMode: activeOnlineGame.apiMode || 'board' }) });
  } catch (error) {
    toast(`Lichess từ chối nước ${uci}: ${error.message}`);
    listenOnlineGame();
  }
}
async function listenOnlineGame() {
  stopOnlineStream();
  const token = getLichessToken();
  const streamGameId = String(activeOnlineGame?.id || '');
  if (!streamGameId || !token) return;
  const controller = new AbortController();
  onlineStreamController = controller;
  const isCurrentStream = () => !controller.signal.aborted && activeOnlineGame?.id === streamGameId && onlineStreamController === controller;
  try {
    const response = await fetch(apiUrl('/api/lichess/stream'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(settings.backendAccessToken ? { Authorization: `Bearer ${settings.backendAccessToken}` } : {}) },
      body: JSON.stringify({ token, gameId: streamGameId, apiMode: activeOnlineGame.apiMode || 'board' }),
      signal: controller.signal
    });
    if (!isCurrentStream()) return;
    if (!response.ok || !response.body) {
      const message = await response.text().catch(() => 'Không mở được luồng ván.');
      throw new Error(message.slice(0, 300));
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = '';
    const handleStreamLine = line => {
      const trimmed = line.trim();
      if (!trimmed || !isCurrentStream()) return;
      try { processLichessEvent(JSON.parse(trimmed)); }
      catch (error) { console.warn('Lichess event parse:', error); }
    };
    while (isCurrentStream()) {
      const { value, done } = await reader.read();
      if (!isCurrentStream()) break;
      if (done) {
        pending += decoder.decode();
        if (pending.trim()) handleStreamLine(pending);
        pending = '';
        break;
      }
      pending += decoder.decode(value, { stream: true });
      const lines = pending.split('\n');
      pending = lines.pop() || '';
      for (const line of lines) {
        if (!isCurrentStream()) break;
        handleStreamLine(line);
      }
    }
  } catch (error) {
    if (isCurrentStream() && error?.name !== 'AbortError') toast(`Luồng Lichess bị ngắt: ${error.message}`);
  } finally {
    if (onlineStreamController === controller) onlineStreamController = null;
  }
}
function processLichessEvent(event) {
  if (!event || typeof event !== 'object') return;
  if (event.type === 'gameFull') {
    activeOnlineGame.initialFen = event.initialFen && event.initialFen !== 'startpos' ? event.initialFen : null;
    const whiteName = event.white?.name || event.white?.id || '';
    const blackName = event.black?.name || event.black?.id || '';
    if (activeOnlineGame.username && whiteName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'w';
    else if (activeOnlineGame.username && blackName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'b';
    else if (event.color === 'black' || event.color === 'white') humanColor = event.color === 'black' ? 'b' : 'w';
    orientation = humanColor;
    syncLichessMoveList(event.state?.moves || '');
    if (currentView === 'play') renderView();
  } else if (event.type === 'gameState') {
    syncLichessMoveList(event.moves || '');
    if (event.status && event.status !== 'started') toast(`Ván Lichess kết thúc: ${event.status}.`, 'success');
    if (currentView === 'play') renderView();
  } else if (event.type === 'chatLine') {
    console.info('[Lichess chat]', event.username, event.text);
  }
}
function syncLichessMoveList(movesText) {
  const replay = activeOnlineGame?.initialFen ? new Chess(activeOnlineGame.initialFen) : new Chess();
  for (const uci of String(movesText || '').split(/\s+/).filter(Boolean)) {
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) continue;
    try { replay.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) }); }
    catch { break; }
  }
  game = replay;
  gameEpoch += 1;
  const history = game.history({ verbose: true });
  const last = history[history.length - 1];
  lastMove = last ? { from: last.from, to: last.to } : null;
  selected = null; selectedTargets = [];
}

async function copyText(value) {
  const text = String(value ?? '');
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      toast('Đã sao chép.', 'success');
      return true;
    }
  } catch { /* Try the legacy selection API below for older WebViews. */ }
  let textarea;
  try {
    textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const ok = Boolean(document.execCommand?.('copy'));
    toast(ok ? 'Đã sao chép.' : 'Không sao chép được trên trình duyệt này.');
    return ok;
  } catch {
    toast('Không sao chép được trên trình duyệt này.');
    return false;
  } finally {
    textarea?.remove();
  }
}
function downloadTextFile(contents, filename, mimeType) {
  let url;
  let link;
  try {
    url = URL.createObjectURL(new Blob([contents], { type: mimeType }));
    link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    return true;
  } catch (error) {
    toast(`Không tạo được tệp tải xuống: ${error.message || error}`);
    return false;
  } finally {
    link?.remove();
    if (url) setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
}
function gamePgnWithResult() {
  const result = getGameResult().token;
  const raw = (game.pgn() || '').trim();
  // chess.js may return a complete PGN after a saved game has been loaded.
  // Strip its prior header block, then write one canonical, current header set.
  let moveText = raw;
  const hasPgnHeaders = /^\[[A-Za-z0-9_]+\s+\"/.test(raw);
  const blankLine = hasPgnHeaders ? raw.indexOf('\n\n') : -1;
  if (blankLine >= 0) moveText = raw.slice(blankLine + 2).trim();
  else moveText = raw.replace(/^(?:\s*\[[^\]\r\n]*\]\s*)+/, '').trim();
  moveText = moveText.replace(/(?:1-0|0-1|1\/2-1\/2|\*)\s*$/, '').trim();

  const whiteName = mode === 'local' ? 'White' : (humanColor === 'w' ? 'Player' : (mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : 'Stockfish'));
  const blackName = mode === 'local' ? 'Black' : (humanColor === 'b' ? 'Player' : (mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : 'Stockfish'));
  const defaultFen = new Chess().fen();
  const setupHeaders = gameStartFen && gameStartFen !== defaultFen
    ? `\n[SetUp "1"]\n[FEN "${pgnEscape(gameStartFen)}"]`
    : '';
  const terminationHeader = manualGameResult?.reason
    ? `\n[Termination "${pgnEscape(manualGameResult.reason)}"]`
    : '';
  const headers = `[Event "Cờ Vua ViLa"]\n[Site "Cờ Vua ViLa"]\n[White "${pgnEscape(whiteName)}"]\n[Black "${pgnEscape(blackName)}"]\n[Result "${result}"]${setupHeaders}${terminationHeader}`;
  return `${headers}\n\n${moveText || result}${moveText ? ` ${result}` : ''}`;
}
function downloadPgn() {
  downloadTextFile(gamePgnWithResult(), 'covua-vila-game.pgn', 'application/x-chess-pgn;charset=utf-8');
}

function stopOnlineStream() {
  if (onlineStreamController) { onlineStreamController.abort(); onlineStreamController = null; }
}

// Re-measure against the actual WebView viewport on rotation, split-screen, or inset changes.
window.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });
window.addEventListener('orientationchange', scheduleBoardLayoutSync, { passive: true });
window.visualViewport?.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });

async function loadExternalOpeningCatalog() {
  if (openingCatalogLoadPromise) return openingCatalogLoadPromise;
  openingCatalogLoadPromise = (async () => {
    try {
      const response = await fetch('./openings-eco.json', { cache: 'force-cache' });
      if (!response.ok) throw new Error(`HTTP ${response.status} loading openings-eco.json`);
      const payload = await response.json();
      const entries = Array.isArray(payload) ? payload : payload?.openings;
      if (!Array.isArray(entries) || !entries.length) {
        if (OPENINGS.length < REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Kho khai cuộc chưa đầy đủ', message: `Ứng dụng đang có ${OPENINGS.length.toLocaleString()} biến mẫu, chưa đạt yêu cầu ${REQUIRED_OPENING_COUNT.toLocaleString()}. Cần build lại với dữ liệu ECO hợp lệ; không xóa kho đang có.`, type: 'error', sourceKey: 'opening-catalog:missing-full-data' });
        if (currentView === 'health') renderView();
        return 0;
      }
      const additions = mergeOpeningEntries(OPENINGS, entries, 5000);
      if (additions.length) {
        OPENINGS.push(...additions);
        console.info(`[Cờ Vua ViLa] Loaded ${additions.length} additional ECO openings; total ${OPENINGS.length}.`);
      } else {
        console.info('[Cờ Vua ViLa] The bundled ECO file contains no new move lines; keeping the curated book already loaded in the app.');
      }
      // A non-empty JSON file can still be only the curated fallback or contain duplicates.
      // Always report the actual live count instead of silently returning before the readiness check.
      if (OPENINGS.length >= REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Thư viện khai cuộc đã nạp', message: `Đã nạp ${OPENINGS.length.toLocaleString()} biến khai cuộc hợp lệ.`, type: 'success', sourceKey: `opening-catalog:loaded:${OPENINGS.length}` });
      else addAppNotification({ title: 'Kho khai cuộc chưa đủ dữ liệu', message: `Hiện có ${OPENINGS.length.toLocaleString()} biến khai cuộc (kể cả bộ dự phòng); bản phát hành yêu cầu ít nhất ${REQUIRED_OPENING_COUNT.toLocaleString()}. Cần build lại với kho ECO đầy đủ.`, type: 'warning', sourceKey: `opening-catalog:below-threshold:${OPENINGS.length}` });
      const playCount = $('#playOpeningCount');
      if (playCount) playCount.textContent = OPENINGS.length.toLocaleString();
      if (currentView === 'openings' && $('#openingGrid')) {
        openingPageLimit = 48;
        const query = String($('#openingSearch')?.value || '').trim().toLocaleLowerCase();
        const family = $('#openingFilter')?.value || 'all';
        const filteredCount = OPENINGS.filter(item => (family === 'all' || item.family === family) && `${item.name} ${item.eco} ${item.note} ${item.line}`.toLocaleLowerCase().includes(query)).length;
        if ($('#openingCount')) $('#openingCount').textContent = `${filteredCount.toLocaleString()} đường khai cuộc`;
        $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', family);
        wireOpeningButtons();
      }
      const label = $('#openingRecognition');
      if (label && currentView === 'play') {
        const found = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
        label.textContent = found ? `Khai cuộc nhận diện: ${found.name}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước');
      }
      if (currentView === 'health') renderView();
      return additions.length;
    } catch (error) {
      console.info('[Cờ Vua ViLa] Expanded opening catalog unavailable; curated offline book remains active.', error?.message || error);
      if (OPENINGS.length < REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Không tải được kho khai cuộc mở rộng', message: `Chỉ còn ${OPENINGS.length.toLocaleString()} biến mẫu trên thiết bị. Lỗi nạp dữ liệu: ${String(error?.message || error).slice(0, 220)}`, type: 'error', sourceKey: 'opening-catalog:load-failed' });
      if (currentView === 'health') renderView();
      return 0;
    }
  })();
  return openingCatalogLoadPromise;
}

// Boot
syncSocialNav();
syncInboxBadge();
ensurePieceSprite();
{ const savedYt = parseYoutubeUrl(savedYoutubeMusicUrl()); if (savedYt) setChessMusicYoutube(savedYt, { onFailure: error => toast(`${error?.message || 'YouTube không phát được.'} Đã quay về nhạc cờ vua tích hợp.`) }); }
syncMusicControls();
$('#appMusicToggle')?.addEventListener('click', toggleChessMusicFromUi);
document.addEventListener('pointerdown', handleMusicAutostartGesture, { capture: true, passive: true });
document.addEventListener('keydown', handleMusicAutostartGesture, { capture: true });
adoptSocialCallback();
setInterval(() => { void pollSocialInbox(); }, 60_000);
if (socialState.token) setTimeout(() => { void pollSocialInbox(); }, 1500);
$$('.tab').forEach(tab => tab.addEventListener('click', () => { if (tab.hidden) return; setView(tab.dataset.view); }));
$('.brand')?.addEventListener('click', event => { event.preventDefault(); setView('home'); });
$('#accountShortcut')?.addEventListener('click', () => setView('friends'));
$('#openInbox')?.addEventListener('click', () => setView('inbox'));
const brandLogo = $('.brand-logo');
brandLogo?.addEventListener('error', () => { brandLogo.hidden = true; const fallback = $('#brandLogoFallback'); if (fallback) fallback.hidden = false; }, { once: true });
if (brandLogo?.complete && brandLogo.naturalWidth === 0) brandLogo.dispatchEvent(new Event('error'));
$('#bottomMore')?.addEventListener('click', () => { $('#openMenu')?.click(); const open = $('#mainMenu')?.classList.contains('menu-open'); $('#bottomMore')?.setAttribute('aria-expanded', String(Boolean(open))); });
$('#openMenu')?.addEventListener('click', () => { const menu = $('#mainMenu'); const open = menu?.classList.toggle('menu-open') ?? false; $('#openMenu')?.setAttribute('aria-expanded', String(open)); $('#bottomMore')?.setAttribute('aria-expanded', String(open)); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && currentView === 'play' && (premoveQueue.length || selected) && !$('#modalRoot')?.children.length) {
    const hadPremoves = clearPendingPremove({ silent: false });
    selected = null; selectedTargets = [];
    if (hadPremoves || currentView === 'play') renderBoard();
    return;
  }
  if (event.key !== 'Escape' || !$('#mainMenu')?.classList.contains('menu-open')) return;
  $('#mainMenu')?.classList.remove('menu-open');
  $('#openMenu')?.setAttribute('aria-expanded', 'false');
  $('#bottomMore')?.setAttribute('aria-expanded', 'false');
  $('#openMenu')?.focus();
});
$('#openSettings')?.addEventListener('click', () => setView('settings'));
$('#engineStatus')?.addEventListener('click', retryStockfishEngine);
window.addEventListener('pagehide', () => {
  persistLocalGameRecovery();
  const match = rankedMatchState?.match;
  if (currentView !== 'ranked' || !socialState.token || match?.status !== 'active') return;
  try {
    const base = socialBackendBase();
    void fetch(`${base}/api/social/ranked/matches/${encodeURIComponent(match.id)}/abandon`, {
      method: 'POST', keepalive: true,
      headers: { Authorization: `Bearer ${socialState.token}`, 'Content-Type': 'application/json' },
      body: '{}'
    }).catch(() => {});
  } catch { /* Server-side presence timeout remains the fallback when pagehide cannot reach the backend. */ }
});
resetClock(settings.clockPreset);
ensureClockTicker();
const restoredLocalGame = offerLocalGameRecovery();
renderView();
if (restoredLocalGame && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor) {
  botThinking = true;
  scheduleBotMove(300);
}
initEngine();
void loadExternalOpeningCatalog();

// Offline support (v3.46.4): cache the app shell and engines so VILA works without a network.
if ('serviceWorker' in navigator && import.meta.env.PROD && /^https?:$/.test(window.location.protocol) && !window.Capacitor?.isNativePlatform?.()) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(new URL(`${import.meta.env.BASE_URL}sw.js`, window.location.href).href).catch(error => console.warn('[VILA] Service worker not registered:', error));
  });
}
window.addEventListener('offline', () => toast('Đang offline: Stockfish, bot cục bộ, khai cuộc, câu đố và xem lại vẫn chạy; chỉ tính năng Lichess/cộng đồng trực tuyến cần mạng.'));
window.addEventListener('online', () => toast('Đã có mạng trở lại.', 'success'));


document.addEventListener('pointerdown', event => {
  const menu = $('#mainMenu');
  if (!menu?.classList.contains('menu-open')) return;
  if (event.target.closest('#mainMenu, #openMenu, #bottomMore')) return;
  menu.classList.remove('menu-open'); $('#openMenu')?.setAttribute('aria-expanded', 'false'); $('#bottomMore')?.setAttribute('aria-expanded', 'false');
}, true);
