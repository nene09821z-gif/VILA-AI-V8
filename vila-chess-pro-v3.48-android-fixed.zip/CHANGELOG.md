# Changelog

## Chưa phát hành — sửa lỗi, đi trước vô hạn, giao diện dễ đọc
- Sửa 2 test fail: bản ZIP GitHub gọn không có `app/src/main/assets/sw.js`; test nay đọc `public/sw.js` khi bản sao Android vắng.
- Đi trước (premove) kiểu chess.com: xếp hàng vô hạn, nối nhiều nước (kể cả nhập thành, đi cùng quân hai lần); tự đi lần lượt, tự hủy cả hàng đợi khi đối thủ đi khác làm nước đầu không còn hợp lệ. Hủy bằng chuột phải, Esc, nút "Hủy n nước đi trước" hoặc chạm ô đã xếp.
- Nhập thành: bỏ nhãn O-O/O-O-O 8px đè lên ô; danh sách nước đi không xuống dòng, nhập thành dùng chữ đơn cách, nước gần nhất được tô.
- Quân trượt mượt khi bấm đi/bot đi (cả xe khi nhập thành), thả kéo quân vẫn tức thì; tôn trọng giảm chuyển động.
- Bảng màu navy/xanh dương/cyan thống nhất (`src/vila-polish.css`); số chỗ chữ thiếu tương phản giảm từ ~1.460 xuống ~130 (chủ yếu tọa độ trang trí trên bàn cờ).
- Viền xanh quanh nước bạn vừa đi, viền đỏ quanh nước đối thủ vừa đi (hai ô đi/đến, ô đến nháy nhẹ). Màu đi trước chuyển sang vàng hổ phách để không lẫn với viền đỏ.
- Nhãn phân tích kiểu chess.com theo xác suất thắng: Thiên tài (!!), Tuyệt vời (!), Tốt nhất, Xuất sắc, Tốt, Khai cuộc, Thiếu chính xác, Sai lầm, Bỏ lỡ, Sai lầm nghiêm trọng; huy hiệu tròn có màu. Thiên tài = hy sinh quân thật sự theo biến Stockfish; Tuyệt vời = nước duy nhất (MultiPV 2) hoặc lật ngược thế cờ.
- Mức phân tích ván mới "Cao nhất" (mặc định): Stockfish 19 Lite 8 giây/nước, MultiPV 2, Hash 64MB; có thể chọn Sâu/Chuẩn trong Cài đặt. Chưa có bản Full NNUE trong gói (cần tải ở bước build).
- Thêm: tự động phong Hậu, thông báo nước đi cho trình đọc màn hình (aria-live).

## v3.47.2 — Stockfish 10 nhanh hơn và gói GitHub gọn hơn

- Đấu trường: giới hạn thời gian Stockfish 10 khoảng 0,2–0,6 giây/nước; giảm timeout để dự phòng nhanh hơn.
- Đấu người: giới hạn Stockfish 10 ở tối đa 0,5 giây/nước; rút watchdog riêng cho engine cũ.
- Giữ Stockfish 10 và các fallback; không đổi cấu hình phân tích mạnh nhất.
- Giữ bản ZIP AI Studio trong `public/assets/aistudio`; Gradle tự khôi phục bản sao Android trong giai đoạn `preBuild`.
- Tăng versionName/versionCode, làm mới Service Worker và cache asset.

## v3.47.1 — giảm độ trễ Đấu trường AI và bỏ Stockfish 10 khỏi mặc định
- Đấu trường mặc định ghép Stockfish 19 với ViLa Rookie, không còn tự chọn Stockfish 10 cổ điển.
- Giảm ngân sách suy nghĩ mỗi nước của Đấu trường: Stockfish 19 dùng giới hạn 0,7–1,5 giây/nước; Stockfish 10 legacy dùng 0,3–1,2 giây/nước. Giảm nhịp nghỉ mặc định giữa nước còn 0,15 giây.
- Stockfish 10 vẫn có thể chọn thủ công để so sánh, được ghi nhãn là bản cũ/chậm hơn; không xóa tệp engine hoặc giấy phép.
- Đồng bộ thay đổi quan trọng trong JS bundle Android có sẵn, tăng version và Service Worker cache lên v3.47.1.
- QA tập trung: xem `TEST_REPORT_V3_47_1.md`. Chưa có build Vite/Gradle sạch do thiếu dependencies trong môi trường; không tuyên bố đã kiểm thử trên điện thoại thật.

## v3.47.0 — online cờ ngày, giao diện sáng và bot luyện người mới
- Thêm mốc 1 ngày và 2 ngày vào hàng đợi đấu trực tuyến; không thêm các mốc này vào thiết lập ván cục bộ.
- Thêm lựa chọn luyện người mới dựa trên Skill Level thấp của Stockfish, không giả lập Elo chính xác.
- Làm sáng giao diện câu đố/xem lại và tăng khả năng nhận chạm ở nút Đấu trường AI.
- Giữ nguyên Stockfish 19 Lite WASM và Stockfish 10 ASM.js hiện có; chưa có bản Full NNUE trong manifest.

## v3.46.4 — thiết lập trận riêng, vào bàn cờ sau khi bắt đầu

- Tách luồng chơi thành trang **Thiết lập trận đấu** và màn bàn cờ. Khi mới vào Chơi cờ, người dùng không còn phải cuộn qua bàn cờ để tìm phần thiết lập.
- Chọn chế độ, phong cách bot, màu quân, mức sức mạnh, thời gian trước khi tạo ván.
- Nút **Ván mới**, **Chơi lại**, **Thiết lập trận** và **Chơi nhanh** đưa người dùng về màn thiết lập; thao tác engine và đồng hồ được dừng khi rời trận.
- Giảm vùng cuộn thừa trên màn thiết lập di động; ẩn phần cài đặt trùng lặp trong cột phụ khi đang đấu.
- Tăng phiên bản/cache lên v3.46.4 để giảm nguy cơ giữ UI cũ trên thiết bị đã cài.

## v3.46.3 — đồng bộ bảng màu xanh dương/cyan, cache và Docker

- Đồng bộ màu giao diện theo logo: navy, xanh dương, cyan; giữ vàng cho phần thưởng.
- Sửa CSS bàn cờ để các theme do người dùng chọn tiếp tục áp dụng qua `--board-*`.
- Tăng phiên bản và Service Worker cache lên v3.46.3; đổi cache-bust biểu tượng lên v349.
- Thêm Dockerfile và `.dockerignore`; cập nhật test giao diện theo palette mới.
- Kiểm thử offline: chỉ xác nhận các bài test có thể chạy với dependency sẵn có; các bài cần `chess.js`/`express` phải được chạy ở môi trường cài dependency.

# Changelog

## v3.46.2 — logo thương hiệu mới và kỷ vật trong Cài đặt
- Dùng biểu tượng vương miện + mã xanh từ ảnh nguồn người dùng làm brand icon, favicon, PWA/app icon và các mật độ mipmap Android; giữ ảnh logo đầy đủ làm wordmark trong Cài đặt.
- Thêm ảnh tượng đài kỷ niệm vào riêng mục Cài đặt, tối ưu sang WebP và cache offline.
- Cập nhật cache key Service Worker để tránh icon cũ còn hiển thị trên Android/WebView; thêm manifest PWA và test hồi quy thương hiệu.
- QA: `test:static` 264/264; cú pháp JS/MJS 131/131; full test 266/270 do 4 test không nạp được dependency thiếu; `npm run build` chặn ở prebuild vì thiếu `chess.js`. Chi tiết tại `TEST_REPORT_V3_46_2.md`; chưa xác nhận APK.

## v3.46.1 — đối chiếu audit, dữ liệu khai cuộc dự phòng và cache đồng bộ
- Đồng bộ phiên bản ứng dụng/package/server và tăng cache-bust favicon để tránh dùng tài nguyên cũ sau cập nhật.
- Thay danh mục khai cuộc rỗng bằng 338 dòng khai cuộc dự phòng đã khử trùng lặp từ kho curation trong mã nguồn. Đây chỉ là bộ dự phòng, không giả làm dữ liệu Lichess đầy đủ; build phát hành vẫn bắt buộc nạp và xác thực ít nhất 3.000 dòng.
- Sửa thông báo khi danh mục JSON chỉ lặp lại biến đã có: ứng dụng vẫn cập nhật số liệu/chẩn đoán và báo thiếu dữ liệu thay vì âm thầm trả về.
- Sửa thứ tự lịch sử changelog/README, cập nhật nguồn câu đố và liên kết báo cáo QA hiện tại.
- QA: `npm run test:static` 261/261 đạt; 130/130 tệp JS/MJS qua `node --check`; `npm test` 263/267 với 4 test bị chặn do thiếu `chess.js`/`express`. `npm install` lỗi DNS `EAI_AGAIN`; production build/APK chưa xác minh. Xem `TEST_REPORT_V3_46_1.md`.

## v3.46.0 — giao diện mobile, đồng hồ nhanh và nhạc cờ vua
- Gom thiết lập trận, danh sách nước đi, phân tích và khai cuộc vào một menu Công cụ, tránh dàn hàng nút dài trên điện thoại.
- Bỏ dòng nhận diện khai cuộc bên dưới bàn cờ và thẻ gợi ý màu vàng; nước gợi ý vẫn được vẽ trực tiếp trên bàn cờ và hiển thị bằng thông báo ngắn.
- Thêm các nút chọn nhanh Siêu chớp 30 giây, Bullet 1+0, Blitz 3+2 và Rapid 10+0; vẫn giữ toàn bộ mốc thời gian trong danh sách thiết lập.
- Làm gọn thanh điều hướng trên màn hình hẹp, cải thiện thao tác kéo quân trên WebView và thêm lối tắt ghép trận người thật.
- Bỏ bản ghi Gymnopédie cũ khỏi nhạc tích hợp; các nhạc nền tích hợp là giai điệu tổng hợp nguyên bản chạy offline, còn nhạc từ YouTube chỉ phát khi người dùng chọn.
- Tăng version/cache key lên v3.46.0 và cập nhật kiểm thử hồi quy.
- QA bản này: `npm run test:static` 254/254; kiểm tra cú pháp 131/131 tệp JavaScript/MJS. `npm test` đạt 256/260; bốn test không khởi chạy vì môi trường thiếu `chess.js`/`express`. Chưa xác minh build APK hoặc thao tác trên thiết bị thật; xem `TEST_REPORT_V3_46_0.md`.

## v3.45.0 — độ an toàn đồng hồ và thao tác phong cấp
- Tính thời gian mỗi tick bằng hàm thuần có kiểm thử riêng; chặn giá trị thời gian `NaN`, không cho đồng hồ chạy tiếp trong ván đã kết thúc và không cộng thời gian khi đồng hồ bị rollback.
- Sửa race trong hộp chọn phong cấp: chụp ô xuất phát, FEN và epoch của ván trước khi mở hộp thoại; hủy nước đi nếu vị trí hoặc ván đã thay đổi thay vì dùng biến chọn quân có thể đã đổi.
- Khi Worker tìm nước ngoại tuyến bị treo/quá hạn, kết thúc Worker, dọn timeout của yêu cầu đang chờ và dùng tìm kiếm dự phòng nông có giới hạn thay vì để các yêu cầu sau mắc kẹt.
- Đưa avatar mã vương miện vào danh sách cache lõi của Service Worker để giao diện thương hiệu sẵn sàng ngoại tuyến ngay sau cài đặt.
- Xóa tệp tạm rỗng `public/test.tmp`; đồng bộ metadata package, giao diện, API health, user-agent và cache key lên v3.45.0.
- Kiểm thử: `test:static` 251/251 đạt; 128/128 tệp JS/MJS kiểm tra cú pháp đạt. Test tập trung đồng hồ, phong cấp bất đồng bộ và phục hồi Worker 9/9 đạt. `npm test` có 253/257 bài đạt, 4 bài không khởi chạy do thiếu `chess.js`/`express`; registry npm không phân giải được DNS trong môi trường này. Chưa xác nhận build APK hoặc thao tác trên thiết bị/máy chủ thật.

## v3.44.0 — nhận diện ViLa và giao diện màu sắc nhẹ
- Thêm ảnh mã đội vương miện do người dùng cung cấp làm dấu hiệu thương hiệu và avatar hồ sơ trên trang chủ.
- Thêm chuyển động màu bằng CSS nhẹ; không tải video và tôn trọng cài đặt giảm chuyển động của thiết bị.
- Giữ nguyên các luồng chơi cờ, đồng hồ xếp hạng, bạn bè/tìm kiếm, đấu trường, phân tích, câu đố, nhiệm vụ, cửa hàng và mini-game.
- Bổ sung CSS thích ứng cho avatar và hiệu ứng màu sắc.

## v3.43.0 — Stockfish 10 UCI handshake and mobile polish
- Parse each line of UCI output independently in the main Stockfish worker path. This handles legacy worker events that bundle `uciok`, `readyok`, and other lines into one event, with exact handshake matching and a longer startup watchdog.
- Added regression coverage for bundled/multiline UCI output, object-wrapped worker events and engine-health state; included engine-health tests in the static suite.
- Refined the analysis panel for small screens and mobile review metadata; kept the action toolbar in normal flow so it no longer obscures the lower match screen.
- The release workflow requires Stockfish 10, Stockfish 19 Lite/ASM and Full NNUE assets plus the Stockfish 10 license notice. Actual engine execution still must be confirmed by the GitHub build and a device run; the package dependency install could not complete in this offline environment.

## v3.42.0 — Engine recovery, puzzle service and mobile layout
- Stockfish 10 is a required dependency for release packaging; GitHub Actions fails early if the script or GPL notice is absent.
- Arena Stockfish 10 opponents retry using Stockfish 19 and then the VILA offline search core while validating every returned move against legal moves.
- Added a public puzzle proxy to the user's own backend with bounded recently-served puzzle IDs and daily-puzzle caching; client uses this server when configured and falls back to Lichess.
- Increased offline puzzle pool to 150 positions, remembered puzzle history to 15,000 positions, and puzzle pack downloads to 20 validated puzzles per batch.
- Fixed the mobile match action bar being cropped/overlaying content by placing it back into normal document flow; improved contrast of player cards and clock surfaces.
- Added five board cosmetics and four offline generated background music choices plus the optional online classical recording.
- Validation caveats for this line of work are consolidated in TEST_REPORT_V3_43_0.md; device-side play still needs GitHub APK build and a real-device run.

## v3.41.0 — VILA Atelier: thiết kế lại toàn bộ giao diện

- Thay ngôn ngữ giao diện tối xanh cũ bằng không gian sáng, phong cách editorial/studio: nền giấy, panel rõ cấp bậc, xanh lá làm màu hành động và điểm nhấn vàng cho phần giải đấu.
- Làm mới header, menu chức năng, thanh điều hướng mobile, màn chủ, bảng cờ, panel đồng hồ, danh sách nước đi, câu đố, khai cuộc, đấu trường, biểu đồ và cài đặt bằng lớp CSS riêng `src/vila-atelier.css`; giữ lại toàn bộ ID và bộ xử lý thao tác hiện có.
- Thiết kế lại thanh hành động ván cờ thành cụm 5 nút cảm ứng đồng đều; ẩn bottom navigation trong màn chơi trên điện thoại để không chồng lấp với thanh hành động.
- Bỏ Google Fonts tải từ xa để giảm yêu cầu mạng và tránh làm chậm khởi động offline; sử dụng font hệ thống.
- Đồng bộ metadata, API health, Service Worker, favicon cache-busting và test phiên bản lên 3.41.0.
- Bổ sung kiểm thử tĩnh cho lớp giao diện mới, breakpoint di động, offline-first typography và bảo toàn các hook chức năng.
- Đồng bộ các màn chuyên biệt vốn còn giữ tông cũ: phân tích và xem lại ván, lịch sử/PGN, ranked và câu đố, tiến trình/nhiệm vụ/cửa hàng, mạng xã hội, inbox, bảng xếp hạng/admin và hộp kết quả.
- Bổ sung kiểm thử tĩnh riêng cho các màn chuyên biệt; giữ nguyên module xử lý luật, engine và dữ liệu, tránh thay logic cờ chỉ để phục vụ thiết kế.
- QA cuối: test tĩnh 239/239; cú pháp 126/126 JS/MJS; 0 lỗi parse trong hai stylesheet. Full suite 241/245, 4 test không khởi chạy do thiếu dependency trong môi trường; không tuyên bố APK/device đã được nghiệm thu.

## v3.40.0 — kiểm tra UCI thật và khôi phục ván có kiểm chứng

- Thêm state machine kiểm tra khởi động Stockfish: chỉ đánh dấu sẵn sàng khi nhận `uciok` rồi `readyok`; `readyok` lạc chỗ và `bestmove` đến sớm không được tính là handshake thành công.
- Nút mã góc trên hiển thị thời gian khởi động trong tooltip, tên profile engine và thông báo lỗi cụ thể; trạng thái này phản ánh UCI handshake thật chứ không phải một nhãn giao diện đơn thuần.
- Bản lưu ván đang chơi dùng schema v3 kèm checksum FNV-1a, kiểm tra thời gian lưu, mode, nước đi, hướng quân, FEN, đồng hồ và kích thước snapshot trước khi replay. Snapshot v2 cũ vẫn được chấp nhận để khôi phục tương thích; nước đi vẫn được replay và FEN cuối phải khớp.
- Đồng bộ phiên bản package, giao diện, API health, cache Service Worker, tài liệu build và kiểm thử về 3.40.0. Sửa các kỳ vọng phiên bản cũ trong test để test hồi quy còn có thể chạy khi phát hành mới.
- Kiểm thử tĩnh 228/228 và cú pháp 121/121 đạt. Bộ test đầy đủ 230/234; bốn tệp test không khởi chạy do các dependency `chess.js`/`express` không có vì `npm install` bị timeout. Không tuyên bố build APK hoặc test thiết bị khi chưa thực hiện được.

## v3.38.0 — màn chọn người chơi, bàn công cụ gọn, kho câu đố và Cúp ViLa

- Đưa lựa chọn “Mới chơi / Đã hiểu luật” ra ngoài phần cài đặt thu gọn để hiển thị ngay trước bàn cờ trên điện thoại.
- Thanh bút chì được cố định trong luồng bố cục; bỏ lưu tọa độ kéo-thả cũ, gom mũi tên, khoanh ô, đổi màu và xóa vào cùng một cụm.
- Thu gọn thanh nút thao tác để nhãn không tràn và không bị kéo giãn trên màn hình nhỏ.
- Thêm biểu tượng mã Stockfish có trạng thái tải/sẵn sàng/lỗi; hiển thị tên phiên bản đầy đủ, trong đó đường tải Stockfish 10 vẫn dùng gói riêng và chuỗi fallback an toàn.
- Thêm bảng Cúp đấu trường, lưu bảng điểm giải vòng tròn và nhiệm vụ liên quan.
- Thêm mini-game Cờ ca-rô offline với bot tìm kiếm minimax tối ưu.
- Thêm kho câu đố Lichess đã xác minh, tải theo lô 10 đề và lưu tối đa 50 đề hợp lệ trên máy; không nhúng cả cơ sở dữ liệu nhiều triệu dòng vào APK.
- Cập nhật nhãn ký hiệu phân tích và thêm nhiệm vụ luyện tập/đấu trường/mini-game.

## v3.37.2 — sửa bố cục trận đấu Android

- Hiển thị bàn cờ rõ ngay cả trước khi bắt đầu; chuyển lựa chọn kinh nghiệm và nút bắt đầu thành thẻ nhỏ phía trên bàn cờ.
- Đặt lại vị trí cuộn khi chuyển màn hình để tránh thẻ đối thủ bị che bởi thanh đầu trang dính.
- Bổ sung vùng đệm nội dung phía dưới cho thanh thao tác cố định trên WebView di động.
- Tăng cache key Service Worker để lấy CSS/JS mới.

## v3.37.1 — sửa vòng đời Stockfish 10 trong Đấu trường

- Bổ sung hàng rào UCI `isready`/`readyok` trước mỗi tìm kiếm, reset `ucinewgame` đúng một lần mỗi ván thay vì mỗi nửa nước.
- Tách callback theo đúng Worker, tách từng dòng UCI nếu wrapper gộp nhiều dòng, huỷ Worker lỗi/timeout an toàn và cho phép khởi tạo lại ở lượt tiếp theo.
- Lỗi Stockfish 10 nay được ghi vào trạng thái Đấu trường trong khi nước dự phòng hợp lệ vẫn giúp ván đấu tiếp tục.
- Tăng phiên bản cache Service Worker lên 3.37.1 để tránh giữ mã cũ.
- Kiểm thử giả lập nhiều nước liên tiếp, vị trí sau bắt quân, dòng UCI gộp, timeout/khởi động lại và lỗi tạo Worker đồng bộ. Chưa tuyên bố engine thật đã chạy trên thiết bị Android trong môi trường này.

## v3.37.0 — Stockfish 10 Arena, review page tách riêng, thêm bộ quân

- Thêm đối thủ Stockfish 10 (gói npm alias `stockfish-10` / `10.0.2`) dùng worker UCI riêng để thi đấu ở Đấu trường, không tranh worker với Stockfish 19. Build Android bắt buộc kiểm tra script và giấy phép engine cũ trước khi đóng gói.
- Trang kết quả/xem lại được tách thành route riêng, chia bố cục bàn cờ phát lại và biến engine với biểu đồ lợi thế, biên bản theo cặp, nhãn nước đi, thống kê Trắng/Đen và tải PGN. Không tuyên bố dùng CAPS2 của Chess.com.
- Bổ sung 3 palette quân gốc VILA (Amethyst, Sapphire, Bronze) và 4 bộ quân được cấp phép từ Lichess (`kiwen-suwi`, `firi`, `totoy`, `shapes`), kèm credit/license khi build.
- Chốt phiên bản app/package/server/workflow ở 3.37.0; thêm test cho giao thức UCI giả lập, cổng build Stockfish 10, route review và gradient SVG.
- Các bài test tĩnh được chạy trong môi trường sửa đổi; `npm install`, test tích hợp phụ thuộc `chess.js`/`express`, Gradle và chạy trên Android vẫn phải được xác nhận qua GitHub Actions/thiết bị. Không đánh dấu APK đã build nếu chưa có artifact.


## v3.36.0 — Bot mạnh hơn, đánh giá minh bạch và xem lại có gợi ý

- Android build thêm Stockfish 19 Full NNUE cùng Lite và ASM-JS dự phòng; thiết bị có bộ nhớ/CPU phù hợp tự ưu tiên Full. Máy yếu giữ Lite để giảm rủi ro tràn bộ nhớ; vẫn có thể chọn Full thủ công.
- Mặc định nghĩ sâu hơn (độ sâu trần 30, đến 2,6 giây mỗi nước); cài đặt tùy chỉnh của người dùng được giữ nguyên khi cập nhật.
- Gỡ nhánh tự bỏ qua Stockfish bằng nước heuristic/ngẫu nhiên trong chế độ Elo thấp. Dưới ngưỡng UCI_Elo của Stockfish, engine dùng Skill Level 0–7 theo từng mức; số Elo thấp được ghi rõ là preset luyện tập, không phải xếp hạng benchmark.
- Phân tích toàn ván dùng ngân sách thời gian hợp lý hơn, ghi lại nước tốt nhất engine tìm thấy trước từng nước thật, lưu SAN gợi ý, độ sâu, điểm trước/sau và mức điểm đã mất. Biên bản nay ghép nước Trắng/Đen theo lượt, hỗ trợ nhảy tới thế cờ và tổng hợp nhãn riêng cho mỗi bên.
- Xử lý vị trí chiếu hết/hòa cuối ván và quy đổi mate score; không còn tự gắn nhãn “Thiên tài” chỉ vì một quân có thể bị ăn. Chỉ đánh dấu nước khai cuộc khi mức mất điểm vẫn nhỏ. Changelog ghi lại các thay đổi theo từng phiên bản; ZIP phát hành chỉ kèm báo cáo tương ứng với phiên bản hiện tại.
- Bỏ các báo cáo cũ khỏi ZIP phát hành; giữ bộ test hồi quy lịch sử cần thiết.


## v3.35.0 — sảnh Trang chủ, câu đố Lichess và trải nghiệm Android

- Sửa lỗi khởi động sai: ứng dụng nay mở ở **Trang chủ/Sảnh VILA**, không mở thẳng vào bàn cờ. “Chơi ngay” mới bắt đầu ván, còn tùy chỉnh ván đấu đi tới thiết lập.
- Thiết kế lại trang chủ thành dashboard có thẻ hồ sơ/Elo cục bộ, thanh lối tắt 5 chế độ, hero chơi cờ, thẻ câu đố ngày, các chế độ AI/câu đố/bài học/phân tích/online, khu luyện tập và mini-game. Điều hướng gọn, responsive và safe-area cho Android.
- Kết nối Lichess Daily Puzzle qua `/api/puzzle/daily` và câu đố huấn luyện lần lượt qua `/api/puzzle/next` với 5 mức độ; kiểm tra PGN và toàn bộ dòng giải bằng `chess.js`, cache theo ngày, timeout và phương án dự phòng ngoại tuyến. Câu đố nhiều nước tự chơi nước đáp của đối thủ và chuyển câu tiếp sau khi giải.
- Giữ/chỉnh sửa lại hồ sơ Đấu trường AI, trang phân tích/xem lại, kho khai cuộc, chơi offline bằng Stockfish, luồng online qua backend/Lichess. Giữ rõ khác biệt giữa engine thật và profile phong cách.
- Bổ sung test hồi quy ngăn việc quay lại mở trực tiếp vào bàn cờ, test dữ liệu câu đố và validate cache.
- Ghi lại giới hạn: nếu không có mạng, daily cache chỉ hoạt động sau lần tải thành công trước đó; nếu không có cache, tự dùng thế đố sinh ngoại tuyến. APK phải build trên GitHub Actions trước khi coi là phát hành.

## v3.34.0 — VILA mobile-first refresh

- Thay shell điều hướng bằng thanh chế độ 5 mục, menu chức năng gọn và bottom navigation dành cho Android. Bản 3.34.0 mở thẳng vào phòng chơi; đây là lỗi đã được sửa ở v3.35.0 để app khởi động tại Sảnh Trang chủ.
- Thiết kế lại Đấu trường AI theo bố cục dọc: hồ sơ hai bot, bàn cờ lớn, biên bản nước đi và thiết lập nâng cao có thể thu gọn. Giữ nguyên Stockfish, luật chess.js, chế độ đấu trận/giải vòng tròn và tải PGN.
- Thêm trung tâm Mini-game ngoại tuyến: Rubik 3×3 với trạng thái sticker thật, xoay mặt qua swipe/nút U/D/L/R/F/B, xáo trộn, hoàn tác và kiểm tra đã giải; thêm 2048 (phím/swipe/nút hướng), lật thẻ ghi nhớ và Trượt số 15 với xáo trộn bằng các bước hợp lệ.
- Câu đố Luyện tự do, Puzzle Rush và Sinh tồn tự động chuyển bài sau khi giải đúng; thử thách hằng ngày vẫn giữ nguyên chính sách một đề mỗi ngày.
- Thêm kiểm thử thuần Node cho xoay Rubik/đảo ngược/xáo trộn và logic 2048.
- Các bot phong cách vẫn là profile tìm kiếm VILA dựa trên engine cục bộ, không được quảng cáo là các engine neural độc lập. Cần hoàn tất npm test và GitHub Actions để xác nhận build APK trước phát hành.


## v3.33.0 — giao diện phòng đấu và độ trễ thao tác
- Làm mới phòng đấu theo tông xanh đêm, thẻ người chơi/đồng hồ, thanh chức năng riêng và thanh thao tác năm nút trên điện thoại.
- Giảm chi phí chọn quân: chỉ cập nhật các ô cờ đổi trạng thái; chỉ tính nước hợp lệ khi cử chỉ đã thành thao tác kéo.
- Dùng hình học bàn cờ đã cache để xác định ô thả, tránh hit-test DOM qua `elementFromPoint()` trong lúc kéo.
- Giữ các view/chức năng cũ; thêm nút hủy lựa chọn nước đi.
- Pin phiên bản cụ thể cho các dependency trực tiếp; ZIP phát hành hiện tại kèm báo cáo `TEST_REPORT_V3_37_0.md`; báo cáo của phiên bản cũ không được đóng gói lại.

## v3.32.0 — kiểm thử và độ tin cậy
- Sửa lỗi cú pháp trong `tests/visual-settings.test.js` khiến bộ kiểm thử tĩnh không thể khởi chạy đầy đủ.
- Chuẩn hóa kỳ vọng của test: `normalizeVisualSettings` chỉ giữ các tùy chọn giao diện mà module thực sự hỗ trợ; không giả định module này quản lý kiểu quân cờ.
- Đồng bộ phiên bản package, tiêu đề, API health, service-worker cache và nhận diện tác vụ tải tài nguyên sang 3.32.0.
- Thêm cổng kiểm tra cú pháp JavaScript toàn bộ `src`, `server`, `scripts`, `tests` vào quy trình nghiệm thu thủ công.
- Xác minh lại 169 test tĩnh và ghi rõ bốn test tích hợp bị chặn bởi dependency chưa cài trong môi trường.

## v3.31.0 — phòng đấu hợp nhất, thương hiệu mới và luyện tập mở rộng

- Tái thương hiệu toàn bộ giao diện web/Android thành **Cờ Vua ViLa**, icon mới và bảng màu xanh ngọc–vàng.
- Phòng đấu gom thao tác nhanh, thiết lập đối thủ, khai cuộc, danh sách nước và phân tích vào một màn hình.
- Sửa hoàn tác để khôi phục đúng clock snapshot trước nước đi; thêm Làm lại và lịch sử đồng hồ theo từng nửa nước đi.
- Có 18 profile bot offline cấu hình được chọn (bao gồm 6 profile mới: Mentor, Hunter, Sentinel, Strategist, Endgame Pro, Chaos), ngoài engine Stockfish; phân biệt rõ profile cấu hình với engine neural được train độc lập.
- Mở rộng lên 19 kiểu quân cờ: 14 kiểu nội bộ (1 PNG + 13 phối màu vector) và 5 bộ SVG nguồn mở được tải, kiểm tra giấy phép, đóng gói offline trong release GitHub.
- Thêm Luyện tự do, Đề hôm nay xác định theo ngày, Puzzle Rush 3 phút và Sinh tồn 3 mạng; chống kết quả Worker cũ ghi đè lượt hết giờ.
- Test: 166/167 bài kiểm thử tĩnh đạt; full suite 168/173 đạt (5 lỗi khởi tạo trong môi trường hiện tại).

## Lịch sử trước đó

Các thay đổi lịch sử từ các bản v3.x trước được gom vào các tệp nguồn, commit và kiểm thử hiện tại. Báo cáo audit/changelog lặp theo từng phiên bản cũ đã được loại khỏi ZIP để giảm nhiễu.
