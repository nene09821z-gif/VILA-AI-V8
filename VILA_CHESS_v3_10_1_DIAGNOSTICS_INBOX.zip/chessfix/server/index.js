import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { timingSafeEqual } from 'node:crypto';
import { buildChatPayload, normalizeChatOptions } from './ai-request.js';
import { extractChatText, getChatEmptyHint, getChatFinishReason, parseChatResponseBody } from './chat-response.js';
import { isConfirmedFreeModel } from './model-catalog.js';
import { friendlyProviderFailure, providerKeyRequired, sanitizeProviderDetail } from './provider-errors.js';
import {
  normalizeBaseUrl, openAiChatUrl, anthropicMessagesUrl, openAiModelsUrl,
  anthropicModelsUrl, geminiModelsUrl, geminiGenerateContentUrl
} from './provider-endpoints.js';
import { createSocialRouter } from './social.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
app.use(express.json({ limit: '1mb' }));

const CORS_ORIGINS = (process.env.CORS_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173,capacitor://localhost,https://localhost,http://localhost').split(',').map(x => x.trim()).filter(Boolean);
const ACCESS_SECRET = process.env.TUBOR_ACCESS_TOKEN || '';
app.use('/api', (req, res, next) => {
  const origin = req.headers.origin;
  if (origin && CORS_ORIGINS.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  // Social endpoints use their own per-user signed session token. Do not make
  // sign-up/login depend on a shared secret embedded in the app.
  if (req.path.startsWith('/social/')) return next();
  if (ACCESS_SECRET && req.path !== '/health') {
    const supplied = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const a = Buffer.from(supplied);
    const b = Buffer.from(ACCESS_SECRET);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return res.status(401).json({ error: 'Backend yêu cầu mã truy cập hợp lệ.' });
  }
  next();
});

const PORT = Number(process.env.PORT || 8787);
// Bind only to loopback by default. Public deployments require an access token.
const HOST = process.env.HOST || '127.0.0.1';
const isLoopbackHost = ['127.0.0.1', 'localhost', '::1'].includes(HOST.toLowerCase());
if (!isLoopbackHost && !ACCESS_SECRET) {
  console.error('[TUBOR] Refusing to expose the AI/Lichess proxy without TUBOR_ACCESS_TOKEN. Configure a long random token first.');
  process.exit(1);
}

const aiRateBuckets = new Map();
const AI_RATE_LIMIT_PER_MINUTE = Math.max(10, Math.min(600, Number(process.env.AI_RATE_LIMIT_PER_MINUTE || 120)));
function limitAiCalls(req, res, next) {
  const now = Date.now();
  const key = req.ip || req.socket?.remoteAddress || 'unknown';
  let bucket = aiRateBuckets.get(key);
  if (!bucket || now - bucket.startedAt >= 60_000) bucket = { startedAt: now, count: 0 };
  bucket.count++;
  aiRateBuckets.set(key, bucket);
  if (aiRateBuckets.size > 2000) {
    for (const [ip, item] of aiRateBuckets) if (now - item.startedAt >= 60_000) aiRateBuckets.delete(ip);
  }
  if (bucket.count > AI_RATE_LIMIT_PER_MINUTE) {
    res.setHeader('Retry-After', String(Math.max(1, Math.ceil((60_000 - (now - bucket.startedAt)) / 1000))));
    return res.status(429).json({ error: `Đã vượt giới hạn ${AI_RATE_LIMIT_PER_MINUTE} yêu cầu AI/phút. Hãy đợi rồi thử lại.` });
  }
  next();
}

function sendUpstreamError(res, status, message) {
  return res.status(status).json({ error: message || 'Dịch vụ bên ngoài trả về lỗi.' });
}
function providerLabel(mode, endpoint) {
  try {
    const host = new URL(endpoint).hostname.toLowerCase();
    if (host.includes('generativelanguage.googleapis.com')) return 'Gemini';
    if (host.includes('groq.com')) return 'Groq';
    if (host.includes('openrouter.ai')) return 'OpenRouter';
    if (host.includes('anthropic.com')) return 'Anthropic';
    if (host.includes('deepseek.com')) return 'DeepSeek';
    if (host.includes('openai.com')) return 'OpenAI';
  } catch {}
  return mode === 'gemini' ? 'Gemini' : mode === 'anthropic' ? 'Anthropic' : 'nhà cung cấp đã cấu hình';
}
function cleanString(value, max = 8000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'VILA Chess AI Arena', version: '3.10.1' }));

// Persistent community accounts, friends, Top 100, and owner-only admin tools.
// The store lives outside public/static assets and must be included in backups.
app.use('/api/social', await createSocialRouter({ dataDir: path.join(root, 'data') }));

// Return only the models visible to the caller's own provider account/API key.
// Model IDs are never hard-coded as a substitute for provider discovery.
app.post('/api/ai/models', limitAiCalls, async (req, res) => {
  const mode = cleanString(req.body?.mode || 'openai-compatible', 40).toLowerCase();
  const endpoint = cleanString(req.body?.endpoint, 2000);
  const apiKey = cleanString(req.body?.apiKey, 4000);
  if (!['gemini', 'anthropic', 'openai-compatible'].includes(mode)) return sendUpstreamError(res, 400, 'Loại API không được hỗ trợ để liệt kê model.');
  if (providerKeyRequired(mode, endpoint) && !apiKey) return sendUpstreamError(res, 400, `${providerLabel(mode, endpoint)} cần API key riêng để lấy danh sách model. Chỉ endpoint nội bộ localhost mới có thể bỏ key.`);
  try {
    const models = [];
    let nextPageToken = '';
    let truncated = false;
    const maxPages = mode === 'openai-compatible' ? 1 : 5;
    for (let page = 0; page < maxPages; page++) {
      const currentPageToken = nextPageToken;
      let url;
      const headers = { Accept: 'application/json' };
      if (mode === 'gemini') {
        url = geminiModelsUrl(endpoint, apiKey, nextPageToken);
      } else if (mode === 'anthropic') {
        url = anthropicModelsUrl(endpoint, nextPageToken);
        headers['x-api-key'] = apiKey;
        headers['anthropic-version'] = '2023-06-01';
      } else {
        url = openAiModelsUrl(endpoint);
        if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
      }
      const upstream = await fetch(url, { method: 'GET', headers, signal: AbortSignal.timeout(30000) });
      const raw = await upstream.text();
      let data;
      try { data = JSON.parse(raw); } catch { data = { message: raw.slice(0, 700) }; }
      if (!upstream.ok) {
        const detailValue = data?.error?.message || data?.error || data?.message || `HTTP ${upstream.status}`;
        const detail = String(typeof detailValue === 'string' ? detailValue : JSON.stringify(detailValue));
        const mapped = friendlyProviderFailure(upstream.status, detail, providerLabel(mode, endpoint), apiKey);
        return sendUpstreamError(res, mapped.status, `Không lấy được model. ${mapped.message}`);
      }
      const list = mode === 'gemini' ? (Array.isArray(data?.models) ? data.models : []) : Array.isArray(data?.data) ? data.data : Array.isArray(data?.models) ? data.models : [];
      for (const item of list) {
        const rawId = String(item?.id || item?.name || '').trim();
        const id = mode === 'gemini' ? rawId.replace(/^models\//i, '') : rawId;
        if (!id || (mode === 'gemini' && Array.isArray(item.supportedGenerationMethods) && !item.supportedGenerationMethods.includes('generateContent'))) continue;
        if (!models.some(existing => existing.id === id)) models.push({ id, name: String(item.display_name || item.displayName || item.name || item.id || id), description: String(item.description || '').slice(0, 240), free: isConfirmedFreeModel(item, { mode, endpoint }) ? true : null });
      }
      const hasMore = mode === 'gemini' ? Boolean(data?.nextPageToken) : mode === 'anthropic' ? data?.has_more === true : false;
      nextPageToken = mode === 'gemini' ? String(data?.nextPageToken || '') : mode === 'anthropic' ? String(data?.last_id || '') : '';
      if (!hasMore) break;
      if (page === maxPages - 1 || !nextPageToken || nextPageToken === currentPageToken) {
        truncated = true;
        break;
      }
    }
    // Preserve provider order (often newest-first) instead of sorting away recency.
    if (!models.length) return sendUpstreamError(res, 502, 'Nhà cung cấp phản hồi nhưng không có model tương thích được tìm thấy.');
    res.json({ models, count: models.length, mode, truncated });
  } catch (error) {
    res.status(502).json({ error: `Không lấy được danh sách model: ${String(error?.message || error).slice(0, 400)}` });
  }
});

app.post('/api/ai/chat', limitAiCalls, async (req, res) => {
  const mode = cleanString(req.body?.mode || 'openai-compatible', 40).toLowerCase();
  const endpoint = cleanString(req.body?.endpoint, 2000);
  const apiKey = cleanString(req.body?.apiKey, 4000);
  const model = cleanString(req.body?.model, 200);
  const messages = Array.isArray(req.body?.messages) ? req.body.messages.slice(-24) : [];
  const system = cleanString(req.body?.system, 8000);
  if (!['gemini', 'anthropic', 'openai-compatible'].includes(mode)) return sendUpstreamError(res, 400, 'Loại API không được hỗ trợ.');
  if (!model) return sendUpstreamError(res, 400, 'Hãy nhập tên model AI trong Cài đặt.');
  if (providerKeyRequired(mode, endpoint) && !apiKey) return sendUpstreamError(res, 400, `${providerLabel(mode, endpoint)} cần API key. Hãy nhập key của đúng nhà cung cấp trong Cài đặt.`);
  if (!messages.length) return sendUpstreamError(res, 400, 'Chưa có nội dung để gửi AI.');
  if (messages.some(m => !m || !['user', 'assistant', 'system'].includes(m.role) || typeof m.content !== 'string')) {
    return sendUpstreamError(res, 400, 'Định dạng hội thoại không hợp lệ.');
  }
  try {
    let url;
    let headers = { 'Content-Type': 'application/json' };
    const options = normalizeChatOptions(req.body || {});
    const upstreamTimeoutMs = Math.min(60_000, Math.max(3_000, Number(req.body?.timeoutMs) || 25_000));
    const payload = buildChatPayload({ mode, model, messages, system, ...options });
    if (mode === 'gemini') {
      const base = endpoint ? normalizeBaseUrl(endpoint) : 'https://generativelanguage.googleapis.com';
      if (!apiKey && !/[?&]key=[^&]+/.test(base)) return sendUpstreamError(res, 400, 'Gemini cần API key.');
      url = geminiGenerateContentUrl(base, model, apiKey);
    } else if (mode === 'anthropic') {
      if (!apiKey) return sendUpstreamError(res, 400, 'Anthropic cần API key.');
      url = anthropicMessagesUrl(endpoint || 'https://api.anthropic.com');
      headers['x-api-key'] = apiKey;
      headers['anthropic-version'] = '2023-06-01';
    } else {
      url = openAiChatUrl(endpoint || 'https://api.openai.com/v1');
      if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
    }
    const upstream = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload), signal: AbortSignal.timeout(upstreamTimeoutMs) });
    const contentType = upstream.headers.get('content-type') || '';
    const raw = await upstream.text();
    const data = parseChatResponseBody(raw, contentType, mode);
    if (!upstream.ok) {
      const detail = data?.error?.message || data?.message || `HTTP ${upstream.status}`;
      const mapped = friendlyProviderFailure(upstream.status, detail, providerLabel(mode, endpoint), apiKey);
      return sendUpstreamError(res, mapped.status, mapped.message);
    }
    const text = extractChatText(mode, data);
    if (!text) {
      const hint = getChatEmptyHint(mode, data);
      const finishReason = getChatFinishReason(mode, data);
      console.warn(`[AI chat] Empty textual output for mode=${mode} model=${model} finish=${finishReason}`);
      return sendUpstreamError(res, 502, `API đã phản hồi thành công nhưng chưa có câu trả lời văn bản. ${hint}`);
    }
    res.json({ text, model: data?.model || model, finishReason: getChatFinishReason(mode, data), usage: data?.usage || data?.usageMetadata || null });
  } catch (error) {
    const timedOut = error?.name === 'TimeoutError' || error?.name === 'AbortError';
    const detail = sanitizeProviderDetail(error?.message || error, apiKey);
    res.status(timedOut ? 504 : 502).json({ error: `${timedOut ? 'AI API quá thời gian chờ' : 'Không gọi được AI API'}: ${detail}` });
  }
});

async function lichessRequest(pathname, token, options = {}) {
  const cleanToken = cleanString(token, 4000);
  if (!cleanToken) throw new Error('Hãy nhập Lichess personal access token. Token không được gửi vào mã nguồn công khai.');
  return fetch(`https://lichess.org${pathname}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${cleanToken}`,
      Accept: options.accept || 'application/json',
      ...(options.method === 'POST' ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}),
      ...(options.headers || {})
    },
    signal: options.signal || AbortSignal.timeout(30000)
  });
}

app.post('/api/lichess/account', async (req, res) => {
  try {
    const upstream = await lichessRequest('/api/account', req.body?.token);
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.id, username: data.username, title: data.title || '', perfs: data.perfs || {} });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/challenge-ai', async (req, res) => {
  try {
    const level = Math.max(1, Math.min(8, Number(req.body?.level || 3)));
    const limit = Math.max(0, Math.min(10800, Number(req.body?.clockLimit || 300)));
    const increment = Math.max(0, Math.min(180, Number(req.body?.clockIncrement || 0)));
    const form = new URLSearchParams({ level: String(level), 'clock.limit': String(limit), 'clock.increment': String(increment), color: ['white', 'black', 'random'].includes(req.body?.color) ? req.body.color : 'random' });
    const upstream = await lichessRequest('/api/challenge/ai', req.body?.token, { method: 'POST', body: form.toString() });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.id, url: data.url, color: data.color, status: data.status, raw: data });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/challenge-user', async (req, res) => {
  try {
    const username = cleanString(req.body?.username, 80).replace(/^@/, '');
    if (!/^[a-zA-Z0-9_-]{2,30}$/.test(username)) return res.status(400).json({ error: 'Tên người chơi Lichess không hợp lệ.' });
    const limit = Math.max(0, Math.min(10800, Number(req.body?.clockLimit || 300)));
    const increment = Math.max(0, Math.min(180, Number(req.body?.clockIncrement || 0)));
    const form = new URLSearchParams({ rated: 'false', 'clock.limit': String(limit), 'clock.increment': String(increment), color: ['white', 'black', 'random'].includes(req.body?.color) ? req.body.color : 'random', variant: 'standard' });
    const upstream = await lichessRequest(`/api/challenge/${encodeURIComponent(username)}`, req.body?.token, { method: 'POST', body: form.toString() });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.challenge?.id || data.id, url: data.challenge?.url || data.url, status: data.challenge?.status || data.status, raw: data });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/move', async (req, res) => {
  try {
    const gameId = cleanString(req.body?.gameId, 100);
    const move = cleanString(req.body?.move, 10);
    if (!/^[a-zA-Z0-9]{8}$/.test(gameId)) return res.status(400).json({ error: 'Mã ván Lichess không hợp lệ.' });
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(move)) return res.status(400).json({ error: 'Nước đi phải ở định dạng UCI, ví dụ e2e4.' });
    const apiMode = req.body?.apiMode === 'bot' ? 'bot' : 'board';
    const route = apiMode === 'bot' ? `/api/bot/game/${gameId}/move/${move}` : `/api/board/game/${gameId}/move/${move}`;
    const upstream = await lichessRequest(route, req.body?.token, { method: 'POST', body: '' });
    const text = await upstream.text();
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, text || `Lichess HTTP ${upstream.status}`);
    res.json({ ok: true, response: text });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/stream', async (req, res) => {
  const upstreamController = new AbortController();
  let upstreamStream = null;
  // Aborting the response must also abort the fetch. Calling body.cancel()
  // after Readable.fromWeb locks the WebStream is not reliable.
  const abortUpstream = () => {
    if (!upstreamController.signal.aborted) upstreamController.abort();
    if (upstreamStream && !upstreamStream.destroyed) upstreamStream.destroy();
  };
  res.once('close', abortUpstream);
  try {
    const gameId = cleanString(req.body?.gameId, 100);
    if (!/^[a-zA-Z0-9]{8}$/.test(gameId)) return res.status(400).json({ error: 'Mã ván Lichess không hợp lệ.' });
    const apiMode = req.body?.apiMode === 'bot' ? 'bot' : 'board';
    const route = apiMode === 'bot' ? `/api/bot/game/stream/${gameId}` : `/api/board/game/stream/${gameId}`;
    const upstream = await lichessRequest(route, req.body?.token, { method: 'GET', accept: 'application/x-ndjson', signal: upstreamController.signal });
    if (upstreamController.signal.aborted) return;
    if (!upstream.ok || !upstream.body) {
      const message = await upstream.text().catch(() => 'Lichess không mở được luồng ván cờ.');
      if (!res.destroyed) return sendUpstreamError(res, upstream.status || 502, message.slice(0, 500));
      return;
    }
    res.status(200);
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    upstreamStream = Readable.fromWeb(upstream.body);
    upstreamStream.on('error', error => {
      if (upstreamController.signal.aborted || res.destroyed) return;
      if (!res.headersSent) res.status(502).json({ error: `Luồng Lichess bị lỗi: ${String(error.message || error).slice(0, 300)}` });
      else res.destroy(error);
    });
    upstreamStream.pipe(res);
  } catch (error) {
    if (upstreamController.signal.aborted || error?.name === 'AbortError' || res.destroyed) return;
    if (!res.headersSent) res.status(400).json({ error: String(error.message || error) });
    else res.destroy(error);
  }
});

app.get('/api/openings/explorer', async (req, res) => {
  try {
    const moves = cleanString(req.query.moves, 1000).split(',').filter(Boolean).slice(0, 40);
    if (moves.some(m => !/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(m))) return res.status(400).json({ error: 'Danh sách nước UCI không hợp lệ.' });
    const url = new URL('https://explorer.lichess.ovh/lichess');
    url.searchParams.set('variant', 'standard');
    url.searchParams.set('speeds[]', 'blitz');
    url.searchParams.set('ratings[]', '1600');
    url.searchParams.set('moves', moves.join(','));
    const upstream = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Opening Explorer HTTP ${upstream.status}`);
    res.json(data);
  } catch (error) { res.status(502).json({ error: `Không lấy được dữ liệu khai cuộc: ${String(error.message || error)}` }); }
});

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(root, 'dist')));
  app.get('/{*splat}', (_req, res) => res.sendFile(path.join(root, 'dist', 'index.html')));
}

const httpServer = app.listen(PORT, HOST, () => {
  console.log(`[VILA Chess] API server listening on http://${HOST}:${PORT}`);
  if (process.env.NODE_ENV === 'production') console.log('[VILA Chess] Production mode: serving dist/');
});

let shutdownStarted = false;
function gracefulShutdown(reason, exitCode = 0) {
  if (shutdownStarted) return;
  shutdownStarted = true;
  console.error(`[VILA Chess] Shutdown requested (${reason}); closing HTTP listener.`);
  const hardStop = setTimeout(() => process.exit(exitCode || 1), 10_000);
  hardStop.unref();
  httpServer.close(() => { clearTimeout(hardStop); process.exit(exitCode); });
}
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('unhandledRejection', reason => {
  console.error('[VILA Chess] Unhandled promise rejection; terminating so the process manager can restart safely:', reason);
  gracefulShutdown('unhandledRejection', 1);
});
process.on('uncaughtException', error => {
  console.error('[VILA Chess] Uncaught exception; terminating so the process manager can restart safely:', error);
  gracefulShutdown('uncaughtException', 1);
});
