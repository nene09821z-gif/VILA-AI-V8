import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomBytes, randomUUID, scrypt as scryptCallback, createHmac, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCallback);
const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,24}$/;
const TOKEN_TTL_SECONDS = 7 * 24 * 60 * 60;
const asText = (value, max = 120) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && timingSafeEqual(aa, bb);
};
function maskedAddress(req) {
  const value = String(req.ip || req.socket?.remoteAddress || '').replace(/^::ffff:/, '');
  if (value.includes('.')) return value.split('.').slice(0, 3).join('.') + '.x';
  return value.includes(':') ? value.split(':').slice(0, 4).join(':') + ':…' : 'unknown';
}
function hashAddress(req) {
  return createHash('sha256').update(maskedAddress(req)).digest('hex').slice(0, 16);
}
function publicUser(user) {
  return {
    id: user.id, username: user.username, displayName: user.displayName,
    bio: user.bio || '', role: user.role === 'admin' ? 'admin' : 'player',
    elo: Number(user.elo) || 1200, games: Number(user.games) || 0,
    wins: Number(user.wins) || 0, draws: Number(user.draws) || 0, losses: Number(user.losses) || 0,
    createdAt: user.createdAt, lastSeenAt: user.lastSeenAt || null,
    online: Boolean(user.lastSeenAt && Date.now() - new Date(user.lastSeenAt).getTime() < 90_000),
    banned: Boolean(user.banned)
  };
}

export async function createSocialRouter({ dataDir }) {
  const router = express.Router();
  const dbPath = path.join(dataDir, 'social-store.json');
  await fs.mkdir(dataDir, { recursive: true });
  let db;
  try {
    db = JSON.parse(await fs.readFile(dbPath, 'utf8'));
  } catch (error) {
    if (error?.code === 'ENOENT') {
      db = {};
    } else {
      // Fail closed on corrupted/unreadable data. Never overwrite the only copy
      // of account data with an empty store during automatic startup recovery.
      throw new Error(`[VILA social] Cannot read ${dbPath}; refusing to replace potentially recoverable account data. Restore a verified backup or repair the JSON file. Cause: ${error.message}`);
    }
  }
  if (!db || typeof db !== 'object' || Array.isArray(db)) {
    throw new Error(`[VILA social] Invalid store structure at ${dbPath}; refusing to reset account data automatically.`);
  }
  db.users = Array.isArray(db.users) ? db.users : [];
  db.friendRequests = Array.isArray(db.friendRequests) ? db.friendRequests : [];
  db.audit = Array.isArray(db.audit) ? db.audit : [];
  db.matches = Array.isArray(db.matches) ? db.matches : [];
  const externalTokenSecret = String(process.env.SOCIAL_TOKEN_SECRET || '');
  if (externalTokenSecret && Buffer.byteLength(externalTokenSecret, 'utf8') < 32) {
    throw new Error('[VILA social] SOCIAL_TOKEN_SECRET must be at least 32 bytes; generate a random secret and configure it in private server secrets.');
  }
  if (externalTokenSecret) {
    // Keep environment-provided secrets out of the persisted JSON account store.
    delete db.tokenSecret;
  } else if (typeof db.tokenSecret !== 'string' || Buffer.byteLength(db.tokenSecret, 'utf8') < 32) {
    db.tokenSecret = randomBytes(48).toString('base64url');
  }
  const tokenSecret = externalTokenSecret || db.tokenSecret;
  let writeQueue = Promise.resolve();
  const persist = () => {
    const snapshot = JSON.stringify(db, null, 2);
    writeQueue = writeQueue.catch(() => {}).then(async () => {
      const tempPath = `${dbPath}.${process.pid}.tmp`;
      await fs.writeFile(tempPath, snapshot, { mode: 0o600 });
      await fs.rename(tempPath, dbPath);
      try { await fs.chmod(dbPath, 0o600); } catch {}
    });
    return writeQueue;
  };
  const audit = async (req, actor, action, target = '', detail = '') => {
    db.audit.push({ id: randomUUID(), at: new Date().toISOString(), actor: actor || 'system', action, target: String(target).slice(0, 100), detail: String(detail).slice(0, 300), source: hashAddress(req) });
    db.audit = db.audit.slice(-2000);
    await persist();
  };

  // Bootstrap an administrator only from private deployment environment variables.
  // Never ship a default password or promote a user based on a client-supplied role.
  const adminUsername = asText(process.env.ADMIN_USERNAME, 24).toLowerCase();
  const adminPassword = String(process.env.ADMIN_PASSWORD || '');
  const adminEmail = asText(process.env.ADMIN_EMAIL, 254).toLowerCase();
  if (adminUsername && adminPassword) {
    if (!USERNAME_RE.test(adminUsername) || adminPassword.length < 14) {
      console.error('[VILA social] Admin bootstrap skipped: ADMIN_USERNAME must be 3–24 valid characters and ADMIN_PASSWORD must be at least 14 characters.');
    } else {
      let admin = db.users.find(u => u.username.toLowerCase() === adminUsername);
      if (!admin) {
        const salt = randomBytes(16).toString('hex');
        const hash = await scrypt(adminPassword, salt, 64);
        admin = { id: randomUUID(), username: adminUsername, displayName: 'VILA Admin', email: emailPattern.test(adminEmail) ? adminEmail : '', bio: 'Quản trị viên nền tảng', salt, passwordHash: Buffer.from(hash).toString('hex'), role: 'admin', elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, banned: false, createdAt: new Date().toISOString(), lastSeenAt: null, lastSeenPersistedAt: 0 };
        db.users.push(admin);
        await audit({ ip: 'system' }, 'system', 'admin_bootstrap_created', admin.id, `username=${adminUsername}`);
        console.log(`[VILA social] Bootstrap administrator created: ${adminUsername}. Password is not logged.`);
      } else if (admin.role !== 'admin') {
        // Never elevate a pre-existing username blindly: an attacker could have
        // registered it before deployment secrets were configured.
        let matchesConfiguredPassword = false;
        if (admin.salt && admin.passwordHash) {
          const configuredHash = Buffer.from(await scrypt(adminPassword, admin.salt, 64)).toString('hex');
          matchesConfiguredPassword = safeEqual(configuredHash, admin.passwordHash);
        }
        if (matchesConfiguredPassword) {
          admin.role = 'admin';
          admin.banned = false;
          admin.banReason = '';
          if (emailPattern.test(adminEmail)) admin.email = adminEmail;
          await audit({ ip: 'system' }, 'system', 'admin_bootstrap_promoted', admin.id, `username=${adminUsername}`);
        } else {
          console.error(`[VILA social] Admin bootstrap refused: username ${adminUsername} already exists with a different password. Choose a new ADMIN_USERNAME or perform an authenticated admin recovery.`);
        }
      }
    }
  } else if (!db.users.some(u => u.role === 'admin')) {
    console.warn('[VILA social] No admin exists. Set ADMIN_USERNAME and ADMIN_PASSWORD (14+ chars) in private server environment to bootstrap one.');
  }
  await persist();

  const limits = new Map();
  const oauthStates = new Map();
  function rateLimit({ name, max, windowMs }) {
    return (req, res, next) => {
      const key = `${name}:${req.ip || req.socket?.remoteAddress || 'unknown'}`;
      const now = Date.now();
      let item = limits.get(key);
      if (!item || now - item.start >= windowMs) item = { start: now, count: 0 };
      item.count += 1; limits.set(key, item);
      if (limits.size > 5000) for (const [k, v] of limits) if (now - v.start > windowMs) limits.delete(k);
      if (item.count > max) {
        res.setHeader('Retry-After', String(Math.max(1, Math.ceil((windowMs - (now - item.start)) / 1000))));
        return res.status(429).json({ error: 'Quá nhiều yêu cầu. Hãy chờ một chút rồi thử lại.' });
      }
      next();
    };
  }
  router.use(rateLimit({ name: 'all', max: 300, windowMs: 60_000 }));
  router.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  function signToken(user) {
    const now = Math.floor(Date.now() / 1000);
    const payload = Buffer.from(JSON.stringify({ sub: user.id, ver: Number(user.sessionVersion) || 0, iat: now, exp: now + TOKEN_TTL_SECONDS })).toString('base64url');
    const sig = createHmac('sha256', tokenSecret).update(payload).digest('base64url');
    return `${payload}.${sig}`;
  }
  function verifyToken(token) {
    const [payload, sig, extra] = String(token || '').split('.');
    if (!payload || !sig || extra) return null;
    const expected = createHmac('sha256', tokenSecret).update(payload).digest('base64url');
    if (!safeEqual(sig, expected)) return null;
    try {
      const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
      if (!data.sub || !Number.isFinite(data.exp) || data.exp <= Date.now() / 1000) return null;
      return data;
    } catch { return null; }
  }
  async function requireAuth(req, res, next) {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const payload = verifyToken(token);
    if (!payload) return res.status(401).json({ error: 'Phiên đăng nhập hết hạn hoặc không hợp lệ. Hãy đăng nhập lại.' });
    const user = db.users.find(u => u.id === payload.sub);
    if (!user || user.banned) return res.status(403).json({ error: user?.banned ? 'Tài khoản đã bị khóa. Liên hệ quản trị viên để khiếu nại.' : 'Không tìm thấy tài khoản.' });
    if ((Number(payload.ver) || 0) !== (Number(user.sessionVersion) || 0)) return res.status(401).json({ error: 'Phiên đăng nhập đã bị thu hồi. Hãy đăng nhập lại.' });
    req.socialUser = user;
    user.lastSeenAt = new Date().toISOString();
    if (Date.now() - Number(user.lastSeenPersistedAt || 0) > 60_000) {
      user.lastSeenPersistedAt = Date.now();
      persist().catch(error => console.error('[VILA social] presence persistence error:', error.message));
    }
    next();
  }
  const requireAdmin = (req, res, next) => {
    if (req.socialUser?.role !== 'admin') return res.status(403).json({ error: 'Chỉ quản trị viên mới được truy cập khu vực này.' });
    next();
  };
  const findUser = username => db.users.find(u => u.username.toLowerCase() === String(username).toLowerCase());

  router.get('/health', (_req, res) => {
    res.json({ ok: true, service: 'VILA Chess social', status: 'online', timestamp: new Date().toISOString() });
  });

  router.post('/auth/register', rateLimit({ name: 'register', max: 5, windowMs: 60 * 60_000 }), async (req, res) => {
    const username = asText(req.body?.username, 24).toLowerCase();
    const displayName = asText(req.body?.displayName || username, 40);
    const email = asText(req.body?.email, 254).toLowerCase();
    const password = String(req.body?.password || '');
    if (!USERNAME_RE.test(username)) return res.status(400).json({ error: 'Tên đăng nhập cần 3–24 ký tự: chữ, số, dấu chấm, gạch dưới hoặc gạch ngang.' });
    if (displayName.length < 2) return res.status(400).json({ error: 'Tên hiển thị cần ít nhất 2 ký tự.' });
    if (password.length < 12 || password.length > 256) return res.status(400).json({ error: 'Mật khẩu cần dài từ 12 đến 256 ký tự.' });
    if (email && !emailPattern.test(email)) return res.status(400).json({ error: 'Email không hợp lệ.' });
    if (findUser(username)) return res.status(409).json({ error: 'Tên đăng nhập đã được sử dụng.' });
    const salt = randomBytes(16).toString('hex');
    const hash = await scrypt(password, salt, 64);
    const user = { id: randomUUID(), username, displayName, email, bio: '', salt, passwordHash: Buffer.from(hash).toString('hex'), role: 'player', elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, banned: false, createdAt: new Date().toISOString(), lastSeenAt: new Date().toISOString(), lastSeenPersistedAt: Date.now() };
    db.users.push(user);
    await audit(req, user.id, 'account_registered', user.id, 'local password account');
    res.status(201).json({ token: signToken(user), user: publicUser(user) });
  });

  router.post('/auth/login', rateLimit({ name: 'login', max: 12, windowMs: 15 * 60_000 }), async (req, res) => {
    const username = asText(req.body?.username, 254).toLowerCase();
    const password = String(req.body?.password || '');
    if (!username || !password || password.length > 256) return res.status(400).json({ error: 'Nhập tên đăng nhập và mật khẩu.' });
    const user = findUser(username) || db.users.find(u => u.email && u.email.toLowerCase() === username);
    if (!user || !user.salt || !user.passwordHash) {
      // Keep failed-login response generic to avoid exposing registered usernames.
      await audit(req, 'anonymous', 'login_failed', username, 'invalid credentials');
      return res.status(401).json({ error: 'Tên đăng nhập/email hoặc mật khẩu không đúng.' });
    }
    const candidate = Buffer.from(await scrypt(password, user.salt, 64)).toString('hex');
    if (!safeEqual(candidate, user.passwordHash)) {
      await audit(req, 'anonymous', 'login_failed', user.id, 'invalid credentials');
      return res.status(401).json({ error: 'Tên đăng nhập/email hoặc mật khẩu không đúng.' });
    }
    if (user.banned) return res.status(403).json({ error: 'Tài khoản đã bị khóa. Liên hệ quản trị viên để khiếu nại.' });
    user.lastSeenAt = new Date().toISOString();
    user.lastSeenPersistedAt = Date.now();
    await audit(req, user.id, 'login_success', user.id, 'password login');
    res.json({ token: signToken(user), user: publicUser(user) });
  });

  function oauthConfig(provider) {
    if (provider === 'google') return { clientId: process.env.GOOGLE_CLIENT_ID || '', clientSecret: process.env.GOOGLE_CLIENT_SECRET || '' };
    if (provider === 'github') return { clientId: process.env.GITHUB_CLIENT_ID || '', clientSecret: process.env.GITHUB_CLIENT_SECRET || '' };
    return null;
  }
  function socialPublicUrl() {
    const value = String(process.env.SOCIAL_PUBLIC_URL || process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
    if (!value) return '';
    try { const url = new URL(value); if (!['http:', 'https:'].includes(url.protocol)) return ''; if (process.env.NODE_ENV === 'production' && url.protocol !== 'https:') return ''; return url.origin; } catch { return ''; }
  }
  function frontendReturnUrl(token = '', error = '') {
    const configured = process.env.SOCIAL_FRONTEND_URL || (process.env.NODE_ENV === 'production' ? socialPublicUrl() : 'http://localhost:5173/');
    let url;
    try { url = new URL(configured || '/'); } catch { url = new URL('/', 'http://localhost:5173'); }
    if (!['http:', 'https:'].includes(url.protocol)) url = new URL('/', 'http://localhost:5173');
    if (process.env.NODE_ENV === 'production' && url.protocol !== 'https:') { const fallback = socialPublicUrl(); url = fallback ? new URL(fallback) : new URL('https://localhost/'); }
    url.hash = token ? `social_token=${encodeURIComponent(token)}` : error ? `social_error=${encodeURIComponent(error.slice(0, 180))}` : '';
    return url.toString();
  }
  function safeOAuthUsername(provider, identity) {
    let base = asText(identity.username || identity.name || provider + 'player', 40).normalize('NFKD').replace(/[^a-zA-Z0-9_.-]/g, '').toLowerCase().slice(0, 18);
    if (base.length < 3) base = `${provider}player`;
    let username = base;
    while (findUser(username)) username = `${base.slice(0, 16)}${randomBytes(2).toString('hex')}`;
    return username;
  }
  async function upsertOAuthUser(provider, identity) {
    let user = db.users.find(item => item.oauthProviders?.[provider]?.id === String(identity.id));
    if (user) {
      if (user.banned) throw new Error('Tài khoản đã bị khóa. Liên hệ quản trị viên để khiếu nại.');
      user.lastSeenAt = new Date().toISOString();
      user.lastSeenPersistedAt = Date.now();
      await audit({ ip: 'oauth' }, user.id, 'oauth_login_success', user.id, provider);
      return user;
    }
    const email = identity.emailVerified && emailPattern.test(String(identity.email || '')) ? String(identity.email).toLowerCase() : '';
    // Do not silently merge two identities by email. Account linking must be an explicit authenticated action.
    if (email && db.users.some(item => item.email && item.email.toLowerCase() === email)) {
      throw new Error('Email này đã có tài khoản VILA Chess. Hãy đăng nhập tài khoản hiện có; việc liên kết tài khoản sẽ cần xác thực bổ sung.');
    }
    user = { id: randomUUID(), username: safeOAuthUsername(provider, identity), displayName: asText(identity.name || identity.username || provider, 40) || provider, email, bio: '', salt: '', passwordHash: '', oauthProviders: { [provider]: { id: String(identity.id) } }, role: 'player', elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, banned: false, createdAt: new Date().toISOString(), lastSeenAt: new Date().toISOString(), lastSeenPersistedAt: Date.now() };
    db.users.push(user);
    await audit({ ip: 'oauth' }, user.id, 'oauth_account_created', user.id, provider);
    return user;
  }
  router.get('/auth/oauth/:provider/start', rateLimit({ name: 'oauth-start', max: 20, windowMs: 15 * 60_000 }), (req, res) => {
    const provider = asText(req.params.provider, 12).toLowerCase();
    if (!['google', 'github'].includes(provider)) return res.status(404).json({ error: 'Nhà cung cấp OAuth không được hỗ trợ.' });
    const config = oauthConfig(provider);
    if (!config?.clientId || !config?.clientSecret) return res.status(503).json({ error: `Đăng nhập ${provider} chưa được cấu hình trên máy chủ. Hãy thiết lập client ID/secret và callback URL.` });
    const publicUrl = socialPublicUrl();
    if (!publicUrl) return res.status(503).json({ error: 'Máy chủ thiếu SOCIAL_PUBLIC_URL (URL HTTPS công khai của backend). Chưa thể bật OAuth.' });
    const state = randomBytes(32).toString('base64url');
    oauthStates.set(state, { provider, createdAt: Date.now() });
    const secureCookie = process.env.NODE_ENV === 'production' ? '; Secure' : '';
    res.setHeader('Set-Cookie', `vila_oauth_state=${state}; Max-Age=600; Path=/api/social/auth/oauth; HttpOnly; SameSite=Lax${secureCookie}`);
    for (const [key, val] of oauthStates) if (Date.now() - val.createdAt > 10 * 60_000) oauthStates.delete(key);
    const redirectUri = `${publicUrl}/api/social/auth/oauth/${provider}/callback`;
    const url = provider === 'google'
      ? new URL('https://accounts.google.com/o/oauth2/v2/auth')
      : new URL('https://github.com/login/oauth/authorize');
    url.searchParams.set('client_id', config.clientId);
    url.searchParams.set('redirect_uri', redirectUri);
    url.searchParams.set('state', state);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('scope', provider === 'google' ? 'openid email profile' : 'read:user user:email');
    if (provider === 'google') url.searchParams.set('prompt', 'select_account');
    res.redirect(url.toString());
  });

  async function completeOAuth(provider, req, res) {
    const state = asText(req.query?.state, 200);
    const cookieHeader = String(req.headers.cookie || '');
    const cookieMatch = cookieHeader.match(/(?:^|;\s*)vila_oauth_state=([A-Za-z0-9_-]+)/);
    const cookieState = cookieMatch?.[1] || '';
    const stateData = oauthStates.get(state);
    oauthStates.delete(state);
    const secureCookie = process.env.NODE_ENV === 'production' ? '; Secure' : '';
    res.setHeader('Set-Cookie', `vila_oauth_state=; Max-Age=0; Path=/api/social/auth/oauth; HttpOnly; SameSite=Lax${secureCookie}`);
    if (!stateData || !cookieState || !safeEqual(state, cookieState) || stateData.provider !== provider || Date.now() - stateData.createdAt > 10 * 60_000) return res.redirect(frontendReturnUrl('', 'Phiên OAuth hết hạn hoặc không hợp lệ. Hãy thử lại.'));
    if (req.query?.error) return res.redirect(frontendReturnUrl('', 'Bạn đã hủy hoặc nhà cung cấp từ chối đăng nhập.'));
    const code = asText(req.query?.code, 2000);
    if (!code) return res.redirect(frontendReturnUrl('', 'Nhà cung cấp không trả authorization code.'));
    const config = oauthConfig(provider);
    const publicUrl = socialPublicUrl();
    const redirectUri = `${publicUrl}/api/social/auth/oauth/${provider}/callback`;
    try {
      let identity;
      if (provider === 'google') {
        const tokenResponse = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code, client_id: config.clientId, client_secret: config.clientSecret, redirect_uri: redirectUri, grant_type: 'authorization_code' }), signal: AbortSignal.timeout(15000) });
        const tokenData = await tokenResponse.json().catch(() => ({}));
        if (!tokenResponse.ok || !tokenData.access_token) throw new Error('Google không chấp nhận mã đăng nhập. Kiểm tra callback URL và OAuth client.');
        const infoResponse = await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
        const info = await infoResponse.json().catch(() => ({}));
        if (!infoResponse.ok || !info.sub) throw new Error('Không xác minh được hồ sơ Google.');
        identity = { id: info.sub, name: info.name || info.given_name || 'Google player', email: info.email || '', emailVerified: info.email_verified === true, username: `google${String(info.sub).slice(-8)}` };
      } else {
        const tokenResponse = await fetch('https://github.com/login/oauth/access_token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' }, body: new URLSearchParams({ code, client_id: config.clientId, client_secret: config.clientSecret, redirect_uri: redirectUri }), signal: AbortSignal.timeout(15000) });
        const tokenData = await tokenResponse.json().catch(() => ({}));
        if (!tokenResponse.ok || !tokenData.access_token) throw new Error('GitHub không chấp nhận mã đăng nhập. Kiểm tra callback URL và OAuth App.');
        const headers = { Authorization: `Bearer ${tokenData.access_token}`, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'VILA-Chess' };
        const userResponse = await fetch('https://api.github.com/user', { headers, signal: AbortSignal.timeout(15000) });
        const info = await userResponse.json().catch(() => ({}));
        if (!userResponse.ok || !info.id) throw new Error('Không xác minh được hồ sơ GitHub.');
        const emailResponse = await fetch('https://api.github.com/user/emails', { headers, signal: AbortSignal.timeout(15000) });
        const emails = emailResponse.ok ? await emailResponse.json().catch(() => []) : [];
        const verifiedEmail = Array.isArray(emails) ? emails.find(item => item.primary && item.verified)?.email || emails.find(item => item.verified)?.email || '' : '';
        identity = { id: info.id, name: info.name || info.login || 'GitHub player', username: info.login || '', email: verifiedEmail || '', emailVerified: Boolean(verifiedEmail) };
      }
      const user = await upsertOAuthUser(provider, identity);
      await persist();
      return res.redirect(frontendReturnUrl(signToken(user)));
    } catch (error) {
      const message = String(error?.message || error).slice(0, 180);
      await audit(req, 'anonymous', 'oauth_login_failed', provider, message).catch(() => {});
      return res.redirect(frontendReturnUrl('', message));
    }
  }
  router.get('/auth/oauth/google/callback', rateLimit({ name: 'oauth-callback-google', max: 30, windowMs: 15 * 60_000 }), (req, res) => completeOAuth('google', req, res));
  router.get('/auth/oauth/github/callback', rateLimit({ name: 'oauth-callback-github', max: 30, windowMs: 15 * 60_000 }), (req, res) => completeOAuth('github', req, res));

  router.get('/auth/me', requireAuth, (req, res) => res.json({ user: publicUser(req.socialUser) }));
  router.patch('/profile', requireAuth, async (req, res) => {
    const displayName = asText(req.body?.displayName, 40);
    const bio = asText(req.body?.bio, 180);
    if (displayName.length < 2) return res.status(400).json({ error: 'Tên hiển thị cần ít nhất 2 ký tự.' });
    req.socialUser.displayName = displayName;
    req.socialUser.bio = bio;
    await persist();
    res.json({ user: publicUser(req.socialUser) });
  });

  router.get('/users/search', requireAuth, (req, res) => {
    const q = asText(req.query.q, 30).toLowerCase();
    if (q.length < 2) return res.status(400).json({ error: 'Nhập ít nhất 2 ký tự để tìm người chơi.' });
    const results = db.users.filter(u => !u.banned && u.id !== req.socialUser.id && (u.username.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q))).slice(0, 20).map(publicUser);
    res.json({ users: results });
  });

  router.get('/friends', requireAuth, (req, res) => {
    const userId = req.socialUser.id;
    const accepted = db.friendRequests.filter(r => r.status === 'accepted' && (r.from === userId || r.to === userId));
    const incoming = db.friendRequests.filter(r => r.status === 'pending' && r.to === userId).map(r => ({ id: r.id, createdAt: r.createdAt, user: publicUser(db.users.find(u => u.id === r.from) || { id: '', username: 'unknown', displayName: 'Tài khoản không tồn tại' }) }));
    const outgoing = db.friendRequests.filter(r => r.status === 'pending' && r.from === userId).map(r => ({ id: r.id, createdAt: r.createdAt, user: publicUser(db.users.find(u => u.id === r.to) || { id: '', username: 'unknown', displayName: 'Tài khoản không tồn tại' }) }));
    const friends = accepted.map(r => db.users.find(u => u.id === (r.from === userId ? r.to : r.from))).filter(Boolean).filter(u => !u.banned).map(publicUser).sort((a, b) => Number(b.online) - Number(a.online) || a.displayName.localeCompare(b.displayName));
    res.json({ friends, incoming, outgoing });
  });

  router.post('/friends/request', requireAuth, async (req, res) => {
    const username = asText(req.body?.username, 24).toLowerCase();
    const target = findUser(username);
    if (!target || target.banned) return res.status(404).json({ error: 'Không tìm thấy người chơi này.' });
    if (target.id === req.socialUser.id) return res.status(400).json({ error: 'Bạn không thể tự kết bạn với mình.' });
    let existing = db.friendRequests.find(r => (r.from === req.socialUser.id && r.to === target.id) || (r.from === target.id && r.to === req.socialUser.id));
    if (existing?.status === 'accepted') return res.status(409).json({ error: 'Hai bạn đã là bạn bè.' });
    if (existing?.status === 'pending' && existing.from === target.id) {
      existing.status = 'accepted'; existing.updatedAt = new Date().toISOString();
      await audit(req, req.socialUser.id, 'friend_request_auto_accepted', target.id, 'reciprocal request');
      return res.json({ message: 'Đã chấp nhận lời mời đang chờ; hai bạn đã là bạn bè.' });
    }
    if (existing?.status === 'pending') return res.status(409).json({ error: 'Lời mời kết bạn đã được gửi.' });
    existing = { id: randomUUID(), from: req.socialUser.id, to: target.id, status: 'pending', createdAt: new Date().toISOString(), updatedAt: null };
    db.friendRequests.push(existing);
    await audit(req, req.socialUser.id, 'friend_request_sent', target.id, 'pending');
    res.status(201).json({ message: `Đã gửi lời mời kết bạn tới @${target.username}.` });
  });

  router.post('/friends/:requestId/accept', requireAuth, async (req, res) => {
    const item = db.friendRequests.find(r => r.id === req.params.requestId && r.to === req.socialUser.id && r.status === 'pending');
    if (!item) return res.status(404).json({ error: 'Không tìm thấy lời mời đang chờ.' });
    item.status = 'accepted'; item.updatedAt = new Date().toISOString();
    await audit(req, req.socialUser.id, 'friend_request_accepted', item.from, 'accepted');
    res.json({ message: 'Đã thêm bạn bè.' });
  });

  router.delete('/friends/:friendId', requireAuth, async (req, res) => {
    const userId = req.socialUser.id;
    const before = db.friendRequests.length;
    db.friendRequests = db.friendRequests.filter(r => !((r.from === userId && r.to === req.params.friendId) || (r.from === req.params.friendId && r.to === userId)));
    if (before === db.friendRequests.length) return res.status(404).json({ error: 'Không tìm thấy bạn bè/lời mời tương ứng.' });
    await audit(req, userId, 'friend_relation_removed', req.params.friendId, 'removed relationship or request');
    res.json({ message: 'Đã cập nhật danh sách bạn bè.' });
  });

  router.get('/leaderboard', (req, res) => {
    const limit = Math.max(1, Math.min(100, Number(req.query.limit) || 100));
    const users = db.users.filter(u => !u.banned).sort((a, b) => (Number(b.elo) || 1200) - (Number(a.elo) || 1200) || (Number(b.games) || 0) - (Number(a.games) || 0) || a.createdAt.localeCompare(b.createdAt));
    res.json({ users: users.slice(0, limit).map((u, index) => ({ rank: index + 1, ...publicUser(u) })), totalPlayers: users.length, generatedAt: new Date().toISOString(), source: 'server' });
  });

  router.get('/admin/overview', requireAuth, requireAdmin, (_req, res) => {
    const mem = process.memoryUsage();
    res.json({ users: db.users.length, activeUsers: db.users.filter(u => !u.banned && u.lastSeenAt && Date.now() - new Date(u.lastSeenAt).getTime() < 90_000).length, bannedUsers: db.users.filter(u => u.banned).length, admins: db.users.filter(u => u.role === 'admin' && !u.banned).length, pendingFriendRequests: db.friendRequests.filter(r => r.status === 'pending').length, uptimeSeconds: Math.floor(process.uptime()), node: process.version, platform: process.platform, arch: process.arch, cpus: os.cpus().length, loadAverage: os.loadavg().map(n => Number(n.toFixed(2))), memory: { rssMb: Math.round(mem.rss / 1048576), heapUsedMb: Math.round(mem.heapUsed / 1048576), heapTotalMb: Math.round(mem.heapTotal / 1048576), systemFreeMb: Math.round(os.freemem() / 1048576), systemTotalMb: Math.round(os.totalmem() / 1048576) }, db: { users: db.users.length, friendRequests: db.friendRequests.length, auditEvents: db.audit.length } });
  });

  router.get('/admin/users', requireAuth, requireAdmin, (req, res) => {
    const q = asText(req.query.q, 80).toLowerCase();
    const users = db.users.filter(u => !q || u.username.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q) || String(u.email || '').toLowerCase().includes(q)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 200).map(u => ({ ...publicUser(u), email: u.email || '' }));
    res.json({ users, total: db.users.length });
  });

  router.patch('/admin/users/:id', requireAuth, requireAdmin, async (req, res) => {
    const target = db.users.find(u => u.id === req.params.id);
    if (!target) return res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
    if (target.id === req.socialUser.id) return res.status(400).json({ error: 'Không thể khóa hoặc đổi quyền tài khoản đang đăng nhập.' });
    if (target.role === 'admin') return res.status(403).json({ error: 'Không thể tác động tài khoản admin khác qua bảng quản lý người dùng.' });
    const action = asText(req.body?.action, 20);
    if (action === 'ban') {
      target.sessionVersion = (Number(target.sessionVersion) || 0) + 1;
      target.banned = true;
      target.banReason = asText(req.body?.reason || 'Vi phạm quy định cộng đồng', 180);
      target.bannedAt = new Date().toISOString();
    } else if (action === 'unban') {
      target.banned = false; target.banReason = ''; target.bannedAt = null;
    } else return res.status(400).json({ error: 'Hành động chỉ được là ban hoặc unban.' });
    await audit(req, req.socialUser.id, `user_${action}ned`, target.id, target.banReason || 'unbanned');
    res.json({ user: publicUser(target), message: action === 'ban' ? 'Đã khóa tài khoản.' : 'Đã mở khóa tài khoản.' });
  });

  router.get('/admin/audit', requireAuth, requireAdmin, (req, res) => {
    const limit = Math.max(1, Math.min(200, Number(req.query.limit) || 100));
    res.json({ events: db.audit.slice(-limit).reverse() });
  });

  return router;
}
