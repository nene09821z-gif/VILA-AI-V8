/** Validated, migration-safe settings for browser storage and Android WebView. */
export const DEFAULTS = Object.freeze({
  aiMode: 'gemini',
  endpoint: 'https://generativelanguage.googleapis.com',
  model: 'gemini-3.8-flash',
  apiKey: '',
  aiProfiles: [],
  backendUrl: '',
  backendAccessToken: '',
  temperature: 0.3,
  botSkill: 20,
  botStrengthMode: 'max',
  botElo: 2600,
  botDepth: 18,
  botMoveTimeMs: 1200,
  analysisMoveTimeMs: 2600,
  clockPreset: '10+0',
  botEngine: 'auto',
  botEnginePreferenceSet: false,
  assistantName: 'VILA Chess AI',
  openingBookEnabled: true,
  soundEnabled: true,
  coachEngineMode: 'api'
});

const AI_MODES = new Set(['gemini', 'anthropic', 'openai-compatible']);
const ENGINE_MODES = new Set(['auto', 'lite-single', 'full-single']);
const PROFILE_MODES = new Set(['gemini', 'anthropic', 'openai-compatible']);

function cleanText(value, fallback, max = 4000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : fallback;
}
function clampNumber(value, fallback, min, max) {
  if (value === null || value === '' || typeof value === 'boolean') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
function cleanHttpUrl(value, fallback = '') {
  const candidate = cleanText(value, fallback, 2000);
  if (!candidate) return fallback;
  try {
    const parsed = new URL(candidate);
    if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname) return fallback;
    if (parsed.username || parsed.password || parsed.search || parsed.hash) return fallback;
    return parsed.toString().replace(/\/+$/, '');
  } catch {
    return fallback;
  }
}

export function normalizeSettings(storedValue) {
  const stored = storedValue && typeof storedValue === 'object' && !Array.isArray(storedValue)
    ? storedValue
    : {};
  const out = { ...DEFAULTS, ...stored };

  out.aiMode = AI_MODES.has(out.aiMode) ? out.aiMode : DEFAULTS.aiMode;
  out.endpoint = cleanHttpUrl(out.endpoint, DEFAULTS.endpoint) || DEFAULTS.endpoint;
  out.model = cleanText(out.model, DEFAULTS.model, 200) || DEFAULTS.model;
  out.apiKey = cleanText(out.apiKey, '', 4000);
  out.backendUrl = cleanHttpUrl(out.backendUrl, '');
  out.backendAccessToken = cleanText(out.backendAccessToken, '', 4000);
  out.assistantName = cleanText(out.assistantName, DEFAULTS.assistantName, 80) || DEFAULTS.assistantName;
  out.temperature = clampNumber(out.temperature, DEFAULTS.temperature, 0, 1.5);
  out.botSkill = Math.round(clampNumber(out.botSkill, DEFAULTS.botSkill, 0, 20));
  out.botElo = Math.round(clampNumber(out.botElo, DEFAULTS.botElo, 500, 3200));
  out.botDepth = Math.round(clampNumber(out.botDepth, DEFAULTS.botDepth, 5, 30));
  out.botMoveTimeMs = Math.round(clampNumber(out.botMoveTimeMs, DEFAULTS.botMoveTimeMs, 500, 5000));
  out.analysisMoveTimeMs = Math.round(clampNumber(out.analysisMoveTimeMs, DEFAULTS.analysisMoveTimeMs, 1000, 8000));
  const validClockPresets = new Set(['untimed', '1+0', '3+2', '5+0', '10+0', '15+10']);
  out.clockPreset = validClockPresets.has(out.clockPreset) ? out.clockPreset : DEFAULTS.clockPreset;
  out.botStrengthMode = out.botStrengthMode === 'elo' ? 'elo' : 'max';
  out.botEngine = ENGINE_MODES.has(out.botEngine) ? out.botEngine : DEFAULTS.botEngine;
  out.botEnginePreferenceSet = out.botEnginePreferenceSet === true;
  out.openingBookEnabled = out.openingBookEnabled !== false;
  out.soundEnabled = out.soundEnabled !== false;
  out.coachEngineMode = out.coachEngineMode === 'stockfish' ? 'stockfish' : 'api';

  // Old builds stored Lite as the implicit default. Migrate it unless the user
  // explicitly saved an engine choice, so new installs can use adaptive mode.
  if (!out.botEnginePreferenceSet && out.botEngine === 'lite-single') out.botEngine = 'auto';

  const sourceProfiles = Array.isArray(stored.aiProfiles) ? stored.aiProfiles : [];
  const seenIds = new Set(['stockfish', 'current']);
  out.aiProfiles = sourceProfiles.slice(0, 20).flatMap((profile, index) => {
    if (!profile || typeof profile !== 'object' || Array.isArray(profile)) return [];
    const name = cleanText(profile.name, '', 40);
    const endpoint = cleanHttpUrl(profile.endpoint, '');
    const model = cleanText(profile.model, '', 200);
    const aiMode = PROFILE_MODES.has(profile.aiMode) ? profile.aiMode : 'openai-compatible';
    let id = cleanText(profile.id, `profile-${index + 1}`, 100).replace(/[^a-zA-Z0-9._-]/g, '-');
    if (!id || seenIds.has(id)) id = `profile-${index + 1}`;
    while (seenIds.has(id)) id = `${id}-x`;
    seenIds.add(id);
    // Invalid/partial stored profiles are discarded rather than breaking render logic.
    if (!name || !endpoint || !model) return [];
    return [{ id, name, aiMode, endpoint, model, apiKey: cleanText(profile.apiKey, '', 4000) }];
  });
  return out;
}
