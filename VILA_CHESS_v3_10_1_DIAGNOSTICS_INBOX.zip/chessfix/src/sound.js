let audioContext = null;
function getAudioContext() {
  if (typeof window === 'undefined') return null;
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  try { audioContext ||= new Ctor(); return audioContext; } catch { return null; }
}
export function unlockBoardSound() {
  const ctx = getAudioContext();
  if (!ctx) return false;
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return true;
}
export function playBoardSound(move, chess, enabled = true) {
  if (!enabled || !move) return false;
  const ctx = getAudioContext();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    let notes;
    if (chess?.isCheckmate?.()) notes = [660, 523, 392];
    else if (chess?.isCheck?.()) notes = [660, 880];
    else if (move.captured || String(move.flags || '').includes('c') || String(move.flags || '').includes('e')) notes = [480, 620];
    else if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) notes = [520, 740];
    else notes = [460];
    notes.forEach((hz, index) => {
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(hz, now + index * 0.055);
      gain.gain.setValueAtTime(0.0001, now + index * 0.055);
      gain.gain.exponentialRampToValueAtTime(0.055, now + index * 0.055 + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.055 + 0.095);
      oscillator.connect(gain); gain.connect(ctx.destination);
      oscillator.start(now + index * 0.055); oscillator.stop(now + index * 0.055 + 0.11);
    });
    return true;
  } catch { return false; }
}


// Optional online piano recording: Gymnopedie No. 1, performed by Kevin MacLeod.
// Audio is only requested after the player presses the music button; a generated
// ambient fallback remains available offline or when a WebView blocks the URL.
const CLASSICAL_MUSIC_URL = 'https://upload.wikimedia.org/wikipedia/commons/2/2a/Gymnopedie_No._1_%28ISRC_USUAN1100787%29.mp3';
let musicAudio = null;
let musicTimer = null;
let musicStep = 0;
let musicEnabled = false;
let synthMusicActive = false;
const melody = [
  392.00, 493.88, 587.33, 493.88, 440.00, 523.25, 659.25, 523.25,
  349.23, 440.00, 523.25, 440.00, 329.63, 392.00, 493.88, 392.00,
  293.66, 369.99, 440.00, 369.99, 329.63, 392.00, 493.88, 392.00,
  261.63, 329.63, 392.00, 329.63, 293.66, 349.23, 440.00, 349.23
];
const chordRoots = [130.81, 146.83, 110.00, 123.47, 98.00, 110.00, 87.31, 98.00];
function stopSynthMusic() {
  if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
  synthMusicActive = false;
}
function playAmbientStep() {
  const ctx = getAudioContext();
  if (!ctx || !musicEnabled || !synthMusicActive) return;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    const index = musicStep % melody.length;
    const hz = melody[index];
    // Soft bell-like upper voice, with a long attack/release so it feels musical
    // rather than like the short UI click noises.
    const lead = ctx.createOscillator();
    const leadGain = ctx.createGain();
    const tone = ctx.createBiquadFilter();
    lead.type = 'sine'; lead.frequency.setValueAtTime(hz, now);
    tone.type = 'lowpass'; tone.frequency.setValueAtTime(1500, now);
    leadGain.gain.setValueAtTime(0.0001, now);
    leadGain.gain.exponentialRampToValueAtTime(0.012, now + 0.16);
    leadGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.28);
    lead.connect(tone); tone.connect(leadGain); leadGain.connect(ctx.destination);
    lead.start(now); lead.stop(now + 1.32);
    // Gentle sustained harmony and fifth, fading between steps.
    if (index % 4 === 0) {
      const root = chordRoots[Math.floor(index / 4) % chordRoots.length];
      [root, root * 1.5].forEach((frequency, voice) => {
        const osc = ctx.createOscillator(); const gain = ctx.createGain();
        osc.type = 'triangle'; osc.frequency.setValueAtTime(frequency, now);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.006 / (voice + 1), now + 0.22);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.2);
        osc.connect(gain); gain.connect(ctx.destination); osc.start(now); osc.stop(now + 2.25);
      });
    }
    musicStep += 1;
  } catch { /* Web Audio may be blocked by the current WebView/device. */ }
}
function startSynthMusic() {
  if (!musicEnabled || synthMusicActive) return;
  try { musicAudio?.pause(); } catch {}
  synthMusicActive = true;
  playAmbientStep();
  musicTimer = setInterval(playAmbientStep, 780);
}
function getClassicalAudio() {
  if (musicAudio || typeof window === 'undefined' || typeof window.Audio !== 'function') return musicAudio;
  musicAudio = new window.Audio(CLASSICAL_MUSIC_URL);
  musicAudio.loop = true;
  musicAudio.preload = 'none';
  musicAudio.volume = 0.22;
  musicAudio.addEventListener('error', () => { if (musicEnabled) startSynthMusic(); });
  return musicAudio;
}
async function startChessMusic() {
  const audio = getClassicalAudio();
  if (!musicEnabled) return;
  if (!audio) { startSynthMusic(); return; }
  try {
    stopSynthMusic();
    audio.currentTime = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
    await audio.play();
    synthMusicActive = false;
  } catch {
    startSynthMusic();
  }
}
export function isChessMusicPlaying() { return musicEnabled; }
export function setChessMusicPlaying(enabled) {
  musicEnabled = Boolean(enabled);
  if (!musicEnabled) {
    stopSynthMusic();
    try { if (musicAudio) { musicAudio.pause(); musicAudio.currentTime = 0; } } catch {}
    return false;
  }
  unlockBoardSound();
  void startChessMusic();
  return true;
}
