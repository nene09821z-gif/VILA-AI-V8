/** Local daily challenges and cosmetic rewards. These rewards are game points, not cash or online rank. */
export const DAILY_MISSIONS = Object.freeze([
  { id: 'checkin', title: 'Điểm danh hôm nay', description: 'Mở VILA Chess mỗi ngày để giữ chuỗi hoạt động.', event: 'checkin', goal: 1, reward: 10, icon: '☀' },
  { id: 'finish_game', title: 'Hoàn thành một ván', description: 'Chơi một ván với Stockfish hoặc AI và kết thúc ván.', event: 'complete_game', goal: 1, reward: 40, icon: '♟' },
  { id: 'opening_visit', title: 'Học một khai cuộc', description: 'Mở thư viện khai cuộc và xem các biến mở đầu.', event: 'visit_openings', goal: 1, reward: 20, icon: '⌘' },
  { id: 'coach_visit', title: 'Học cùng AI Coach', description: 'Mở AI Coach để khám phá chiến thuật và kế hoạch.', event: 'visit_coach', goal: 1, reward: 20, icon: '✦' }
]);

export const COSMETICS = Object.freeze([
  { id: 'classic', name: 'Cổ điển', description: 'Xanh lá và kem truyền thống.', cost: 0, icon: '♟', colors: ['#eeeed2', '#769656'], defaultOwned: true },
  { id: 'ocean', name: 'Đại dương', description: 'Bàn cờ xanh biển dịu mắt.', cost: 100, icon: '🌊', colors: ['#d8eaf0', '#4d8298'] },
  { id: 'walnut', name: 'Gỗ óc chó', description: 'Tông gỗ ấm, cổ điển.', cost: 150, icon: '🪵', colors: ['#ead5b7', '#986543'] },
  { id: 'midnight', name: 'Nửa đêm', description: 'Bàn cờ than chì và bạc.', cost: 200, icon: '🌙', colors: ['#cbd4df', '#475568'] }
]);

const own = (value) => value && typeof value === 'object' && !Array.isArray(value);
const clampInt = (value, min = 0, max = 1_000_000) => Math.max(min, Math.min(max, Math.floor(Number(value) || 0)));
export function localDayKey(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function previousDayKey(key) {
  const [year, month, day] = String(key).split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() - 1);
  return localDayKey(d);
}
export function createDailyState(date = new Date()) {
  const day = localDayKey(date);
  return {
    version: 1, day, lastVisitDay: day, streak: 1, coins: 0,
    missionProgress: { checkin: 1 }, claimed: [],
    stats: { gamesCompleted: 0, openingsVisited: 0, coachVisited: 0 },
    ownedCosmetics: ['classic'], activeCosmetic: 'classic'
  };
}
export function normalizeDailyState(input, date = new Date()) {
  const base = createDailyState(date);
  if (!own(input)) return base;
  const state = {
    ...base, ...input,
    day: typeof input.day === 'string' ? input.day : base.day,
    lastVisitDay: typeof input.lastVisitDay === 'string' ? input.lastVisitDay : '',
    streak: clampInt(input.streak), coins: clampInt(input.coins),
    missionProgress: own(input.missionProgress) ? { ...input.missionProgress } : {},
    claimed: Array.isArray(input.claimed) ? input.claimed.filter(id => DAILY_MISSIONS.some(m => m.id === id)) : [],
    stats: own(input.stats) ? { ...base.stats, ...input.stats } : { ...base.stats },
    ownedCosmetics: Array.isArray(input.ownedCosmetics) ? [...new Set(input.ownedCosmetics.filter(id => COSMETICS.some(c => c.id === id)))] : ['classic'],
    activeCosmetic: COSMETICS.some(c => c.id === input.activeCosmetic) ? input.activeCosmetic : 'classic'
  };
  state.stats = Object.fromEntries(Object.entries(state.stats).map(([key, value]) => [key, clampInt(value)]));
  if (!state.ownedCosmetics.includes('classic')) state.ownedCosmetics.unshift('classic');
  if (!state.ownedCosmetics.includes(state.activeCosmetic)) state.activeCosmetic = 'classic';
  if (state.day !== localDayKey(date)) {
    const today = localDayKey(date);
    if (state.lastVisitDay !== today) state.streak = state.lastVisitDay === previousDayKey(today) ? state.streak + 1 : 1;
    state.day = today;
    state.lastVisitDay = today;
    state.missionProgress = { checkin: 1 };
    state.claimed = [];
  }
  state.missionProgress.checkin = 1;
  for (const mission of DAILY_MISSIONS) state.missionProgress[mission.id] = Math.min(mission.goal, clampInt(state.missionProgress[mission.id]));
  return state;
}
export function recordMissionEvent(input, event, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const mission = DAILY_MISSIONS.find(item => item.event === event);
  if (!mission) return state;
  state.missionProgress[mission.id] = Math.min(mission.goal, (state.missionProgress[mission.id] || 0) + 1);
  if (mission.id === 'finish_game') state.stats.gamesCompleted = clampInt(state.stats.gamesCompleted + 1);
  if (mission.id === 'opening_visit') state.stats.openingsVisited = clampInt(state.stats.openingsVisited + 1);
  if (mission.id === 'coach_visit') state.stats.coachVisited = clampInt(state.stats.coachVisited + 1);
  return state;
}
export function claimMissionReward(input, missionId, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const mission = DAILY_MISSIONS.find(item => item.id === missionId);
  if (!mission) return { state, ok: false, reason: 'unknown_mission', reward: 0 };
  if ((state.missionProgress[mission.id] || 0) < mission.goal) return { state, ok: false, reason: 'not_completed', reward: 0 };
  if (state.claimed.includes(mission.id)) return { state, ok: false, reason: 'already_claimed', reward: 0 };
  state.claimed.push(mission.id);
  state.coins = clampInt(state.coins + mission.reward);
  return { state, ok: true, reason: '', reward: mission.reward };
}
export function purchaseCosmetic(input, cosmeticId, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const item = COSMETICS.find(c => c.id === cosmeticId);
  if (!item) return { state, ok: false, reason: 'unknown_item' };
  if (state.ownedCosmetics.includes(item.id)) return { state, ok: false, reason: 'already_owned' };
  if (state.coins < item.cost) return { state, ok: false, reason: 'not_enough_coins' };
  state.coins -= item.cost;
  state.ownedCosmetics.push(item.id);
  return { state, ok: true, reason: '' };
}
export function equipCosmetic(input, cosmeticId, date = new Date()) {
  const state = normalizeDailyState(input, date);
  if (!COSMETICS.some(c => c.id === cosmeticId)) return { state, ok: false, reason: 'unknown_item' };
  if (!state.ownedCosmetics.includes(cosmeticId)) return { state, ok: false, reason: 'not_owned' };
  state.activeCosmetic = cosmeticId;
  return { state, ok: true, reason: '' };
}
export function getMissionSummary(input, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const completed = DAILY_MISSIONS.filter(m => (state.missionProgress[m.id] || 0) >= m.goal).length;
  const claimed = state.claimed.length;
  return { coins: state.coins, streak: state.streak, completed, total: DAILY_MISSIONS.length, claimed };
}
