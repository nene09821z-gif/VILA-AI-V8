# Test report — Chess Bot v1.8.1

Date: 2026-10-16

## Results executed in this environment

- `node --check server/index.js`: PASS
- `node --check server/ai-request.js`: PASS
- `node --check src/main.js`: PASS
- `npm run test:static`: PASS — 49 tests, 49 passed, 0 failed.
- `node --test tests/*.test.js`: 50 discovered; 49 passed, 1 failed to load because `chess.js` is not installed (`ERR_MODULE_NOT_FOUND`). The failure is an unavailable dependency, not a failed chess assertion.
- `npm install --no-audit --no-fund`: did not complete before the environment timeout; no `node_modules` was available.

## Changes covered by tests

- Provider payload builder tests cover Gemini role mapping and `maxOutputTokens`, Anthropic `max_tokens`, OpenAI-compatible `max_tokens`, output bounds, temperature bounds, and context truncation.
- Existing static tests cover engine profile selection, MultiPV parsing, clock presets, endpoint construction, UI structure, timeout/cancellation guards, and Android workflow requirements.

## Not verified here

- Live provider latency or API correctness against real keys/endpoints.
- Real Stockfish WASM execution/benchmark.
- Full `chess.js` rules tests, Vite production build, Capacitor/Gradle APK build, or on-device touch/layout performance on OPPO A17k.

Run `npm ci`, `npm test`, `npm run build`, then the repository GitHub Actions Android workflow in an environment with registry access and Android build support. Do not treat this report as an APK or device certification.
