# Kế hoạch tối ưu Chess Bot Android — v2.7.0

Ngày rà soát: 2026-10-16

## Mục tiêu

Giữ các luồng chơi hiện có (Stockfish, AI qua API, đấu trường, khai cuộc, Coach, Lichess, PGN và cài đặt), đồng thời giảm thời gian chờ trên điện thoại phổ thông, làm bàn cờ dễ chạm hơn ở màn hình hẹp, thêm phân tích nhiều biến và đồng hồ theo kiểu cờ nhanh/chess.com.

## 1. Stockfish: nhanh hơn mà không giả vờ mạnh hơn

- Nước đi của bot dùng `go movetime` có giới hạn, mặc định 1200 ms và có thể đặt từ 500–5000 ms; giới hạn depth vẫn được dùng làm trần chứ không ép engine chờ đến depth bằng mọi giá.
- Nếu WebView không báo rõ dung lượng RAM hoặc báo dưới 4 GB, Hash đặt 16 MB; trường hợp báo từ 4 GB trở lên đặt 32 MB. Engine vẫn chạy single-thread để tránh giả định `SharedArrayBuffer`/cross-origin isolation có sẵn.
- Watchdog giúp thoát khỏi tìm kiếm bị treo và chuyển sang nước đi hợp lệ dự phòng. Nước dự phòng chỉ bảo đảm ván không bị kẹt, không được xem là sức mạnh Stockfish.
- `MultiPV 3` dành cho phân tích chủ động; khi chơi nước chính/gợi ý/đấu trường, MultiPV được trả lại 1 để không phí thời gian cho các nhánh phụ.

### Cấu hình khuyến nghị ban đầu cho OPPO A17k

1. Engine: **Tự động** hoặc **Lite Single**.
2. Thời gian mỗi nước: **1200 ms**; tăng lên **1800–2500 ms** nếu ưu tiên chất lượng nước hơn phản hồi nhanh.
3. Hash: tự chọn 16 MB nếu trình duyệt không báo RAM; tránh tăng mạnh vì có thể gây áp lực bộ nhớ.
4. Chỉ thử **Full Single** khi chấp nhận tải khoảng 94 MB và thiết bị đủ bộ nhớ/trống dung lượng. Gói Lite single khoảng 1,7 MB còn Full single khoảng 94 MB; bản đa luồng cần cross-origin isolation, không nên bật chỉ để hy vọng nhanh hơn trong WebView Android.
5. Sau 5–10 ván, kiểm tra nóng máy, tụt khung hình, thời gian tải engine và độ mạnh thực tế trước khi tăng thời gian tìm kiếm.

Giới hạn thời gian thấp làm app phản hồi nhanh hơn nhưng cũng có thể giảm chất lượng tìm kiếm. Không thể khẳng định Elo hoặc FPS đạt mức cụ thể nếu chưa chạy benchmark trên máy thật.

## 2. Bàn cờ và giao diện 360 CSS px

- Bàn cờ dùng lưới 8×8 với ô vuông, giới hạn tỷ lệ 1:1, kiểm soát overflow và vùng chạm; breakpoint riêng cho màn hình hẹp.
- Đồng hồ và bảng phân tích được bố trí lại cho mobile, hạn chế tràn ngang.
- Mốc `360 CSS px` là mục tiêu bố cục, không nhất thiết bằng 360 pixel vật lý của điện thoại. Cần xác minh với viewport thật của OPPO A17k, vì cỡ chữ hệ thống, thanh điều hướng và WebView có thể làm thay đổi phần không gian sử dụng.

## 3. Phân tích nhiều biến và đồng hồ

- Thêm bảng `MultiPV 3`, đọc tối đa ba phương án, chuyển nước UCI thành SAN và hiển thị điểm theo quy ước điểm dương có lợi cho Trắng.
- Phân tích dùng ngân sách riêng mặc định 2600 ms (cài đặt 1000–8000 ms), tự dừng khi hết ngân sách hoặc thế cờ đã thay đổi.
- Đồng hồ cục bộ có các preset `1+0`, `3+2`, `5+0`, `10+0`, `15+10`, và không giới hạn; xử lý increment, flag hết giờ và đặt lại khi tạo ván mới.
- Đồng hồ cho trận Lichess tiếp tục do Lichess quản lý, không chạy đồng hồ cục bộ trùng lặp.

## 4. API và model inventory

- Gemini: gọi `GET /v1beta/models` và theo `nextPageToken`; chat gọi `POST /v1beta/models/{model}:generateContent`.
- Anthropic: gọi `GET /v1/models?limit=1000&after_id=...`; chat gọi `POST /v1/messages`.
- OpenAI-compatible: dùng `GET /v1/models` và `POST /v1/chat/completions` theo base URL của nhà cung cấp.
- App lấy model từ endpoint và API key đang cấu hình, lọc model Gemini không hỗ trợ `generateContent`, và vẫn cho phép nhập Model ID thủ công cho proxy tương thích. Tên model/quyền truy cập phụ thuộc nhà cung cấp, tài khoản và API key; không có danh sách chung nào bảo đảm model nào cũng dùng được trên mọi endpoint.
- API key gửi qua request đến backend; khi triển khai công khai phải dùng HTTPS, cấu hình mã truy cập backend và không đưa key vào mã nguồn/repository. Không commit `.env`.

## 5. Cổng kiểm thử trước khi phát hành

### Đã chạy trong môi trường chỉnh sửa

- `npm run test:static`: 46/46 pass.
- Kiểm tra cú pháp JavaScript/MJS; kiểm tra JSON/XML.
- Unit test cho endpoint URL, thông số đồng hồ, parser MultiPV, schema cài đặt và cấu trúc UI.

### Chưa xác minh, không được coi là đạt

- Bộ `npm test` đầy đủ không tải được `chess.js` trong môi trường này vì dependencies chưa cài; không có `package-lock.json`, và việc cài package bị hết thời gian chờ. Bài luật cờ không chạy.
- Stockfish JS/WASM thật chưa được copy vào `public/engine`, nên chưa benchmark UCI/search trong container.
- Chưa chạy Vite production build, kết nối live đến API nhà cung cấp, Capacitor/Gradle, APK trên thiết bị hoặc test touch/heat/FPS thật trên OPPO A17k.

### Trình tự bắt buộc trên GitHub Actions hoặc máy có mạng

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
REQUIRE_STOCKFISH=1 npm run build
npm run android:init
cd android && ./gradlew assembleDebug
```

Sau khi build, cài APK vào thiết bị và thử ít nhất: tạo ván, đi quân/chọn phong cấp, hoàn tác, đổi màu, gợi ý, MultiPV, hết giờ/increment, AI API (Gemini/OpenAI-compatible/Anthropic nếu có key), Arena, PGN và Lichess. Chỉ phát hành sau khi cả workflow build và các luồng quan trọng trên thiết bị đều đạt.
