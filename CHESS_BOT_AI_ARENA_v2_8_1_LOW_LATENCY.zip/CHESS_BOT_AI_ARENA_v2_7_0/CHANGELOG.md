# Changelog

## v2.6.1 — Stability Fix (package version 1.6.1)

- Giữ bản nháp AI Coach khi có yêu cầu khác đang chạy.
- Timeout API dùng chung 90 giây và hỗ trợ abort từ caller.
- Kiểm tra cấu hình trước khi vào chế độ AI; không tự chuyển lỗi cấu hình thành nước đi dự phòng mà không cảnh báo.
- Hủy upstream Lichess đúng cách khi client disconnect.
- Xử lý NDJSON record cuối khi không có newline kết thúc.
- Thêm 5 kiểm tra hồi quy tĩnh.
- Đồng bộ phiên bản `/api/health` và tài liệu.
- Xác minh static 36/36; full tests/build bị giới hạn bởi DNS/npm dependency trong môi trường rà soát.

## v2.6.2 — CI test compatibility fix
- Fixed the en-passant test expectation: `Chess#get()` returns `undefined` for an empty square in chess.js 1.4.0, not `null`.
- Kept the en-passant move sequence and board-state assertions intact; this fixes the incorrect test expectation rather than skipping the test.


## v2.7.0 — Stockfish responsiveness + mobile chess UX (package version 1.7.0)

- Replaced depth-only main move searches with bounded `go movetime` searches and watchdog/fallback handling; move budget is configurable from 500–5000 ms.
- Use conservative Hash allocation (16 MB below 4 GB/unknown WebView memory, otherwise 32 MB); retain single-thread UCI for reliable Android WebView operation.
- Added a three-line Stockfish MultiPV panel with score, depth and SAN variations.
- Added bullet/blitz/rapid local clocks with per-move increments and flag-fall handling.
- Tightened 8×8 board geometry and responsive controls for narrow mobile screens.
- Added provider model discovery endpoint and an actual model dropdown for Gemini, Anthropic and OpenAI-compatible endpoints. Gemini uses `GET /v1beta/models` and `:generateContent`; model IDs come from the selected API key and provider response.
- Added dedicated tests for clocks, UCI MultiPV parsing, and provider URL construction; static suite passes 46/46 in this environment.
- Full chess-rule test and production/Android engine build remain unverified because dependencies and Stockfish JS/WASM assets are not installed locally.

## v1.8.0 — Low-latency AI and reliability
- Added provider-specific, bounded chat payload construction for Gemini, Anthropic, and OpenAI-compatible APIs.
- Reduced AI Coach conversation context to the latest six messages and bounded PGN context to the latest 1,800 characters.
- Reduced default AI Coach output to 384 tokens, temperature to at most 0.5, and request timeout to 30 seconds; API move selection retains its tighter 11-second timeout and Stockfish fallback.
- Added server-side request timeout clamping (3–60 seconds) and explicit 504 timeout responses.
- Added regression tests for provider payload mapping, token limits, and context truncation.

## v1.8.1 — Faster API moves and safer fallback
- Reduced API move output budget to a tiny UCI response (8-token minimum supported by payload builder) and set an 11-second upstream timeout / 12-second client timeout for AI move selection.
- Removed automatic retry after transport/provider failures during AI-vs-AI turns; retry is retained only when a successful model response contains invalid UCI, avoiding doubled wait and API cost.
- On normal AI-vs-player API failure, try a short real Stockfish search first; only use the legal-move heuristic if local engine is unavailable/busy.
- AI Coach is bounded to 700 output tokens with a 45-second provider timeout and a 48-second client timeout.
- Added/updated payload-bound tests; static regression suite passes 49/49. Full chess-rule suite and production build still require dependencies/engine assets unavailable in this environment.

## v1.8.1 — AI API latency pass
- Provider-aware payload builder applies bounded output/context defaults across Gemini, Anthropic, and OpenAI-compatible endpoints.
- AI Coach now sends only recent conversation context, trims PGN context, caps output at 384 tokens, and uses a 30-second provider deadline (35-second client guard).
- API game move selection keeps its short timeout and local Stockfish fallback; all returned API moves remain checked against legal moves.
- Added 3 executable unit tests for payload construction and bounds.
