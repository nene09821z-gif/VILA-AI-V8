# Chess Bot AI Arena — Báo cáo rà soát (cập nhật v1.7.0)

## Tổng quan

Rà soát ZIP `CHESS_BOT_AI_ARENA_v2_6.zip`, tập trung vào đường đi của yêu cầu API, AI Coach, chế độ AI và stream Lichess. Bản sửa giữ các tính năng hiện có, không xóa tài nguyên chỉ dựa trên tên.

## Mức độ và kết quả

### Đã sửa

- **P1 — Bản nháp AI Coach bị mất khi gửi trùng:** guard được thực hiện trước khi xóa nội dung ô nhập.
- **P1 — Yêu cầu API có thể treo vô hạn:** thêm timeout 90 giây trong helper dùng chung; giữ hỗ trợ hủy từ caller.
- **P1 — Vào chế độ AI khi thiếu API key bắt buộc:** kiểm tra cấu hình trước khi bắt đầu/chọn chế độ, đồng thời chặn bắt đầu ván mới nếu cấu hình bị thiếu.
- **P1 — Dừng stream Lichess không hủy upstream đúng cách:** gắn `AbortController` vào request tới Lichess; hủy controller và Node stream khi client đóng kết nối.
- **P2 — Bản ghi NDJSON cuối không có newline bị bỏ qua:** flush `TextDecoder` và đọc dòng pending cuối cùng.
- **P2 — Phiên bản health endpoint lệch package:** đồng bộ thành 1.6.1.

### Còn mở

- Full suite và luật cờ chưa chạy được do `chess.js` chưa cài; truy cập registry npm thất bại do DNS `EAI_AGAIN`.
- Chưa build production, Stockfish WASM runtime hoặc APK/AAB.
- Chưa có `package-lock.json`; cần sinh trong môi trường có mạng và dùng quy trình cài dependencies ổn định trước khi phát hành.
- Chưa thử bằng giao diện/thiết bị thật nên chưa thể xác nhận tất cả tương tác.

## Không xóa

Giữ lại các script kiểm tra, thư viện, assets thương hiệu và cấu hình Android đang được tham chiếu. Không đưa `node_modules`, bản build tạm hoặc APK chưa được tạo/xác minh vào ZIP nguồn.


## Bổ sung rà soát v1.7.0 — Stockfish, bàn cờ và model endpoint

- **Stockfish response budget:** game move now uses bounded `go movetime` and a watchdog; the default is 1200 ms and can be adjusted. Lower time decreases latency but can reduce search quality; this is a controlled trade-off rather than a strength guarantee.
- **Memory safety:** Hash uses 16 MB for unknown/sub-4-GB WebView memory, 32 MB otherwise. Engine remains single-thread UCI to avoid assuming browser shared-memory/cross-origin-isolation support.
- **Board geometry:** 8 equal grid columns and rows with square cells, clipped piece glyphs and breakpoints for ≤680/≤380 CSS px. The CSS change is not a physical-device certification; OPPO A17k touch/viewport tests remain open.
- **Analysis/clock:** MultiPV 3 panel, SAN conversion and local chess clocks with increment and flagging added. Added guards against analysis after game completion/time flag.
- **Model discovery:** provider URL helpers were extracted into `server/provider-endpoints.js` for unit testing. Live inventory is fetched from provider endpoints; actual available models depend on the user's endpoint/key/permissions.
- **Verification:** 46/46 static tests pass. Full rules test could not load missing `chess.js`; engine JS/WASM assets are absent in the environment, so real engine search, production build and APK are not verified.
