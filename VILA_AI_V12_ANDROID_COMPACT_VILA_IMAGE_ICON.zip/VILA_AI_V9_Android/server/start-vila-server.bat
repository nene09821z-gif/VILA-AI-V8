@echo off
setlocal
if not exist node_modules call npm install
if not exist .env copy .env.example .env
for /f "tokens=1,* delims==" %%A in (.env) do if "%%A"=="GEMINI_API_KEY" set GEMINI_API_KEY=%%B
set PORT=8787
node server.js
