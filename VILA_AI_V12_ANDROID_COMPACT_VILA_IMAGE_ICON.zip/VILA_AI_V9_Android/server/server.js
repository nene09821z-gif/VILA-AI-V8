const express = require('express');
const path = require('path');
const fs = require('fs');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/openai';
const GEMINI_NATIVE = 'https://generativelanguage.googleapis.com/v1beta/models';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.static(__dirname, { extensions: ['html'] }));

const sleep = ms => new Promise(r => setTimeout(r, ms));
const retryable = s => [408, 429, 500, 502, 503, 504].includes(Number(s));

async function geminiChat(body) {
  if (!GEMINI_KEY) {
    const e = new Error('Server chưa có GEMINI_API_KEY trong biến môi trường.'); e.status = 500; throw e;
  }
  const models = [...new Set([
    body.model,
    'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash',
    'gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'
  ].filter(Boolean))];
  let last;
  for (const model of models) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const r = await fetch(`${GEMINI_BASE}/chat/completions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${GEMINI_KEY}` },
          body: JSON.stringify({ model, messages: body.messages || [], temperature: Number(body.temperature ?? 0.2), max_tokens: Math.min(Number(body.max_tokens || 8192), 16384) })
        });
        const text = await r.text();
        let data = {}; try { data = text ? JSON.parse(text) : {}; } catch {}
        if (r.ok) return { ...data, model };
        last = new Error(data?.error?.message || `Gemini HTTP ${r.status}`); last.status = r.status;
        if (r.status === 429) break;
        if (!retryable(r.status)) break;
        await sleep(800 * (attempt + 1));
      } catch (e) { last = e; if (attempt) break; await sleep(800); }
    }
  }
  throw last || new Error('Không thể kết nối Gemini.');
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'VILA AI Server', apiKeyConfigured: !!GEMINI_KEY, time: new Date().toISOString() }));

app.get('/api/config', (_req, res) => res.json({ ok: true, serverMode: true, apiKeyConfigured: !!GEMINI_KEY, maxTokens: 16384 }));

app.post('/api/chat', async (req, res) => {
  try { res.json(await geminiChat(req.body || {})); }
  catch (e) { res.status(Number(e.status) || 500).json({ message: e.message, status: e.status || 500, retryAfterMs: e.status === 429 ? 3000 : 0 }); }
});

app.post('/api/search', async (req, res) => {
  try {
    if (!GEMINI_KEY) return res.status(500).json({ message: 'Server chưa có GEMINI_API_KEY.' });
    const model = req.body?.model || 'gemini-3.8-flash';
    const messages = req.body?.messages || [];
    const system = messages.find(x => x.role === 'system');
    const contents = messages.filter(x => x.role === 'user' || x.role === 'assistant').map(x => ({ role: x.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(x.content || '') }] }));
    const payload = { contents, tools: [{ google_search: {} }], generationConfig: { temperature: 0.2, maxOutputTokens: 8192 } };
    if (system) payload.systemInstruction = { parts: [{ text: String(system.content || '') }] };
    const r = await fetch(`${GEMINI_NATIVE}/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(GEMINI_KEY)}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    const text = await r.text(); let data={}; try{data=text?JSON.parse(text):{}}catch{}
    if(!r.ok) return res.status(r.status).json({message:data?.error?.message||`Search HTTP ${r.status}`});
    const aiReply=(data?.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();
    const chunks=data?.groundingMetadata?.groundingChunks||[];
    const sources=chunks.map(c=>c.web).filter(w=>w?.uri).filter((w,i,a)=>a.findIndex(x=>x.uri===w.uri)===i).slice(0,8);
    const answer=aiReply+(sources.length?'\n\n### Nguồn Web\n'+sources.map((s,i)=>`${i+1}. [${s.title||s.uri}](${s.uri})`).join('\n'):'');
    res.json({ok:true,aiReply:answer,model});
  } catch(e){ res.status(500).json({message:e.message}); }
});

app.get('*', (_req,res)=>res.sendFile(path.join(__dirname,'VILA_AI_Studio_Free_V8_SERVER_VIP.html')));

app.listen(PORT, HOST, ()=>console.log(`VILA AI Server running on http://${HOST}:${PORT}`));
